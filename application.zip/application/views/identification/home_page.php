<?php
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {reloadSection();}";
?>
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet" />
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/refinedByFilter.css" />
<link href="<?php echo base_url();?>c3js/c3.css" rel="stylesheet" type="text/css">
    
    <!-- Load d3.js and c3.js -->
    <script src="<?php echo base_url();?>c3js/d3.v3.min.js" charset="utf-8"></script>
    <script src="<?php echo base_url();?>c3js/c3.min.js"></script>  
	<!-- JQGrid Plugins -->
<style>
	#rssfeed_content{
		border:1px solid #1A5C76;
		border-top:5px solid #1A5C76;
		padding-left:10px;
	}
	
	#tabs1 a{
		display:block;
		width:auto;
		float:left;
		border:1px solid #D0CCC9;
		text-align: center;
		margin-right:5px;
		background-color: #EFEFEF;
		padding: 5px 0;
		text-decoration: none;
		margin-right:0px;
		cursor: pointer;
		border-radius: 7px 7px 0 0;
		color: #333333;
		font-size: 13px;
		padding: 5px 21px;
	}
	
	#tabs1 div.divider{
		display: inline;
		width: 3px;
		border: 0px;
		border-bottom: 1px solid #D0CCC9;
		display: block;
	    float: left;
	    height: 29px;
	    margin-top: 2px;
	}
	#tabs1 a.current{
		background-color: #FFFFFF;
		border-bottom:1px solid #FFFFFF;
		z-index: 100;
		font-weight: bold;
	}
/*	#tabs1 div.lastRight{
		width: 188px;
	}
*/
	#tabs1 div.firstRight{
		width: 0px;
	}
	#tabs1{
		border-bottom: 0 none;
	    clear: both;
	    color: #898989;
	    float: left;
	    padding-bottom: 0;
	    padding-left: 0;
	    z-index: 1;
	    margin-top: 10px;
	}
	
	.min, .max {
   	font-size: 11px;
    text-align: center;
    width: 30px;
}

 /**** UI Slider ****/
.timeLineSliderContainer{
 	text-align:left;
 	margin-bottom:-10px;
	border:0 none;
	margin-right: 5px;
	width: 100%;
 }
 
.timeLineSliderContainer .ui-widget-content {
 	height: 1px;
    margin-left: 81px;
    margin-top: 7px;
    min-width: 100px;
    overflow: visible;
    width: 200px;
 }
 
.timeLineSliderContainer .ui-widget-header{
 	height:3px;
 	background: #4572A7;
 }
 
.timeLineSliderContainer p{
 	margin:0;
 	padding:0;
 }
 .frozen-bdiv{
  height:419px !important;   
 }
.timeLineSliderContainer .ui-slider-horizontal .ui-slider-handle{
 	background-image: url(<?php echo base_url();?>images/slider_handle.gif) !important;
 	background-repeat: no-repeat;
 	background-color: none;
 	width:11px;
 	height:13px;
 	border:0;
 	width:20px;
 	height:15px;
 	margin-top: -4px;
 }
 
.timeLineSliderContainer p{
	background-color: #FFFFFF;
  	font-size:10px;
  	margin-bottom:12px;
  	margin-left:5px;
  	margin-top:-25px;
}

.timeLineSliderContainer p label{
  	font-size:11px;
}

.timeLineSliderContainer #yearRange{
	display:inline;
  	width:80px;
	font-size:10px;
}

.timeLineSliderContainer .ui-slider-horizontal .ui-slider-handle{
    background-image: url("<?php echo base_url();?>images/kolm-sprite-image.png") !important;
	background-position: -75px -6px;
    background:url("<?php echo base_url();?>images/all_icons.png") repeat scroll 38% -35% transparent !important;
    cursor: pointer !important;
    
}

#customWeightage{
	padding: 0px;
}

#customWeightageSection table td{
 	vertical-align: top;
 	border-bottom: 1px solid #BBBBBB;
    border-left: 1px solid #BBBBBB;
    border-right: 1px solid #BBBBBB;	
    padding: 2px;
}
.firstcol{
	width: 50%;
}
.sliderWithLabel{
	overflow: hidden;
	display: inline-block;
	width: 300px;
	min-height: 33px;
}
.child-range .sliderWithLabel{
	width: 278px;
}
.parent-range {
	position: relative;
}
.sliderWithLabel label{
	display: inline-block;
    float: left;
    text-align: left;
    width: 124px;
    font-weight: normal;
}
.parent-range .sliderWithLabel label{
	width: 90px;
	font-weight: bold;
}
.sliderWithLabel .oneSlider{
	display: inline-block;
    margin-left: 9px;
    width: 48%;
}

#customWeightageSection .twoSlider {
	display: inline-block;
	margin-left: 10px;
    width: 150px;
    position: absolute;
    right: 20px;
}
.sec1,.sec2{
	display: inline-block;
	float: left;
}
.sec1{
	width: 55%;
	padding-left: 15px;
}
.sec2{
	width: 40%;
	text-align: right;
}
#totalWeight{
    /*background-color: #2b9af3;
    font-size: 12px;
    color: white;
    font-weight: bold;*/
    width: 39px;
    font-size: 20px;
}
.exceeded{
	border: 2px solid red;
}

.rankEqual{
    background: url("<?php echo base_url();?>images/no_change_blue.svg") no-repeat scroll 0 1px / 16px auto transparent;
      display: inline-block;
    height: 18px;
    padding-left: 5px;
    width: 12px;
    height: 18px;
    padding-left: 6px;
    /* margin-top: -5px; */
    width: 12px;
    margin-left: 2px;
}
.rankUp{
	background: url("<?php echo base_url();?>images/up_arrow.svg") no-repeat scroll 0 1px / 16px auto transparent;
    display: inline-block;
    height: 18px;
    padding-left: 5px;
    width: 12px;
    height: 18px;
    padding-left: 6px;
    /* margin-top: -5px; */
    width: 12px;
    margin-left: 2px;
}
.rankDown{
	background: url("<?php echo base_url();?>images/down_arrow.svg") no-repeat scroll 0 1px / 16px auto transparent;
    display: inline-block;
    height: 18px;
    padding-left: 5px;
    width: 12px;
    height: 18px;
    padding-left: 6px;
    /* margin-top: -5px; */
    width: 12px;
    margin-left: 2px;
}

#rankingGridContainer{
	
}
.ui-th-ltr, .ui-jqgrid .ui-jqgrid-htable th.ui-th-ltr {
	text-align: center;
}
.totalColumn{
	background: #EEEEEE;
}
.gridWrapper .ui-jqgrid tr.jqgrow td{
	padding-left: 5px;
}
#rankingGridContainer .userSettings{
	position: absolute;
    right: 0;
}

#tabs1 .sprite_iconSet{
	margin-top: -3px !important;
	float: right;
}
.trendsIcon{
	background-image: url("<?php echo base_url();?>images/trends.png");
    background-repeat: no-repeat;
    background-size: 17px auto;
}
.jqg-second-row-header th{
	border-left: 1px solid #bbbbbb !important;
}
#sideBarContents #secondaryNav ul li{
	background: none;
	border: medium none;
	position: relative;
}
#sideBarContents #secondaryNav ul li:hover{
	background: none;
}
#showWeighatages{
	background: #eeeeee;
}
#showWeighatages .weight{
	color: green;
	position: absolute;
	right: 0;
}
#showWeighatages .child .weight{
	right: 10px;
}
#showWeighatages li.child{
	padding-left: 10px;
}
#showWeighatages li label{
	font-weight: normal;
}
#sideBarContents,#sideBarWrapper{
	width: 160px;
}

.keywordSearch{
	display: inline;
}
.keywordSearch ul{
	border-color: #EEEEEE -moz-use-text-color #EEEEEE #EEEEEE;
    border-image: none;
    border-style: solid none solid solid;
    border-width: 1px 0 1px 1px;
    display: inline-block;
    float: left;
    height: 28px;
    list-style: none outside none;
    margin: -2px 0 0;
    padding: 0 0 0 0;
}
.keywordSearch ul li{
	background: none repeat scroll 0 0 #EEEEEE;
    float: left;
    height: 21px;
    margin: 2px 0 0 5px;
    padding-left: 5px;
    padding-right: 5px;
    padding-top: 3px;
}
.keywordSearch ul li span.removeKeyword{
	font-family: Arial, Helvetica, sans-serif !important;
	font-size: 16px !important;
	line-height: 18px;
	float: right;
	margin: 1px 0 0 5px;
	padding: 0;
	cursor: pointer;
	color: #A6B4CE;
}
.keywordSearch input[name='keywords']{
	height: 22px;
	width: 250px;
}

#sideBarContents #secondaryNav ul li a{
	
}
#weightageSettingOptions a{
	background: transparent !important;
}
.excelExportIcon {
    float: right;
    margin-right: 26px;
    margin-top: -2px;
}
#filtersApplied{
	margin-bottom: 5px;
	margin-top: 5px;
	float: left;
	margin-left: 36px;
}
#addFilters1 {
    background: url("<?php echo base_url();?>images/ipad/save_active.png");
    background-repeat: no-repeat;
    background-size: 14px;
    cursor: pointer;
    display: inline;
    padding-right: 16px;
    margin-left: 5px;
    
}
#addFilters:HOVER #addFilters1{
	background: url("<?php echo base_url();?>images/ipad/save_inactive.png");
    background-repeat: no-repeat;
    background-size: 14px;
	display: inline;
	cursor: pointer;
	padding-right: 16px;
}
#sideBarContents, #sideBarWrapper{
	min-height: 500px;
}
#leftSideBar{
	padding-top: 40px;
}
a.blueButton{
	height: 24px;
	padding-left: 0px;
}
a.blueButton span{
	background-image: url("<?php echo base_url();?>images/mixer-128.png");
    background-repeat: no-repeat;
    background-size: 23px auto;
    display: inline-block;
    height: 23px;
    vertical-align: middle;
    width: 23px;
    margin-right: 6px;
}

.frozen-div{
	background: none repeat scroll 0 0 white !important;
    height: 75px !important;
    top: 43px !important;
    overflow:hidden !important;
}
.frozen-div > table{
	padding-top: 20px;
}


.ui-jqgrid-bdiv{
	/*height:1200px !important;*/
}
@-moz-document url-prefix() {
    .frozen-bdiv {
       
    }
   .ui-jqgrid-bdiv{
	top: -27px;
	}
}

@media screen and (-webkit-min-device-pixel-ratio:0) { 
	.frozen-bdiv{
			
	}
	 .ui-jqgrid-bdiv{
	top: -27px;
	}
}

.frozen-div.ui-state-default.ui-jqgrid-hdiv{
	top:30px !important;
	height: 88px !important;
	border-bottom:0px !important;
}
.frozen-div .ui-jqgrid-sortable{
	padding: 11px;
}
.gridWrapper .ui-jqgrid tr.ui-search-toolbar th{
	height: 25px;
}
.gridWrapper .ui-jqgrid tr.ui-search-toolbar th input{
	height: 16px !important;
}
#trendsGridContainer .gridWrapper .ui-jqgrid tr.ui-search-toolbar th input{
	height: 23px !important;
}
.jqg-second-row-header th{
	white-space: nowrap;
	overflow: hidden;
}
.selectedHighlight{
	background: #4572A7;
	height: 3px;
	position: absolute;
	top: 0;
}
#kolsActivitiesChart{
	margin-top: 55px;
}

#customWeightageSection select option[value='2'], #customWeightageSection .priorityHigh{
	color: white;
	background: green;
}
#customWeightageSection select option[value='1'], #customWeightageSection .priorityMedium{
	color: black;
	background: yellow;
}
#customWeightageSection select option[value='0'], #customWeightageSection .priorityLow{
	color: white;
	background: red;
}
#customWeightageSection select option[value=''], #customWeightageSection .priority{
	color: black;
	background: white;
}



#customWeightageSection select[name='surveys_priority'] option{
	color: black;
	background: white;
}

th.ui-th-column div {
    white-space: normal !important;
    height: auto !important;
    padding: 2px;
    overflow:hidden !important;
}
.ui-jqgrid .ui-jqgrid-sortable {
    top: 1px !important;
}

.ui-jqgrid .ui-jqgrid-bdiv{

}
.ui-state-default{
	overflow:hidden !important;
}
.HeaderButton{
	display: none;
}
.ui-jqgrid-bdiv{
    max-height: 420px;
    
}
#leftSideBar{
	padding-top: 0px
}
#leftSidebarForm .NewBlueButton{
	width: 140px;
	margin-bottom: 5px !important;
	text-align: left;
}
#kolsByRankingResultSet_cb{
	width: 25px !important;
}
#RSSFEED1 .blueButton{
	height: 17px !important;
    margin-left: 9px;
    margin-top: -1px;
    padding-bottom: 3px;
    padding-left: 4px;
    padding-top: 2px;
}
.addContactCss{
    position: relative;
    top: 0px !important;
}
.ui-jqgrid .ui-pg-input {
    width: 37px !important;
}
#rankingGridContainer .add-contact +.ui-jqgrid-htable{
        margin-top: -20px;
}
 label.facet-toggle {
	    background: url("<?php echo base_url()?>images/kolm-sprite-image.png") no-repeat scroll -8px -91px transparent;
	}
	 label.collapsed {
	    background-position: -28px -91px;
	}
	
	 label.facet-toggle {
	    cursor: pointer;
	    display: block;
	    font-size: 85%;
	    height: 11px;
	    position: relative;
	    right: 0;
	    text-indent: -99999px;
	    top: 14px;
	    width: 11px;
	    //margin-left: 19px;
	}
	 label.facet-toggled {
	    cursor: pointer;
	    display: block;
	    font-size: 85%;
	    height: 11px;
	    position: relative;
	    right: 0;
	    text-indent: -99999px;
	    top: 14px;
	    width: 11px;
	    //margin-left: 19px;
	}
        .guidlinesColumn{
            margin-top: 19px;
        }
	.gridWrapper .ui-jqgrid tr.jqgrow td div.microViewIcon {
    	background: rgba(0, 0, 0, 0) url("<?php echo base_url();?>images/microview_inactive.png") no-repeat scroll 0 0 / 20px auto;
	}
	div.microViewIcon{
		width: 20px !important;
		height: 20px !important;
	}
	.frozen-bdiv {
		/*height: 420px !important;*/
		top: 120px !important;
	}
	.autocomplete label.meshTerm{
		height: auto;
    	min-height: 25px;
	}
        .trendsMessage{
            margin-left: 285px;
            margin-top: -16px;
        }
        #trendsGridContainer .ui-search-table{
            margin-bottom: 2.4em !important;
        }
        
        /* Different colors for each columns */
        .color-11{
        	background: #A9BFD9 !important;
        }
        .color-12{
        	background: #BFCFE3 !important;
        }
        .color-13{
        	background: #D4DFEC !important;
        }
        .color-21{
        	background: #F3B9B4 !important;
        }
        .color-22{
        	background: #F6CBC7 !important;
        }
        .color-23{
			background: #F9DCD9 !important;
        }
        .color-24{
			background: #f8e9e6 !important;
        }
        .color-25{
			background: #F9EAE7 !important;
        }
        .color-26{
			background: #FBF2F2 !important;
        }
        .color-31{
        	background: #FBCC90 !important;
        }
        .color-32{
        	background: #FBCC90 !important;
        }
        .color-33{
        	background: #FBCC90 !important;
        }
        .color-41{
        	background: #BEE5D3 !important;
        }
        .color-42{
        	background: #CEECDE !important;
		}
        .color-43{
        	background: #DEF2E9 !important;
        }
        .color-51{
        	background: #ECDFEC !important;
        }
        .color-52{
        	background: #F1E7F1 !important;
		}
        .color-53{
        	background: #fff !important;
        }
        
        .events_container{
        	background-color: #a9bfd9;
        }
        .publications_container{
        	background-color: #bee5d3;
        }
        .affiliations_container{
        	background-color: #f3b9b4;
        }
        .trials_container{
        	background-color: #fbcc90;
        }
        #customWeightageSection label{
        	color: #000000 !important;
        }
        #customWeightageSection .min, #customWeightageSection .min{
        	color: #000000 !important;
        }
        .progress {
		    width: 100%;
		}
		#rightSideBar {
            padding-left:0px;
        }
        #searchLeftBar li.category::after {
    border-top: 1px solid #bbbbbb;
    content: "";
    display: block;
    height: 1px;
    margin: 10px 0px 0 -11px;
}
#searchLeftBar label.facet-toggle{
    right: 5px;
}
#searchFiltersElements ul li{
    padding-left:5px;
    padding-right:5px;
}
.sprite_iconSet{
    margin-left:0px;
    height: 20px;
}
.frozen-bdiv.ui-jqgrid-bdiv {
    background: #fff;
}
.title-bar-actions.add-contact{
		  z-index: 1;
		}
.ui-jqgrid .ui-jqgrid-resize{
    #height: 50px !important;
}
.refineByRegionImage {
    background-image: url('../images/ipad/region_active.svg');    
}
.ui-jqgrid tr.jqgrow td{
    height:23px !important;
}
.ui-jqgrid-labels th{
    height:23px !important;
}
.gridWrapper .ui-jqgrid .ui-jqgrid-hdiv{
    border-bottom: 1px solid #ffffff !important;
}
.ui-search-table{
    margin-bottom: 1.9em;
}
</style>

<script type="text/javascript">
var chartColors=<?php echo CHART_COLOR_CODES ?>;
var prevRSSFeedName="RSSFEED1";
var columnsToHide = [];
var selectedWeightage = [];
var runColSetting = true;
var customOk = "Adjust";
var customCancel = "Disable";
var d = new Date();
var defaultStartYear =  (d.getFullYear())-5;
var defaultEndYear = d.getFullYear();
<?php if((!empty($yearRange[0]) || $yearRange[0]!='') && (!empty($yearRange[1]) || $yearRange[1]!='')){ ?>
    var defaultStartYear =  <?php echo $yearRange[0]?>;
	var defaultEndYear = <?php echo $yearRange[1]?>;
<?php } ?>
var projectId = '';
<?php if(isset($projectId)) {?>
	projectId = '<?php echo $projectId; ?>';	
<?php }?>
var isProjectChanged = 0;
var resetAllFiltersSet=false;
var baseUrl='<?php echo base_url();?>';
var unCheckAll=0;
var homeSection = "<?php echo $this->uri->segment(3);?>";
var loadTopSpeaker=0;
var loadTopResearcher=0;
var chartType='';
var trendsData='';
var isResetAllFilter = false;
var checkFirstTime = true;
columnsToHide.push('colsett');
columnsToHide.push('pub');
columnsToHide.push('aff');
columnsToHide.push('numtc');

var columnsToHideNew = [];
columnsToHideNew.push('colsett');
columnsToHideNew.push('pub');
columnsToHideNew.push('aff');
columnsToHideNew.push('numtc');
columnsToHideNew.push('numevc');
columnsToHideNew.push('numed');
columnsToHideNew.push('nump');
columnsToHideNew.push('numtc');
var keywordsAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>identifications/search_term',
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
			//var selText = $(event).children('.specialties').html();
			//var selId = $(event).children('.specialties').attr('name');
			var selText = $(event).children('.meshTerm').val();
			var selId = $(event).children('.meshTerm').attr('name');
			var meshTree = $(event).children('.meshTree').attr('value');
			selText=selText.replace(/\&amp;/g,'&');
			selTextElems = selText.split("(");
			selText = selTextElems[0].trim();
			$('#keywords').val('');
			var isSelectedKeyword = false;
			$("#keywordSearch1 ul li").each(function (){
				if($(this).find(".keywordText").html() == selText){
					jAlert("The searched keyword is already selected");
					isSelectedKeyword = true;
				}
			});
			if(!isSelectedKeyword){
				if(event.length>20){
					if(event.substring(0,21)=="No results found for "){
						return false;
					}else{
						var selectedKeyword = '<li><span autotext="'+selText+'" class="keywordText">'+selText+'</span> <span onclick="removeSelectedKeyword(this);return false;" class="removeKeyword">x</span></li>';
						$("#keywordSearch ul").append(selectedKeyword);
						$("#keywordSearch1 ul").append(selectedKeyword);
						$("#multiKeywords").append($('<option></option>').attr('value', selText).text(selText));
						$('#multiKeywords option[value="'+selText+'"]').attr('selected', true);
						reloadSection();
					}
				}else{
					var selectedKeyword = '<li><span autotext="'+selText+'" class="keywordText">'+selText+'</span> <span onclick="removeSelectedKeyword(this);return false;" class="removeKeyword">x</span></li>';
					$("#keywordSearch ul").append(selectedKeyword);
					$("#keywordSearch1 ul").append(selectedKeyword);
					$("#multiKeywords").append($('<option></option>').attr('value', selText).text(selText));
					$('#multiKeywords option[value="'+selText+'"]').attr('selected', true);
					reloadSection();
				}
			}
		}
	};

var keywordsAutoCompleteOptions1 = {
		serviceUrl: '<?php echo base_url();?>identifications/search_term',
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
//			alert(selectedWeightage.toSource());
			//var selText = $(event).children('.specialties').html();
			//var selId = $(event).children('.specialties').attr('name');
			var selText = $(event).children('.meshTerm').val();
			var selId = $(event).children('.meshTerm').attr('name');
			var meshTree = $(event).children('.meshTree').attr('value');
			selText=selText.replace(/\&amp;/g,'&');
			selTextElems = selText.split("(");
			selText = selTextElems[0].trim();
			$('#keywords1').val('');
			var isSelectedKeyword = false;
			$("#keywordSearch ul li").each(function (){
				if($(this).find(".keywordText").html() == selText){
					jAlert("The searched keyword is already selected");
					isSelectedKeyword = true;
				}
			});
			if(!isSelectedKeyword){
				isProjectChanged = 1;
				if(event.length>20){
					if(event.substring(0,21)=="No results found for "){
						return false;
					}else{
						var selectedKeyword = '<li><span autotext="'+selText+'" class="keywordText" meshterm='+meshTree+'>'+selText+'</span> <span onclick="removeSelectedKeyword(this);return false;" class="removeKeyword">x</span></li>';
						$("#keywordSearch ul").append(selectedKeyword);
						$("#keywordSearch1 ul").append(selectedKeyword);
						$("#multiKeywords").append($('<option></option>').attr('value', selText).text(selText));
						$('#multiKeywords option[value="'+selText+'"]').attr('selected', true);
						$("#multiKeywordsId").append($('<option></option>').attr('value', meshTree).text(meshTree));
						$('#multiKeywordsId option[value="'+meshTree+'"]').attr('selected', true);
						reloadSection();
					}
				}else{
					var selectedKeyword = '<li><span autotext="'+selText+'" class="keywordText" meshterm="'+meshTree+'">'+selText+'</span> <span onclick="removeSelectedKeyword(this);return false;" class="removeKeyword">x</span></li>';
					$("#keywordSearch ul").append(selectedKeyword);
					$("#keywordSearch1 ul").append(selectedKeyword);
					$("#multiKeywords").append($('<option></option>').attr('value', selText).text(selText));
					$('#multiKeywords option[value="'+selText+'"]').attr('selected', true);
					$("#multiKeywordsId").append($('<option></option>').attr('value', meshTree).text(meshTree));
					$('#multiKeywordsId option[value="'+meshTree+'"]').attr('selected', true);
					reloadSection();
				}
			}
		}
	};
function resetSlidersOnProjectChange(){
	$( ".twoSlider" ).slider({
		range: true,
		min: 2000,
		max: defaultEndYear,
		values: [ defaultStartYear, defaultEndYear],
		step:1,
		slide: function( event, ui ) {
			$(ui.handle).parent().children('.timelineValueHolder').val(ui.values);
	        var handleIndex = $(ui.handle).data('index.uiSliderHandle');
	        var label = handleIndex == 0 ? '.min' : '.max';
			var delay = function() {
	            $(ui.handle).parent().children(label).html(ui.value).position({
	                my: 'center top',
	                at: 'center top',
	                of: ui.handle,
	                offset: "0, 10"
	            });
	        };
	        setTimeout(delay, 5);
	        // wait for the ui.handle to set its position
	        setTimeout(delay, 5);
	        if($(ui.handle).parent().attr('id') == "timeLineSlider"){
	        	var delay = function() {
		            $("#timeLineSlider1").children(label).html(ui.value).position({
		                my: 'center top',
		                at: 'center top',
		                of: ui.handle,
		                offset: "0, 10"
		            });
		        };
		        // wait for the ui.handle to set its position
		        setTimeout(delay, 5);
		    }else{
		    	var delay = function() {
		            $("#timeLineSlider").children(label).html(ui.value).position({
		                my: 'center top',
		                at: 'center top',
		                of: ui.handle,
		                offset: "0, 10"
		            });
		        };
		        // wait for the ui.handle to set its position
// 		        setTimeout(delay, 5);
			}
		        
	        
		}
	});
	
	$( ".oneSlider" ).slider({
		max: 100,
		step:5,
		slide: function( event, ui ) {
			
			$(ui.handle).parent().children('.timelineValueHolder').val(ui.value);
			var delay = function() {
				 $(ui.handle).parent().children('.max').html(ui.value).position({
		                my: 'center top',
		                at: 'center top',
		                of: ui.handle,
		                offset: "0, 10"
		            });
					if($(ui.handle).parent().children('.timelineValueHolder').attr('name') == 'surveys_all'){
						if(ui.value > 0){
							$("#customWeightage input[name='include_survey']").attr('checked','checked');
							$("#customWeightage input[name='include_survey2']").attr('checked','checked');
						}else{
							$("#customWeightage input[name='include_survey']").removeAttr('checked');
							$("#customWeightage input[name='include_survey2']").removeAttr('checked');
						}
					}
	        };
	        $(ui.handle).parent().children('.selectedHighlight').width(ui.value+'%');
	        
	        // wait for the ui.handle to set its position
	        setTimeout(delay, 5);
	
	        //Toggle the parent and child values
	        if($(ui.handle).parent().hasClass('parentNode')){
				$(ui.handle).parent().parent().parent().next().find('.oneSlider').each(function(){
					$("#"+$(this).attr('id')).slider( "disable");
					$("#"+$(this).attr('id')).slider( "value",0);
					$("#"+$(this).attr('id')).children('.timelineValueHolder').val(0);
					$("#"+$(this).attr('id')).children('.selectedHighlight').width('0%');
					$("#"+$(this).attr('id')).children('.max').html(0).position({
		                my: 'center top',
		                at: 'center top',
		                of: ui.handle,
		                offset: "0, 10"
		            });
				});
		    }else{
		    	$(ui.handle).parent().parent().parent().parent().prev().find('.oneSlider').each(function(){
					$("#"+$(this).attr('id')).slider( "disable");
					$("#"+$(this).attr('id')).slider( "value",0);
					$("#"+$(this).attr('id')).children('.timelineValueHolder').val(0);
					$("#"+$(this).attr('id')).children('.selectedHighlight').width('0%');
					$("#"+$(this).attr('id')).children('.max').html(0).position({
		                my: 'center top',
		                at: 'center top',
		                of: ui.handle,
		                offset: "0, 10"
		            });
				});
		  	}
	
		  	//Calculate total weighte
	        calculateTotalWeightage();
		}
	});
	 $( ".twoSlider" ).each(function(){
			$(this).children('.timelineValueHolder').val(defaultStartYear+","+defaultEndYear);
		});	
// 	 alert(defaultStartYear+'--'+defaultEndYear);
}
$(document).ready(function(){
	$("input[name='wyn']").val("yes");
	$("#showWeighatages").css("display","block");
	var customWeightage={
			title: "Column Settings",
			modal: true,
			autoOpen: false,
			width: 1000,
			height: 630,
			dialogClass: "microView",
			draggable:false,
			open: function(){
				//Assging selected weightage
				setTimeout(applySelectedWeightage, 5);
			},
			close:function(){
				//applySelectedWeightage();
			}
		};
	$( "#customWeightage" ).dialog(customWeightage);
	
	var addKolsCustomFilters={
			title: "Add Custom Filters",
			modal: true,
			autoOpen: false,
			width: 600,
			height: 400,
			dialogClass: "microView",
			draggable:false,
			open: function(){
	
			}
		};
	$( "#addKolsCustomFilters" ).dialog(addKolsCustomFilters);
	
	$('#rssfeed_tabs li a').click(function(){
		$('#rssfeed_tabs li a.current').removeClass('current');
		$(this).addClass('current');
	});
	
	$('#rssfeed_tabs li a').eq(0).trigger('click');	
	
	$('#tabs1 a').click(function(){
		$('#tabs1 a.current').removeClass('current');
		$(this).addClass('current');
	});
	
	//Set or retrive colums to hide
// 	$("#colSettingsHolder input[name='col_settings[]']").each(function(){
// 		$(this).attr('checked','checked');
// 		var thisVal = $(this).val();
// 		columnsToHide.push(thisVal);
// 	});
/*	
	$( ".twoSlider" ).slider({
		range: true,
		min: 2000,
		max: defaultEndYear,
		values: [ defaultStartYear, defaultEndYear],
		step:1,
		slide: function( event, ui ) {
			$(ui.handle).parent().children('.timelineValueHolder').val(ui.values);
	        var handleIndex = $(ui.handle).data('index.uiSliderHandle');
	        var label = handleIndex == 0 ? '.min' : '.max';
			var delay = function() {
	            $(ui.handle).parent().children(label).html(ui.value).position({
	                my: 'center top',
	                at: 'center top',
	                of: ui.handle,
	                offset: "0, 10"
	            });
	        };
	        setTimeout(delay, 5);
	        // wait for the ui.handle to set its position
	        setTimeout(delay, 5);
	        if($(ui.handle).parent().attr('id') == "timeLineSlider"){
	        	var delay = function() {
		            $("#timeLineSlider1").children(label).html(ui.value).position({
		                my: 'center top',
		                at: 'center top',
		                of: ui.handle,
		                offset: "0, 10"
		            });
		        };
		        // wait for the ui.handle to set its position
		        setTimeout(delay, 5);
		    }else{
		    	var delay = function() {
		            $("#timeLineSlider").children(label).html(ui.value).position({
		                my: 'center top',
		                at: 'center top',
		                of: ui.handle,
		                offset: "0, 10"
		            });
		        };
		        // wait for the ui.handle to set its position
// 		        setTimeout(delay, 5);
			}
		        
	        
		}
	});
	
	$( ".oneSlider" ).slider({
		max: 100,
		step:5,
		slide: function( event, ui ) {
			
			$(ui.handle).parent().children('.timelineValueHolder').val(ui.value);
			var delay = function() {
				 $(ui.handle).parent().children('.max').html(ui.value).position({
		                my: 'center top',
		                at: 'center top',
		                of: ui.handle,
		                offset: "0, 10"
		            });
					if($(ui.handle).parent().children('.timelineValueHolder').attr('name') == 'surveys_all'){
						if(ui.value > 0){
							$("#customWeightage input[name='include_survey']").attr('checked','checked');
							$("#customWeightage input[name='include_survey2']").attr('checked','checked');
						}else{
							$("#customWeightage input[name='include_survey']").removeAttr('checked');
							$("#customWeightage input[name='include_survey2']").removeAttr('checked');
						}
					}
	        };
	        $(ui.handle).parent().children('.selectedHighlight').width(ui.value+'%');
	        
	        // wait for the ui.handle to set its position
	        setTimeout(delay, 5);
	
	        //Toggle the parent and child values
	        if($(ui.handle).parent().hasClass('parentNode')){
				$(ui.handle).parent().parent().parent().next().find('.oneSlider').each(function(){
					$("#"+$(this).attr('id')).slider( "disable");
					$("#"+$(this).attr('id')).slider( "value",0);
					$("#"+$(this).attr('id')).children('.timelineValueHolder').val(0);
					$("#"+$(this).attr('id')).children('.selectedHighlight').width('0%');
					$("#"+$(this).attr('id')).children('.max').html(0).position({
		                my: 'center top',
		                at: 'center top',
		                of: ui.handle,
		                offset: "0, 10"
		            });
				});
		    }else{
		    	$(ui.handle).parent().parent().parent().parent().prev().find('.oneSlider').each(function(){
					$("#"+$(this).attr('id')).slider( "disable");
					$("#"+$(this).attr('id')).slider( "value",0);
					$("#"+$(this).attr('id')).children('.timelineValueHolder').val(0);
					$("#"+$(this).attr('id')).children('.selectedHighlight').width('0%');
					$("#"+$(this).attr('id')).children('.max').html(0).position({
		                my: 'center top',
		                at: 'center top',
		                of: ui.handle,
		                offset: "0, 10"
		            });
				});
		  	}
	
		  	//Calculate total weighte
	        calculateTotalWeightage();
		}
	});
	$( ".twoSlider" ).each(function(){
		$(this).children('.timelineValueHolder').val(defaultStartYear+","+defaultEndYear);
	});	
	*/
	resetSlidersOnProjectChange();
	// Binding the function for slidechange event 
// 	$( "#timeLineSlider" ).bind( "slidechange", filterChart);	
	$("#customWeightageSection .timeLineSlider").on('mouseover',function(){
		$("#"+$(this).attr('id')).slider( "enable" );
	});
	$("#customWeightageSection .timeLineSlider").on('mouseout',function(){
		if($(this).children('.timelineValueHolder').val() == 0)
			$("#"+$(this).attr('id')).slider( "disable" );
	});
	
	$("#toggleWeightage").on("change",function(){
		if($(this).attr('checked') == 'checked'){
			$("#customWeightage input[name='wyn']").val('yes');
			$("#showWeighatages").show();
			if($("#totalWeight").val() == 0){
				arrTempAllWt['pubs_all'] = publicationsDefaultWt;
				arrTempAllWt['affiliations_all'] = affiliationDefaultWt;
				arrTempAllWt['events_all'] = eventDefaultWt;
				arrTempAllWt['trials_all'] = trialsDefaultWt;
				enableWeightages();
			}
		}else{
			$("#customWeightage input[name='wyn']").val('no');
			$("#showWeighatages").hide();
		}
		isProjectChanged = 1;
		reloadSection();
	});
	
	// Trigger the Autocompleter for 'education' field of  Event'
	a = $('#keywords').autocomplete(keywordsAutoCompleteOptions);
	a = $('#keywords1').autocomplete(keywordsAutoCompleteOptions1);
	
	//Priority change option
	$("#customWeightageSection select").on('change',function(){
		var selText = $(this).find("option:selected").text();
		var selVal = $(this).val();
		$(this).removeClass("priorityHigh priorityMedium priorityLow priority");
		$(this).addClass('priority'+selText);
	});
	
	$("input[name='include_survey2']").on('change',function(){
		if($(this).attr('checked') == 'checked'){
			//$("input[name='include_survey']").attr('checked','checked');
		}else{
			//$("input[name='include_survey']").removeAttr('checked');
			$("#customWeightage input[name='surveys_all']").val(0);
			$("#customWeightage input[name='surveys_all']").parent().slider( "value",0);
			$("#customWeightage input[name='surveys_all']").parent().children('.selectedHighlight').width(0+'%');
			$("#customWeightage input[name='surveys_all']").parent().children('.max').html(0).position({
	            my: 'center top',
	            at: 'center top',
	            of: $("#customWeightage input[name='surveys_all']").next(),
	            offset: "0, 10"
	        });
			calculateTotalWeightage();
		}
	});
	
	$("#toggleWeightage").attr('checked','checked');
	arrWeightages = $("#weightageForm").serializeArray();
	arrWeightagesHideShowValues = arrTempAllWt;
	arrApplyWeightages = {};
});

/* Initialize default Weightages */
var arrTempAllWt = {};
var eventDefaultWt = 30;
var affiliationDefaultWt = 25;
var publicationsDefaultWt = 25;
var trialsDefaultWt = 20;
arrTempAllWt['pubs_all'] = publicationsDefaultWt;
arrTempAllWt['affiliations_all'] = affiliationDefaultWt;
arrTempAllWt['events_all'] = eventDefaultWt;
arrTempAllWt['trials_all'] = trialsDefaultWt;

var arrWeightages;
var arrApplyWeightages;
var arrWeightagesHideShow = false;
var arrWeightagesHideShowValues;
var columnsToHide = [];
var globalPostDataObject;
var arrClientKolIds = get_client_kol_ids();

$(window).load(function () {
	reloadSection();
});
function reloadSection(){	
	if(isSaveFilterActive){
		globalPostDataObject = postDataObject;
		arrApplyWeightages = postDataObject;
// 		isSaveFilterActive = false;
	}else{
		globalPostDataObject = getAllFilters();
	}	
	if(isRefReportActive && prevRSSFeedName != 'RSSFEED4'){
		$("#customWeightage input[name='wyn']").val('yes');
		$("#toggleWeightage").prop('checked', true);
		$("#showWeighatages").show();
		isRefReportActive = false;
	}
// 	console.log(globalPostDataObject);
// 	console.log(arrApplyWeightages);
	$('#rssfeed_content1 .rssFeedReportsContainer').css('display','none');
	switch(prevRSSFeedName){
		case "RSSFEED1":
			$('#tabs1 a.current').removeClass('current');
			$('#tabs1 #rankR').addClass('current');
			$('#rssfeed_content1 #'+prevRSSFeedName).css('display','block');
			loadRankingReport();
			break;
		case "RSSFEED2":
			$('#rssfeed_content1 #'+prevRSSFeedName).css('display','block');
			loadRankingChart();
			break;
		case "RSSFEED3":
			$('#rssfeed_content1 #'+prevRSSFeedName).css('display','block');
			loadTrendsReport();
			break;	
	}
	
}

function loadTopSpeakers(){
// 	isRankingReportLoadedFirst =true;
	isProjectChanged = 1;
	if(prevRSSFeedName == 'RSSFEED4'){
		prevRSSFeedName = 'RSSFEED1';
	}
	arrTempAllWt = {};
	arrTempAllWt['events_speaker'] = 100;
	enableWeightages();
	reloadSection();
	showOnlyAppliedWeightagecolumns();
	$('#jqgh_kolsByRankingResultSet_numevc .facet-toggle').removeClass('collapsed');
}

function loadTopResearchers(){
// 	isRankingReportLoadedFirst =true;
	isProjectChanged = 1;
	if(prevRSSFeedName == 'RSSFEED4'){
		prevRSSFeedName = 'RSSFEED1';
	}
	arrTempAllWt = {};
	arrTempAllWt['pubs_all'] = 100;
	enableWeightages();
	reloadSection();
	showOnlyAppliedWeightagecolumns();
	$('#jqgh_kolsByRankingResultSet_nump .facet-toggle').removeClass('collapsed');
}


function enableWeightages(){
	$("#toggleWeightage").prop('checked', true);
	$("#customWeightage input[name='wyn']").val("yes");
	$("#showWeighatages").show();
}
var filterProjectIdFirstTime = true;
function getAllFilters(){
	var postDataObject = getSelectedWeightages();
	var leftFilters = $("#rightSidebarForm").serialize();
	postDataObject['custom_post']=leftFilters;
	if(filterProjectIdFirstTime){
		postDataObject['project']=projectId;
		postDataObject['project_id']=projectId;
    	filterProjectIdFirstTime = false;
    }

	return postDataObject;
}
function getSelectedWeightages(){
	arrApplyWeightages = {};
	$.each(arrWeightages,function (index,value){
		if(typeof(arrTempAllWt[value.name]) != "undefined" && arrTempAllWt[value.name] !== null) {
			arrApplyWeightages[value.name] = arrTempAllWt[value.name];
		}else{
			arrApplyWeightages[value.name] = value.value;
		}
	});
	var arrMultiKeywordValues = []; 
	var arrMultiKeywordIdValues = []; 
	$('#multiKeywords :selected').each(function(i, selected){ 
	  arrMultiKeywordValues[i] = $(selected).text(); 
	});
	$('#multiKeywordsId :selected').each(function(i, selected){ 
	  arrMultiKeywordIdValues[i] = $(selected).text(); 
	});
	arrApplyWeightages['multi_keywords'] = arrMultiKeywordValues;
	arrApplyWeightages['multi_keywords_id'] = arrMultiKeywordIdValues;
	arrApplyWeightages['keywords'] = arrMultiKeywordValues;
	arrApplyWeightages['wyn'] = $("#customWeightage input[name='wyn']").val();
	var defaultYearRange = defaultStartYear+','+defaultEndYear;
// 	console.log(arrApplyWeightages['pubs_year_range']+'----'+defaultYearRange);	
	if(isProjectChanged){
    	/*if(arrApplyWeightages['year_range']==defaultYearRange){	
    	 arrApplyWeightages['year_range'] = defaultYearRange;
    	}
    	if(arrApplyWeightages['events_year_range']==defaultYearRange){	
    		 arrApplyWeightages['events_year_range'] = defaultYearRange;
    	}
    	if(arrApplyWeightages['pubs_year_range']==defaultYearRange){	
    		 arrApplyWeightages['pubs_year_range'] = defaultYearRange;
    	}
    	if(arrApplyWeightages['aff_year_range']==defaultYearRange){	
    		 arrApplyWeightages['aff_year_range'] = defaultYearRange;
    	}
    	if(arrApplyWeightages['trials_year_range']==defaultYearRange){	
    		 arrApplyWeightages['trials_year_range'] = defaultYearRange;
    	}*/
    	arrApplyWeightages['year_range'] = defaultYearRange;
		arrApplyWeightages['events_year_range'] = defaultStartYear+','+defaultEndYear;
       	 arrApplyWeightages['pubs_year_range'] = defaultStartYear+','+defaultEndYear;
       	 arrApplyWeightages['aff_year_range'] = defaultStartYear+','+defaultEndYear;
       	 arrApplyWeightages['trials_year_range'] = defaultStartYear+','+defaultEndYear;
       	isProjectChanged =0;
	} 
/*
	if($("#customWeightage input[name='wyn']").val() == 'yes'){
		if(arrWeightagesHideShow == true){
			arrApplyWeightages = arrWeightagesHideShowValues;
			arrWeightagesHideShow == false;
		}
		
	}else{
		arrWeightagesHideShowValues = arrApplyWeightages;
		arrWeightagesHideShow == true;
		arrApplyWeightages = {};
	}
	*/
	return arrApplyWeightages;	
}

function applySelectedWeightage(){
	$.each(arrApplyWeightages,function (index,value){
		var oName = index;
		var oValue = value;
		switch(oName) {
		    case 'keywords': 
			    break;
		    case 'multi_keywords' :
// 		    	console.log(oValue);
			    $("#keywordSearch ul").html("");
				$("#keywordSearch1 ul").html("");
				$("#multiKeywords").html("");
				$("#keywords").val("");
			    if(oValue != '' && oValue.length != 0){
				    for(k in oValue){
				    	var selectedKeyword = '<li><span autotext="'+oValue[k]+'" class="keywordText mesterm'+k+'">'+oValue[k]+'</span> <span onclick="removeSelectedKeyword(this);return false;" class="removeKeyword">x</span></li>';
						$("#keywordSearch ul").append(selectedKeyword);
						$("#keywordSearch1 ul").append(selectedKeyword);
						$("#multiKeywords").append($('<option></option>').attr('value', oValue[k]).text(oValue[k]));
						$('#multiKeywords option[value="'+oValue[k]+'"]').attr('selected', true);
					}
	   		 	}
	    	break;
		    case 'multi_keywords_id' :
// 		    	console.log(oValue);			    				
				$("#multiKeywordsId").html("");				
			    if(oValue != '' && oValue.length != 0){
				    for(k in oValue){	
					    $('.mesterm'+k).attr("mestermId",oValue[k]);				   		
						$("#multiKeywordsId").append($('<option></option>').attr('value', oValue[k]).text(oValue[k]));
						$('#multiKeywordsId option[value="'+oValue[k]+'"]').attr('selected', true);
					}
	   		 	}
	    	break;
		    case 'pubs_all' :
		    case 'affiliations_all' :
		    case 'events_all' :
		    case 'trials_all' :
		    case 'editorial_all' :
		    case 'assoc_all' :
		    case 'industry_all' :
		    case 'expert_all' :
		    case 'pubs_lead' :
		    case 'pubs_ma' :
		    case 'pubs_sa' :
		    case 'pubs_fa' :
		    case 'pubs_la' :
		    case 'events_speaker' :
		    case 'events_orgcom' :
		    case 'trials_pi' :
		    case 'trials_ci':
		    case 'surveys_all' :if(oName == 'surveys_all' && oValue > 0 && oValue != ''){
			    					$("#customWeightage input[name='include_survey']").attr('checked','checked');
									$("#customWeightage input[name='include_survey2']").attr('checked','checked');
								 }
		    case 'guideline_all':if(oValue >= 0 && oValue != ''){
			    				$("#customWeightage input[name='"+oName+"']").val(oValue);
			    				$("#customWeightage input[name='"+oName+"']").parent().slider( "value",oValue);
			    				$("#customWeightage input[name='"+oName+"']").parent().children('.selectedHighlight').width(oValue+'%');
			    				$("#customWeightage input[name='"+oName+"']").parent().children('.max').html(oValue).position({
					                my: 'center top',
					                at: 'center top',
					                of: $("#customWeightage input[name='"+oName+"']").next(),
					                offset: "0, 10"
					            });
		    				}
		        break;
		    case 'year_range':
		    case 'pubs_year_range':
		    case 'events_year_range':
		    case 'trials_year_range':
		    case 'editorial_year_range':
		    case 'assoc_year_range':
		    case 'industry_year_range':
		    case 'guideline_year_range':
		    case 'aff_year_range': if(isNaN(oValue) && oValue != '' && oValue.length > 4){
		    							arrValues = oValue.split(',');
			    						$("#customWeightage input[name='"+oName+"']").val(oValue);
									  	$("#customWeightage input[name='"+oName+"']").parent().slider( "values",[arrValues[0],arrValues[1]]);
									  	$("#customWeightage input[name='"+oName+"']").parent().children('.min').html(arrValues[0]).position({
							                my: 'center top',
							                at: 'center top',
							                of: $("#customWeightage input[name='"+oName+"']").next().next(),
							                offset: "0, 10"
							            });
									  	$("#customWeightage input[name='"+oName+"']").parent().children('.max').html(arrValues[1]).position({
							                my: 'center top',
							                at: 'center top',
							                of: $("#customWeightage input[name='"+oName+"']").next().next().next(),
							                offset: "0, 10"
							            });
		    						}	
			    break;
		    case 'pub_priority' :
		    case 'trials_priority' :
		    case 'aff_priority' :
		    case 'events_priority' :
		    case 'surveys_priority' :
		    case 'guideline_priority' :$("select[name='"+oName+"'] option[value='"+oValue+"']").attr("selected",true);
			    break;
		    default: break;
		}
	});
	showWeightagesOnSidebar();
}

function showWeightagesOnSidebar(){
// 	console.log(arrApplyWeightages);
	$.each(arrApplyWeightages,function (index,value){
		var oName = index;
		var oValue = value;
		switch(oName) {
		    case 'keywords': 
			    //$("#customWeightage input[name='keywords']").val(oValue);
		        break;
		    case 'pubs_all' :
		    case 'events_all' :
		    case 'affiliations_all' :
		    case 'trials_all' :
		    case 'editorial_all' :
		    case 'assoc_all' :
		    case 'industry_all' :
		    case 'expert_all' :
		    case 'pubs_lead' :
		    case 'pubs_ma' :
		    case 'pubs_sa' :
		    case 'pubs_fa' :
		    case 'pubs_la' :
		    case 'events_speaker' :
		    case 'events_orgcom' :
		    case 'trials_pi' :
		    case 'trials_ci':
		    case 'surveys_all':
		    case 'guideline_all':if(oValue > 0 && oValue != ''){
			    				$("#showWeighatages span."+oName).html(oValue+"%");
		    				}else{
		    					$("#showWeighatages span."+oName).html("-");
			    			}
		        break;
		    default: break;
		}
	});
	calculateTotalWeightage();
	if($("#toggleWeightage").attr('checked') == 'checked'){
// 		showOnlyAppliedWeightagecolumns();
	}
}

function calculateTotalWeightage(){
	var totalWeight = 0;
	$(".oneSlider").each(function(){
		totalWeight += parseInt($(this).children('.timelineValueHolder').val());
	});

	$(".totalWeight").val(totalWeight);
	$("#showWeighatages .totalWeight").html(totalWeight+"%");
    $("#totalWeight").html(totalWeight + "%");
	if(totalWeight != 100){	
		$(".totalWeight").addClass("exceeded");
		$("#weightageNotice").show();
	}else{
		$(".totalWeight").removeClass("exceeded");
		$("#weightageNotice").hide();
	}
}

function showCustomWeightage(){
	$('#customWeightage').dialog("open");
	return false;
}

function saveSelectedWeightages(){ 
// 	isRankingReportLoadedFirst =true;
	arrTempAllWt = {};
	var weightagesFormArr = $("#weightageForm").serializeArray();
	$.each(weightagesFormArr,function (index,value){
		if(value.value != "") {
			arrTempAllWt[value.name] = value.value;
		}
	});
	
	if($("#totalWeight").val() != 100){
		return false;
	}
	if($("#customWeightage input[name='include_survey2']").attr('checked') == 'checked')
		$("#customWeightage input[name='include_survey']").attr('checked','checked');
	else
		$("#customWeightage input[name='include_survey']").removeAttr('checked');
	$("#toggleWeightage").attr('checked','checked');
	$("#customWeightage input[name='wyn']").val('yes');
	$("#showWeighatages").show();
	//showWeightagesOnSidebar();
	$("#customWeightage").dialog("close");
	
	reloadSection();
	showOnlyAppliedWeightagecolumns();
}

var filterProjectIdFirstTime = true;
function loadFilters(){
	arrApplyWeightages['chartType']=chartType;
	var filterData = globalPostDataObject;
	$.ajax({
		dataType:"text",
		url:base_url+"identifications/load_filters",
		type:"POST",
		data:filterData,
		success:function(returnData){
                                chartType='';

			$("#rightSideBarContainer").html(returnData);
			$('#searchLeftBar').unblock();
			displaySelectedFilters();
			applySelectedWeightage();
// 			$("#customFilterMsg").html($('#savedFilterValue option:selected').text());
			if(isSaveFilterActive){
				$("#savedFilterValue option:selected").prop("selected", false);
				$("#savedFilterValue option[value='"+savedFilterId+"']").prop("selected", true);
				$("#savedFilterValue option[value='"+savedFilterId+"']").attr("selected", "selected");
				$("#savedFilterValue").attr("title",$("#savedFilterValue").find("option:selected").text());
// 				$("#savedFilterValue option:first").text($("#savedFilterValue option[value='"+savedFilterId+"']").text());
				var weightagesFormArr = $("#weightageForm").serializeArray();
					$.each(weightagesFormArr,function (index,value){
						if(value.value != "") {
							arrTempAllWt[value.name] = value.value;
						}
					});
				isSaveFilterActive = false;
			}
		}
	});
}

function loadRankingReport(){
    chartType='rank';
	resetAllFiltersSet=false;
	loadRankingData();

	var dataUrl = base_url+"identifications/get_ranking_report";
	if(homeSection == 'mysql')
		dataUrl = base_url+"identifications/get_ranking_report/mysql";

	$('#rssfeed_content1').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
	$('#searchLeftBar').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
	loadFilters();
	return;
}

function loadRankingData(){
	var client_id = <?php echo $this->session->userdata('client_id'); ?>;
	var dataUrl = base_url+"identifications/get_ranking_report";
	if(homeSection == 'mysql')
		dataUrl = base_url+"identifications/get_ranking_report/mysql";
	
	jqgridIds[0]="kolsByRankingResultSet";
	var gridWidth = 870;
	if($("#rightSideBarWrapper").attr('style') == 'display: none;')
		gridWidth = 1150;

	var filterData = globalPostDataObject;
	var dataSet=arrClientKolIds;
	$("#RSSFEED1").html("");
	// Append the required div and table
	$("#RSSFEED1").html('<div id="rankingGridContainer" class="gridWrapper"><table id="kolsByRankingResultSet"></table><div id="kolsByRankingPager"></div></div>');
	jQuery("#kolsByRankingResultSet").jqGrid({
	   	url:dataUrl,
	   	postData:filterData,
		datatype: "json",
		colNames:['Id','','Name','Rank','Score',
                    '<label class="customHeader">Events </label><label class="facet-toggle collapsed" id="event" onclick="showColumns(this,event)"></label><label class="eventColumn1">Total</label>',
                    '<label class="eventColumn">Speaking </label>','<label class="eventColumn">Organizing Committee</label>','<label class="customHeader">Affiliations </label><label class="facet-toggle collapsed" id="affiliation" onclick="showColumns(this,event)"></label><label class="affiliationColumn1">Total</label>',
                    '<label class="affiliationColumn">Industry </label>',
                   '<label class="affiliationColumn">Associations</label>','<label class="affiliationColumn">Editorial Boards</label>',
                    '<label class="affiliationColumn">Univ/Hospital </label>','<label class="affiliationColumn">Guidelines</label>',
                    '<label class="customHeader">Publications </label><label class="facet-toggle collapsed" id="publication" onclick="showColumns(this,event)"></label><label class="publicationColumn1">Total</label>',
                    '<label class="publicationColumn">Lead Author </label>','<label class="publicationColumn">Contributing Author</label>',
                    '<label class="publicationColumn">Single Author </label>','<label class="publicationColumn">First Author</label>','<label class="publicationColumn">Last Author</label>',
                    '<label class="customHeader">Trials </label><label class="facet-toggled" id="trial"></label><label class="trialColumn">Total</label>','Peer Nominations',
                    '','','unique id'],
	   	colModel:[
					{name:'id',index:'kol_id',hidden:true},
					{name:'micro',index:'micro',width:30, search:false,hidden:true},
					{name:'name',index:'name',width:200,search:true,formatter: function (cellvalue, options, rowObject) {
				        return "<a href='"+base_url+"kols/view/"+rowObject.unique_id+"' target='_NEW' class='link' title='" + $.jgrid.stripHtml(cellvalue) + "'>" +
				            $.jgrid.htmlEncode(cellvalue) + "</a>";
						
			    	}},
			    	{name:'rank',index:'rank',sorttype:'int',align:"center",search:false,width:60},
			    	{name:'score',index:'score',sorttype:'int',align:"center",search:false,width:80},
			    	{name:'numevc',index:'numevc',width:80,sorttype:'int',classes:'totalColumn color-11',title:false,search:false},
			    	{name:'numspc',index:'numspc',width:70,sorttype:'int',classes:'color-12',title:false,search:false,hidden:true},
			    	{name:'numocc',index:'numocc',width:70,sorttype:'int',classes:'color-13',search:false,hidden:true},
					{name:'numed',index:'numed',width:90,sorttype:'int',classes:'totalColumn color-21',title:false,search:false},
			    	{name:'numia',index:'numia',width:70,sorttype:'int',classes:'totalColumn color-22',search:false,hidden:true},
			    	{name:'numas',index:'numas',width:85,sorttype:'int',classes:'totalColumn color-23',search:false,hidden:true},
			    	{name:'numeb',index:'numeb',width:70,sorttype:'int',classes:'totalColumn color-24',search:false,hidden:true},
			    	{name:'numec',index:'numec',width:90,sorttype:'int',classes:'totalColumn  color-25',search:false,hidden:true},
					{name:'numgc',index:'numgc',width:70,sorttype:'int',classes:'totalColumn color-26',search:false,hidden:true},
			    	{name:'nump',index:'nump',width:107,sorttype:'int',classes:'totalColumn  color-41',search:false},
			    	{name:'leadc',index:'leadc',width:70,sorttype:'int',classes:'color-42',search:false,hidden:true},
			    	{name:'numma',index:'numma',width:90,sorttype:'int',classes:'color-43',search:false,hidden:true},
			    	{name:'numsa',index:'numsa',width:70,sorttype:'int',classes:'color-43',search:false,hidden:true},
			    	{name:'numfa',index:'numfa',width:70,sorttype:'int',classes:'color-43',search:false,hidden:true},
			    	{name:'numla',index:'numla',width:70,sorttype:'int',classes:'color-43',search:false,hidden:true},
			    	{name:'numtc',index:'numtc',width:80,sorttype:'int',classes:'totalColumn color-31',search:false},
			    	{name:'numic',index:'numic',width:70,sorttype:'int',classes:'totalColumn',hidden:true,search:false},
			    	{name:'profile_type',index:'profile_type',hidden:true},
			    	{name:'my_kols',index:'my_kols',hidden:true},
			    	{name:'unique_id',index:'unique_id',hidden:true}
	   	],
	   	multiselect: true,
	   	rowNum:100,
	   	shrinkToFit: false,
	   	rownumbers: true,
	   	rownumWidth:50,
	   	loadonce:true,
	   	ignoreCase:true,
	    headertitles:true,
	   	height:"auto",	
	    viewrecords: true,
	   	resizable:true,
	   	width:gridWidth,
	   	pager: '#kolsByRankingPager',
	   	mtype: "POST",
	    jsonReader: { repeatitems : false, id: "0" }, 
	    caption:'KTL Ranking',
            sortname:'score',
            sortorder:'desc',
	   	rowList:[100],
	    gridComplete: function(){ 
	    	initilizeGridSearchPlaceholder();
	    	$("#rankingGridContainer .ui-jqgrid-titlebar").html('');
	    	$("#rankingGridContainer .ui-jqgrid-titlebar").append('<span class="ui-jqgrid-title">KTL Ranking</span><div style="text-decoration: underline;position: absolute;top: 28px;left: 130px;" class="title-bar-actions add-contact"><a class="" style=" color:#2b9af3;"; href="#" onclick="addToMyContacts()" rel="tooltip" data-original-title="Add to Contacts">Add to Contacts</a></div>');
	    	$("#rankingGridContainer .ui-jqgrid-titlebar").append('<div class="userSettings sprite_iconSet tooltip-demo tooltop-right active" id="settingOptions"><a onclick="loadColumnSettings(event); return false;" href="" rel="tooltip" data-original-title="Column Settings">&nbsp;</a>	</div>');
	    	if(INTERNAL_CLIENT_ID==client_id){	    	
    	    	$("#rankingGridContainer").find(".excelExportIcon").remove();
    	    	$("#rankingGridContainer .ui-jqgrid-titlebar").append('<div onclick="export_ranking_data()" class="excelExportIcon sprite_iconSet tooltip-demo"> <a href="#" rel="tooltip" data-original-title="Export">&nbsp;</a></div>');
	    	}
//   $('.add-contact').remove();			
//     $("#rankingGridContainer .frozen-div").prepend('<div style=" color:#2b9af3;    margin-left: 135px;text-decoration: underline;" class="title-bar-actions add-contact"><a class="" style=" color:#2b9af3;"; href="#" onclick="addToMyContacts()" rel="tooltip" data-original-title="Add to Contacts">Add to Contacts</a></div>');

    // 			$(".frozen-bdiv").height($(".frozen-bdiv").find("table").height());
	    	/*var ids = jQuery("#kolsByRankingResultSet").jqGrid('getDataIDs'); 
    		for(var i=0;i < ids.length;i++){
		    	var rowData = jQuery("#kolsByRankingResultSet").jqGrid('getRowData', ids[i]);
				microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewKolMicroProfile('"+rowData.id+"',this); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Profile Snapshot\">&nbsp;</a></div></label>";
		    	jQuery("#kolsByRankingResultSet").jqGrid('setRowData',ids[i],{micro:microviewLink}); 
	    	} */

	    	//$("#jqgh_kolsByRankingResultSet_rank").click();
	    	//jQuery("#kolsByRankingResultSet").jqGrid('setFrozenColumns');
              
			$('#rssfeed_content1').unblock();
                         onpageLoad=false;
                         applyLocalColumnChanges();
                         if(checkFirstTime){
             				$.each(columnsToHideNew,function (key,val){
             					$("#colSettingsHolder input[value='"+val+"']").attr("checked","checked");
             				});
             				checkFirstTime = false;
             			}
    	},
    	onSortCol: function(){ 
	    	runColSetting = false;
    	},
    	beforeRequest: function(){
    		
        	if(runColSetting){
	    		//applyLocalColumnChanges();
	    		colorGroupedHeader();
        	}
        	runColSetting = true;
    	},
    	beforeProcessing: function (data, status, xhr) {
    		$("#rankingExportForm textarea").html(JSON.stringify(data));
        },
    	onSelectAll: function(aRowids,status) {
    		var ids = jQuery("#kolsByRankingResultSet").jqGrid('getDataIDs'); 
    		for(var i=0;i < ids.length;i++){ 
    		
			    	var cl = ids[i];				    	
			    	var rowData = jQuery("#kolsByRankingResultSet").jqGrid('getRowData', cl);
			    	if(rowData.status=='Approved' || rowData.status=='Profiling' || rowData.status=='Review'){
						
			    		  var cbs = $("tr.jqgrow > td > input.cbox:disabled",jQuery("#kolsByRankingResultSet")[0]);
			                cbs.removeAttr("checked");

			                //modify the selarrrow parameter
			                jQuery("#kolsByRankingResultSet")[0].p.selarrrow = jQuery("#kolsByRankingResultSet").find("tr.jqgrow:has(td > input.cbox:checked)")
			                    .map(function() { return this.id; }) // convert to set of ids
			                    .get(); // convert to instance of Array
					}
                                        
                                         
	    	}   

	          
        },

        rowattr: function (item) {
//            var arr=jQuery("#kolsByRankingResultSet").jqGrid('getDataIDs');
//            for(var i = 0; i <  arr.length; i++ ){
//                var id=arr[i];
//                var rowData = jQuery("#kolsByRankingResultSet").jqGrid('getRowData', id);
//                if(rowData.my_kols==1){
//                    $("#jqg_kolsByRankingResultSet_"+id).replaceWith('<label><div class="tooltip-demo tooltop-right microViewIcon Male" onclick=\"viewKolMicroProfile('+rowData.id+',this); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel="tooltip" title=\"Profile Snapshot\">&nbsp;</a></div></label>');
//                }
//            }
       },

        loadComplete: function (data){
            $("#jqgh_kolsByRankingResultSet_numtc").attr("title", "Clinical Trial Total");
          
         
                       
                                var arr =jQuery("#kolsByRankingResultSet").jqGrid('getDataIDs');
                                for(var i = 0; i <  arr.length; i++ ){
                                        var d = jQuery("#kolsByRankingResultSet").getRowData(arr[i]);
    		if(jQuery.inArray(parseInt(d.id), dataSet) !== -1){
    			if(d.micro == '1'){	
                	$("#jqg_kolsByRankingResultSet_"+arr[i]).replaceWith('<label><div class="tooltip-demo tooltop-right microViewIcon Male" onclick=\"viewKolMicroProfile('+d.id+',this); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel="tooltip" title=\"Profile Snapshot\">&nbsp;</a></div></label>');
    			}else{
    				$("#jqg_kolsByRankingResultSet_"+arr[i]).replaceWith('<label><div class="tooltip-demo tooltop-right requestProfile sprite_iconSet" onclick=\"addNewKolProfile('+d.id+',this); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel="tooltip" title=\"Request Profile\">&nbsp;</a></div></label>');
    			}
            }
            jQuery("#kolsByRankingResultSet").jqGrid('setCell', arr[i],"score", d.score , "",{title:"Score: "+d.score});
            jQuery("#kolsByRankingResultSet").jqGrid('setCell', arr[i],"numevc", d.numevc , "",{title:"Total: "+d.numevc});
            jQuery("#kolsByRankingResultSet").jqGrid('setCell', arr[i],"numspc", d.numspc , "",{title:"Speaking: "+d.numspc});
            jQuery("#kolsByRankingResultSet").jqGrid('setCell', arr[i],"numocc", d.numocc , "",{title:"Organizing Committee: "+d.numocc});
            jQuery("#kolsByRankingResultSet").jqGrid('setCell', arr[i],"numed", d.numed , "",{title:"Total: "+d.numed});
            jQuery("#kolsByRankingResultSet").jqGrid('setCell', arr[i],"numia", d.numia , "",{title:"Industry: "+d.numia});
            jQuery("#kolsByRankingResultSet").jqGrid('setCell', arr[i],"numas", d.numas , "",{title:"Associations: "+d.numas});
            jQuery("#kolsByRankingResultSet").jqGrid('setCell', arr[i],"numeb", d.numeb , "",{title:"Editorial Boards: "+d.numeb});
            jQuery("#kolsByRankingResultSet").jqGrid('setCell', arr[i],"numec", d.numec , "",{title:"Univ/Hospital: "+d.numec});
            
            jQuery("#kolsByRankingResultSet").jqGrid('setCell', arr[i],"numgc", d.numgc , "",{title:"Guidelines: "+d.numgc});
            jQuery("#kolsByRankingResultSet").jqGrid('setCell', arr[i],"nump", d.nump , "",{title:"All Pubs: "+d.nump});
            jQuery("#kolsByRankingResultSet").jqGrid('setCell', arr[i],"leadc", d.leadc , "",{title:"Lead Author: "+d.leadc});
            jQuery("#kolsByRankingResultSet").jqGrid('setCell', arr[i],"numma", d.numma , "",{title:"Contributing Author: "+d.numma});
            jQuery("#kolsByRankingResultSet").jqGrid('setCell', arr[i],"numsa", d.numsa , "",{title:"Single Author: "+d.numsa});
            jQuery("#kolsByRankingResultSet").jqGrid('setCell', arr[i],"numfa", d.numfa , "",{title:"First Author: "+d.numfa});
            jQuery("#kolsByRankingResultSet").jqGrid('setCell', arr[i],"numla", d.numla , "",{title:"Last Author: "+d.numla});

            jQuery("#kolsByRankingResultSet").jqGrid('setCell', arr[i],"numtc", d.numtc , "",{title:"Clinical Trials: "+d.numtc});
            //jQuery("#kolsByRankingResultSet").jqGrid('setCell', arr[i],"numic", d.numic , "",{title:"Peer Nominations: "+d.numic});
            
            if (d.my_kols == 1) {
               var cl = arr[i]; 
                 $('#jqg_kolsByRankingResultSet_1') .attr('disabled', true);
            }
        //    console.log(dataSet);
            if(jQuery.inArray(parseInt(d.id), dataSet) !== -1){
            	if(d.micro == '1'){	
                    $("#kolsByRankingResultSet_frozen #jqg_kolsByRankingResultSet_"+arr[i]).replaceWith('<label><div class="tooltip-demo tooltop-right microViewIcon Male" onclick=\"viewKolMicroProfile('+d.id+',this); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel="tooltip" title=\"Profile Snapshot\">&nbsp;</a></div></label>');
                  }else{
                    $("#kolsByRankingResultSet_frozen #jqg_kolsByRankingResultSet_"+arr[i]).replaceWith('<label><div class="tooltip-demo tooltop-right requestProfile sprite_iconSet" onclick=\"addNewKolProfile('+d.id+',this); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel="tooltip" title=\"Request Profile\">&nbsp;</a></div></label>');
                  }
//              
            }

        }
							if(columnsToHide.length < 5){
                       			$(".frozen-bdiv").css({"top":"122px"});
                       		}else{
                       			$(".frozen-bdiv").css({"top":"122px"});
                           	}
//             if(isRankingReportLoadedFirst){        
// 			saveColumnSettings();       
//             }
			
        }

	});
	//jQuery("#JQBlistAllResultSet").jqGrid('navGrid','#listAllPager',{edit:false,add:false,del:false,search:false,refresh:false});
	jQuery("#kolsByRankingResultSet").jqGrid('navGrid','#kolsByRankingPager',{edit:false,add:false,del:false,search:false,refresh:false});
	//Toolbar search bar below the Table Headers
	jQuery("#kolsByRankingResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn",beforeSearch: function(){
		$(".ui-search-toolbar input[type='text']").each(function(){
			if($(this).val() == 'Search')
				$(this).val("");
	    });
	},afterSearch:function(){
		/*$(".ui-search-toolbar input[type='text']").each(function(){
			if($(this).val() == '')
				$(this).val("Search");
	    });*/
	}});

	jQuery("#kolsByRankingResultSet").jqGrid('setFrozenColumns');
	
	//Group column headers
	jQuery("#kolsByRankingResultSet").jqGrid('setGroupHeaders', {
		  useColSpanStyle: false, 
		 
		}); 
	//Column Choosers, Settings
// 	jQuery("#kolsByRankingResultSet").jqGrid('navButtonAdd','#kolsByRankingPager',{
// 	    caption: "Columns",
// 	    title: "Reorder Columns",
// 	    onClickButton : function (){
// 	        jQuery("#kolsByRankingResultSet").jqGrid('columnChooser');
// 	    }
// 	});

	  headerRow = jQuery("#kolsByRankingResultSet").closest("div.ui-jqgrid-view")
      .find("table.ui-jqgrid-htable>thead>tr.ui-jqgrid-labels");

  // increase the height of the resizing span
  resizeSpanHeight = 'height: ' + headerRow.height() + 'px !important; cursor: col-resize;';
  headerRow.find("span.ui-jqgrid-resize").each(function () {
      this.style.cssText = resizeSpanHeight;
  });

  // set position of the dive with the column header text to the middle
  rowHight = headerRow.height();
  headerRow.find("div.ui-jqgrid-sortable").each(function () {
      var ts = $(this);
      ts.css('top', (rowHight - ts.outerHeight()) / 2 + 'px');
  });
	
}

function loadRankingChart(){
	var chartOptions;
	$("#RSSFEED2").html("");
	// Append the required div and table
	$("#RSSFEED2").html('<div id="kolsActivitiesChart"></div>');
	
	var filterData = globalPostDataObject;
	$('#rssfeed_content1').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
	$.ajax({
		dataType:"json",
		url:base_url+"identifications/get_ranking_report/chart",
		type:"POST",
		data:filterData,
		success:function(returnData){
			var activityCategories;
			var eventsData;
			var affsData;
			var pubsData;
			var trialsData;
			var guidlinesData;
			var surveysData;
			activityCategories=returnData[0];
			eventsData=returnData[1];
			affsData=returnData[2];
			pubsData=returnData[3];
			trialsData=returnData[4];
			guidlinesData=returnData[5];
			surveysData=returnData[6];
			chartOptions=loadRankingChartData(activityCategories,eventsData,affsData,pubsData,trialsData,guidlinesData,surveysData);
			$('#rssfeed_content1').unblock();
                        onpageLoad=false;
			loadFilters();
			applySelectedWeightage();
		},
      	complete:function(){
    		//kolsActivitiesChart = new Highcharts.Chart(chartOptions);
    		//kolsActivitiesChart.redraw();
      		$('#rssfeed_content1').unblock();
	     }
	});
		
}

function loadRankingChartData(activityCategories,eventsData,affsData,pubsData,trialsData,guidlinesData,surveysData){
if(typeof activityCategories == "undefined" || activityCategories == null)
             activityCategories = [];
          activityCategories.unshift("x");
          if(typeof eventsData == "undefined" || eventsData == null)
              eventsData=[];
          eventsData.unshift("Events");
          if(typeof affsData == "undefined" || affsData == null)
              affsData=[];
          affsData.unshift("Affiliations" );
          if(typeof pubsData == "undefined" || pubsData == null)
              pubsData=[];
          pubsData.unshift("Publications");
          if(typeof trialsData == "undefined" || trialsData == null)
              trialsData=[];
          trialsData.unshift("Trials");
          if(typeof guidlinesData == "undefined" || guidlinesData == null)
              guidlinesData=[];
          guidlinesData.unshift("Guidelines");
  var chart = c3.generate({
                          bindto: '#kolsActivitiesChart',
                           size: {
      width: 820
  },
                              data: {
                                          x : 'x',
                                          columns: [
                                                  activityCategories,
                                                  eventsData,
                                                  affsData,
                                                  pubsData,
                                                  trialsData,
                                                  guidlinesData],
                                           groups:[['Events', 'Affiliations','Publications','Trials','Guidelines']],
                                          type: 'bar'
       },
                                       color: {
                                        pattern: chartColors
       },
                                      axis: {
                                          x: {
                                              type: 'category',
                                              tick: {
                                                  rotate:90,
                                                  multiline: true
       },
                                              height: 100
                                          }
           },
            bar: {
      width: {
          ratio:0.4// this makes bar width 50% of length between ticks
      }
      // or
      //width: 100 // this makes bar width 100px
  },
                                      tooltip: {
                                  format: {                
                                      value: function (value, ratio, id) {          
                                          return ":  "+value;
           }
               }
  }
                          });
}

function export_ranking_data(){
	
	if($('#includeSurvey').attr('checked') =='checked'){
		
		$('#nomineeChkBox').val('1');
	}else{
		$('#nomineeChkBox').val('0');
	}
	//nomineeChkBox
	$("#weightageValue").val($("#weightageForm").serialize());
	$("#filterValues").val($("#rightSidebarForm").serialize());
	$("#rankingExportForm").submit();	
}
function export_trends_data(){
	$("#weightageValueTrend").val($("#weightageForm").serialize());
	$("#filterValuesTrend").val($("#rightSidebarForm").serialize());
	$("#trendsExportForm").submit();	
}
function loadTrendsReport(){ 
    chartType='trenloadTrendsReportds';
    var dataSet = arrClientKolIds;
	   
	var dataUrl = base_url+"identifications/load_trends_data";
	var filterData = globalPostDataObject;
	resetAllFiltersSet=false;
	$('#rssfeed_content1').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
	$('#searchLeftBar').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
	$.ajax({
		dataType:"json",
		url:dataUrl,
		type:"POST",
		data:filterData,
		success:function(returnData){
            trendsData=returnData;
			returnData = sortByKey(returnData, 'last5');
			var returnData = returnData; 
				 		
			loadTrendsData(returnData,'last5','asc',dataSet);
		                
			loadFilters(filterData);
			$('#rssfeed_content1').unblock();
			initilizeGridSearchPlaceholder();
		                
			$("#trendsExportForm textarea").html(JSON.stringify(returnData));
		          
		}
	});
}

function sortByKey(array, key,order) {
    return array.sort(function(a, b) {
        var x = a[key]; var y = b[key];
        if(order=='desc')
           return ((x > y) ? -1 : ((x < y) ? 1 : 0));
        else
            return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    });
}

var sortGlobalIndex='last5',sortGlobalOrder='asc',sortTriggerd=false;
function trendsGridFunction(sortIndex,sortOrder){
    sortGlobalIndex=sortIndex;
    sortGlobalOrder=sortOrder;
    sortTriggerd=true;
    arrSearch=[];
    trendsGridFunctionSearch(arrSearch,sortTriggerd)


}


function trendsGridFunctionSearch(arrSearch){
    var returnData='';i=0;
  
  /**
   * 
   * if search empty
   * 
   */
  if(!arrSearch.length && !sortTriggerd){
       $('#kolsByTrendsResultSet').jqGrid('clearGridData');
 $("#kolsByTrendsResultSet").setGridParam({recordtext: "View {0} - {1} of "+trendsData.length});
    jQuery("#kolsByTrendsResultSet")
        .jqGrid('setGridParam',
            {
                datatype: 'local',
                data:trendsData,
                sortname:sortGlobalIndex,
                sortorder:sortGlobalOrder,
                records:trendsData.length
            })
        .trigger("reloadGrid");
      return false;
      
        }
    for( var result in arrSearch){
        
          var data_key=arrSearch[result].field;
                                var text=arrSearch[result].value;
         
         
        if(i==0){
      returnData = trendsData.filter(function( obj ) {
                               
				if(obj[data_key].toString().toLowerCase().search(text.toLowerCase()) == -1)
					return false;
				else
					return true;
				});
                            }
                            else{
                        returnData = returnData.filter(function( obj ) {
				if(obj[data_key].toString().toLowerCase().search(text.toLowerCase()) == -1)
					return false;
				else
					return true;
				});         
            }
              i++;                 
    }
  
   
 
 sortTriggerd=false;
    
     if(arrSearch.length)
        returnData = sortByKey(returnData, sortGlobalIndex,sortGlobalOrder);
    else
         returnData = sortByKey(trendsData, sortGlobalIndex,sortGlobalOrder);
  var totalRecords=returnData.length;
 returnData = returnData.slice(0, 100); 
    $('#kolsByTrendsResultSet').jqGrid('clearGridData');

    jQuery("#kolsByTrendsResultSet")
        .jqGrid('setGridParam',
            {
                datatype: 'local',
                data:returnData,
                sortname:sortGlobalIndex,
                sortorder:sortGlobalOrder,
                records:totalRecords
            })
        .trigger("reloadGrid");
    $("#kolsByTrendsResultSet").setGridParam({recordtext: "View {0} - {1} of "+totalRecords});
    
}

function loadTrendsData(json,index,sortOrder,dataSet){
	var client_id = <?php echo $this->session->userdata('client_id'); ?>;
	var filterData = globalPostDataObject;
	var functionCalled=false;
	$("#RSSFEED3").html("");
	// Append the required div and table
	$("#RSSFEED3").html('<div class="gridWrapper" id="trendsGridContainer"><table id="kolsByTrendsResultSet"></table><div id="kolsByTrendsPager"></div></div>');
	jQuery("#kolsByTrendsResultSet").jqGrid({
	   	//url:base_url+'identifications/load_trends_data/',
	   	//postData:filterData,
		//datatype: "json",
		datatype: "local",
	    data: json,
		colNames:['Id','','Name','Last 5 Score','Last 3 Score','Last 1 Score','Last 5 Years','Last 3 Years','','Last 1 Year',''],
	   	colModel:[
					{name:'id',index:'id', hidden:true},
					{name:'micro',index:'micro',width:30, search:false,hidden:true},
					{name:'name',index:'name', width:200,formatter: function (cellvalue, options, rowObject) {
				        return "<a href='"+base_url+"kols/view/"+rowObject.unique_id+"' target='_NEW' class='link' title='" + $.jgrid.stripHtml(cellvalue) + "'>" +
				            $.jgrid.htmlEncode(cellvalue) + "</a>";
						
			    	}},
			    	{name:'last5_score',index:'last5_score', width:100,sorttype:'int',hidden:true},
			    	{name:'last3_score',index:'last3_score', width:100,sorttype:'int',hidden:true},
			    	{name:'last1_score',index:'last1_score', width:100,sorttype:'int',hidden:true},
					{name:'last5',index:'last5', width:200,sorttype:'int'},
					{name:'last3_text',index:'last3_text', width:200,sorttype: function (cellvalue, rowObject) {
						return rowObject.last3;
						
			    	}},
                          {name:'last3',index:'last3', width:100,sorttype:'int',hidden:true},
					{name:'last1_text',index:'last1_text', width:200,sorttype: function (cellvalue, rowObject) {
						  
                 
                return rowObject.last1;
						
			    	}},
                                 {name:'last1',index:'last1', width:100,sorttype:'int',hidden:true},
	   	],
	   	rowNum:100,
	   	rownumbers: true,
	   	autowidth: true,
             records:100,
	   	loadonce:true,
             rownumWidth:50,
	   	ignoreCase:true,
	   	headertitles:true,
	   	hiddengrid:false,
	   	height: "auto",	
	   	width:"100%",
	   	resizable:true,
	   	shrinkToFit: true,
	   	pager: '#kolsByTrendsPager',
	   	mtype: "POST",
//             page:10,
lastpage:5,
	   	sortname: index,
	    viewrecords: true,
	    sortorder: sortOrder,
	    jsonReader: { repeatitems : false, id: "0" ,
//     total: function (json) { return 500; },
    }, 
	    caption:'KTL Trends',
	    rowList:[50,100,150],
	    gridComplete: function(){ 
             onpageLoad=false
	    	initilizeGridSearchPlaceholder();
            if(INTERNAL_CLIENT_ID==client_id){	
    	    	$("#trendsGridContainer").find(".excelExportIcon").remove();
    	    	$("#trendsGridContainer .ui-jqgrid-titlebar").append('<div onclick="export_trends_data()" class="excelExportIcon sprite_iconSet tooltip-demo"> <a href="#" rel="tooltip" data-original-title="Export">&nbsp;</a></div>');
            }	
	    	/*var ids = jQuery("#kolsByTrendsResultSet").jqGrid('getDataIDs'); 
 		for(var i=0;i < ids.length;i++){
		    	var rowData = jQuery("#kolsByTrendsResultSet").jqGrid('getRowData', ids[i]);
				microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewKolMicroProfile('"+rowData.id+"',this); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Profile Snapshot\">&nbsp;</a></div></label>";
		    	jQuery("#kolsByTrendsResultSet").jqGrid('setRowData',ids[i],{micro:microviewLink}); 
	    	} */
   
     $("#kolsByTrendsResultSet").setGridParam({recordtext: "View {0} - {1} of "+trendsData.length});
     
     setTimeout(function(){if(!functionCalled){$('#kolsByTrendsResultSet').trigger( 'reloadGrid' );functionCalled=true;}  }, 1000);
	if($('#referral_all').val()!=0 && $('#referral_all').val()!=100){
         $("#trendsGridContainer").find(".trendsMessage").remove();
//          $("#trendsGridContainer .ui-jqgrid-title").append('<div class="trendsMessage">Referral data point is not considered for generating trends report</div>');
     }  
 	},
      
 	beforeProcessing: function (data, status, xhr) {
 		//$("#trendsExportForm textarea").html(JSON.stringify(data));
     },
 	onSelectAll: function(aRowids,status) {
 		var ids = jQuery("#kolsByTrendsResultSet").jqGrid('getDataIDs'); 
 		for(var i=0;i < ids.length;i++){ 
 		
			    	var cl = ids[i];				    	
			    	var rowData = jQuery("#kolsByTrendsResultSet").jqGrid('getRowData', cl);
			    
			    	if(rowData.status=='Approved' || rowData.status=='Profiling' || rowData.status=='Review'){
						
			    		  var cbs = $("tr.jqgrow > td > input.cbox:disabled",jQuery("#kolsByTrendsResultSet")[0]);
			                cbs.removeAttr("checked");

			                //modify the selarrrow parameter
			                jQuery("#kolsByTrendsResultSet")[0].p.selarrrow = jQuery("#kolsByTrendsResultSet").find("tr.jqgrow:has(td > input.cbox:checked)")
			                    .map(function() { return this.id; }) // convert to set of ids
			                    .get(); // convert to instance of Array
					}
				
	    	} 

	          
     }
	});
	//jQuery("#JQBlistAllResultSet").jqGrid('navGrid','#listAllPager',{edit:false,add:false,del:false,search:false,refresh:false});
	jQuery("#kolsByTrendsResultSet").jqGrid('navGrid','#kolsByTrendsPager',{edit:false,add:false,del:false,search:false,refresh:false});
	//Toolbar search bar below the Table Headers
	jQuery("#kolsByTrendsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn",beforeSearch: function(){
	var search=[];	

         $("#trendsGridContainer  input[type='text']").each(function(){
			if($(this).val() == 'Search')
				$(this).val("");
                         else{
                             if(typeof $(this).attr('name') !== "undefined" && $(this).val()!='')
                                 search.push({"field":$(this).attr('name'),"value":$(this).val()});
                        }
	    });
//         console.log(search);
        trendsGridFunctionSearch(search);  
      
	},afterSearch:function(){
		/*$(".ui-search-toolbar input[type='text']").each(function(){
			if($(this).val() == '')
				$(this).val("Search");
	    });*/
	}});	
} 
var isRefReportActive = false;	
function colorGroupedHeader(){
	$("#rankingGridContainer .ui-th-column").each(function(index){
		switch(index){
			case 7 :
				$(this).addClass("color-11");
				break;
			case 8 :
				$(this).addClass("color-12");
				break;
			case 9 : 
				$(this).addClass("color-13");
				break;
			case 10 :
				$(this).addClass("color-21");
				break;
			case 11 :
				$(this).addClass("color-22");
				break;
			case 12 :
				$(this).addClass("color-23");
				break;
			case 13 :
				$(this).addClass("color-24");
				break;
			case 14 :
				$(this).addClass("color-25");
				break;
			case 15 :
				$(this).addClass("color-26");
				break;
			case 16 :
				$(this).addClass("color-41");
				break;
			case 17 :
				$(this).addClass("color-42");
				break;
			case 18 :
				$(this).addClass("color-43");
				break;
			case 19 :
				$(this).addClass("color-43");
				break;
			case 20 :
				$(this).addClass("color-43");
				break;
			case 21 : 
				$(this).addClass("color-43");
				break;	
			case 22 : 
				$(this).addClass("color-31");
				break;
			case 23 : 
				$(this).addClass("color-31");
				break;
			case 24 :
				$(this).addClass("color-51");
				break;
			case 25 : 
				$(this).addClass("color-52");
				break;
			case 26 : 
				$(this).addClass("color-53");
				break;
			case 27 : 
				$(this).addClass("color-53");
				break;
			case 28 : 
				$(this).addClass("color-53");
				break;
		}
	});
	
}

function applyLocalColumnChanges(){ 
	//Show all columns first
	//jQuery("#kolsByRankingResultSet").hideCol("name");
	if(isResetAllFilter){
		columnsToHide = [];
		columnsToHide.push('numevc');
		columnsToHide.push('numed');
		columnsToHide.push('nump');
		columnsToHide.push('numtc');
		columnsToHide.push('ref');
	}
	
	if($("input[name='include_survey']").attr('checked') == 'checked'){
		columnsToHide.push('numic');
		$("#colSettingsHolder input[value='numic']").attr('checked','checked');
	}else{
		var index = columnsToHide.indexOf("numic");
		if (index >= 0) {
			columnsToHide.splice( index, 1 );
			$("#colSettingsHolder input[value='numic']").removeAttr('checked','checked');
		}
	}
	if(columnsToHide.length > 0){
		jQuery("#kolsByRankingResultSet").hideCol("nump");
	 	jQuery("#kolsByRankingResultSet").hideCol("leadc");
	 	jQuery("#kolsByRankingResultSet").hideCol("numma");
	 	jQuery("#kolsByRankingResultSet").hideCol("numsa");
	 	jQuery("#kolsByRankingResultSet").hideCol("numfa");
	 	jQuery("#kolsByRankingResultSet").hideCol("numla");
	 	jQuery("#kolsByRankingResultSet").hideCol("numed");
	 	jQuery("#kolsByRankingResultSet").hideCol("numia");
	 	jQuery("#kolsByRankingResultSet").hideCol("numas");
	 	jQuery("#kolsByRankingResultSet").hideCol("numeb");
	 	jQuery("#kolsByRankingResultSet").hideCol("numec");
	 	jQuery("#kolsByRankingResultSet").hideCol("numspc");
	 	jQuery("#kolsByRankingResultSet").hideCol("numocc");
	 	jQuery("#kolsByRankingResultSet").hideCol("numevc");
	 	jQuery("#kolsByRankingResultSet").hideCol("numtc");
	 	jQuery("#kolsByRankingResultSet").hideCol("numgc");
	 	jQuery("#kolsByRankingResultSet").hideCol("numic");
		for(var i = 0; i < columnsToHide.length; i++) {
			jQuery("#kolsByRankingResultSet").showCol(columnsToHide[i]);
			 //$('.'+columnsToHide[i]).hide();
		 }
                
                
	}
        if(unCheckAll==1){
            jQuery("#kolsByRankingResultSet").hideCol("nump");
            jQuery("#kolsByRankingResultSet").hideCol("leadc");
            jQuery("#kolsByRankingResultSet").hideCol("numma");
            jQuery("#kolsByRankingResultSet").hideCol("numsa");
            jQuery("#kolsByRankingResultSet").hideCol("numfa");
            jQuery("#kolsByRankingResultSet").hideCol("numla");
            jQuery("#kolsByRankingResultSet").hideCol("numed");
            jQuery("#kolsByRankingResultSet").hideCol("numia");
            jQuery("#kolsByRankingResultSet").hideCol("numas");
            jQuery("#kolsByRankingResultSet").hideCol("numeb");
            jQuery("#kolsByRankingResultSet").hideCol("numec");
            jQuery("#kolsByRankingResultSet").hideCol("numspc");
            jQuery("#kolsByRankingResultSet").hideCol("numocc");
            jQuery("#kolsByRankingResultSet").hideCol("numevc");
            jQuery("#kolsByRankingResultSet").hideCol("numtc");
            jQuery("#kolsByRankingResultSet").hideCol("numgc");
            jQuery("#kolsByRankingResultSet").hideCol("numic");
            for(var i = 0; i < columnsToHide.length; i++) {
                    jQuery("#kolsByRankingResultSet").hideCol(columnsToHide[i]);
                     //$('.'+columnsToHide[i]).hide();
             }
       }
       unCheckAll=0;
	if(columnsToHide.length < 5){
			$(".frozen-bdiv").css({"top":"124px"});
		}else{
			$(".frozen-bdiv").css({"top":"124px"});
   	}
       $("#colSettingsHolder input[name='col_settings[]']:checked").each(function(){
		var thisVal = $(this).val(); 
		if(thisVal=='numspc' || thisVal=='numocc'){
                    
                    var divId='event';
                    var li  = document.getElementById(divId);
                    var  clas=li.className;
                    if(clas=='facet-toggle collapsed'){
                    $('#'+divId).removeClass('collapsed');
                    $('#'+divId).addClass('expanded');
                }
                }
		if(thisVal=='numia' || thisVal=='numas' || thisVal=='numeb' || thisVal=='numec' || thisVal=='numgc'){
                    
                    var divId='publication';
                    var li  = document.getElementById(divId);
                    var  clas=li.className;
                    if(clas=='facet-toggle collapsed'){
                    $('#'+divId).removeClass('collapsed');
                    $('#'+divId).addClass('expanded');
                }
                }
		if(thisVal=='leadc' || thisVal=='numma' || thisVal=='numsa' || thisVal=='numfa' || thisVal=='numla'){
                    
                    var divId='affiliation';
                    var li  = document.getElementById(divId);
                    var  clas=li.className;
                    if(clas=='facet-toggle collapsed'){
                    $('#'+divId).removeClass('collapsed');
                    $('#'+divId).addClass('expanded');
                }
                }
	});
   if(isResetAllFilter){
  	 $('#event').removeClass();
       $('#event').addClass('facet-toggle collapsed');
       $('#publication').removeClass();
       $('#publication').addClass('facet-toggle collapsed');
       $('#referal').removeClass();
       $('#referal').addClass('facet-toggle collapsed');
       $('#affiliation').removeClass();
       $('#affiliation').addClass('facet-toggle collapsed');
       isResetAllFilter = false;
 	}
}

function showOnlyAppliedWeightagecolumns(){
	columnsToHide = [];
	$.each(arrApplyWeightages,function (index,value){
		var oName = index;
		var oValue = value;
// 		alert(oName+" - "+value);
		if(oValue > 0 && oValue != ''){
			switch(oName) {
			    case 'pubs_all' :
			    case 'pubs_lead' :
			    case 'pubs_ma' :
			    case 'pubs_sa' :
			    case 'pubs_fa' :
			    case 'pubs_la' : columnsToHide.push('nump');
							    columnsToHide.push('leadc');
							    columnsToHide.push('numma');
							    columnsToHide.push('numsa');
							    columnsToHide.push('numfa');
							    columnsToHide.push('numla');
							    columnsToHide.push('pub');
			    	break;
			    case 'events_all' :
			    case 'events_speaker' :
			    case 'events_orgcom' :columnsToHide.push('numevc');
								    columnsToHide.push('numspc');
								    columnsToHide.push('numocc');
								    columnsToHide.push('colsett');
				    break;
			    case 'affiliations_all' :
			    case 'editorial_all' :
			    case 'assoc_all' :
			    case 'industry_all' :
                            case 'guideline_all':
			    case 'expert_all' :columnsToHide.push('numeb');
							    columnsToHide.push('numas');
							    columnsToHide.push('numia');
							    columnsToHide.push('numec');
							    columnsToHide.push('numed');
							    columnsToHide.push('aff');
                                                            columnsToHide.push('numgc');
				    break;
			    case 'trials_all' :
			    case 'trials_pi' :
			    case 'trials_ci':columnsToHide.push('numtc');
							    //columnsToHide.push('leadc');
							    //columnsToHide.push('numma');
				    break;
			    case 'surveys_all':columnsToHide.push('numic');
		        	break;
			    default: break;
			}
		}
	});
	applyLocalColumnChanges();
	$("#colSettingsHolder input[name='col_settings[]']").each(function(){
		$(this).removeAttr('checked');
	});
	for(var i = 0; i < columnsToHide.length; i++) {
		$("#colSettingsHolder input[name='col_settings[]'][value='"+columnsToHide[i]+"']").attr('checked','checked');
	}
}

function get_client_kol_ids(){
	var dataSet = new Array();
	$.ajax({
        type: "post",
        dataType:"json",
        async:false,
        url: baseUrl+'identifications/get_client_kolIds',
        success: function(json){
            $.each(json, function(i) {
                dataSet.push(json[i]);
            });
        },
    });
    return dataSet;
}

function viewKolMicroProfile(kolId,thisEle,allPage){
	$("#contentHolder").removeClass("reasonContent");
	//var elmt=document.getElementById(kolId);	
	var pos = getElementAbsolutePos(thisEle);

	var xPos=pos.x+23;
	if(allPage == null){
		var yPos=pos.y+170;
	}else{
		var yPos=pos.y+480;
	}
	$("#arraouHolder").css({'position': 'absolute','top':yPos-31,'left':xPos-11});
	$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos});

	var position = findPos(thisEle);
	$("#arraouHolder").css({'position': 'absolute','top':position[0]-57,'left':position[1]+13});
	$("#contentHolder").css({'position': 'absolute','top':position[0]-24,'left':position[1]+24});
	
	$("#arraouHolder").show();
	$("#contentHolder").show();

	$(".profileContent").html("");
	//$("#contentHolder").html("<div class='microViewLoading'>Loading...</div>");
	$('#contentHolder .profileContent').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});		


	$("#contentHolder .profileContent").load(base_url+'kols/view_kol_micro/'+kolId,{},
			function(){	$('#contentHolder .profileContent').unblock(); }
		);
	
	return false;
}

function findPos(obj) {
	 var obj2 = obj;
	 var curtop = 0;
	 var curleft = 0;
	 if (document.getElementById || document.all) {
	  do  {
	   curleft += obj.offsetLeft-obj.scrollLeft;
	   curtop += obj.offsetTop-obj.scrollTop;
	   obj = obj.offsetParent;
	   obj2 = obj2.parentNode;
	   while (obj2!=obj) {
	    curleft -= obj2.scrollLeft;
	    curtop -= obj2.scrollTop;
	    obj2 = obj2.parentNode;
	   }
	  } while (obj.offsetParent)
	 } else if (document.layers) {
	  curtop += obj.y;
	  curleft += obj.x;
	 }
	 return [curtop, curleft];
	}   // en
	
function closeKolProfile(){
	$("#arraouHolder").hide();
	$(".profileContent").html("");
	$("#contentHolder").hide();
}

function removeSelectedKeyword(thisEle){
	var selText = $(thisEle).parent().find(".keywordText").html();
	var meshtermId = $(thisEle).parent().find(".keywordText").attr('mestermid');
	$(thisEle).parent().remove();
	$('#multiKeywords option[value="'+selText+'"]').remove();
	$('#multiKeywordsId option[value="'+meshtermId+'"]').remove();
	$('.keywordSearch span[autotext="'+selText+'"]').parent().remove();
	reloadSection();
}

function loadColumnSettings(e){
	$("#colSettingsHolder").show();
	//$("#colSettingsHolder").load(base_url+'identifications/load_columns_settings/');
	/*$("#customWeightage .profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$('#columnSettings').dialog("open");
	$('.columnSettingsContent').load(base_url+'identifications/load_columns_settings/');*/
	e.stopPropagation();
}

function prepareSavedFilterData(){
	var filterData = [];
	var leftFilters = $("#leftSidebarForm").serializeArray();
	filterData = filterData.concat(leftFilters);
	var rightFilters = $("#rightSidebarForm").serializeArray();
	filterData = filterData.concat(rightFilters);
	var weightageFilters = $("#weightageForm").serializeArray();
	filterData = filterData.concat(weightageFilters);

	return filterData;
}


function getSavedFilters(){
	$("#addKolsCustomFilters .profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$('#addKolsCustomFilters').dialog("open");
	$('#addKolsCustomFiltersContainer').load(base_url+'identifications/get_saved_filters/');
}

function addFilters(){
	$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$('#addKolsCustomFilters').dialog("open");
	$('#addKolsCustomFiltersContainer').load(base_url+'identifications/add_saved_filters/');
}

function saveFilters(){
	if($('#filterNewName').val() == ''){
		jAlert("Please enter the Saved Filter name");
		return false;
	}
	data = {};
	data['filterName'] = $('#filterNewName').val(); 
	data['filter_type'] = 2; 
// 	data['saveFilter'] = postDataObject;//prepareSavedFilterData();
// 	data['saveFilter'] = getAllFilters();
	data['saveFilter'] = globalPostDataObject;
	data['saveFilter'] = JSON.stringify(data['saveFilter']);
	data['privacy'] = $("input[name='privacy']:checked"). val();
	$(".profileContent").html("<div class='microViewLoading'>Saving...</div>");
	$.ajax({
		type: "post",
		dataType:"json",
		data: data,
		url: base_url+"identifications/save_custom_filters",
		success: function(returnData){
			if(returnData.status == true){
				$(".profileContent").html("");
				$('#addKolsCustomFilters').dialog("close");
				$('#savedFilterValue').append('<option value="'+returnData.id+'" selected="selected">'+data['filterName']+'</option>');
				$('#savedFilterValue').trigger('liszt:updated');
//				$('#addFilters').text($('#savedFilterValue option:selected').text());
				$("#customFilterMsg").html($('#savedFilterValue option:selected').text());
				$('#addFilters').attr('onclick','addFilters()');
			}
	}
	});
}

function updateFilters(){
	data = {};
	data['filterId'] = $('#existNameId').val();
	data['filterName'] = $('#filterNewName').val();  
	data['saveFilter'] = globalPostDataObject;
	data['saveFilter'] = JSON.stringify(data['saveFilter']);
	$(".profileContent").html("<div class='microViewLoading'>Updating...</div>");
	$.ajax({
		type: "post",
		dataType:"json",
		data: data,
		url: base_url+"identifications/update_custom_filters",
		success: function(returnData){
			if(returnData.status == true){
				$('#addKolsCustomFilters').dialog("close");
				$('#savedFilterValue option[value="'+data['filterId']+'"]').text(data['filterName']);
				$('#savedFilterValue option[value="'+data['filterId']+'"]').attr("selected","selected");
				$('#savedFilterValue').trigger('liszt:updated');
				$("#customFilterMsg").html($('#savedFilterValue option:selected').text());
				$('#addFilters').attr('onclick','addFilters()');
			}
	}
	});
}

function deleteFilter(id) {
	customOk = "Ok";
	customCancel = "Cancel";
	jConfirm("Are you sure want to delete?","Please Confirm",function(r){
		if(r){
			$('.addCustomFilters').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
			$.ajax({
				type: "post",
				dataType:"json",
				url: base_url+"kols/delete_saved_filter/"+id,
				success: function(returnData){
					if(returnData.status == true){
						$('#addKolsCustomFilters').dialog("close");
						$("#sf"+id).remove();
						$('.addCustomFilters').unblock();
						$('#savedFilterValue option[value="'+id+'"]').remove();
// 						$('#savedFilterValue').trigger('liszt:updated');
					}
			}
			});
		}else{
			return false;
		}
	});
	customOk = "Adjust";
	customCancel = "Disable";
}

function blankFilter(){
	isResetAllFilter = true;
	
	arrTempAllWt['pubs_all'] = 25;
	arrTempAllWt['affiliations_all'] = 25;
	arrTempAllWt['events_all'] = 30;
	arrTempAllWt['trials_all'] = 20;
	$.each($("#categoriesContainer input[type='checkbox']:checked"), function() {
		$(this).removeAttr('checked');
	});
	$.each($("#categoriesContainer input[type='text']"), function() {
		$(this).val('');
	});
	if(projectId != ''){
		$('#projectSelection').val(projectId);
	    $('#projectSelection').trigger("chosen:updated");
	}else{
		var lastValue = $('#projectSelection option:last-child').val();
		$('#projectSelection').val(lastValue);
	    $('#projectSelection').trigger("chosen:updated");
	}
    $('#savedFilterValue').val('');
    
	$("#keywordSearch ul").html('');
	$("#keywordSearch1 ul").html('');
	$("#multiKeywords").html('');
	$("#multiKeywordsId").html('');
	$("#colSettingsHolder input[name='col_settings[]']").each(function(){
		$(this).attr('checked','checked');
	});
	reloadSection();
}

var isSaveFilterActive = false;
var savedFilterId;
function activeCustmFilters() {
	var filterId = $("#savedFilterValue").val();
	if(filterId==''){
		blankFilter();
		return false;
	}
	savedFilterId = $("#savedFilterValue").val();
	$('#searchFiltersContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
	$('#searchResultsContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
	$.ajax({
		type: "post",
		dataType:"json",
		url: base_url+"kols/get_filter_by_id/"+filterId,
		success: function(returnData){
// 			console.log(returnData.filterData);
			if(prevRSSFeedName != "RSSFEED4"){
				if($("#customWeightage input[name='wyn']").val() == 'no'){
					$("#toggleWeightage").attr('checked','checked');
					$("#customWeightage input[name='wyn']").val('yes');
					$("#showWeighatages").show();
				}
			}
			isSaveFilterActive = true;
			postDataObject = $.parseJSON(returnData.filterData);
			reloadSection();
			showOnlyAppliedWeightagecolumns();
			return false;
		}
	});
}


function showColumns(thisEle,event){
	var cls = $(thisEle).attr('class');
	var id  =  $(thisEle).attr('id');
		if(id=="publication"){	
			if(cls=='facet-toggle collapsed'){
				//jQuery("#kolsProfileScore").jqGrid('hideCol',["amount","tax"]); 
				
				jQuery("#kolsByRankingResultSet").jqGrid('showCol',["leadc","numma",
			   	                                       "numsa",
			   	                                       "numfa","numla"]); 
				$(thisEle).removeClass('collapsed');
				$(thisEle).addClass('expanded');
				}else{
					jQuery("#kolsByRankingResultSet").jqGrid('hideCol',["leadc","numma",
						   	                                       "numsa",
						   	                                       "numfa","numla"]);
					$(thisEle).removeClass('expanded');
					$(thisEle).addClass('collapsed');
				}
		}
		
		if(id=="event"){
			if(cls=='facet-toggle collapsed'){
				jQuery("#kolsByRankingResultSet").jqGrid('showCol',["numspc","numocc"]); 
				$(thisEle).removeClass('collapsed');
				$(thisEle).addClass('expanded');
			}else{
				$(thisEle).removeClass('expanded');
				$(thisEle).addClass('collapsed');
				jQuery("#kolsByRankingResultSet").jqGrid('hideCol',["numspc","numocc"]); 
			}
		}
		if(id=="affiliation"){
			if(cls=='facet-toggle collapsed'){
				jQuery("#kolsByRankingResultSet").jqGrid('showCol',["numia","numas","numeb","numec","numgc"]); 
// 				jQuery("#kolsByRankingResultSet").jqGrid('showCol',["numia","numec","numgc"]); 
				$(thisEle).removeClass('collapsed');
				$(thisEle).addClass('expanded');
			}else{
				$(thisEle).removeClass('expanded');
				$(thisEle).addClass('collapsed');
				jQuery("#kolsByRankingResultSet").jqGrid('hideCol',["numia","numas","numeb","numec","numgc"]); 
// 				jQuery("#kolsByRankingResultSet").jqGrid('hideCol',["numia","numec","numgc"]); 
			}
		}
	// get the header row which contains
    headerRow = jQuery("#kolsByRankingResultSet").closest("div.ui-jqgrid-view")
        .find("table.ui-jqgrid-htable>thead>tr.ui-jqgrid-labels");

    // increase the height of the resizing span
    resizeSpanHeight = 'height: ' + headerRow.height() + 'px !important; cursor: col-resize;';
    headerRow.find("span.ui-jqgrid-resize").each(function () {
        this.style.cssText = resizeSpanHeight;
    });

    // set position of the dive with the column header text to the middle
    rowHight = headerRow.height();
    headerRow.find("div.ui-jqgrid-sortable").each(function () {
        var ts = $(this);
        ts.css('top', (rowHight - ts.outerHeight()) / 2 + 'px');
    });
    event.stopPropagation();
}

function displaySelectedFilters(){
	var msg	= '<strong>Results Refined By:</strong><label id="profTypeText" style="font-weight: normal !important;">&nbsp;</label>';
	var separator	= '';
	var specialties 	= '';
	var countries	= '';
	var regions	= '';
	var cities	= '';
	var states	= '';
	var industries	= '';
	var organizations	= '';
	//if($('#projectSelection option:selected').text() != "All Projects") 
	msg	+= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'+$('#projectSelection option:selected').text()+'">Project</a>';
	
	$.each($('#categoriesContainer input:checked'), function( key, value ) {
		var selectedValue	= $(value).parent().html();
		selectedValue = selectedValue.replace(/<\/?[^>]+(>|$)/g, "");
		var selectedSection	= $(this).parent().parent().parent().find('tr').eq(0).find('input[type="checkbox"]').val();
		separator	= '';
		if(selectedSection!=selectedValue){
			switch(selectedSection){
				case 'All Specialties':
					if(specialties!=''){
						separator	= ', ';
					}
					specialties += separator+selectedValue;
					break;
				case 'All Countries':
					if(countries!=''){
						separator	= ', ';
					}
					countries += separator+selectedValue;
					break;
				case 'All Regions':
					if(regions!=''){
						separator	= ', ';
					}
					regions += separator+selectedValue;
					break;
				case 'All States':
					if(states!=''){
						separator	= ', ';
					}
					states += separator+selectedValue;
					break;
				case 'All Cities':
					if(cities!=''){
						separator	= ', ';
					}
					cities += separator+selectedValue;
					break;
				case 'All Industries':
					if(industries!=''){
						separator	= ', ';
					}
					industries += separator+selectedValue;
					break;
				case 'All Organizations':
					if(organizations!=''){
						separator	= ', ';
					}
					organizations += separator+selectedValue;
					break;
			}
		}
	});
	if(specialties!=''){
		msg	+= ', <a href="#" onclick="return false;" rel="tooltip" data-original-title="'+specialties+'">Specialties</a>';
	}
	if(countries!=''){
		msg	+= ', <a href="#" onclick="return false;" rel="tooltip" data-original-title="'+countries+'">Countries</a>';
	}
	if(regions!=''){
		msg	+= ', <a href="#" onclick="return false;" rel="tooltip" data-original-title="'+regions+'">Regions</a>';
	}
	if(cities!=''){
		msg	+= ', <a href="#" onclick="return false;" rel="tooltip" data-original-title="'+cities+'">Cities</a>';
	}
	if(states!=''){
		msg	+= ', <a href="#" onclick="return false;" rel="tooltip" data-original-title="'+states+'">States</a>';
	}
	if(industries!=''){
		msg	+= ', <a href="#" onclick="return false;" rel="tooltip" data-original-title="'+industries+'">Industries</a>';
	}
	if(organizations!=''){
		msg	+= ', <a href="#" onclick="return false;" rel="tooltip" data-original-title="'+organizations+'">Organizations</a>';
	}
	msg	+= ' | <label id="customFilterMsg" style="font-weight: normal !important;">&nbsp;</label>';
	$('span.filterSections').html(msg);
}

function resetAllFilters(loadOrNot){
	isResetAllFilter = true;
	var restArrFilters = {};
	$.each(arrApplyWeightages,function (key,val){
		if (key.indexOf("year_range") < 0){
			restArrFilters[key] = '';
		}else{
			restArrFilters[key] = val;
		}
	});
	arrApplyWeightages = restArrFilters;
// 	console.log("reset");
// 	console.log(arrApplyWeightages);
	arrTempAllWt = {};
	
	$.each($("#categoriesContainer input[type='checkbox']:checked"), function() {
		$(this).removeAttr('checked');
	});
	$.each($("#categoriesContainer input[type='text']"), function() {
		$(this).val('');
	});
	if(projectId != ''){
		$('#projectSelection').val(projectId);
	    $('#projectSelection').trigger("chosen:updated");
	}else{
		var lastValue = $('#projectSelection option:last-child').val();
		$('#projectSelection').val(lastValue);
	    $('#projectSelection').trigger("chosen:updated");
	}
    $('#savedFilterValue').val('');
    
	$("#keywordSearch ul").html('');
	$("#keywordSearch1 ul").html('');
	$("#multiKeywords").html('');
	$("#multiKeywordsId").html('');
	$("#colSettingsHolder input[name='col_settings[]']").each(function(){
		$(this).attr('checked','checked');
	});

	$("#toggleWeightage").prop('checked', false); 
// 	$("#toggleWeightage").attr('checked','checked');
	$("#customWeightage input[name='wyn']").val('no');
	$("#showWeighatages").hide();
	
// 	arrWeightages = arrWeightagesHideShow;
// 	arrWeightages = arrWeightages;
// 	arrTempAllWt = {};
	reloadSection();
}

function addNewKolProfile(KolId){
	/*$(".newProfileContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#newKolProfile").dialog("open");
	$(".newProfileContent").load(base_url+'requested_kols/add_client_pre_kol/'+KolId);
	*/
	var userRoleId = <?php echo $this->session->userdata('user_role_id')?>;
	customOk = "Ok";
	customCancel = "Cancel";
	jConfirm('Do you want a Full profile to be built for this Contact?',"Confirm message",function(r){
		if(r){
			if(userRoleId == ROLE_MANAGER){
				jAlert("The Profile has been requested for processing. You will get a notification once the requests are processed.");
			}else{
				jAlert("Your KOL Profile request has been submitted to your manager for approval. We will notify you when your request is approved");
			}
			$.ajax({
				url:base_url+'requested_kols/request_kol_profile/'+KolId,
				type:'post',
				dataType:'json',
				success:function(returnData){
					if(returnData.saved==true){
						if(userRoleId != ROLE_MANAGER){
							if(returnData.is_user_already_requested == true){
								jAlert("You have already requested profile and it is pending for approval from your manager.");
							}
						}
						//jAlert("The Profile has been requested for processing. You will get a notification once the requests are processed.");
						//window.location = base_url+'requested_kols/show_client_requested_kols';
					}else{
						jAlert("Unable to send request for profiling.");
					}
				}
			});
			return false;
		}else{
			return false;
		}
	});
	customOk = "Adjust";
	customCancel = "Disable";	
}

function addToMyContacts(){
	var selRowId = jQuery("#kolsByRankingResultSet").jqGrid ('getGridParam', 'selarrrow');
	var tempKolIds = new Array();
	for(var i=0;i < selRowId.length;i++){ 
    	var cl = selRowId[i];				    	
    	var rowData = jQuery("#kolsByRankingResultSet").jqGrid('getRowData', cl);
    	tempKolIds.push(rowData.id)
	}
	var data = {};
	
	if(selRowId == ''){
		jAlert("Please select the KTLs to add to My Contacts");
		return false;
	}
	var diff = [];
	jQuery.grep(tempKolIds.map(Number), function(el) {
	        if (jQuery.inArray(el, arrClientKolIds) == -1) diff.push(el);
	});
	data["kol_id"] = diff;
	if(diff == ''){
		jAlert("No KTL to Add Contacts");
		return false;
	}
// 	customOk = "Ok";
// 	customCancel = "Cancel";
// 	jConfirm("Are you sure whant to add selected KTLs to Contact","Confirm message",function(r){
// 		if(r){
        	$.ajax({
        		url:base_url+'identifications/save_kol_to_contact',
        		type:'post',
        		dataType:'json',
        		data: data,
        		success:function(returnData){
        			jAlert('Selected KTLs added to contacts', '', function(result) {
        				location.reload();
                    });
        			
        		},
        		complete: function () {
        			
        		}
        	});
// 		}else{
// 			return false;
// 		}
// 	});
}

function askProfileType(kolId){
	customOk = "Full Profile";
	customCancel = "ID Profile";
	jConfirm(profileRequestConfirmMessage,"Confirm message",function(r){
		if(r){
			var profileUrl = base_url+"kols/view/"+kolId+"/fromId";
			var win = window.open(profileUrl, '_blank');
			  win.focus();
		}else{
			var profileUrl = base_url+"kols/view/"+kolId+"/idonly";
			var win = window.open(profileUrl, '_blank');
			  win.focus();
		}
	});
	customOk = "Adjust";
	customCancel = "Disable";
}

function displaySelectedWeightagesColumns(){
	
}
function hideColumnSettings(){
	$("#colSettingsHolder").hide();
	e.stopPropagation();
}
</script>
<form>
	<input type="hidden" id="projectIdFirstTime" value="<?php echo $defaultProjectId; ?>"></input>
</form>
<div style="padding-top: 7px; border-bottom: 1px solid rgb(187, 187, 187); min-height: 36px;">
	<div id="keywordSearch1" class="keywordSearch">
		<label style="float: left; margin-right: 5px;">Keywords  :</label>
		<ul>
		</ul>
		<input name="keywords1" id="keywords1" class="autocompleteInputBox" placeholder="Keywords" style="color: grey; margin-top: -2px; height: 24px; width: 200px;">
	</div>
	<!-- 
	<div class="timeLineSliderContainer ui-widget-content" style="width: 300px;float: right;">
		<label style="float: left;">Year Range</label>
		<div id="timeLineSlider1" class="timeLineSlider twoSlider" title="Slide to Adjust Timeline" style="float: left; width: 200px; margin-top: -10px;">
			<div class="min"></div>
			<div class="max"></div>
			<input type="hidden" class="timelineValueHolder" name="year_range"/>
		</div>
	</div>  -->
	<div id="resetBttnContainer"><label class="tooltip-demo tooltop-left" id="resetBttn" onclick="resetAllFilters(true);"><a data-original-title="Reset all filters" href="#" class="tooltipLink" rel="tooltip">&nbsp;</a></label>Reset all filters</div>
</div>


<div id="tabs1">
	<div class="divider firstRight">&nbsp;</div>
	<a id="rankR" class="current" >
		<div class="reportsInactive"></div><?php echo lang('Identification.RankingReport');?>
	</a><div class="divider">&nbsp;</div>
	<a id="rankC" >
		<div class="chartsInactive"></div><?php echo lang('Identification.Graph');?>
	</a><div class="divider" >&nbsp;</div>
	<a id="trendsR" >
		<div class="trendsInactive"></div><?php echo lang('Identification.Trends');?>
	</a><div class="divider">&nbsp;</div>
</div>
<div class="clear rssFeed">
	<div id="rssfeed_content1">
		<div id="RSSFEED1" class="rssFeedReportsContainer" style="display:none;"></div>
		<div id="RSSFEED2" class="rssFeedReportsContainer" style="display:none;"></div>
		<div id="RSSFEED3" class="rssFeedReportsContainer" style="display:none;"></div>
		<div id="colSettingsHolder" style="display: none;">
			<ul id="columnSettingTree">
				<li>
					<label><input name="col_settings[]" id="checkedAll" value="colsettall" type="checkbox" onchange="checkUncheckAll(this);" />All</label>
				</li>
				<li>
					<label class="facet-toggle collapsed"></label>
					<label><input class="checkSingle" name="col_settings[]" value="colsett" type="checkbox" />Events</label>
					<ul style="display: none;">
						<li>
							<label><input name="col_settings[]" value="numevc" type="checkbox" />Events Total</label>
						</li>
						<li>
							<label><input name="col_settings[]" value="numspc" type="checkbox" />Speaking</label>
						</li>
						<li>
							<label><input name="col_settings[]" value="numocc" type="checkbox" />Organizing Committee</label>
						</li>
					</ul>
				</li>
				<li>
					<label class="facet-toggle collapsed"></label>
					<label><input class="checkSingle" name="col_settings[]" value="aff" type="checkbox" />Affiliations</label>
					<ul style="display: none;">
						<li>
							<label><input name="col_settings[]" value="numed" type="checkbox" />Affiliations Total</label>
						</li>
						<li>
							<label><input name="col_settings[]" value="numia" type="checkbox" />Industry</label>
						</li>
						<li>
							<label><input name="col_settings[]" value="numas" type="checkbox" />Associations</label>
						</li>
						<li>
							<label><input name="col_settings[]" value="numeb" type="checkbox" />Editorial Boards</label>
						</li>
						<li>
							<label><input name="col_settings[]" value="numec" type="checkbox" />Univ/Hospital</label>
						</li>
                        <li>
                                <label><input  name="col_settings[]" value="numgc" type="checkbox" />Guidelines</label>
                        </li>
					</ul>
				</li>
				<li>
					<label class="facet-toggle collapsed"></label>
					<label><input name="col_settings[]" value="pub" type="checkbox" />Publications</label>
					<ul style="display: none;">
						<li>
							<label><input name="col_settings[]" value="nump" type="checkbox" />Pubs Total</label>
						</li>
						<li>
							<label><input name="col_settings[]" value="leadc" type="checkbox" />Lead Author</label>
						</li>
						<li>
							<label><input name="col_settings[]" value="numma" type="checkbox" />Contributing Author</label>
						</li>
						<li>
							<label><input name="col_settings[]" value="numsa" type="checkbox" />Single Author</label>
						</li>
						<li>
							<label><input name="col_settings[]" value="numfa" type="checkbox" />First Author</label>
						</li>
						<li>
							<label><input name="col_settings[]" value="numla" type="checkbox" />Last Author</label>
						</li>
					</ul>
				</li>
				<li>
					<label><input name="col_settings[]" value="numtc" type="checkbox" />Clinical Trials</label>
				</li>
			</ul>
			<button onclick="saveColumnSettings(); return false;" style="float: right;">Apply</button>
			<button onclick="hideColumnSettings(event); return false;" style="float: right; margin-right: 5px;">Cancel</button>
		</div>
	</div>
</div>

<div id="columnSettings" class="microProfileDialogBox">
	<div class="columnSettingsContent profileContent"></div>
</div>

<div id="customWeightage" class="microProfileDialogBox" style="display: none;">
	<form action="" name="weightageForm" id="weightageForm" onsubmit="return false;" autocomplete="off">
	<input type="hidden" name="wyn">
	<div style="padding-top: 0px; border-bottom: 1px solid rgb(187, 187, 187); min-height: 0px;">
		<div id="keywordSearch" class="keywordSearch">
			<ul>
			</ul>
			<input name="keywords" id="keywords" class="autocompleteInputBox" placeholder="Keywords">
			<select name="multi_keywords[]" id="multiKeywords" multiple="multiple" style="display: none;"></select>
			<select name="multi_keywords_id[]" id="multiKeywordsId" multiple="multiple" style="display: none;"></select>
		</div>
		<!-- 
		<div style="text-align: center;">
			<input type="text" name="total_weight" id="totalWeight" class="totalWeight" readonly="readonly" value="0">
			
			<div class="progress custom-progress">
				<div class="progress-bar progress-bar-default" id="totalWeight" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;max-width: 100%;">
				</div>
			</div>
			 
		</div>
		
		<div style="text-align: center;color: red;" id="weightageNotice">
			Weightages should be equal to 100%
		</div>
		 -->
		<div class="timeLineSliderContainer ui-widget-content" style="width: 300px;float: right;display: none;">
			<label style="float: left;">Year Range</label>
			<div id="timeLineSlider" class="timeLineSlider twoSlider" title="Slide to Adjust Timeline" style="float: left; width: 200px; margin-top: -10px;">
				<div class="min"></div>
				<div class="max"></div>
				<input type="hidden" class="timelineValueHolder" name="year_range"/>
			</div>
		</div>
	</div>
	<div id="customWeightageSection"> 
		<table>
			<tbody>
				<tr>
                                    <td class="firstcol events_container">
						<div class="parent-range timeLineSliderContainer">
							<div class="sliderWithLabel">
								<label>Events</label>
								<div id="eventsWeightage" class="timeLineSlider oneSlider parentNode" title="Slide to Adjust Timeline">
									<div class="min"></div>
									<div class="max"></div>
									<input type="hidden" class="timelineValueHolder" value="0" name="events_all"/>
									<div class="selectedHighlight"></div>
								</div>
							</div>
							<div class="timeLineSlider twoSlider" title="Slide to Adjust Timeline">
								<div class="min"></div>
								<div class="max"></div>
								<input type="hidden" class="timelineValueHolder" value="0" name="events_year_range"/>
							</div>
						</div>
						<div class="child-range timeLineSliderContainer">
							<div class="sec1">
								<div class="sliderWithLabel">
									<label>Speaker</label>
									<div id="speakerWeightage" class="timeLineSlider oneSlider childNode" title="Slide to Adjust Timeline">
										<div class="min"></div>
										<div class="max"></div>
										<input type="hidden" class="timelineValueHolder" value="0" name="events_speaker"/>
										<div class="selectedHighlight"></div>
									</div>
								</div>
								<div class="sliderWithLabel">
									<label>Organizing Commitee</label>
									<div id="orgcomWeightage" class="timeLineSlider oneSlider childNode" title="Slide to Adjust Timeline">
										<div class="min"></div>
										<div class="max"></div>
										<input type="hidden" class="timelineValueHolder" value="0" name="events_orgcom"/>
										<div class="selectedHighlight"></div>
									</div>
								</div>
							</div>
							
							<div class="sec2">
								<label>Event Priority</label>
								<select name="events_priority">
									<option value="">All</option>
									<option value="2">High</option>
									<option value="1">Medium</option>
									<option value="0">Low</option>
								</select>
							</div>
							
						</div>
					</td>
					<td class="publications_container">
						<div class="parent-range timeLineSliderContainer">
							<div class="sliderWithLabel">
								<label>Publications</label>
								<div id="pubsWeightage" class="timeLineSlider oneSlider parentNode" title="Slide to Adjust Timeline">
									<div class="min"></div>
									<div class="max"></div>
									<input type="hidden" class="timelineValueHolder" value="0" name="pubs_all"/>
									<div class="selectedHighlight"></div>
								</div>
							</div>
							<div class="timeLineSlider twoSlider" title="Slide to Adjust Timeline">
								<div class="min"></div>
								<div class="max"></div>
								<input type="hidden" class="timelineValueHolder" value="0" name="pubs_year_range"/>
							</div>
						</div>
						<div class="child-range timeLineSliderContainer">
							<div class="sec1">
								<div class="sliderWithLabel">
									<label>Lead Author</label>
									<div id="leadAuthWeightage" class="timeLineSlider oneSlider childNode" title="Slide to Adjust Timeline">
										<div class="min"></div>
										<div class="max"></div>
										<input type="hidden" class="timelineValueHolder" value="0" name="pubs_lead"/>
										<div class="selectedHighlight"></div>
									</div>
								</div>
								<div class="sliderWithLabel">
									<label>Contributing Author</label>
									<div id="middleAuthWeightage" class="timeLineSlider oneSlider childNode" title="Slide to Adjust Timeline">
										<div class="min"></div>
										<div class="max"></div>
										<input type="hidden" class="timelineValueHolder" value="0" name="pubs_ma"/>
										<div class="selectedHighlight"></div>
									</div>
								</div>
								<div class="sliderWithLabel">
									<label>Single Author</label>
									<div id="singleAuthWeightage" class="timeLineSlider oneSlider childNode" title="Slide to Adjust Timeline">
										<div class="min"></div>
										<div class="max"></div>
										<input type="hidden" class="timelineValueHolder" value="0" name="pubs_sa"/>
										<div class="selectedHighlight"></div>
									</div>
								</div>
								<div class="sliderWithLabel">
									<label>First Author</label>
									<div id="firstAuthWeightage" class="timeLineSlider oneSlider childNode" title="Slide to Adjust Timeline">
										<div class="min"></div>
										<div class="max"></div>
										<input type="hidden" class="timelineValueHolder" value="0" name="pubs_fa"/>
										<div class="selectedHighlight"></div>
									</div>
								</div>
								<div class="sliderWithLabel">
									<label>Last Author</label>
									<div id="lastAuthWeightage" class="timeLineSlider oneSlider childNode" title="Slide to Adjust Timeline">
										<div class="min"></div>
										<div class="max"></div>
										<input type="hidden" class="timelineValueHolder" value="0" name="pubs_la"/>
										<div class="selectedHighlight"></div>
									</div>
								</div>
							</div>
							
							<div class="sec2">
								<label>Journal Priority</label>
								<select name="pub_priority">
									<option value="">All</option>
									<option value="2">High</option>
									<option value="1">Medium</option>
									<option value="0">Low</option>
								</select>
							</div>
							
						</div>
					</td>
                                </tr>
				
				<tr>
                                    <td class="firstcol affiliations_container">
						<div class="parent-range timeLineSliderContainer">
							<div class="sliderWithLabel">
								<label>Affiliations</label>
                                    <div id="affiliationsWeightage" class="timeLineSlider oneSlider parentNode" title="Slide to Adjust Timeline">
									<div class="min"></div>
									<div class="max"></div>
									<input type="hidden" class="timelineValueHolder" value="0" name="affiliations_all"/>
									<div class="selectedHighlight"></div>
								</div>
							</div>
							<div class="timeLineSlider twoSlider" title="Slide to Adjust Timeline">
								<div class="min"></div>
								<div class="max"></div>
								<input type="hidden" class="timelineValueHolder" value="0" name="aff_year_range"/>
							</div>
						</div>
						<div class="child-range timeLineSliderContainer">
							<div class="sec1">
								<div class="sliderWithLabel">
									<label>Industry</label>
									<div id="industryWeightage" class="timeLineSlider oneSlider parentNode" title="Slide to Adjust Timeline">
										<div class="min"></div>
										<div class="max"></div>
										<input type="hidden" class="timelineValueHolder" value="0" name="industry_all"/>
										<div class="selectedHighlight"></div>
									</div>
								</div>
                                                                <div class="sliderWithLabel">
									<label>Associations</label>
									<div id="assocWeightage" class="timeLineSlider oneSlider parentNode" title="Slide to Adjust Timeline">
										<div class="min"></div>
										<div class="max"></div>
										<input type="hidden" class="timelineValueHolder" value="0" name="assoc_all"/>
										<div class="selectedHighlight"></div>
									</div>
								</div>
								<div class="sliderWithLabel">
									<label>Editorial Board</label>
									<div id="editorialWeightage" class="timeLineSlider oneSlider parentNode" title="Slide to Adjust Timeline">
										<div class="min"></div>
										<div class="max"></div>
										<input type="hidden" class="timelineValueHolder" value="0" name="editorial_all"/>
										<div class="selectedHighlight"></div>
									</div>
								</div>
								<div class="sliderWithLabel">
									<label>Univ/Hospital</label>
									<div id="expertWeightage" class="timeLineSlider oneSlider parentNode" title="Slide to Adjust Timeline">
										<div class="min"></div>
										<div class="max"></div>
										<input type="hidden" class="timelineValueHolder" value="0" name="expert_all"/>
										<div class="selectedHighlight"></div>
									</div>
								</div>
                                                                <div class="sliderWithLabel">
                                                                    <label>Guidelines</label>
                                                                    <div id="guidelineWeightage" class="timeLineSlider oneSlider parentNode" title="Slide to Adjust Timeline">
                                                                            <div class="min"></div>
                                                                            <div class="max"></div>
                                                                            <input type="hidden" class="timelineValueHolder" value="0" name="guideline_all"/>
                                                                            <div class="selectedHighlight"></div>
                                                                    </div>
                                                                </div>
							</div>
							
							<div class="sec2">
								<label>Priority</label>
								<select name="aff_priority">
									<option value="">All</option>
									<option value="2">High</option>
									<option value="1">Medium</option>
									<option value="0">Low</option>
								</select>
							</div>
						</div>
					</td>
					<td class="trials_container">
						<div class="parent-range timeLineSliderContainer">
							<div class="sliderWithLabel">
								<label>Trials</label>
								<div id="trialsWeightage" class="timeLineSlider oneSlider parentNode" title="Slide to Adjust Timeline">
									<div class="min"></div>
									<div class="max"></div>
									<input type="hidden" class="timelineValueHolder" value="0" name="trials_all"/>
									<div class="selectedHighlight"></div>
								</div>
							</div>
							<div class="timeLineSlider twoSlider" title="Slide to Adjust Timeline">
								<div class="min"></div>
								<div class="max"></div>
								<input type="hidden" class="timelineValueHolder" value="0" name="trials_year_range"/>
							</div>
						</div>
						<div class="child-range timeLineSliderContainer">
							<div class="sec1">
								&nbsp;
								<div class="sliderWithLabel" style="display: none;">
									<label>Principal Investigator</label>
									<div id="piWeightage" class="timeLineSlider oneSlider childNode" title="Slide to Adjust Timeline">
										<div class="min"></div>
										<div class="max"></div>
										<input type="hidden" class="timelineValueHolder" value="0" name="trials_pi"/>
										<div class="selectedHighlight"></div>
									</div>
								</div>
								<div class="sliderWithLabel" style="display: none;">
									<label>Co-Investigator</label>
									<div id="ciWeightage" class="timeLineSlider oneSlider childNode" title="Slide to Adjust Timeline">
										<div class="min"></div>
										<div class="max"></div>
										<input type="hidden" class="timelineValueHolder" value="0" name="trials_ci"/>
										<div class="selectedHighlight"></div>
									</div>
								</div>
							</div>
							
							<div class="sec2">
								<label>Sponsor Priority</label>
								<select name="trials_priority">
									<option value="">All</option>
									<option value="2">High</option>
									<option value="1">Medium</option>
									<option value="0">Low</option>
								</select>
							</div>
							
						</div>
						
						<div class="parent-range timeLineSliderContainer" style="display: none;">
							<div class="sliderWithLabel">
								<label style="width: 120px;">Peer Nominations</label>
								<div id="surveysWeightage" class="timeLineSlider oneSlider parentNode" title="Slide to Adjust Timeline">
									<div class="min"></div>
									<div class="max"></div>
									<input type="hidden" class="timelineValueHolder" value="0" name="surveys_all"/>
									<div class="selectedHighlight"></div>
								</div>
							</div>
							<div style="display: inline-block; float: right; margin-right: 6px; width: 174px; margin-top: -39px;">
								<input id="includeSurvey2" type="checkbox" name="include_survey2" <?php if(isset($filters['include_survey'])) echo "checked = 'checked'";?>>
								<label for="includeSurvey2" class="categoryName" style="float:right;border-bottom:0px;">Include Peer Nominations </label>
							</div>
						</div>
						<div class="child-range timeLineSliderContainer" style="display: none;">
							<div class="sec1">
								&nbsp;
							</div>
							<div class="sec2">
								&nbsp;
							</div>
						</div>
					</td>
				</tr>
				
				<tr>
					<td colspan="2">
						<div style="text-align: center;">
							<input name="total_weight" id="totalWeight" class="totalWeight" readonly="readonly" value="0">
							<button onclick="$('#customWeightage').dialog('close'); applySelectedWeightage(); return false;">Cancel</button>
							<button onclick="saveSelectedWeightages(); return false;">Apply</button>
						</div>
						<div style="text-align: center;color: red;" id="weightageNotice">
							Weightages should be equal to 100%
						</div>
					</td>
				</tr>
				
			</tbody>
		</table>
	</div>
	</form>
	
</div>
<input type="hidden" id="globalYear" value="0"/>
<form name="rankingExportForm" id="rankingExportForm" method="post" action="<?php echo base_url()?>identifications/export_ranking_data" style="display: none;">
	<textarea rows="" cols="" name="json_data"></textarea>
	<input type="hidden" name="nominee_chk_box" id="nomineeChkBox" value="0"></input>
	<input type="hidden" name="weightage_values" id="weightageValue" value=""></input>
	<input type="hidden" name="filter_values" id="filterValues" value=""></input>
</form>
<form name="trendsExportForm" id="trendsExportForm" method="post" action="<?php echo base_url()?>identifications/export_trends_data" style="display: none;">
	<textarea rows="" cols="" name="json_data"></textarea>
	<input type="hidden" name="weightage_values_trend" id="weightageValueTrend" value=""></input>
	<input type="hidden" name="filter_values_trend" id="filterValuesTrend" value=""></input>
</form>

<!-- Container for the 'Micro Profile'  box -->
<div id="contentHolder" class="callOutTest microView" style="display: none;">
	<div>
		<a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeKolProfile();" class="ui-icon ui-icon-closethick">close</span></a><!--
		<img class="ui-icon ui-icon-closethick" alt="" src="" onclick="closeKolProfile();" />
	--></div>
	<div class="profileContent"></div>
</div>
<div id="arraouHolder" class="callOutTest" style="display: none;"><div class="arrowMarkIcon"></div></div>
<!-- Container to add Custom filters -->
<div id="addKolsCustomFilters1"></div>
<div id="addKolsCustomFilters" class="addCustomFilters">
	<div id="addKolsCustomFiltersContainer" class="profileContent"></div>
</div>
<style>
	#columnSettingTree ul{
		list-style: none;
	}
	
	#columnSettingTree > li{
		position: relative;
	}
	ul.checktree-root, ul#tree ul {
		list-style: none;
	}
	ul.checktree-root label {
		font-weight: normal;
		position: relative;
	}
	ul.checktree-root label input {
		position: relative;
		top: 2px;
		left: -5px;
	}
	
	#columnSettingTree label.facet-toggle {
	    background: url("<?php echo base_url();?>images/kolm-sprite-image.png") no-repeat scroll -8px -91px transparent;
	}
	#columnSettingTree label.facet-toggle {
	   cursor: pointer;
	    display: block;
	    font-size: 85%;
	    height: 11px;
	    left: -16px;
	    position: absolute;
	    text-indent: -99999px;
	    top: 6px;
	    width: 11px;
	}
	#columnSettingTree label.collapsed {
	    background-position: -28px -91px;
	}

	#colSettingsHolder{
		background: none repeat scroll 0 0 white;
	    border: 1px solid #DDDDDD;
	    right: 1px;
	    padding: 5px;
	    position: absolute;
	    top: 22px;
	}
</style>


<script src="<?php echo base_url();?>js/jquery/jquery-checktree.js"></script>
<script type="text/javascript">

function saveColumnSettings(){
// 	isRankingReportLoadedFirst = true;
	//s$(".ui-jqgrid .ui-jqgrid-htable").css("margin-top","-22px");
	columnsToHide = [];
	$("#colSettingsHolder input[name='col_settings[]']:checked").each(function(){
		var thisVal = $(this).val();
		columnsToHide.push(thisVal);
                unCheckAll=0;
	});
// 	localStorage.columnsToHide = JSON.stringify(columnsToHide);
	applyLocalColumnChanges();
	$("#colSettingsHolder").hide();
}

function checkUncheckAll(thisEle){
	if($(thisEle).attr('checked') == 'checked')	{
		$("#colSettingsHolder input[name='col_settings[]']").each(function(){
			$(this).attr('checked','checked');
		});
		$(thisEle).attr('checked','checked');
	}else{
                unCheckAll=1;
		$("#colSettingsHolder input[name='col_settings[]']").each(function(){
			$(this).removeAttr('checked');
		});
	}
}

$(document).ready(function(){
	$("input[name='col_settings[]'][value!='colsettall']").click(function (){
		$("input[name='col_settings[]'][value='colsettall']").removeAttr("checked");
	});
});
$(document).ready(function(){
	$("#globalYear").val(defaultStartYear+"-"+defaultEndYear);
	$("#rankR").click(function(){
		prevRSSFeedName = "RSSFEED1";
          if($('#allSpecialties').prop("checked") && $('#allStates').prop("checked")
                && $('#allCities').prop("checked") && $('#allIndustries').prop("checked") && $('#allOrgs').prop("checked") && ($("input[name='wyn']").val() != 'yes' || $("input[name='wyn']").val()=='' ))
                    {
                onpageLoad=true;
            }
            else{
               onpageLoad=false; 
            } 
   
//     loadRankingReport();
    reloadSection();
    //applyLocalColumnChanges();
});
      $("#rankC").click(function(){
    	  prevRSSFeedName = "RSSFEED2";
         if($('#allSpecialties').prop("checked") && $('#allStates').prop("checked")
                && $('#allCities').prop("checked") && $('#allIndustries').prop("checked") && $('#allOrgs').prop("checked") && ($("input[name='wyn']").val() != 'yes' || $("input[name='wyn']").val()=='' ))
                    {
                onpageLoad=true;
            }
            else{
               onpageLoad=false; 
            }   
         reloadSection();
//     loadRankingChart();
}); 
      $("#trendsR").click(function(){
    	  prevRSSFeedName = "RSSFEED3";
         if($('#allSpecialties').prop("checked") && $('#allStates').prop("checked")
                && $('#allCities').prop("checked") && $('#allIndustries').prop("checked") && $('#allOrgs').prop("checked") && ($("input[name='wyn']").val() != 'yes' || $("input[name='wyn']").val()=='' ))
                    {
                onpageLoad=true;
            }
            else{
               onpageLoad=false; 
            } 
         reloadSection();
//     loadTrendsReport();
}); 
      
	$('#columnSettingTree').checktree();
	
	for(var i = 0; i < columnsToHide.length; i++) {
		$("#colSettingsHolder input[name='col_settings[]'][value='"+columnsToHide[i]+"']").attr('checked','checked');
	}

	$("#columnSettingTree label.facet-toggle").on('click',function(){
		if($(this).hasClass('expanded')){
			$(this).removeClass('expanded');
			$(this).addClass('collapsed');
			$(this).parent().find('ul').hide();
		}else{
			$(this).removeClass('collapsed');
			$(this).addClass('expanded');
			$(this).parent().find('ul').show();
		}
	});

	$(document).click(function(event){
		$('#colSettingsHolder').hide();
	});

	$('#colSettingsHolder').click(function(e){
		e.stopPropagation();
	});	
	  
//     $('#checkedAll').on('click',function(){
//         if(this.checked){
//             $('.checkSingle').each(function(){
//                 this.checked = true;
//             });
//         }else{
//              $('.checkSingle').each(function(){
//                 this.checked = false;
//             });
//         }
//     });
    
//     $('.checkSingle').on('click',function(){
//         if($('.checkSingle:checked').length == $('.checkSingle').length){
//             $('#checkedAll').prop('checked',true);
//         }else{
//             $('#checkedAll').prop('checked',false);
//         }
//     });
	
});

</script>

<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts = array('jquery/jquery-ui-1.8.16.slider','i18n/grid.locale-en','jquery.jqGrid.min','chosen.jquery','highcharts2_2_2/highcharts3.0.5',
								'highcharts2_2_2/modules/exporting3.0.5');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>