<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array(	'search/org_results',
								'jquery.autocomplete',
								'chosen.jquery'
							 );
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet" />
<!--  Autocomplete Plugin --><!--
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.autocomplete.js"></script>
	
--><style>
	/* added by laxman */
	.span-4 {
		width:175px;
	}
/*	#searchResultsContainer {
		margin-left:7px;
		margin-right:10px;
		margin-top: 0px;
	}
*/	
	#searchResultsContainer table,table.listResultSet{
		border-left:1px solid #ccc;
		border-top:1px solid #ccc;
		border-left:1px solid #eee;
		border-top:1px solid #eee;
		border-bottom:1px solid #EEEEEE;	
		width:100%;
		border: 0px;
	}
	
	#searchResultsContainer table tbody tr.ui-widget-content{
		border:1px solid #ccc;
		border:1px solid #eee;
		border: 0px;
	}
	
	#searchResultsContainer table th,table.listResultSet th{
		text-align:center;	
		background: #22A1ED;
		color:#FFFFFF;
		background: none;
		color:#777;
		border: 0px;
	}
	
	#searchResultsContainer table td, #searchResultsContainer table th,table.listResultSet th,table.listResultSet td{
		font-size:12px;
		color:#626262;
		padding:6px 2px 6px 3px;
		vertical-align:top;
		white-space:normal;
		border-right:1px solid #ccc;
		border-bottom:1px solid #ccc;
		border-right:1px solid #eee;
		border-bottom:0px solid #eee;
		border: 0px;
		border-bottom: 1px solid #dddddd;
	}
	.expandRightSideBar{
		display: block !important;
	}
	.chzn-container-multi .chzn-choices{
		padding-left: 0px !important;
	}
	.chzn-container{
		font-size: 12px;
	}
	.chzn-container-single .chzn-single{
		border-radius: 2px;
		height: 18px;
		padding: 0 0 0 5px;		
	}
	.chzn-container-single .chzn-single span{
		margin-top: -3px;
	}
	.chzn-container .chzn-results{
		padding-left: 0px !important;
		margin: 0px;
	}
	#profileType_chzn .chzn-single span{
		margin-top: 0px;
	}
	#savedFilterValue_chzn .chzn-drop .chzn-search input{
		border-radius: 2px;
	}
	.highlighted{
		background: #5A86B8 !important;
		color: white;
	}
	.chzn-container-single .chzn-search input{
		padding: 2px 20px 2px 4px;
	}
	.chzn-search li input[type="text"]{
		border-radius: 2px !important;
	}
	div.actionIcon{
		float: right;
	}
        #searchResultsContainer ul.pageRightOptions {
    width: 120px;
}
ul.pageRightOptions {
    float: right;
    list-style: outside none none;
    margin: 0;
    padding: 0;
}
ul {
    list-style-type: disc;
}
ul, ol {
    margin: 0 1.5em 1.5em 0;
    padding-left: 3.333em;
}
#searchResultsContainer ul.pageRightOptions li {
    float: right;
}
ul.pageRightOptions li {
    float: left;
    height: 25px;
    line-height: 25px;
    list-style: outside none none;
    padding: 2px 3px;
    min-width: 25px;
}
</style>
<!-- Load the refinedByFilter CSS file ---- Added by Laxman -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/refinedByFilter.css" />
<script type="text/javascript">
/*	
	function doSearchFilter(startIndex){
		//close the microview if it is opened
		closeOrgProfile();
		
		$('#searchResultsContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		var formAction=$("#searchFilterForm").attr("action");
		var data=$("#searchFilterForm").serialize();
		data=data+"&page="+startIndex;
		$.ajax({
			type: "post",
			dataType:"text",
			data: data,
			url: formAction,
			success: function(returnData){
				$("#searchResultsContainer").html(returnData);
			},
			complete: function(){
				$('#searchResultsContainer').unblock();
			}
		});

		
	}

	function doSearchFilter1(startIndex,thisEle){
		//close the microview if it is opened
		closeOrgProfile();
		
		var expandedCategories = new Array();
		$('.expanded').each(function(){
			var parentId=$(this).parent().attr('id');
			expandedCategories.push(parentId);
		});
		var collapsedCategories = new Array();
		$('.collapsed').each(function(){
			var parentId=$(this).parent().attr('id');
			collapsedCategories.push(parentId);
		});
		//show loading image
		//$('.loadingIndicator').show();

		$('#searchResultsContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		//If 'All' is selected uncheck other checkbox of that category, 
		//Else uncheck the checkbox representing 'All', do the same for all categories
		if(thisEle!=null){
			if($(thisEle).val()=='country'){
				$('.countryElement').each(function(){
					$(this).removeAttr('checked');
				});
			}else {
				if($(thisEle).attr('class')=='countryElement')
					$('#allCountries').removeAttr('checked');
			}
			if($(thisEle).val()=='state'){
				$('.stateElement').each(function(){
					$(this).removeAttr('checked');
				});
			}else {
				if($(thisEle).attr('class')=='stateElement')
					$('#allStates').removeAttr('checked');
			}
	
			if($(thisEle).val()=='orgType'){
				$('.orgTypeElement').each(function(){
					$(this).removeAttr('checked');
				});
			}else {
				if($(thisEle).attr('class')=='orgTypeElement')
					$('#allOrgTypes').removeAttr('checked');
			}
		}
		//End of toggling 'All' and 'Others'
		
		//Get Selected check box value for each Category separatly
		var orgIdValues	  =new Array();
		$.each($("input[name='org_ids[]']:checked"), function() {
			orgIdValues.push($(this).val());
		});
		var countryValues = new Array();
		$.each($("input[name='country_ids[]']:checked"), function() {
			countryValues.push($(this).val());
		});
		var stateValues = new Array();
		$.each($("input[name='state_ids[]']:checked"), function() {
			stateValues.push($(this).val());
		});
		var orgTypeValues = new Array();
		$.each($("input[name='orgType_ids[]']:checked"), function() {
			orgTypeValues.push($(this).val());
		});		
		//End of Selecting Checkbox value for each Category separatly
		
		//Make all check boxes disabled while Loading
		$("#searchFiltersElements input[type='checkbox']").each(function(){
			$(this).attr({'disabled': true});
		});
		
		//To make Autocomplete field empty if value equal to 'Enter Country'
		if($('#orgName').val()=='Enter Org Name'){
			$('#orgName').val('');
		}
		
		if($('#country').val()=='Enter Country'){
			$('#country').val('');
		}
		if($('#state').val()=='Enter State'){
			$('#state').val('');
		}

		if($('#orgType').val()=='Enter Org Type'){
			$('#orgType').val('');
		}

		var formAction=$("#searchFilterForm").attr("action");
		var data=$("#searchFilterForm").serialize();
		data=data+"&page="+startIndex;
		data=data+"&countries="+countryValues;
		data=data+"&states="+stateValues;
		data=data+"&org_types="+orgTypeValues;	
		data=data+"&org_ids="+orgIdValues;	
		data=data+"&my_kols="+true;
		//Send Request to reload the filtered search results
		$.ajax({
			type: "post",
			dataType:"text",
			data: data,
			url: formAction,
			success: function(returnData){
				$("#searchResultsContainer").html(returnData);
			},
			complete: function(){
				//hide loading image
				$('.loadingIndicator').hide();
				$('#searchResultsContainer').unblock();
			}
		});
		//Send Request to reload the filtered 'Filter CheckBox's'
		$.ajax({
			type: "post",
			dataType:"text",
			data: data,
			url: '<?php echo base_url();?>organizations/reload_filters',
			success: function(returnData){
				$("#searchFiltersContainer").html(returnData);
			},
			complete: function(){
				//hide loading image
				$('.loadingIndicator').hide();
				$('#searchResultsContainer').unblock();
				//Expanding and collapseing the categoties
				$.each(expandedCategories, function(index, value) {
					$('#'+value+' label.facet-toggle').removeClass('collapsed');
					$('#'+value+' label.facet-toggle').addClass('expanded');
					$('#searchLeftBar #'+value+' ul').show(); 
				});	
				$.each(collapsedCategories, function(index, value) {
					$('#'+value+' label.facet-toggle').removeClass('expanded');
					$('#'+value+' label.facet-toggle').addClass('collapsed');
					$('#searchLeftBar #'+value+' ul').hide(); 
				});
			}
		});
	}

	$(document).ready(function(){
		
		// Settings for the Dialog Box
		var orgMicroProfileDialogOpts = {
				title: "Organization Snapshot",
				modal: true,
				autoOpen: false,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};
		
		$("#orgMicroProfile").dialog(orgMicroProfileDialogOpts);

		$("#savedFilterValue").chosen();		
	});
	
	//
	// Opens the Modal Box with the Micro Profile content of Organization
	// @param: orgId
	//
	function viewOrgMicroProfile_old(orgId){
		$("#orgMicroProfile .profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#orgMicroProfile").dialog("open");
		$(".profileContent").load('<?php echo base_url().'organizations/view_micro_org/'?>'+orgId);
		return false;
	}

	checked=false;
	function checkedAll (list) {
		
		var aa= document.getElementById('list');
		//jAlert(aa.toSource.value());
		 if (checked == false)
	          {
	           checked = true;
	          }
	        else
	          {
	          checked = false;
	          }
			for (var i =0; i < aa.elements.length; i++) 
		{
	
			 aa.elements[i].checked = checked;
		}
	
	}

	//
	// Opens the Modal Box with the Micro Profile content of KOL
	// @param: kolId
	//
	function viewOrgMicroProfile(orgId, e){
		var elmt=document.getElementById("org"+orgId);	
		var pos = getElementAbsolutePos(elmt);
		var xPos=pos.x+417;
		var yPos=pos.y-10;
		//$("#callOutTest").css({'position': 'absolute','top':yPos,'left':xPos});
		//$("#callOutTest").show();
		$("#arraouHolder").css({'position': 'absolute','top':yPos-25,'left':xPos+237});
		$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos-35});
		$("#arraouHolder").show();
		$("#contentHolder").show();

		$(".profileContent").html("");
		//$("#contentHolder").html("<div class='microViewLoading'>Loading...</div>");
		$('#contentHolder .profileContent').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});		
		$(".profileContent").load('<?php echo base_url().'organizations/view_micro_org/'?>'+orgId,{},
			function(){	$('#contentHolder .profileContent').unblock(); }
		);
		
		return false;
	}

	function closeOrgProfile(){
		$("#arraouHolder").hide();
		$(".profileContent").html("");
		$("#contentHolder").hide();
	}

*/

</script>
<div id="searchContainer">
	<div id="searchTopMenus"></div>
	<div id="searchResultsContainer" class="maxWidth">
		<?php echo $this->load->view($orgResultsPage,$orgResultsData);?>
	</div>
<!-- <div id="refinedByWrapper" class="rightRefinedByFilter">
		<div id="refinedByContainer">
			<div id="rightSideBarSlider" class="tooltip-demo tooltop-left collapseRightSideBar"><a href="#" class="tooltipLink" rel='tooltip' title="Show Refine By">&nbsp;</a></div>
			<div id="searchLeftBar" style="display: block;">
				<h3>
					<div class="funnelIcon sprite_iconSet"></div>Refine By
					<div id="resetBttnContainer"><label class="tooltip-demo tooltop-left" id="resetBttn" onclick="resetFilters();"><a href="#" class="tooltipLink" rel='tooltip' title="Reset Filters">&nbsp;</a></label>Reset</div>
				</h3>
				<div id="searchFiltersContainer">
					<?php //echo $this->load->view($filterPage,$filterData);?>
				</div>
			</div>
		</div>
	</div>
-->
	<div id="addNewOrg" class="microProfileDialogBox">
		<div class="addNewOrgProfileContent profileContent1"></div>
	</div>
	<div id="alignOrgUsersModalBox" class="microProfileDialogBox">
		<div class="alignOrgUsersContent profileContent"></div>
	</div>
	<div class="clear">&nbsp;</div>
	
	<!-- Container for the 'ORG Micro Profile' modal box -->
	<div id="dailog1">
		<div id="orgMicroProfile" class="microProfileDialogBox">
			<div class="profileContent"></div>
		</div>
	</div>
	<!-- END of Container for the 'ORG Micro Profile' modal box -->
	
	<!-- Container for the 'Org Micro Profile'  box -->
	<div id="contentHolder" class="callOutTest microView" style="display: none;">
		<div>
			<a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeOrgProfile();" class="ui-icon ui-icon-closethick">close</span></a>
			<!--<img class="ui-icon ui-icon-closethick" alt="" src="" onclick="closeOrgProfile();"/>
		--></div>
		<div class="profileContent"></div>
	</div>
	<div id="arraouHolder" class="callOutTest" style="display: none;"><div class="arrowMarkIcon"></div></div>
</div>
