<?php

/**
 * This is Model file of 'Kol'
 *
 * @package application.models
 * @author Ambarish
 * @since
 * @created on  9-12-10
 */
class Kol extends Model {

    //Constructor
    function Kol() {
        parent::Model();
        $this->load->model("Event_helper");
        $this->load->model("common_helpers");
        $this->load->model("interaction");
        $this->load->model('Country_helper');
        $this->load->model('Client_User');
        $this->load->model("pubmed");
    }

    /**
     *  INSERT kol details into DB
     * @param $arrKol
     * @return true/false
     */
    function saveKol($arrKol) {
        $this->db->where('first_name', $arrKol['first_name']);
        $this->db->where('middle_name', $arrKol['middle_name']);
        $this->db->where('last_name', $arrKol['last_name']);
        $this->db->where('specialty', $arrKol['specialty']);
        $arrKolDetail = $this->db->get('kols');

        if ($arrKolDetail->num_rows() != 0) {
            return false;
        } else {
            if ($arrKol['org_id'] == 0 || empty($arrKol['org_id'])) {
                $arrKol['org_id'] = null;
            }
            if ($this->db->insert('kols', $arrKol)) {
                return $this->db->insert_id();
            } else {
                return false;
            }
        }
    }

    /*
     * Get Organization name from 'organizations' Table
     * @param $orgName
     * @return $id
     */

    function getOrgName($orgName) {
        $id = '';
        $this->db->where('name', $orgName);
        $result = $this->db->get('organizations');
        foreach ($result->result_array() as $row) {
            $id = $row['id'];
        }
        return $id;
    }

    /*
     * Get Organization 'id' from 'organizations' Table
     * @param $orgId
     * @return $name
     */

    function getOrgId($orgId) {
        $name = '';
        $this->db->where('id', $orgId);
        $result = $this->db->get('organizations');
        foreach ($result->result_array() as $row) {
            $name = $row['name'];
        }
        return $name;
    }

    /**
     *  GET kol details
     * @param
     * @return array - $arrKolDetail - Returns
     */
    function getKolDetail($limit = null, $startFrom = null, $doCount = null) {
        if (!$doCount) {
            $this->db->select(array('kols.*', 'client_users.user_name as user_full_name'));
            $this->db->join('client_users', 'client_users.id = kols.created_by', 'left');
        }

        $this->db->where("(client_users.client_id=" . INTERNAL_CLIENT_ID . " or kols.status='" . COMPLETED . "')");

        if ($doCount) {
            $this->db->distinct();
            $count = $this->db->count_all_results('kols');
            return $count;
        } else {
            if ($limit != null)
                $this->db->limit($limit, $startFrom);
            $this->db->order_by('first_name', 'asc');

            $arrKolDetail = $this->db->get('kols');
            return $arrKolDetail;
        }
    }
    /**
     * Gets the modified date of KOL
     * @param $kolId
     * @return $modifiedDate
     */
    function getKolModifiedDate($kolId){
    	$this->db->select('modified_on');
    	$this->db->where('id',$kolId);
    	$result = $this->db->get('kols');
    	
    	foreach ($result->result_array() as $res){
    		$modifiedDate = $res['modified_on'];
    	}
    	return $modifiedDate;
    }
	
    
    function getAllKolCountryIdByKolId($kolId){
    	$arrKolDetails = array();
    	$this->db->select('country_id');
    	$this->db->where('kol_id',$kolId);
    	$arrKolDetailResult = $this->db->get('kol_locations');
    	foreach ($arrKolDetailResult->result_array() as $arrKol) {
    		$arrKolDetails[] = $arrKol['country_id'];
    	}
    	return array_unique($arrKolDetails);
    }
    /**
     * Edit kol details
     * @param $id
     * @return array - $arrKolDetail
     */
    function editKol($id) {
        $arrKolDetails = array();
        $this->db->select('kols.*, titles.title as title_name, specialties.specialty as specialty_name, degrees.degree,kol_locations.private_practice,kol_locations.latitude,kol_locations.longitude');
        $this->db->where('kols.id', $id);
        //$this->db->where('kol_locations.is_primary', '1');
        $this->db->join('titles', 'kols.title = titles.id', 'left');
        $this->db->join('specialties', 'kols.specialty = specialties.id', 'left');
        $this->db->join('degrees', 'kols.degree_id = degrees.id', 'left');
        $this->db->join('kol_locations', 'kols.id = kol_locations.kol_id and kol_locations.is_primary = 1', 'left',false);
        if ($arrKolDetailResult = $this->db->get('kols')) {
            // If the results are not available
            if ($arrKolDetailResult->num_rows() == 0) {
                return false;
            }

            foreach ($arrKolDetailResult->result_array() as $arrKol) {
                $arrKolDetails = $arrKol;
                if (is_numeric($arrKolDetails['title']))
                	$arrKolDetails['title_id'] = $arrKolDetails['title'];
                    $arrKolDetails['title'] = $arrKolDetails['title_name'];
            }
            return $arrKolDetails;
        }else {
            return false;
        }
    }

    /**
     * Upadate kol details
     * @param
     * @return array - $arrKolDetail
     */
    function updateKol($arrKol) {
    	if ($arrKol["is_primary"] == "1" && $arrKol["title"] > 0) {
    		$title_id = array('title' => $arrKol["title"]);
    		$this->db->where('id', $arrKol['id']);
    		$this->db->update('kols', $title_id);
    	}
        $id = $arrKol['id'];
        $this->db->where('id', $id);
        $arrKol = $this->db->update('kols', $arrKol);
        return $arrKol;
    }

    /**
     * Delete kol details
     * @param integer $id
     * @return
     */
    function deleteKol($id) {
        $this->db->where('id', $id);
        $this->db->delete('kols');
        return true;
    }

    /**
     * Save Membership details to DB
     * @param  $arrMembership
     * @return true/false
     */
    function saveMembership($arrMembership) {

        if ($this->db->insert('kol_memberships', $arrMembership)) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

//End of  saving Membership  detail to DB

    /**
     * List the memberships detail for passed Id
     * @param  $arrMembership
     * @return array - $arrMembershipDetails
     * 	Ex: array('row1'=>Array('id'=>'value','type'='value'),
     *           'row2'=>Array('id'=>'value','type'='value'))
     */
    function listMemberships($type = null, $kolId = null, $startFrom = null, $limit = null) {
        $arrMembershipDetails = array();
        if ($kolId != null && $type != null) {
            //Getting the data from 'kol_memberships' table and 'name' from 'institutions' table
            
            $this->db->select(array('kol_memberships.*', 'institutions.name', 'engagement_types.engagement_type','is_analyst','CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name'));
            $this->db->join('institutions', 'institutions.id = kol_memberships.institute_id', 'left');
            $this->db->join('client_users', 'kol_memberships.created_by = client_users.id','left');
            $this->db->where('kol_id', $kolId);
            if ($type != 'all') {
                $this->db->where('type', $type);
            }
            //Getting the data from 'kol_memberships' table and 'engagement_type' from 'engagement_types' table
            //$this->db->select(array('kol_memberships.*','engagement_types.engagement_type'));
            $this->db->join('engagement_types', 'engagement_types.id = kol_memberships.engagement_id', 'left');
        }

        if ($limit != null) {
            $this->db->limit($limit, $startFrom);
        }       
        $this->db->order_by('engagement_types.engagement_type','asc');
        $this->db->order_by('kol_memberships.start_date','desc');        
        if ($arrMembershipDetailResult = $this->db->get('kol_memberships')) {
            if ($arrMembershipDetailResult->num_rows() == 0) {
                return false;
            }
            //echo $this->db->last_query();exit;
            foreach ($arrMembershipDetailResult->result_array() as $arrMembership) {
                //setting the institute name
                $arrMembership['institute_id'] = $arrMembership['name'];
                if ($arrMembership['url1'] != '') {
                    $arrMembership['url1'] = '<a href=\'' . $arrMembership['url1'] . '\' target="_new">URL 1</a>';
                }if ($arrMembership['url2'] != '') {
                    $arrMembership['url2'] = '<a href=\'' . $arrMembership['url2'] . '\' target="_new">URL 2</a>';
                }

                //setting the engagement name
                $arrMembership['engagement_id'] = ($arrMembership['engagement_type'] != null) ? $arrMembership['engagement_type'] : '';

                // For the Govt and Association Types, store the 'Committee' values in the 'Department' col.
                //if(($type == 'government') || ($type == 'association')){
                //$arrMembership['department']	= $arrMembership['committee'];
                //}

                $arrMembershipDetails[] = $arrMembership;
            }
            return $arrMembershipDetails;
        } else {
            return false;
        }
    }

//End of getting Membership  detail

    /**
     * List the all memberships detail for passed Id
     * @param  $arrMembership
     * @return array - $arrMembershipDetails
     * 	Ex: array('row1'=>Array('id'=>'value','type'='value'),
     *           'row2'=>Array('id'=>'value','type'='value'))
     */
    function listAllAffiliationsDetails($kolId = null) {
        $clientId = $this->session->userdata('client_id');
        $arrMembershipDetails = array();
        if ($kolId != null) {
            //Getting the data from 'kol_memberships' table and 'name' from 'institutions' table
            $this->db->select(array('kol_memberships.*', 'institutions.name', 'engagement_types.engagement_type','is_analyst','CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name'));
            $this->db->join('institutions', 'institutions.id = kol_memberships.institute_id', 'left');
            $this->db->join('engagement_types', 'engagement_types.id = kol_memberships.engagement_id', 'left');
            $this->db->join('client_users', 'kol_memberships.created_by = client_users.id','left');
            $this->db->where('kol_id', $kolId);

            if ($clientId != INTERNAL_CLIENT_ID) {
                $this->db->where("(kol_memberships.client_id=$clientId or kol_memberships.client_id=" . INTERNAL_CLIENT_ID . ")");
            }
            //$this->db->order_by('institutions.name', 'asc');
            $this->db->order_by('kol_memberships.start_date', 'desc');
            
            if ($arrMembershipDetailResult = $this->db->get('kol_memberships')) {
                if ($arrMembershipDetailResult->num_rows() == 0) {
                    return false;
                }

                foreach ($arrMembershipDetailResult->result_array() as $arrMembership) {                    
                    $arrMembership['eAllowed'] =  $this->common_helpers->isActionAllowed('kol_details', 'edit', $arrMembership);
                    $arrMembershipDetails[] = $arrMembership;
                }
                return $arrMembershipDetails;
            } else
                return false;
        }
    }

    /**
     * Edit the memberships detail for passed Id
     * @param  $arrMembership
     * @return array - $arrMembership
     *
     */
    function editMembership($id) {

        $this->db->where('id', $id);
        if ($arrMembership = $this->db->get('kol_memberships')) {
            return $arrMembership;
        } else {
            return false;
        }
    }

    /**
     * Update the memberships detail for passed array $arrMembership
     * @param  $arrMembership
     * @return array - $arrMembership
     *
     */
    function updateMembership($arrMembership) {

        $id = $arrMembership['id'];
        $this->db->where('id', $id);
        if ($arrMembership = $this->db->update('kol_memberships', $arrMembership))
            return true;
        else
            return false;
    }

//End of Update

    /**
     * Delete the memberships detail for passed 'id'
     * @param  integer 'id'
     * @return true/false
     *
     */
    function deleteMembership($id) {
        //$this->firephp->log($id);
        $this->db->where('id', $id);
        if ($query = $this->db->delete('kol_memberships')) {
            return true;
        } else
            return false;
    }

    /**
     * Returns the list of  Names, based on the Membership Type
     *
     * @param $membershipType
     * @param $name
     * @return Array	$arrMembershipNames	Ex: arry('NIIT', 'JetKing');
     */
    function getMembershipName($membershipType, $name) {
        $this->db->select('name');
        $this->db->where('type', $membershipType);
        $this->db->like('name', $name);
        $arrResultSet = $this->db->get('kol_memberships');

        $arrMembershipNames = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrMembershipNames[] = $arrRow['name'];
        }

        return $arrMembershipNames;
    }

    /**
     * Returns the list of MembershipDepartment, based on the Membership Type
     *
     * @param $membershipType
     * @param $department
     * @return Array	$arrMembershipDepartment	Ex: arry('NIIT', 'JetKing');
     */
    function getMembershipDepartment($membershipType, $department) {
        $this->db->select('department');
        $this->db->where('type', $membershipType);
        $this->db->like('department', $department);
        $arrResultSet = $this->db->get('kol_memberships');

        $arrMembershipDepartment = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrMembershipDepartment[] = $arrRow['department'];
        }

        return $arrMembershipDepartment;
    }

    /**
     * Returns the list of Title, based on the MembershipType Type
     *
     * @param $membershipType
     * @param $title
     * @return Array	$arrMembershipTitles	Ex: arry('NIIT', 'JetKing');
     */
    function getMembershipTitle($membershipType, $title) {
        $this->db->select('title');
        $this->db->where('type', $membershipType);
        $this->db->like('title', $title);
        $arrResultSet = $this->db->get('kol_memberships');

        $arrMembershipTitles = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrMembershipTitles[] = $arrRow['title'];
        }

        return $arrMembershipTitles;
    }

    /**
     * Returns the list of Committee, based on the MembershipType Type
     *
     * @param $membershipType
     * @param $committee
     * @return Array	$arrMembershipCommittee	Ex: arry('NIIT', 'JetKing');
     */
    function getMembershipCommittee($membershipType, $committee) {
        $this->db->select('committee');
        $this->db->where('type', $membershipType);
        $this->db->like('committee', $committee);
        $arrResultSet = $this->db->get('kol_memberships');

        $arrMembershipCommittee = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrMembershipCommittee[] = $arrRow['committee'];
        }

        return $arrMembershipCommittee;
    }

    /**
     * Returns the list of Committee, based on the MembershipType Type
     *
     * @param $membershipType
     * @param $role
     * @return Array	$arrMembershipRole	Ex: arry('NIIT', 'JetKing');
     */
    function getMembershipRole($membershipType, $role) {
        $this->db->select('role');
        $this->db->where('type', $membershipType);
        $this->db->like('role', $role);
        $arrResultSet = $this->db->get('kol_memberships');

        $arrMembershipRole = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrMembershipRole[] = $arrRow['role'];
        }

        return $arrMembershipRole;
    }

    /**
     * Returns the list of division based on the Education Type
     *
     * @param $membershipType
     * @param $division
     * @return Array	$arrMembershipDivision	Ex: arry('NIIT', 'JetKing');
     */
    function getMembershipDivision($membershipType, $division) {
        $this->db->select('division');
        $this->db->where('type', $membershipType);
        $this->db->like('division', $division);
        $arrResultSet = $this->db->get('kol_memberships');

        $arrMembershipDivision = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrMembershipDivision[] = $arrRow['division'];
        }

        return $arrMembershipDivision;
    }

    //End of Memberships---------------
    //start of oranization-----
    /**
     * Returns the list of "Organization names"
     *
     * @param $name
     * @return Array	$arrOrgName	Ex: arry('Bilva', 'JetKing');
     */
    function getAutoOrgName($name) {
        $this->db->select('name');
        $this->db->like('name', $name);
        $this->db->distinct();
        $arrResultSet = $this->db->get('organizations');
        $arrOrgName = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrOrgName[] = $arrRow['name'];
        }
        return $arrOrgName;
    }

    //-------------Start of Event DAO functions-------------------------------
    /**
     * Saves the Event Data to DB
     *
     * @return Last Insert Id/false
     */
    function saveEvent($eventDetails,$eventId) {
    	if ($this->db->insert('kol_events', $eventDetails)) {
    		return $this->db->insert_id();
    	} else {
    		return false;
    	}
    }

    /**
     * Date function to convert from mysql format to php.
     *
     * @param date $inputDate Input date (format - YYYY-MM-DD)
     * @param string $delimeter Delimeter you want afetr converted
     * @return date  Output date (format - MM/DD/YYYY).
     */
    function convertDateToMM_DD_YYYY($inputDate, $delimiter = '/') {

        $ddDate = substr($inputDate, 8, 2);
        $mmDate = substr($inputDate, 5, 2);
        $yyDate = substr($inputDate, 0, 4);
        return ($mmDate . $delimiter . $ddDate . $delimiter . $yyDate);
    }

    /**
     * List all Events Data
     *
     * @return $arrEventsDetails/false
     */
    function listEvents($type, $kolId = null, $startDate, $endDate, $startFrom = null, $limit = null,$sortByYear=false) {

        $clientId = $this->session->userdata('client_id');
        $arrEventsDetails = array();
        //Get the Events of KolId
        if ($kolId != null) {
            $this->db->where('kol_id', $kolId);
            $this->db->where('kol_events.type', $type);
            if ($startDate != 0 && $endDate != 0) {
                $wherBetween = "(YEAR(start) BETWEEN '$startDate' AND '$endDate' OR YEAR(start)='0')";
                $this->db->where($wherBetween);
            }
            if ($type == 'conference') {
                $this->db->select(array('kol_events.*', 'event_sponsor_types.type as stype', 'event_organizer_types.type as otype', 'events.name', 'countries.Country', 'regions.Region', 'cities.City', 'conf_session_types.session_type', 'conf_event_types.event_type', 'event_topics.name as topic_name','client_users.is_analyst','client_users.first_name','client_users.last_name'));
                $this->db->join('events', 'events.id = event_id', 'left');
                $this->db->join('countries', 'CountryId = country_id', 'left');
                $this->db->join('regions', 'RegionId = state_id', 'left');
                $this->db->join('cities', 'cityId = city_id', 'left');
                $this->db->join('conf_session_types', 'conf_session_types.id = kol_events.session_type', 'left');
                $this->db->join('conf_event_types', 'conf_event_types.id = kol_events.event_type', 'left');
                $this->db->join('event_topics', 'kol_events.topic = event_topics.id', 'left');
                $this->db->join('event_sponsor_types', 'kol_events.sponsor_type = event_sponsor_types.id', 'left');
                $this->db->join('event_organizer_types', 'kol_events.organizer_type = event_organizer_types.id', 'left');
            } else {
                $this->db->select(array('kol_events.*', 'online_event_types.event_type', 'events.name', 'kol_events.event_type as onEventTypeId'));
                $this->db->join('events', 'events.id = event_id', 'left');
                $this->db->join('online_event_types', 'online_event_types.id = kol_events.event_type', 'left');
            }
            $this->db->join('client_users', 'client_users.id = kol_events.created_by');
        }

        if ($limit != null)
            $this->db->limit($limit, $startFrom);

        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where("(kol_events.client_id=$clientId or kol_events.client_id=" . INTERNAL_CLIENT_ID . ")");
        }
        if($sortByYear){
        	$this->db->order_by('kol_events.end','desc');
        }else{
        	$this->db->order_by('conf_event_types.event_type','asc');
        	$this->db->order_by('events.name','asc');
        }
        if ($arrEventsDetailsResult = $this->db->get('kol_events')) {
            //echo $this->db->last_query();
            foreach ($arrEventsDetailsResult->result_array() as $arrEvent) {
                $arrEvent['start'] = $this->convertDateToMM_DD_YYYY($arrEvent['start']);
                if ($arrEvent['start'] == '00/00/0000') {
                    $arrEvent['start'] = '';
                }
                $arrEvent['end'] = $this->convertDateToMM_DD_YYYY($arrEvent['end']);
                if ($arrEvent['end'] == '00/00/0000') {
                    $arrEvent['end'] = '';
                }
                if ($arrEvent['url1'] != '') {
                    $arrEvent['url1'] = '<a href=\'' . $arrEvent['url1'] . '\' target="_new">URl1</a>';
                }
                if ($arrEvent['url2'] != '') {
                    $arrEvent['url2'] = '<a href=\'' . $arrEvent['url2'] . '\' target="_new">URl2</a>';
                }
                $arrEvent['eAllowed'] =  $this->common_helpers->isActionAllowed('kol_details', 'edit', $arrEvent);
                $arrEventsDetails[] = $arrEvent;
            }
            return $arrEventsDetails;
        } else {
            return false;
        }
    }

    /**
     * Edit the Event Details
     *
     * @return true/false
     */
    function editEventById($id) {
        $this->db->where('id', $id);
        if ($arrEventDetails = $this->db->get('kol_events')) {
            return $arrEventDetails;
        } else {
            return false;
        }
    }

    /**
     * Updates the Event Data
     *
     * @return true/false
     */
    function updateEvent($eventDetails) {
        $this->db->where('id', $eventDetails['id']);
        if ($this->db->update('kol_events', $eventDetails)) {
        	return true;
        } else {
            return false;
        }
    }

    /**
     * Delete the Event Data
     *
     */
    function deleteEventById($id) {
        $this->db->where('id', $id);
        if ($query = $this->db->delete('kol_events')) {
            return true;
        } else
            return false;
    }

    /**
     * Returns the list of Participation Names, based on the Event Type
     *
     * @param $eventType
     * @param $participationName
     * @return Array	$arrParticipationNames
     */
    function getEventParticipations($eventType, $participationName) {
        $this->db->select('participation_type');
        $this->db->where('event_type', $eventType);
        $this->db->like('participation_type', $participationName);
        $arrResultSet = $this->db->get('kol_events');

        $arrParticipationNames = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrParticipationNames[] = $arrRow['participation_type'];
        }

        return $arrParticipationNames;
    }

    /**
     * Returns the list of Subject Names, based on the Event Type
     *
     * @param $eventType
     * @param $subjectName
     * @return Array	$arrSubjectNames
     */
    function getEventSubjects($eventType, $subjectName) {
        $this->db->select('subject');
        $this->db->where('event_type', $eventType);
        $this->db->like('subject', $subjectName);
        $arrResultSet = $this->db->get('kol_events');

        $arrSubjectNames = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrSubjectNames[] = $arrRow['subject'];
        }

        return $arrSubjectNames;
    }

    /**
     * Returns the Event Id
     *
     * @param String $name
     * @return Array $arrEventId
     */
    function getEventLookupId($name = null) {
        if ($name != null) {
            $this->db->select('id');
            $this->db->where('name', $name);
            $arrResultSet = $this->db->get('events');

            if ($arrResultSet->num_rows() == 0) {
                return false;
            }
            $arrEventId = array();
            foreach ($arrResultSet->result_array() as $arrRow) {
                return $arrRow['id'];
            }

            return $arrEventId;
        } else
            return false;
    }

    /**
     * Saves the Event Lookup Detail to DB
     *
     * @return Last Insert Id/false
     */
    function saveEventLookup($eventLookupDetails) {
        $eventLookupDetails['category'] = $eventLookupDetails['category'];
        $eventLookupDetails['name'] = $eventLookupDetails['name'];
        $this->db->where('category', $eventLookupDetails['category']);
        $this->db->where('name', $eventLookupDetails['name']);
        if ($arrEvents = $this->db->get('events')) {
            if ($arrEvents->num_rows() != 0) {
                return false;
            } else {
                if ($this->db->insert('events', $eventLookupDetails)) {
                    return $this->db->insert_id();
                } else {
                    return false;
                }
            }
        }
    }

    /**
     * Searches for the EventName and Returns the list of Event Names matched
     *
     * @param String $category
     * @param String $eventName
     * @return Array	$arrEventLookupNames
     */
    function getEventLookupNames($category, $eventName) {
        $this->db->select('id,name');
        $this->db->where('category', $category);
        $this->db->like('name', $eventName);
        $arrResultSet = $this->db->get('events');

        $arrEventLookupNames = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrEventLookupNames[$arrRow['id']] = $arrRow['name'];            
        }

        return $arrEventLookupNames;
    }

    /**
     * Searches for the EventName and Returns the list of Event Names matched
     *
     * @param String $category
     * @param String $eventName
     * @return Array	$arrEventLookupNames
     */
    function getSearchEventLookupNames($eventName) {
        $this->db->select('events.id,events.name');
        //$this->db->where('category', $category);
        $this->db->like('name', $eventName);
        $this->db->join('kol_events', 'kol_events.event_id=events.id', 'inner');
        $this->db->join('kols', 'kol_events.kol_id=kols.id', 'inner');
        $this->db->where('kols.status', COMPLETED);
        $this->db->group_by('events.id');
        $arrResultSet = $this->db->get('events');
        $arrEventLookupNames = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrEventLookupNames[$arrRow['id']] = $arrRow['name'];
        }

        return $arrEventLookupNames;
    }

    /**
     * Searches for the Role name and Returns the list of Role names matched
     *
     * @param String $type
     * @param $roleName
     * @return Array	$arrRoleNames
     */
    function getRoleNames($type, $roleName) {
        $this->db->select('role');
        $this->db->where('type', $type);
        $this->db->like('role', $roleName);
        $this->db->distinct();
        $arrResultSet = $this->db->get('kol_events');

        $arrRoleNames = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrRoleNames[] = $arrRow['role'];
        }

        return $arrRoleNames;
    }

    /**
     * Searches for the Role name and Returns the list of Role names matched
     *
     * @param String $type
     * @param $roleName
     * @return Array	$arrRoleNames
     */
    function getSearchRoleNames($roleName) {
        $this->db->select('role');
        $this->db->like('role', $roleName);
        $arrResultSet = $this->db->get('kol_events');

        $arrRoleNames = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrRoleNames[] = $arrRow['role'];
        }

        return $arrRoleNames;
    }

    /**
     * Searches for the Organizer name and Returns the list of Organizer names matched
     *
     *
     * @param $orgName
     * @return Array	$arrRoleNames
     */
    function getOrganizerNames($orgName) {
        $this->db->select('organizer');
        $this->db->like('organizer', $orgName);
        $arrResultSet = $this->db->get('kol_events');

        $arrRoleNames = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrRoleNames[] = $arrRow['organizer'];
        }

        return $arrRoleNames;
    }

    /**
     * Returns all the EventName from the lookuptable
     * @return array	-
     */
    function getAllEventLookupNames() {
        $arrAllEventNames = array();

        $arrEventNamesResult = $this->db->get('events');
        foreach ($arrEventNamesResult->result_array() as $arrEventName) {
            $arrAllEventNames[$arrEventName['id']] = $arrEventName['name'];
        }
        return $arrAllEventNames;
    }

    /*
     * Returns the EventLookupName of the  EventLookup ID
     */

    function getEventLookupName($id) {

        $eventName = '';
        $this->db->select('name');
        $this->db->where('id', $id);
        $eventNameRusult = $this->db->get('events');
        foreach ($eventNameRusult->result_array() as $row) {
            $eventName = $row['name'];
        }
        return $eventName;
    }

    //-------------End of Event DAO functions-------------------------------
    //-------------Start of Education & Training DAO functions-------------------------------
    /**
     * Saves the Education Detail to DB
     *
     * @return Last Insert Id/false
     */
    function saveEducationDetail($educationDetails) {
    	pr($educationDetails);
        if ($this->db->insert('kol_educations', $educationDetails)) {
        	return $this->db->insert_id();
        } else {
            return false;
        }
    }

    /**
     * List all Education Details Data
     *
     * @return true/false
     */
    function listEducationDetails($type, $kolId = null) {
        $clientId = $this->session->userdata('client_id');
        $arrEducationDetails = array();
        //Get the Events of KolId
        if ($kolId != null) {
            $this->db->where('kol_id', $kolId);
            if ($type != 'all') {
                $this->db->where('type', $type);
            }else{
                $this->db->where('type !=', 'honors_awards');
            }
            //if ($type != 'honors_awards') {
                $this->db->select(array('kol_educations.*', 'institutions.name','client_users.is_analyst','client_users.first_name','client_users.last_name'));
                $this->db->join('institutions', 'institutions.id = kol_educations.institute_id', 'left');
                $this->db->join('client_users', 'client_users.id = kol_educations.created_by', 'left');
            //}
        }
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where("(kol_educations.client_id=$clientId or kol_educations.client_id=" . INTERNAL_CLIENT_ID . ")");
        }
        $this->db->order_by('kol_educations.start_date','desc');
       
        if ($arrEducationDetailsResult = $this->db->get('kol_educations')) {
            foreach ($arrEducationDetailsResult->result_array() as $arrEducation) {
                if ($type != 'honors_awards') {
                    $arrEducation['institute_id'] = $arrEducation['name'];
                }
                if ($arrEducation['url1'] != '') {
                    $arrEducation['url1'] = '<a href=\'' . $arrEducation['url1'] . '\' target="_new">URL1</a>';
                }
                if ($arrEducation['url2'] != '') {
                    $arrEducation['url2'] = '<a href=\'' . $arrEducation['url2'] . '\' target="_new">URL2</a>';
                }
                $arrEducation['eAllowed'] = $this->common_helpers->isActionAllowed('kol_details', 'edit', $arrEducation); 
                $arrEducationDetails[] = $arrEducation;
            }
            return $arrEducationDetails;
        } else {
            return false;
        }
    }

    /**
     * Updates the Education Detail Data
     *
     * @return true/false
     */
    function updateEducationDetail($educationDetails) {
        $result = array();
        $this->db->where('id', $educationDetails['id']);
        if ($this->db->update('kol_educations', $educationDetails)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Delete the Education Detail Data By Id
     *
     */
    function deleteEducationDetailById($id) {
        $this->db->where('id', $id);
        if ($query = $this->db->delete('kol_educations')) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Returns the list of Institute Names, based on the Education Type
     *
     * @param $educationType
     * @param $instituteName
     * @return Array	$arrInstituteNames	Ex: arry('NIIT', 'JetKing');
     */
    function getEducationInstitutes($educationType, $instituteName) {
        $this->db->select('institute_name');
        $this->db->where('type', $educationType);
        $this->db->like('institute_name', $instituteName);
        $arrResultSet = $this->db->get('kol_educations');

        $arrInstituteNames = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrInstituteNames[] = $arrRow['institute_name'];
        }

        return $arrInstituteNames;
    }

    /**
     * Returns the list of Degree Names, based on the Education Type
     *
     * @param $educationType
     * @param $degreeName
     * @return Array	$arrDegreeNames
     */
    function getEducationDegrees($educationType, $degreeName) {
        $this->db->select('degree');
        $this->db->where('type', $educationType);
        $this->db->like('degree', $degreeName);
        $arrResultSet = $this->db->get('kol_educations');

        $arrDegreeNames = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrDegreeNames[] = $arrRow['degree'];
        }

        return $arrDegreeNames;
    }

    /**
     * Returns the list of Specialty Names, based on the Education Type
     *
     * @param $educationType
     * @param $specialtyName
     * @return Array	$arrSpecialtyNames
     */
    function getEducationSpecialtys($educationType, $specialtyName) {
        $this->db->select('specialty');
        $this->db->where('type', $educationType);
        $this->db->like('specialty', $specialtyName);
        $arrResultSet = $this->db->get('kol_educations');

        $arrSpecialtyNames = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrSpecialtyNames[] = $arrRow['specialty'];
        }

        return $arrSpecialtyNames;
    }

    /**
     * Returns the Institute Id
     *
     * @param String $name
     * @return Array $arrInstituteId
     */
    function getInstituteId($name = null) {
        if ($name != null) {
            $this->db->select('id');
            $this->db->where('name', $name);
            $arrResultSet = $this->db->get('institutions');

            if ($arrResultSet->num_rows() == 0) {
                return false;
            }
            $arrInstituteId = array();
            foreach ($arrResultSet->result_array() as $arrRow) {
                return $arrRow['id'];
            }

            return $arrInstituteId;
        } else
            return false;
    }

    /**
     * Returns the Institute Id if Exist else save the institute and returns its id
     * @author Ambarish
     * @since 2.2
     * @Created-on 03-may-11
     *
     * @param String $name
     * @return Array $arrInstituteId
     */
    function getInstituteIdElseSave($institutionDetails) {
        if ($institutionDetails['name'] != null || !empty($institutionDetails['name'])) {
            $this->db->select('id');
            $this->db->where('name', $institutionDetails['name']);
            $arrResultSet = $this->db->get('institutions');

            if ($arrResultSet->num_rows() == 0) {
                $institutionDetails['created_by'] = $this->session->userdata('user_id');
                $institutionDetails['created_on'] = date("Y-m-d H:i:s");
                $this->db->insert('institutions', $institutionDetails);
                return $this->db->insert_id();
            } else {
                foreach ($arrResultSet->result_array() as $arrRow) {
                    return $arrRow['id'];
                }
            }
        } else
            return false;
    }

    /**
     * Returns the Event Id if Exist else save the institute and returns its id
     * @author Vinayak
     * @since 2.2
     * @Created-on 03-may-11
     *
     * @param String $name
     * @return Array $arrEventId
     */
    function getEventIdElseSave($eventDetails) {
        if ($eventDetails['name'] != null) {
            $this->db->select('id');
            $this->db->where('name', $eventDetails['name']);
            $arrResultSet = $this->db->get('events');
            if ($arrResultSet->num_rows() == 0) {
                $eventDetails['created_by'] = $this->session->userdata('user_id');
                $eventDetails['created_on'] = date("Y-m-d H:i:s");
                $this->db->insert('events', $eventDetails);
                return $this->db->insert_id();
            }
            $arrEventId = array();
            foreach ($arrResultSet->result_array() as $arrRow) {
                return $arrRow['id'];
            }
        } else
            return false;
    }

    /**
     * Searches for the InstituteName and Returns the list of Institution Names matched
     *
     * @param $instituteName
     * @return Array	$arrInstituteNames	Ex: arry('NIIT', 'JetKing');
     */
    function getInstituteNames($instituteName) {
        $this->db->select('institutions.id,name');
        $this->db->like('name', $instituteName, 'after');
        $this->db->limit(10);
        $this->db->distinct();
        $this->db->join('kol_educations', 'kol_educations.institute_id=institutions.id', 'inner');
        $arrResultSet = $this->db->get('institutions');

        $arrInstituteNames = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrInstituteNames[$arrRow['id']] = $arrRow['name'];
        }

        return $arrInstituteNames;
    }

    /**
     * Returns all the InstituteNames from the lookuptable
     * @return array	- ID, and InstituteNames
     */
    function getAllInstituteNames() {
        $arrAllInstituteNames = array();

        $arrInstituteNamesResult = $this->db->get('institutions');
        foreach ($arrInstituteNamesResult->result_array() as $arrInstituteName) {
            $arrAllInstituteNames[$arrInstituteName['id']] = $arrInstituteName['name'];
        }
        return $arrAllInstituteNames;
    }

    /**
     * Saves the Institution Detail to DB
     *
     * @return Last Insert Id/false
     */
    function saveInstitution($institutionDetails) {

        $instituteName = '';
        $instituteName = $institutionDetails['name'];
        $this->db->where('name', $instituteName);
        if ($result = $this->db->get('institutions')) {
            if ($result->num_rows() != 0) {
                return false;
            } else {
                if ($this->db->insert('institutions', $institutionDetails)) {
                    return $this->db->insert_id();
                } else {
                    return false;
                }
            }
        }
    }

    /*
     * Returns the name of the  Institute ID
     */

    function getInstituteName($id) {

        $instituteName = '';
        $this->db->select('name');
        $this->db->where('id', $id);
        $instituteName = $this->db->get('institutions');
        foreach ($instituteName->result_array() as $row) {
            $instituteName = $row['name'];
        }
        return $instituteName;
    }

    //-------------End of Education & Training DAO functions-------------------------------
    //-------------Start of Press DAO functions-------------------------------
    /**
     * Saves the Press Data to DB
     *
     * @return true/false
     */
    function savePress($pressDetails) {
        if ($this->db->insert('kol_press', $pressDetails)) {
            return true;
        } else {
            return false;
        }
    }

    //-------------End of Press DAO functions-------------------------------
    //-------------Start of Social Media DAO functions-------------------------------
    /**
     * Saves the Social Media Data to DB
     *
     * @return true/false
     */
    function saveSocialMedia($socialMediaDetails) {
        $this->db->where('id', $socialMediaDetails['id']);
        if ($this->db->update('kols', $socialMediaDetails)) {
            return true;
        } else {
            return false;
        }
    }

    //-------------End of Social Media DAO functions-------------------------------
    //-------------Start of Contact DAO functions-------------------------------
    /**
     * Saves the Contact Details Data to DB
     *
     * @return true/false
     */
    function saveContact($contactDetails) {
        if ($this->db->insert('kol_additional_contacts', $contactDetails)) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    /**
     * List all Contacts Data
     *
     * @return true/false
     */
    function listContacts($kolId = null) {
        $arrContactDetails = array();
        if ($kolId != null) {
            $this->db->where('kol_id', $kolId);
        }

        if ($arrContactDetailsResult = $this->db->get('kol_additional_contacts')) {
            if ($arrContactDetailsResult->num_rows() == 0) {
                return false;
            }
            foreach ($arrContactDetailsResult->result_array() as $row) {
                $arrContactDetails[] = $row;
            }
            return $arrContactDetails;
        } else {
            return false;
        }
    }

    /**
     * Edit the Contact Details
     *
     * @return true/false
     */
    function editContactById($id) {
        $this->db->where('id', $id);
        if ($arrContactDetails = $this->db->get('kol_additional_contacts')) {
            return $arrContactDetails;
        } else {
            return false;
        }
    }

    /**
     * Updates the Contact Detail Data
     *
     * @return true/false
     */
    function updateContact($contactDetails) {
        $this->db->where('id', $contactDetails['id']);
        if ($this->db->update('kol_additional_contacts', $contactDetails)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Delete the Contact Detail By Id
     *
     */
    function deleteContactById($id) {

        $this->db->where('id', $id);
        if ($query = $this->db->delete('kol_additional_contacts')) {
            return true;
        } else
            return false;
    }

    //-------------End of Contact DAO functions-------------------------------
    //-------------Start of Organization DAO functions-------------------------------
    /**
     * Saves the Organization Detail to DB
     *
     * @return Last Insert Id/false
     */
    function saveOrganization($organizationDetails) {
        if ($this->db->insert('organizations', $organizationDetails)) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    /**
     * List all Organization Details Data
     *
     * @return true/false
     */
    function listOrganizations() {
        if ($arrOrganizationDetails = $this->db->get('organizations')) {
            return $arrOrganizationDetails;
        } else {
            return false;
        }
    }

    /**
     * Returns all the matching Organization Names
     *
     */
    function getOrganizationNames($organizationName) {
        $this->db->select('id,name');
        $this->db->like('name', $organizationName);
        //$this->db->where('status',COMPLETED);
        $this->db->where('status_otsuka', "ACTV");
        $arrResultSet = $this->db->get('organizations');

        $arrOrganizationNames = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrOrganizationNames[$arrRow['id']] = $arrRow['name'];
        }

        return $arrOrganizationNames;
    }

    function getOrganizationNamesWithStateCity($organizationName,$restrictByRegion=0) {
    	$client_id = $this->session->userdata('client_id');
        $this->db->select('id,name,regions.region as state,cities.city as city');
        $this->db->join('regions', 'regions.regionID = organizations.state_id', 'left');
        $this->db->join('cities', 'cities.cityID = organizations.city_id', 'left');
        if($restrictByRegion){
	        if(INTERNAL_CLIENT_ID != $client_id && $this->session->userdata('user_role_id') != ROLE_ADMIN){
		        if($this->session->userdata('user_role_id') == ROLE_USER || $this->session->userdata('user_role_id') == ROLE_MANAGER){
		            $group_names = explode(',', $this->session->userdata('group_names'));
		            $this->db->join ( 'countries', 'countries.CountryId=organizations.country_id', 'left' );
		            $this->db->where_in( 'countries.GlobalRegion', $group_names);
		        }
	        }
        }
        $this->db->like('name', $organizationName);
        
        //$this->db->where('status',COMPLETED);
       // $this->db->where('status_otsuka', "ACTV");
        $arrResultSet = $this->db->get('organizations');

        $arrOrganizationNames = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
//			$arrOrganizationNames[$arrRow['id']] = $arrRow['name'];
//                        $arrOrganizationNames[] = $arrRow['state'];
            $arrOrganizationNames[] = $arrRow;
        }
        return $arrOrganizationNames;
    }

    //-------------End of Organization DAO functions-------------------------------

    /*
     * Returns  the count of Afilliations
     *
     *
     */
    function countAfiliations($kolId, $type = null) {
        $count = '';
        if ($kolId != null)
            $this->db->where('kol_id', $kolId);
        if ($type != null)
            $this->db->where('type', $type);
        if ($count = $this->db->count_all_results('kol_memberships')) {
;
            return $count;
        } else {
            return $count;
        }
    }

    /*
     * Returns  the count of Events
     *
     */

    function countEvents($kolId) {
        $count = '';
        $this->db->where('kol_id', $kolId);
        if ($count = $this->db->count_all_results('kol_events')) {
            return $count;
        } else {
            return $count;
        }
    }

    /*
     * Returns  the count of Events
     *
     */

    function countPublications($kolId) {
        $count = '';
        $this->db->where('kol_id', $kolId);
        $this->db->where('is_deleted', 0);
        $this->db->where('is_verified', 1);
        if ($count = $this->db->count_all_results('kol_publications')) {
            return $count;
        } else {
            return $count;
        }
    }

    /*
     * Returns  the count of Events
     *
     */

    function countTrials($kolId) {
        $count = '';
        $this->db->where('kol_id', $kolId);
        $this->db->where('is_verified', 1);
        if ($count = $this->db->count_all_results('kol_clinical_trials')) {
            return $count;
        } else {
            return $count;
        }
    }

    /**
     *  GET kol details of the Specified Id
     * @param
     * @return array - $arrKolDetail - Returns
     */
    function getKolDetailsById($kolId) {
        $arrKolDetails = array();
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $this->db->where('kols.id', $kolId);
        $this->db->select(array('kols.*', 'countries.Country', 'regions.Region', 'cities.City',  'titles.title as kol_title','specialties.specialty as specialty_name'));
        $this->db->join('countries', 'CountryId = country_id', 'left');
        $this->db->join('regions', 'RegionId = state_id', 'left');
        $this->db->join('cities', 'cityId = city_id', 'left');
        $this->db->join('specialties', 'specialties.id = kols.specialty', 'left');
//         $this->db->join('kol_locations', 'kols.id = kol_locations.kol_id', 'left');
        $this->db->join('titles', 'kols.title = titles.id', 'left');
        $arrKolDetailsResult = $this->db->get('kols');
        //echo $this->db->last_query(); exit;
        foreach ($arrKolDetailsResult->result_array() as $row) {
            if (!empty($row['org_id']))
                $row['org_id'] = $this->getOrgId($row['org_id']);
//             else
//                 $row['org_id'] = $row['private_practice'];

            if ($row['salutation'] != 0) {
                $row['salutation'] = $arrSalutations[$row['salutation']];
            } else
                $row['salutation'] = "";
           // $row['suffix'] = $this->getSuffixById($row['suffix']);
           $row['title']=$row['kol_title'];
            $arrKolDetails[] = $row;
        }       
        return $arrKolDetails;
    }
    
    /**
     *  GET Org details of the Specified Id
     * @param
     * @return array - $arrOrgDetails - Returns
     */
    function getOrgDetailsById($kolId) {
        $arrOrgDetails = array();
        $arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
        $this->db->where('organizations.id', $kolId);
        $this->db->select(array('organizations.*', 'countries.Country', 'regions.Region', 'cities.City'));
        $this->db->join('countries', 'CountryId = country_id', 'left');
        $this->db->join('regions', 'RegionId = state_id', 'left');
        $this->db->join('cities', 'cityId = city_id', 'left');
        $arrOrgDetailsResult = $this->db->get('organizations');
        //echo $this->db->last_query(); exit;
        foreach ($arrOrgDetailsResult->result_array() as $row) {
            $arrOrgDetails[] = $row;
        }
        return $arrOrgDetails;
    }

    /**
     * Get the Education Detail of the Specified KolId
     *
     * @return Array/false
     */
    function getEducationDetailById($kolId) {
        $arrEducationDetails = array();
        $clientId = $this->session->userdata('client_id');
        $this->db->where('kol_id', $kolId);
        $this->db->select(array('kol_educations.*', 'institutions.name'));
        $this->db->join('institutions', 'institutions.id = kol_educations.institute_id', 'left');

        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where("(kol_educations.client_id=$clientId or kol_educations.client_id=" . INTERNAL_CLIENT_ID . ")");
        }
        $arrEducationDetailsResult = $this->db->get('kol_educations');
        foreach ($arrEducationDetailsResult->result_array() as $arrRow) {
            $arrEducationDetails[] = $arrRow;
        }
        return $arrEducationDetails;
    }

    /**
     * List all Education Details Data
     *
     * @return true/false
     */
    function listAllEducationDetails($kolId = null) {

        $clientId = $this->session->userdata('client_id');
        $arrEducationDetails = array();
        //Get the Events of KolId
        if ($kolId != null) {
            $this->db->where('kol_id', $kolId);

            $this->db->select(array('kol_educations.*', 'institutions.name'));
            $this->db->join('institutions', 'institutions.id = kol_educations.institute_id', 'left');
        }

        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where("(kol_educations.client_id=$clientId or kol_educations.client_id=" . INTERNAL_CLIENT_ID . ")");
        }

        if ($arrEducationDetailsResult = $this->db->get('kol_educations')) {
            foreach ($arrEducationDetailsResult->result_array() as $arrEducation) {
                $arrEducation['institute_id'] = $arrEducation['name'];
                if ($arrEducation['url1'] != '') {
                    $arrEducation['url1'] = '<a href=\'' . $arrEducation['url1'] . '\' target="_new">URL1</a>';
                }
                if ($arrEducation['url2'] != '') {
                    $arrEducation['url2'] = '<a href=\'' . $arrEducation['url2'] . '\' target="_new">URL2</a>';
                }
                $arrEducationDetails[] = $arrEducation;
            }
            return $arrEducationDetails;
        } else {
            return false;
        }
    }

    /**
     * List all Membership Details Data
     *
     * @return true/false
     */
    function listAllMembershipsDetails($kolId = null) {
        $arrMembershipDetails = array();
        $clientId = $this->session->userdata('client_id');
        $arrMembership = array();
        if ($kolId != null) {
            //Getting the data from 'kol_memberships' table and 'name' from 'institutions' table
            $this->db->select(array('kol_memberships.*', 'institutions.name'));
            $this->db->join('institutions', 'institutions.id = kol_memberships.institute_id', 'left');
            $this->db->where('kol_id', $kolId);


            //Getting the data from 'kol_memberships' table and 'engagement_type' from 'engagement_types' table
            $this->db->select(array('kol_memberships.*', 'engagement_types.engagement_type'));
            $this->db->join('engagement_types', 'engagement_types.id=engagement_id', 'left');
        }

        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where("(client_id=$clientId or client_id=" . INTERNAL_CLIENT_ID . ")");
        }

        $this->db->order_by('type', 'asc');
        $this->db->order_by('engagement_type', 'asc');

        if ($arrMembershipDetailResult = $this->db->get('kol_memberships')) {
            if ($arrMembershipDetailResult->num_rows() == 0) {
                return false;
            }

            foreach ($arrMembershipDetailResult->result_array() as $arrMembership) {
                //setting the institute name
                $arrMembership['institute_id'] = $arrMembership['name'];
                if ($arrMembership['url1'] != '') {
                    $arrMembership['url1ForExport'] = $arrMembership['url1'];
                    $arrMembership['url1'] = '<a href=\'' . $arrMembership['url1'] . '\' target="_new">URl1</a>';
                }if ($arrMembership['url2'] != '') {
                    $arrMembership['ur21ForExport'] = $arrMembership['url2'];
                    $arrMembership['url2'] = '<a href=\'' . $arrMembership['url2'] . '\' target="_new">URl2</a>';
                }
                //setting the engagement name
                $arrMembership['engagement_id'] = $arrMembership['engagement_type'];
                $arrMembershipDetails[] = $arrMembership;
            }
            return $arrMembershipDetails;
        } else {
            return false;
        }
    }

    /**
     * List all Events Data
     *
     * @return $arrEventsDetails/false
     */
    function listAllEvents($kolId = null, $limit = 0) {

        $arrEventsDetails = array();
        //Get the Events of KolId
        $clientId = $this->session->userdata('client_id');
        if ($kolId != null) {
            $this->db->where('kol_id', $kolId);

            $this->db->select(array('kol_events.*', 'event_sponsor_types.type as stype', 'event_organizer_types.type as otype', 'events.name', 'countries.Country', 'regions.Region', 'cities.City', 'conf_session_types.session_type'));
            $this->db->join('events', 'events.id = event_id', 'left');
            $this->db->join('countries', 'CountryId = country_id', 'left');
            $this->db->join('regions', 'RegionId = state_id', 'left');
            $this->db->join('cities', 'cityId = city_id', 'left');
            $this->db->join('conf_session_types', 'conf_session_types.id = kol_events.session_type', 'left');
            $this->db->join('event_sponsor_types', 'kol_events.sponsor_type = event_sponsor_types.id', 'left');
            $this->db->join('event_organizer_types', 'kol_events.organizer_type = event_organizer_types.id', 'left');
        }

        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where("(kol_events.client_id=$clientId or kol_events.client_id=" . INTERNAL_CLIENT_ID . ")");
        }

        $this->db->order_by('conf_session_types.session_type', 'asc');
        $this->db->order_by('kol_events.end', 'desc');
        if ($limit == 20) {
            $this->db->limit('20');
        }
        if ($arrEventsDetailsResult = $this->db->get('kol_events')) {

            foreach ($arrEventsDetailsResult->result_array() as $arrEvent) {
                if ($arrEvent['type'] == 'conference') {
                    if ($arrEvent['event_type'] != '0') {
                        $arrEvent['event_type'] = $this->Event_helper->getConferenceEventTypeById($arrEvent['event_type']);
                    } else {
                        $arrEvent['event_type'] = '';
                    }
                }
                if ($arrEvent['type'] == 'online') {
                    if ($arrEvent['event_type'] != '0') {
                        $arrEvent['event_type'] = $this->Event_helper->getOnlineEventTypeById($arrEvent['event_type']);
                    } else {
                        $arrEvent['event_type'] = '';
                    }
                }

                $arrEvent['start'] = $this->convertDateToMM_DD_YYYY($arrEvent['start']);
                if ($arrEvent['start'] == '00/00/0000') {
                    $arrEvent['start'] = '';
                }
                $arrEvent['end'] = $this->convertDateToMM_DD_YYYY($arrEvent['end']);
                if ($arrEvent['end'] == '00/00/0000') {
                    $arrEvent['end'] = '';
                }
                if ($arrEvent['url1'] != '') {
                    $arrEvent['url1ForExport'] = $arrEvent['url1'];
                    $arrEvent['url1'] = '<a href=\'' . $arrEvent['url1'] . '\' target="_new">URl1</a>';
                }
                if ($arrEvent['url2'] != '') {
                    $arrEvent['url2ForExport'] = $arrEvent['url2'];
                    $arrEvent['url2'] = '<a href=\'' . $arrEvent['url2'] . '\' target="_new">URl2</a>';
                }
                $arrEventsDetails[] = $arrEvent;
            }

            return $arrEventsDetails;
        } else {
            return false;
        }
    }
	function getTitleById($id){
			$get = $this->db->get_where("titles",array("id"=>$id));
			if($get->num_rows()>0){
				return $get->row()->title;				
			}
			return false;			
	} 
    function getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, $doCount, $doGroupBy = false, $groupByCategory = null, $arrKolIds = null, $isFrmInfluenceMap = false, $arrQueryOptions = array(),$checkClientBasedVisibilityByClientId=0) {
    	$sizeOfKeywords = sizeof($arrKeywords);
        if ($sizeOfKeywords > 0 && empty($arrKeywords[0])) {
            $sizeOfKeywords = 0;
        }
        $currentController = $this->uri->segment(1);
        $currentControllerIpad = $this->uri->segment(2);

        $arrKols = array();
        $client_id = $this->session->userdata('client_id');
        $user_id = $this->session->userdata('user_id');
        
        /* $this->db->select("kols_client_visibility.kol_id");
        $this->db->where_in('kols_client_visibility.client_id', $client_id);
        $this->db->where_in('kols_client_visibility.is_visible', '1');
        $resultSet = $this->db->get("kols_client_visibility");
        foreach($resultSet->result_array() as $row){
        	$arrKolIds[] = $row['kol_id']; //Add it to the new array
        }
        $kolIdsInWhere =  implode(',',$arrKolIds); //Implode the array. */
        
        if ($doCount == false && $doGroupBy == false) {
        	
            //$this->db->select('kols.*,organizations.name,specialties.specialty as specs,countries.country');
            $this->db->select('c.is_analyst,c.is_analyst,concat(m.first_name," ",m.last_name) as modified_by, concat(c.first_name," ",c.last_name) as created_by, kols.opt_in_out_status,kols.id,kols.salutation,kols.first_name,kols.unique_id,kols.middle_name,kols.last_name,kols.gender,kols.profile_image,kols.primary_phone,kols.primary_email,kols.specialty,kols.org_id,organizations.name,specialties.specialty as specs,countries.country,regions.region as state,cities.City AS city,kol_locations.latitude as lat,kol_locations.longitude as lang,cities.city,kols.profile_type, kols.created_on, kols.modified_on,kols.created_by as created_by_id,kols.status', false);
            //$this->db->join('kol_activities_count', 'kol_activities_count.kol_id = kols.id', 'left');
            $this->db->join('client_users as c', 'c.id = kols.created_by', 'left');
            $this->db->join('client_users as m', 'm.id = kols.created_by', 'left');
            $this->db->join('kol_locations', 'kols.id = kol_locations.kol_id and kol_locations.is_primary=1', 'left');
            //$this->db->join('cities', 'cities.cityID = kols.city_id', 'left');
        }

        $this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
        $this->db->join('titles', 'titles.id = kols.title', 'left');
        $this->db->join('specialties', 'specialties.id = kols.specialty', 'left');
        $this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
        $this->db->join('regions', 'regions.regionID = kols.state_id', 'left');
        $this->db->join('cities', 'cities.CityId = kols.city_id', 'left');
        if(KOL_CONSENT){
            $this->db->select('opt_inout_statuses.name as opt_status_name');
            $this->db->join('opt_inout_statuses', 'opt_inout_statuses.id = kols.opt_in_out_status', 'left');
        }

        if ($arrFilterFields != null && $arrFilterFields['education'] != null && isset($arrFilterFields['education']) && sizeof($arrFilterFields['education']) > 0 && !($doGroupBy == true && $groupByCategory == 'education')) {
            $this->db->distinct();
            $this->db->join('kol_educations', 'kol_educations.kol_id = kols.id', 'left');
            $this->db->join('institutions', 'kol_educations.institute_id = institutions.id', 'left');
            $this->db->where_in('institutions.id', $arrFilterFields['education']);
            $this->db->where('kol_educations.type', 'education');
        }
        if ($arrFilterFields != null && $arrFilterFields['event_id'] != null && isset($arrFilterFields['event_id']) && sizeof($arrFilterFields['event_id']) > 0 && !($doGroupBy == true && $groupByCategory == 'event')) {
            $this->db->distinct();
            $this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');
            $this->db->join('events', 'kol_events.event_id = events.id', 'left');
            $this->db->where_in('kol_events.event_id', $arrFilterFields['event_id']);
        }
        if ($arrFilterFields != null && $arrFilterFields['list_id'] != null && isset($arrFilterFields['list_id']) && sizeof($arrFilterFields['list_id']) > 0 && !($doGroupBy == true && $groupByCategory == 'list')) {
            $this->db->distinct();
            $this->db->join('list_kols', 'list_kols.kol_id=kols.id', 'left');
            $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
            //$this->db->where_in('list_names.list_name',$arrFilterFields['list_id']);
            $this->db->where_in('list_names.id', $arrFilterFields['list_id']);
        }
        if ($arrFilterFields != null && $arrFilterFields['type'] != null && isset($arrFilterFields['type']) && sizeof($arrFilterFields['type']) > 0 && !($doGroupBy == true && $groupByCategory == 'type')) {
            $this->db->distinct();
            $this->db->join('organization_types', 'organization_types.id=organizations.type_id', 'left');
            //$this->db->where_in('list_names.list_name',$arrFilterFields['list_id']);
            $this->db->where_in('organization_types.id', $arrFilterFields['type']);
//                      
        }
        if ($arrFilterFields != null && $arrFilterFields['title'] != null && isset($arrFilterFields['title']) && $arrFilterFields['title'] != '' && sizeof($arrFilterFields['title']) > 0 && !($doGroupBy == true && $groupByCategory == 'title')) {
            $this->db->distinct();
            //$this->db->where_in('kols.title', $arrFilterFields['title']);
            $this->db->where_in('titles.title', $arrFilterFields['title']);
//                      
        }
        if ($arrFilterFields != null && $arrFilterFields['region'] != null && isset($arrFilterFields['region']) && sizeof($arrFilterFields['region']) > 0 && !($doGroupBy == true && $groupByCategory == 'region')) {
            $this->db->distinct();
            $this->db->where_in('countries.GlobalRegion', $arrFilterFields['region']);
//                      
        }
        if(KOL_CONSENT){
            if ($arrFilterFields != null && $arrFilterFields['opt_inout'] != null && isset($arrFilterFields['opt_inout']) && sizeof($arrFilterFields['opt_inout']) > 0 && !($doGroupBy == true && $groupByCategory == 'opt_inout')) {
                $this->db->distinct();
                $this->db->where_in('opt_inout_statuses.id', $arrFilterFields['opt_inout']);
                //
            }
        }

        $keywordSearchByAutoComplete = 0;
        $keywordSearchByAutoComplete = $this->session->userdata('keywordSearchByAutoComplete');
        switch ($sizeOfKeywords) {
            case 1:
                $name = trim($arrKeywords[0]);
                $where = '(kols.first_name LIKE "%' . $name . '%" OR kols.last_name LIKE "%' . $name . '" OR kols.middle_name LIKE "%' . $name . '%")';
                if ($keywordSearchByAutoComplete) {
                    $where = '(kols.first_name = "' . $name . '")';
                }
                $this->db->where($where);
                break;
            case 2:
                $name1 = trim($arrKeywords[0]);
                $name2 = trim($arrKeywords[1]);
                $where = "(kols.first_name IN('" . $name1 . "','" . $name2 . "') OR kols.last_name IN ('" . $name1 . "','" . $name2 . "') OR kols.middle_name IN ('" . $name1 . "','" . $name2 . "'))";
                if ($keywordSearchByAutoComplete) {
                    $where = '((kols.first_name = "' . $name1 . '" AND kols.last_name="' . $name2 . '") or (kols.first_name = "' . $name1 . '" AND kols.middle_name="' . $name2 . '"))';
                }
                $this->db->where($where);
                break;
            case 3:
                $name1 = trim($arrKeywords[0]);
                $name2 = trim($arrKeywords[1]);
                $name3 = trim($arrKeywords[2]);
                $where = "(kols.first_name IN('" . $name1 . "','" . $name2 . "','" . $name3 . "') OR kols.last_name IN ('" . $name1 . "','" . $name2 . "','" . $name3 . "') OR kols.middle_name IN ('" . $name1 . "','" . $name2 . "','" . $name3 . "'))";
                if ($keywordSearchByAutoComplete) {
                    $where = '(kols.first_name = "' . $name1 . '" AND kols.middle_name="' . $name2 . '" AND kols.last_name="' . $name3 . '")';
                }
                $this->db->where($where);
                break;
        }
        /*
          if(sizeof($arrKeywords)==1){
          $name=trim($arrKeywords[0]);
          $where='(kols.first_name LIKE "%'.$name.'%" OR kols.last_name LIKE "%'.$name.'" OR kols.middle_name LIKE "%'.$name.'%")';
          if($keywordSearchByAutoComplete){
          $where = '(kols.first_name = "'.$name.'")';
          }
          }else if(sizeof($arrKeywords)==2){
          $name1=trim($arrKeywords[0]);
          $name2=trim($arrKeywords[1]);
          $where="(kols.first_name IN('".$name1."','".$name2."') OR kols.last_name IN ('".$name1."','".$name2."') OR kols.middle_name IN ('".$name1."','".$name2."'))";
          if($keywordSearchByAutoComplete){
          $where = '((kols.first_name = "'.$name1.'" AND kols.last_name="'.$name2.'") or (kols.first_name = "'.$name1.'" AND kols.middle_name="'.$name2.'"))';
          }
          }else if(sizeof($arrKeywords)==3){
          $name1=trim($arrKeywords[0]);
          $name2=trim($arrKeywords[1]);
          $name3=trim($arrKeywords[2]);
          $where="(kols.first_name IN('".$name1."','".$name2."','".$name3."') OR kols.last_name IN ('".$name1."','".$name2."','".$name3."') OR kols.middle_name IN ('".$name1."','".$name2."','".$name3."'))";
          if($keywordSearchByAutoComplete){
          $where = '(kols.first_name = "'.$name1.'" AND kols.middle_name="'.$name2.'" AND kols.last_name="'.$name3.'")';
          }
          }
          $this->db->where($where);
         */
        //$this->db->like('first_name', $name, 'after');
        //$this->db->or_like('middle_name', $name, 'after');
        //$this->db->or_like('last_name', $name, 'after');
        //pr($arrFilterFields);

        if ($arrFilterFields != null && $arrFilterFields['country'] != '' && isset($arrFilterFields['country']) && sizeof($arrFilterFields['country']) > 0 && !($doGroupBy == true && $groupByCategory == 'country'))
            $this->db->where_in('countries.countryId', $arrFilterFields['country']);
        if ($arrFilterFields != null && $arrFilterFields['state'] != '' && isset($arrFilterFields['state']) && sizeof($arrFilterFields['state']) > 0 && !($doGroupBy == true && $groupByCategory == 'state')) {
            //$this->db->where_in('regions.region', $arrFilterFields['state']);
            $this->db->where_in('regions.regionID', $arrFilterFields['state']);
        }
        if ($arrFilterFields != null && $arrFilterFields['city'] != '' && isset($arrFilterFields['city']) && sizeof($arrFilterFields['city']) > 0 && !($doGroupBy == true && $groupByCategory == 'city')) {
            $this->db->where_in('cities.CityId', $arrFilterFields['city']);
        }
        if ($arrFilterFields != null && $arrFilterFields['organization'] != '' && isset($arrFilterFields['organization']) && sizeof($arrFilterFields['organization']) > 0 && !($doGroupBy == true && $groupByCategory == 'organization')) {
            //$this->db->where_in('organizations.name', $arrFilterFields['organization']);
            //$arrOrgIds	= array();
            //foreach($arrFilterFields['organization'] as $orgId=>$orgName){
            //	$arrOrgIds[]	= $orgId;
            //}
            //pr($arrFilterFields['organization']);
           // $this->db->where('organizations.status', COMPLETED);
            $this->db->where_in('organizations.id', $arrFilterFields['organization']);
        }
        if ($arrFilterFields != null && $arrFilterFields['organization'] != '' && isset($arrFilterFields['organization']) && sizeof($arrFilterFields['organization']) > 0 && !($doGroupBy == true && $groupByCategory == 'organization')) {
            //$this->db->where_in('organizations.name', $arrFilterFields['organization']);
            //$arrOrgIds	= array();
            //foreach($arrFilterFields['organization'] as $orgId=>$orgName){
            //	$arrOrgIds[]	= $orgId;
            //}
            //pr($arrFilterFields['organization']);
           // $this->db->where('organizations.status', COMPLETED);
            $this->db->where_in('organizations.id', $arrFilterFields['organization']);
        }
        if ($arrFilterFields != null && $arrFilterFields['specialty'] != '' && isset($arrFilterFields['specialty']) && sizeof($arrFilterFields['specialty']) > 0 && !($doGroupBy == true && $groupByCategory == 'specialty')) {
            $this->db->where_in('specialties.id', $arrFilterFields['specialty']);
        }
        if ($arrFilterFields != null && $arrFilterFields['kol_id'] != '') {
            $this->db->where_in('kols.id', $arrFilterFields['kol_id']);
        }
        if ($arrFilterFields != null && $arrFilterFields['profile_type'] != '' && $arrFilterFields['profile_type'] != "undefined") {
            $this->db->where('kols.profile_type', $arrFilterFields['profile_type']);
        }
        if ($arrKolIds != null && isset($arrKolIds) && sizeof($arrKolIds) > 0) {
            $this->db->where_in('kols.id', $arrKolIds);
        }
        if ($arrFilterFields != null && $arrFilterFields['global_region'] != '' && isset($arrFilterFields['global_region']) && sizeof($arrFilterFields['global_region']) > 0 && !($doGroupBy == true && $groupByCategory == 'global_region'))
            $this->db->where_in('countries.GlobalRegion', $arrFilterFields['global_region']);
        if(KOL_CONSENT){
            if ($arrFilterFields != null && $arrFilterFields['opt_inout'] != '' && isset($arrFilterFields['opt_inout']) && sizeof($arrFilterFields['opt_inout']) > 0 && !($doGroupBy == true && $groupByCategory == 'opt_inout'))
                $this->db->where_in('opt_inout_statuses.id', $arrFilterFields['opt_inout']);
        }
        if ($doCount) {
            /*
              $this->db->distinct();
              $count=$this->db->count_all_results('kols');
             */
            if ($currentController == 'maps' or $currentControllerIpad == 'maps') {
                $this->db->where_in('kols.status', array(COMPLETED));
            } else {
                //$this->db->where_in('kols.status',array(COMPLETED,PRENEW));
                $this->db->where('kols.customer_status', "ACTV");
            }

            $this->db->select('COUNT(DISTINCT kols.id) AS count');
            if (isset($arrFilterFields) && sizeof($arrFilterFields['viewType']) > 0) {
                $this->db->where_in('kols.id', $arrFilterFields['viewType']);
            }
            if ($arrFilterFields['profile_type'] != "" && $arrFilterFields['profile_type'] != "undefined") {
                $this->db->where('kols.profile_type', $arrFilterFields['profile_type']);
            }
        	$loggedInuserClientId	= $client_id;
            if($checkClientBasedVisibilityByClientId>0){
            	$loggedInuserClientId	= $checkClientBasedVisibilityByClientId;
            }
            if($loggedInuserClientId !== INTERNAL_CLIENT_ID){
            	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
            	$this->db->where('kols_client_visibility.client_id', $loggedInuserClientId);
            }
            $arrKolDetailsResult = $this->db->get('kols');
            $resultRow = $arrKolDetailsResult->row();
            $count = $resultRow->count;
//            echo $this->db->last_query();
//            exit;

            return $count;
        } else {
            if ($doGroupBy) {
                if ($groupByCategory == 'country') {
                    $this->db->select('kols.country_id,countries.country,COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('country_id');
                    //$this->db->where('country IS NOT NULL');
                }
                if ($groupByCategory == 'state') {
                    $this->db->select('kols.state_id,regions.region as state,COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('state_id');
                    //$this->db->where('country IS NOT NULL');
                }
                if ($groupByCategory == 'city') {
                    $this->db->select('kols.city_id,cities.City as city,COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('city_id');
                    //$this->db->where('country IS NOT NULL');
                }
                if ($groupByCategory == 'specialty') {
                    $this->db->select('kols.specialty,specialties.specialty as specs,COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('specialty');
                    //$this->db->where('specialties.specialty IS NOT NULL');
                }
                if ($groupByCategory == 'organization') {
                    $this->db->select('organizations.id as org_id,organizations.name,COUNT(DISTINCT kols.id) as count');
                    //$this->db->where('organizations.status', COMPLETED);
                    $this->db->group_by('organizations.id');
                    //$this->db->where('name IS NOT NULL');
                }
                if ($groupByCategory == 'education') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count,institutions.name as institute_name,kol_educations.institute_id');
                    $this->db->join('kol_educations', 'kol_educations.kol_id = kols.id', 'left');
                    $this->db->join('institutions', 'kol_educations.institute_id = institutions.id', 'left');
                    $this->db->where('kol_educations.type', 'education');
                    //$this->db->where('institutions.name IS NOT NULL');
                    $this->db->where('institutions.id > 0');
                    $this->db->group_by('kol_educations.institute_id');
                }
                if ($groupByCategory == 'event') {
                    //	$this->db->select('COUNT(DISTINCT kols.id) as count,events.name as event_name');
                    $this->db->select('COUNT(DISTINCT kols.id) as count,events.name as event_name,kol_events.event_id as event_id');
                    $this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');
                    $this->db->join('events', 'kol_events.event_id = events.id', 'left');
                    //$this->db->where('events.name IS NOT NULL');
                    $this->db->where('events.id > 0');
                    $this->db->group_by('kol_events.event_id');
                }
                if ($groupByCategory == 'list') {
                    $this->db->select('list_kols.list_name_id,list_names.list_name,list_categories.category,COUNT(DISTINCT kols.id) AS count');
                    $this->db->join('list_kols', 'list_kols.kol_id=kols.id', 'left');
                    $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
                    $this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
                    $this->db->where('list_categories.client_id', $client_id);
                    $where = "(list_categories.user_id=$user_id OR list_categories.is_public=1)";
                    $this->db->where($where);
                    $this->db->group_by('list_kols.list_name_id');
                }
                if ($groupByCategory == 'global_region') {
                    //	$this->db->select('countries.GlobalRegion,COUNT(DISTINCT kols.id) as count');
                    //$this->db->group_by('countries.GlobalRegion');
                    //$this->db->where('country IS NOT NULL');
                }

                if ($groupByCategory == 'type') {
                    $this->db->select('organization_types.type,organization_types.id as org_type_id,COUNT(DISTINCT kols.id) as count');
                    $this->db->join('organization_types', 'organization_types.id=organizations.type_id', 'left');
//                                        $this->db->join('kols','kols.org_id=organizations.org_id','left');



                    $this->db->group_by('organization_types.id');
                }

                if ($groupByCategory == 'title') {
                   $this->db->select('titles.title,kols.id as kol_type_id,COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('titles.title');
                }

                if ($groupByCategory == 'region') {
                    $this->db->select('countries.GlobalRegion,countries.countryId as region_type_id,COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('countries.GlobalRegion');
                }
                if(KOL_CONSENT){
                    if ($groupByCategory == 'opt_inout') {
                        $this->db->select('opt_inout_statuses.name as opt_name, opt_inout_statuses.id as opt_in_out_id,COUNT(DISTINCT kols.id) as count');
                        $this->db->where('kols.opt_in_out_status !=', 0);
                        $this->db->group_by('opt_inout_statuses.name');
                    }
                }

                $this->db->order_by('count', 'desc');
            } else {
                if (!$isFrmInfluenceMap)
                    $this->db->limit($limit, $startFrom);
            }
            if ($currentController == 'maps' or $currentControllerIpad == 'maps') {
                //$this->db->where_in('kols.status', array(COMPLETED));
            } else {
                //$this->db->where_in('kols.status',array(COMPLETED,PRENEW));
                $this->db->where('kols.customer_status', "ACTV");
            }
            if ($arrFilterFields['profile_type'] != "" && $arrFilterFields['profile_type'] != "undefined") {
                $this->db->where('kols.profile_type', $arrFilterFields['profile_type']);
            }
            if (sizeof($arrQueryOptions) > 0) {
                switch ($arrQueryOptions['sort_by']) {
                    case 'name':
                        if ($this->session->userdata('name_order') == 2) {
                            $this->db->order_by('kols.last_name', $arrQueryOptions['sort_order']);
                        } else {
                            $this->db->order_by('kols.first_name', $arrQueryOptions['sort_order']);
                            $this->db->order_by('kols.middle_name', $arrQueryOptions['sort_order']);
                            $this->db->order_by('kols.last_name', $arrQueryOptions['sort_order']);
                        }
                        break;
                    case 'specialty':$this->db->order_by('specialties.specialty', $arrQueryOptions['sort_order']);
                        break;
                    case 'state':$this->db->order_by('regions.region', $arrQueryOptions['sort_order']);
                        break;
                    case 'city':$this->db->order_by('cities.City', $arrQueryOptions['sort_order']);
                        break;
                    case 'country':$this->db->order_by('countries.country', $arrQueryOptions['sort_order']);
                        break;
                    case 'opt_status':$this->db->order_by('kols.opt_in_out_status', $arrQueryOptions['sort_order']);
                        break;
                }
            } else if (!$doGroupBy) {
                if ($this->session->userdata('name_order') == 2) {
                    $this->db->order_by('kols.last_name', $arrQueryOptions['sort_order']);
                } else {
                    $this->db->order_by('kols.first_name');
                }
            }
//			pr($arrFilterFields);
            if (isset($arrFilterFields) && sizeof($arrFilterFields['viewType']) > 0) {
                $this->db->where_in('kols.id', $arrFilterFields['viewType']);
            }
            $loggedInuserClientId	= $client_id;
            if($checkClientBasedVisibilityByClientId>0){
            	$loggedInuserClientId	= $checkClientBasedVisibilityByClientId;
            }
            if($loggedInuserClientId !== INTERNAL_CLIENT_ID){
            	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
            	$this->db->where('kols_client_visibility.client_id', $loggedInuserClientId);
            }
            
            $arrKolDetailsResult = $this->db->get('kols');
// 		 	pr($this->db->last_query());exit; 
            foreach ($arrKolDetailsResult->result_array() as $row) {
                $arrKols[] = $row;
            }
            return $arrKols; 
        }
    }

    function getMatchingKolsDoAnd2($arrKeywords, $arrFilterFields, $limit, $startFrom, $doCount, $doGroupBy = false, $groupByCategory = null, $arrQueryOptions = array()) {
        $client_id = $this->session->userdata('client_id');
        $user_id = $this->session->userdata('user_id');
        $arrKols = array();

        if (sizeof($arrKeywords == 2)) {
            $name1 = trim($arrKeywords[0]);
            $name2 = trim($arrKeywords[1]);
            $where = "((first_name='" . $name1 . "' AND last_name='" . $name2 . "') OR (first_name='" . $name1 . "' AND middle_name='" . $name2 . "') OR (middle_name='" . $name1 . "' AND last_name='" . $name2 . "') OR (first_name='" . $name2 . "' AND last_name='" . $name1 . "') OR (first_name='" . $name2 . "' AND middle_name='" . $name1 . "') OR (middle_name='" . $name2 . "' AND last_name='" . $name1 . "'))";
        } else if (sizeof($arrKeywords == 3)) {
            $name1 = trim($arrKeywords[0]);
            $name2 = trim($arrKeywords[1]);
            $name3 = trim($arrKeywords[2]);
            $where1 = "(first_name='" . $name1 . "' AND middle_name='" . $name2 . "' AND last_name='" . $name3 . "')";
            $where2 = "(first_name='" . $name1 . "' AND middle_name='" . $name3 . "' AND last_name='" . $name2 . "')";
            $where3 = "(first_name='" . $name2 . "' AND middle_name='" . $name1 . "' AND last_name='" . $name3 . "')";
            $where4 = "(first_name='" . $name2 . "' AND middle_name='" . $name3 . "' AND last_name='" . $name1 . "')";
            $where5 = "(first_name='" . $name3 . "' AND middle_name='" . $name2 . "' AND last_name='" . $name1 . "')";
            $where6 = "(first_name='" . $name3 . "' AND middle_name='" . $name1 . "' AND last_name='" . $name2 . "')";
            $where = "(" . $where1 . " OR " . $where2 . " OR " . $where3 . " OR " . $where4 . " OR " . $where5 . " OR " . $where6 . ")";
        }

        if (!$doCount)
            $this->db->select('kols.*,organizations.name,specialties.specialty as specs,countries.country,regions.region as state,cities.City as city');

        $this->db->join('titles', 'titles.id = kols.title', 'left');
        $this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
        $this->db->join('specialties', 'specialties.id = kols.specialty', 'left');
        $this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
        $this->db->join('regions', 'regions.regionID = kols.state_id', 'left');
        $this->db->join('cities', 'cities.CityId = kols.city_id', 'left');
        if(KOL_CONSENT){
            $this->db->select('opt_inout_statuses.name as opt_status_name');
            $this->db->join('opt_inout_statuses', 'opt_inout_statuses.id = kols.opt_in_out_status', 'left');
        }
        
        if ($arrFilterFields != null && $arrFilterFields['education'] != null && isset($arrFilterFields['education']) && sizeof($arrFilterFields['education']) > 0 && !($doGroupBy == true && $groupByCategory == 'education')) {
            $this->db->distinct();
            $this->db->join('kol_educations', 'kol_educations.kol_id = kols.id', 'left');
            $this->db->join('institutions', 'kol_educations.institute_id = institutions.id', 'left');
            $this->db->where_in('institutions.id', $arrFilterFields['education']);
            $this->db->where('kol_educations.type', 'education');
        }
        if ($arrFilterFields != null && $arrFilterFields['event_id'] != null && isset($arrFilterFields['event_id']) && sizeof($arrFilterFields['event_id']) > 0 && !($doGroupBy == true && $groupByCategory == 'event')) {
            $this->db->distinct();
            $this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');
            $this->db->join('events', 'kol_events.event_id = events.id', 'left');
            $this->db->where_in('kol_events.event_id', $arrFilterFields['event_id']);
        }
        if ($arrFilterFields != null && $arrFilterFields['list_id'] != null && isset($arrFilterFields['list_id']) && sizeof($arrFilterFields['list_id']) > 0 && !($doGroupBy == true && $groupByCategory == 'list')) {
            $this->db->distinct();
            $this->db->join('list_kols', 'list_kols.kol_id=kols.id', 'left');
            $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
            //$this->db->where_in('list_names.list_name',$arrFilterFields['list_id']);
            $this->db->where_in('list_names.id', $arrFilterFields['list_id']);
        }
        if(KOL_CONSENT){
            if ($arrFilterFields != null && $arrFilterFields['opt_inout'] != null && isset($arrFilterFields['opt_inout']) && sizeof($arrFilterFields['opt_inout']) > 0 && !($doGroupBy == true && $groupByCategory == 'opt_inout')) {
                $this->db->distinct();
                $this->db->where_in('opt_inout_statuses.id', $arrFilterFields['opt_inout']);
                //
            }
        }

        $this->db->where($where);
        if ($arrFilterFields != null && $arrFilterFields['country'] != '' && isset($arrFilterFields['country']) && sizeof($arrFilterFields['country']) > 0 && !($doGroupBy == true && $groupByCategory == 'country'))
            $this->db->where_in('countries.countryId', $arrFilterFields['country']);
        if ($arrFilterFields != null && $arrFilterFields['state'] != '' && isset($arrFilterFields['state']) && sizeof($arrFilterFields['state']) > 0 && !($doGroupBy == true && $groupByCategory == 'state')) {
            //$this->db->where_in('regions.region', $arrFilterFields['state']);
            $this->db->where_in('regions.RegionID', $arrFilterFields['state']);
        }
        if ($arrFilterFields != null && $arrFilterFields['city'] != '' && isset($arrFilterFields['city']) && sizeof($arrFilterFields['city']) > 0 && !($doGroupBy == true && $groupByCategory == 'city')) {
            $this->db->where_in('cities.CityId', $arrFilterFields['city']);
        }
        if ($arrFilterFields != null && $arrFilterFields['organization'] != '' && isset($arrFilterFields['organization']) && sizeof($arrFilterFields['organization']) > 0 && !($doGroupBy == true && $groupByCategory == 'organization')) {
            /* $arrOrgIds	= array();
              foreach($arrFilterFields['organization'] as $orgId=>$orgName){
              $arrOrgIds[]	= $orgId;
              }
             */
            $this->db->where('organizations.status', COMPLETED);
            $this->db->where_in('organizations.id', $arrFilterFields['organization']);
        }
        if ($arrFilterFields != null && $arrFilterFields['title'] != null && isset($arrFilterFields['title']) && sizeof($arrFilterFields['title']) > 0 && !($doGroupBy == true && $groupByCategory == 'title')) {
        	$this->db->distinct();        	
        	$this->db->where_in('titles.title', $arrFilterFields['title']);        	
        }
        //$this->db->where_in('organizations.id', $arrFilterFields['organization']);
        if ($arrFilterFields != null && $arrFilterFields['specialty'] != '' && isset($arrFilterFields['specialty']) && sizeof($arrFilterFields['specialty']) > 0 && !($doGroupBy == true && $groupByCategory == 'specialty'))
            $this->db->where_in('specialties.id', $arrFilterFields['specialty']);
        if(KOL_CONSENT){
            if ($arrFilterFields != null && $arrFilterFields['opt_inout'] != '' && isset($arrFilterFields['opt_inout']) && sizeof($arrFilterFields['opt_inout']) > 0 && !($doGroupBy == true && $groupByCategory == 'opt_inout'))
                $this->db->where_in('opt_inout_statuses.id', $arrFilterFields['opt_inout']);
        }
        if ($doCount) {
            $this->db->distinct();
            //$this->db->where('status', COMPLETED);
            $count = $this->db->count_all_results('kols');
            return $count;
        } else {
            if ($doGroupBy) {
                if ($groupByCategory == 'country') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('country_id');
                    //$this->db->where('country IS NOT NULL');
                }
                if ($groupByCategory == 'state') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('state_id');
                    //$this->db->where('country IS NOT NULL');
                }
                if ($groupByCategory == 'city') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('city_id');
                    //$this->db->where('country IS NOT NULL');
                }
                if ($groupByCategory == 'specialty') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('specialty');
                    //$this->db->where('specialties.specialty IS NOT NULL');
                }
                if ($groupByCategory == 'organization') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('organizations.id');
                    //$this->db->where('name IS NOT NULL');
                }
                if ($groupByCategory == 'education') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count,institutions.name as institute_name,kol_educations.institute_id');
                    $this->db->join('kol_educations', 'kol_educations.kol_id = kols.id', 'left');
                    $this->db->join('institutions', 'kol_educations.institute_id = institutions.id', 'left');
                    $this->db->where('kol_educations.type', 'education');
                    $this->db->where('institutions.name IS NOT NULL');
                    $this->db->group_by('kol_educations.institute_id');
                }
                if ($groupByCategory == 'title') {
                	$this->db->select('titles.title,kols.id as kol_type_id,COUNT(DISTINCT kols.id) as count');
                	$this->db->group_by('titles.title');
                }
                if ($groupByCategory == 'event') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count,events.name as event_name,events.id as event_id');
                    $this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');
                    $this->db->join('events', 'kol_events.event_id = events.id', 'left');
                    $this->db->where('events.name IS NOT NULL');
                    $this->db->group_by('kol_events.event_id');
                }
                if ($groupByCategory == 'list') {
                    $this->db->select('list_kols.list_name_id,list_names.list_name,list_categories.category,COUNT(kols.id) AS count');
                    $this->db->join('list_kols', 'list_kols.kol_id=kols.id', 'left');
                    $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
                    $this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
                    $this->db->where('list_categories.client_id', $client_id);
                    $where = "(list_categories.user_id=$user_id OR list_categories.is_public=1)";
                    $this->db->where($where);
                    $this->db->group_by('list_kols.list_name_id');
                }
                if(KOL_CONSENT){
                    if ($groupByCategory == 'opt_inout') {
                        $this->db->select('opt_inout_statuses.name as opt_name, opt_inout_statuses.id as opt_in_out_id,COUNT(DISTINCT kols.id) as count');
                        $this->db->where('kols.opt_in_out_status !=', 0);
                        $this->db->group_by('opt_inout_statuses.name');
                    }
                }
                $this->db->order_by('count', 'desc');
            } else
                $this->db->limit($limit, $startFrom);

            if (sizeof($arrQueryOptions) > 0) {
                switch ($arrQueryOptions['sort_by']) {
                    case 'name':
                        if ($this->session->userdata('name_order') == 2) {
                            $this->db->order_by('kols.last_name', $arrQueryOptions['sort_order']);
                        } else {
                            $this->db->order_by('kols.first_name', $arrQueryOptions['sort_order']);
                            $this->db->order_by('kols.middle_name', $arrQueryOptions['sort_order']);
                            $this->db->order_by('kols.last_name', $arrQueryOptions['sort_order']);
                        }
                        break;
                    case 'specialty':$this->db->order_by('specialties.specialty', $arrQueryOptions['sort_order']);
                        break;
                    case 'state':$this->db->order_by('countries.country', $arrQueryOptions['sort_order']);
                        break;
                    case 'city':$this->db->order_by('cities.city', $arrQueryOptions['sort_order']);
                        break;
                    case 'country':$this->db->order_by('regions.region', $arrQueryOptions['sort_order']);
                        break;
                    case 'opt_status':$this->db->order_by('kols.opt_in_out_status', $arrQueryOptions['sort_order']);
                        break;
                }
            } else {
                $this->db->order_by('kols.first_name');
            }
            if (isset($arrFilterFields) && sizeof($arrFilterFields['viewType']) > 0) {
                $this->db->where_in('kols.id', $arrFilterFields['viewType']);
            }
           // $this->db->where('status', COMPLETED);
            if ($arrFilterFields['profile_type'] != "" && $arrFilterFields['profile_type'] != "undefined") {
                $this->db->where('kols.profile_type', $arrFilterFields['profile_type']);
            }
            if($client_id !== INTERNAL_CLIENT_ID){
                $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
                $this->db->where('kols_client_visibility.client_id', $client_id);
            }
            
            $arrKolDetailsResult = $this->db->get('kols');
            foreach ($arrKolDetailsResult->result_array() as $row) {
                $arrKols[] = $row;
            }
//			echo $this->db->last_query();		
            return $arrKols;
        }
    }

    function getAdvSearchMatchingKols($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, $doCount, $doGroupBy = false, $groupByCategory = null) {
        $client_id = $this->session->userdata('client_id');
        $user_id = $this->session->userdata('user_id');
        //$arrFilterFields=$arrFilterFields;
        $eduJoined = false;
        $eventJoined = false;
        $arrKolDetails = array();
        $arrKolIdsMatchingKeyword = array();
        $arrUniqueKolIds = array();
        if ($arrAdvSearchFields['keywords'] != '') {
            $arrKolIdsMatchingKeyword = $this->getKeywordMatchingKols($arrAdvSearchFields['keywords']);
        }
        if (isset($arrAdvSearchFields['first_name']) || isset($arrAdvSearchFields['last_name']))
            if (($arrAdvSearchFields['first_name'] != '') || ($arrAdvSearchFields['last_name'] != '')) {
                $this->db->distinct();
                $this->db->select("kols.id");
                if ($arrAdvSearchFields['first_name'] != '') {
                    $where = "kols.first_name like '%" . addslashes($arrAdvSearchFields['first_name']) . "%'";
                    $this->db->where($where, null);
                }
                if ($arrAdvSearchFields['last_name'] != '') {
                    $where = "kols.last_name like '%" . addslashes($arrAdvSearchFields['last_name']) . "%'";
                    $this->db->where($where, null);
                }
                $arrKolResultSet = $this->db->get('kols');
                foreach ($arrKolResultSet->result_array() as $row) {
                    $arrKolIdsMatchingNames[] = $row['id'];
                }
                if ($arrAdvSearchFields['keywords'] != '') {
                    $arrKolIdsMatchingKeyword = array_intersect($arrKolIdsMatchingKeyword, $arrKolIdsMatchingNames);
                } else {
                    $arrKolIdsMatchingKeyword = $arrKolIdsMatchingNames;
                }
            }
        if ($arrAdvSearchFields != null && (isset($arrAdvSearchFields['pkeywords']) || isset($arrAdvSearchFields['pauthpos']))) {
            $pubsQuery = 'select kol_publications.kol_id,kol_publications.auth_pos,publications.article_title,publications.abstract_text, MAX(publications_authors.position) AS max_pos 
								from publications, kol_publications, publications_authors 
								where kol_publications.pub_id=publications.id and
								publications_authors.pub_id=publications.id and 
								kol_publications.is_verified=1 and 
								kol_publications.is_deleted=0 and (';
            if ($arrAdvSearchFields['pkeywords'] != '')
                $pubsQuery .= "(publications.article_title like '%" . $arrAdvSearchFields['pkeywords'] . "%' or publications.abstract_text like '%" . $arrAdvSearchFields['pkeywords'] . "%')";
            if ($arrAdvSearchFields['pkeywords'] != '' && $arrAdvSearchFields['pauthpos'] != '') {
                $pubsQuery .= ') AND (';
            }
            if ($arrAdvSearchFields['pauthpos'] != '') {
                if ($arrAdvSearchFields['pauthpos'] == 1) // first auth position
                    $pubsQuery .= "kol_publications.auth_pos=1";
                if ($arrAdvSearchFields['pauthpos'] == 2) // middle auth position
                    $pubsQuery .= "(kol_publications.auth_pos > 1 and kol_publications.auth_pos < publications_authors.position)";
                if ($arrAdvSearchFields['pauthpos'] == 3) // last auth position
                    $pubsQuery .= "(kol_publications.auth_pos!=1 and kol_publications.auth_pos = publications_authors.position)";
                if ($arrAdvSearchFields['pauthpos'] == 4) // single auth position
                    $pubsQuery .= "(kol_publications.auth_pos<2 and kol_publications.auth_pos = publications_authors.position)";
            }
            $pubsQuery .= ') group by publications_authors.pub_id';
            if ($arrAdvSearchFields['pkeywords'] != '' || $arrAdvSearchFields['pauthpos'] != '') {
                $pubResultSet = $this->db->query($pubsQuery);
                $arrPubData = array();
                foreach ($pubResultSet->result_array() as $row) {
                    if ($arrAdvSearchFields['pauthpos'] != '' && $arrAdvSearchFields['pauthpos'] == 4 && $row['max_pos'] > 1) {
                        continue;
                    }
                    $arrPubData[$row['kol_id']][] = $row;
                }
                foreach ($arrPubData as $kol_id => $arrActualRow) {
                    $textAuthPos = '';
                    $textArticle = '';
                    $textAbstract = '';
                    foreach ($arrActualRow as $key => $row) {
                        $textAuthPos .= $row['auth_pos'] . ' , ';
                        $textArticle .= $row['article_title'] . ' , ';
                        $textAbstract .= $row['abstract_text'] . ' , ';
                    }
                    $arrPubsKolsData[$kol_id] = array('auth_pos' => $textAuthPos, 'article' => $textArticle, 'abstract' => $textAbstract);
                }
            }
        }
        if ($arrAdvSearchFields != null && (isset($arrAdvSearchFields['etopic']) || isset($arrAdvSearchFields['erole']))) {
            $eventsQuery = "select kol_events.kol_id,kol_events.role,event_topics.name as topic_name 
								from kol_events, event_topics where 
								event_topics.id=kol_events.topic and (";

            if (!empty($arrAdvSearchFields['etopic']) && $arrAdvSearchFields['etopic'] != '')
                $eventsQuery .= 'event_topics.name like "%' . $arrAdvSearchFields['etopic'] . '%"';
            if (!empty($arrAdvSearchFields['etopic']) && $arrAdvSearchFields['etopic'] != '' && !empty($arrAdvSearchFields['erole']) && $arrAdvSearchFields['erole'] != '') {
                $eventsQuery .= ') AND (';
            }
            if (!empty($arrAdvSearchFields['erole']) && $arrAdvSearchFields['erole'] != '') {
                $eventsQuery .= "kol_events.role like '%" . $arrAdvSearchFields['erole'] . "%'";
            }
            $eventsQuery .= ")";
            if ((!empty($arrAdvSearchFields['etopic']) && $arrAdvSearchFields['etopic'] != '') || (!empty($arrAdvSearchFields['erole']) && $arrAdvSearchFields['erole'] != '')) {
                $eventsResultSet = $this->db->query($eventsQuery);
                //echo $eventsQuery;
                //echo $this->db->last_query();
                $arrEventsData = array();
                foreach ($eventsResultSet->result_array() as $row) {
                    $arrEventsData[$row['kol_id']][] = $row;
                }
                foreach ($arrEventsData as $kol_id => $arrActualRow) {
                    $textEventRole = '';
                    $textEventTopic = '';
                    foreach ($arrActualRow as $key => $row) {
                        $textEventRole .= $row['role'] . ' , ';
                        $textEventTopic .= $row['topic_name'] . ' , ';
                    }
                    $arrEventsKolsData[$kol_id] = array('event_role' => $textEventRole, 'topic_name' => $textEventTopic);
                }
            }
        }

        if ($arrAdvSearchFields != null && (isset($arrAdvSearchFields['tkeywords']) || isset($arrAdvSearchFields['trole']))) {

            $trialsQuery = "select kol_clinical_trials.kol_id,cts_investigators.role,clinical_trials.trial_name,clinical_trials.condition,clinical_trials.official_title 
							from clinical_trials, kol_clinical_trials, ct_investigators, cts_investigators
							where kol_clinical_trials.cts_id=clinical_trials.id
							and ct_investigators.cts_id=kol_clinical_trials.cts_id
							and cts_investigators.id=ct_investigators.investigator_id and (";
            if (!empty($arrAdvSearchFields['tkeywords']) && $arrAdvSearchFields['tkeywords'] != '') {
                //$trialsQuery	.= "clinical_trials.tkeywords like '%".$arrAdvSearchFields['tkeywords']."%'";
                $trialsQuery .= "clinical_trials.trial_name like '%" . $arrAdvSearchFields['tkeywords'] . "%'";
                $trialsQuery .= " or clinical_trials.condition like '%" . $arrAdvSearchFields['tkeywords'] . "%'";
                $trialsQuery .= "or clinical_trials.official_title like '%" . $arrAdvSearchFields['tkeywords'] . "%'";
            }
            if (!empty($arrAdvSearchFields['tkeywords']) && $arrAdvSearchFields['tkeywords'] != '' && !empty($arrAdvSearchFields['trole']) && $arrAdvSearchFields['trole'] != '') {
                $trialsQuery .= ') AND (';
            }
            if (!empty($arrAdvSearchFields['trole']) && $arrAdvSearchFields['trole'] != '') {
                $trialsQuery .= "(cts_investigators.role like '%" . $arrAdvSearchFields['trole'] . "%' or clinical_trials.kol_role like '%" . $arrAdvSearchFields['trole'] . "%')";
            }
            $trialsQuery .= ")";
            if ((!empty($arrAdvSearchFields['tkeywords']) && $arrAdvSearchFields['tkeywords'] != '') || (!empty($arrAdvSearchFields['trole']) && $arrAdvSearchFields['trole'] != '')) {
                $trialsResultSet = $this->db->query($trialsQuery);
                //echo $this->db->last_query();
                $arrTrialsData = array();
                foreach ($trialsResultSet->result_array() as $row) {
                    $arrTrialsData[$row['kol_id']][] = $row;
                }
                foreach ($arrTrialsData as $kol_id => $arrActualRow) {
                    $textTrialRole = '';
                    $textTrialKeyword = '';
                    foreach ($arrActualRow as $key => $row) {
                        $textTrialRole .= $row['role'] . ' , ';
                        $textTrialKeyword .= $row['trial_name'] . ' - ' . $row['condition'] . ' - ' . $row['official_title'] . ' , ';
                    }
                    $arrTrialsKolsData[$kol_id] = array('trial_role' => $textEventRole, 'trial_keyword' => $textTrialKeyword);
                }
            }
        }

        $arrKolIdsMatchingPubs = array_keys($arrPubsKolsData);
        $arrKolIdsMatchingEvents = array_keys($arrEventsKolsData);
        $arrKolIdsMatchingTrials = array_keys($arrTrialsKolsData);

        $arrUniqueKolIds = array_merge($arrUniqueKolIds, $arrKolIdsMatchingKeyword);
        
        if (isset($arrAdvSearchFields['pqtype'])) {
            if (sizeof($arrUniqueKolIds) > 0) {
                $arrUniqueKolIds = array_intersect($arrUniqueKolIds, $arrKolIdsMatchingPubs);
            } else {
                $arrUniqueKolIds = $arrKolIdsMatchingPubs;
            }
        } else if (sizeof($arrKolIdsMatchingPubs) > 0) {
            $arrUniqueKolIds = array_merge($arrUniqueKolIds, $arrKolIdsMatchingPubs);
        }

        if (isset($arrAdvSearchFields['eqtype'])) {
            if (sizeof($arrUniqueKolIds) > 0) {
                $arrUniqueKolIds = array_intersect($arrUniqueKolIds, $arrKolIdsMatchingEvents);
            } else {
                $arrUniqueKolIds = $arrKolIdsMatchingEvents;
            }
        } else if (sizeof($arrKolIdsMatchingEvents) > 0) {
            $arrUniqueKolIds = array_merge($arrUniqueKolIds, $arrKolIdsMatchingEvents);
        }

        if (isset($arrAdvSearchFields['tqtype'])) {
            if (sizeof($arrUniqueKolIds) > 0) {
                $arrUniqueKolIds = array_intersect($arrUniqueKolIds, $arrKolIdsMatchingTrials);
            } else {
                $arrUniqueKolIds = $arrKolIdsMatchingTrials;
            }
        } else if (sizeof($arrKolIdsMatchingTrials) > 0) {
            $arrUniqueKolIds = array_merge($arrUniqueKolIds, $arrKolIdsMatchingTrials);
        }
        $arrUniqueKolIds = array_unique($arrUniqueKolIds);
       
        $includesRefinedFilters = false;
        $this->db->distinct();
        if (!$doCount)
            $this->db->select('kols.id,kols.unique_id,kols.salutation,kols.first_name,kols.middle_name,kols.last_name,kols.suffix,kols.profile_image,organizations.name,specialties.specialty as specs,countries.country, regions.region as state,kols.org_id,kols.state_id,kols.country_id,kols.specialty');
        $this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
        $this->db->join('specialties', 'specialties.id = kols.specialty', 'left');
        $this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
        $this->db->join('regions', 'regions.regionID = kols.state_id', 'left');
        if (isset($arrAdvSearchFields['memebers']) && sizeof($arrAdvSearchFields['memebers']) > 0){
		$this->db->join('kol_memberships', 'kol_memberships.kol_id = kols.id', 'left');
        }

        if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['education']) && $arrAdvSearchFields['education'] != null && sizeof($arrAdvSearchFields['education']) > 0 && !($doGroupBy == true && $groupByCategory == 'education')) {
            $this->db->distinct();
            $this->db->join('kol_educations', 'kol_educations.kol_id = kols.id', 'left');
            $this->db->join('institutions', 'kol_educations.institute_id = institutions.id', 'left');
            $this->db->where_in('institutions.id', $arrAdvSearchFields['education']);
            $this->db->where('kol_educations.type', 'education');
            $eduJoined = true;
            $includesRefinedFilters = true;
        }
        if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['event_id']) && $arrAdvSearchFields['event_id'] != null && sizeof($arrAdvSearchFields['event_id']) > 0 && !($doGroupBy == true && $groupByCategory == 'event')) {
            $this->db->distinct();
            $this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');
            $this->db->join('events', 'kol_events.event_id = events.id', 'left');
            $this->db->where_in('events.id', $arrAdvSearchFields['event_id']);
            $eventJoined = true;
            $includesRefinedFilters = true;
        }
        if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['list_id']) && $arrAdvSearchFields['list_id'] != null && sizeof($arrAdvSearchFields['list_id']) > 0 && !($doGroupBy == true && $groupByCategory == 'list')) {
            $this->db->distinct();
            $this->db->join('list_kols', 'list_kols.kol_id=kols.id', 'left');
            $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
            //$this->db->where_in('list_names.list_name',$arrAdvSearchFields['list_id']);
            $this->db->where_in('list_names.id', $arrAdvSearchFields['list_id']);
            $includesRefinedFilters = true;
        }
        if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['country']) && $arrAdvSearchFields['country'] != '' && sizeof($arrAdvSearchFields['country']) > 0 && !($doGroupBy == true && $groupByCategory == 'country')) {
            $this->db->where_in('countries.countryId', $arrAdvSearchFields['country']);
            $includesRefinedFilters = true;
        }
        if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['state']) && $arrAdvSearchFields['state'] != '' && sizeof($arrAdvSearchFields['state']) > 0 && !($doGroupBy == true && $groupByCategory == 'state')) {
            $this->db->where_in('regions.regionID', $arrAdvSearchFields['state']);
            $includesRefinedFilters = true;
        }
        if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['organization']) && $arrAdvSearchFields['organization'] != '' && sizeof($arrAdvSearchFields['organization']) > 0 && !($doGroupBy == true && $groupByCategory == 'organization')) {
            $this->db->where_in('organizations.id', $arrAdvSearchFields['organization']);
            $includesRefinedFilters = true;
        }
        if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['specialty']) && $arrAdvSearchFields['specialty'] != '' && sizeof($arrAdvSearchFields['specialty']) > 0 && !($doGroupBy == true && $groupByCategory == 'specialty')) {
            $this->db->where_in('specialties.id', $arrAdvSearchFields['specialty']);
            $includesRefinedFilters = true;
        }
        if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['type']) && $arrAdvSearchFields['type'] != '' && sizeof($arrAdvSearchFields['type']) > 0 && !($doGroupBy == true && $groupByCategory == 'type')) {
            $this->db->distinct();
            $this->db->join('organization_types', 'organization_types.id=organizations.type_id', 'left');
            //$this->db->where_in('list_names.list_name',$arrFilterFields['list_id']);
            $this->db->where_in('organization_types.id', $arrAdvSearchFields['type']);
//                      
            $includesRefinedFilters = true;
        }
        if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['kol_titles']) && $arrAdvSearchFields['kol_titles'] != '' && sizeof($arrAdvSearchFields['kol_titles']) > 0 && !($doGroupBy == true && $groupByCategory == 'kol_titles')) {
            $this->db->distinct();
            $this->db->distinct();
            $this->db->where_in('kols.title', $arrAdvSearchFields['kol_titles']);
//                      
            $includesRefinedFilters = true;
        }
        if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['region']) && $arrAdvSearchFields['region'] != '' && sizeof($arrAdvSearchFields['region']) > 0 && !($doGroupBy == true && $groupByCategory == 'region')) {
            $this->db->distinct();
            $this->db->distinct();
            $this->db->where_in('countries.GlobalRegion', $arrAdvSearchFields['region']);
//                      
            $includesRefinedFilters = true;
        }
          if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['topic']) && $arrAdvSearchFields['topic'] != '' && sizeof($arrAdvSearchFields['topic']) > 0 && !($doGroupBy == true && $groupByCategory == 'topic')) {
            $this->db->distinct();
            $this->db->distinct();
                 $eventJoined=true;
            $this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');

                   
                    $this->db->join('event_topics', 'event_topics.id = kol_events.topic', 'left');
            $this->db->where_in('event_topics.name', $arrAdvSearchFields['topic']);
//                      
            $includesRefinedFilters = true;
        }
        /* 	
          if($arrAdvSearchFields!=null && $arrAdvSearchFields['education']!=null){
          $this->db->join('kol_educations', 'kol_educations.kol_id = kols.id', 'left');
          $this->db->where('kol_educations.institute_id',$arrAdvSearchFields['education']);
          $eduJoined=true;
          }
          if($arrAdvSearchFields!=null && $arrAdvSearchFields['event_id']!=null){
          $this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');
          $this->db->where('kol_events.event_id',$arrAdvSearchFields['event_id']);
          $eventJoined=true;
          }
          if($arrAdvSearchFields['specialty']!='')
          $this->db->where('specialties.specialty', $arrAdvSearchFields['specialty']);
          if($arrAdvSearchFields['country']!='')
          $this->db->where('countries.country', $arrAdvSearchFields['country']);
          if($arrAdvSearchFields['organization']!='')
          $this->db->where('organizations.name', $arrAdvSearchFields['organization']);
         */
        /* 	if($arrAdvSearchFields['first_name']!=''){
          //	$this->db->where('first_name', $arrAdvSearchFields['first_name']);
          $where	= "kols.first_name like '%".addslashes($arrAdvSearchFields['first_name'])."%'";
          $this->db->where($where,null);
          }
          if($arrAdvSearchFields['last_name']!=''){
          //	$this->db->where('last_name', $arrAdvSearchFields['last_name']);
          $where	= "kols.last_name like '%".addslashes($arrAdvSearchFields['last_name'])."%'";
          $this->db->where($where,null);
          }
          if($arrAdvSearchFields['middle_name']!=''){
          //	$this->db->where('middle_name', $arrAdvSearchFields['middle_name']);
          $where	= "kols.middle_name like '%".addslashes($arrAdvSearchFields['middle_name'])."%'";
          $this->db->where($where,null);
          }
         */
        if ($arrAdvSearchFields['sub_specialty'] != '')
            $this->db->where('sub_specialty', $arrAdvSearchFields['sub_specialty']);
        if ($arrAdvSearchFields['title'] != '')
            $this->db->where('kols.title', $arrAdvSearchFields['title']);
        if ($arrAdvSearchFields['postal_code'] != '')
            $this->db->where('kols.postal_code', $arrAdvSearchFields['postal_code']);
        if ($arrAdvSearchFields['profileType'] != '')
            $this->db->where('kols.profile_type', $arrAdvSearchFields['profileType']);
       /*  if (isset($arrAdvSearchFields['viewType']) && sizeof($arrAdvSearchFields['viewType']) > 0)
            $this->db->where_in('kols.id', $arrAdvSearchFields['viewType']); */
         if (isset($arrAdvSearchFields['memebers']) && sizeof($arrAdvSearchFields['memebers']) > 0)
            $this->db->where_in('kol_memberships.institute_id', $arrAdvSearchFields['memebers']);

            $arrKolIdsMatchingViewType = array_keys($arrAdvSearchFields['viewType']);
            if (isset($arrAdvSearchFields['viewType'])) {
            	if (sizeof($arrUniqueKolIds) > 0) {
            		$arrUniqueKolIds = array_intersect($arrUniqueKolIds, $arrKolIdsMatchingViewType);
            	}else{
            		$arrUniqueKolIds	= array(0);
            	}
            }
         //pr($arrUniqueKolIds); 
            
            
//		if($arrAdvSearchFields['keywords']!=''){
//			$keywords	=	$arrAdvSearchFields['keywords'];			
//			if(!$eduJoined){
//				$this->db->join('kol_educations', 'kol_educations.kol_id = kols.id', 'left');
//				$this->db->join('institutions', 'institutions.id = kol_educations.institute_id', 'left');	
//				$eduJoined=true;
//			}
//			if(!$eventJoined){
//				$this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');
//				$this->db->join('events', 'events.id = kol_events.event_id', 'left');	
//				$eventJoined=true;
//			}
//			$this->db->join('kol_memberships', 'kol_memberships.kol_id = kols.id', 'left');
//			$this->db->join('institutions', 'institutions.id = kol_memberships.institute_id', 'left');
//			
//			$whereWords="(inst.name LIKE '%".$keywords."%' OR institutions.name LIKE '%".$keywords."%' OR events.name LIKE '%".$keywords."%' OR kol_memberships.title LIKE '%".$keywords."%' OR kol_events.session_name LIKE '%".$keywords."%')";
//			$this->db->where($whereWords);
        //$arrKolIdsMatchingKeyword=$this->getKeywordMatchingKols($arrAdvSearchFields['keywords']);
//			if(sizeof($arrKolIdsMatchingKeyword)>0)
//				$this->db->where_in('kols.id',$arrKolIdsMatchingKeyword);
//			else //In order to return matching result as 0
//				$this->db->where_in('kols.id','a');
//		}

        if (sizeof($arrUniqueKolIds) > 0) {
            $this->db->where_in('kols.id', $arrUniqueKolIds);
        } else if (!$includesRefinedFilters) {
            $this->db->where('kols.id','0');
        }

        if ($doCount) {
            $this->db->distinct();
            $this->db->select('COUNT(DISTINCT kols.id) AS `count`');
            //$result=$this->db->count_all_results('kols');
            //$this->db->where('kols.status', COMPLETED);
            $result = $this->db->get('kols');
//			echo $this->db->last_query();
            $resultObj = $result->row();
            $count = $resultObj->count;
            return $count;
        } else {
            if ($doGroupBy) {
                if ($groupByCategory == 'country') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('kols.country_id');
                    //$this->db->where('country IS NOT NULL');
                }
                if ($groupByCategory == 'state') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('kols.state_id');
                    //$this->db->where('country IS NOT NULL');
                }
                if ($groupByCategory == 'specialty') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('kols.specialty');
                    //$this->db->where('specialties.specialty IS NOT NULL');
                }
                if ($groupByCategory == 'organization') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('organizations.id');
                    //$this->db->where('name IS NOT NULL');
                }
                if ($groupByCategory == 'education') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count,institutions.name as institute_name,institutions.id as institute_id');
                    if (!$eduJoined) {
                        $this->db->join('kol_educations', 'kol_educations.kol_id = kols.id', 'left');
                        $this->db->join('institutions', 'kol_educations.institute_id = institutions.id', 'left');
                    }
                    $this->db->where('kol_educations.type', 'education');
                    $this->db->where('institutions.name IS NOT NULL');
                    $this->db->group_by('kol_educations.institute_id');
                }
                if ($groupByCategory == 'event') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count,events.name as event_name,events.id as event_id');
                    if (!$eventJoined) {
                        $this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');
                        
                    }
                    $this->db->join('events', 'kol_events.event_id = events.id', 'left');
                    $this->db->where('events.name IS NOT NULL');
                    $this->db->group_by('events.id');
                }
                if ($groupByCategory == 'list') {
                    $this->db->select('list_kols.list_name_id,list_names.list_name,list_categories.category,COUNT(kols.id) AS count');
                    $this->db->join('list_kols', 'list_kols.kol_id=kols.id', 'left');
                    $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
                    $this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
                    $this->db->where('list_categories.client_id', $client_id);
                    $where = "(list_categories.user_id=$user_id OR list_categories.is_public=1)";
                    $this->db->where($where);
                    $this->db->group_by('list_kols.list_name_id');
                }
                if ($groupByCategory == 'type') {
                    $this->db->select('organization_types.type,organization_types.id as org_type_id,COUNT(DISTINCT kols.id) as count');
                    $this->db->join('organization_types', 'organization_types.id=organizations.type_id', 'left');
//                                        $this->db->join('kols','kols.org_id=organizations.org_id','left');



                    $this->db->group_by('organization_types.id');
                }

                if ($groupByCategory == 'title') {
                    $this->db->select('kols.title,kols.id as kol_type_id,COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('kols.title');
                }

                if ($groupByCategory == 'region') {
                    $this->db->select('countries.GlobalRegion,countries.countryId as region_type_id,COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('countries.GlobalRegion');
                }
                 if ($groupByCategory == 'topic') {
                      if (!$eduJoined) {
                           $this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');

                      }
                    $this->db->join('event_topics', 'event_topics.id = kol_events.topic', 'left');

                    $this->db->select('  `kols`.`id`, count(distinct kols.id) as count,`event_topics`.`name`, `event_topics`.`id` as topic_type_id
');
                    $this->db->group_by('event_topics.name');
                }
                $this->db->order_by('count', 'desc');
            } else
                $this->db->limit($limit, $startFrom);
            $this->db->order_by('kols.first_name');
            if($client_id !== INTERNAL_CLIENT_ID){
            	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
            	$this->db->where('kols_client_visibility.client_id', $client_id);
            }
            //$this->db->where('kols.status', COMPLETED);
            $arrKolDetailsResult = $this->db->get('kols');
            
           //pr($this->db->last_query()); 
            foreach ($arrKolDetailsResult->result_array() as $row) {
                $arrKolDetails[] = $row;
            }
            if (!$doCount) {
                if (!$doGroupBy) {
                    foreach ($arrKolDetails as $key => $row) {
                        if (isset($arrPubsKolsData[$row['id']])) {
                            foreach ($arrPubsKolsData[$row['id']] as $pubFieldName => $pubValue) {
                                $arrKolDetails[$key][$pubFieldName] = $pubValue;
                            }
                        }
                        if (isset($arrEventsKolsData[$row['id']])) {
                            foreach ($arrEventsKolsData[$row['id']] as $eventFieldName => $eventValue) {
                                $arrKolDetails[$key][$eventFieldName] = $eventValue;
                            }
                        }
                        if (isset($arrTrialsKolsData[$row['id']])) {
                            foreach ($arrTrialsKolsData[$row['id']] as $trialFieldName => $trialValue) {
                                $arrKolDetails[$key][$trialFieldName] = $trialValue;
                            }
                        }
                    }
                    $arrKols1 = array();
                    $arrCountryData = array();
                    $arrStateData = array();
                    $arrSpecialtyData = array();
                    $arrOrgsData = array();
                    // calculate relative count
                    $totalRelativeCount = 0;
                    $totalRelativeCount = sizeof($arrAdvSearchFields);
                    foreach ($arrKolDetails as $kolDetails) {
                        $relativeCount = 0;
                        foreach ($kolDetails as $index => $value) {
                            foreach ($arrAdvSearchFields as $key => $input) {
                                if ((preg_match_all('/' . $input . '/i', $value, $matches)) > 0) {
                                    //$relativeCount+=sizeof($matches);
                                    //	echo $input.'-'.$value.'-'.preg_match_all('/'.$input.'/i',$value,$matches).'<br />';
                                    $relativeCount += preg_match_all('/' . $input . '/i', $value, $matches);
                                    //	echo $relativeCount.':';
                                }
                            }
                            //echo $relativeCount.'-';
                            $kolDetails1 = $kolDetails;
                            if ($relativeCount < 1)
                                $relativeCount = 1;
                            if ($relativeCount > $totalRelativeCount)
                                $totalRelativeCount = $relativeCount;

                            //$kolDetails1['relative_count']= round(($relativeCount*100)/$totalRelativeCount);

                            $kolDetails1['relative_count'] = $relativeCount;
                            $kolDetails1['max_count'] = $totalRelativeCount;
                        }
                        //	pr($kolDetails);
                        //	echo '<br />';
                        //$arrKols1[][$relativeCount]=$kolDetails1;
                        $arrKols1[] = array($relativeCount, $kolDetails1);
                        //pr(array($relativeCount,$kolDetails1));
                        $arrCountryData[] = $kolDetails1['country'];
                        $arrStateData[] = $kolDetails1['state'];
                        $arrSpecialtyData[] = array('specialty' => $kolDetails1['specialty'], 'specs' => $kolDetails1['specs']);
                        $arrOrgsData[] = $kolDetails1['name'];
                    }
                    if (isset($arrKols1)) {
                        rsort($arrKols1);
                    }
                    //	pr($arrKols1);
                    if (($startFrom + $limit) < sizeof($arrKols1)) {
                        $endLimit = $startFrom + $limit;
                    } else {
                        $endLimit = sizeof($arrKols1);
                    }
                    //	echo $startFrom.'-'.$endLimit;
                    //	for($i=$startFrom;$i<($endLimit);$i++){
                    for ($i = 0; $i < ($endLimit); $i++) {
                        $arrKols1[$i][1]['relative_count'] = round(($arrKols1[$i][1]['relative_count'] * 100) / $totalRelativeCount);
                        $returnData[] = $arrKols1[$i];
                    }
                    $returnData['maxCount'] = $totalRelativeCount;

                    foreach ($arrCountryData as $index => $countryName) {
                        if (!isset($arrFilterCountryData[$countryName])) {
                            $arrFilterCountryData[$countryName]['country'] = $countryName;
                            $arrFilterCountryData[$countryName]['count'] = 1;
                        } else {
                            $arrFilterCountryData[$countryName]['count'] += 1;
                        }
                    }
                    $returnData['arrCountries'] = $arrFilterCountryData;

                    foreach ($arrStateData as $index => $stateName) {
                        if (!isset($arrFilterStateData[$stateName])) {
                            $arrFilterStateData[$stateName]['state'] = $stateName;
                            $arrFilterStateData[$stateName]['count'] = 1;
                        } else {
                            $arrFilterStateData[$stateName]['count'] += 1;
                        }
                    }
                    $returnData['arrStates'] = $arrFilterStateData;

                    foreach ($arrSpecialtyData as $index => $arrRow) {
                        if (!isset($arrFilterSpecialtyData[$arrRow['specialty']])) {
                            $arrFilterSpecialtyData[$arrRow['specialty']]['specs'] = $specialtyName['specs'];
                            $arrFilterSpecialtyData[$arrRow['specialty']]['specialty'] = $specialtyName['specialty'];
                            $arrFilterSpecialtyData[$arrRow['specialty']]['count'] = 1;
                        } else {
                            $arrFilterSpecialtyData[$arrRow['specialty']]['count'] += 1;
                        }
                    }
                    $returnData['arrSpecialties'] = $arrFilterSpecialtyData;

                    foreach ($arrOrgsData as $index => $orgName) {
                        if (!isset($arrFilterOrgData[$orgName])) {
                            $arrFilterOrgData[$orgName]['name'] = $orgName;
                            $arrFilterOrgData[$orgName]['count'] = 1;
                        } else {
                            $arrFilterOrgData[$orgName]['count'] += 1;
                        }
                    }
                    $returnData['arrOrganizations'] = $arrFilterOrgData;
                    //pr($returnData);
                } else {
                    $returnData = $arrKolDetails;
                }
                return $returnData;
            } else {
                return sizeof($arrKolDetails);
            }
        }
    }

    /**
     * List all  MAtched Events Data 
     * @author 	Ambarish N
     * @since	2.4
     * @created June-07-2011
     * @return $arrEventsDetails/false
     */
    function getMatchEvents($eventName, $arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, $doCount, $doGroupBy = false, $groupByCategory = null) {
        $arrEvents = array();
        if (!$doCount)
            $this->db->select('kol_events.*,events.name,countries.country,conf_session_types.session_type,regions.region as state');
        $this->db->join('events', 'events.id = kol_events.event_id', 'left');
        $this->db->join('countries', 'countries.countryId = kol_events.country_id', 'left');
        $this->db->join('regions', 'regions.regionID = kol_events.state_id', 'left');
        $this->db->join('conf_session_types', 'conf_session_types.id = kol_events.session_type', 'left');
        $this->db->join('online_event_types', 'online_event_types.id = kol_events.event_type', 'left');
        $this->db->join('conf_event_types', 'conf_event_types.id = kol_events.event_type', 'left');

        if ($eventName != '')
            $this->db->like('name', $eventName, 'both');

        //Advance search fields
        if ($arrAdvSearchFields['type'] != '') {
            if ($arrAdvSearchFields['type'] == 'CME' || $arrAdvSearchFields['type'] == 'Symposium' || $arrAdvSearchFields['type'] == 'Seminar' || $arrAdvSearchFields['type'] == 'Workshop' || $arrAdvSearchFields['type'] == 'Grand Round' || $arrAdvSearchFields['type'] == 'Poster Session') {
                $this->db->where('conf_session_types.session_type', $arrAdvSearchFields['type']);
            } else if ($arrAdvSearchFields['type'] == 'CME' || $arrAdvSearchFields['type'] == 'Webcast' || $arrAdvSearchFields['type'] == 'Webinar' || $arrAdvSearchFields['type'] == 'Podcast') {
                $where = "(online_event_types.event_type='" . $arrAdvSearchFields['type'] . "' and kol_events.type='online')";
                $this->db->where($where);
            } else {
                $where = "(conf_event_types.event_type='" . $arrAdvSearchFields['type'] . "' and kol_events.type='conference')";
                $this->db->where($where);
            }
        }
        if ($arrAdvSearchFields['role'] != '') {
            $this->db->like('role', $arrAdvSearchFields['role']);
        }

        if ($arrAdvSearchFields['country'] != '') {
            $this->db->like('country', $arrAdvSearchFields['country']);
        }
        if ($arrAdvSearchFields['state'] != '') {
            $this->db->like('region', $arrAdvSearchFields['state']);
        }
        if ($arrAdvSearchFields['organizer'] != '') {
            $this->db->like('organizer', $arrAdvSearchFields['organizer']);
        }

        //Filter fields
        //if($arrFilterFields['country']!='')
        if ($arrFilterFields != null && $arrFilterFields['country'] != '' && isset($arrFilterFields['country']) && sizeof($arrFilterFields['country']) > 0 && !($doGroupBy == true && $groupByCategory == 'country'))
            $this->db->where_in('countries.country', $arrFilterFields['country']);
        if ($arrFilterFields != null && $arrFilterFields['state'] != '' && isset($arrFilterFields['state']) && sizeof($arrFilterFields['state']) > 0 && !($doGroupBy == true && $groupByCategory == 'state'))
            $this->db->where_in('regions.region', $arrFilterFields['state']);
        //if(isset($arrFilterFields['organizer']))
        if ($arrFilterFields != null && $arrFilterFields['organizer'] != '' && isset($arrFilterFields['organizer']) && sizeof($arrFilterFields['organizer']) > 0 && !($doGroupBy == true && $groupByCategory == 'organizer'))
            $this->db->where_in('organizer', $arrFilterFields['organizer']);
        if ($arrFilterFields != null && $arrFilterFields['role'] != '' && isset($arrFilterFields['role']) && sizeof($arrFilterFields['role']) > 0 && !($doGroupBy == true && $groupByCategory == 'role'))
            $this->db->where_in('role', $arrFilterFields['role']);

        if ($doCount) {
            $this->db->distinct();
            $count = $this->db->count_all_results('kol_events');
            return $count;
        } else {
            if ($doGroupBy) {
                if ($groupByCategory == 'country') {
                    $this->db->select('COUNT(DISTINCT kol_events.id) as count');
                    $this->db->group_by('country_id');
                    //$this->db->where('country IS NOT NULL');
                }
                if ($groupByCategory == 'state') {
                    $this->db->select('COUNT(DISTINCT kol_events.id) as count');
                    $this->db->group_by('state_id');
                    //$this->db->where('country IS NOT NULL');
                }
                if ($groupByCategory == 'organizer') {
                    $this->db->select('COUNT(DISTINCT kol_events.id) as count');
                    $this->db->group_by('organizer');
                    //$this->db->where('name IS NOT NULL');
                }
                if ($groupByCategory == 'role') {
                    $this->db->select('COUNT(DISTINCT kol_events.id) as count');
                    $this->db->group_by('role');
                    //$this->db->where('name IS NOT NULL');
                }
                $this->db->order_by('count', 'desc');
            } else
                $this->db->limit($limit, $startFrom);

            $arrEventDetailsResult = $this->db->get('kol_events');
            foreach ($arrEventDetailsResult->result_array() as $row) {
                $arrEvents[] = $row;
            }
            return $arrEvents;
        }
    }

    /**
     * 	Filter  MAtched Events Data
     * @author 	Ambarish N
     * @since	2.4
     * @created June-07-2011
     * @return $arrEventsDetails/false
     */
    function getFilterMatchEvents($eventName, $arrFilterEvents, $limit, $startFrom, $doCount) {
        $arrEvents = array();
        if (!$doCount)
            $this->db->select('kol_events.*,events.name,countries.country,conf_session_types.session_type,conf_event_types.event_type,online_event_types.event_type');
        $this->db->join('events', 'events.id = kol_events.event_id', 'left');
        $this->db->join('countries', 'countries.countryId = kol_events.country_id', 'left');
        $this->db->join('conf_session_types', 'conf_session_types.id = kol_events.session_type', 'left');
        $this->db->join('conf_event_types', 'conf_event_types.id = kol_events.event_type', 'left');
        $this->db->join('online_event_types', 'online_event_types.id = kol_events.event_type', 'left');
        $this->db->like('name', $eventName);
        if ($arrFilterEvents['type'] != '') {
            $this->db->where('conf_session_types.session_type', $arrFilterEvents['type']);
        }
        if ($arrFilterEvents['role'] != '') {
            $this->db->like('role', $arrFilterEvents['role']);
        }

        if ($arrFilterEvents['country'] != '') {
            $this->db->like('country', $arrFilterEvents['country']);
        }
        if ($arrFilterEvents['organizer'] != '') {
            $this->db->like('organizer', $arrFilterEvents['organizer']);
        }

        if ($doCount) {
            $this->db->distinct();
            $count = $this->db->count_all_results('kol_events');
            return $count;
        } else {
            $this->db->limit($limit, $startFrom);
            $arrEventDetailsResult = $this->db->get('kol_events');
            foreach ($arrEventDetailsResult->result_array() as $row) {
                $arrEvents[] = $row;
            }
            return $arrEvents;
        }
    }

    /**
     * 	Advance seearch  MAtched Events Data 
     * @author 	Ambarish N
     * @since	2.4
     * @created June-07-2011
     * @return $arrEventsDetails/false
     */
    function getAdvSearchMatchingEvents($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, $doCount, $doGroupBy = false, $groupByCategory = null) {
        $arrEvents = array();
        if (!$doCount)
            $this->db->select('kol_events.*,events.name,countries.country,conf_session_types.session_type,conf_event_types.event_type,online_event_types.event_type,regions.region as state');
        $this->db->join('events', 'events.id = kol_events.event_id', 'left');
        $this->db->join('countries', 'countries.countryId = kol_events.country_id', 'left');
        $this->db->join('regions', 'regions.regionID = kol_events.state_id', 'left');
        $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
        $this->db->join('conf_session_types', 'conf_session_types.id = kol_events.session_type', 'left');
        $this->db->join('conf_event_types', 'conf_event_types.id = kol_events.event_type', 'left');
        $this->db->join('online_event_types', 'online_event_types.id = kol_events.event_type', 'left');
        $this->db->where('kols.status', COMPLETED);
        //Advance search fields
        if ($arrAdvSearchFields['type'] != '') {
            /* 	if($arrAdvSearchFields['type']=='CME' ||$arrAdvSearchFields['type']=='Symposium' ||$arrAdvSearchFields['type']=='Seminar' ||$arrAdvSearchFields['type']=='Workshop' ||$arrAdvSearchFields['type']=='Grand Round' ||$arrAdvSearchFields['type']=='Poster Session'){
              $this->db->where('conf_session_types.session_type',$arrAdvSearchFields['type']);
              }else if($arrAdvSearchFields['type']=='CME' ||$arrAdvSearchFields['type']=='Webcast' ||$arrAdvSearchFields['type']=='Webinar'||$arrAdvSearchFields['type']=='Podcast'){
              $where="(online_event_types.event_type='".$arrAdvSearchFields['type']."' and kol_events.type='online')";
              $this->db->where($where);
              }
              else {
             */
            $where = "(conf_event_types.event_type='" . $arrAdvSearchFields['type'] . "' and kol_events.type='conference')";
            $this->db->where($where);
            //	}
        }
        if ($arrAdvSearchFields['role'] != '') {
            $this->db->like('role', $arrAdvSearchFields['role']);
        }

        if ($arrAdvSearchFields['country'] != '') {
            $this->db->like('country', $arrAdvSearchFields['country']);
        }
        if ($arrAdvSearchFields['state'] != '') {
            $this->db->like('region', $arrAdvSearchFields['state']);
        }
        if ($arrAdvSearchFields['organizer'] != '') {
            $this->db->like('organizer', $arrAdvSearchFields['organizer']);
        }

        //Filter fields
        //	if($arrFilterFields['country']!='')
        if ($arrFilterFields != null && $arrFilterFields['country'] != '' && isset($arrFilterFields['country']) && sizeof($arrFilterFields['country']) > 0 && !($doGroupBy == true && $groupByCategory == 'country'))
            $this->db->where_in('countries.country', $arrFilterFields['country']);
        if ($arrFilterFields != null && $arrFilterFields['state'] != '' && isset($arrFilterFields['state']) && sizeof($arrFilterFields['state']) > 0 && !($doGroupBy == true && $groupByCategory == 'state'))
            $this->db->where_in('regions.region', $arrFilterFields['state']);
        //if($arrFilterFields!=null && $arrFilterFields['organization']!='' && isset($arrFilterFields['organization']) && sizeof($arrFilterFields['organization'])>0 && !($doGroupBy==true && $groupByCategory=='organization'))
        //$this->db->where_in('organizations.name', $arrFilterFields['organization']);
        //if(isset($arrFilterFields['organizer']))
        if ($arrFilterFields != null && $arrFilterFields['organizer'] != '' && isset($arrFilterFields['organizer']) && sizeof($arrFilterFields['organizer']) > 0 && !($doGroupBy == true && $groupByCategory == 'organizer'))
            $this->db->where_in('organizer', $arrFilterFields['organizer']);
        if ($arrFilterFields != null && $arrFilterFields['role'] != '' && isset($arrFilterFields['role']) && sizeof($arrFilterFields['role']) > 0 && !($doGroupBy == true && $groupByCategory == 'role'))
            $this->db->where_in('role', $arrFilterFields['role']);


        if ($doCount) {
            //	$this->db->distinct();
            //	$count=$this->db->count_all_results('kol_event');

            $this->db->select('COUNT(DISTINCT kol_events.id) AS count');
            $arrKolDetailsResult = $this->db->get('kol_events');
            $resultRow = $arrKolDetailsResult->row();
            $count = $resultRow->count;
            //	echo "-----".$this->db->last_query().'-----';
            return $count;
        } else {
            if ($doGroupBy) {
                if ($groupByCategory == 'country') {
                    $this->db->select('COUNT(DISTINCT kol_events.id) as count');
                    $this->db->group_by('country_id');
                    //$this->db->where('country IS NOT NULL');
                }
                if ($groupByCategory == 'state') {
                    $this->db->select('COUNT(DISTINCT kol_events.id) as count');
                    $this->db->group_by('state_id');
                    //$this->db->where('country IS NOT NULL');
                }
                if ($groupByCategory == 'organizer') {
                    $this->db->select('COUNT(DISTINCT kol_events.id) as count');
                    $this->db->group_by('organizer');
                    //$this->db->where('name IS NOT NULL');
                }
                if ($groupByCategory == 'role') {
                    $this->db->select('COUNT(DISTINCT kol_events.id) as count');
                    $this->db->group_by('role');
                    //$this->db->where('name IS NOT NULL');
                }

                $this->db->order_by('count', 'desc');
            } else
                $this->db->limit($limit, $startFrom);
            $arrEventDetailsResult = $this->db->get('kol_events');
            //	echo $this->db->last_query();
            foreach ($arrEventDetailsResult->result_array() as $row) {
                $arrEvents[] = $row;
            }

            return $arrEvents;
        }
    }

    /*
     * Getiing evnt data for "event_micro_view" by passing event Id
     *
     *
     */

    function getEventMicroData($eventId) {
        $arrEvents = array();
        $this->db->select('kol_events.*,event_topics.name as topic_name, events.name,countries.country,conf_session_types.session_type,regions.region');
        $this->db->join('events', 'events.id = kol_events.event_id', 'left');
        $this->db->join('countries', 'countries.countryId = kol_events.country_id', 'left');
        $this->db->join('regions', 'regions.regionId = kol_events.state_id', 'left');
        $this->db->join('conf_session_types', 'conf_session_types.id = kol_events.session_type', 'left');
        $this->db->join('event_topics', 'event_topics.id=kol_events.topic');
        $this->db->where('kol_events.id', $eventId);
        $arrEventDetailsResult = $this->db->get('kol_events');
        foreach ($arrEventDetailsResult->result_array() as $row) {

            $row['date'] = $row['start'] . '/' . $row['end'];
            if ($row['date'] == '0000-00-00/0000-00-00') {
                $row['date'] = '';
            }
            $arrEvents[] = $row;
        }
        return $arrEvents;
    }

    /**
     * Counts the number each affilition types for one kol
     *
     * @param unknown_type $kolId
     * @return array $arrAffiliations
     */
    function getAffiliationChart($kolId) {
        $arrAffiliations = array();
        $this->db->select('type,count(*) as count');
        $this->db->where('kol_id', $kolId);
        $this->db->group_by('type');
        $this->db->order_by('type');

        $arrAffiliationsResult = $this->db->get('kol_memberships');
        foreach ($arrAffiliationsResult->result_array() as $row) {
            $arrAffiliations[] = $row;
        }
        //pr($arrAffiliations);
        return $arrAffiliations;
    }

    /**
     * Counts the number publication processed for each year for one kol
     *
     * @param unknown_type $kolId
     * @return array $arrPublications
     */
    function getPublicationChart($kolId, $fromYear, $toYear, $keyword) {
        $arrPublications = array();
        $this->db->select('year(created_date) as year,count(distinct kol_publications.pub_id) as count');
        $this->db->join('kol_publications', 'kol_publications.pub_id = publications.id', 'left');
        if ($keyword != '') {
            $this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id', 'left');
            $this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id', 'left');
            $this->db->join('publication_substances', 'publication_substances.pub_id=publications.id', 'left');
            $this->db->join('pubmed_substances', 'pubmed_substances.id=publication_substances.substance_id', 'left');
            $this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
        }

        $this->db->where('kol_id', $kolId);
        $this->db->where('kol_publications.is_deleted', 0);
        $this->db->where('kol_publications.is_verified', 1);
        if ($fromYear != 0 && $toYear != 0)
            $this->db->where('year(publications.created_date) between ' . $fromYear . ' and ' . $toYear);
        $this->db->group_by('year(created_date)');
        $this->db->order_by('year(created_date)', 'desc');
        //$this->db->limit('15');

        $arrPublicationsResult = $this->db->get('publications');
        foreach ($arrPublicationsResult->result_array() as $row) {
            $arrPublications[] = $row;
        }
        //pr($arrPublications);
        return $arrPublications;
    }

    /**
     * Counts the number of Online "Event types" for one kol
     *
     * @param unknown_type $kolId
     * @return array $arrOnlineEvents
     */
    function getOnlineEventsChart($kolId, $fromYear, $toYear) {
        $arrOnlineEvents = array();
        $this->db->select('online_event_types.event_type,count(*) as count');
        $this->db->join('online_event_types', 'online_event_types.id = kol_events.event_type', 'left');
        $this->db->where("(year(kol_events.start) between  " . $fromYear . "  and  " . $toYear . "  or year(kol_events.start)=0)");

        $this->db->where('kol_id', $kolId);
        $this->db->where('kol_events.type', 'online');
        $this->db->where_not_in('kol_events.event_type', '0');

        $this->db->group_by('kol_events.event_type');
        $this->db->order_by('online_event_types.event_type');

        $arrOnlineEventsResult = $this->db->get('kol_events');
        foreach ($arrOnlineEventsResult->result_array() as $row) {
            $arrOnlineEvents[] = $row;
        }
        //pr($arrOnlineEvents);
        return $arrOnlineEvents;
    }

    /**
     * Counts the number of Conference "Event types" for one kol
     *
     * @param unknown_type $kolId
     * @return array $arrConferenceEvents
     */
    function getConferenceEventsChart($kolId, $fromYear, $toYear) {
        $arrConferenceEvents = array();
        $this->db->select('conf_event_types.event_type,count(*) as count');
        $this->db->join('conf_event_types', 'conf_event_types.id = kol_events.event_type', 'left');
        $this->db->where("(year(kol_events.start) between  " . $fromYear . "  and  " . $toYear . "  or year(kol_events.start)=0)");

        $this->db->where('kol_id', $kolId);
        //Right now not using conf_event_types of id=3(its deleted), by default event_type value is '0'
        $this->db->where('kol_events.type', 'conference');
        $this->db->where_not_in('kol_events.event_type', '0');
        //$this->db->where_not_in('kol_events.event_type','3');

        $this->db->group_by('kol_events.event_type');
        $this->db->order_by('conf_event_types.event_type');

        $arrConferenceEventsResult = $this->db->get('kol_events');
        //echo $this->db->last_query();
        foreach ($arrConferenceEventsResult->result_array() as $row) {
            $arrConferenceEvents[] = $row;
        }
        //pr($arrConferenceEvents);
        return $arrConferenceEvents;
    }

    /**
     * Counts the number of Major Meshterm for one kol
     *
     * @param unknown_type $kolId
     * @return array $arrMajorMeshterm
     */
    function getPubMajorMeshTermChart($kolId, $fromYear, $toYear, $keyword) {
        $arrMajorMeshterm = array();
        $this->db->select('pubmed_mesh_terms.id,pubmed_mesh_terms.term_name as mesh_term,count(distinct kol_publications.pub_id) as count,pubmed_mesh_terms.parent_id');
        $this->db->join('publication_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id', 'left');
        $this->db->join('publications', 'publications.id = publication_mesh_terms.pub_id', 'left');
        $this->db->join('kol_publications', 'kol_publications.pub_id = publications.id', 'left');

        if ($keyword != '') {
            //$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
            //$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
            $this->db->join('publication_substances', 'publication_substances.pub_id=publications.id', 'left');
            $this->db->join('pubmed_substances', 'pubmed_substances.id=publication_substances.substance_id', 'left');
            $this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
        }
        $this->db->where('kol_publications.is_deleted', 0);
        $this->db->where('kol_publications.is_verified', 1);
        $this->db->where('kol_id', $kolId);
        $this->db->where('publication_mesh_terms.is_major', '1');
        $this->db->where('year(publications.created_date) between ' . $fromYear . ' and ' . $toYear);
        $this->db->group_by('pubmed_mesh_terms.term_name,pubmed_mesh_terms.parent_id');
        $this->db->order_by('count', 'desc');
        $this->db->limit('20');

        $arrMajorMeshtermResult = $this->db->get('pubmed_mesh_terms');
        foreach ($arrMajorMeshtermResult->result_array() as $row) {
            $arrMajorMeshterm[] = $row;
        }
        //echo $this->db->last_query();
        //pr($arrMajorMeshterm);
        return $arrMajorMeshterm;
    }

    /**
     * Edit kol details
     * @param $id
     * @return array - $arrKolDetail
     */
    function getKolMicroData($id) {
        $arrKolDetails = array();

        $this->db->select('kols.unique_id,kols.opt_in_out_status,kols.salutation,kols.first_name,kols.middle_name,kols.last_name,kols.suffix,kols.postal_code,kols.address1,kols.address2,kols.license,titles.title,kols.division,kols.status,kols.profile_image,kols.gender,kols.fax,kols.primary_phone,kols.primary_email,kols.org_id,kols.unique_id,countries.country,organizations.status as org_status,organizations.name,specialties.specialty as specialty_name,regions.region as state,regions.code as state_code,cities.city as city,kols.profile_type,kol_locations.private_practice');
        $this->db->join('specialties', 'specialties.id = kols.specialty', 'left');
        $this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
        $this->db->join('regions', 'regions.regionID = kols.state_id', 'left');
        $this->db->join('cities', 'cities.cityID = kols.city_id', 'left');
        $this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
        $this->db->where('kols.id', $id);
        $this->db->join('titles', 'kols.title = titles.id', 'left');
        $this->db->join('kol_locations', 'kols.id = kol_locations.kol_id', 'left');
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
            $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
            $this->db->where('kols_client_visibility.client_id', $client_id);
        }
        if ($arrKolDetailResult = $this->db->get('kols')) {
            // If the results are not available
            if ($arrKolDetailResult->num_rows() == 0) {
                return false;
            }

            foreach ($arrKolDetailResult->result_array() as $arrKol) {  		
                        		
                $arrKolDetails[] = $arrKol;
            }
            return $arrKolDetails;
        } else {
            return false;
        }
    }

    /**
     * Returns the no of kols in the application
     * @return unknown_type
     */
    function countKols() {
        $count = '';
        //$this->db->where('status', COMPLETED);
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
            $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
            $this->db->where('kols_client_visibility.client_id', $client_id);
        }
        if ($count = $this->db->count_all_results('kols')) {
            return $count;
        } else {
            return false;
        }
    }

    /**
     * Counts the number kols based on country
     * @return unknown_type
     */
    function getKolsCountByCountry() {
        $arrKolsCount = array();
        $this->db->select('countries.Country,count(*) as count');
        $this->db->join('countries', 'countries.CountryId = kols.country_id', 'left');
        $this->db->where_not_in('kols.country_id', '0');
        $this->db->group_by('kols.country_id');
        $this->db->order_by('count', 'desc');

        $arrKolsCountResult = $this->db->get('kols');
        foreach ($arrKolsCountResult->result_array() as $row) {
            $arrKolsCount[] = $row;
        }
        //pr($arrKolsCount);
        return $arrKolsCount;
    }

    /**
     * Returns the no of kols in the application
     * @return unknown_type
     */
    function getKolCountBySpecialty() {
        $arrKolCount = array();
        $this->db->select('specialties.specialty,count(specialties.specialty) as count');
        $this->db->join('specialties', 'specialties.id=kols.specialty', 'left');
        $this->db->group_by('specialties.specialty');
        $this->db->where_not_in('kols.specialty', '0');
        $arrCount = $this->db->get('kols');
        foreach ($arrCount->result_array() as $row) {
            //$row['specialty']=$row['count'];
            $arrKolCount[] = $row;
        }
        return $arrKolCount;
    }

    /**
     * Returns the  no of "co_authors" of kol in the application
     * @return unknown_type
     */
    function getKolCoAuthFreqency($id, $fromYear, $toYear, $arrKolName, $forInfluence = null, $keyword) {

        $arrSuffixes = array("Sr.", "Sr", "Jr.", "Jr", "I", "II", "III", "IV");
        $arrLastNameWords = explode(" ", $arrKolName['last_name']);
        $numWords = sizeof($arrLastNameWords);
        if ($numWords > 1) {
            $lastWord = $arrLastNameWords[$numWords - 1];
            if (in_array($lastWord, $arrSuffixes)) {
                unset($arrLastNameWords[$numWords - 1]);
                $arrKolName['last_name'] = implode(" ", $arrLastNameWords);
            }
        }

        $lastName = trim($arrKolName['last_name'], ".");
        $middleName = trim($arrKolName['middle_name'], ".");
        //If Fore name contains only first name
        $foreName = trim($arrKolName['first_name'], ".");

        $firstCharOfFMname = substr($foreName, 0, 1) . ' ' . substr($middleName, 0, 1);

        $FnameMnameOfFchar = $foreName . ' ' . substr($arrKolName['middle_name'], 0, 1);

        //If Fore name contains first name & middle name
        $foreNameFM = $arrKolName['first_name'] . ' ' . $arrKolName['middle_name'];
        ;

        //If Fore name contains first name of First Char
        $foreNameFirstChar = substr($arrKolName['first_name'], 0, 1);

        //If Fore name contains Middle name of First Char
        $foreNameMiddleNameFirstChar = substr($arrKolName['middle_name'], 0, 1);

        //If Fore name contains first name of First Char  & middle name
        $foreNameFirstCharM = substr($arrKolName['first_name'], 0, 1) . ' ' . $arrKolName['middle_name'];

        $firstNameMiddleNameFirstChar = trim(substr($arrKolName['first_name'], 0, 1) . "" . substr($arrKolName['middle_name'], 0, 1));

        //Get KOL name combinations from the database if any
        $enteredNameCombinations = '';
        //Old method given name combinaions
        /* $commaSepNames = implode(",",$arrNameCombinations);
          $commaSepNames = "(\"" . str_replace(",", "\",\"", $commaSepNames) . "\")";
          $enteredNameCombinations = 'OR CONCAT(pubmed_authors.last_name," ",pubmed_authors.initials) IN '.$commaSepNames.' OR CONCAT(pubmed_authors.last_name," ",pubmed_authors.fore_name) IN'.$commaSepNames; */
        //New method, using inline query
        $enteredNameCombinations = 'OR CONCAT(pubmed_authors.last_name," ",pubmed_authors.initials) IN (select name from kol_name_combinations where kol_id =' . $id . ') OR CONCAT(pubmed_authors.last_name," ",pubmed_authors.fore_name) IN (select name from kol_name_combinations where kol_id =' . $id . ')';

        $arrCOAuthCount = array();
        $this->db->select('pubmed_authors.id,pubmed_authors.last_name,pubmed_authors.initials,pubmed_authors.fore_name,COUNT(distinct kol_publications.pub_id) as count');
        $this->db->join('publications', 'kol_publications.pub_id=publications.id', 'left');
        $this->db->join('publications_authors', 'publications_authors.pub_id = kol_publications.pub_id', 'left');
        $this->db->join('pubmed_authors', 'publications_authors.alias_id = pubmed_authors.id', 'left');
        if ($keyword != '') {
            $this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id', 'left');
            $this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id', 'left');
            $this->db->join('publication_substances', 'publication_substances.pub_id=publications.id', 'left');
            $this->db->join('pubmed_substances', 'pubmed_substances.id=publication_substances.substance_id', 'left');
            $this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
        }
        $this->db->group_by('pubmed_authors.last_name,pubmed_authors.initials,pubmed_authors.fore_name');
        $this->db->order_by('count', 'desc');
        if (!isset($forInfluence))
            $this->db->limit('20');
        $this->db->where('kol_publications.kol_id', $id);
        $this->db->where('kol_publications.is_deleted', 0);
        $this->db->where('kol_publications.is_verified', 1);
        if ($fromYear != 0 && $toYear != 0)
            $this->db->where('year(publications.created_date) between ' . $fromYear . ' and ' . $toYear);
        $where = "!((last_name='Not Available' ) and (fore_name='Not Available'))";
        $where1 = "!((last_name=\"$lastName\" and fore_name=\"$foreName\") OR (last_name=\"$lastName\" and fore_name=\"$foreNameFM\") OR (last_name=\"$lastName\" and fore_name=\"$foreNameFirstCharM\") OR (last_name=\"$lastName\" and fore_name=\"$foreNameFirstChar\") OR (last_name=\"$lastName\" and fore_name=\"$middleName\") OR (last_name=\"$lastName\" and fore_name=\"$foreNameMiddleNameFirstChar\") OR(last_name=\"$lastName\" and fore_name=\"$firstCharOfFMname\")OR(last_name=\"$lastName\" and fore_name=\"$FnameMnameOfFchar\") OR(last_name=\"$lastName\" and initials=\"$firstNameMiddleNameFirstChar\") $enteredNameCombinations)";
        //$where="!(last_name='' and fore_name='Christopher P')";
        $this->db->where($where);
        $this->db->where($where1);

        $arrCOAuth = $this->db->get('kol_publications');
        foreach ($arrCOAuth->result_array() as $row) {
            $arrCOAuthCount[$row['id']] = $row;
        }
        return $arrCOAuthCount;
    }

    /**
     * Counts the number Events based on each kolId
     * @return unknown_type
     */
    function getEventsCountOfAllKols() {
        $arrEventsCount = array();
        $this->db->select('kol_id,COUNT(kol_id) as cnt_events');
        $this->db->group_by('kol_id');

        $arrEventsCountResult = $this->db->get('kol_events');
        foreach ($arrEventsCountResult->result_array() as $row) {
            $arrEventsCount[] = $row;
        }
        //pr($arrEventsCount);
        return $arrEventsCount;
    }

    /**
     * Counts the number Affiliations based on each kolId
     * @return unknown_type
     */
    function getAffsCountOfAllKols() {
        $arrAffsCount = array();
        $this->db->select('kol_id,COUNT(kol_id) as cnt_affiliations');
        $this->db->group_by('kol_id');

        $arrAffsCountResult = $this->db->get('kol_memberships');
        foreach ($arrAffsCountResult->result_array() as $row) {
            $arrAffsCount[] = $row;
        }
        //pr($arrAffsCount);
        return $arrAffsCount;
    }

    /**
     * Counts the number Publications based on each kolId
     * @return unknown_type
     */
    function getPublicationsCountOfAllKols() {
        $arrPublicationsCount = array();
        $this->db->select('kol_id,COUNT(kol_id) as cnt_publications');
        $this->db->group_by('kol_id');
        $this->db->where('kol_publications.is_deleted', 0);
        $this->db->where('kol_publications.is_verified', 1);

        $arrPublicationsCountResult = $this->db->get('kol_publications');
        foreach ($arrPublicationsCountResult->result_array() as $row) {
            $arrPublicationsCount[] = $row;
        }
        //pr($arrPublicationsCount);
        return $arrPublicationsCount;
    }

    /**
     * Counts the number Trials based on each kolId
     * @return unknown_type
     */
    function getTrialsCountOfAllKols() {
        $arrTrialsCount = array();
        $this->db->select('kol_id,COUNT(kol_id) as cnt_trials');
        $this->db->group_by('kol_id');

        $arrTrialsCountResult = $this->db->get('kol_clinical_trials');
        foreach ($arrTrialsCountResult->result_array() as $row) {
            $arrTrialsCount[] = $row;
        }
        //pr($arrTrialsCount);
        return $arrTrialsCount;
    }

    /**
     *  GET kol Names
     * @param
     * @return array - $arrKolDetail - Returns
     */
    function getKolNames($arrIds = "",$restrictByRegion=0) {
    	$client_id = $this->session->userdata('client_id');
        $arrKolDetail = array();
        $this->db->select('kols.id,kols.unique_id,kols.salutation,kols.first_name,kols.middle_name,kols.last_name,kols.status');
        if ($arrIds != "" && is_array($arrIds))
            $this->db->where_in('kols.id', $arrIds);
        
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
        	$this->db->where('kols_client_visibility.client_id', $client_id);
        
        	if($restrictByRegion && $this->session->userdata('user_role_id') != ROLE_ADMIN){
        	    $group_names = explode(',', $this->session->userdata('group_names'));
        	    $this->db->join ( 'countries', 'countries.CountryId=kols.country_id', 'left' );
        	    $this->db->where_in( 'countries.GlobalRegion', $group_names);
        	}
        }        
        $this->db->order_by('kols.first_name');
        
        $arrKolDetailResult = $this->db->get('kols');
        
        foreach ($arrKolDetailResult->result_array() as $row) {
            $arrKolDetail[] = $row;
        }
        return $arrKolDetail;
    }

    function getEventTypesCountByTimeLine($fromYear = 0, $toYear = 0, $arrKolIds = 0, $arrCountries = 0, $arrSpecialities = 0, $arrListNamesIds = 0, $arrStatesIds = 0, $profileType, $viewType, $arrGlobalRegionIds = 0) {

        $sqlQuery = "SELECT conf_event_types.event_type, COUNT(distinct kol_events.event_id) as count, YEAR(kol_events.start) as year
										FROM kol_events
										LEFT JOIN conf_event_types ON conf_event_types.id=kol_events.event_type
										LEFT JOIN kols ON kols.id=kol_events.kol_id 
        								left join countries on kols.country_id=countries.countryId
										";
        
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$sqlQuery .= "left join kols_client_visibility on kols_client_visibility.kol_id = kols.id";
        }
        if ($arrListNamesIds != '' && $arrListNamesIds != 0) {

            $userId = $this->session->userdata('user_id');
            $clientId = $this->session->userdata('client_id');

            $commaistNamesIds = $this->common_helpers->convertArrayToCommaSeparatedElements($arrListNamesIds);
            $sqlQuery .= " left join list_kols on list_kols.kol_id=kol_events.kol_id
	 		                 left join  list_names on list_kols.list_name_id=list_names.id
	 		                 left join list_categories on list_names.category_id=list_categories.id
            				 ";
            // $sqlQuery	.=             "and list_names.id in ($commaistNamesIds) and ((list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 )))";
            //$this->db->join('list_kols','list_kols.kol_id=kol_events.kol_id','left');
            //$this->db->join('list_names','list_kols.list_name_id=list_names.id','left');
            ////$this->db->join('list_categories','list_names.category_id=list_categories.id','left');
            //$this->db->where_in('list_names.id',$arrListNamesIds);
            //$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
        }
        $sqlQuery .= " WHERE 	`kol_events`.`event_type` != 'null' 
						AND YEAR(kol_events.start)!='' ";

        if($client_id !== INTERNAL_CLIENT_ID){
        	$sqlQuery .= " AND kols_client_visibility.client_id=".$client_id;
        }
        //Adding where condition for Kol's if Exist
        if (is_array($arrKolIds)) {
            $commaKolIds = $this->common_helpers->convertArrayToCommaSeparatedElements($arrKolIds);
            $sqlQuery .= " AND kol_events.kol_id IN($commaKolIds) ";
        } else if ($arrKolIds != 0) {
            $sqlQuery .= " AND kol_events.kol_id='$arrKolIds' ";
        }
		
        //Adding where condition for Country's if Exist
        if (is_array($arrGlobalRegionIds) && sizeof($arrGlobalRegionIds) > 0) {
        	//$commaGlobalRegion = $this->common_helpers->convertArrayToCommaSeparatedElements($arrGlobalRegionIds);
        	$count = sizeof($arrGlobalRegionIds);
        		$i;
        		$commaGlobalRegion = '';
        		$seprator = '';
	        		foreach($arrGlobalRegionIds as $value){
	        			$commaGlobalRegion .= $seprator."'".$value."'"; 
	        			$seprator = ',';
	        			$i++;
	        		}
        	$sqlQuery .= " AND countries.GlobalRegion IN($commaGlobalRegion) ";
        }
        
        //Adding where condition for Country's if Exist
        if (is_array($arrCountries) && sizeof($arrCountries) > 0) {
            $commaCountries = $this->common_helpers->convertArrayToCommaSeparatedElements($arrCountries);
            $sqlQuery .= " AND kols.country_id IN($commaCountries) ";
        }

        if (is_array($arrStatesIds)) {
            $commaStates = $this->common_helpers->convertArrayToCommaSeparatedElements($arrStatesIds);
            $sqlQuery .= " AND kols.state_id IN($commaStates) ";
        } else if ($arrStatesIds != 0) {
            $sqlQuery .= " AND kols.state_id='$arrStatesIds' ";
        }

        //Adding where condition for Speciality's if Exist
        if (is_array($arrSpecialities) && sizeof($arrSpecialities) > 0) {
            $arrEventDatails = array();
            $commaSpecialities = $this->common_helpers->convertArrayToCommaSeparatedElements($arrSpecialities);
            $sqlQuery .= " AND kols.specialty IN($commaSpecialities) ";
        }

        //Adding year range condition
        //	if($fromYear!=0 && $toYear!=0)
        //	$sqlQuery	.=" AND YEAR(kol_events.start) BETWEEN '$fromYear' AND '$toYear' ";
        /* 	$sqlQuery	.= " GROUP BY kol_events.event_type, YEAR(kol_events.start) UNION ALL ";
          $sqlQuery	.= " SELECT online_event_types.event_type, COUNT(kol_events.event_type) as count, YEAR(kol_events.start) as year
          FROM kol_events
          LEFT JOIN online_event_types ON online_event_types.id=kol_events.event_type
          LEFT JOIN kols ON kols.id=kol_events.kol_id
          WHERE 	kol_events.type = 'online' AND
          kol_events.event_type = online_event_types.id AND YEAR(kol_events.start)!='' ";
         */
        //Adding where condition for Kol's if Exist
     /*    if (is_array($arrKolIds)) {
            $commaKolIds = $this->common_helpers->convertArrayToCommaSeparatedElements($arrKolIds);
            $sqlQuery .= " AND kol_events.kol_id IN($commaKolIds) ";
        } else if ($arrKolIds != 0) {
            $sqlQuery .= " AND kol_events.kol_id='$arrKolIds' ";
        } */

        //Adding where condition for Country's if Exist
        if (is_array($arrCountries) && sizeof($arrCountries) > 0) {
            $sqlQuery .= " AND kols.country_id IN($commaCountries) ";
        }

        if (is_array($arrStatesIds)) {
            $sqlQuery .= " AND kols.state_id IN($commaStates) ";
        } else if ($arrStatesIds != 0) {
            $sqlQuery .= " AND kols.state_id='$arrStatesIds' ";
        }

        //Adding where condition for Speciality's if Exist
        if (is_array($arrSpecialities) && sizeof($arrSpecialities) > 0) {
            $sqlQuery .= " AND kols.specialty IN($commaSpecialities) ";
        }
        if ($profileType != '') {
            $sqlQuery .= " AND kols.profile_type='$profileType' ";
//			$this->db->where('kols.profile_type',$profileType);
        }
        if (isset($viewType) && sizeof($viewType) > 0) {
            $viewType = implode(",", $viewType);
            $sqlQuery .= " AND kols.id IN($viewType) ";
//			$this->db->where_in('kols.id',$viewType);
        }
        if ($arrListNamesIds != '' && $arrListNamesIds != 0) {

            //$userId   =$this->session->userdata('user_id');
            //$clientId =$this->session->userdata('client_id');
            //$commaistNamesIds=$this->common_helpers->convertArrayToCommaSeparatedElements($arrListNamesIds);
            //$sqlQuery	.= " left join list_kols on list_kols.kol_id=kol_events.kol_id
            //                 left join  list_names on list_kols.list_name_id=list_names.id
            //               left join list_categories on list_names.category_id=list_categories.id" ;
            $sqlQuery .= " and list_names.id in ($commaistNamesIds) and ((list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 )))";
            //$this->db->join('list_kols','list_kols.kol_id=kol_events.kol_id','left');
            //$this->db->join('list_names','list_kols.list_name_id=list_names.id','left');
            ////$this->db->join('list_categories','list_names.category_id=list_categories.id','left');
            //$this->db->where_in('list_names.id',$arrListNamesIds);
            //$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
        }
        //Adding year range condition
        if ($fromYear != 0 && $toYear != 0)
            $sqlQuery .=" AND (YEAR(kol_events.start) BETWEEN '$fromYear' AND '$toYear' OR year(kol_events.start)=0)";

        $sqlQuery .=" GROUP BY kol_events.event_type, YEAR(kol_events.start)";
        
        
        $result = $this->db->query($sqlQuery);
       //pr($this->db->last_query());exit;
        foreach ($result->result_array() as $row) {
            $arrEventDatails[] = $row;
        }

        return $arrEventDatails;
    }

    /**
     *  GET kol Names
     * @param
     * @return array - $arrKolDetail - Returns
     *
     */
    function getAllAffiliations() {
        $arrAffiliationsDetail = array();
        $this->db->select('type,count(id) as count');
        $this->db->where_not_in('type', '0');
        $this->db->groupby('type');

        $arrAffiliations = $this->db->get('kol_memberships');
        foreach ($arrAffiliations->result_array() as $row) {
            $arrAffiliationsDetail[] = $row;
        }
        return $arrAffiliationsDetail;
    }

    /**
     * Counts the number kols based on Event Types
     * @return unknown_type
     */
    function getKolsCountByEventType() {
        $arrKolsCount = array();
        $arrKolsCountResult = $this->db->query("select online_event_types.event_type,count(*) as count from kol_events
							LEFT JOIN online_event_types ON online_event_types.id=kol_events.event_type 
							where kol_events.type='online' AND kol_events.event_type<>0 group by kol_events.event_type 
							UNION ALL
							select conf_event_types.event_type,count(*) as count from kol_events 
							LEFT JOIN conf_event_types ON conf_event_types.id=kol_events.event_type 
							where kol_events.type='conference' AND kol_events.event_type<>3 AND kol_events.event_type<>0 group by kol_events.event_type");

        foreach ($arrKolsCountResult->result_array() as $row) {
            $arrKolsCount[] = $row;
        }
        return $arrKolsCount;
    }

    /**
     * Get the full name of  kol
     * @param $KolId
     * @author Vinayak malladad
     * @since 1.5
     * @Ceated on 4/3/11
     * @return array  $arrKolName
     */
    function getKolName($id) {
        $arrKol = array();
        $this->db->select('id,unique_id,salutation,first_name,middle_name,last_name,suffix,status');
        $this->db->where('id', $id);
        $arrKolNameresult = $this->db->get('kols');
        foreach ($arrKolNameresult->result_array() as $row) {
            $arrKol = $row;
        }
        return $arrKol;
    	
    }

    /**
     * Generates the Affiliations chart Based on the parameters passed
     *
     * @param unknown_type $fromYear
     * @param unknown_type $toYear
     * @param unknown_type $arrKolIds
     * @param unknown_type $arrEngTypeIds
     * @param unknown_type $arrOrgType
     * @param unknown_type $arrCountries
     * @param unknown_type $arrSpecialities
     * @param unknown_type $selectType
     * @return unknown_type
     */
    function getAffiliationsByParam($fromYear, $toYear, $arrKolIds = 0, $arrEngTypes = '', $arrOrgType = '', $arrCountries = 0, $arrSpecialities = 0, $selectType, $arrListNamesIds = 0, $arrStates = 0, $arrProfileType = '', $viewType=array(), $arrGlobalRegionIds = 0, $analystSelectedClientId = 0) {
        $arrAffiliationsDetail = array();
        $isKolsJoined = false;

        $referer = $_SERVER['HTTP_REFERER'];
        $arrSegments = explode('/', $referer);
        $referer = $arrSegments[sizeof($arrSegments) - 1];

        $countType = 'kol_memberships.id';
        if ($referer == 'affiliations' || $referer == 'affiliations#')
            $countType = 'kol_memberships.institute_id';

        $this->db->select($selectType . ',count(DISTINCT ' . $countType . ') as count');
        if ($fromYear != 0 && $toYear != 0) {
            //	$this->db->where("(kol_memberships.start_date between  ".$fromYear."  and  ".$toYear."  or kol_memberships.start_date=0)");
            $this->db->where("((kol_memberships.start_date between  " . $fromYear . "  and  " . $toYear . ") or (kol_memberships.start_date=0 or kol_memberships.start_date=''))");
        }
        $this->db->join('engagement_types', 'engagement_types.id=kol_memberships.engagement_id', 'left');

        //Adding where condition for KolId if Exist
        if (is_array($arrKolIds) && sizeof($arrKolIds)>0) {
            $this->db->where_in('kol_memberships.kol_id', $arrKolIds);
        } else if ($arrKolIds != 0) {
            $this->db->where('kol_memberships.kol_id', $arrKolIds);
        }

        //Adding where condition for EngTypeId if Exist
        if (is_array($arrEngTypes)) {
            if (is_numeric($arrEngTypes[0]))
                $this->db->where_in('engagement_types.id', $arrEngTypes);
            else
                $this->db->where_in('engagement_types.engagement_type', $arrEngTypes);
        }else if ($arrEngTypes != '') {
            if (is_numeric($arrEngTypes))
                $this->db->where('engagement_types.id', $arrEngTypes);
            else
                $this->db->where('engagement_types.engagement_type', $arrEngTypes);
        }

        //Adding where condition for OrgType if Exist
        if (is_array($arrOrgType)) {
            $this->db->where_in('kol_memberships.type', $arrOrgType);
        } else if ($arrOrgType != '') {
            $this->db->where('kol_memberships.type', $arrOrgType);
        }
		
        //Adding where condition for Gobal Region's if Exist
        if (is_array($arrGlobalRegionIds)) {
        	$this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
        	$isKolsJoined = true;
        	$this->db->join('countries','kols.country_id=countries.countryId','left');
        	$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
        } else if ($arrGlobalRegionIds != 0) {
        	$this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
        	$isKolsJoined = true;
        	$this->db->join('countries','kols.country_id=countries.countryId','left');
        	$this->db->where('countries.GlobalRegion', $arrGlobalRegionIds);
        }
        
        //Adding where condition for Country's if Exist
        if (is_array($arrCountries)) {
        	if (!$isKolsJoined)
            	$this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where_in('kols.country_id', $arrCountries);
        } else if ($arrCountries != 0) {
        	if (!$isKolsJoined)
        		$this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where('kols.country_id', $arrCountries);
        }
        if (is_array($arrStates)) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where_in('kols.state_id', $arrStates);
        }else if ($arrStates != 0) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where('kols.state_id', $arrStates);
        }

        //Adding where condition for Speciality's if Exist
        if (is_array($arrSpecialities)) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where_in('kols.specialty', $arrSpecialities);
        }else if ($arrSpecialities != 0) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where('kols.specialty', $arrSpecialities);
        }

        if ($arrListNamesIds != '' && $arrListNamesIds != 0) {
            $userId = $this->session->userdata('user_id');
            $clientId = $this->session->userdata('client_id');
            $this->db->join('list_kols', 'list_kols.kol_id=kol_memberships.kol_id', 'left');
            $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
            $this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
            $this->db->where_in('list_names.id', $arrListNamesIds);
            $this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
        }
        if ($arrProfileType != '')
            $this->db->where('kols.profile_type', $arrProfileType);
        if (sizeof($viewType) > 0) {
            $this->db->where_in('kols.id', $viewType);
        }
        //$this->db->where_not_in('kol_memberships.type','others');
        // even if the records with KOL ID = 0 or type = 0 then it should be ignored 	
        $this->db->where_not_in('type', array('0',''));
        $this->db->where('kol_memberships.kol_id>',0,false);
        if (!$isKolsJoined)
            $this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
		
		
            //$this->db->where('kols.status',COMPLETED);// To Load Charts Comment on Profile Request as well Non Profile Request
           

        $this->db->group_by($selectType);
		
        if($analystSelectedClientId != null || $analystSelectedClientId > 0){
        	$client_id = $analystSelectedClientId;
        }else{
        	$client_id = $this->session->userdata('client_id');
        }
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
        	$this->db->where('kols_client_visibility.client_id', $client_id);
        }
        
        $arrAffiliations = $this->db->get('kol_memberships');
        //pr($this->db->last_query());exit;
        foreach ($arrAffiliations->result_array() as $row) {
            $arrAffiliationsDetail[] = $row;
        }
        return $arrAffiliationsDetail;
    }

    /*
     * Counts the number of Affiliations based on "engagament_type" for one kol
     * @param $kolId
     * @author Vianayak Malladad
     * @since 1.5
     * @return Array $arrAff ex:(array([0]=>array( [engagement_type] => Consulting  [count] => 5))
     *
     */

    function getAffilitionsByEngType($kolId, $type) {
        $arrAff = array();
        $arrAffResult = $this->db->query("SELECT engagement_types.engagement_type,count(kol_memberships.engagement_id) as count
											FROM kol_memberships
											LEFT JOIN engagement_types ON engagement_types.id=kol_memberships.engagement_id
											WHERE kol_memberships.kol_id=$kolId and kol_memberships.engagement_id!='' and kol_memberships.type='$type'
											GROUP BY kol_memberships.engagement_id
										");
        foreach ($arrAffResult->result_array() as $row) {
            $arrAff[] = $row;
        }
        return $arrAff;
    }

    /**
     * Returns the kol Events years range
     * @author 	Vinayak
     * @Created on: 8-02-11
     * @since	1.5
     * @return Array
     */
    function getEventsYearsRange($kolId) {
        $arrYears = array();
        $arrYears['min_year'] = '';
        $arrYears['max_year'] = '';
        $arrResults = $this->db->query("SELECT MIN(year(start)) AS min_year, max(year(start)) AS max_year
										FROM kol_events 
										WHERE (year(start))!=0 AND kol_id=$kolId");

        foreach ($arrResults->result_array() as $row) {
            $arrYears['min_year'] = $row['min_year'];
            $arrYears['max_year'] = $row['max_year'];
        }
        return $arrYears;
    }

    /*
     * Counts the number of Events based on "session_type" for one kol
     * @param $kolId
     * @author Vianayak Malladad
     * @since 1.5
     * @return Array $arrAff ex:(array([0]=>array( [session_type] => Consulting  [count] => 5))
     *
     */

    function getEventsBySessionType($arrKolId = 0, $fromYear = 0, $toYear = 0, $role = 0, $arrCountries = 0, $arrSpecialities = 0, $arrListNamesIds = 0, $arrStates = 0) {
        //pr($arrCountries);
        $arrEvents = array();
        $isKolsJoined = false;

        $this->db->select('conf_session_types.session_type,count(*) as count');
        $this->db->join('conf_session_types', 'conf_session_types.id=kol_events.session_type', 'left');
        $this->db->where_not_in('kol_events.session_type', 0);

        if (is_array($arrKolId)) {
            $this->db->where_in('kol_events.kol_id', $arrKolId);
        } else if ($arrKolId != 0) {
            $this->db->where('kol_events.kol_id', $arrKolId);
        }

        if ($role != '') {
            $this->db->where('kol_events.role', $role);
        }

        //Adding where condition for Country's if Exist
        if (is_array($arrCountries)) {
            $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where_in('kols.country_id', $arrCountries);
        } else if ($arrCountries != 0) {
            $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where('kols.country_id', $arrCountries);
        }
        if (is_array($arrStates)) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where_in('kols.state_id', $arrStates);
        }else if ($arrStates != 0) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where('kols.state_id', $arrStates);
        }

        //Adding where condition for Speciality's if Exist
        if (is_array($arrSpecialities)) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where_in('kols.specialty', $arrSpecialities);
        }else if ($arrSpecialities != 0) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where('kols.specialty', $arrSpecialities);
        }

        if ($arrListNamesIds != '' && $arrListNamesIds != 0) {
            $userId = $this->session->userdata('user_id');
            $clientId = $this->session->userdata('client_id');
            $this->db->join('list_kols', 'list_kols.kol_id=kol_events.kol_id', 'left');
            $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
            $this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
            $this->db->where_in('list_names.id', $arrListNamesIds);
            $this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
        }

        if ($isKolsJoined) {
            //$this->db->where('kols.status', COMPLETED);
        } else {
            $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
           // $this->db->where('kols.status', COMPLETED);
        }
        if ($fromYear != 0 && $toYear != 0)
            $this->db->where("(year(kol_events.start) between  " . $fromYear . "  and  " . $toYear . "  or year(kol_events.start)=0)");
        //	$this->db->where('year(kol_events.start) between ' .$fromYear. ' and ' .$toYear);
        $this->db->group_by('kol_events.session_type');

        $arrEventsresult = $this->db->get('kol_events');
        //echo $this->db->last_query();
        foreach ($arrEventsresult->result_array() as $row) {
            $arrEvents[] = $row;
        }
        return $arrEvents;
    }

    /*
     * Counts the number of Events based on "session_type" for one kol
     * @param $kolId
     * @author Vianayak Malladad
     * @since 1.5
     * @return Array $arrAff ex:(array([0]=>array( [session_type] => Consulting  [count] => 5))
     *
     */

    function getEventsByRole($arrKolId = 0, $fromYear = 0, $toYear = 0, $sessionType = 0, $arrCountries = 0, $arrSpecialities = 0, $arrListNamesIds = 0, $arrStates = 0) {
        $arrEvents = array();
        $isKolsJoined = false;

        $this->db->select('kol_events.role,COUNT(kol_events.role) as count');
        $this->db->where_not_in('kol_events.role', '');

        if (is_array($arrKolId)) {
            $this->db->where_in('kol_events.kol_id', $arrKolId);
        } else if ($arrKolId != 0) {
            $this->db->where('kol_events.kol_id', $arrKolId);
        }
        //Adding where condition for Country's if Exist
        if (is_array($arrCountries)) {
            $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where_in('kols.country_id', $arrCountries);
        } else if ($arrCountries != 0) {
            $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where('kols.country_id', $arrCountries);
        }

        if (is_array($arrStates)) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where_in('kols.state_id', $arrStates);
        }else if ($arrStates != 0) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where('kols.state_id', $arrStates);
        }

        //Adding where condition for Speciality's if Exist
        if (is_array($arrSpecialities)) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where_in('kols.specialty', $arrSpecialities);
        }else if ($arrSpecialities != 0) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where('kols.specialty', $arrSpecialities);
        }

        if ($sessionType != '') {
            $this->db->join('conf_session_types', 'conf_session_types.id = kol_events.session_type', 'left');
            $this->db->where('conf_session_types.session_type', $sessionType);
        }
        if ($arrListNamesIds != '' && $arrListNamesIds != 0) {
            $userId = $this->session->userdata('user_id');
            $clientId = $this->session->userdata('client_id');
            $this->db->join('list_kols', 'list_kols.kol_id=kol_events.kol_id', 'left');
            $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
            $this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
            $this->db->where_in('list_names.id', $arrListNamesIds);
            $this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
        }

        if ($isKolsJoined) {
           // $this->db->where('kols.status', COMPLETED);
        } else {
            $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            //$this->db->where('kols.status', COMPLETED);
        }
        if ($fromYear != 0 && $toYear != 0)
            $this->db->where("(year(kol_events.start) between  " . $fromYear . "  and  " . $toYear . "  or year(kol_events.start)=0)");
        //	$this->db->where('year(kol_events.start) between ' .$fromYear. ' and ' .$toYear);
        $this->db->where_not_in('kol_events.role', '');
        $this->db->group_by('kol_events.role');

        if ($arrEventsresult = $this->db->get('kol_events')) {

            foreach ($arrEventsresult->result_array() as $row) {
                $arrEvents[] = $row;
            }
            //echo $this->db->last_query();
            return $arrEvents;
        }
    }

    /**
     * Retrives the all the Kols or Kols count which matches the given parameters, for each parameter it does AND operation,
     * if the parameter is an 'Array' it does or with in that
     * @author 	Ramesh B
     * @Created on: 10-03-11
     * @since	1.5.1
     * @return Array
     */
    function getKolsByParam($fromYear = 0, $toYear = 0, $arrKolIds = 0, $arrCountries = 0, $arrSpecialties = 0, $groupBy = 0, $arrListNamesIds = 0, $arrStates = 0, $profileType, $viewType, $arrGlobalRegionIds = 0) {
        $arrKols = array();
        $isKolsJoined = false;

        //echo $fromYear;
        //Adding where condition for KOL Id's if Exist
        if (is_array($arrKolIds)) {
            $this->db->where_in('kols.id', $arrKolIds);
        } else if ($arrKolIds != 0) {
            $this->db->where('kols.id', $arrKolIds);
        }
		
        //Adding where condition for Gobal Region's if Exist
        if (is_array($arrGlobalRegionIds)) {
        	$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
        } else if ($arrGlobalRegionIds != 0) {
        	$this->db->where('countries.GlobalRegion', $arrGlobalRegionIds);
        }
        
        //Adding where condition for Country's if Exist
        if (is_array($arrCountries)) {
            $this->db->where_in('kols.country_id', $arrCountries);
        } else if ($arrCountries != 0) {
            $this->db->where('kols.country_id', $arrCountries);
        }

        if (is_array($arrStates)) {
            $this->db->where_in('kols.state_id', $arrStates);
        } else if ($arrStates != 0) {
            $this->db->where('kols.state_id', $arrStates);
        }
        //Adding where condition for Speciality's if Exist
        if (is_array($arrSpecialties)) {
            $this->db->where_in('kols.specialty', $arrSpecialties);
        } else if ($arrSpecialties != 0) {
            $this->db->where('kols.specialty', $arrSpecialties);
        }
        if ($fromYear != 0 && $toYear != 0) {
            //$wherBetween="(YEAR(kols.dob) BETWEEN '$fromYear' AND '$toYear' OR YEAR(kols.dob)='0')";
            //$this->db->where($wherBetween);
        }

        //Adding Group by based param $groupBy
        if ($arrListNamesIds != '' && $arrListNamesIds != 0) {
            $userId = $this->session->userdata('user_id');
            $clientId = $this->session->userdata('client_id');
            $this->db->join('list_kols', 'list_kols.kol_id=kols.id', 'left');
            $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
            $this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
            $this->db->where_in('list_names.id', $arrListNamesIds);
            $this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
        }

        if ((string) $groupBy == "year") {
            $this->db->select('YEAR(kols.dob) AS year, COUNT(YEAR(kols.dob)) AS count');
            $this->db->group_by('YEAR(kols.dob)');
            //echo $groupBy;
        } else if ((string) $groupBy == 'country') {
            $this->db->join('countries', 'countries.CountryId=kols.country_id', 'left');
            $this->db->select('countries.Country As name, COUNT(kols.country_id) AS count');
            $this->db->where("countries.Country != 'null'");
            $this->db->group_by('kols.country_id');
            $this->db->order_by('count DESC');
            //echo $groupBy;
        } else if ((string) $groupBy == 'specialty') {
            $this->db->join('specialties', 'specialties.id=kols.specialty', 'left');
            $this->db->join('countries', 'countries.CountryId=kols.country_id', 'left');
            $this->db->select('specialties.specialty As name, COUNT(kols.specialty) AS count');
            $this->db->where("specialties.specialty != 'null'");
            $this->db->group_by('kols.specialty');
            $this->db->order_by('count DESC');
            //echo $groupBy;
        } else {
            $this->db->select('kols.*');
            //echo 'No Grouping';
        }
        if ($profileType != '') {
            $this->db->where('kols.profile_type', $profileType);
        }
        if (isset($viewType) && sizeof($viewType) > 0) {
            $this->db->where_in('kols.id', $viewType);
        }
        $this->db->where('kols.status', COMPLETED);
        
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
        	$this->db->where('kols_client_visibility.client_id', $client_id);
        }
        
        $arrKolsResults = $this->db->get('kols');
        foreach ($arrKolsResults->result_array() as $row) {
            $arrKols[] = $row;
        }
        return $arrKols;
    }

    /*
     * Retrives the all the Events or Events count which matches the given parameters, for each parameter it does AND operation,
     * @param $kolId
     * @author Vianayak Malladad
     * @since 1.5
     * @return Array $arrAff ex:(array([0]=>array( [session_type] => Consulting  [count] => 5))
     *
     */

    function getEventsByParam($fromYear = 0, $toYear = 0, $arrKolIds = 0, $arrSessionTypes = 0, $arrRoles = 0, $arrCountries = 0, $arrSpecialities = 0, $groupBy = 0, $arrListNamesIds = 0, $arrStates = 0, $arrProfileType = '', $viewType, $arrGlobalRegionIds = 0, $analystSelectedClientId = 0) {
    	$arrEvents = array();
        $isKolsJoined = false;
        $isSesssionJoined = false;

        if (is_array($arrKolIds)) {
            $this->db->where_in('kol_events.kol_id', $arrKolIds);
        } else if ($arrKolIds != 0) {
            $this->db->where('kol_events.kol_id', $arrKolIds);
        }
        //Adding where condition for Gobal Region's if Exist
        if (is_array($arrGlobalRegionIds)) {
        	$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
        	$isKolsJoined = true;	 
        	$this->db->join('countries', 'kols.country_id=countries.countryId','left');
        	$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
        } else if ($arrGlobalRegionIds != 0) {
        	$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
        	$isKolsJoined = true;
        	$this->db->join('countries', 'kols.country_id=countries.countryId','left');
        	$this->db->where('countries.GlobalRegion', $arrGlobalRegionIds);
        }
        
        //Adding where condition for Country's if Exist
        if (is_array($arrCountries)) {
        	if (!$isKolsJoined)
            	$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where_in('kols.country_id', $arrCountries);
        } else if ($arrCountries != 0) {
        	if (!$isKolsJoined)
        		$this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where('kols.country_id', $arrCountries);
        }

        if (is_array($arrStates)) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where_in('kols.state_id', $arrStates);
        }else if ($arrStates != 0) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where('kols.state_id', $arrStates);
        }

        //Adding where condition for Speciality's if Exist
        if (is_array($arrSpecialities)) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where_in('kols.specialty', $arrSpecialities);
        }else if ($arrSpecialities != 0) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where('kols.specialty', $arrSpecialities);
        }

        //Adding where condition for Session Type's if Exist
        if (is_array($arrSessionTypes)) {
            if (!$isSesssionJoined)
                $this->db->join('conf_session_types', 'conf_session_types.id = kol_events.session_type', 'left');
            $isSesssionJoined = true;
            if (is_numeric($arrSessionTypes[0]))
                $this->db->where_in('conf_session_types.id', $arrSessionTypes);
            else
                $this->db->where_in('conf_session_types.session_type', $arrSessionTypes);
        }else if ($arrSessionTypes != 0 && $arrSessionTypes != '') {
            //pr($arrSessionTypes);
            if (!$isSesssionJoined)
                $this->db->join('conf_session_types', 'conf_session_types.id = kol_events.session_type', 'left');
            $isSesssionJoined = true;
            if (is_numeric($arrSessionTypes))
                $this->db->where('conf_session_types.id', $arrSessionTypes);
            else
                $this->db->where('conf_session_types.session_type', $arrSessionTypes);
        }

        if (is_array($arrRoles)) {
            $this->db->where_in('kol_events.role', $arrRoles);
        } else if ($arrRoles != 0 && $arrRoles != '') {
            $this->db->where('kol_events.role', $arrRoles);
        }

        if ($arrListNamesIds != '' && $arrListNamesIds != 0) {
            $userId = $this->session->userdata('user_id');
            $clientId = $this->session->userdata('client_id');
            $this->db->join('list_kols', 'list_kols.kol_id=kol_events.kol_id', 'left');
            $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
            $this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
            $this->db->where_in('list_names.id', $arrListNamesIds);
            $this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
        }

        if ($fromYear != 0 && $toYear != 0)
            $this->db->where("(year(kol_events.start) between  " . $fromYear . "  and  " . $toYear . "  or year(kol_events.start)=0)");



        //Adding Group by based param $groupBy
        if ((string) $groupBy == "year") {
            $this->db->select('YEAR(kol_events.start) AS year, COUNT(YEAR(kol_events.start)) AS count');
            $this->db->group_by('YEAR(kol_events.start)');
            //echo $groupBy;
        } else if ((string) $groupBy == 'role') {
            $this->db->select('kol_events.role,COUNT(kol_events.role) as count');
            $this->db->where_not_in('kol_events.role', '');
            $this->db->group_by('kol_events.role');
            //echo $groupBy;
        } else if ((string) $groupBy == 'session_type') {
            if (!$isSesssionJoined)
                $this->db->select('conf_session_types.session_type,count(*) as count');
            $this->db->join('conf_session_types', 'conf_session_types.id=kol_events.session_type', 'left');
            $this->db->where_not_in('kol_events.session_type', 0);
            $this->db->group_by('kol_events.session_type');
            //echo $groupBy;
        }else if ((string) $groupBy == 'kolId') {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->select('kols.id as kol_id,kols.salutation,kols.last_name,kols.middle_name,kols.first_name, COUNT(kol_events.kol_id) AS count');
            $this->db->group_by('kol_events.kol_id');
            $this->db->order_by('count DESC');
        }else {
            $this->db->select('kol_events.*');
            //echo 'No Grouping';
        }
        if ($arrProfileType != '')
            $this->db->where('kols.profile_type', $arrProfileType);
        if (isset($viewType) && sizeof($viewType) > 0) {
            $this->db->where_in('kols.id', $viewType);
        }
        if ($isKolsJoined){
            //$this->db->where('kols.status', COMPLETED);
        }
        if($analystSelectedClientId != null || $analystSelectedClientId > 0){
        		$client_id = $analystSelectedClientId;
        	}else{
        		$client_id = $this->session->userdata('client_id');
        }
		if($client_id !== INTERNAL_CLIENT_ID){
           	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
           	$this->db->where('kols_client_visibility.client_id', $client_id);
        }        
        
        if ($arrEventsresult = $this->db->get('kol_events')) {
       	//pr($this->db->last_query());exit;
            foreach ($arrEventsresult->result_array() as $row) {
                $arrEvents[] = $row;
            }

            return $arrEvents;
        }
    }

    /**
     * Returns the Id of the given Specialty Name
     * @author 	Ramesh B
     * @Created on: 11-03-11
     * @since	1.5.1
     * @return Integer
     */
    function getSpecialtyId($specialtyName) {
        $id = '';
        $this->db->where('specialty', $specialtyName);
        $result = $this->db->get('specialties');
        foreach ($result->result_array() as $row) {
            $id = $row['id'];
        }
        return $id;
    }

    /**
     * Returns all the Engagement types and there id's from the lookup table
     * @author 	Ramesh B
     * @Created on: 21-03-11
     * @since	1.5.1
     * @return Array
     */
    function getEngagementTypesFromLookUp() {
        $arrEngagementTypes = '';
        $this->db->select('id,engagement_type as type');
        $results = $this->db->get('engagement_types');
        foreach ($results->result_array() as $row) {
            $arrEngagementTypes[$row['id']] = $row;
        }
        return $arrEngagementTypes;
    }

    /**
     * Returns all the Organiztion types and there id's from the lookup table
     * @author 	Ramesh B
     * @Created on: 21-03-11
     * @since	1.5.1
     * @return Array
     */
    function getOrganizationTypesFromLookUp() {
        $arrOrganizationTypes = '';
        $this->db->select('DISTINCT(type)');
        $this->db->where('type !=', 'grants');
        $this->db->where('type !=', '0');
        $results = $this->db->get('kol_memberships');
        foreach ($results->result_array() as $row) {
            $arrOrganizationTypes[] = $row;
        }
        return $arrOrganizationTypes;
    }

    /**
     * Returns all the Session types and there id's from the lookup table
     * @author 	Ramesh B
     * @Created on: 21-03-11
     * @since	1.5.1
     * @return Array
     */
    function getSessionTypesFromLookUp() {
        $arrSessionTypes = '';
        $this->db->select('id,session_type as type');
        $results = $this->db->get('conf_session_types');
        foreach ($results->result_array() as $row) {
            $arrSessionTypes[$row['id']] = $row;
        }
        return $arrSessionTypes;
    }

    /**
     * Returns all the engagement types and there id's from the lookup table
     * @author 	Ramesh B
     * @Created on: 21-03-11
     * @since	1.5.1
     * @return Array
     */
    function getRoles() {
        $arrRoles = '';
        $this->db->select('DISTINCT(role)');
        $this->db->where("role !='' AND role IS NOT null");
        $results = $this->db->get('kol_events');
        foreach ($results->result_array() as $row) {
            $arrRoles[] = $row;
        }
        return $arrRoles;
    }

    function affTempRenameLater($arrEngTypes = 0, $arrOrgType = 0, $fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds) {
        $arrAff = array();

        if ($arrEngTypes != 0) {
            $this->db->select('kol_memberships.kol_id,kol_memberships.engagement_id as type_id,COUNT(kol_memberships.engagement_id)as count');
            $this->db->join('engagement_types', 'kol_memberships.engagement_id = engagement_types.id', 'left');
            $this->db->where_in('kol_memberships.engagement_id', $arrEngTypes);
            $this->db->group_by('kol_memberships.kol_id,engagement_types.id');
        }

        if ($arrOrgType != 0) {
            $this->db->select('kol_memberships.kol_id,kol_memberships.type as type_id,COUNT(kol_memberships.engagement_id)as count');
            $this->db->where_in('kol_memberships.type', $arrOrgType);
            $this->db->group_by('kol_memberships.kol_id,kol_memberships.type');
        }

        $this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
        
        if ($arrGlobalRegionIds != 0) {
        	$this->db->join('countries','kols.country_id=countries.countryId','left');
        	$this->db->where('countries.GlobalRegion', $arrGlobalRegionIds);
        }
        
        if ($arrCountriesIds != 0) {
            $this->db->where_in('kols.country_id', $arrCountriesIds);
        }

        if ($arrSpecialityIds != 0) {
            $this->db->where_in('kols.specialty', $arrSpecialityIds);
        }

        if ($arrKolIds != 0) {
            $this->db->where_in('kols.id', $arrKolIds);
        }

        if ($arrStatesIds != 0) {
            $this->db->where_in('kols.state_id', $arrStatesIds);
        }
        if ($profileType != 0) {
            $this->db->where('kols.profile_type', $profileType);
        }
        if ($viewType != 0) {
            $this->db->where_in('kols.id', $viewType);
        }
        if ($arrListNamesIds) {
            $userId = $this->session->userdata('user_id');
            $clientId = $this->session->userdata('client_id');
            $this->db->join('list_kols', 'list_kols.kol_id=kol_memberships.kol_id', 'left');
            $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
            $this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
            $this->db->where_in('list_names.id', $arrListNamesIds);
            $this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
        }

        if ($fromYear != 0 && $toYear != 0)
            $this->db->where("(kol_memberships.start_date between  " . $fromYear . "  and  " . $toYear . "  or kol_memberships.start_date=0)");

        $arrAffResult = $this->db->get('kol_memberships');
        
        //pr($this->db->last_query());exit;
        /* $arrAffResult = $this->db->query("SELECT kol_memberships.kol_id,kol_memberships.engagement_id as type_id,COUNT(kol_memberships.engagement_id)as count FROM kol_memberships
          LEFT JOIN engagement_types ON kol_memberships.engagement_id = engagement_types.id
          GROUP BY kol_memberships.kol_id,engagement_types.id
          ");
         */
        foreach ($arrAffResult->result_array() as $row) {
            $arrAff[$row['kol_id']][$row['type_id']] = $row['count'];
        }
        return $arrAff;
    }

    function eventTempRenameLater($arrSessionTypes = 0, $arrRoles = 0, $fromYear, $toYear, $arrKolIds, $arrCountriesIds, $arrSpecialityIds, $arrListNamesIds, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds = 0) {
        $arrAff = array();

        if ($arrSessionTypes != 0) {
            $this->db->select('kol_events.kol_id,kol_events.session_type as type_id,COUNT(kol_events.session_type)as count');
            $this->db->join('conf_session_types', 'kol_events.session_type  =conf_session_types.id', 'left');
            $this->db->where_in('kol_events.session_type ', $arrSessionTypes);
            $this->db->group_by('kol_events.kol_id,kol_events.session_type');
        }

        if ($arrRoles != 0) {
            $this->db->select('kol_events.kol_id,kol_events.role as type_id,COUNT(kol_events.role)as count');
            $this->db->where_in('kol_events.role ', $arrRoles);
            $this->db->group_by('kol_events.kol_id,kol_events.role');
        }

        $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
		
        if ($arrGlobalRegionIds != 0) {
        	$this->db->join('countries','kols.country_id=countries.countryId','left');
        	$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
        }
        
        if ($arrCountriesIds != 0) {
            $this->db->where_in('kols.country_id', $arrCountriesIds);
        }

        if ($arrSpecialityIds != 0) {
            $this->db->where_in('kols.specialty', $arrSpecialityIds);
        }

        if ($arrKolIds != 0) {
            $this->db->where_in('kols.id', $arrCountriesIds);
        }
        if ($arrStatesIds != 0) {
            $this->db->where_in('kols.state_id', $arrStatesIds);
        }
        if ($profileType != 0) {
            $this->db->where('kols.profile_type', $profileType);
        }
        if ($viewType != 0) {
            $this->db->where_in('kols.id', $viewType);
        }

        if ($arrListNamesIds != 0) {
            $this->db->join('list_kols', 'list_kols.kol_id=kol_events.kol_id', 'left');
            $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
            $this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
            $this->db->where_in('list_names.id', $arrListNamesIds);
        }

        if ($fromYear != 0 && $toYear != 0)
            $this->db->where("(year(kol_events.start) between  " . $fromYear . "  and  " . $toYear . "  or year(kol_events.start)=0)");

        $arrAffResult = $this->db->get('kol_events');
        /* $arrAffResult = $this->db->query("SELECT kol_memberships.kol_id,kol_memberships.engagement_id as type_id,COUNT(kol_memberships.engagement_id)as count FROM kol_memberships
          LEFT JOIN engagement_types ON kol_memberships.engagement_id = engagement_types.id
          GROUP BY kol_memberships.kol_id,engagement_types.id
          ");
         */

        foreach ($arrAffResult->result_array() as $row) {
            $arrAff[$row['kol_id']][$row['type_id']] = $row['count'];
        }
        return $arrAff;
    }

    /**
     * Save  Personal Info details as record and return last record id
     * @author 	Ramesh B
     * @since	2.2
     * @return
     * @created 05-05-2011
     */
    function savePersonalInfo($kolPersonalInfo) {
        if ($this->db->insert('kol_personal_info', $kolPersonalInfo)) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    /**
     * Retrive the Kol Personal info record of this client
     * @author 	Ramesh B
     * @since	2.2
     * @return
     * @created 05-05-2011
     */
    function getKolPersonalInfo($kolId, $clientId) {
        $kolPersonalInfo = array();
        $this->db->select('*');
        $this->db->where('kol_id', $kolId);
        $this->db->where('client_id', $clientId);
        $result = $this->db->get('kol_personal_info');
        $kolPersonalInfo = $result->row_array();
        return $kolPersonalInfo;
    }

    /**
     * Updates the Kol Personal info record
     * @author 	Ramesh B
     * @since	2.2
     * @return
     * @created 05-05-2011
     */
    function updatePersonalInfo($kolPersonalInfo) {
        $this->db->where('id', $kolPersonalInfo['id']);
        if ($this->db->update('kol_personal_info', $kolPersonalInfo))
            return true;
        else
            return false;
    }

    /**
     * Get the Personal Info details from Form and save it as record with client and kolids
     * @author 	Ramesh B
     * @since	2.2
     * @return 
     * @created 05-05-2011
     */
    function savePersonalInfoDocument($arrDocDetails) {
        if ($this->db->insert('personal_info_docs', $arrDocDetails)) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    /**
     * Retrives the personal info details for given id
     * @author 	Ramesh B
     * @since	2.2
     * @return 
     * @created 05-05-2011
     */
    function getPersonalInfoDocuments($personalInfoId) {
        $arrDocuments = array();
        $this->db->select('*');
        $this->db->where('personal_info_id', $personalInfoId);
        $results = $this->db->get('personal_info_docs');
        foreach ($results->result_array() as $row) {
            $arrDocuments[] = $row;
        }
        return $arrDocuments;
    }

    /**
     * Deletes the personal info details for given id
     * @author 	Ramesh B
     * @since	2.2
     * @return 
     * @created 05-05-2011
     */
    function deletePersonalInfoDocument($documentId) {
        $this->db->where('id', $documentId);
        if ($this->db->delete('personal_info_docs'))
            return true;
        else
            return false;
    }

    /*
     * To get all speciaties count for Reports(Refine by charts by chek box kind of filtering) 
     * @author Vinayak
     * @since 2.4
     * @created on 3-6-2011
     */

    function getAllSpecialties($fromYear, $toYear, $arrSpecialityIds, $arrCountriesIds, $arrKolIds, $arrListNamesIds, $reportSection = '', $chartType, $arrStatesIds, $profileType, $viewType, $arrGlobalRegionIds) {
    	$arrSpecialties = array();
        if ($reportSection == 'events') {

            $this->db->select("specialties.specialty,count(DISTINCT kol_events.event_id) as count,specialties.id");
            $this->db->join('kols', 'kols.specialty=specialties.id', 'left');
            $this->db->join('kol_events', 'kol_events.kol_id=kols.id', 'left');
            $this->db->where('kols.status', COMPLETED);
            if ($chartType == 'Events By Session Type') {
                $this->db->where_not_in('kol_events.session_type', '');
            }
            if ($fromYear != 0 && $toYear != 0)
                $this->db->where("(year(kol_events.start) between  " . $fromYear . "  and  " . $toYear . "  or year(kol_events.start)=0)");
        }

        if ($reportSection == 'affiliations') {
            $this->db->select("specialties.specialty,count(DISTINCT kol_memberships.institute_id) as count,specialties.id");
            $this->db->join('kols', 'kols.specialty=specialties.id', 'left');
            $this->db->join('kol_memberships', 'kol_memberships.kol_id=kols.id', 'left');
            $this->db->where('kols.status', COMPLETED);
            if ($fromYear != 0 && $toYear != 0)
                $this->db->where("(kol_memberships.start_date between  " . $fromYear . "  and  " . $toYear . "  or kol_memberships.start_date=0)");
            if ($chartType == 'Affiliations By Eng Type') {
                $this->db->where_not_in('kol_memberships.engagement_id', '');
            }
        }

        if ($reportSection == 'activity') {

            $this->db->select('specialties.specialty,count(kols.id)as count,specialties.id');
            $this->db->join('kols', 'kols.specialty=specialties.id', 'inner');
            $this->db->where('kols.status', COMPLETED);
            /* 	
              if($arrListNamesIds!='' && $arrListNamesIds!=0){
              $userId=$this->session->userdata('user_id');
              $clientId=$this->session->userdata('client_id');
              $this->db->join('list_kols','list_kols.kol_id=kols.id','left');
              $this->db->join('list_names','list_names.id=list_kols.list_name_id','left');
              $this->db->join('list_categories','list_categories.id=list_names.category_id','left');
              $this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
              $this->db->where_in('list_names.id',$arrListNamesIds);
              }
             */
        }

        if ($reportSection == 'publications') {
            $this->db->select('specialties.specialty,count(kol_publications.id) as count,specialties.id');
            $this->db->join('kols', 'kols.specialty=specialties.id', 'left');
            $this->db->join('kol_publications', 'kol_publications.kol_id=kols.id', 'left');
            $this->db->join('publications', 'publications.id=kol_publications.pub_id', 'left');
            $this->db->where('kol_publications.is_verified', 1);
            $this->db->where('kol_publications.is_deleted', 0);
            $this->db->where('kols.status', COMPLETED);
            if ($fromYear != 0 && $toYear != 0)
                $this->db->where('(YEAR(publications.created_date) BETWEEN ' . $fromYear . '  and  ' . $toYear . ' OR YEAR(publications.created_date)="0")');
        }

        if ($reportSection == 'segmentation') {

            $this->db->select('specialties.specialty,count(kols.id)as count,specialties.id');
            $this->db->join('kols', 'kols.specialty=specialties.id', 'inner');
            /* 	
              if($arrListNamesIds!=''){
              $userId=$this->session->userdata('user_id');
              $clientId=$this->session->userdata('client_id');
              $this->db->join('list_kols','list_kols.kol_id=kols.id','left');
              $this->db->join('list_names','list_names.id=list_kols.list_name_id','left');
              $this->db->join('list_categories','list_categories.id=list_names.category_id','left');
              $this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
              $this->db->where_in('list_names.id',$arrListNamesIds);
              }
             */
        }
        if ($arrGlobalRegionIds != '' && $arrGlobalRegionIds != 0) {
        	$this->db->join('countries','kols.country_id=countries.countryId','inner');
        	$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
        }
        if ($arrCountriesIds != '' && $arrCountriesIds != 0) {
            $this->db->where_in('kols.country_id', $arrCountriesIds);
        }
        if ($arrStatesIds != '' && $arrStatesIds != 0) {
            $this->db->where_in('kols.state_id', $arrStatesIds);
        }
        if ($arrKolIds != '' && $arrKolIds != 0) {
            $this->db->where_in('kols.id', $arrKolIds);
        }
        if ($arrListNamesIds != '' && $arrListNamesIds != 0 && sizeof($arrListNamesIds) > 0) {
            $userId = $this->session->userdata('user_id');
            $clientId = $this->session->userdata('client_id');
            $this->db->join('list_kols', 'list_kols.kol_id=kols.id', 'left');
            $this->db->join('list_names', 'list_names.id=list_kols.list_name_id', 'left');
            $this->db->join('list_categories', 'list_categories.id=list_names.category_id', 'left');
            $this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
            $this->db->where_in('list_names.id', $arrListNamesIds);
        }
        if ($profileType != '') {
            $this->db->where("kols.profile_type", $profileType);
        }
        if (isset($viewType) && sizeof($viewType) > 0) {
            $this->db->where_in("kols.id", $viewType);
        }
        $this->db->group_by('specialties.specialty');
        $this->db->order_by('count desc');
        
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
        	$this->db->where('kols_client_visibility.client_id', $client_id);
        }
        
        $arrSpecialtiesResult = $this->db->get('specialties');
        //print $this->db->last_query();exit;
        foreach ($arrSpecialtiesResult->result_array() as $row) {
            //$arrSpecialties[$row['specialty']]=$row;
            $arrSpecialties[$row['id']] = $row;
        }
        return $arrSpecialties;
    }

    /*
     * To get all Kols and their count for Reports(Refine by charts by chek box kind of filtering) 
     * @author Vinayak
     * @since 2.4
     * @created on 3-6-2011
     */

    function getAllKols($fromYear = 0, $toYear = 0, $arrSpecialityIds = 0, $arrCountriesIds = 0, $arrKolIds = 0, $arrListNamesIds = 0, $reportSection, $chartType, $arrStatesIds = 0, $profileType, $viewType, $arrGlobalRegionIds=0) {
        $arrKolDetail = array();
        //echo $reportSection;
        if ($reportSection == 'activity') {
            $this->db->select('id,first_name,middle_name,last_name');
            //$this->db->where('kols.status', COMPLETED);
            if ($profileType != '') {
                $this->db->where("kols.profile_type", $profileType);
            }
            if (isset($viewType) && sizeof($viewType) > 0) {
                $this->db->where_in("kols.id", $viewType);
            }
            if ($arrStatesIds != '' && $arrStatesIds != 0) {
            	$this->db->where_in('kols.state_id', $arrStatesIds);
            }
            if ($arrGlobalRegionIds != '' && $arrGlobalRegionIds != 0) {
            	$this->db->join('countries','kols.country_id=countries.countryId','inner');
            	$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
            }
            if ($arrStatesIds != '' && $arrStatesIds != 0) {
                $this->db->where_in('kols.state_id', $arrStatesIds);
            }
            $arrKolDetailResult = $this->db->get('kols');
            foreach ($arrKolDetailResult->result_array() as $row) {
//				$arrKolDetail[$row['first_name']." ".$row['middle_name']." ".$row['last_name']]=$row;
                $row['name'] = nf($row['first_name'], $row['middle_name'], $row['last_name']);
                $arrKolDetail[$row['id']] = $row;
            }
//			pr($arrKolDetail);
            return $arrKolDetail;
        }

        if ($reportSection == 'affiliations') {
            $this->db->select('kols.id,kols.first_name,kols.middle_name,kols.last_name,count(DISTINCT kol_memberships.institute_id) as count');
            $this->db->join('kols', 'kol_memberships.kol_id=kols.id', 'left');
           // $this->db->where('kols.status', COMPLETED);
            if ($fromYear != 0 && $toYear != 0)
                $this->db->where("(kol_memberships.start_date between  " . $fromYear . "  and  " . $toYear . "  or kol_memberships.start_date=0)");
            $this->db->where_not_in('kol_memberships.kol_id', '');
            if ($chartType == 'Affiliations By Eng Type') {
                $this->db->where_not_in('kol_memberships.engagement_id', '');
            }


            if ($arrCountriesIds != '' && $arrCountriesIds != 0) {
                $this->db->where_in('kols.country_id', $arrCountriesIds);
            }
            if ($arrStatesIds != '' && $arrStatesIds != 0) {
                $this->db->where_in('kols.state_id', $arrStatesIds);
            }

            if ($arrSpecialityIds != '' && $arrSpecialityIds != 0) {
                $this->db->where_in('kols.specialty', $arrSpecialityIds);
            }
            if ($profileType != '') {
                $this->db->where("kols.profile_type", $profileType);
            }
            if (isset($viewType) && sizeof($viewType) > 0) {
                $this->db->where_in("kols.id", $viewType);
            }
            $this->db->group_by('kol_memberships.kol_id');
            $this->db->order_by('count desc');
            $arrKolDetailResult = $this->db->get('kol_memberships');
            foreach ($arrKolDetailResult->result_array() as $row) {
//				$arrKolDetail[$row['first_name']." ".$row['middle_name']." ".$row['last_name']]=$row;
                $row['name'] = nf($row['first_name'], $row['middle_name'], $row['last_name']);
                $arrKolDetail[$row['id']] = $row;
            }
//			pr($arrKolDetail);
            return $arrKolDetail;
        }

        if ($reportSection == 'events') {
            $this->db->select('kols.id,kols.first_name,kols.middle_name,kols.last_name,kol_events.kol_id,count(DISTINCT kol_events.event_id) as count');
            $this->db->join('kols', 'kol_events.kol_id=kols.id', 'left');
            //$this->db->where('kols.status', COMPLETED);
            if ($fromYear != 0 && $toYear != 0)
                $this->db->where("(year(kol_events.start) between  " . $fromYear . "  and  " . $toYear . "  or year(kol_events.start)=0)");


            if ($arrCountriesIds != '' && $arrCountriesIds != 0) {
                $this->db->where_in('kols.country_id', $arrCountriesIds);
            }
            if ($arrStatesIds != '' && $arrStatesIds != 0) {
                $this->db->where_in('kols.state_id', $arrStatesIds);
            }
            if ($arrSpecialityIds != '' && $arrSpecialityIds != 0) {
                $this->db->where_in('kols.specialty', $arrSpecialityIds);
            }

            if ($chartType == 'Events By Session Type') {
                $this->db->where_not_in('kol_events.session_type', '');
            }
            if ($profileType != '') {
                $this->db->where("kols.profile_type", $profileType);
            }
            if (isset($viewType) && sizeof($viewType) > 0) {
                $this->db->where_in("kols.id", $viewType);
            }
            $this->db->group_by('kol_events.kol_id');
            $this->db->order_by('count desc');
            $arrKolDetailResult = $this->db->get('kol_events');
            foreach ($arrKolDetailResult->result_array() as $row) {
//				$arrKolDetail[$row['first_name']." ".$row['middle_name']." ".$row['last_name']]=$row;
                $row['name'] = nf($row['first_name'], $row['middle_name'], $row['last_name']);
                $arrKolDetail[$row['id']] = $row;
            }
//			pr($arrKolDetail);
            return $arrKolDetail;
        }

        if ($reportSection == 'publications') {
            $this->db->select('kols.first_name,kols.middle_name,kols.last_name,kol_publications.kol_id,count(kol_publications.id) as count');
            $this->db->join('kols', 'kols.id=kol_publications.kol_id', 'left');
            $this->db->join('publications', 'publications.id=kol_publications.pub_id', 'left');
            //$this->db->where('kols.status', COMPLETED);
            if ($arrCountriesIds != '' && $arrCountriesIds != 0) {
                $this->db->where_in('kols.country_id', $arrCountriesIds);
            }
            if ($arrStatesIds != '' && $arrStatesIds != 0) {
                $this->db->where_in('kols.state_id', $arrStatesIds);
            }

            if ($arrSpecialityIds != '' && $arrSpecialityIds != 0) {
                $this->db->where_in('kols.specialty', $arrSpecialityIds);
            }
            if ($fromYear != 0 && $toYear != 0)
                $this->db->where('(YEAR(publications.created_date) BETWEEN ' . $fromYear . '  and  ' . $toYear . ' OR YEAR(publications.created_date)="0")');
            if ($profileType != '') {
                $this->db->where("kols.profile_type", $profileType);
            }
            if (isset($viewType) && sizeof($viewType) > 0) {
                $this->db->where_in("kols.id", $viewType);
            }
            $this->db->where('kol_publications.is_verified', 1);
            $this->db->where('kol_publications.is_deleted', 0);
            $this->db->group_by('kol_publications.kol_id');
            $this->db->order_by('count desc');
            $arrKolDetailResult = $this->db->get('kol_publications');
            foreach ($arrKolDetailResult->result_array() as $row) {
//				$arrKolDetail[$row['first_name']." ".$row['middle_name']." ".$row['last_name']]=$row;
                $row['name'] = nf($row['first_name'], $row['middle_name'], $row['last_name']);
                $arrKolDetail[$row['kol_id']] = $row;
            }
            return $arrKolDetail;
        }

        if ($reportSection == 'segmentation') {
            $this->db->select('id,first_name,middle_name,last_name');
            //$this->db->where('kols.status', COMPLETED);
            if ($arrStatesIds != '' && $arrStatesIds != 0) {
                $this->db->where_in('kols.state_id', $arrStatesIds);
            }
            if ($profileType != '') {
                $this->db->where("kols.profile_type", $profileType);
            }
            if (isset($viewType) && sizeof($viewType) > 0) {
                $this->db->where_in("kols.id", $viewType);
            }
            $arrKolDetailResult = $this->db->get('kols');
            foreach ($arrKolDetailResult->result_array() as $row) {
//				$arrKolDetail[$row['first_name']." ".$row['middle_name']." ".$row['last_name']]=$row;
                $row['name'] = nf($row['first_name'], $row['middle_name'], $row['last_name']);
                $arrKolDetail[$row['id']] = $row;
            }
            return $arrKolDetail;
        }
    }

    /*
     * To get KolId By passing Kol Name 
     * @author Vinayak
     * @since 2.4
     * @created on 3-6-2011
     */

    function getKolId($name) {
        $name = str_replace(' ', '', $name);
        $kolId = '';
        $kolResultSet = $this->db->query("select id
											from kols
											where CONCAT_WS(' ',first_name,middle_name,last_name)='" . addslashes($name) . "'");
        foreach ($kolResultSet->result_array() as $row) {
            $kolId = $row['id'];
        }
        return $kolId;
    }

    /*
     * To get List of Kol Names By passing Kol Name for autocomltete 
     * @author Vinayak
     * @since 2.4
     * @created on 3-6-2011
     */

    function getKolNamesForAutocomplete($kolName) {
        $arrKols = array();
        $this->db->select("kols.id,first_name,middle_name,last_name,organizations.name as name");
        //	$this->db->select("kols.id,first_name,middle_name,last_name");
        $this->db->join('organizations', 'kols.org_id=organizations.id', 'left');
        $this->db->like("concat(first_name,middle_name,last_name)", $kolName);

        $this->db->where_in('kols.status', array(COMPLETED, PRENEW));
        $arrKolsResult = $this->db->get('kols');
        //echo $this->db->last_query();
        $arrCompletedKols = array();
        $arrMyCustomers = array();
        foreach ($arrKolsResult->result_array() as $row) {
            if ($row['status'] == PRENEW) {
                $arrMyCustomers[$row['id']][] = $row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name'];
                $arrMyCustomers[$row['id']][] = $row['name'];
            } else {
                $arrCompletedKols[$row['id']][] = $row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name'];
                $arrCompletedKols[$row['id']][] = $row['name'];
            }
            //$arrKols[$row['id']][]=$row['first_name'].' '.$row['middle_name'].' '.$row['last_name'];
            //$arrKols[$row['id']][]=$row['name'].(($row['status']=="Not Requested")?' <span class="profileType">[C]</span>':'');
        }
        $arrKols['kols'] = $arrCompletedKols;
        $arrKols['customers'] = $arrMyCustomers;
        return $arrKols;
    }

    /*
     * To get count of kols
     * @author Vinayak
     * @since 2.4
     * @created on 3-6-2011
     */

    function getAllKolsCount() {
        $this->db->select('COUNT(DISTINCT kols.id) AS count');
        $status = COMPLETED;
        $this->db->where('status', "$status");
        $countResult = $this->db->get('kols');
        foreach ($countResult->result_array() as $row) {
            $count1 = $row['count'];
        }
        return $count1;
    }

    /* To get all countries  for pie chart
     * @author Vinayak 
     * @since 2.5
     * @created on 21-6-2011
     * @param $arrKols
     */

    function getCountries($arrCountries = 0, $speacilty = 0, $arrOrganizations = 0, $arrEvents = 0, $arrEducations = 0, $arrLists = 0, $arrKolIds = 0) {
        $this->db->select("countries.country,count(countryId)as count");
        $this->db->join('countries', 'countries.countryid=kols.country_id', 'left');
        if ($arrCountries != '') {
            $this->db->where_in("countries.country", $arrCountries);
        }
        if ($speacilty != '') {
            $this->db->join('specialties', 'specialties.id=kols.specialty', 'left');
            $this->db->where_in("specialties.specialty", $speacilty);
        }
        //	pr($arrOrganizations);
        if ($arrOrganizations != '') {
            $this->db->join('organizations', 'organizations.id=kols.org_id', 'left');
            //$this->db->where_in("organizations.name",$arrOrganizations);
            $arrOrgIds = array();
            foreach ($arrOrganizations as $orgId => $orgName) {
                $arrOrgIds[] = $orgId;
            }
            $this->db->where_in('organizations.id', $arrOrgIds);
        }

        if ($arrEvents != '') {

            $this->db->join('kol_events', 'kol_events.kol_id=kols.id', 'left');
            $this->db->join('events', 'kol_events.event_id=events.id', 'left');
            $this->db->where_in("events.name", $arrEvents);
        }

        if ($arrLists != '') {
            $this->db->join('list_kols', 'list_kols.kol_id=kols.id', 'left');
            $this->db->join('list_names', 'list_names.id=list_kols.list_name_id', 'left');
            $this->db->where_in("list_names.id", $arrLists);
        }

        if ($arrKolIds != '' && $arrKolIds != '') {
            $this->db->where_in('kols.id', $arrKolIds);
        }
        $this->db->where_not_in("countries.country", '');
        $this->db->group_by("countries.country");
        $arrKolsResults = $this->db->get('kols');

        foreach ($arrKolsResults->result_array() as $row) {
            $arrKols[] = $row;
        }
        return $arrKols;
    }

    /* To get all specialties  for pie chart
     * @author Vinayak 
     * @since 2.5
     * @created on 21-6-2011
     * @param $arrKols
     */

    function getSpecialties($arrCountries = 0, $speacilty = 0, $arrOrganizations = 0, $arrEvents = 0, $arrEducations = 0, $arrLists = 0, $arrKolIds = 0) {

        $this->db->select("specialties.specialty,count(specialties.specialty) as count");
        $this->db->join('specialties', 'specialties.id=kols.specialty', 'left');
        if ($arrCountries != '') {
            $this->db->join('countries', 'countries.countryid=kols.country_id', 'left');
            $this->db->where_in("countries.country", $arrCountries);
        }
        if ($speacilty != '') {

            $this->db->where_in("specialties.specialty", $speacilty);
        }
        if ($arrOrganizations != '') {
            $this->db->join('organizations', 'organizations.id=kols.org_id', 'left');
            $this->db->where_in("organizations.name", $arrOrganizations);
        }

        if ($arrEvents != '') {
            $this->db->join('kol_events', 'kol_events.kol_id=kols.id', 'left');
            $this->db->join('events', 'kol_events.event_id=events.id', 'left');
            $this->db->where_in("events.name", $arrEvents);
            $this->db->distinct();
        }

        if ($arrEducations != '') {
            $this->db->join('kol_educations', 'kol_educations.kol_id=kols.id', 'left');
            $this->db->join('institutions', 'institutions.id=kol_educations.institute_id', 'left');
            $this->db->where_in("institutions.name", $arrEducations);
        }

        if ($arrLists != '') {
            $this->db->join('list_kols', 'list_kols.kol_id=kols.id', 'left');
            $this->db->join('list_names', 'list_names.id=list_kols.list_name_id', 'left');
            $this->db->where_in("list_names.id", $arrLists);
        }

        if ($arrKolIds != '' && $arrKolIds != '') {
            $this->db->where_in('kols.id', $arrKolIds);
        }
        $this->db->where("(specialties.specialty != ' ')");
        $this->db->group_by("specialties.specialty");
        $arrKolsResults = $this->db->get('kols');

        foreach ($arrKolsResults->result_array() as $row) {
            $arrKols[] = $row;
        }
        return $arrKols;
    }

    /* To get specialty id by specialty name 
     * @author Vinayak 
     * @since 2.5
     * @created on 21-6-2011
     * @return type array-$specialityId
     * @param $speciality
     */

    function getSpcialtyId($speciality) {
        $specialityId = '';
        $this->db->where('specialty', $speciality);
        $arrResult = $this->db->get('specialties');
        foreach ($arrResult->result_array() as $row) {

            $specialityId = $row['id'];
        }
        return $specialityId;
    }

    /* To Count nomebr of kols for particular list
     * @author Vinayak 
     * @since 2.5
     * @created on 21-6-2011
     * @return type array-$count1
     */

    function getAllListKolsCount() {
        $clientId = $this->session->userdata('client_id');
        $usrId = $this->session->userdata('user_id');
        $countResult = $this->db->query("select count(list_kols.kol_id) as count
						from list_kols
						left join list_names on list_names.id=list_kols.list_name_id
						left join list_categories on list_categories.id=list_names.category_id
						where list_categories.client_id=$clientId and (list_categories.user_id=$usrId or list_categories.is_public=0)");


        foreach ($countResult->result_array() as $row) {
            $count1 = $row['count'];
        }
        return $count1;
    }

    /* To get all event types and teeir count for chart
     * @since 2.5
     * @author Vinayak
     * @created 27-6-2011
     * @return type $arrEventDatails
     */

    function getEventTypesAndCount($fromYear = 0, $toYear = 0, $arrKolIds = 0, $arrCountriesIds = 0, $arrSpecialityIds = 0, $arrListNamesIds = 0, $arrStatesIds = 0, $profileType, $viewType, $arrGlobalRegionIds = 0) {
    	$client_id = $this->session->userdata('client_id');
        $arrEventDatails = array();
        $this->db->select('conf_event_types.id,conf_event_types.event_type,count(DISTINCT kol_events.event_id)as count');
        $this->db->join('conf_event_types', 'conf_event_types.id=kol_events.event_type', 'left');
        $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
        $status = COMPLETED;
        //$this->db->where('kols.status', "$status");
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
        	$this->db->where('kols_client_visibility.client_id', $client_id);
        }
        //	$this->db->where('YEAR(kol_events.start)!=""');
        if ($arrGlobalRegionIds != '' && $arrGlobalRegionIds != 0) {
        	$this->db->join('countries', 'kols.country_id=countries.countryId','left');
        	$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
        }
        //	$this->db->where('YEAR(kol_events.start)!=""'); 
        if ($arrSpecialityIds != '' && $arrSpecialityIds != 0) {
            $this->db->where_in('kols.specialty', $arrSpecialityIds);
        }

        if ($arrCountriesIds != '' && $arrCountriesIds != 0) {
            $this->db->where_in('kols.country_id', $arrCountriesIds);
        }
        if ($arrStatesIds != '' && $arrStatesIds != 0) {
            $this->db->where_in('kols.state_id', $arrStatesIds);
        }
        if (is_array($arrKolIds)) {
            $this->db->where_in('kols.id', $arrKolIds);
        } else if ($arrKolIds != 0) {
            $this->db->where('kols.id', $arrKolIds);
        }

        if ($fromYear != 0 && $toYear != 0)
            $this->db->where("(year(kol_events.start) between  " . $fromYear . "  and  " . $toYear . "  or year(kol_events.start)=0)");

        if ($arrListNamesIds != '' && $arrListNamesIds != 0) {
            $userId = $this->session->userdata('user_id');
            $clientId = $this->session->userdata('client_id');
            $this->db->join('list_kols', 'list_kols.kol_id=kol_events.kol_id', 'left');
            $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
            $this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
            $this->db->where_in('list_names.id', $arrListNamesIds);
            $this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
        }
        if ($profileType != '')
            $this->db->where("kols.profile_type", $profileType);
        if (isset($viewType) && sizeof($viewType) > 0) {
            $this->db->where_in('kols.id', $viewType);
        }
        $this->db->where("YEAR(kol_events.start)!=", '');
        $this->db->where("kol_events.event_type !=", 'null');
        $this->db->group_by('kol_events.event_type');
        $this->db->order_by('count', 'desc');
        $result = $this->db->get('kol_events');
        //pr($this->db->last_query());exit;
        foreach ($result->result_array() as $row) {
            $arrEventDatails[] = $row;
        }
        
        return $arrEventDatails;
    }

    /* To get all event topics of a given specialty
     * @since 2.5
     * @author Ramesh B
     * @created 01-7-2011
     * @return Array
     */

    function getTopicsBySpecialty($specialtyId) {
        $arrTopics = array();
        $this->db->where('specialty_id', $specialtyId);
        $this->db->order_by("name", "asc");
        $result = $this->db->get('event_topics');
        foreach ($result->result_array() as $row) {
            $arrTopics[$row['id']] = $row;
        }
        return $arrTopics;
    }

    /* To get all event topics regardles of specialty
     * @since 2.5
     * @author Ramesh B
     * @created 01-7-2011
     * @return Array
     */

    function getAllTopics() {
        $arrTopics = array();
        $result = $this->db->get('event_topics');
        foreach ($result->result_array() as $row) {
            $arrTopics[$row['id']] = $row;
        }
        return $arrTopics;
    }

    /* Fetches the Id of a given topic name
     * @since 2.5
     * @author Ramesh B
     * @created 05-7-2011
     * @return Array
     */

    function getTopicId($topicName) {
        $topicId = 0;
//         $this->db->like('name', $topicName, 'after');
        $this->db->where('name', $topicName);
        $result = $this->db->get('event_topics');
        if ($result->num_rows() != 0) {
            $resultObject = $result->row();
            $topicId = $resultObject->id;
        }
        return $topicId;
    }

    /* Fetches the Id of a given topic name
     * @since 2.5
     * @author Ramesh B
     * @created 05-7-2011
     * @return Array
     */

    function getTopicName($topicId) {
        $topicName = "";
        $this->db->where('id', $topicId);
        $result = $this->db->get('event_topics');
        if ($result->num_rows() != 0) {
            $resultObject = $result->row();
            $topicName = $resultObject->name;
        }
        return $topicName;
    }

    /**
     * Update the kol record matching the 'cin_num'
     * @author 	Ambarish N
     * @since	2.5
     * @return 
     * @created 27-06-2011
     */
    function updateImportedKol($kolsDetails) {
        $this->db->where('pin', $kolsDetails['pin']);
        $arrKolDetail = $this->db->get('kols');
        if ($arrKolDetail->num_rows() == 0) {
            return false;
        } else {
            $this->db->where('pin', $kolsDetails['pin']);
            if ($this->db->update('kols', $kolsDetails)) {
                //return true;
                $resultObject = $arrKolDetail->row();
                return $resultObject->id;
            } else
                return false;
        }
    }

    /**
     * Retruns the kolId by matching the 'pin'
     * @author 	Ambarish N
     * @since	2.5
     * @return 
     * @created 27-06-2011
     */
    function getKolIdByPin($pin) {
        $id = 0;
        $this->db->where('pin', $pin);
        $this->db->select('id');
        $result = $this->db->get('kols');
        $data = $result->row();
        if ($data != null)
            $id = $data->id;
        return $id;
    }

    /**
     * Returns the Co-Evented Kols and count with respect to given kol
     * @author 	Ramesh B
     * @since	
     * @return Array
     * @created 11-07-11
     */
    function getCoEventedKols($arrKolIds = null) {
        //Old Querry
        $arrKols = array();
        $this->db->select("e2.kol_id, COUNT(DISTINCT e2.event_id) as count");
        $this->db->join('kol_events as e2', 'kol_events.event_id=e2.event_id', 'left');
        $this->db->join('kols', 'e2.kol_id = kols.id', 'left');
        //$where="kol_events.kol_id='$arrKolIds' AND e2.kol_id!='$arrKolIds'";
        //$this->db->where($where);
        $this->db->where('kol_events.kol_id', $arrKolIds);
        $this->db->where('e2.kol_id !=', $arrKolIds);
        //$this->db->where('kols.status', COMPLETED);
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
            $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
            $this->db->where('kols_client_visibility.client_id', $client_id);
        }  
        $this->db->group_by('e2.kol_id');
        $results = $this->db->get('kol_events');
        foreach ($results->result_array() as $row) {
            $arrKols[] = $row;
        }
        return $arrKols;

        /* $arrKols=array();
          $this->db->select("kol_events.kol_id as parent_kol,e2.kol_id, COUNT(DISTINCT e2.event_id) as count");
          $this->db->join('kol_events as e2','kol_events.event_id=e2.event_id','left');
          $this->db->where('kol_events.kol_id != e2.kol_id');
          if($arrKolIds != null)
          $this->db->where_in('kol_events.kol_id',$arrKolIds);
          $this->db->group_by('kol_events.kol_id,e2.kol_id');
          $results=$this->db->get('kol_events');
          foreach($results->result_array() as $row){
          $arrKols[$row['parent_kol']][]=$row;
          }
          return $arrKols; */
    }

    /**
     * Returns the Co-Affiliated Kols and count with respect to given kol
     * @author 	Ramesh B
     * @since	
     * @return Array
     * @created 11-07-11
     */
    function getCoAffiliatedKols($arrKolIds = null) {
        //Old Querry
        $arrKols = array();
        $this->db->select("m2.kol_id, COUNT(DISTINCT m2.institute_id) as count");
        $this->db->join('kol_memberships as m2', 'kol_memberships.institute_id=m2.institute_id', 'left');
        $this->db->join('kols', 'm2.kol_id = kols.id', 'left');
        //$where="kol_memberships.kol_id='$arrKolIds' AND m2.kol_id!='$arrKolIds'";
        //$this->db->where($where);
        $this->db->where('kol_memberships.kol_id', $arrKolIds);
        $this->db->where('m2.kol_id !=', $arrKolIds);
        $this->db->where('kol_memberships.type', "university");
        $this->db->where('m2.type', "university");
        //$this->db->where('kols.status', COMPLETED);
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
            $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
            $this->db->where('kols_client_visibility.client_id', $client_id);
        }

        $this->db->group_by('m2.kol_id');
        $results = $this->db->get('kol_memberships');
        foreach ($results->result_array() as $row) {
            $arrKols[] = $row;
        }
        return $arrKols;

        /* $arrKols=array();
          $this->db->select("kol_memberships.kol_id as parent_kol,m2.kol_id, COUNT(m2.kol_id) as count");
          $this->db->join('kol_memberships as m2','kol_memberships.institute_id=m2.institute_id','left');
          $this->db->where('kol_memberships.kol_id != m2.kol_id');
          $this->db->where('kol_memberships.type',"university");
          if($arrKolIds != null)
          $this->db->where_in('kol_memberships.kol_id',$arrKolIds);
          $this->db->group_by('kol_memberships.kol_id,m2.kol_id');
          $results=$this->db->get('kol_memberships');
          foreach($results->result_array() as $row){
          $arrKols[$row['parent_kol']][]=$row;
          }
          return $arrKols; */
    }

    function saveEventTopic($topics) {
        $topicId = '';
        $this->db->select('id');
        $this->db->where('name', $topics['name']);
        $this->db->where('specialty_id', $topics['specialty_id']);
        $resultSet = $this->db->get('event_topics');
        if ($resultSet->num_rows() != 0) {
            $topicObj = $resultSet->first_row();
            $topicId = $topicObj->id;
        } else {
            $this->db->insert('event_topics', $topics);
            $topicId = $this->db->insert_id();
        }
        return $topicId;
    }

    /**
     * Prepares the array Which contains kol_id as key and its PIN as Value	
     * @author 	Ambarish N
     * @since	2.6
     * @created July-19-2011
     * @return $arrKols
     */
    function getKolsIdAndPin() {
        $kolResult = array();
        $arrKols = array();

        $this->db->select('id,pin');
        $kolResult = $this->db->get('kols');
        
        foreach ($kolResult->result_array() as $row) {
            $arrKols[$row['id']] = $row['pin'];
        }
        return $arrKols;
    }

    /**
     * Delete Additional Contact details of the KOL id passed
     * @author 	Ambarish N
     * @since	2.6
     * @created July-19-2011
     * 
     * @param integer $kolId
     * @return
     */
    function deleteAdditionalContactByKolId($kolId) {
        if (is_array($kolId)) {
            $this->db->where_in('kol_id', $kolId);
        } else {
            $this->db->where('kol_id', $kolId);
        }
        $this->db->delete('kol_additional_contacts');
    }

    /**
     * Delete Education details of the KOL id passed
     * @author 	Ambarish N
     * @since	2.6
     * @created July-19-2011
     * 
     * @param integer $kolId
     * @return
     */
    function deleteEducationsByKolId($kolId) {
        if (is_array($kolId)) {
            $this->db->where_in('kol_id', $kolId);
        } else {
            $this->db->where('kol_id', $kolId);
        }
        $this->db->delete('kol_educations');
    }

    /**
     * Delete Affiliation details of the KOL id passed
     * @author 	Ambarish N
     * @since	2.6
     * @created July-19-2011
     * 
     * @param integer $kolId
     * @return
     */
    function deleteAffiliationsByKolId($kolId) {
        if (is_array($kolId)) {
            $this->db->where_in('kol_id', $kolId);
        } else {
            $this->db->where('kol_id', $kolId);
        }
        $this->db->delete('kol_memberships');
    }

    /**
     * Delete Event details of the KOL id passed
     * @author 	Ambarish N
     * @since	2.6
     * @created July-19-2011
     * 
     * @param integer $kolId
     * @return
     */
    function deleteEventsByKolId($kolId) {
        if (is_array($kolId)) {
            $this->db->where_in('kol_id', $kolId);
        } else {
            $this->db->where('kol_id', $kolId);
        }
        $this->db->delete('kol_events');
    }

    /**
     * Deletes the personal info details for given Kol ID
     * @author 	Ambarish N
     * @since	2.6
     * @return 
     * @created July-19-2011
     */
    function deletePersonalInfoByKolId($kolId) {
        if (is_array($kolId)) {
            $this->db->where_in('kol_id', $kolId);
        } else {
            $this->db->where('kol_id', $kolId);
        }
        if ($this->db->delete('kol_personal_info'))
            return true;
        else
            return false;
    }

    /**
     * Retrives the Personal Info details for the passed KOL id
     * @author 	Ambarish N
     * @since	2.6
     * @return 
     * @created July-19-2011
     * @return Array $arrPersonalInfos
     */
    function getPersonalInfoByKolId($kolId) {
        $arrPersonalInfos = array();
        $this->db->where('kol_id', $kolId);
        $arrPersonalInfosResults = $this->db->get('kol_personal_info');
        foreach ($arrPersonalInfosResults->result_array() as $row) {
            $arrPersonalInfos[] = $row;
        }
        return $arrPersonalInfos;
    }

    /**
     * Deletes the document with the given document id
     * @author 	Ambarish N
     * @since	2.6
     * @return 
     * @created July-19-2011
     * @return Boolean
     */
    function deletePersonalInfoDocuments($documentId) {
        $fileName = "";
        $this->db->where('id', $documentId);
        $this->db->select('doc_path');
        $result = $this->db->get('personal_info_docs');
        $data = $result->row();
        $fileName = $data->doc_path;
        $this->db->where('id', $documentId);
        if ($this->db->delete('personal_info_docs'))
            return $fileName;
        else
            return false;
    }

    /** Date function to convert the date from php format to mysql.
     *
     * @param date $inputDate Input date (format - MM/DD/YYYY or M/D/YYYY)
     * @return date  Output date (format - YYYY-MM-DD).
     */
    function convertDateToYYYYMMDD($inputDate) {
        $date = '';
        if (empty($inputDate)) {
            return $date;
        }
        $arrDate = array();
        $arrDate = explode('/', $inputDate);

        $mmDate = $arrDate[0];
        $ddDate = $arrDate[1];
        $yyDate = $arrDate[2];
        return ($yyDate . '-' . $mmDate . '-' . $ddDate);
    }

    function getDuplicateInstituteNames() {
        $logFilePath = $_SERVER['DOCUMENT_ROOT'] . '/kolm/system/logs';
        $logInstSelectFileName = $logFilePath . '/institute_select.txt';
        $logInstAlterFileName = $logFilePath . '/institute_alter.txt';
        $logEduAlterFileName = $logFilePath . '/kol_educations_alter.txt';
        $loMembershipAlterFileName = $logFilePath . '/kol_memberships_alter.txt';

        $logInstSelectFile = fopen($logInstSelectFileName, "w");
        $logInstAlterFile = fopen($logInstAlterFileName, "w");
        $logEduAlterFile = fopen($logEduAlterFileName, "w");
        $logMembershipAlterFile = fopen($loMembershipAlterFileName, "w");
        //Get all duplicate institute names
        $arrDupInstNames = array();
        $query = "SELECT id, NAME, COUNT(id) AS num FROM institutions GROUP BY NAME HAVING COUNT(id)>1 ORDER BY num DESC";
        $result = $this->db->query($query);
        foreach ($result->result_array() as $row) {
            $arrDupInstNames[$row['id']] = $row['NAME'];
        }

        //loop trough each name 
        foreach ($arrDupInstNames as $id => $instName) {
            if ($instName != '') {
                //get duplicate ids  for each name
                $arrIds = array();
                $query = "SELECT id,NAME FROM institutions WHERE NAME='$instName'";
                $result = $this->db->query($query);
                foreach ($result->result_array() as $row) {
                    $arrIds[] = $row['id'];
                }
                fwrite($logInstSelectFile, $query . "\r\n");
                //echo $this->db->last_query();
                //pr($arrIds);
                $firstId = $arrIds[0];
                unset($arrIds[0]);

                //Update the table 'kol_educations'
                $arrCommaIds = $this->common_helpers->convertArrayToCommaSeparatedElements($arrIds);
                $query = "UPDATE kol_educations SET institute_id=$firstId WHERE institute_id IN ($arrCommaIds)";
                $result = $this->db->query($query);
                //echo $this->db->last_query();
                fwrite($logEduAlterFile, $query . "\r\n");

                //Update the table 'kol_memberships'
                $arrCommaIds = $this->common_helpers->convertArrayToCommaSeparatedElements($arrIds);
                $query = "UPDATE kol_memberships SET institute_id=$firstId WHERE institute_id IN ($arrCommaIds)";
                $result = $this->db->query($query);
                //echo $this->db->last_query();
                fwrite($logMembershipAlterFile, $query . "\r\n");

                //Delete the Duplicate id's from the master table
                $query = "DELETE FROM institutions WHERE id IN ($arrCommaIds)";
                $result = $this->db->query($query);
                //echo $this->db->last_query();
                fwrite($logInstAlterFile, $query . "\r\n");
            }
        }
    }

    /*
     * Get the data for Events Topic Chart
     * @author Vinayak Malladad
     * @since 3.1
     * @created on 5-9-2011
     * @param $kolId,$startYear,$endYear
     */

    function getDataForEventsTopicChart($kolId, $startYear, $endYear) {
        $arrTopics = array();
        $this->db->select('event_topics.name,count(event_topics.name) as count,event_topics.id');
        $this->db->join('event_topics', 'kol_events.topic=event_topics.id', 'left');
        $this->db->where('kol_events.kol_id', $kolId);
        if ($startYear != 0 && $endYear != 0)
            $this->db->where("((year(start) between $startYear and $endYear) or year(start)=0)");
        $this->db->where('kol_events.topic !=', 'null');
        $this->db->where('event_topics.name !=', 'null');
        $this->db->group_by('event_topics.name');
        $this->db->order_by('count', 'desc');
        $arrResult = $this->db->get('kol_events');
        //echo $this->db->last_query();exit;
        foreach ($arrResult->result_array() as $row) {
            $arrTopics[] = $row;
        }
        return $arrTopics;
    }

    /*
     * Get the data for Events Role Chart By Topic 
     * @author Vinayak Malladad
     * @since 3.1
     * @created on 5-9-2011
     * @param $kolId,$topicName,$startYear,$endYear
     */

    function getDataForEventsRoleChartByTopic($kolId, $topicName, $startYear, $endYear) {
        $arrRoles = array();
        $this->db->select('kol_events.role,count(role) as count');
        $this->db->join('event_topics', 'kol_events.topic=event_topics.id', 'left');
        $this->db->where("(kol_events.kol_id=$kolId and ((year(start) between $startYear and $endYear) or year(start)=0))");
        $this->db->where('event_topics.name', $topicName);
        $this->db->where('kol_events.role !=', 'null');
        $this->db->group_by('kol_events.role');
        $this->db->order_by('count', 'desc');
        $arrResult = $this->db->get('kol_events');
        foreach ($arrResult->result_array() as $row) {
            $arrRoles[] = $row;
        }
        return $arrRoles;
    }

    /**
     * Returns the list of kols within the given start point and limit
     * 
     * @author Ramesh B
     * @since 3.2
     * @param $limit - number of records to fetch
     * @param $startFrom  - starting record number 
     * @return Array
     * @created 13-10-11 
     */
    function listKols($limit, $startFrom) {
        $arrKols = array();
        $this->db->select('kols.id,kols.salutation,kols.first_name,kols.middle_name,kols.last_name,kols.suffix,kols.profile_image,specialties.specialty as specs,countries.Country as country,organizations.name as name');
        $this->db->join('specialties', 'specialties.id=kols.specialty', 'left');
        $this->db->join('countries', 'countries.CountryId=kols.country_id', 'left');
        $this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
        $this->db->limit($limit, $startFrom);
        $this->db->order_by('kols.first_name');
        $arrResults = $this->db->get('kols');

        foreach ($arrResults->result_array() as $row) {
            $arrKols[$row['id']] = $row;
        }
        return $arrKols;
    }

    /**
     * Loop troug given education details and prepares a data as required by the view page
     * 
     * @author Ramesh B
     * @since 3.2
     * @param $arrEducationsResults
     * @created 17-10-11 
     */
    function prepeareEducationDetails($arrEducationsResults) {
        $arrEducationDetails = array();
        foreach ($arrEducationsResults as $row) {
            $row['date'] = '';
            if ($row['start_date'] != '')
                $row['date'] .= $row['start_date'];

            if (($row['start_date'] != '') && ($row['end_date']))
                $row['date'] .= " - ";

            if ($row['end_date'] != '')
                $row['date'] .= $row['end_date'];

            $row['year'] = date_display($row['year']);

            $arrEducationDetails[] = $row;
        }
        return $arrEducationDetails;
    }

    /**
     * Loop troug given affiliations details and prepares a data as required by the view page
     * 
     * @author Ramesh B
     * @since 3.2
     * @param $arrMembershipResult
     * @created 17-10-11 
     */
    function prepeareAffiliationsDetails($arrMembershipResult) {
        $arrMembership = array();
        foreach ($arrMembershipResult as $row) {
            $row['date'] = '';
            if ($row['start_date'] != '')
                $row['date'] .= $row['start_date'];

            if (($row['start_date'] != '') && ($row['end_date']))
                $row['date'] .= " - ";

            if ($row['end_date'] != '')
                $row['date'] .= $row['end_date'];

            $arrMembership[] = $row;
        }
        return $arrMembership;
    }

    /**
     * Calculates the count of each activity of given kol id and returns array of count
     * 
     * @author Ramesh B
     * @since 3.2
     * @param $kolId
     * @created 20-10-11 
     */
    function getActivityCounts($kolId) {
        $clientId = $this->session->userdata('client_id');
        $userId = 0;
        if ($this->session->userdata('user_role_id') == ROLE_USER)
            $userId = $this->session->userdata('user_id');

        $arrActivityCounts = array();
        //Get the count of "affilitions"
        $noOfAffilitions = $this->countAfiliations($kolId);
        $arrActivityCounts['affiliationsCount'] = $noOfAffilitions;

        //Get the count of "Events"
        $noOfEvents = $this->countEvents($kolId);
        $arrActivityCounts['eventsCount'] = $noOfEvents;

        //Get the count of "Publications"
        $noOfPublications = $this->countPublications($kolId);
        $arrActivityCounts['publicationsCount'] = $noOfPublications;

        //Get the count of "Trials"
        $noOfTrials = $this->countTrials($kolId);
        $arrActivityCounts['trialsCount'] = $noOfTrials;

        //Get the count of "Interactions"
        $noOfInteractions = $this->interaction->countInteractions($clientId, $userId, $kolId);
        $arrActivityCounts['interactionsCount'] = $noOfInteractions;

        return $arrActivityCounts;
    }

    /**
     * INSERT kol details into DB
     * @author Vinayak
     * @since 3.3
     * @param $arrKol
     * @return true/false
     */
    function saveImportedKol($arrKol) {

        $this->db->where('pin', $arrKol['pin']);

        $arrKolDetail = $this->db->get('kols');

        if ($arrKolDetail->num_rows() != 0) {
            return false;
        } else {
            $this->db->where('first_name', $arrKol['first_name']);
            $this->db->where('middle_name', $arrKol['middle_name']);
            $this->db->where('last_name', $arrKol['last_name']);
            if ($arrKolDetail->num_rows() != 0) {
                return false;
            } else {
                if ($this->db->insert('kols', $arrKol)) {
                    $id = $this->db->insert_id();                    
                    $data = array('unique_id' => md5($id)); // to genrate unique id and update                    
                    $this->db->where('id', $id);
                    $this->db->update('kols', $data);
                    return $id;
                } else {
                    return false;
                }
            }
        }
    }

    function getKeywordMatchingKols($keyWord) {

        $arrKolIds = array();
        /* Kol Education institute match */
        $this->db->distinct();
        $this->db->select('kols.id');
        $this->db->join('kol_educations', 'kol_educations.kol_id = kols.id', 'left');
        $this->db->join('institutions', 'institutions.id = kol_educations.institute_id');
        //$this->db->where("institutions.name LIKE '%$keyWord%'");
        $this->db->where('institutions.name LIKE "%' . $keyWord . '%"');
        $arrEduResults = $this->db->get('kols');
        foreach ($arrEduResults->result_array() as $row)
            $arrKolIds[] = $row['id'];

        /* Kol Event name and session name match */
        $this->db->distinct();
        $this->db->select('kols.id');
        $this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');
        $this->db->join('events', 'events.id = kol_events.event_id');
        //$this->db->where("events.name LIKE '%$keyWord%' OR kol_events.session_name LIKE '%$keyWord%'");
        $this->db->where('events.name LIKE "%' . $keyWord . '%" OR kol_events.session_name LIKE "%' . $keyWord . '%"');
        $arrEduResults = $this->db->get('kols');
        foreach ($arrEduResults->result_array() as $row)
            $arrKolIds[] = $row['id'];

        /* Kol Affiliations title and institute match */
        $this->db->distinct();
        $this->db->select('kols.id');
        $this->db->join('kol_memberships', 'kol_memberships.kol_id = kols.id', 'left');
        $this->db->join('institutions', 'institutions.id = kol_memberships.institute_id');
        //$this->db->where("institutions.name LIKE '%$keyWord%' OR kol_memberships.title LIKE '%$keyWord%'");
        $this->db->where('institutions.name LIKE "%' . $keyWord . '%" OR kol_memberships.title LIKE "%' . $keyWord . '%"');
        $arrEduResults = $this->db->get('kols');
        foreach ($arrEduResults->result_array() as $row)
            $arrKolIds[] = $row['id'];

        $this->db->distinct();
        $this->db->select("kols.id");
        $where = "kols.biography like '%" . $keyWord . "%'";
        $where .= " or kols.research_interests like '%" . $keyWord . "%'";
        $this->db->where($where, null);
        $arrKolResultSet = $this->db->get('kols');
        foreach ($arrKolResultSet->result_array() as $row) {
            $arrKolIds[] = $row['id'];
        }

        return array_unique($arrKolIds);
    }

    /* get specialty name by id
     * @author vinayak
     * @since 3.5
     * @created 15-12-2011
     * @param $specialtyId
     * @return $specialty
     */

    function getSpecialtyById($specialtyId) {
        $specialty = '';
        $this->db->where('id', $specialtyId);
        $arrSpecialty = $this->db->get('specialties');
        foreach ($arrSpecialty->result_array() as $row) {
            $specialty = $row['specialty'];
        }

        return $specialty;
    }

    /**
     * Returns the Co-Organized Kols and count with respect to given kol
     * @author 	Ramesh B
     * @since	3.6
     * @return Array
     * @created 20-12-2011
     */
    function getCoOrganizedKols($arrKolIds = null) {
        //Old Querry
        $arrKols = array();
        $client_id = $this->session->userdata('client_id');
        $this->db->select("k2.id as kol_id, COUNT(DISTINCT k2.id) as count");
        $this->db->join('kols as k2', 'kols.org_id=k2.org_id', 'inner');
        $this->db->where('kols.id', $arrKolIds);
        $this->db->where('k2.id !=', $arrKolIds);
//         $this->db->where('kols.status', COMPLETED);
//         $this->db->where('k2.status', COMPLETED);
        $this->db->where('kols.org_id !=', '');
        $this->db->group_by('k2.id');
        if($client_id !== INTERNAL_CLIENT_ID){
            $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
            $this->db->where('kols_client_visibility.client_id', $client_id);
        }
        $results = $this->db->get('kols');
        foreach ($results->result_array() as $row) {
            $arrKols[] = $row;
        }
        return $arrKols;

        /* $arrKols=array();
          $this->db->select("kols.id as parent_kol,k2.id, COUNT(k2.id) as count");
          $this->db->join('kols as k2','kols.org_id=k2.org_id','inner');
          $this->db->where('kols.id != k2.id');
          if($arrKolIds != null)
          $this->db->where_in('kols.id',$arrKolIds);
          $this->db->group_by('kols.id,k2.id');
          $results=$this->db->get('kols');
          foreach($results->result_array() as $row){
          $arrKols[$row['parent_kol']][]=$row;
          }
          return $arrKols; */
    }

    /**
     * Returns the Co-Educated Kols and count with respect to given kol
     * @author 	Ramesh B
     * @since	3.6
     * @return Array
     * @created 20-12-2011
     */
    function getCoEducatedKols($arrKolIds = null) {
        //Old Querry
        $arrKols = array();
        $this->db->select("edu2.kol_id, COUNT(DISTINCT edu2.kol_id) as count");
        $this->db->join('kol_educations as edu2', 'kol_educations.institute_id=edu2.institute_id', 'inner');
        $this->db->join('kols', 'edu2.kol_id = kols.id', 'left');
        $this->db->where('kol_educations.kol_id', $arrKolIds);
        $this->db->where('edu2.kol_id !=', $arrKolIds);
        $this->db->where('edu2.institute_id !=', 0);
        $this->db->where('kol_educations.type', 'education');
        $this->db->where('edu2.type', 'education');
//         $this->db->where('kols.status', COMPLETED);
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
            $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
            $this->db->where('kols_client_visibility.client_id', $client_id);
        }
        $this->db->group_by('edu2.kol_id');
        $results = $this->db->get('kol_educations');
        foreach ($results->result_array() as $row) {
            $arrKols[] = $row;
        }
        return $arrKols;

        /* $arrKols=array();
          $this->db->select("kol_educations.kol_id as parent_kol,edu2.kol_id, COUNT(edu2.kol_id) as count");
          $this->db->join('kol_educations as edu2','kol_educations.institute_id=edu2.institute_id','inner');
          $this->db->where('kol_educations.kol_id != edu2.kol_id');
          if($arrKolIds != null)
          $this->db->where_in('kol_educations.kol_id',$arrKolIds);
          $this->db->group_by('kol_educations.kol_id,edu2.kol_id');
          $results=$this->db->get('kol_educations');
          foreach($results->result_array() as $row){
          $arrKols[$row['parent_kol']][]=$row;
          }
          return $arrKols; */
    }

    function getAdvSearchMatchingKols1($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, $doCount, $doGroupBy = false, $groupByCategory = null) {
        $client_id = $this->session->userdata('client_id');
        $user_id = $this->session->userdata('user_id');
        $arrFilterFields = $arrFilterFields;
        $eduJoined = false;
        $eventJoined = false;
        $arrKols = array();
        $arrKolIdsMatchingKeyword = array();
        if ($arrAdvSearchFields['keywords'] != '') {
            $arrKolIdsMatchingKeyword = $this->getKeywordMatchingKols($arrAdvSearchFields['keywords']);
        }

        $this->db->distinct();
        if (!$doCount) {
            //$this->db->select('kols.id,kols.salutation,kols.first_name,kols.middle_name,kols.last_name,kols.suffix,kols.profile_image,organizations.name,specialties.specialty as specs,countries.country');
            //$this->db->select('kols.id,kols.salutation,kols.first_name,kols.middle_name,kols.last_name,kols.suffix,kols.profile_image,organizations.name,specialties.specialty as specs,countries.country,publications.article_title,publications.abstract_text,event_topics.name as etopic, kol_events.role as erole,cts_investigators.role,concat(clinical_trials.trial_name,clinical_trials.condition,clinical_trials.official_title ) as tkeywords');
            //$this->db->select('kols.id,kols.salutation,kols.first_name,kols.middle_name,kols.last_name,kols.suffix,kols.profile_image,organizations.name,specialties.specialty as specs,countries.country,publications.article_title,publications.abstract_text,event_topics.name as etopic, kol_events.role as erole');
            $selectFields = 'kols.id,kols.salutation,kols.first_name,kols.middle_name,kols.last_name,kols.suffix,kols.gender,kols.profile_image,kols.research_interests,kols.biography,organizations.name,specialties.specialty as specs,countries.country';
            if ((!empty($arrAdvSearchFields['tkeywords']) && $arrAdvSearchFields['tkeywords'] != '') || (!empty($arrAdvSearchFields['trole']) && $arrAdvSearchFields['trole'] != '')) {
                $selectFields .=',concat(clinical_trials.trial_name,clinical_trials.condition,clinical_trials.official_title ) as tkeywords';
            }
            if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['pkeywords']) && $arrAdvSearchFields['pkeywords'] != '') {
                $selectFields .=',publications.article_title,publications.abstract_text';
            }
            if ((!empty($arrAdvSearchFields['etopic']) && $arrAdvSearchFields['etopic'] != '') || (!empty($arrAdvSearchFields['erole']) && $arrAdvSearchFields['erole'] != '')) {
                $selectFields .=',event_topics.name as etopic, kol_events.role as erole,cts_investigators.role';
            }
            $this->db->select($selectFields);
        }
        $this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
        $this->db->join('specialties', 'specialties.id = kols.specialty', 'left');
        $this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
        $this->db->join('kol_publications', 'kol_publications.kol_id = kols.id', 'left');
        $this->db->join('publications', 'publications.id = kol_publications.pub_id', 'left');
        $this->db->join('publications_authors', 'publications_authors.pub_id = publications.id', 'left');

        if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['education']) && $arrAdvSearchFields['education'] != null && sizeof($arrAdvSearchFields['education']) > 0 && !($doGroupBy == true && $groupByCategory == 'education')) {
            $this->db->distinct();
            $this->db->join('kol_educations', 'kol_educations.kol_id = kols.id', 'left');
            $this->db->join('institutions', 'kol_educations.institute_id = institutions.id', 'left');
            $this->db->where_in('institutions.name', $arrAdvSearchFields['education']);
            $this->db->where('kol_educations.type', 'education');
            $eduJoined = true;
        }
        if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['event_id']) && $arrAdvSearchFields['event_id'] != null && sizeof($arrAdvSearchFields['event_id']) > 0 && !($doGroupBy == true && $groupByCategory == 'event')) {
            $this->db->distinct();
            $this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');
            $this->db->join('events', 'kol_events.event_id = events.id', 'left');
            $this->db->where_in('events.name', $arrAdvSearchFields['event_id']);
            $eventJoined = true;
        }
        if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['list_id']) && $arrAdvSearchFields['list_id'] != null && sizeof($arrAdvSearchFields['list_id']) > 0 && !($doGroupBy == true && $groupByCategory == 'list')) {
            $this->db->distinct();
            $this->db->join('list_kols', 'list_kols.kol_id=kols.id', 'left');
            $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
            //$this->db->where_in('list_names.list_name',$arrAdvSearchFields['list_id']);
            $this->db->where_in('list_names.id', $arrAdvSearchFields['list_id']);
        }
        if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['country']) && $arrAdvSearchFields['country'] != '' && sizeof($arrAdvSearchFields['country']) > 0 && !($doGroupBy == true && $groupByCategory == 'country'))
            $this->db->where_in('countries.country', $arrAdvSearchFields['country']);
        if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['organization']) && $arrAdvSearchFields['organization'] != '' && sizeof($arrAdvSearchFields['organization']) > 0 && !($doGroupBy == true && $groupByCategory == 'organization'))
            $this->db->where_in('organizations.name', $arrAdvSearchFields['organization']);
        if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['specialty']) && $arrAdvSearchFields['specialty'] != '' && sizeof($arrAdvSearchFields['specialty']) > 0 && !($doGroupBy == true && $groupByCategory == 'specialty'))
            $this->db->where_in('specialties.specialty', $arrAdvSearchFields['specialty']);

        if ($arrAdvSearchFields['first_name'] != '') {
            $where = "kols.first_name like '" . $arrAdvSearchFields['first_name'] . "%'";
            //$this->db->like('first_name', $arrAdvSearchFields['first_name'], 'after');
            $this->db->or_where($where, null);
        }
        if ($arrAdvSearchFields['last_name'] != '') {
            $where = "kols.last_name like '" . $arrAdvSearchFields['last_name'] . "%'";
            //$this->db->like('last_name', $arrAdvSearchFields['last_name'], 'after');
            $this->db->or_where($where, null);
        }
        if ($arrAdvSearchFields['middle_name'] != '')
            $this->db->where('middle_name', $arrAdvSearchFields['middle_name']);
        if ($arrAdvSearchFields['sub_specialty'] != '')
            $this->db->where('sub_specialty', $arrAdvSearchFields['sub_specialty']);
        if ($arrAdvSearchFields['title'] != '')
            $this->db->where('kols.title', $arrAdvSearchFields['title']);
        if ($arrAdvSearchFields['postal_code'] != '')
            $this->db->where('kols.postal_code', $arrAdvSearchFields['postal_code']);


        if ($arrAdvSearchFields['keywords'] != '') {
            $keywords = $arrAdvSearchFields['keywords'];

            if (sizeof($arrKolIdsMatchingKeyword) > 0)
                $this->db->where_in('kols.id', $arrKolIdsMatchingKeyword);
            else //In order to return matching result as 0
                $this->db->where_in('kols.id', 'a');
            $where = "kols.biography like '%" . $arrAdvSearchFields['keywords'] . "%'";
            $where .= " or kols.research_interests like '%" . $arrAdvSearchFields['keywords'] . "%'";
            //$this->db->like('last_name', $arrAdvSearchFields['last_name'], 'after');
            $this->db->or_where($where, null);
            //	$where = "countries.country LIKE '%".$keywords."%' OR organizations.name LIKE '%".$keywords."%' OR specialties.specialty LIKE '%".$keywords."%'";
            //	$this->db->or_where($where,null);
        }
//pr($arrAdvSearchFields);
        if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['pkeywords']) && isset($arrAdvSearchFields['pauthpos'])) {
            $where = '(';
            if ($arrAdvSearchFields['pkeywords'] != '')
                $where .= "(publications.article_title like '%" . $arrAdvSearchFields['pkeywords'] . "%' or publications.abstract_text like '%" . $arrAdvSearchFields['pkeywords'] . "%')";
            if ($arrAdvSearchFields['pkeywords'] != '' && $arrAdvSearchFields['pauthpos'] != '')
                $where .= ' or ';
            if ($arrAdvSearchFields['pauthpos'] != '') {
                if ($arrAdvSearchFields['pauthpos'] == 1) // first auth position
                    $where .= "publications_authors.position=1";
                if ($arrAdvSearchFields['pauthpos'] == 2) // middle auth position
                    $where .= "publications_authors.position > 1";
                if ($arrAdvSearchFields['pauthpos'] == 3) // last auth position
                    $where .= "publications_authors.position > 1";
            }
            $where .= ')';
            if ($arrAdvSearchFields['pkeywords'] != '' || $arrAdvSearchFields['pauthpos'] != '') {
                if ($arrAdvSearchFields['pqtype']) {
                    $this->db->where($where, null);
                } else {
                    $this->db->or_where($where, null);
                }
            }
        }

        /* 		if($arrAdvSearchFields!=null && isset($arrAdvSearchFields['pkeywords']) && $arrAdvSearchFields['pkeywords']!=''){
          $where	= "(publications.article_title like '%".$arrAdvSearchFields['pkeywords']."%' or publications.abstract_text like '%".$arrAdvSearchFields['pkeywords']."%')";
          if($arrAdvSearchFields['pqtype']){
          $this->db->where($where,null);
          }else{
          $this->db->or_where($where,null);
          }
          }


          if($arrAdvSearchFields!=null && isset($arrAdvSearchFields['pkeywords']) && isset($arrAdvSearchFields['pauthpos'])){
          //$where	= "(publications.article_title like '%".$arrAdvSearchFields['pkeywords']."%' or publications.abstract_text like '%".$arrAdvSearchFields['pkeywords']."%')";
          $where	= "(";
          if(!empty($arrAdvSearchFields['pkeywords']) && $arrAdvSearchFields['pkeywords']!='')
          $where	.= "publications.article_title like '%".$arrAdvSearchFields['pkeywords']."%' or publications.abstract_text like '%".$arrAdvSearchFields['pkeywords']."%'";
          if(!empty($arrAdvSearchFields['pkeywords']) && $arrAdvSearchFields['pkeywords']!='' && !empty($arrAdvSearchFields['pauthpos']) && $arrAdvSearchFields['pauthpos']!='')
          $where	.= " or ";
          if(!empty($arrAdvSearchFields['pauthpos']) && $arrAdvSearchFields['pauthpos']!=''){
          if($arrAdvSearchFields['pauthpos']==1) // first auth position
          $where	.= "publications_authors.position=1";
          if($arrAdvSearchFields['pauthpos']==2) // middle auth position
          $where	.= "publications_authors > 1";
          if($arrAdvSearchFields['pauthpos']==3) // last auth position
          $where	.= "publications_authors > 1";
          }
          $where .= ")";
          if($arrAdvSearchFields['pqtype']){
          $this->db->where($where,null);
          }else{
          $this->db->or_where($where,null);
          }
          }
         */
        if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['etopic']) && isset($arrAdvSearchFields['erole'])) {
            if (!$eventJoined) {
                $this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');
                $this->db->join('event_topics', 'event_topics.id = kol_events.topic', 'left');
            }
            $where = "(";
            if (!empty($arrAdvSearchFields['etopic']) && $arrAdvSearchFields['etopic'] != '')
                $where .= "event_topics.name like '%" . $arrAdvSearchFields['etopic'] . "%'";
            if (!empty($arrAdvSearchFields['etopic']) && $arrAdvSearchFields['etopic'] != '' && !empty($arrAdvSearchFields['erole']) && $arrAdvSearchFields['erole'] != '')
                $where .= " or ";
            if (!empty($arrAdvSearchFields['erole']) && $arrAdvSearchFields['erole'] != '')
                $where .= "kol_events.role like '%" . $arrAdvSearchFields['erole'] . "%'";
            $where .= ")";
            if ((!empty($arrAdvSearchFields['etopic']) && $arrAdvSearchFields['etopic'] != '') || (!empty($arrAdvSearchFields['erole']) && $arrAdvSearchFields['erole'] != '')) {
                if ($arrAdvSearchFields['eqtype']) {
                    $this->db->where($where, null);
                } else {
                    $this->db->or_where($where, null);
                }
            }
        }

        if ($arrAdvSearchFields != null && isset($arrAdvSearchFields['tkeywords']) && isset($arrAdvSearchFields['trole'])) {
            if (!$eventJoined) {
                $this->db->join('kol_clinical_trials', 'kol_clinical_trials.kol_id = kols.id', 'left');
                $this->db->join('clinical_trials', 'clinical_trials.id = kol_clinical_trials.cts_id', 'left');
                $this->db->join('cts_investigators', 'cts_investigators.id = kol_clinical_trials.cts_id', 'left');
            }
            $where = "(";
            if (!empty($arrAdvSearchFields['tkeywords']) && $arrAdvSearchFields['tkeywords'] != '')
                $where .= "clinical_trials.tkeywords like '%" . $arrAdvSearchFields['tkeywords'] . "%'";
            if (!empty($arrAdvSearchFields['tkeywords']) && $arrAdvSearchFields['tkeywords'] != '' && !empty($arrAdvSearchFields['trole']) && $arrAdvSearchFields['trole'] != '')
                $where .= " or ";
            if (!empty($arrAdvSearchFields['trole']) && $arrAdvSearchFields['trole'] != '')
                $where .= "cts_investigators.role like '%" . $arrAdvSearchFields['trole'] . "%'";
            $where .= ")";
            if ((!empty($arrAdvSearchFields['tkeywords']) && $arrAdvSearchFields['tkeywords'] != '') || (!empty($arrAdvSearchFields['trole']) && $arrAdvSearchFields['trole'] != '')) {
                if ($arrAdvSearchFields['tqtype']) {
                    $this->db->where($where, null);
                } else {
                    $this->db->or_where($where, null);
                }
            }
            //$this->db->group_by('tkeywords');
        }

        if ($doCount) {
            $this->db->distinct();
            $this->db->select('COUNT(DISTINCT kols.id) AS `count`');
            //$result=$this->db->count_all_results('kols');
            $result = $this->db->get('kols');
            $resultObj = $result->row();
            $count = $resultObj->count;
            //echo $this->db->last_query();
            return $count;
        } else {
            if ($doGroupBy) {
                if ($groupByCategory == 'country') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('kols.country_id');
                    //$this->db->where('country IS NOT NULL');
                }
                if ($groupByCategory == 'specialty') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('kols.specialty');
                    //$this->db->where('specialties.specialty IS NOT NULL');
                }
                if ($groupByCategory == 'organization') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('organizations.id');
                    //$this->db->where('name IS NOT NULL');
                }
                if ($groupByCategory == 'education') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count,institutions.name as institute_name');
                    if (!$eduJoined) {
                        $this->db->join('kol_educations', 'kol_educations.kol_id = kols.id', 'left');
                        $this->db->join('institutions', 'kol_educations.institute_id = institutions.id', 'left');
                    }
                    $this->db->where('kol_educations.type', 'education');
                    $this->db->where('institutions.name IS NOT NULL');
                    $this->db->group_by('kol_educations.institute_id');
                }
                if ($groupByCategory == 'event') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count,events.name as event_name');
                    if (!$eventJoined) {
                        $this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');
                        $this->db->join('events', 'kol_events.event_id = events.id', 'left');
                    }
                    $this->db->where('events.name IS NOT NULL');
                    $this->db->group_by('kol_events.event_id');
                }
                if ($groupByCategory == 'list') {
                    $this->db->select('list_kols.list_name_id,list_names.list_name,list_categories.category,COUNT(kols.id) AS count');
                    $this->db->join('list_kols', 'list_kols.kol_id=kols.id', 'left');
                    $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
                    $this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
                    $this->db->where('list_categories.client_id', $client_id);
                    $where = "(list_categories.user_id=$user_id OR list_categories.is_public=1)";
                    $this->db->where($where);
                    $this->db->group_by('list_kols.list_name_id');
                }
                $this->db->order_by('count', 'desc');
            } else {
                //$this->db->limit($limit, $startFrom);
                $this->db->group_by('kols.id');
            }
            $this->db->order_by('kols.first_name');
            $arrKolDetailsResult = $this->db->get('kols');
            //	echo $this->db->last_query().'<br />';

            foreach ($arrKolDetailsResult->result_array() as $row) {
                $arrKols[] = $row;
            }

            if (!$doCount && !$doGroupBy) {
                $arrSearchInputs = $arrAdvSearchFields;
                foreach ($arrSearchInputs as $index => $value) {
                    if (empty($value)) {
                        unset($arrSearchInputs[$index]);
                    }
                }
                $totalRelativeCount = 0;
                $totalRelativeCount = sizeof($arrSearchInputs); // based on search input query
                foreach ($arrKols as $kolDetails) {
                    $relativeCount = 0;
                    //$totalRelativeCount	= (sizeof($kolDetails)-6);  // based on no. of columns match
                    foreach ($kolDetails as $index => $value) {
                        //$perColumn		= 1;
                        foreach ($arrSearchInputs as $key => $input) {
                            //if((substr_count($value,$input))>0)
                            //if((preg_match_all('/'.$input.'/i',$value,$matches))>0 && $perColumn==1){
                            if ((preg_match_all('/' . $input . '/i', $value, $matches)) > 0) {
                                //$relativeCount++;
                                $relativeCount+=sizeof($matches);
                                //	$perColumn = 0;
                                //echo $input.'-'.$value.'-'.preg_match_all('/'.$input.'/i',$value,$matches).'<br />';
                                //pr($matches);
                            }
                        }
                        $kolDetails1 = $kolDetails;
                        if ($relativeCount > $totalRelativeCount)
                            $totalRelativeCount = $relativeCount;
                        if ($relativeCount < 1)
                            $relativeCount = 1;
                        //$kolDetails1['relative_count']= round(($relativeCount*100)/$totalRelativeCount);
                        $kolDetails1['relative_count'] = $relativeCount;
                        $kolDetails1['max_count'] = $totalRelativeCount;
                    }
                    //$arrKols1[][$relativeCount]=$kolDetails1;
                    $arrKols1[] = array($relativeCount, $kolDetails1);
                }
                rsort($arrKols1);
                //	pr($arrKols1);
                if (($startFrom + $limit) < sizeof($arrKols1)) {
                    $endLimit = $startFrom + $limit;
                } else {
                    $endLimit = sizeof($arrKols1);
                }
                for ($i = $startFrom; $i < ($endLimit); $i++) {
                    $arrKols1[$i][1]['relative_count'] = round(($arrKols1[$i][1]['relative_count'] * 100) / $totalRelativeCount);
                    $returnData[] = $arrKols1[$i];
                }
                $returnData['maxCount'] = $totalRelativeCount;
                //pr($returnData);
                return $returnData;
            }
            return $arrKols;
        }
    }

    function getAdvSearchMatchingKolsOptimised($arrAdvSearchFields, $arrFilterFields, $limit, $startFrom, $doCount, $doGroupBy = false, $groupByCategory = null) {
        $arrUniqueKolIds = array();
        $arrKolIdsMatchingKeyword = array();
        $arrPubsKolsData = array();
        $arrEventsKolsData = array();
        $arrTrialsKolsData = array();
        $arrFilterCountryData = array();
        $arrFilterStateData = array();
        $arrFilterCityData = array();
        $arrFilterSpecialtyData = array();
        $arrFilterOrgsData = array();
        $arrFilterOrgData = array();
        $arrFilterOrgTypeData = array();
        $arrFilterTitleData = array();
        $arrFilterRegionData = array();
         $arrFilterTopicData = array();
        if (isset($arrAdvSearchFields['keywords'])) {
            $arrKolIdsMatchingKeyword = $this->getKeywordMatchingKols($arrAdvSearchFields['keywords']);
            /* 	$this->db->distinct();
              $this->db->select("kols.id");
              $where	= "kols.biography like '%".$arrAdvSearchFields['keywords']."%'";
              $where	.= " or kols.research_interests like '%".$arrAdvSearchFields['keywords']."%'";
              $this->db->or_where($where,null);
              $arrKolResultSet	=	$this->db->get('kols');
              foreach($arrKolResultSet->result_array() as $row){
              $arrKolIdsMatchingKeyword[]	= $row['id'];
              }
              $arrKolIdsMatchingKeyword	=	array_unique($arrKolIdsMatchingKeyword);
             */
        }
        if (isset($arrAdvSearchFields['first_name']) || isset($arrAdvSearchFields['last_name']))
            if (($arrAdvSearchFields['first_name'] != '') || ($arrAdvSearchFields['last_name'] != '')) {

                $this->db->distinct();
                $this->db->select("kols.id");
                if ($arrAdvSearchFields['first_name'] != '') {
                    $where = "kols.first_name like '%" . addslashes($arrAdvSearchFields['first_name']) . "%'";
                    $this->db->where($where, null);
                }
                if ($arrAdvSearchFields['last_name'] != '') {
                    $where = "kols.last_name like '%" . addslashes($arrAdvSearchFields['last_name']) . "%'";
                    $this->db->where($where, null);
                }
                $arrKolResultSet = $this->db->get('kols');
                foreach ($arrKolResultSet->result_array() as $row) {
                    $arrKolIdsMatchingNames[] = $row['id'];
                }
                if ($arrAdvSearchFields['keywords'] != '') {
                    $arrKolIdsMatchingKeyword = array_intersect($arrKolIdsMatchingKeyword, $arrKolIdsMatchingNames);
                } else {
                    $arrKolIdsMatchingKeyword = $arrKolIdsMatchingNames;
                }
            }
        /* 	$pubQuery		= "select kol_publications.kol_id,kol_publications.auth_pos,publications.article_title,publications.abstract_text, MAX(publications_authors.position) AS max_pos
          from publications, kol_publications, publications_authors
          where kol_publications.pub_id=publications.id
          and publications_authors.pub_id=publications.id
          and kol_publications.auth_pos=2
          group by publications_authors.pub_id";
         */
        if ($arrAdvSearchFields != null && (isset($arrAdvSearchFields['pkeywords']) || isset($arrAdvSearchFields['pauthpos']))) {
            $pubsQuery = 'select kol_publications.kol_id,kol_publications.auth_pos,publications.article_title,publications.abstract_text, MAX(publications_authors.position) AS max_pos 
								from publications, kol_publications, publications_authors 
								where kol_publications.pub_id=publications.id and
								publications_authors.pub_id=publications.id and 
								kol_publications.is_verified=1 and 
								kol_publications.is_deleted=0 and (';
            if ($arrAdvSearchFields['pkeywords'] != '')
                $pubsQuery .= "(publications.article_title like '%" . $arrAdvSearchFields['pkeywords'] . "%' or publications.abstract_text like '%" . $arrAdvSearchFields['pkeywords'] . "%')";
            if ($arrAdvSearchFields['pkeywords'] != '' && $arrAdvSearchFields['pauthpos'] != '') {
                $pubsQuery .= ') AND (';
            }
            if ($arrAdvSearchFields['pauthpos'] != '') {
                /* 		if($arrAdvSearchFields['pqtype']){
                  $pubsQuery	.= ') AND (';
                  }else{
                  $pubsQuery	.= ') or (';
                  }
                 */
                if ($arrAdvSearchFields['pauthpos'] == 1) // first auth position
                    $pubsQuery .= "kol_publications.auth_pos=1";
                if ($arrAdvSearchFields['pauthpos'] == 2) // middle auth position
                    $pubsQuery .= "(kol_publications.auth_pos > 1 and kol_publications.auth_pos < publications_authors.position)";
                if ($arrAdvSearchFields['pauthpos'] == 3) // last auth position
                    $pubsQuery .= "(kol_publications.auth_pos!=1 and kol_publications.auth_pos = publications_authors.position)";
                if ($arrAdvSearchFields['pauthpos'] == 4) // single auth position
                    $pubsQuery .= "(kol_publications.auth_pos<2 and kol_publications.auth_pos = publications_authors.position)";
            }
            $pubsQuery .= ') group by publications_authors.pub_id';
            if ($arrAdvSearchFields['pkeywords'] != '' || $arrAdvSearchFields['pauthpos'] != '') {
                $pubResultSet = $this->db->query($pubsQuery);
                $arrPubData = array();
                foreach ($pubResultSet->result_array() as $row) {
                    if ($arrAdvSearchFields['pauthpos'] != '' && $arrAdvSearchFields['pauthpos'] == 4 && $row['max_pos'] > 1) {
                        continue;
                    }
                    $arrPubData[$row['kol_id']][] = $row;
                }
                foreach ($arrPubData as $kol_id => $arrActualRow) {
                    $textAuthPos = '';
                    $textArticle = '';
                    $textAbstract = '';
                    foreach ($arrActualRow as $key => $row) {
                        $textAuthPos .= $row['auth_pos'] . ' , ';
                        $textArticle .= $row['article_title'] . ' , ';
                        $textAbstract .= $row['abstract_text'] . ' , ';
                    }
                    $arrPubsKolsData[$kol_id] = array('auth_pos' => $textAuthPos, 'article' => $textArticle, 'abstract' => $textAbstract);
                }
            }
        }

        /* 		$eventsQuery	= "select kol_events.kol_id,kol_events.role,event_topics.name as topic_name 
          from kol_events, event_topics
          where event_topics.id=kol_events.topic";
         */
        if ($arrAdvSearchFields != null && (isset($arrAdvSearchFields['etopic']) || isset($arrAdvSearchFields['erole']))) {
            $eventsQuery = "select kol_events.kol_id,kol_events.role,event_topics.name as topic_name 
								from kol_events, event_topics where 
								event_topics.id=kol_events.topic and (";

            if (!empty($arrAdvSearchFields['etopic']) && $arrAdvSearchFields['etopic'] != '')
                $eventsQuery .= 'event_topics.name like "%' . $arrAdvSearchFields['etopic'] . '%"';
            if (!empty($arrAdvSearchFields['etopic']) && $arrAdvSearchFields['etopic'] != '' && !empty($arrAdvSearchFields['erole']) && $arrAdvSearchFields['erole'] != '') {
                $eventsQuery .= ') AND (';
            }
            if (!empty($arrAdvSearchFields['erole']) && $arrAdvSearchFields['erole'] != '') {
                /* 		if($arrAdvSearchFields['eqtype']){
                  $eventsQuery	.= ') AND (';
                  }else{
                  $eventsQuery	.= ') or (';
                  }
                 */
                $eventsQuery .= "kol_events.role like '%" . $arrAdvSearchFields['erole'] . "%'";
            }
            $eventsQuery .= ")";
            if ((!empty($arrAdvSearchFields['etopic']) && $arrAdvSearchFields['etopic'] != '') || (!empty($arrAdvSearchFields['erole']) && $arrAdvSearchFields['erole'] != '')) {
                $eventsResultSet = $this->db->query($eventsQuery);
                $arrEventsData = array();
                foreach ($eventsResultSet->result_array() as $row) {
                    $arrEventsData[$row['kol_id']][] = $row;
                }
                foreach ($arrEventsData as $kol_id => $arrActualRow) {
                    $textEventRole = '';
                    $textEventTopic = '';
                    foreach ($arrActualRow as $key => $row) {
                        $textEventRole .= $row['role'] . ' , ';
                        $textEventTopic .= $row['topic_name'] . ' , ';
                    }
                    $arrEventsKolsData[$kol_id] = array('event_role' => $textEventRole, 'topic_name' => $textEventTopic);
                }
            }
        }

        /* 		$trialsQuery	= "select kol_clinical_trials.kol_id,cts_investigators.role,clinical_trials.trial_name,clinical_trials.condition,clinical_trials.official_title 
          from clinical_trials, kol_clinical_trials, ct_investigators, cts_investigators
          where kol_clinical_trials.cts_id=clinical_trials.id
          and ct_investigators.cts_id=kol_clinical_trials.cts_id
          and cts_investigators.id=ct_investigators.investigator_id";
         */
        if ($arrAdvSearchFields != null && (isset($arrAdvSearchFields['tkeywords']) || isset($arrAdvSearchFields['trole']))) {

            $trialsQuery = "select kol_clinical_trials.kol_id,cts_investigators.role,clinical_trials.trial_name,clinical_trials.condition,clinical_trials.official_title 
							from clinical_trials, kol_clinical_trials, ct_investigators, cts_investigators
							where kol_clinical_trials.cts_id=clinical_trials.id
							and ct_investigators.cts_id=kol_clinical_trials.cts_id
							and cts_investigators.id=ct_investigators.investigator_id and (";
            if (!empty($arrAdvSearchFields['tkeywords']) && $arrAdvSearchFields['tkeywords'] != '') {
                //$trialsQuery	.= "clinical_trials.tkeywords like '%".$arrAdvSearchFields['tkeywords']."%'";
                $trialsQuery .= "clinical_trials.trial_name like '%" . $arrAdvSearchFields['tkeywords'] . "%'";
                $trialsQuery .= " or clinical_trials.condition like '%" . $arrAdvSearchFields['tkeywords'] . "%'";
                $trialsQuery .= "or clinical_trials.official_title like '%" . $arrAdvSearchFields['tkeywords'] . "%'";
            }
            if (!empty($arrAdvSearchFields['tkeywords']) && $arrAdvSearchFields['tkeywords'] != '' && !empty($arrAdvSearchFields['trole']) && $arrAdvSearchFields['trole'] != '') {
                $trialsQuery .= ') AND (';
            }
            if (!empty($arrAdvSearchFields['trole']) && $arrAdvSearchFields['trole'] != '') {
                /* 		if($arrAdvSearchFields['tqtype']){
                  $trialsQuery	.= ') AND (';
                  }else{
                  $trialsQuery	.= ') or (';
                  }
                 */
                $trialsQuery .= "(cts_investigators.role like '%" . $arrAdvSearchFields['trole'] . "%' or clinical_trials.kol_role like '%" . $arrAdvSearchFields['trole'] . "%')";
            }
            $trialsQuery .= ")";
            if ((!empty($arrAdvSearchFields['tkeywords']) && $arrAdvSearchFields['tkeywords'] != '') || (!empty($arrAdvSearchFields['trole']) && $arrAdvSearchFields['trole'] != '')) {
                $trialsResultSet = $this->db->query($trialsQuery);
                //echo $this->db->last_query();
                $arrTrialsData = array();
                foreach ($trialsResultSet->result_array() as $row) {
                    $arrTrialsData[$row['kol_id']][] = $row;
                }
                foreach ($arrTrialsData as $kol_id => $arrActualRow) {
                    $textTrialRole = '';
                    $textTrialKeyword = '';
                    foreach ($arrActualRow as $key => $row) {
                        $textTrialRole .= $row['role'] . ' , ';
                        $textTrialKeyword .= $row['trial_name'] . ' - ' . $row['condition'] . ' - ' . $row['official_title'] . ' , ';
                    }
                    $arrTrialsKolsData[$kol_id] = array('trial_role' => $textEventRole, 'trial_keyword' => $textTrialKeyword);
                }
            }
        }
        $arrKolIdsMatchingPubs = array_keys($arrPubsKolsData);
        $arrKolIdsMatchingEvents = array_keys($arrEventsKolsData);
        $arrKolIdsMatchingTrials = array_keys($arrTrialsKolsData);
        /* 		$arrUniqueKolIds		= array_merge($arrUniqueKolIds,$arrKolIdsMatchingKeyword);
          if(isset($arrAdvSearchFields['pqtype'])){
          if(sizeof($arrUniqueKolIds)>0){
          $arrUniqueKolIds	= array_intersect($arrUniqueKolIds,$arrKolIdsMatchingPubs);
          }else{
          //$arrUniqueKolIds	= $arrKolIdsMatchingPubs;
          }
          }else if(sizeof($arrKolIdsMatchingPubs)>0){
          $arrUniqueKolIds	= array_merge($arrUniqueKolIds,$arrKolIdsMatchingPubs);
          }
          if(isset($arrAdvSearchFields['eqtype'])){
          if(sizeof($arrUniqueKolIds)>0){
          $arrUniqueKolIds	= array_intersect($arrUniqueKolIds,$arrKolIdsMatchingEvents);
          }else{
          //$arrUniqueKolIds	= $arrKolIdsMatchingEvents;
          }
          }else{
          $arrUniqueKolIds	= array_merge($arrUniqueKolIds,$arrKolIdsMatchingEvents);
          }
          if(isset($arrAdvSearchFields['tqtype'])){
          if(sizeof($arrUniqueKolIds)>0){
          $arrUniqueKolIds	= array_intersect($arrUniqueKolIds,$arrKolIdsMatchingTrials);
          }else{
          //$arrUniqueKolIds	= $arrKolIdsMatchingTrials;
          }
          }else{
          $arrUniqueKolIds	= array_merge($arrUniqueKolIds,$arrKolIdsMatchingTrials);
          }
          $arrUniqueKolIds = array_unique($arrUniqueKolIds);
         */
        $arrUniqueKolIds = array_merge($arrUniqueKolIds, $arrKolIdsMatchingKeyword);
        if (isset($arrAdvSearchFields['pqtype'])) {
            if (sizeof($arrUniqueKolIds) > 0) {
                $arrUniqueKolIds = array_intersect($arrUniqueKolIds, $arrKolIdsMatchingPubs);
            } else {
                $arrUniqueKolIds = $arrKolIdsMatchingPubs;
            }
        } else if (sizeof($arrKolIdsMatchingPubs) > 0) {
            $arrUniqueKolIds = array_merge($arrUniqueKolIds, $arrKolIdsMatchingPubs);
        }

        if (isset($arrAdvSearchFields['eqtype'])) {
            if (sizeof($arrUniqueKolIds) > 0) {
                $arrUniqueKolIds = array_intersect($arrUniqueKolIds, $arrKolIdsMatchingEvents);
            } else {
                $arrUniqueKolIds = $arrKolIdsMatchingEvents;
            }
        } else if (sizeof($arrKolIdsMatchingEvents) > 0) {
            $arrUniqueKolIds = array_merge($arrUniqueKolIds, $arrKolIdsMatchingEvents);
        }

        if (isset($arrAdvSearchFields['tqtype'])) {
            if (sizeof($arrUniqueKolIds) > 0) {
                $arrUniqueKolIds = array_intersect($arrUniqueKolIds, $arrKolIdsMatchingTrials);
            } else {
                $arrUniqueKolIds = $arrKolIdsMatchingTrials;
            }
        } else if (sizeof($arrKolIdsMatchingTrials) > 0) {
            $arrUniqueKolIds = array_merge($arrUniqueKolIds, $arrKolIdsMatchingTrials);
        }
        $arrUniqueKolIds = array_unique($arrUniqueKolIds);
        $arrKolDetails = array();
//    var_dump($doCount);
//       if(!$doCount)
        $selectFields = 'kols.id,kols.unique_id,kols.salutation,kols.first_name,kols.middle_name,kols.last_name,kols.suffix,kols.gender,kols.profile_image,kols.research_interests,kols.biography,organizations.name,kols.specialty,specialties.specialty as specs,countries.country,regions.region as state,cities.City as city,kols.org_id,kols.state_id,kols.city_id,organization_types.type,organization_types.id as org_type_id,kols.title,kols.id as kol_type_id,countries.GlobalRegion,kols.id as region_type_id';
//       else
//        $selectFields = 'kols.id,kols.salutation,kols.first_name,kols.middle_name,kols.last_name,kols.suffix,kols.gender,kols.profile_image,kols.research_interests,kols.biography,organizations.name,kols.specialty,specialties.specialty as specs,countries.country,regions.region as state,cities.City as city,kols.org_id,kols.state_id,kols.city_id,organization_types.type,organization_types.id as org_type_id,kols.title,kols.id as kol_type_id,countries.GlobalRegion,kols.id as region_type_id,kols.id as topic_type_id,event_topics.name as topic_name';
  
        $this->db->distinct();
        $this->db->select($selectFields);
        $this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
        $this->db->join('specialties', 'specialties.id = kols.specialty', 'left');
        $this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
         $this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');
        $this->db->join('event_topics', 'event_topics.id = kol_events.topic', 'left');
        $this->db->join('regions', 'regions.regionID = kols.state_id', 'left');
        $this->db->join('cities', 'cities.CityId = kols.city_id', 'left');
        $this->db->join('organization_types', 'organization_types.id = organizations.type_id', 'left');
         $this->db->join('kol_memberships', 'kol_memberships.kol_id = kols.id', 'left');
        if (sizeof($arrUniqueKolIds) > 0 || sizeof($arrAdvSearchFields['memebers'])>0) {
            if (isset($arrFilterFields['specialty']) && sizeof($arrFilterFields['specialty']) > 0)
                $this->db->where_in('kols.specialty', $arrFilterFields['specialty']);
            if (isset($arrFilterFields['country']) && sizeof($arrFilterFields['country']) > 0)
                $this->db->where_in('kols.country_id', $arrFilterFields['country']);
            if (isset($arrFilterFields['state']) && sizeof($arrFilterFields['state']) > 0)
                $this->db->where_in('kols.state_id', $arrFilterFields['state']);
            if (isset($arrFilterFields['city']) && sizeof($arrFilterFields['city']) > 0)
                $this->db->where_in('kols.city_id', $arrFilterFields['city']);
//			if(isset($arrFilterFields['list_id']) && sizeof($arrFilterFields['list_id'])>0)
//				$this->db->where_in('kols.id',$arrFilterFields['list_id']);
            if (isset($arrFilterFields['organization']) && sizeof($arrFilterFields['organization']) > 0)
                $this->db->where_in('kols.org_id', $arrFilterFields['organization']);
//			if(isset($arrFilterFields['education']) && sizeof($arrFilterFields['education'])>0)
//				$this->db->where_in('kols.id',$arrFilterFields['education']);
//			if(isset($arrFilterFields['event_id']) && sizeof($arrFilterFields['event_id'])>0)
//				$this->db->where_in('kols.id',$arrFilterFields['event_id']);
            if (isset($arrFilterFields['profile_type']) && $arrFilterFields['profile_type'] != '')
                $this->db->where('kols.profile_type', $arrFilterFields['profile_type']);
            if (isset($arrFilterFields['viewType']) && $arrFilterFields['viewType'] != '')
                $this->db->where_in('kols.id', $arrFilterFields['viewType']);
             if (isset($arrAdvSearchFields['memebers']) && $arrAdvSearchFields['memebers'] != '')
                $this->db->where_in('kol_memberships.institute_id', $arrAdvSearchFields['memebers']);
             if(sizeof($arrUniqueKolIds)>0)
                $this->db->where_in('kols.id', $arrUniqueKolIds);
            $this->db->where("(kols.status='" . COMPLETED . "')", null);
//             if(!$doCount)
//                 $this->db->group_by('kols.id');
            $arrKolDetailsResultSet = $this->db->get('kols');
//                        echo $this->db->last_query();
            foreach ($arrKolDetailsResultSet->result_array() as $row) {
                $arrKolDetails[] = $row;
            }
        }

        if (!$doCount) {

            foreach ($arrKolDetails as $key => $row) {
                if (isset($arrPubsKolsData[$row['id']])) {
                    foreach ($arrPubsKolsData[$row['id']] as $pubFieldName => $pubValue) {
                        $arrKolDetails[$key][$pubFieldName] = $pubValue;
                    }
                }
                if (isset($arrEventsKolsData[$row['id']])) {
                    foreach ($arrEventsKolsData[$row['id']] as $eventFieldName => $eventValue) {
                        $arrKolDetails[$key][$eventFieldName] = $eventValue;
                    }
                }
                if (isset($arrTrialsKolsData[$row['id']])) {
                    foreach ($arrTrialsKolsData[$row['id']] as $trialFieldName => $trialValue) {
                        $arrKolDetails[$key][$trialFieldName] = $trialValue;
                    }
                }
            }
            $arrKols1 = array();
            $arrCountryData = array();
            $arrStateData = array();
            $arrCityData = array();
            $arrSpecialtyData = array();
            $arrOrgsData = array();
            // calculate relative count
            $totalRelativeCount = 0;
            $totalRelativeCount = sizeof($arrAdvSearchFields);
            foreach ($arrKolDetails as $kolDetails) {
                $relativeCount = 0;
                foreach ($kolDetails as $index => $value) {
                    foreach ($arrAdvSearchFields as $key => $input) {
                        if ((preg_match_all('/' . $input . '/i', $value, $matches)) > 0) {
                            //$relativeCount+=sizeof($matches);
                            //	echo $input.'-'.$value.'-'.preg_match_all('/'.$input.'/i',$value,$matches).'<br />';
                            $relativeCount += preg_match_all('/' . $input . '/i', $value, $matches);
                            //	echo $relativeCount.':';
                        }
                    }
                    //echo $relativeCount.'-';
                    $kolDetails1 = $kolDetails;
                    if ($relativeCount < 1)
                        $relativeCount = 1;
                    if ($relativeCount > $totalRelativeCount)
                        $totalRelativeCount = $relativeCount;

                    //$kolDetails1['relative_count']= round(($relativeCount*100)/$totalRelativeCount);

                    $kolDetails1['relative_count'] = $relativeCount;
                    $kolDetails1['max_count'] = $totalRelativeCount;
                }
                //	pr($kolDetails);
                //	echo '<br />';
                //$arrKols1[][$relativeCount]=$kolDetails1;
                $arrKols1[] = array($relativeCount, $kolDetails1);
//                                pr($kolDetails1);
                //pr(array($relativeCount,$kolDetails1));
                $arrCountryData[] = $kolDetails1['country'];
                //$arrStateData[]		= $kolDetails1['state'];
                $arrStateData[] = array('state' => $kolDetails1['state'], 'state_id' => $kolDetails1['state_id']);
                $arrCityData[] = array('city' => $kolDetails1['city'], 'city_id' => $kolDetails1['city_id']);
                $arrSpecialtyData[] = array('specialty' => $kolDetails1['specialty'], 'specs' => $kolDetails1['specs']);
                $arrOrgsData[] = $kolDetails1['name'];
                $arrTitleData[] = array('title' => $kolDetails1['title'], 'kol_type_id' => $kolDetails1['kol_type_id']);
                $arrOrgTypeData[] = array('type' => $kolDetails1['type'], 'org_type_id' => $kolDetails1['org_type_id']);
                ;
                $arrRegionData[] = array('GlobalRegion' => $kolDetails1['GlobalRegion'], 'region_type_id' => $kolDetails1['kol_type_id']);
             
                $arrTopicData[] = array('name' => $kolDetails['topic_name'], 'topic_type_id' => $kolDetails1['topic_type_id']);

            }
            if (isset($arrKols1)) {
                rsort($arrKols1);
            }
            //	pr($arrKols1);
            if (($startFrom + $limit) < sizeof($arrKols1)) {
                $endLimit = $startFrom + $limit;
            } else {
                $endLimit = sizeof($arrKols1);
            }
            for ($i = $startFrom; $i < ($endLimit); $i++) {
                $arrKols1[$i][1]['relative_count'] = round(($arrKols1[$i][1]['relative_count'] * 100) / $totalRelativeCount);
                $returnData[] = $arrKols1[$i];
            }
            $returnData['maxCount'] = $totalRelativeCount;

            foreach ($arrCountryData as $index => $countryName) {
                if (!isset($arrFilterCountryData[$countryName])) {
                    $arrFilterCountryData[$countryName]['country'] = $countryName;
                    $arrFilterCountryData[$countryName]['count'] = 1;
                } else {
                    $arrFilterCountryData[$countryName]['count'] += 1;
                }
            }
            $returnData['arrCountries'] = $arrFilterCountryData;

            foreach ($arrStateData as $index => $arrStateRow) {
                if (!isset($arrFilterStateData[$arrStateRow['state_id']])) {
                    $arrFilterStateData[$arrStateRow['state_id']]['state'] = $arrStateRow['state'];
                    $arrFilterStateData[$arrStateRow['state_id']]['state_id'] = $arrStateRow['state_id'];
                    $arrFilterStateData[$arrStateRow['state_id']]['count'] = 1;
                } else {
                    $arrFilterStateData[$arrStateRow['state_id']]['count'] += 1;
                }
            }
            $returnData['arrStates'] = $arrFilterStateData;

            foreach ($arrCityData as $index => $arrCityRow) {
                if (!isset($arrFilterCityData[$arrCityRow['city_id']])) {
                    $arrFilterCityData[$arrCityRow['city_id']]['city'] = $arrCityRow['city'];
                    $arrFilterCityData[$arrCityRow['city_id']]['city_id'] = $arrCityRow['city_id'];
                    $arrFilterCityData[$arrCityRow['city_id']]['count'] = 1;
                } else {
                    $arrFilterCityData[$arrCityRow['city_id']]['count'] += 1;
                }
            }
            $returnData['arrCities'] = $arrFilterCityData;

            foreach ($arrSpecialtyData as $index => $arrRow) {
                if (!isset($arrFilterSpecialtyData[$arrRow['specialty']])) {
                    $arrFilterSpecialtyData[$arrRow['specialty']]['specs'] = $arrRow['specs'];
                    $arrFilterSpecialtyData[$arrRow['specialty']]['specialty'] = $arrRow['specialty'];
                    $arrFilterSpecialtyData[$arrRow['specialty']]['count'] = 1;
                } else {
                    $arrFilterSpecialtyData[$arrRow['specialty']]['count'] += 1;
                }
            }
            $returnData['arrSpecialties'] = $arrFilterSpecialtyData;

            foreach ($arrOrgsData as $index => $orgName) {
                if (!isset($arrFilterOrgData[$orgName])) {
                    $arrFilterOrgData[$orgName]['name'] = $orgName;
                    $arrFilterOrgData[$orgName]['count'] = 1;
                } else {
                    $arrFilterOrgData[$orgName]['count'] += 1;
                }
            }
            $returnData['arrOrganizations'] = $arrFilterOrgData;


            foreach ($arrOrgTypeData as $index => $arrTypeRow) {
                if (!isset($arrFilterOrgTypeData[$arrTypeRow['org_type_id']])) {
                    $arrFilterOrgTypeData[$arrTypeRow['org_type_id']]['type'] = $arrTypeRow['type'];
                    $arrFilterOrgTypeData[$arrTypeRow['org_type_id']]['org_type_id'] = $arrTypeRow['org_type_id'];
                    $arrFilterOrgTypeData[$arrTypeRow['org_type_id']]['count'] = 1;
                } else {
                    $arrFilterOrgTypeData[$arrTypeRow['org_type_id']]['count'] += 1;
                }
            }
            $returnData['arrOrganizationsType'] = $arrFilterOrgTypeData;


            foreach ($arrTitleData as $index => $title) {
                if (!isset($arrFilterTitleData[$title['title']])) {
                    $arrFilterTitleData[$title['title']]['title'] = $title['title'];
                    $arrFilterTitleData[$title['title']]['kol_type_id'] = $title['kol_type_id'];

                    $arrFilterTitleData[$title['title']]['count'] = 1;
                } else {
                    $arrFilterTitleData[$title['title']]['count'] += 1;
                }
            }
            $returnData['arrTitles'] = $arrFilterTitleData;


            foreach ($arrRegionData as $index => $region) {
                if (!isset($arrFilterRegionData[$region['GlobalRegion']])) {
                    $arrFilterRegionData[$region['GlobalRegion']]['GlobalRegion'] = $region['GlobalRegion'];
//                                        $arrFilterRegionData[$region['region_type_id']]['region_type_id']	= $region['region_type_id'];

                    $arrFilterRegionData[$region['GlobalRegion']]['count'] = 1;
                    $arrFilterRegionData[$region['GlobalRegion']]['region_type_id'] = $region['region_type_id'];
                    ;
                } else {
                    $arrFilterRegionData[$region['GlobalRegion']]['count'] += 1;
                }
            }
            $returnData['arrRegions'] = $arrFilterRegionData;

            
            foreach ($arrTopicData as $index => $topic) {
                if (!isset($arrFilterTopicData[$topic['name']])) {
                    $arrFilterTopicData[$topic['name']]['name'] = $topic['name'];
//                                        $arrFilterRegionData[$region['region_type_id']]['region_type_id']	= $region['region_type_id'];

                    $arrFilterTopicData[$topic['name']]['count'] = 1;
                    $arrFilterTopicData[$topic['name']]['topic_type_id'] = $topic['topic_type_id'];
                    ;
                } else {
                    $arrFilterTopicData[$topic['name']]['count'] += 1;
                }
            }
            $returnData['arrTopics'] = $arrFilterTopicData;

		
            return $returnData;
        } else {
            return sizeof($arrKolDetails);
        }
    }

    function getKolCoAuthersAndPubsCount($kolId) {
        $arrData = array();
        $query = "SELECT pubmed_authors.id,pubmed_authors.last_name,pubmed_authors.initials,pubmed_authors.fore_name,COUNT(*) 
				FROM pubmed_authors 
				LEFT JOIN publications_authors ON pubmed_authors.id=publications_authors.alias_id
				LEFT JOIN publications ON publications_authors.pub_id=publications.id 
				LEFT JOIN kol_publications ON publications.id=kol_publications.pub_id
				WHERE kol_publications.is_verified=1 AND kol_publications.kol_id=33 AND !((last_name='Not Available' ) AND (fore_name='Not Available')) 
				AND !((last_name='Cannon' AND fore_name='Christopher') OR (last_name='Cannon' AND fore_name='Christopher P') OR (last_name='Cannon' AND fore_name='C ') OR (last_name='Cannon' AND fore_name='C') OR (last_name='Cannon' AND fore_name='') OR (last_name='Cannon' AND fore_name='') OR(last_name='Cannon' AND fore_name='C ')OR(last_name='Cannon' AND fore_name='Christopher'))
				GROUP BY pubmed_authors.last_name,pubmed_authors.initials,pubmed_authors.fore_name";
        $results = $this->db->query($query);
        foreach ($results->result_array() as $row) {
            $arrData[$row['id']] = $row;
        }
        //pr($arrData);
        return $arrData;
    }

    function getAllEventTopics() {
        $arrEventTopics = array();
        $this->db->select('event_topics.name as etopic_name');
        $this->db->join('kol_events', 'kol_events.topic=event_topics.id', 'inner');
        $this->db->group_by('event_topics.name');
        $this->db->order_by('event_topics.name', 'asc');
        $resultSet = $this->db->get('event_topics');
        foreach ($resultSet->result_array() as $row) {
            if ($row['etopic_name'] != null)
                $arrEventTopics[] = $row['etopic_name'];
        }
        return array_unique($arrEventTopics);
    }

    function getAllEventRoles() {
        $arrEventRoles = array();
        $this->db->select('kol_events.role as erole_name');
        $this->db->group_by('kol_events.role');
        $this->db->order_by('kol_events.role', 'asc');
        $resultSet = $this->db->get('kol_events');
        foreach ($resultSet->result_array() as $row) {
            if ($row['erole_name'] != null)
                $arrEventRoles[] = $row['erole_name'];
        }
        return array_unique($arrEventRoles);
    }

    function getAllTrialRoles() {
        $arrTrialRoles = array();
        $this->db->select('cts_investigators.role as trole_name');
        $this->db->group_by('cts_investigators.role');
        $this->db->order_by('cts_investigators.role', 'asc');
        $resultSet = $this->db->get('cts_investigators');
        foreach ($resultSet->result_array() as $row) {
            if ($row['trole_name'] != null)
                $arrTrialRoles[] = $row['trole_name'];
        }
        $this->db->select('clinical_trials.kol_role as trole_name');
        $this->db->group_by('clinical_trials.kol_role');
        $this->db->order_by('clinical_trials.kol_role', 'asc');
        $resultSet = $this->db->get('clinical_trials');
        foreach ($resultSet->result_array() as $row) {
            if ($row['trole_name'] != null)
                $arrTrialRoles[] = $row['trole_name'];
        }
        $arrTrialRoles = array_intersect_key($arrTrialRoles, array_unique(array_map('strtolower', $arrTrialRoles)));
        natcasesort($arrTrialRoles);
        return $arrTrialRoles;
    }

    function getKolNameForAutocomplete($fieldName, $fieldValue) {
    	$client_id = $this->session->userdata('client_id');
        $arrKols = array();
        $this->db->select("$fieldName");
        $this->db->like("$fieldName", $fieldValue);
        //$this->db->where("(kols.status='" . COMPLETED . "')", null);
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
        	$this->db->where('kols_client_visibility.client_id', $client_id);
        }
        /* if($client_id !== INTERNAL_CLIENT_ID && $this->session->userdata('user_role_id') != ROLE_ADMIN){
        		$group_names = explode(',', $this->session->userdata('group_names'));
        		$this->db->join ( 'countries', 'countries.CountryId=kols.country_id', 'left' );
        		$this->db->where_in( 'countries.GlobalRegion', $group_names);
        } */
        $arrKolsResult = $this->db->get('kols');
        //pr($arrKolsResult);
        foreach ($arrKolsResult->result_array() as $row) {
            $arrKols[] = $row[$fieldName];
        }
        return array_unique($arrKols);
    }

    function getSpecialtyIdByPIN($pin) {
        $this->db->select('kols.specialty');
        $this->db->where('kols.pin', $pin);
        $arrResultSet = $this->db->get('kols');
        if ($arrResultSet->num_rows() == 0) {
            return false;
        } else {
            $row = $arrResultSet->result_array();
            return $row[0]['specialty'];
        }
    }

    /**
     *  GET kol details
     * @param
     * @return array - $arrKolDetail - Returns
     */
    function getRequestedKolDetail() {
        $clientId = $this->session->userdata('client_id');
        $userId = $this->session->userdata['user_id'];
        $userRoleId = $this->session->userdata['user_role_id'];
        $managerId = $userId;
        if ($userRoleId == ROLE_USER)
            $managerId = $this->Client_User->getManagerId($userId);
        $this->db->select('kols.primary_email,kols.primary_phone,kols.salutation,client_users.first_name as user_first_name,client_users.last_name as user_last_name,client_users.manager_id,kols.id,kols.first_name,kols.middle_name,kols.last_name,kols.created_by,kols.approved_by,kols.status,kols.salutation,kols.specialty,client_users.user_name as user_full_name,organizations.name,countries.country,user_requests.requested_on,user_requests.rej_or_appr_on');
        $this->db->join('client_users', 'client_users.id = kols.created_by', 'left');
        $this->db->join('user_requests', 'user_requests.kol_id = kols.id', 'left');
        $this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
        $this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
        $this->db->where("(kols.status!='" . COMPLETED . "' and kols.status!='" . PRENEW . "' and kols.status!='" . REJECT . "')");
        $this->db->order_by('first_name', 'asc');
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where("(client_users.client_id=$clientId)");
            //$this->db->where('client_users.manager_id',$managerId);
        }

        $this->db->where("(client_users.client_id!='" . INTERNAL_CLIENT_ID . "')");
        $arrKolDetail = $this->db->get('kols');
        foreach ($arrKolDetail->result_array() as $row) {
            $arrkol[] = $row;
        }
        return $arrkol;
    }

    function updateStatus($arrKolId) {
        $arr['status'] = $arrKolId['status'];
        $arr['modified_by'] = $arrKolId['modified_by'];
        $arr['modified_on'] = date("Y-m-d H:i:s");
        $this->db->where_in('id', $arrKolId['kolId']);

        if ($this->db->update('kols', $arr)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Retrieves the education details for given education id
     * @author 	Ramesh B
     * @since June 06, 2012
     * @version 4.2
     * @params $educationId
     * @return unknown_type
     */
    function getEducationById($educationId) {
        $arrEducationDetails = array();
        $clientId = $this->session->userdata('client_id');
        $this->db->where('kol_educations.id', $educationId);
        $this->db->select(array('kol_educations.*', 'institutions.name','institutions.id as institutionsId','client_users.first_name','client_users.last_name','client_users.is_analyst'));
        $this->db->join('institutions', 'institutions.id = kol_educations.institute_id', 'left');
        $this->db->join('client_users', 'client_users.id = kol_educations.created_by', 'left');
        if ($clientId != INTERNAL_CLIENT_ID) {
            //$this->db->where("(kol_educations.client_id=$clientId or kol_educations.client_id=".INTERNAL_CLIENT_ID.")");
        }
        $arrEducationDetailsResult = $this->db->get('kol_educations');
        foreach ($arrEducationDetailsResult->result_array() as $arrRow) {
            $arrEducationDetails = $arrRow;
        }
        return $arrEducationDetails;
    }

    /**
     * Retrieves the education details for given education id
     * @author 	Ramesh B
     * @since June 06, 2012
     * @version 4.2
     * @params $educationId
     * @return unknown_type
     */
    function getAffiliationById($affId) {
        $arrAffDetails = array();
        $clientId = $this->session->userdata('client_id');
        $this->db->where('kol_memberships.id', $affId);
        $this->db->select(array('kol_memberships.*', 'institutions.name'));
        $this->db->join('institutions', 'institutions.id = kol_memberships.institute_id', 'left');

        if ($clientId != INTERNAL_CLIENT_ID) {
            //$this->db->where("(kol_educations.client_id=$clientId or kol_educations.client_id=".INTERNAL_CLIENT_ID.")");
        }
        $arrAffDetailsResult = $this->db->get('kol_memberships');
        foreach ($arrAffDetailsResult->result_array() as $arrRow) {
            $arrAffDetails = $arrRow;
        }
        //echo $this->db->last_query();
        return $arrAffDetails;
    }

    /**
     * Retrieves the education details for given education id
     * @author 	Ramesh B
     * @since June 06, 2012
     * @version 4.2
     * @params $educationId
     * @return unknown_type
     */
    function getEventById($eventId) {
        $arrEventDetails = array();
        $clientId = $this->session->userdata('client_id');
        $this->db->where('kol_events.id', $eventId);
        $this->db->select(array('event_sponsor_types.type as sponsor_type', 'event_sponsor_types.type as sponsor_type_name', 'kol_events.*', 'events.name', 'conf_event_types.event_type as conf_event_type', 'countries.country', 'event_topics.name as event_topic','event_topics.specialty_id as et_specialty_id', 'conf_session_types.session_type as conf_session_type', 'regions.region','client_users.first_name','client_users.last_name','client_users.is_analyst'));
        //$this->db->select(array('event_sponsor_types.type as sponsor_type', 'event_sponsor_types.type as sponsor_type_name', 'kol_events.*', 'events.name', 'conf_event_types.event_type as conf_event_type', 'countries.country', 'event_topics.name as event_topic', 'conf_session_types.session_type as conf_session_type', 'regions.region'));
        $this->db->join('events', 'events.id = kol_events.event_id', 'left');
        //$this->db->join('conf_event_types','conf_event_types.id = kol_events.event_type', 'left');
        $this->db->join('countries', 'countries.countryId = kol_events.country_id', 'left');
        $this->db->join('regions', 'regions.RegionID = kol_events.state_id', 'left');
        $this->db->join('conf_event_types', 'conf_event_types.id = kol_events.event_type', 'left');
        $this->db->join('conf_session_types', 'conf_session_types.id = kol_events.session_type', 'left');
        $this->db->join('event_topics', 'event_topics.id = kol_events.topic', 'left');
        $this->db->join('event_sponsor_types', 'event_sponsor_types.id = kol_events.sponsor_type', 'left');
        $this->db->join('client_users', 'client_users.id = kol_events.created_by', 'left');
        if ($clientId != INTERNAL_CLIENT_ID) {
            //$this->db->where("(kol_educations.client_id=$clientId or kol_educations.client_id=".INTERNAL_CLIENT_ID.")");
        }
        $arrEventDetailsResult = $this->db->get('kol_events');
        foreach ($arrEventDetailsResult->result_array() as $arrRow) {
            $arrEventDetails = $arrRow;
        }
        return $arrEventDetails;
    }

    function getEventRoles() {
        $this->db->order_by('role asc');
        $arrResultSet = $this->db->get('event_roles');
        foreach ($arrResultSet->result_array() as $row) {

            $arrRoles[$row['id']] = $row['role'];
        }
        return $arrRoles;
    }

    function saveAdditionalContact($arrContacts) {
        if ($this->db->insert('additionalcontacts', $arrContacts)) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    function listAdditionalContacts($kolId) {
        $locationType = array(
            '1' => 'Private practice',
            '2' => 'Hospital',
            '3' => 'Institution',
            '4' => 'Physical',
            '5' => 'Others'
        );
        $arrContacts = array();
        $this->db->select('additionalcontacts.*');
        //	$this->db->select('additionalcontacts.*,client_users.user_role_id as owner_role_id');
        //	$this->db->join('client_users','client_users.id=additionalcontacts.created_by','left');
        $this->db->where('kol_id', $kolId);
        $arrContactsResultSet = $this->db->get('additionalcontacts');
        foreach ($arrContactsResultSet->result_array() as $row) {
            if (isset($row['type']) && $row['type'] > 0) {
                $row['type'] = $locationType[$row['type']];
                $row['state'] = $this->Country_helper->getStateById($row['state_id']);
                $row['city'] = $this->Country_helper->getCityeById($row['city_id']);
            }
            $arrContacts[] = $row;
        }
        return $arrContacts;
    }

    function getAdditionalContactByType($kolId, $id) {
        $locationType = array(
            '1' => 'Private practice',
            '2' => 'Hospital',
            '3' => 'Institution',
            '4' => 'Physical',
            '5' => 'Others'
        );
        $arrContacts = array();
        $this->db->select('additionalcontacts.*');
        $this->db->where('kol_id', $kolId);
        $this->db->where('id', $id);
        $arrContactsResultSet = $this->db->get('additionalcontacts');
        foreach ($arrContactsResultSet->result_array() as $row) {
            if (isset($row['type']) && $row['type'] > 0) {
                $row['type'] = $locationType[$row['type']];
                $row['state'] = $this->Country_helper->getStateById($row['state_id']);
                $row['city'] = $this->Country_helper->getCityeById($row['city_id']);
            }
            $arrContacts[] = $row;
        }
        return $arrContacts;
    }

    function getAllNonProfiledKols() {
        $arrKolNames = array();
        $this->db->select('first_name,id,last_name');
        //$this->db->where_not_in('status',array('Completed'));
        $this->db->where_in('kols.status', array(PRENEW));
        $this->db->order_by('first_name', 'last_name');
        $result = $this->db->get('kols');
        foreach ($result->result_array() as $row) {
            $arrKolNames[$row['id']] = $row['first_name'] . " " . $row['last_name'];
        }
        return $arrKolNames;
    }

    /**
     * Delete the Conatcts Detail Data By Id
     *
     */
    function deleteContactsDetailById($id) {
        $this->db->where('id', $id);
        if ($query = $this->db->delete('additionalcontacts')) {
            return true;
        } else {
            return false;
        }
    }

    /*
     * To get List of Kol Names By passing Kol Name for autocomltete 
     * @author Vinayak
     * @since 2.4
     * @created on 3-6-2011
     */

    function getKolNamesForAutocompleteTest($kolName) {
        $arrKols = array();
        $this->db->select("first_name,middle_name,last_name");
        $this->db->like("concat(first_name,middle_name,last_name)", $kolName);
        $this->db->where('status', COMPLETED);
        $arrKolsResult = $this->db->get('kols');
        //echo $this->db->last_query();
        foreach ($arrKolsResult->result_array() as $row) {

            $arrKols[] = $row['first_name'] . ' ' . $row['middle_name'] . ' ' . $row['last_name'];
        }
        return $arrKols;
    }

    function getTopSpecialties($startIndex, $noOfRecords) {
        $this->db->select('specialties.specialty,count(kols.specialty) as specilatycount');
        $this->db->join('specialties', 'specialties.id=kols.specialty', 'inner');
        //$this->db->where('kols.status', COMPLETED);
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
            $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
            $this->db->where('kols_client_visibility.client_id', $client_id);
        }
        $this->db->group_by('kols.specialty');
        $this->db->order_by('specilatycount', 'desc');        
        $this->db->limit($noOfRecords, $startIndex);
        $specilatiesResultSet = $this->db->get('kols');
        foreach ($specilatiesResultSet->result_array() as $row) {
            $arrSpecilaties[] = $row;
        }
        return $arrSpecilaties;
    }

    function eventsByTypeTabularReport($typeId, $kol_id, $fromYear, $toYear, $filters, $viewType) {
        $arrEvents = array();
        $this->db->select('events.id,events.name, kol_events.organizer, kol_events.start, kol_events.end, COUNT(DISTINCT(kol_events.kol_id)) AS attended_kols');
        $this->db->join('events', 'kol_events.event_id  = events.id', 'left');
        $this->db->join('kols', 'kol_events.kol_id = kols.id', 'left');
        $this->db->where('event_type', $typeId);
        $this->db->where('(YEAR(kol_events.start) BETWEEN ' . $fromYear . ' AND ' . $toYear . ' OR YEAR(kol_events.start)=0)');
        //$this->db->where('kols.status', COMPLETED);
        if (count($viewType) > 0 && !empty($viewType))
            $this->db->where_in('kols.id', $viewType);
        //Refine by filters
        if ($filters != null) {
        	if(isset($filters['global_region'])){
        		$globalRegion = $filters['global_region'];
        		foreach($globalRegion as $arrGlobalRegionIds){
        			$globalRegionSorted[] = str_replace("%20"," ",$arrGlobalRegionIds);
        		}
        		$this->db->join('countries', 'countries.CountryId = kols.country_id','left');
        		$isKolsJoined = true;
        		$this->db->where_in('countries.GlobalRegion', $globalRegionSorted);
        	}
            if (isset($filters['specialty'])) {
                $this->db->join('specialties', 'specialties.id = kols.specialty', 'left');
                $this->db->where_in('specialties.id', $filters['specialty']);
            }
            if (isset($filters['country'])) {
            	if($isKolsJoined == false)
                	$this->db->join('countries', 'countries.CountryId = kols.country_id', 'left');
            	
                $this->db->where_in('countries.CountryId', $filters['country']);
            }
            if (isset($filters['state'])) {
                $this->db->join('regions', 'regions.RegionID = kols.state_id', 'left');
                $this->db->where_in('regions.RegionID', $filters['state']);
            }
            if (isset($filters['kol_id'])) {
                $this->db->where_in('kol_events.kol_id', $filters['kol_id']);
            }
            if (isset($filters['listName'])) {
                $userId = $this->session->userdata('user_id');
                $clientId = $this->session->userdata('client_id');
                $this->db->join('list_kols', 'list_kols.kol_id=kol_events.kol_id', 'left');
                $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
                $this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
                $this->db->where_in('list_names.id', $filters['listName']);
                $this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
            }
        }
        $this->db->group_by('event_id');
        $this->db->order_by('attended_kols', 'desc');
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
        	$this->db->where('kols_client_visibility.client_id', $client_id);
        }
        
        $arrResults = $this->db->get('kol_events');
        //pr($this->db->last_query());exit;
        foreach ($arrResults->result_array() as $row) {
            if ($arrResults->num_rows() != 0) {
                $row['start'] = sql_date_to_app_date($row['start']);
                $row['end'] = sql_date_to_app_date($row['end']);
                $arrEvents[] = $row;
            } else {
                return false;
            }
        }
        return $arrEvents;
    }

    function  getKolsByEventId($eventId){
        $this->db->select('kols.id,kols.unique_id, kols.first_name,kols.last_name,kols.middle_name,events.name,specialties.specialty,countries.Country as country,regions.Region as state, cities.City as city');       
        $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
        $this->db->join('events', 'events.id = kol_events.event_id', 'left');
        $this->db->join('specialties', 'specialties.id = kols.specialty', 'left');
        $this->db->join('countries', 'countries.CountryId = kols.country_id', 'left');
        $this->db->join('regions', 'regions.RegionID = kols.state_id', 'left');
        $this->db->join('cities', 'cities.CityID = kols.city_id', 'left');
        $this->db->where('events.id', $eventId);
        $this->db->group_by('kol_events.kol_id');
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
        	$this->db->where('kols_client_visibility.client_id', $client_id);
        }
        $result = $this->db->get('kol_events');
//         pr($this->db->last_query());exit;
       return $result->result_array();
    }
    function  getKolsByInstId($instId,$viewType){
        $this->db->select('kols.id,kols.unique_id, kols.first_name,kols.last_name,kols.middle_name,institutions.name ,specialties.specialty,countries.Country as country,regions.Region as state, cities.City as city');
        $this->db->join('kols', 'kols.id=kol_memberships.kol_id', 'left');
        $this->db->join('institutions', 'institutions.id = kol_memberships.institute_id', 'left');
        $this->db->join('specialties', 'specialties.id = kols.specialty', 'left');
        $this->db->join('countries', 'countries.CountryId = kols.country_id', 'left');
        $this->db->join('regions', 'regions.RegionID = kols.state_id', 'left');
        $this->db->join('cities', 'cities.CityID = kols.city_id', 'left');
        $this->db->where('institutions.id', $instId);
        $this->db->group_by('kol_memberships.kol_id');
        if (count($viewType) > 0 && !empty($viewType)){
        	$this->db->where_in('kols.id', $viewType);
        }
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
        	$this->db->where('kols_client_visibility.client_id', $client_id);
        }
        $result = $this->db->get('kol_memberships');
        //pr($this->db->last_query());exit;
        return $result->result_array();
    }
    
    function affsByTypeTabularReport($type, $kol_id, $fromYear, $toYear, $filters, $viewType) {
        $arrAffs = array();
        $this->db->select('institutions.id, institutions.name, COUNT(DISTINCT(kol_memberships.kol_id)) AS attended_kols');
        $this->db->join('engagement_types', 'engagement_types.id  = kol_memberships.engagement_id', 'left');
        $this->db->join('kols', 'kol_memberships.kol_id = kols.id', 'left');
        $this->db->join('institutions', 'institutions.id = kol_memberships.institute_id', 'left');
        $this->db->where('kol_memberships.type', $type);
        //$this->db->where('kol_memberships.start_date BETWEEN '.$fromYear.' AND '.$toYear.' OR kol_memberships.start_date=0)');
        //$this->db->where('kols.status', COMPLETED);
        if ($fromYear != 0 && $toYear != 0) {
            //	$this->db->where("(kol_memberships.start_date between  ".$fromYear."  and  ".$toYear."  or kol_memberships.start_date=0)");
            $this->db->where("((kol_memberships.start_date between  " . $fromYear . "  and  " . $toYear . ") or (kol_memberships.start_date=0 or kol_memberships.start_date=''))");
        }
        if (count($viewType) > 0 && !empty($viewType)){
            $this->db->where_in('kols.id', $viewType);
        }
        //Refine by filters
        if ($filters != null) {
        	if(isset($filters['global_region'])){
        		$globalRegion = $filters['global_region'];
        		foreach($globalRegion as $arrGlobalRegionIds){
        			$globalRegionSorted[] = str_replace("%20"," ",$arrGlobalRegionIds);
        		}
        		$this->db->join('countries', 'countries.CountryId = kols.country_id','left');
        		$isKolsJoined = true;
        		$this->db->where_in('countries.GlobalRegion', $globalRegionSorted);
        	}
            if (isset($filters['specialty'])) {
                $this->db->join('specialties', 'specialties.id = kols.specialty', 'left');
                $this->db->where_in('specialties.id', $filters['specialty']);
            }
            if (isset($filters['country'])) {
				if($isKolsJoined == false)
                	$this->db->join('countries', 'countries.CountryId = kols.country_id', 'left');
				
                $this->db->where_in('countries.CountryId', $filters['country']);
            }
            if (isset($filters['state'])) {
                $this->db->join('regions', 'regions.RegionID = kols.state_id', 'left');
                $this->db->where_in('regions.RegionId', $filters['state']);
            }
            if (!empty($filters['kol_id'])) {
                $this->db->where_in('kol_memberships.kol_id', $filters['kol_id']);
            }
            if (isset($filters['listName'])) {
                $userId = $this->session->userdata('user_id');
                $clientId = $this->session->userdata('client_id');
                $this->db->join('list_kols', 'list_kols.kol_id=kol_memberships.kol_id', 'left');
                $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
                $this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
                $this->db->where_in('list_names.id', $filters['listName']);
                $this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
            }
        }
        $this->db->group_by('kol_memberships.institute_id');
        $this->db->order_by('attended_kols', 'desc');
        
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
        	$this->db->where('kols_client_visibility.client_id', $client_id);
        }
        
        
        $arrResults = $this->db->get('kol_memberships');
       //pr($this->db->last_query());exit;
        foreach ($arrResults->result_array() as $row) {
            if ($arrResults->num_rows() != 0) {
                $row['date'] = '';
                if ($row['start_date'] != '')
                    $row['date'] .= $row['start_date'];
                else
                    $row['date'] .= 'NA';

                $row['date'] .= " - ";

                if ($row['end_date'] != '')
                    $row['date'] .= $row['end_date'];
                else
                    $row['date'] .= 'NA';

                if ($row['date'] == 'NA - NA') {
                    $row['date'] = '';
                }
                $arrAffs[] = $row;
            } else {
                return false;
            }
        }
        return $arrAffs;
    }

    function resetProfileImage($kolId) {
        $arrData['profile_image'] = '';
        $this->db->where_in('id', $kolId);
        if ($this->db->update('kols', $arrData)) {
            return true;
        } else {
            return false;
        }
    }

    function saveKolNoDuplicateCheck($rowData) {
        if ($this->db->insert('kols', $rowData)) {
            return $this->db->insert_id();
            ;
        } else
            return false;
    }

    function checkSimilarKols($rowData) {
        $arrResults = array();
        $this->db->select('kols.id,first_name,middle_name,last_name,org_id,kols.status,kols.profile_type,cities.City as city, regions.Region as state,specialties.specialty');
        $this->db->join('cities', 'kols.city_id = cities.CityId', 'left');
        $this->db->join('regions', 'kols.state_id = regions.RegionID', 'left');
        $this->db->join('specialties', 'kols.specialty= specialties.id', 'left');
        $where = "((first_name = \"" . $rowData['first_name'] . "\" AND last_name = \"" . $rowData['last_name'] . "\") OR (first_name = \"" . $rowData['last_name'] . "\" AND last_name = \"" . $rowData['first_name'] . "\") OR (first_name = \"" . $rowData['first_name'] . "\" AND last_name = \"" . substr($rowData['last_name'], 0, 1) . "\"))";
        //$this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
        $this->db->where($where);
        $results = $this->db->get('kols');
        //echo $this->db->last_query();
        if (is_object($results) && $results->num_rows() > 0)
            $arrResults = $results->result_array();
        return $arrResults;
    }

    function checkDuplicateKols($rowData) {
        $arrResults = array();
        $this->db->select('kols.id,salutation,first_name,middle_name,last_name,org_id,kols.status,kols.profile_type,cities.City as city, regions.Region as state,specialties.specialty');
        $this->db->join('cities', 'kols.city_id = cities.CityId', 'left');
        $this->db->join('regions', 'kols.state_id = regions.RegionID', 'left');
        $this->db->join('specialties', 'kols.specialty= specialties.id', 'left');
        $this->db->where('kols.first_name', $rowData['first_name']);
//		$this->db->where('kols.middle_name', $rowData['middle_name']);
        $this->db->where('kols.last_name', $rowData['last_name']);
        $this->db->where('kols.specialty', $rowData['specialty']);
        //$this->db->where('status !=','Not Requested');
        $results = $this->db->get('kols');
        //echo $this->db->last_query();
        if (is_object($results) && $results->num_rows() > 0)
            $arrResults = $results->result_array();
        return $arrResults;
    }

    function isNotRequestedProfileExists($rowData) {
        $arrResults = array();
        $this->db->select('kols.id,salutation,first_name,middle_name,last_name,title,division,address1,primary_phone,primary_email,fax,npi_num,org_id,kols.status,kols.profile_type,cities.City as city, regions.Region as state,specialties.specialty');
        $this->db->join('cities', 'kols.city_id = cities.CityId', 'left');
        $this->db->join('regions', 'kols.state_id = regions.RegionID', 'left');
        $this->db->join('specialties', 'kols.specialty= specialties.id', 'left');
        $where = "((first_name = \"" . $rowData['first_name'] . "\" AND last_name = \"" . $rowData['last_name'] . "\") OR (first_name = \"" . $rowData['last_name'] . "\" AND last_name = \"" . $rowData['first_name'] . "\"))";
        //$this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
        $this->db->where($where);
        $this->db->where('status', 'Not Requested');
        $results = $this->db->get('kols');
        //echo $this->db->last_query();
        if (is_object($results) && $results->num_rows() > 0) {
            $arrResults = $results->result_array();
            return $arrResults[0];
        } else
            return false;
    }

    function saveSpecialty($arrData) {
        $specialtyId = '';
        $this->db->where('specialty', $arrData['specialty']);
        $arrSpecialty = $this->db->get('specialties');
        if ($arrSpecialty->num_rows() != 0) {
            $specialtyObj = $arrSpecialty->first_row();
            $specialtyId = $specialtyObj->id;
        } else {
            if ($this->db->insert('specialties', $arrData)) {
                $specialtyId = $this->db->insert_id();
            } else {
                
            }
        }
        return $specialtyId;
    }

    /*
     * Lists all processed kols for analyst application, it's for ajax pagination,search and sort version of jqgrid
     * @author Ramesh B
     * @since 22 Feb 2013
     * @version otsuka1.0.11
     * @return Array or Integer
     */

    function getProcessedKols($limit = null, $startFrom = null, $doCount = null, $sidx = '', $sord = '', $where = '') {
        if (!$doCount) {
            $this->db->select(array('kols.id', 'kols.pin', 'kols.is_imported', 'kols.salutation', 'kols.first_name', 'kols.middle_name', 'kols.last_name', 'kols.gender', 'specialties.specialty', 'organizations.name as org_name', 'kols.is_pubmed_processed', 'kols.is_clinical_trial_processed', 'kols.status', 'client_users.user_name as user_full_name'));
        }

        $this->db->join('client_users', 'client_users.id = kols.created_by', 'left');
        $this->db->join('specialties', 'kols.specialty = specialties.id', 'left');
        $this->db->join('organizations', 'kols.org_id = organizations.id', 'left');

        //Add the where conditions for any jqgrid filters
        if (isset($where['kol_name'])) {
            $this->db->where("(kols.first_name LIKE '%" . $where['kol_name'] . "%' or kols.middle_name LIKE '%" . $where['kol_name'] . "%' or kols.last_name LIKE '%" . $where['kol_name'] . "%')");
//			$this->db->like('kols.first_name',$where['kol_name']);	
//			$this->db->like('kols.middle_name',$where['kol_name']);
//			$this->db->like('kols.last_name',$where['kol_name']);
        }
        if (isset($where['specialty'])) {
            $this->db->like('specialties.specialty', $where['specialty']);
        }
        if (isset($where['gender'])) {
            $this->db->like('kols.gender', $where['gender']);
        }
        if (isset($where['organization'])) {
            $this->db->like('organizations.name', $where['organization']);
        }
        if (isset($where['pubmed_processed'])) {
            if (preg_match("/[yes]{1,}/i", $where['pubmed_processed']))
                $where['pubmed_processed'] = 1;
            elseif (preg_match("/[no]{1,}/i", $where['pubmed_processed']))
                $where['pubmed_processed'] = 0;
            elseif (preg_match("/[re crawl]{1,}/i", $where['pubmed_processed']))
                $where['pubmed_processed'] = 2;
            $this->db->like('kols.is_pubmed_processed', $where['pubmed_processed']);
        }
        if (isset($where['trial_processed'])) {
            if (preg_match("/[yes]{1,}/i", $where['trial_processed']))
                $where['trial_processed'] = 1;
            elseif (preg_match("/[no]{1,}/i", $where['trial_processed']))
                $where['trial_processed'] = 0;
            $this->db->like('kols.is_clinical_trial_processed', $where['trial_processed']);
        }
        if (isset($where['created_by'])) {
            $this->db->like('client_users.user_name', $where['created_by']);
        }
        if (isset($where['pin'])) {
            $this->db->like('kols.pin', $where['pin']);
        }
        if (isset($where['status'])) {
            $this->db->like('kols.status', $where['status']);
        }

     //   $this->db->where("(client_users.client_id=" . INTERNAL_CLIENT_ID . " or kols.status='" . COMPLETED . "')");
     //   $this->db->where("(client_users.client_id=" . INTERNAL_CLIENT_ID . ")");

        if ($doCount) {
            $this->db->distinct();
            $count = $this->db->count_all_results('kols');
            return $count;
        } else {
            if ($sidx != '' && $sord != '') {
                switch ($sidx) {
                    case 'kol_name' : $this->db->order_by("kols.first_name", $sord);
                        break;
                    case 'specialty' :$this->db->order_by("specialties.specialty", $sord);
                        break;
                    case 'gender' :$this->db->order_by("kols.gender", $sord);
                        break;
                    case 'organization' :$this->db->order_by("organizations.name", $sord);
                        break;
                    case 'pubmed_processed' :$this->db->order_by("kols.is_pubmed_processed", $sord);
                        break;
                    case 'trial_processed' :$this->db->order_by("kols.is_clinical_trial_processed", $sord);
                        break;
                    case 'created_by' :$this->db->order_by("client_users.user_name", $sord);
                        break;
                    case 'status' :$this->db->order_by("kols.status", $sord);
                        break;
                }
                //$this->db->order_by($sidx,$sord);
            }
            $this->db->order_by('first_name', 'asc');

            $arrKolDetail = $this->db->get('kols', $limit, $startFrom);
            //pr($this->db->last_query());exit;
            return $arrKolDetail;
        }
    }

    function getCityIdByState($city, $stateId) {
        $cityID = 0;
        $this->db->select('cityId');
        $this->db->where('city', $city);
        if ($stateId != '') {
            $this->db->where('regionId', $stateId);
        }
        $city = $this->db->get('cities');
        if (isset($city) && is_object($city)) {
            foreach ($city->result_array() as $row4) {
                $cityID = $row4['cityId'];
            }
        }else{
            $cityID = $this->country_helper->checkCityIfExistElseAdd();
        }
        return $cityID;
    }

    function getStateIdByCountry($region, $countryId) {
        $cityID = 0;
        $this->db->select('regionId');
        $this->db->where('region', $region);
        if ($countryId != '') {
            $this->db->where('countryId', $countryId);
        }
        $city = $this->db->get('regions');
        if (isset($city) && is_object($city)) {
            foreach ($city->result_array() as $row4) {
                $cityID = $row4['regionId'];
            }
        }
        return $cityID;
    }

    function getInstituteNameById($arrId) {
        $instituteName = array();
        $arrayIds = array();
        if(!empty($arrId)){
            foreach($arrId as $key=>$value){
            	if(is_numeric($value)){
            		$arrayIds[$key] =  $value;
            	}
            }
            $this->db->select('id,name');
            $this->db->where_in('id', $arrayIds);
            $resultSet = $this->db->get('institutions');           
            foreach ($resultSet->result_array() as $row) {
                $instituteName[$row['id']] = $row['name'];
            }
        }       
        return $instituteName;
    }

    function getEventNameById($arrId) {

        $eventName = array();
        $this->db->select('id as event_id,name');
        $this->db->where_in('id', $arrId);
        $eventNameRusult = $this->db->get('events');
        foreach ($eventNameRusult->result_array() as $row) {
            $eventName[$row['event_id']] = $row['name'];
        }
        return $eventName;
    }

    function saveCustomFilters($arrData) {
        if ($this->db->insert('custom_filters', $arrData)) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    function getAllCustomFilterByUser($userId) {
        $arrData = array();
        $this->db->_reset_select();
        $this->db->where('created_by', $userId);
        $this->db->where('filter_type', 1);
        $this->db->order_by('applied_on', 'desc');
        $this->db->order_by('name', 'asc');
        $result = $this->db->get('custom_filters');
        foreach ($result->result_array() as $row) {
            $arrData[] = $row;
        }
        return $arrData;
    }

    function getFilterById($arrData) {
        $this->db->where('id', $arrData['id']);
        if ($this->db->update('custom_filters', $arrData)) {
            $this->db->where('id', $arrData['id']);
            $result = $this->db->get('custom_filters');
            if ($result->num_rows() > 0) {
                foreach ($result->result() as $row) {
                    $arrData = $row->filter_value;
                }
            }
            return $arrData;
        } else {
            return false;
        }
    }

    function updateCustomFilters($arrData) {
        $this->db->where('id', $arrData['id']);
        $result = $this->db->update('custom_filters', $arrData);
        if ($result)
            return true;
        else
            return false;
    }

    function deleteSavedFilter($filterId) {
        $this->db->where('id', $filterId);
        $result = $this->db->delete('custom_filters');
        if ($result)
            return true;
        else
            return false;
    }

    function updateSavedFilter($arrData) {
        $this->db->where('id', $arrData['id']);
        $result = $this->db->update('custom_filters', $arrData);
        if ($result)
            return true;
        else
            return false;
    }

    function getFilterByRecentApplied() {
        $userId = $this->session->userdata('user_id');
        $this->db->select("id,name,filter_value");
        $this->db->where('filter_type', 1);
        $this->db->where('created_by', $userId);
        $this->db->where('applied_on !=', '0000-00-00 00:00:00');
        $this->db->order_by('applied_on', "desc");
        $this->db->limit(1);
        $result = $this->db->get('custom_filters');
		//pr($this->db->last_query());exit;
        if ($result->num_rows() > 0) {
            foreach ($result->result_array() as $row) {
                $data = $row;
            }
            $arrPostData = array();
            $arrFilterValue = json_decode($data['filter_value']);
            $postData = explode('&', $arrFilterValue->postData);
            //pr($postData);exit;
            foreach ($postData as $key => $row) {
                $arrValues = array();
                $arrRow = explode('=', $row);
                $arrValues = explode(',', $arrRow[1]);
                foreach ($arrValues as $index => $value) {
                    if ($value != '') {
                        $eachFieldVal = explode("%2C", $value);
                        foreach ($eachFieldVal as $eachVal) {
                            $arrPostData[$arrRow[0]][$eachVal] = $eachVal;
                        }
                    }
                }
            }
//			pr($arrPostData);
            $arrFilterFields = array();
            foreach ($arrPostData as $key => $value) {
            	//pr($arrPostData);exit;
                switch ($key) {
                	case 'kol_types':
                		$arrFilterFields['title'] = $value;
                		break;
                    case 'specialties':
                        $arrFilterFields['specialty'] = $value;
                        break;
                    case 'states':
                        $arrFilterFields['state'] = $value;
                        break;
                    case 'cities':
                        $arrFilterFields['city'] = $value;
                        break;
                    case 'countries':
                        $arrFilterFields['country'] = $value;
                        break;
                    case 'organizations':
                        $arrFilterFields['organization'] = $value;
                        break;
                    case 'lists':
                        $arrFilterFields['list_id'] = $value;
                        break;
                    case 'educations':
                        $arrFilterFields['education'] = $value;
                        break;
                    case 'events':
                        $arrFilterFields['event_id'] = $value;
                        break;
                    case 'kol_id':
                        $arrFilterFields['kol_id'] = $value;
                        break;
                    case 'profile_type':
                        if ($arrPostData['profile_type']['Basic'] == 'Basic')
                            $arrFilterFields['profile_type'] = "Basic";
                        else if ($arrPostData['profile_type']['Basic%20Plus'] == 'Basic%20Plus')
                            $arrFilterFields['profile_type'] = "Basic Plus";
                        else if ($arrPostData['profile_type']['Full%20Profile'] == 'Full%20Profile')
                            $arrFilterFields['profile_type'] = "Full Profile";
                        break;
                }
            }
//			pr($arrFilterFields);
            $data['filter_value'] = $arrPostData;
            $data['arrFilterFields'] = $arrFilterFields;
            return $data;
        }else {
            return false;
        }
    }

    function resetAppliedFilter($userId) {
        $arrData['applied_on'] = '';
        $this->db->where("created_by", $userId);
        $this->db->where("filter_type", 1);
        if ($this->db->update("custom_filters", $arrData))
            return true;
        else
            return false;
    }

    function getKolNameById($id) {
        $kolName = array();
        $this->db->select('id,first_name,middle_name,last_name');
        $this->db->where_in('id', $id);
        $kolNameRusult = $this->db->get('kols');
        foreach ($kolNameRusult->result_array() as $key => $row) {
//			$kolName[$row['id']] = $row['first_name']." ".$row['middle_name']." ".$row['last_name'];
            $kolName[$row['id']] = $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']);
        }
        return $kolName;
    }

    function getKolNameByIdFilterLabel($id) {
        $kolName = array();
        $this->db->select('id,first_name,middle_name,last_name');
        $this->db->where_in('id', $id);
        $kolNameRusult = $this->db->get('kols');
        foreach ($kolNameRusult->result_array() as $key => $row) {
//			$kolName[$row['id']] = $row['first_name']." ".$row['middle_name']." ".$row['last_name'];
            $kolName = $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']);
        }
        return $kolName;
    }

    function getEventLoaction($kolId) {
       	$this->db->select('cities.city,cities.Latitude,cities.Longitude');
        $this->db->join('cities', 'cities.CityId=kol_events.city_id', 'inner');
        $this->db->where('kol_id', $kolId);
        $this->db->group_by('city');
        $this->db->order_by('kol_events.end', 'desc');
        //$this->db->limit(1,0);
        $arrResult = $this->db->get('kol_events');
        //print $this->db->last_query();exit;
        foreach ($arrResult->result_array() as $row) {
            $arrEvents[] = $row;
        }
        return $arrEvents;
        
        /* $this->db->select('cities.city,kol_events.Latitude,kol_events.Longitude');
        $this->db->join('cities', 'cities.CityId=kol_events.city_id', 'inner');
        $this->db->where('kol_id', $kolId);
        $this->db->where('kol_events.latitude IS NOT NULL',null,false);
        $this->db->where('kol_events.longitude IS NOT NULL',null,false);
        $this->db->group_by('cities.City');
        $this->db->order_by('kol_events.end', 'desc');
        //$this->db->limit(1,0);
        $arrResult = $this->db->get('kol_events');
        //print $this->db->last_query();exit;
        foreach ($arrResult->result_array() as $row) {
        	$arrEvents[] = $row;
        }
        return $arrEvents; */
    }

    /*
     * Counts the number of Events based on "session_type" for one kol
     * @param $kolId
     * @author Vianayak Malladad
     * @since 1.5
     * @return Array $arrAff ex:(array([0]=>array( [session_type] => Consulting  [count] => 5))
     *
     */

    function getEventsBySponsorType($arrKolId = 0, $fromYear = 0, $toYear = 0, $role = 0, $arrCountries = 0, $arrSpecialities = 0, $arrListNamesIds = 0, $arrStates = 0) {
        //pr($arrCountries);
        $arrEvents = array();
        $isKolsJoined = false;

        $this->db->select('event_sponsor_types.type,count(*) as count');
        $this->db->join('event_sponsor_types', 'event_sponsor_types.id=kol_events.sponsor_type', 'left');
        $this->db->where_not_in('kol_events.sponsor_type', 0);

        if (is_array($arrKolId)) {
            $this->db->where_in('kol_events.kol_id', $arrKolId);
        } else if ($arrKolId != 0) {
            $this->db->where('kol_events.kol_id', $arrKolId);
        }

        if ($role != '') {
            $this->db->where('kol_events.role', $role);
        }

        //Adding where condition for Country's if Exist
        if (is_array($arrCountries)) {
            $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where_in('kols.country_id', $arrCountries);
        } else if ($arrCountries != 0) {
            $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where('kols.country_id', $arrCountries);
        }
        if (is_array($arrStates)) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where_in('kols.state_id', $arrStates);
        }else if ($arrStates != 0) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where('kols.state_id', $arrStates);
        }

        //Adding where condition for Speciality's if Exist
        if (is_array($arrSpecialities)) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where_in('kols.specialty', $arrSpecialities);
        }else if ($arrSpecialities != 0) {
            if (!$isKolsJoined)
                $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            $isKolsJoined = true;
            $this->db->where('kols.specialty', $arrSpecialities);
        }

        if ($arrListNamesIds != '' && $arrListNamesIds != 0) {
            $userId = $this->session->userdata('user_id');
            $clientId = $this->session->userdata('client_id');
            $this->db->join('list_kols', 'list_kols.kol_id=kol_events.kol_id', 'left');
            $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
            $this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
            $this->db->where_in('list_names.id', $arrListNamesIds);
            $this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
        }

        if ($isKolsJoined) {
            //$this->db->where('kols.status', COMPLETED);
        } else {
            $this->db->join('kols', 'kols.id=kol_events.kol_id', 'left');
            //$this->db->where('kols.status', COMPLETED);
        }
        if ($fromYear != 0 && $toYear != 0)
            $this->db->where("(year(kol_events.start) between  " . $fromYear . "  and  " . $toYear . "  or year(kol_events.start)=0)");
        //	$this->db->where('year(kol_events.start) between ' .$fromYear. ' and ' .$toYear);
        $this->db->group_by('kol_events.sponsor_type');

        $arrEventsresult = $this->db->get('kol_events');
//		echo $this->db->last_query();
        foreach ($arrEventsresult->result_array() as $row) {
            $arrEvents[] = $row;
        }
        return $arrEvents;
    }

    function saveEducationDetailByBulk($educationDetail) {

        foreach ($educationDetail as $row) {
            $row['honor_name'] = mysql_real_escape_string($row['honor_name']);
            $row['degree'] = mysql_real_escape_string($row['degree']);
            $row['specialty'] = mysql_real_escape_string($row['specialty']);
            $bulkInsert.="('" . $row['type'] . "','" . $row['institute_id'] . "','" . $row['degree'] . "','" . $row['honor_name'] . "','" . $row['specialty'] . "','" . $row['year'] . "','" . $row['start_date'] . "','" . $row['end_date'] . "','" . $row['created_by'] . "',
			
			'" . $row['created_on'] . "','" . $row['client_id'] . "','" . $row['kol_id'] . "','" . $row['data_type_indicator'] . "')" . ',';
            ;
            //,$row['institute_id'],'".$row['degree']."','".$row['specialty']."','".$row['start_date']."','".$row['end_date']."','".$row['end_date']."')";
        }

        $eduString = substr($bulkInsert, 0, -1);
        //echo $new;
        $this->db->query('insert into kol_educations(`type`,`institute_id`,`degree`,`honor_name`,`specialty`,`year`,`start_date`,`end_date`,`created_by`,`created_on`,`client_id`,`kol_id`,`data_type_indicator`) values ' . $eduString . '');
        //	$this->db->insert_batch('kol_events', $educationDetail); 
    }

    function saveAffiliationDetailByBulk($affiliationDetail) {

        foreach ($affiliationDetail as $row) {
           // $row['role'] = mysql_real_escape_string($row['role']);
           // $row['department'] = mysql_real_escape_string($row['department']);
           $row['role'] = addslashes($row['role']);
           $row['department'] = addslashes($row['department']);
            $bulkInsert.="('" . $row['engagement_id'] . "','" . $row['type'] . "','" . $row['institute_id'] . "','" . $row['department'] . "','" . $row['role'] . "','" . $row['start_date'] . "','" . $row['end_date'] . "','" . $row['created_by'] . "',
			
			'" . $row['created_on'] . "','" . $row['client_id'] . "','" . $row['kol_id'] . "','" . $row['data_type_indicator'] . "')" . ',';
            ;
            //,$row['institute_id'],'".$row['degree']."','".$row['specialty']."','".$row['start_date']."','".$row['end_date']."','".$row['end_date']."')";
        }

        $affiliationString = substr($bulkInsert, 0, -1);

        $this->db->query('insert into kol_memberships(`engagement_id`,`type`,`institute_id`,`department`,`role`,`start_date`,`end_date`,`created_by`,`created_on`,`client_id`,`kol_id` ,`data_type_indicator`) values ' . $affiliationString . '');
//		echo $this->db->last_query();
    }

    function saveEventDetailByBulk($eventDetail) {
$bulkInsert	= '';
        foreach ($eventDetail as $row) {
 /*           $row['session_name'] = mysql_real_escape_string($row['session_name']);
            $row['role'] = mysql_real_escape_string($row['role']);
            $row['organizer'] = mysql_real_escape_string($row['organizer']);
            $row['location'] = mysql_real_escape_string($row['location']);
            $row['address'] = mysql_real_escape_string($row['address']);
            $row['organizer_type'] = mysql_real_escape_string($row['organizer_type']);
            $row['session_sponsor'] = mysql_real_escape_string($row['session_sponsor']);
            $row['sponsor_type'] = mysql_real_escape_string($row['sponsor_type']);
*/
        	$row['session_name'] = addslashes($row['session_name']);
            $row['role'] = addslashes($row['role']);
            $row['organizer'] = addslashes($row['organizer']);
            $row['location'] = addslashes($row['location']);
            $row['address'] = addslashes($row['address']);
            $row['organizer_type'] = addslashes($row['organizer_type']);
            $row['session_sponsor'] = addslashes($row['session_sponsor']);
            $row['sponsor_type'] = addslashes($row['sponsor_type']);

            $bulkInsert.="('" . $row['organizer_type'] . "','" . $row['session_sponsor'] . "','" . $row['sponsor_type'] . "','" . $row['type'] . "','" . $row['event_id'] . "','" . $row['event_type'] . "','" . $row['session_type'] . "',
						'" . $row['session_name'] . "','" . $row['role'] . "','" . $row['topic'] . "','" . $row['start'] . "',
						'" . $row['end'] . "','" . $row['organizer'] . "','" . $row['location'] . "','" . $row['address'] . "',
						'" . $row['country_id'] . "','" . $row['state_id'] . "','" . $row['city_id'] . "','" . $row['postal_code'] . "',
						'" . $row['created_by'] . "','" . $row['created_on'] . "','" . $row['client_id'] . "','" . $row['kol_id'] . "','" . $row['data_type_indicator'] . "')" . ',';
            ;
            //,$row['institute_id'],'".$row['degree']."','".$row['specialty']."','".$row['start_date']."','".$row['end_date']."','".$row['end_date']."')";
        }

        $eventString = substr($bulkInsert, 0, -1);
        //echo $new;
        $this->db->query('insert into kol_events(`organizer_type`,`session_sponsor`,`sponsor_type`,`type`,`event_id`,`event_type`,`session_type`,`session_name`,`role`,`topic`,
						`start`,`end`,`organizer`,`location`,`address`,`country_id`,`state_id`,`city_id`,`postal_code`,`created_by`,`created_on`,`client_id`,`kol_id`, `data_type_indicator`) values ' . $eventString . '');
    }

    function getCountOfEducations($kolId) {

        $this->db->where('kol_id', $kolId);
        $result = $this->db->count_all_results('kol_educations');
        return $result;
    }

    function getCountOfAffiliation($kolId) {

        $this->db->where('kol_id', $kolId);
        $result = $this->db->count_all_results('kol_memberships');
        return $result;
    }

    function getCountOfEvents($kolId) {

        $this->db->where('kol_id', $kolId);
        $result = $this->db->count_all_results('kol_events');
        return $result;
    }

    function getCountOfPubs($kolId) {

        $this->db->where('kol_id', $kolId);
        $result = $this->db->count_all_results('kol_publications');
        return $result;
    }

    function getCountOfTrials($kolId) {

        $this->db->where('kol_id', $kolId);
        $result = $this->db->count_all_results('kol_clinical_trials');
        return $result;
    }

    function getEventsBySessionTypeByKolId($kolId, $startDate, $endDate, $session_type) {
        $this->db->select("kol_events.*,events.name");
        $this->db->join('conf_session_types', 'conf_session_types.id = kol_events.session_type', 'left');
        $this->db->join('events', 'events.id = kol_events.event_id', 'left');
        $this->db->where('kol_id', $kolId);
        $this->db->where('conf_session_types.session_type', $session_type);
        $this->db->where("(year(kol_events.start) between  " . $startDate . "  and  " . $endDate . "  or year(kol_events.start)=0)");
        $arrResult = $this->db->get('kol_events');
//		echo $this->db->last_query();
        foreach ($arrResult->result_array() as $row) {
            $arrEvents[] = $row;
        }
        return $arrEvents;
    }

    function getEventsByTopicNameByKolId($kolId, $startDate, $endDate, $topicName) {
        $this->db->select("kol_events.*,events.name");
        $this->db->join('event_topics', 'event_topics.id = kol_events.topic', 'left');
        $this->db->join('events', 'events.id = kol_events.event_id', 'left');
        $this->db->where('kol_id', $kolId);
        $this->db->where('event_topics.name', $topicName);
        $this->db->where("(year(kol_events.start) between  " . $startDate . "  and  " . $endDate . "  or year(kol_events.start)=0)");
        $arrResult = $this->db->get('kol_events');
//		echo $this->db->last_query();
        foreach ($arrResult->result_array() as $row) {
            $arrEvents[] = $row;
        }
        return $arrEvents;
    }

    function getEventsByRoleByKolId($kolId, $startDate, $endDate, $roleName) {
        $this->db->select("kol_events.*,events.name");
        $this->db->join('events', 'events.id = kol_events.event_id', 'left');
        $this->db->where('kol_id', $kolId);
        $this->db->where('kol_events.role', $roleName);
        $this->db->where("(year(kol_events.start) between  " . $startDate . "  and  " . $endDate . "  or year(kol_events.start)=0)");
        $arrResult = $this->db->get('kol_events');
//		echo $this->db->last_query();
        foreach ($arrResult->result_array() as $row) {
            $arrEvents[] = $row;
        }
        return $arrEvents;
    }

    function getEventsByTimelineByKolId($kolId, $startDate, $eventType) {
        $this->db->select("DISTINCT(kol_events.event_id),kol_events.start,kol_events.end,kol_events.organizer,events.name");
//		$this->db->select("kol_events.*,events.name");
        $this->db->join('conf_event_types', 'conf_event_types.id = kol_events.event_type', 'left');
        $this->db->join('events', 'events.id = kol_events.event_id', 'left');
        $this->db->where('kol_id', $kolId);
        $this->db->where('conf_event_types.event_type', $eventType);
        $this->db->where("(year(kol_events.start) between  " . $startDate . "  and  " . $startDate . ")");
        $arrResult = $this->db->get('kol_events');
//		echo $this->db->last_query();
        foreach ($arrResult->result_array() as $row) {
            $arrEvents[] = $row;
        }
        return $arrEvents;
    }

    function deleteEducationDetailByIds($ids) {
        $this->db->where_in('id', $ids);
        if ($query = $this->db->delete('kol_educations')) {
            return true;
        } else {
            return false;
        }
    }

    function deleteselectedAffiliations($arrAffIds) {
        $this->db->where_in('id', $arrAffIds);
        if ($query = $this->db->delete('kol_memberships')) {
            return true;
        } else {
            return false;
        }
    }

    function deleteselectedEvents($arrEveIds) {
        $this->db->where_in('id', $arrEveIds);
        if ($query = $this->db->delete('kol_events')) {
            return true;
        } else {
            return false;
        }
    }

    function getEventsBySponsorByKolId($kolId, $startDate, $endDate, $sponsorName) {
        $this->db->select("kol_events.*,events.name");
        $this->db->join('events', 'events.id = kol_events.event_id', 'left');
        $this->db->join('event_sponsor_types', 'event_sponsor_types.id = kol_events.sponsor_type', 'left');
        $this->db->where('kol_id', $kolId);
        $this->db->where('event_sponsor_types.type', $sponsorName);
        $this->db->where("(year(kol_events.start) between  " . $startDate . "  and  " . $endDate . "  or year(kol_events.start)=0)");
        $arrResult = $this->db->get('kol_events');
        //echo $this->db->last_query();
        foreach ($arrResult->result_array() as $row) {
            $arrEvents[] = $row;
        }
        return $arrEvents;
    }

    function getMyKolsView($userId) {
        $this->db->select('kol_id');
        $this->db->where('user_id', $userId);
        $this->db->join('kols', 'user_kols.kol_id = kols.id', 'left');
        //$this->db->where('kols.status',COMPLETED);
        $this->db->where('kols.customer_status', "ACTV");
        $result = $this->db->get('user_kols');
        foreach ($result->result_array() as $row) {
            $arr[$row['kol_id']] = $row['kol_id'];
        }
        return $arr;
    }

    /**
     * Retruns the kolId by matching the 'NPI'
     * @author Ramesh B
     * @since 
     * @return 
     * @created 
     */
    function getKolIdByNPI($npi) {
        $id = 0;
        $this->db->where('npi_num', $npi);
        $this->db->select('id');
        $result = $this->db->get('kols');
        $data = $result->row();
        if ($data != null)
            $id = $data->id;
        return $id;
    }

    function getKolIdByMDM($npi) {
        $id = 0;
        $this->db->where('mdm_id', $npi);
        $this->db->select('id');
        $result = $this->db->get('kols');
        $data = $result->row();
        if ($data != null)
            $id = $data->id;
        return $id;
    }

    /**
     * Retruns the kol Status by matching the 'KOL id'
     * @author Ramesh B
     * @since 
     * @return 
     * @created 
     */
    function getKolStatus($kolId) {
        $status = '';
        $this->db->where('id', $kolId);
        $this->db->select('status');
        $result = $this->db->get('kols');
        $data = $result->row();
        if ($data != null)
            $status = $data->status;
        return $status;
    }

    function addToKolAnalytics($kolId) {
        $arrInsert = array();
        $arrInsert["kol_id"] = $kolId;
        $arrInsert["user_id"] = $this->session->userdata('user_id');
        $arrInsert["client_id"] = $this->session->userdata('client_id');
        $arrInsert["created_on"] = date("Y-m-d H:i:s");
        $datetime_from = date("Y-m-d H:i:s", strtotime("-10 minutes", strtotime(date("Y-m-d H:i:s"))));
        $this->db->where("user_id", $arrInsert["user_id"]);
        $this->db->where("kol_id", $kolId);
        $this->db->where("created_on > ", $datetime_from);
        $arrData = $this->db->get("kol_ananlytics");
        if ($arrData->num_rows() == 0) {
            $this->db->insert("kol_ananlytics", $arrInsert);
        }
        return true;
    }

    function getAllAffTypes($kolId, $type = '') {
        $this->db->select('count(*) as count');
        $this->db->where('kol_id', $kolId);
        if ($type != '')
            $this->db->where('type', $type);
        $result = $this->db->get('kol_memberships');
        if ($result->num_rows() > 0) {
            foreach ($result->result_array() as $row) {
                $count = $row['count'];
            }
            if ($count > 0)
                return true;
            else
                return false;
        }else {
            return false;
        }
    }

    function getEvent($kolId) {
        $this->db->select('count(*) as count');
        $this->db->where('kol_id', $kolId);
        $result = $this->db->get('kol_events');
        if ($result->num_rows() > 0) {
            foreach ($result->result_array() as $row) {
                $count = $row['count'];
            }
            if ($count > 0)
                return true;
            else
                return false;
        }else {
            return false;
        }
    }

    function getPubs($kolId) {
        $this->db->select('count(*) as count');
        $this->db->where('kol_id', $kolId);
        $result = $this->db->get('kol_publications');
        if ($result->num_rows() > 0) {
            foreach ($result->result_array() as $row) {
                $count = $row['count'];
            }
            if ($count > 0)
                return true;
            else
                return false;
        }else {
            return false;
        }
    }

    function getSocialMedia($kolId) {
        $this->db->select('count(*) as count');
        $this->db->where('id', $kolId);
        $result = $this->db->get('kols');
        if ($result->num_rows() > 0) {
            foreach ($result->result_array() as $row) {
                $count = $row['count'];
            }
            if ($count > 0)
                return true;
            else
                return false;
        }else {
            return false;
        }
    }

    function getKolMediaById($kolId) {
        $this->db->select("kol_media.*,STR_TO_DATE(DATE, '%m/%d/%Y') AS datas", false);
        $this->db->where('kol_id', $kolId);
        $this->db->order_by("datas", "DESC");
        $arrResult = $this->db->get('kol_media');
//		echo $this->db->last_query();
        $retArr = array();
        if ($arrResult->num_rows() > 0) {
            foreach ($arrResult->result_array() as $row) {
                $retArr[] = $row;
            }
            return $retArr;
        } else {
            return false;
        }
    }

    function getMediaCount($kolId) {
        $this->db->where('kol_id', $kolId);
        $result = $this->db->get('kol_media');
        if ($result->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    function getSocialMediaCount($kolId) {
        $this->db->where('facebook !=', '');
        $this->db->where('you_tube !=', '');
        $this->db->where('twitter !=', '');
        $this->db->where('id', $kolId);
        $result = $this->db->get('kols');
        if ($result->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    function getAllClinicalTrials($kolId) {
        $this->db->where('kol_id', $kolId);
        $result = $this->db->get('kol_clinical_trials');
        if ($result->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    function listAllMedia($kolId) {
        $this->db->select("kol_media.*,STR_TO_DATE(DATE, '%m/%d/%Y') AS datas", false);
        $this->db->where('kol_id', $kolId);
        $this->db->order_by("datas", "DESC");
        $arrResult = $this->db->get('kol_media');
        $retArr = array();
        if ($arrResult->num_rows() > 0) {
            foreach ($arrResult->result_array() as $row) {
                $retArr[] = $row;
            }
            return $retArr;
        } else {
            return array();
        }
    }

    function getAllAffiliationsTypeIndustry($type = '', $where) {
        $clientId = $this->session->userdata('client_id');
        $arrMembershipDetails = array();
//		if($kolId != null){
        //Getting the data from 'kol_memberships' table and 'name' from 'institutions' table
        $this->db->select(array('kol_memberships.*', 'institutions.name', 'engagement_types.engagement_type'));
        $this->db->join('institutions', 'institutions.id = kol_memberships.institute_id', 'left');
        $this->db->join('engagement_types', 'engagement_types.id = kol_memberships.engagement_id', 'left');
        if ($where['kol_id'] != '')
            $this->db->where('kol_memberships.kol_id', $where['kol_id']);

        $this->db->where('institutions.name', $where['organizer']);
        if ($where['start'] != '')
            $this->db->where('kol_memberships.start_date', $where['start']);
        if ($where['start'] != '')
            $this->db->where('kol_memberships.end_date', $where['end']);

        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where("(kol_memberships.client_id=$clientId or kol_memberships.client_id=" . INTERNAL_CLIENT_ID . ")");
        }
        if ($type != '')
            $this->db->where('type', $type);
        else
            $this->db->where('type !=', 'industry');

        $this->db->order_by('institutions.name', 'asc');
        if ($arrMembershipDetailResult = $this->db->get('kol_memberships')) {
            if ($arrMembershipDetailResult->num_rows() == 0) {
                return false;
            }

            foreach ($arrMembershipDetailResult->result_array() as $arrMembership) {
                $arrMembershipDetails[] = $arrMembership;
            }
            return $arrMembershipDetails;
        } else
            return false;

//		}
    }

    function deleteIndusAffiliation($id, $kolId, $type) {
        $this->db->where('kol_id', $kolId);
        $this->db->where('source_row_id', $id);
        if ($type == 'event')
            $this->db->where('added_from', 1);
        else if ($type == 'trial')
            $this->db->where('added_from', 2);
        if ($this->db->delete('kol_memberships')) {
            return true;
        }
    }

    function getTopConceptDataForChart($kolId, $fromYear, $toYear, $keyword, $limit = '') {
        $arrMajorMeshterm = array();
        $this->db->select('pubmed_mesh_terms.id,pubmed_mesh_terms.term_name as name,count(distinct kol_publications.pub_id) as count,pubmed_mesh_terms.parent_id,pubmed_mesh_terms.tree_id');
        $this->db->join('publication_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id', 'left');
        $this->db->join('publications', 'publications.id = publication_mesh_terms.pub_id', 'left');
        $this->db->join('kol_publications', 'kol_publications.pub_id = publications.id', 'left');

        if ($keyword != '') {
            //$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
            //$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
            $this->db->join('publication_substances', 'publication_substances.pub_id=publications.id', 'left');
            $this->db->join('pubmed_substances', 'pubmed_substances.id=publication_substances.substance_id', 'left');
            $this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
        }
        $this->db->where('kol_publications.is_deleted', 0);
        $this->db->where('kol_publications.is_verified', 1);
        $this->db->where('kol_id', $kolId);
        //$this->db->where('publication_mesh_terms.is_major','0');
        $this->db->where('year(publications.created_date) between ' . $fromYear . ' and ' . $toYear);
        $this->db->group_by('pubmed_mesh_terms.term_name');
        $this->db->order_by('count', 'desc');
        if ($limit != 'all')
            $this->db->limit('20');

        $arrMajorMeshtermResult = $this->db->get('pubmed_mesh_terms');
        foreach ($arrMajorMeshtermResult->result_array() as $row) {
            $arrMajorMeshterm[] = $row;
        }
//		echo $this->db->last_query();
//		exit;
//		pr($arrMajorMeshterm);
        return $arrMajorMeshterm;
    }

    /**
     * Returns the count of number of events, affiliations for a particular kol
     * @author Shruti Purushan
     * @since 
     * @return 
     * @created 20-04-2015
     */
    function totalEvents($kolId) {
        $this->db->select("count(*) as count");
        $this->db->where("kol_id", $kolId);
        $result = $this->db->get("kol_events");
        foreach ($result->result_array() as $row) {
            $total = $row["count"];
        }
        return $total;
    }

    function totalTrainings($type, $kolId, $exclude = '') {
        $this->db->select("count(*) as count");
        $this->db->where("kol_id", $kolId);
        if ($type != 'all') {
            $this->db->where('type', $type);
        }
        if (!empty($exclude) || sizeof($exclude) > 0) {
            $this->db->where_not_in('type', $exclude);
        }
        $result = $this->db->get("kol_educations");
        foreach ($result->result_array() as $row) {
            $total = $row["count"];
        }
        return $total;
    }

    function totalTrainingsCount($type, $kolId, $exclude = '') {
        $this->db->select("count(*) as count");
        $this->db->where("kol_id", $kolId);
        if ($type != 'all') {
            $this->db->where('type', $type);
        }
        if (!empty($exclude) || sizeof($exclude) > 0) {
        	$this->db->where_not_in('type', $exclude);
        }
        $result = $this->db->get("kol_educations");
        //pr($this->db->last_query());exit;
        foreach ($result->result_array() as $row) {
            $total = $row["count"];
        }
        return $total;
    }

    function totalAffiliations($kolId) {
        $this->db->select("count(*) as count");
        $this->db->where("kol_id", $kolId);
        $result = $this->db->get("kol_memberships");
        foreach ($result->result_array() as $row) {
            $total = $row["count"];
        }
        return $total;
    }

    function listEducationDetailsRecent5($type, $kolId = null, $exclude = '') {
        $clientId = $this->session->userdata('client_id');

        $arrEducationDetails = array();
        //Get the Events of KolId
        if ($kolId != null) {
            $this->db->where('kol_id', $kolId);
            $this->db->order_by('kol_educations.start_date', 'desc');
            $this->db->order_by('kol_educations.end_date', 'desc');
            $this->db->limit(5, 0);
            if (!empty($exclude) || sizeof($exclude) > 0) {
                $this->db->where_not_in('type', $exclude);
            }
            if ($type != 'all') {
                $this->db->where('type', $type);
            }
            if ($type != 'honors_awards') {
                $this->db->select(array('kol_educations.*', 'institutions.name'));
                $this->db->join('institutions', 'institutions.id = kol_educations.institute_id', 'left');
            }
        }

        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where("(client_id=$clientId or client_id=" . INTERNAL_CLIENT_ID . ")");
        }
        if ($arrEducationDetailsResult = $this->db->get('kol_educations')) {
            foreach ($arrEducationDetailsResult->result_array() as $arrEducation) {
                if ($type != 'honors_awards') {
                    $arrEducation['institute_id'] = $arrEducation['name'];
                }
                if ($arrEducation['url1'] != '') {
                    $arrEducation['url1'] = '<a href=\'' . $arrEducation['url1'] . '\' target="_new">URL1</a>';
                }
                if ($arrEducation['url2'] != '') {
                    $arrEducation['url2'] = '<a href=\'' . $arrEducation['url2'] . '\' target="_new">URL2</a>';
                }
                $arrEducationDetails[] = $arrEducation;
            }
            return $arrEducationDetails;
        } else {
            return false;
        }
    }

    /*
     * Displaying 15 education details for mobile ui
     */

    function listEducationDetailsRecent15($type, $kolId = null) {
        $clientId = $this->session->userdata('client_id');

        $arrEducationDetails = array();
        //Get the Events of KolId
        if ($kolId != null) {
            $this->db->where('kol_id', $kolId);
            $this->db->order_by('kol_educations.start_date', 'desc');
            $this->db->order_by('kol_educations.end_date', 'desc');
            $this->db->limit(15, 0);
            if ($type != 'all') {
                $this->db->where('type', $type);
            }
            if ($type != 'honors_awards') {
                $this->db->select(array('kol_educations.*', 'institutions.name'));
                $this->db->join('institutions', 'institutions.id = kol_educations.institute_id', 'left');
            }
        }

        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where("(client_id=$clientId or client_id=" . INTERNAL_CLIENT_ID . ")");
        }
        if ($arrEducationDetailsResult = $this->db->get('kol_educations')) {
            foreach ($arrEducationDetailsResult->result_array() as $arrEducation) {
                if ($type != 'honors_awards') {
                    $arrEducation['institute_id'] = $arrEducation['name'];
                }
                if ($arrEducation['url1'] != '') {
                    $arrEducation['url1'] = '<a href=\'' . $arrEducation['url1'] . '\' target="_new">URL1</a>';
                }
                if ($arrEducation['url2'] != '') {
                    $arrEducation['url2'] = '<a href=\'' . $arrEducation['url2'] . '\' target="_new">URL2</a>';
                }
                $arrEducationDetails[] = $arrEducation;
            }
            return $arrEducationDetails;
        } else {
            return false;
        }
    }

    /*
     * Displaying only 15 details at a time for lazy loading in mobile ui
     */

    function listEducationDetailsRecent15LoadMore($type, $kolId = null, $offset) {
        $clientId = $this->session->userdata('client_id');

        $arrEducationDetails = array();
        //Get the Events of KolId
        if ($kolId != null) {
            $this->db->where('kol_id', $kolId);
            $this->db->order_by('kol_educations.start_date', 'desc');
            $this->db->order_by('kol_educations.end_date', 'desc');
            $this->db->limit(15, $offset);
            if ($type != 'all') {
                $this->db->where('type', $type);
            }
            if ($type != 'honors_awards') {
                $this->db->select(array('kol_educations.*', 'institutions.name'));
                $this->db->join('institutions', 'institutions.id = kol_educations.institute_id', 'left');
            }
        }

        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where("(client_id=$clientId or client_id=" . INTERNAL_CLIENT_ID . ")");
        }
        if ($arrEducationDetailsResult = $this->db->get('kol_educations')) {
            foreach ($arrEducationDetailsResult->result_array() as $arrEducation) {
                if ($type != 'honors_awards') {
                    $arrEducation['institute_id'] = $arrEducation['name'];
                }
                if ($arrEducation['url1'] != '') {
                    $arrEducation['url1'] = '<a href=\'' . $arrEducation['url1'] . '\' target="_new">URL1</a>';
                }
                if ($arrEducation['url2'] != '') {
                    $arrEducation['url2'] = '<a href=\'' . $arrEducation['url2'] . '\' target="_new">URL2</a>';
                }
                $arrEducationDetails[] = $arrEducation;
            }
            return $arrEducationDetails;
        } else {
            return false;
        }
    }

    function listAllAffiliationsDetailsRecent5($kolId = null) {
        $clientId = $this->session->userdata('client_id');
        $arrMembershipDetails = array();
        if ($kolId != null) {
            //Getting the data from 'kol_memberships' table and 'name' from 'institutions' table
            $this->db->select(array('kol_memberships.*', 'institutions.name', 'engagement_types.engagement_type'));
            $this->db->join('institutions', 'institutions.id = kol_memberships.institute_id', 'left');
            $this->db->join('engagement_types', 'engagement_types.id = kol_memberships.engagement_id', 'left');
            $this->db->where('kol_id', $kolId);

            if ($clientId != INTERNAL_CLIENT_ID) {
                $this->db->where("(kol_memberships.client_id=$clientId or kol_memberships.client_id=" . INTERNAL_CLIENT_ID . ")");
            }
            $this->db->order_by('kol_memberships.start_date', 'desc');
            $this->db->limit(5, 0);
            if ($arrMembershipDetailResult = $this->db->get('kol_memberships')) {
                if ($arrMembershipDetailResult->num_rows() == 0) {
                    return false;
                }

                foreach ($arrMembershipDetailResult->result_array() as $arrMembership) {
                    $arrMembershipDetails[] = $arrMembership;
                }
                return $arrMembershipDetails;
            } else
                return false;
        }
    }

    /*
     * Displaying 15 affiliation details for mobile ui
     */

    function listAllAffiliationsDetailsRecent15($kolId = null) {
        $clientId = $this->session->userdata('client_id');
        $arrMembershipDetails = array();
        if ($kolId != null) {
            //Getting the data from 'kol_memberships' table and 'name' from 'institutions' table
            $this->db->select(array('kol_memberships.*', 'institutions.name', 'engagement_types.engagement_type'));
            $this->db->join('institutions', 'institutions.id = kol_memberships.institute_id', 'left');
            $this->db->join('engagement_types', 'engagement_types.id = kol_memberships.engagement_id', 'left');
            $this->db->where('kol_id', $kolId);

            if ($clientId != INTERNAL_CLIENT_ID) {
                $this->db->where("(kol_memberships.client_id=$clientId or kol_memberships.client_id=" . INTERNAL_CLIENT_ID . ")");
            }
            $this->db->order_by('kol_memberships.end_date', 'desc');
            $this->db->limit(15, 0);
            if ($arrMembershipDetailResult = $this->db->get('kol_memberships')) {
                if ($arrMembershipDetailResult->num_rows() == 0) {
                    return false;
                }

                foreach ($arrMembershipDetailResult->result_array() as $arrMembership) {
                    $arrMembershipDetails[] = $arrMembership;
                }
                return $arrMembershipDetails;
            } else
                return false;
        }
    }

    /*
     * Displaying only 15 details at a time for lazy loading in mobile ui
     */

    function listAllAffiliationsDetailsRecent15LoadMore($kolId = null, $offset) {
        $clientId = $this->session->userdata('client_id');
        $arrMembershipDetails = array();
        if ($kolId != null) {
            //Getting the data from 'kol_memberships' table and 'name' from 'institutions' table
            $this->db->select(array('kol_memberships.*', 'institutions.name', 'engagement_types.engagement_type'));
            $this->db->join('institutions', 'institutions.id = kol_memberships.institute_id', 'left');
            $this->db->join('engagement_types', 'engagement_types.id = kol_memberships.engagement_id', 'left');
            $this->db->where('kol_id', $kolId);

            if ($clientId != INTERNAL_CLIENT_ID) {
                $this->db->where("(kol_memberships.client_id=$clientId or kol_memberships.client_id=" . INTERNAL_CLIENT_ID . ")");
            }
            $this->db->order_by('kol_memberships.end_date', 'desc');
            $this->db->limit(15, $offset);
            if ($arrMembershipDetailResult = $this->db->get('kol_memberships')) {
                if ($arrMembershipDetailResult->num_rows() == 0) {
                    return false;
                }

                foreach ($arrMembershipDetailResult->result_array() as $arrMembership) {
                    $arrMembershipDetails[] = $arrMembership;
                }
                return $arrMembershipDetails;
            } else
                return false;
        }
    }

    function listEventsRecent5($type, $kolId = null, $startDate = 0, $endDate = 0, $startFrom = 0, $limit = 5) {

        $clientId = $this->session->userdata('client_id');
        $arrEventsDetails = array();
        //Get the Events of KolId
        if ($kolId != null) {
            $this->db->where('kol_id', $kolId);
            $this->db->where('kol_events.type', $type);
            if ($startDate != 0 && $endDate != 0) {
                $wherBetween = "(YEAR(start) BETWEEN '$startDate' AND '$endDate' OR YEAR(start)='0')";
                $this->db->where($wherBetween);
            }
            if ($type == 'conference') {
                $this->db->select(array('kol_events.*', 'event_sponsor_types.type as stype', 'event_organizer_types.type as otype', 'events.name', 'countries.Country', 'regions.Region', 'cities.City', 'conf_session_types.session_type', 'conf_event_types.event_type', 'event_topics.name as topic_name'));
                $this->db->join('events', 'events.id = event_id', 'left');
                $this->db->join('countries', 'CountryId = country_id', 'left');
                $this->db->join('regions', 'RegionId = state_id', 'left');
                $this->db->join('cities', 'cityId = city_id', 'left');
                $this->db->join('conf_session_types', 'conf_session_types.id = kol_events.session_type', 'left');
                $this->db->join('conf_event_types', 'conf_event_types.id = kol_events.event_type', 'left');
                $this->db->join('event_topics', 'kol_events.topic = event_topics.id', 'left');
                $this->db->join('event_sponsor_types', 'kol_events.sponsor_type = event_sponsor_types.id', 'left');
                $this->db->join('event_organizer_types', 'kol_events.organizer_type = event_organizer_types.id', 'left');
            } else {
                $this->db->select(array('kol_events.*', 'online_event_types.event_type', 'events.name', 'kol_events.event_type as onEventTypeId'));
                $this->db->join('events', 'events.id = event_id', 'left');
                $this->db->join('online_event_types', 'online_event_types.id = kol_events.event_type', 'left');
            }
        }

        if ($limit != null)
            $this->db->limit($limit, $startFrom);

        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where("(client_id=$clientId or client_id=" . INTERNAL_CLIENT_ID . ")");
        }
//		$this->db->order_by('conf_event_types.event_type','desc');
//                $this->db->order_by('kol_memberships.start_date','desc');
//                        $this->db->order_by('kol_memberships.start_date','desc');

        $this->db->order_by('kol_events.end', 'desc');


        if ($arrEventsDetailsResult = $this->db->get('kol_events')) {
//			echo $this->db->last_query();
            foreach ($arrEventsDetailsResult->result_array() as $arrEvent) {
                $arrEvent['start'] = $this->convertDateToMM_DD_YYYY($arrEvent['start']);
                if ($arrEvent['start'] == '00/00/0000') {
                    $arrEvent['start'] = '';
                }
                $arrEvent['end'] = $this->convertDateToMM_DD_YYYY($arrEvent['end']);
                if ($arrEvent['end'] == '00/00/0000') {
                    $arrEvent['end'] = '';
                }
                if ($arrEvent['url1'] != '') {
                    $arrEvent['url1'] = '<a href=\'' . $arrEvent['url1'] . '\' target="_new">URl1</a>';
                }
                if ($arrEvent['url2'] != '') {
                    $arrEvent['url2'] = '<a href=\'' . $arrEvent['url2'] . '\' target="_new">URl2</a>';
                }
                $arrEventsDetails[] = $arrEvent;
            }
            return $arrEventsDetails;
        } else {
            return false;
        }
    }

    /*
     * Displaying 15 event details for mobile ui
     */

    function listEventsRecent15($type, $kolId = null, $startDate, $endDate, $startFrom = null, $limit = null) {

        $clientId = $this->session->userdata('client_id');
        $arrEventsDetails = array();
        //Get the Events of KolId
        if ($kolId != null) {
            $this->db->where('kol_id', $kolId);
            $this->db->where('kol_events.type', $type);
            if ($startDate != 0 && $endDate != 0) {
                $wherBetween = "(YEAR(start) BETWEEN '$startDate' AND '$endDate' OR YEAR(start)='0')";
                $this->db->where($wherBetween);
            }
            if ($type == 'conference') {
                $this->db->select(array('kol_events.*', 'event_sponsor_types.type as stype', 'event_organizer_types.type as otype', 'events.name', 'countries.Country', 'regions.Region', 'cities.City', 'conf_session_types.session_type', 'conf_event_types.event_type', 'event_topics.name as topic_name'));
                $this->db->join('events', 'events.id = event_id', 'left');
                $this->db->join('countries', 'CountryId = country_id', 'left');
                $this->db->join('regions', 'RegionId = state_id', 'left');
                $this->db->join('cities', 'cityId = city_id', 'left');
                $this->db->join('conf_session_types', 'conf_session_types.id = kol_events.session_type', 'left');
                $this->db->join('conf_event_types', 'conf_event_types.id = kol_events.event_type', 'left');
                $this->db->join('event_topics', 'kol_events.topic = event_topics.id', 'left');
                $this->db->join('event_sponsor_types', 'kol_events.sponsor_type = event_sponsor_types.id', 'left');
                $this->db->join('event_organizer_types', 'kol_events.organizer_type = event_organizer_types.id', 'left');
            } else {
                $this->db->select(array('kol_events.*', 'online_event_types.event_type', 'events.name', 'kol_events.event_type as onEventTypeId'));
                $this->db->join('events', 'events.id = event_id', 'left');
                $this->db->join('online_event_types', 'online_event_types.id = kol_events.event_type', 'left');
            }
        }

        if ($limit != null)
            $this->db->limit($limit, $startFrom);

        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where("(client_id=$clientId or client_id=" . INTERNAL_CLIENT_ID . ")");
        }
//		$this->db->order_by('conf_event_types.event_type','desc');
//                $this->db->order_by('kol_memberships.start_date','desc');
//                        $this->db->order_by('kol_memberships.start_date','desc');

        $this->db->order_by('kol_events.end', 'desc');
        $this->db->limit(15, 0);
        if ($arrEventsDetailsResult = $this->db->get('kol_events')) {
//			echo $this->db->last_query();
            foreach ($arrEventsDetailsResult->result_array() as $arrEvent) {
                $arrEvent['start'] = $this->convertDateToMM_DD_YYYY($arrEvent['start']);
                if ($arrEvent['start'] == '00/00/0000') {
                    $arrEvent['start'] = '';
                }
                $arrEvent['end'] = $this->convertDateToMM_DD_YYYY($arrEvent['end']);
                if ($arrEvent['end'] == '00/00/0000') {
                    $arrEvent['end'] = '';
                }
                if ($arrEvent['url1'] != '') {
                    $arrEvent['url1'] = '<a href=\'' . $arrEvent['url1'] . '\' target="_new">URl1</a>';
                }
                if ($arrEvent['url2'] != '') {
                    $arrEvent['url2'] = '<a href=\'' . $arrEvent['url2'] . '\' target="_new">URl2</a>';
                }
                $arrEventsDetails[] = $arrEvent;
            }
            return $arrEventsDetails;
        } else {
            return false;
        }
    }

    /*
     * Displaying only 15 details at a time for lazy loading in mobile ui
     */

    function listEventsRecent15LoadMore($type, $kolId = null, $startDate, $endDate, $offset) {

        $clientId = $this->session->userdata('client_id');
        $arrEventsDetails = array();
        //Get the Events of KolId
        if ($kolId != null) {
            $this->db->where('kol_id', $kolId);
            $this->db->where('kol_events.type', $type);
            if ($startDate != 0 && $endDate != 0) {
                $wherBetween = "(YEAR(start) BETWEEN '$startDate' AND '$endDate' OR YEAR(start)='0')";
                $this->db->where($wherBetween);
            }
            if ($type == 'conference') {
                $this->db->select(array('kol_events.*', 'event_sponsor_types.type as stype', 'event_organizer_types.type as otype', 'events.name', 'countries.Country', 'regions.Region', 'cities.City', 'conf_session_types.session_type', 'conf_event_types.event_type', 'event_topics.name as topic_name'));
                $this->db->join('events', 'events.id = event_id', 'left');
                $this->db->join('countries', 'CountryId = country_id', 'left');
                $this->db->join('regions', 'RegionId = state_id', 'left');
                $this->db->join('cities', 'cityId = city_id', 'left');
                $this->db->join('conf_session_types', 'conf_session_types.id = kol_events.session_type', 'left');
                $this->db->join('conf_event_types', 'conf_event_types.id = kol_events.event_type', 'left');
                $this->db->join('event_topics', 'kol_events.topic = event_topics.id', 'left');
                $this->db->join('event_sponsor_types', 'kol_events.sponsor_type = event_sponsor_types.id', 'left');
                $this->db->join('event_organizer_types', 'kol_events.organizer_type = event_organizer_types.id', 'left');
            } else {
                $this->db->select(array('kol_events.*', 'online_event_types.event_type', 'events.name', 'kol_events.event_type as onEventTypeId'));
                $this->db->join('events', 'events.id = event_id', 'left');
                $this->db->join('online_event_types', 'online_event_types.id = kol_events.event_type', 'left');
            }
        }

        if ($limit != null)
            $this->db->limit($limit, $startFrom);

        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where("(client_id=$clientId or client_id=" . INTERNAL_CLIENT_ID . ")");
        }
//		$this->db->order_by('conf_event_types.event_type','desc');
//                $this->db->order_by('kol_memberships.start_date','desc');
//                        $this->db->order_by('kol_memberships.start_date','desc');

        $this->db->order_by('kol_events.end', 'desc');
        $this->db->limit(15, $offset);
        if ($arrEventsDetailsResult = $this->db->get('kol_events')) {
//			echo $this->db->last_query();
            foreach ($arrEventsDetailsResult->result_array() as $arrEvent) {
                $arrEvent['start'] = $this->convertDateToMM_DD_YYYY($arrEvent['start']);
                if ($arrEvent['start'] == '00/00/0000') {
                    $arrEvent['start'] = '';
                }
                $arrEvent['end'] = $this->convertDateToMM_DD_YYYY($arrEvent['end']);
                if ($arrEvent['end'] == '00/00/0000') {
                    $arrEvent['end'] = '';
                }
                if ($arrEvent['url1'] != '') {
                    $arrEvent['url1'] = '<a href=\'' . $arrEvent['url1'] . '\' target="_new">URl1</a>';
                }
                if ($arrEvent['url2'] != '') {
                    $arrEvent['url2'] = '<a href=\'' . $arrEvent['url2'] . '\' target="_new">URl2</a>';
                }
                $arrEventsDetails[] = $arrEvent;
            }
            return $arrEventsDetails;
        } else {
            return false;
        }
    }

    /** load 15 */
    function listKols_load15($limit, $offset) {

        $arrKols = array();
        $this->db->select('kols.id,kols.gender,kols.salutation,kols.first_name,kols.middle_name,kols.last_name,kols.suffix,kols.profile_image,specialties.specialty as specs,countries.Country as country,organizations.name as name');
        $this->db->join('specialties', 'specialties.id=kols.specialty', 'left');
        $this->db->join('countries', 'countries.CountryId=kols.country_id', 'left');
        $this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
        $this->db->where('kols.status', COMPLETED);
        //$this->db->limit($limit, $startFrom);
        $this->db->limit(15, $offset);
        $this->db->order_by('kols.first_name');
        $arrResults = $this->db->get('kols');

        foreach ($arrResults->result_array() as $row) {
            $arrKols[$row['id']] = $row;
        }
        return $arrKols;
    }

    /**
     * Retrieves count of kols assigned to user
     * 
     * @author Sumati K
     * @since 
     * @created 29 April 2015
     * 
     */
    function getCountOfAssignedKols() {
        $this->db->where('user_kols.user_id', $this->session->userdata('user_id'));
        $this->db->from('user_kols');
        return $this->db->count_all_results();
    }

    /**
     * Retrieves all Education Institutes with respect to kols
     * 
     * @author Sumati K
     * @since 
     * @created 4 May 2015
     * 
     */
    function getAllEducationInstitutes() {
        $this->db->distinct();
        $this->db->select("institutions.*");
        $this->db->where('kol_educations.type', 'education');
        $this->db->join('kol_educations', 'kol_educations.institute_id=institutions.id');
        $this->db->order_by("name", "asc");
        $query = $this->db->get('institutions');
        return $query->result_array();
    }

    function getExcludedKolsEduIns($arrIds) {

        $this->db->select(array('distinct institutions.id', 'institutions.name', '0 as kol_edu_ins_count'), false);
        $this->db->join('kol_educations', 'kol_educations.kol_id=kols.id');
        $this->db->join('institutions', 'kol_educations.institute_id=institutions.id');

        $this->db->where('kols.status', 'Completed');
        $this->db->where('kol_educations.type', 'education');
        if (count($arrIds) != 0)
            $this->db->where_not_in('institutions.id', $arrIds);

        $this->db->order_by("institutions.name", "asc");
        $this->db->group_by('institutions.id');
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
        	$this->db->where('kols_client_visibility.client_id', $client_id);
        }
        $query = $this->db->get('kols');
        return $query->result_array();
    }

    /**
     * Retrieves kols based on search filters
     * 
     * @author Sumati K
     * @since 
     * @created 28 April 2015
     * 
     */
    function getKolsBySearch($searchData, $countFlag) {
        $query = "";
        $nameFormatOrder = $this->common_helpers->get_name_format_order_simple('kols');
        //get distinct kols
        $this->db->distinct();

        if ($countFlag == true) {
            $this->db->select('count(distinct kols.id) as count');
        } else {
            //fetch all kols with respect to assignment
            //All Contacts
            $this->db->select(array('kols.*', 'concat('.$nameFormatOrder.') as name', 'specialties.specialty', 'countries.Country as country', 'regions.Region as state', 'organizations.name as org_name', 'cities.City as city'));

            //if countflag is false then fetch 15 kols with respect to offset
            $this->db->limit(15, $searchData['offset'] - 15);
        }

        if ($searchData['assignedTo'] == $this->session->userdata('user_id')) {
            if ($countFlag != true) {
                //My Contacts
                $this->db->select(array('kols.*', 'concat('.$nameFormatOrder.') as name', 'specialties.specialty', 'countries.Country as country', 'regions.Region as state', 'organizations.name as org_name', 'cities.City as city'));
            }

            //fetch kols assigned to user
            $this->db->join('user_kols', 'kols.id=user_kols.kol_id');
            $this->db->where('user_kols.user_Id', $this->session->userdata('user_id'));
        }

        //sort kols in ascending order
        //$this->db->order_by("first_name", "asc");
        $nameFormat = $this->session->userdata('name_order');
        if ($nameFormat == 1 || $nameFormat == 3)
        	$this->db->order_by("first_name",'asc');
        	else if ($nameFormat == 2)
        		$this->db->order_by("last_name",'asc');

        //fetch kols based on lists
        if ($searchData['lists'] != "") {
            $this->db->join('list_kols', 'kols.id=list_kols.kol_id');
            $this->db->where_in('list_kols.list_name_id', $searchData['lists']);
        }

        //fetch kols based on profile type
        if ($searchData['profileType'] != "") {
            $this->db->where('kols.profile_type', $searchData['profileType']);
        }


        $this->db->join('specialties', 'specialties.id=kols.specialty', 'left');
        //fetch kols based on specialty
        if ($searchData['specialties'] != "") {
            $this->db->where_in('specialties.id', $searchData['specialties']);
        }

        $this->db->join('countries', 'countries.CountryId=kols.country_id', 'left');
        //fetch kols based on country
        if ($searchData['countries'] != "") {
            $this->db->where_in('kols.country_id', $searchData['countries']);
        }

        $this->db->join('regions', 'regions.RegionID = kols.state_id', 'left');
        //fetch kols based on state
        if ($searchData['states'] != "") {
            $this->db->where_in('kols.state_id', $searchData['states']);
        }

        $this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
        //fetch kols based on organization
        if ($searchData['organizations'] != "") {
            $this->db->where_in('kols.org_id', $searchData['organizations']);
        }

        //fetch kols based on education institutions
        if ($searchData['edu_ins'] != "") {
            $this->db->join('kol_educations', 'kols.id=kol_educations.kol_id');
            $this->db->where('kol_educations.type', 'education');
            $this->db->where_in('kol_educations.institute_id', $searchData['edu_ins']);
        }

        $this->db->join('cities', 'cities.CityId = kols.city_id', 'left');

        //fetch kols whose status is set to Completed
        //$this->db->where('kols.status', 'Completed');
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
        	$this->db->where('kols_client_visibility.client_id', $client_id);
        } 
        
        $query = $this->db->get('kols');

//       	print_r($this->db->last_query());
//        	exit();
        return $query->result_array();
    }

    function getKolsBySearchGrid($limit = null, $startFrom = null, $countFlag = null, $sidx = '', $sord = '', $searchData, $gridFilters) {
        $query = "";
        $nameFormatOrder = $this->common_helpers->get_name_format_order_simple('kols');    
        //get distinct kols
        $this->db->distinct();

        if ($countFlag == true) {
            $this->db->select('count(distinct kols.id) as count');
        } else {
            //fetch all kols with respect to assignment
            //All Contacts
            $this->db->select(array('kols.*', 'kols.id as kol_id', 'concat('.$nameFormatOrder.') as name', 'specialties.specialty', 'countries.Country as country', 'regions.Region as state', 'organizations.name as org_name', 'cities.City as city','organizations.type'));
        }

        if ($searchData['assignedTo'] == $this->session->userdata('user_id')) {
            if ($countFlag != true) {
                //My Contacts
                $this->db->select(array('kols.*', 'concat('.$nameFormatOrder.') as name', 'specialties.specialty', 'countries.Country as country', 'regions.Region as state', 'organizations.name as org_name', 'cities.City as city'));
            }

            //fetch kols assigned to user
            $this->db->join('user_kols', 'kols.id=user_kols.kol_id');
            $this->db->where('user_kols.user_Id', $this->session->userdata('user_id'));
        }

        //sort kols in ascending order
        $this->db->order_by("first_name", "asc");

        //fetch kols based on lists
        if ($searchData['lists'] != "") {
            $this->db->join('list_kols', 'kols.id=list_kols.kol_id');
            $this->db->where_in('list_kols.list_name_id', $searchData['lists']);
        }

        //fetch kols based on profile type
        if ($searchData['profileType'] != "") {
            $this->db->where('kols.profile_type', $searchData['profileType']);
        }


        $this->db->join('specialties', 'specialties.id=kols.specialty', 'left');
        //fetch kols based on specialty
        if ($searchData['specialties'] != "") {
            $this->db->where_in('specialties.id', $searchData['specialties']);
        }

        $this->db->join('countries', 'countries.CountryId=kols.country_id', 'left');
        //fetch kols based on country
        if ($searchData['countries'] != "") {
            $this->db->where_in('kols.country_id', $searchData['countries']);
        }

        $this->db->join('regions', 'regions.RegionID = kols.state_id', 'left');
        //fetch kols based on state
        if ($searchData['states'] != "") {
            $this->db->where_in('kols.state_id', $searchData['states']);
        }

        $this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
        $this->db->join('organization_types', 'organization_types.id = organizations.type_id', 'left');
        //fetch kols based on organization
        if ($searchData['organizations'] != "") {
            $this->db->where_in('kols.org_id', $searchData['organizations']);
        }

        //fetch kols based on education institutions
        if ($searchData['edu_ins'] != "") {
            $this->db->join('kol_educations', 'kols.id=kol_educations.kol_id');
            $this->db->where('kol_educations.type', 'education');
            $this->db->where_in('kol_educations.institute_id', $searchData['edu_ins']);
        }

        $this->db->join('cities', 'cities.CityId = kols.city_id', 'left');

        //fetch kols whose status is set to Completed
        $this->db->where('kols.status', 'Completed');

        if (isset($gridFilters['name'])) {
            $this->db->where("(kols.first_name LIKE '%" . $gridFilters['name'] . "%' or kols.middle_name LIKE '%" . $gridFilters['name'] . "%' or kols.last_name LIKE '%" . $gridFilters['name'] . "%')");
        }
        if (isset($gridFilters['specialty'])) {
            $this->db->like('specialties.specialty', $gridFilters['specialty']);
        }
        if (isset($gridFilters['state'])) {
            $this->db->like('regions.region', $gridFilters['state']);
        }
        if (isset($gridFilters['country'])) {
            $this->db->like('countries.country', $gridFilters['country']);
        }
        if (isset($gridFilters['primary_email'])) {
            $this->db->like('kols.primary_email', $gridFilters['primary_email']);
        }
        if (isset($gridFilters['primary_phone'])) {
            $this->db->like('kols.primary_phone', $gridFilters['primary_phone']);
        }

        if ($sidx != '' && $sord != '') {
            switch ($sidx) {
                case 'name' : $this->db->order_by("kols.name", $sord);
                    break;
                case 'specialty' :$this->db->order_by("specialties.specialty", $sord);
                    break;
                case 'state' :$this->db->order_by("regions.state", $sord);
                    break;
                case 'country' :$this->db->order_by("countries.country", $sord);
                    break;
                case 'primary_email' :$this->db->order_by("kols.primary_email", $sord);
                    break;
                case 'primary_phone' :$this->db->order_by("kols.primary_phone", $sord);
                    break;
            }
            //$this->db->order_by($sidx,$sord);
        }

        $query = $this->db->get('kols', $limit, $startFrom);

//        print_r($this->db->last_query());
//        exit();
        return $query->result_array();
    }

    /**
     * Retrieves filters based on selected search filters
     * 
     * @author Sumati K
     * @since 
     * @created 28 April 2015
     * @updated 8 May 2015
     */
    function getFiltersWrtKols($searchData, $type, $flag) {
        $query = "";

        //get distinct kols
        $this->db->distinct();


        //fetch all kols with respect to assignment
        //fetch kols based on lists
        if ($searchData['lists'] != "") {
            $this->db->join('list_kols', 'kols.id=list_kols.kol_id');
            if ($flag == false && $type == "lists") {
                $this->db->where_not_in('list_kols.list_name_id', $searchData['lists']);
            } else
                $this->db->where_in('list_kols.list_name_id', $searchData['lists']);
        }

        //fetch kols based on profile type
        if ($searchData['profileType'] != "") {
            $this->db->where('kols.profile_type', $searchData['profileType']);
        }

        //fetch kols based on specialty
        if ($searchData['specialties'] != "") {
            $this->db->join('specialties', 'specialties.id=kols.specialty');
            if ($flag == false && $type == "specialties") {
                $this->db->where_not_in('specialties.id', $searchData['specialties']);
            } else
                $this->db->where_in('specialties.id', $searchData['specialties']);
        }

        //fetch kols based on country
        if ($searchData['countries'] != "") {
            if ($flag == false && $type == "countries") {
                $this->db->where_not_in('kols.country_id', $searchData['countries']);
            } else
                $this->db->where_in('kols.country_id', $searchData['countries']);
        }

        //fetch kols based on state
        if ($searchData['states'] != "") {
            if ($flag == false && $type == "states") {
                $this->db->where_not_in('kols.state_id', $searchData['states']);
            } else
                $this->db->where_in('kols.state_id', $searchData['states']);
        }

        //fetch kols based on organization
        if ($searchData['organizations'] != "") {
            if ($flag == false && $type == "organizations") {
                $this->db->where_not_in('kols.org_id', $searchData['organizations']);
            } else
                $this->db->where_in('kols.org_id', $searchData['organizations']);
        }
          //fetch kols based on organization type
        if ($searchData['organizations_types'] != "") {
            if ($flag == false && $type == "organizations_types") {
                $this->db->where_not_in('kols.org_id', $searchData['organizations_types']);
            } else
                $this->db->where_in('kols.org_id', $searchData['organizations_types']);
        }
        //fetch kols based on education institutions
        if ($searchData['edu_ins'] != "") {
            $this->db->join('kol_educations', 'kols.id=kol_educations.kol_id');
            $this->db->where('kol_educations.type', 'education');
            if ($flag == false && $type == "edu_ins") {
                $this->db->where_not_in('kol_educations.institute_id', $searchData['edu_ins']);
            } else
                $this->db->where_in('kol_educations.institute_id', $searchData['edu_ins']);
        }

        //fetch kols whose status is set to Completed
        //$this->db->where('kols.status', 'Completed');

        if ($type == "specialties") {
            // get kol specialties with count
            if ($searchData['specialties'] == "") {
                $this->db->join('specialties', 'specialties.id = kols.specialty');
            }

            //All Contacts
            $this->db->select(array('specialties.id', 'specialties.specialty', 'count(distinct kols.id) as kol_specialty_count'));

            if ($searchData['assignedTo'] == $this->session->userdata('user_id')) {
                //My Contacts            
                //fetch kols assigned to user
                $this->db->join('user_kols', 'kols.id=user_kols.kol_id');
                $this->db->where('user_kols.user_Id', $this->session->userdata('user_id'));
            }
            $this->db->order_by("kol_specialty_count", "desc");
            $this->db->group_by('specialties.id');

            //$query = $this->db->get('kols');
        } else if ($type == "countries") {
            // get kol countries with count
            $this->db->join('countries', 'countries.CountryId=kols.country_id');

            //All Contacts
            $this->db->select(array('countries.CountryId', 'countries.Country', 'count(distinct kols.id) as kol_country_count'));

            if ($searchData['assignedTo'] == $this->session->userdata('user_id')) {
                //My Contacts            
                //fetch kols assigned to user
                $this->db->join('user_kols', 'kols.id=user_kols.kol_id');
                $this->db->where('user_kols.user_Id', $this->session->userdata('user_id'));
            }
            $this->db->group_by('countries.CountryId');
            $this->db->order_by("kol_country_count", "desc");

            //$query = $this->db->get('kols');
        } else if ($type == "states") {
            // get kol states with count
            $this->db->join('regions', 'regions.RegionID=kols.state_id');

            //All Contacts
            $this->db->select(array('regions.RegionID', 'regions.Region', 'count(distinct kols.id) as kol_state_count'));

            if ($searchData['assignedTo'] == $this->session->userdata('user_id')) {
                //My Contacts            
                //fetch kols assigned to user
                $this->db->join('user_kols', 'kols.id=user_kols.kol_id');
                $this->db->where('user_kols.user_Id', $this->session->userdata('user_id'));
            }
            $this->db->group_by('regions.RegionID');
            $this->db->order_by("kol_state_count", "desc");

            //$query = $this->db->get('kols');
        } else if ($type == "organizations") {
            // get kol organizations with count
            $this->db->join('organizations', 'organizations.id=kols.org_id');

            //All Contacts
            $this->db->select(array('organizations.id', 'organizations.name', 'count(distinct kols.id) as kol_org_count'));

            if ($searchData['assignedTo'] == $this->session->userdata('user_id')) {
                //My Contacts            
                //fetch kols assigned to user
                $this->db->join('user_kols', 'kols.id=user_kols.kol_id');
                $this->db->where('user_kols.user_Id', $this->session->userdata('user_id'));
            }
            $this->db->order_by("kol_org_count", "desc");
            $this->db->group_by('organizations.id');

            //$query = $this->db->get('kols');
        } else if ($type == "lists") {
            // get kol lists with count
            if ($searchData['lists'] == "") {
                $this->db->join('list_kols', 'list_kols.kol_id=kols.id');
            }
            $this->db->join('list_names', 'list_names.id=list_kols.list_name_id');
            $this->db->join('list_categories', 'list_names.category_id=list_categories.id');
            //All Contacts
            $this->db->select(array('list_names.id', 'list_names.list_name', 'count(distinct kols.id) as kol_list_count'));

            if ($searchData['assignedTo'] == $this->session->userdata('user_id')) {
                //My Contacts            
                //fetch kols assigned to user
                $this->db->join('user_kols', 'kols.id=user_kols.kol_id');
                $this->db->where('user_kols.user_Id', $this->session->userdata('user_id'));
            }
            $this->db->where('list_categories.client_id', $this->session->userdata('client_id'));
            $this->db->order_by("kol_list_count", "desc");
            $this->db->group_by('list_names.id');

            //$query = $this->db->get('kols');
        } else if ($type == "edu_ins") {
            // get kol educational institutions with count

            $this->db->distinct();
            if ($searchData['edu_ins'] == "") {
                $this->db->join('kol_educations', 'kol_educations.kol_id=kols.id');
            }
            $this->db->where('kol_educations.type', 'education');
            $this->db->join('institutions', 'kol_educations.institute_id=institutions.id');

            //All Contacts
            $this->db->select(array('institutions.id', 'institutions.name', 'count(distinct kols.id) as kol_edu_ins_count'));

            if ($searchData['assignedTo'] == $this->session->userdata('user_id')) {
                //My Contacts            
                //fetch kols assigned to user
                $this->db->join('user_kols', 'kols.id=user_kols.kol_id');
                $this->db->where('user_kols.user_Id', $this->session->userdata('user_id'));
            }
            $this->db->order_by("kol_edu_ins_count", "desc");
            $this->db->group_by('institutions.id');

            //$query = $this->db->get('kols');
        }
        
        $client_id = $this->session->userdata('client_id');
        if($client_id !== INTERNAL_CLIENT_ID){
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
        	$this->db->where('kols_client_visibility.client_id', $client_id);
        }
        $query = $this->db->get('kols');
		//pr($this->db->last_query());exit;
        return $query->result_array();
    }

    function networkMapKolDetails($kolId = null) {
        $this->db->select(array('kols.id',
            'kols.salutation',
            "concat(kols.first_name, ' ', kols.middle_name, ' ', kols.last_name) as name",
            'organizations.name as org_name',
            'specialties.specialty',
            'kols.suffix',
            'kols.profile_image',
            'kols.gender', 
            'titles.title',
            'kols.division',
            'countries.Country as country',
            'regions.Region as state',
            "concat(kols.address1, ' ', kols.address2) as address",
            'kols.postal_code',
            'kols.primary_phone',
            'kols.primary_email',
            'kols.fax'));
        $this->db->join('organizations', 'kols.org_id=organizations.id', 'left');
        $this->db->join('titles', 'kols.title = titles.id', 'left');
        $this->db->join('specialties', 'kols.specialty=specialties.id', 'left');
        $this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
        $this->db->join('regions', 'regions.regionID = kols.state_id', 'left');
        $this->db->join('cities', 'cities.cityID = kols.city_id', 'left');
        $this->db->where('kols.id', $kolId);
        $query = $this->db->get('kols');
        return $query->result_array();
    }

    function saveNote($arrDetails) {
    	//pr($arrDetails);exit;
        if ($this->db->insert('kol_notes', $arrDetails)) {
        	//pr($this->db->last_query());
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    function getNotes($kolId) {
        $rows = array();
        $client_id = $this->session->userdata('client_id');
        $this->db->select('kol_notes.*,client_users.first_name,client_users.last_name,modified.first_name as modified_by_first_name, modified.last_name as modified_by_last_name');
        $this->db->where('kol_notes.kol_id', $kolId);
        $this->db->join('client_users', 'kol_notes.created_by = client_users.id', 'left');
        $this->db->join('client_users as modified', 'kol_notes.modified_by = modified.id', 'left');
        if($client_id !== INTERNAL_CLIENT_ID){
            $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kol_notes.kol_id', 'left');
            $this->db->where('kols_client_visibility.client_id', $client_id);
        }
        $this->db->order_by('created_on', 'desc');
        $res = $this->db->get('kol_notes');
//         pr($this->db->last_query());exit;
        if ($res->num_rows() > 0)
            $rows = $res->result_array();

        return $rows;
    }

    function deleteNote($noteId) {
        $get = $this->db->get_where("kol_notes",array("id"=>$noteId))->row();
        $filename = $get->document;
        $this->db->where('id', $noteId);
        if ($this->db->delete("kol_notes")) {
            if($filename!='')
                unlink($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/kol_note_documents/".$filename);
            return true;
        } else {
            return false;
        }
    }
    function deleteNoteAttachment($noteId){
        $get = $this->db->get_where("kol_notes",array("id"=>$noteId))->row();
        $filename = $get->document;
        if($filename!=''){
            unlink($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/kol_note_documents/".$filename); 
            $this->db->update("kol_notes",array("document"=>'',"document_name"=>'',"orginal_doc_name"=>''),array("id"=>$noteId));
            return true;
        } else {
            return false;
        }
    }
    function updateNote($arrData) {
    	//pr($arrData);exit;
        $this->db->where('id', $arrData['id']);
        //pr($this->db->last_query())exit;
        if ($this->db->update("kol_notes", $arrData)) {
            return true;
        } else {
            return false;
        }
    }

    function getNotesById($noteId) {
        $this->db->select("kol_notes.id,kol_notes.kol_id,kol_notes.note,kol_notes.created_by,kol_notes.client_id,kol_notes.created_on,kol_notes.document,kol_notes.document_name,kol_notes.modified_by,kol_notes.modified_by,kol_notes.modified_on,CONCAT(client_users.first_name,' ',client_users.last_name) as name", false);
        $this->db->where('kol_notes.id', $noteId);
        $this->db->join("client_users", "client_users.id = kol_notes.created_by", "left");
        $result = $this->db->get("kol_notes");
        $arr = array();
        foreach ($result->result_array() as $row) {
            $arr[] = $row;
        }
        return $arr;
    }
   /* function deleteKolNotesByKolId($kolId){
        $this->db->where('kol_id', $kolId);
        if ($this->db->delete("kol_notes")) {
            return true;
        } else {
            return false;
        }
    }    
    function deleteASMTRatingByKolId($kolId){
        $this->db->where('kol_id', $kolId);
        if ($this->db->delete("asmt_kols_rating")) {
            return true;
        } else {
            return false;
        }
    }
    function deleteKolActivityCountByKolId($kolId){
        $this->db->where('kol_id', $kolId);
        if ($this->db->delete("kol_activities_count")) {
            return true;
        } else {
            return false;
        }
    }
    function deleteKolLocationsByKolId($kolId){
        $this->db->where('kol_id', $kolId);
        if ($this->db->delete("kol_locations")) {
            return true;
        } else {
            return false;
        }
    }
    function deleteListKolsByKolId($kolId){
        $this->db->where('kol_id', $kolId);
        if ($this->db->delete("list_kols")) {
            return true;
        } else {
            return false;
        }
    }
    function deletePlanProfilesByKolId($kolId){
        $this->db->where('kol_id', $kolId);
        if ($this->db->delete("plan_profiles")) {
            return true;
        } else {
            return false;
        }
    }
    function deleteUserKolsByKolId($kolId){
        $this->db->where('kol_id', $kolId);
        if ($this->db->delete("user_kols")) {
            return true;
        } else {
            return false;
        }
    }*/
	function delete_kol_data($tableName,$columnName,$columnValue){
        if($tableName=='json_store'){
            $columnValue = 'kol_id:'.$columnValue;
        }            
        if(!empty($tableName) && !empty($columnName) && !empty($columnValue)){
            if (is_array($columnValue)) {
                $this->db->where_in($columnName, $columnValue);
            } else {
                $this->db->where($columnName, $columnValue);
            }
            $this->db->delete($tableName);
//             echo $this->db->last_query();
            return true;
        }
        return false;
    }
    function delete_kol_data_all($tableName, $condition){
    	foreach((array)$condition as $key => $value){
    			if (is_array($value)) {
    				$this->db->where_in($key, $value);
    			} else {
    				$this->db->where($key, $value);
    			}
    	}
    	$this->db->delete($tableName);    	
    }
    function getKolGlobalRegion($kolId) {
        $globalRegion = '';
        $this->db->select('countries.GlobalRegion');
        $this->db->where('id', $kolId);
        $this->db->join('countries', 'kols.country_id = countries.CountryID', 'left');
        $res = $this->db->get('kols');
        if ($res->num_rows() > 0) {
            $res = $res->first_row();
            $globalRegion = $res->GlobalRegion;
        }

        return $globalRegion;
    }   

    function listLocationDetails($kolId) {
          $this->db->select('kol_locations.id, concat(COALESCE(kol_locations.address1,""), ", ", COALESCE(kol_locations.address2,""), ", ", COALESCE(kol_locations.address3,"")) as address, organizations.name as org_name,organization_types.type as org_type, cities.City as city,regions.Region as state,kol_locations.postal_code,kol_locations.is_primary,kol_locations.address_type,kol_locations.private_practice,kol_locations.created_by,kol_locations.data_type_indicator,client_users.client_id,CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name', false);
     
//        $this->db->select('kol_locations.id, concat(kol_locations.address1, ", ", kol_locations.address2, ", ",  kol_locations.address3) as address, organizations.name as org_name, cities.City as city,regions.Region as state,kol_locations.postal_code,kol_locations.is_primary,kol_locations.address_type,kol_locations.private_practice', false);
        $this->db->where('kol_id', $kolId);
        //$this->db->join('countries','kol_locations.country_id = countries.CountryID','left');
        $this->db->join('client_users', 'kol_locations.created_by = client_users.id','left');
        $this->db->join('regions', 'kol_locations.state_id = regions.RegionID', 'left');
        $this->db->join('organizations', 'kol_locations.org_institution_id = organizations.id', 'left');
        $this->db->join('organization_types', 'organizations.type_id = organization_types.id', 'left');
        $this->db->join('cities', 'kol_locations.city_id = cities.CityId', 'left');
        $this->db->order_by('is_primary', "DESC");
        $res = $this->db->get('kol_locations');
        return $res->result_array();
    }

    function getKolPrimaryLocation($kolId) {
        $this->db->select('kol_locations.*');
        $this->db->where('kol_id', $kolId);
        $this->db->where('is_primary', 1);
        $res = $this->db->get('kol_locations');
        return $res->result_array();
    }

    function updateKolPrimaryLocation($arrLocationData, $kolId) {
    	$this->db->where('kol_id', $kolId);
    	$this->db->update('kol_locations', array('is_primary' => "0"));
    	
    	if ($arrLocationData["is_primary"] == "1" && $arrLocationData["title"] > 0) {
    	    $title_id = array('title' => $arrLocationData["title"],'division' => $arrLocationData["division"]);
    	    $this->db->where('id', $kolId);
    	    $this->db->update('kols', $title_id);
    	}
        $this->db->where('kol_id', $kolId);
        $this->db->where('org_institution_id', $arrLocationData['org_institution_id']);
//         $this->db->where('is_primary', 1);
        if ($this->db->update('kol_locations', $arrLocationData)) {
            return true;
        } else {
            return false;
        }
    }

    function getKolLocationByOrgInstId($arrLocation){
    	$data = '';
    	$this->db->where('org_institution_id', $arrLocation['org_institution_id']);
    	$this->db->where('kol_id', $arrLocation['kol_id']);
    	$query = $this->db->get('kol_locations');
    	if ($query->num_rows() > 0) {
    		$rowInfo = $query->row();
    		$data = $rowInfo->id;
    		return $data;
    	} else {
    		return false;
    	}
    }

    function getKoPhoneByLocationId($arrPhone){
    	$data = '';
    	$this->db->where('location_id', $arrPhone['location_id']);
    	$this->db->where('contact', $arrPhone['contact']);
    	$query = $this->db->get('phone_numbers');
    	if ($query->num_rows() > 0) {
    		$rowInfo = $query->row();
    		$data = $rowInfo->id;
    		return $data;
    	} else {
    		return false;
    	}
    }

    function saveLocation($arrLocation) {
        if (isset($arrLocation['id'])) {
            $id = $arrLocation['id'];
            unset($arrLocation['id']);

            if ($arrLocation["is_primary"] == "1") {
                $primary_flag = array('is_primary' => 0);
                $this->db->where('kol_id', $arrLocation['kol_id']);
                $this->db->update('kol_locations', $primary_flag);
            }
            if ($arrLocation["is_primary"] == "1" && $arrLocation["title"] > 0 && $arrLocation["division"] > 0) {
                $title_id = array('title' => $arrLocation["title"],'division' => $arrLocation["division"]);
            	$this->db->where('id', $arrLocation['kol_id']);
            	$this->db->update('kols', $title_id);
            }

            $this->db->where('id', $id);
            if ($this->db->update('kol_locations', $arrLocation)) {
                return true;
            } else {
                return false;
            }
        } else {

            if ($arrLocation["is_primary"] == "1") {
                $primary_flag = array('is_primary' => 0);
                $this->db->where('kol_id', $arrLocation['kol_id']);
                $this->db->update('kol_locations', $primary_flag);
            }
            if ($arrLocation["is_primary"] == "1" && $arrLocation["title"] > 0 && $arrLocation["division"] > 0) {
                $title_id = array('title' => $arrLocation["title"],'division' => $arrLocation["division"]);
            	$this->db->where('id', $arrLocation['kol_id']);
            	$this->db->update('kols', $title_id);
            }
            if ($this->db->insert('kol_locations', $arrLocation)) {
                return $this->db->insert_id();
            } else {
                return false;
            }
        }
    }
    // to save loctions while importing kols
    function saveKolLocation($arrLocation) {
    	$checkLoc = $this->check_kolLocation($arrLocation['org_institution_id'],$arrLocation['kol_id']);
    	if ($checkLoc) {   
    		if ($arrLocation["is_primary"] == "1") {
    			$primary_flag = array('is_primary' => 0);
    			$this->db->where('kol_id', $arrLocation['kol_id']);
    			$this->db->update('kol_locations', $primary_flag);
    			
    			if ($arrLocation["title"] > 0) {
    			    $title_id = array('title' => $arrLocation["title"]);
    			    $this->db->where('id', $arrLocation['kol_id']);
    			    $this->db->update('kols', $title_id);
    			}
    			
    			if ($arrLocation["division"] > 0) {
    			    $division_id = array('division' => $arrLocation["division"]);
    			    $this->db->where('id', $arrLocation['kol_id']);
    			    $this->db->update('kols', $division_id);
    			}
    		}    
    		$this->db->where('id', $checkLoc);
    		if ($this->db->update('kol_locations', $arrLocation)) {
    			return $checkLoc;
    		} else {
    			return false;
    		}
    	} else {
    
    		if ($arrLocation["is_primary"] == "1") {
    			$primary_flag = array('is_primary' => 0);
    			$this->db->where('kol_id', $arrLocation['kol_id']);
    			$this->db->update('kol_locations', $primary_flag);
    			
    			if ($arrLocation["title"] > 0) {
    			    $title_id = array('title' => $arrLocation["title"]);
    			    $this->db->where('id', $arrLocation['kol_id']);
    			    $this->db->update('kols', $title_id);
    			}
    			
    			if ($arrLocation["division"] > 0) {
    			    $division_id = array('division' => $arrLocation["division"]);
    			    $this->db->where('id', $arrLocation['kol_id']);
    			    $this->db->update('kols', $division_id);
    			}
    		}
    
    		if ($this->db->insert('kol_locations', $arrLocation)) {
    			return $this->db->insert_id();
    		} else {
    			return false;
    		}
    	}
    }
    // to check weather kol_location already exists
    function check_kolLocation($org_id,$kol_id){
    	$get = $this->db->get_where("kol_locations",array("org_institution_id"=>$org_id,"kol_id"=>$kol_id));
    	if($get->num_rows()>0){
    		return $get->row()->id;
    	}
    	return false;    	
    }
    
    // to save emails while importing kols
    function saveKolEmails($arrEmails) {
    	$checkEmails = $this->check_kolEmails($arrEmails['email'],$arrEmails['contact']);
    	if ($checkEmails) {
    		if ($arrEmails["is_primary"] == "1") {
    			$primary_flag = array('is_primary' => 0);
    			$this->db->where('contact', $arrEmails['contact']);
    			$this->db->update('emails', $primary_flag);
    			if(!empty($arrEmails['email'])){
    				$this->db->where('id', $arrEmails['contact']);
    				$this->db->update('kols', array('primary_email' => $arrEmails['email']));
    			}
    		}
    		$this->db->where('id', $checkEmails);
    		if ($this->db->update('emails', $arrEmails)) {
    			return $checkEmails;
    		} else {
    			return false;
    		}
    	} else {
    		
    		if ($arrEmails["is_primary"] == "1") {
    			$primary_flag = array('is_primary' => 0);
    			$this->db->where('contact', $arrEmails['contact']);
    			$this->db->update('emails', $primary_flag);
    			if(!empty($arrEmails['email'])){
    				$this->db->where('id', $arrEmails['contact']);
    				$this->db->update('kols', array('primary_email' => $arrEmails['email']));
    			}
    		}    
    		if ($this->db->insert('emails', $arrEmails)) {
    			return $this->db->insert_id();
    		} else {
    			return false;
    		}
    	}
    }
    // to check weather emails already exists
    function check_kolEmails($email,$kol_id){
    	$get = $this->db->get_where("emails",array("email"=>$email,"contact"=>$kol_id));
    	if($get->num_rows()>0){
    		return $get->row()->id;
    	}
    	return false;
    }
  
 // to save phone_number while importing kols
    function saveKolPhones($arrPhone) {    	
    	$checkPhone = $this->check_kolPhones($arrPhone['number'],$arrPhone['contact'],$arrPhone['location_id']);
    	if ($checkPhone) {    		
    		if ($arrPhone["is_primary"] == "1") {
    			$primary_flag = array('is_primary' => 0);
    			$this->db->where('contact', $arrPhone['contact']);
    			$this->db->update('phone_numbers', $primary_flag);
    			
    			$phNo = $arrPhone['number'];
    			$phoneNumber = array('primary_phone' => $phNo);
    			$this->db->where('id',$arrPhone['contact']);
    			$this->db->update('kols', $phoneNumber);
    		}
    		$this->db->where('id', $checkPhone);
    		if ($this->db->update('phone_numbers', $arrPhone)) {
    			return $checkPhone;
    		} else {
    			return false;
    		}
    	} else {
    		
    		if ($arrPhone["is_primary"] == "1") {
    			$primary_flag = array('is_primary' => 0);
    			$this->db->where('contact', $arrPhone['contact']);
    			$this->db->update('phone_numbers', $primary_flag);
    			
    			$phNo = $arrPhone['number'];
    			$phoneNumber = array('primary_phone' => $phNo);
    			$this->db->where('id',$arrPhone['contact']);
    			$this->db->update('kols', $phoneNumber);
    		}    		
    		if ($this->db->insert('phone_numbers', $arrPhone)) {    			
    			return $this->db->insert_id();
    		} else {
    			return false;
    		}
    	}
    }
    // to check weather phone_number already exists
    function check_kolPhones($number,$kol_id,$loc_id){
    	$get = $this->db->get_where("phone_numbers",array("number"=>$number,"contact"=>$kol_id,"location_id"=>$loc_id));
    	if($get->num_rows()>0){
    		return $get->row()->id;
    	}
    	return false;
    }
    // to save sate licence while importing kols
    function saveKolLicense($arrLicence) {
    	$checkLicence = $this->check_kolLicense($arrLicence['state_license'],$arrLicence['contact'],$arrLicence['region']);
    	if ($checkLicence) {
    		if ($arrLicence["is_primary"] == "1") {
    			$primary_flag = array('is_primary' => 0);
    			$this->db->where('contact', $arrLicence['contact']);
    			$this->db->update('state_licenses', $primary_flag);
    		}
    		$this->db->where('id', $checkLicence);
    		if ($this->db->update('state_licenses', $arrLicence)) {
    			return $checkLicence;
    		} else {
    			return false;
    		}
    	} else {
    
    		if ($arrLicence["is_primary"] == "1") {
    			$primary_flag = array('is_primary' => 0);
    			$this->db->where('contact', $arrLicence['contact']);
    			$this->db->update('state_licenses', $primary_flag);
    		}
    		if ($this->db->insert('state_licenses', $arrLicence)) {
    			return $this->db->insert_id();
    		} else {
    			return false;
    		}
    	}
    }
    // to check weather sate licence already exists
    function check_kolLicense($licence,$kol_id,$region){
    	$get = $this->db->get_where("state_licenses",array("state_license"=>$licence,"contact"=>$kol_id,"region"=>$region));
    	if($get->num_rows()>0){
    		return $get->row()->id;
    	}
    	return false;
    }
    
    
    // if suffix not exists add suffix
    function saveSuffix($spec) {   
    	$get = $this->db->get_where("professional_suffix",array("suffix"=>$spec));
    	if($get->num_rows()==0){
    		$this->db->insert("professional_suffix",array("suffix"=>$spec,"is_active"=>1));
    		return $this->db->insert_id();
    	}
    	return $get->row()->id;
    }
    // if title not exists add title
    function saveTitle($tit) {
    	$get = $this->db->get_where("titles",array("title"=>$tit));
    	if($get->num_rows()==0){
    		$this->db->insert("titles",array("title"=>$tit,"is_active"=>1,"abbr"=>' ',"client_id"=>INTERNAL_CLIENT_ID));
    		return $this->db->insert_id();
    	}
    	return $get->row()->id;
    }
    function getLocationById($id) {
        $this->db->select('kol_locations.*,organizations.name as org_name');
        $this->db->join('organizations','organizations.id = kol_locations.org_institution_id');
        $this->db->where('kol_locations.id', $id);
        $res = $this->db->get('kol_locations');
        return $res->result_array();
    }
    function getLocationDetailsByKolId($kolId){
        $this->db->select('kol_locations.*,organizations.name as org_name');
        $this->db->join('organizations','organizations.id = kol_locations.org_institution_id');
        $this->db->where('kol_locations.kol_id', $kolId);
        $res = $this->db->get('kol_locations');
        return $res->result_array();
    }
    function deleteLocation($id) {
        $this->db->where('id', $id);
        $this->db->delete('kol_locations');
    }

    function deleteStaff($id, $typeId, $locId) {
        if ($id != "")
            $this->db->where('id', $id);
        if ($typeId != null){
            $this->db->where('contact', $typeId);
            $this->db->where('location_id', $locId);
        }
        $this->db->delete('staffs');
    }

    function saveStaff($arrStaffData) {
        if ($this->db->insert('staffs', $arrStaffData)) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    function updateStaff($id, $arrStaffData) {
        $this->db->where('id', $id);
        if ($this->db->update('staffs', $arrStaffData)) {
            return true;
        } else {
            return false;
        }
    }

    function saveAssignClient($arrAssignData) {
    	if ($this->db->insert('user_kols', $arrAssignData)) {
    		return $this->db->insert_id();
    	} else {
    		return false;
    	}
    }
    
    function updateAssignClient($id, $arrAssignData) {
    	$this->db->where('id', $id);
    	if ($this->db->update('user_kols', $arrAssignData)) {
    		return true;
    	} else {
    		return false;
    	}
    }
    
    function updateEmail($id, $arrEmailData) {
        $contact_type = $arrEmailData['contact_type'];
        unset($arrEmailData['contact_type']);
        if ($arrEmailData['is_primary'] == "1") {
            $this->db->where('contact', $arrEmailData['contact']);
//                $this->db->where('contact_type',$arrEmailData['contact_type']);
            $this->db->update('emails', array('is_primary' => "0"));
           if($contact_type == "kol") {               
                 $this->db->where('id', $arrEmailData['contact']);
                $this->db->update('kols', array('primary_email' => $arrEmailData['email']));
           }
        }
        $this->db->where('id', $id);
        if($this->db->update('emails', $arrEmailData)){
            return true;
        }
        return false;
    }

//    function updateKolInfo($arrKolData, $kolId) {
//        $this->db->where('id', $kolId);
//        if ($this->db->update('kols', $arrKolData)) {
//            return true;
//        } else {
//            return false;
//        }
//    }
//
//    function getKolInfo($id) {
//        $this->db->select('kols.*');
//        $this->db->where('id', $id);
//        $res = $this->db->get('kols');
//        return $res->result_array();
//    }

    function saveContactRestrictions($arrContactData) {
        if ($this->db->insert('contact_restrictions', $arrContactData)) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

//    function updateContactRestrictions($arrContactData, $id) {
//        $this->db->where('contact', $id);
//        if ($this->db->update('contact_restrictions', $arrContactData)) {
//            return true;
//        } else {
//            return false;
//        }
//    }
//
//    function getContactRestrictions($kolId) {
//        $this->db->select('contact_restrictions.*');
//        $this->db->where('contact', $kolId);
//        $res = $this->db->get('contact_restrictions');
//        return $res->result_array();
//    }

//    function getAllActiveDegrees() {
//        $this->db->select('degrees.*');
//        $this->db->where('is_active', 1);
//        $this->db->order_by('degree', 'asc');
//        $res = $this->db->get('degrees');
//        return $res->result_array();
//    }

//    function getAllActiveTitles() {
//        $client_id = $this->session->userdata('client_id');
//        $this->db->select('titles.*');
//        $this->db->where('is_active', 1);
//        $this->db->order_by('title', 'asc');
//        if ($client_id != INTERNAL_CLIENT_ID)
//            $this->db->where('client_id', $client_id);
//        $res = $this->db->get('titles');
//        return $res->result_array();
//    }

//    function getAllActiveProducts() {
//        $this->db->select('products.*');
//        $this->db->where('status', 1);
//        $res = $this->db->get('products');
//        return $res->result_array();
//    }

//    function getAllActiveAdditionalRoles() {
//        $arrRoles = array();
//        $this->db->select('additional_roles.*');
//        $this->db->where('is_active', 1);
//        $this->db->order_by('role_name', 'asc');
//        $res = $this->db->get('additional_roles');
//        foreach ($res->result_array() as $row)
//            $arrRoles[$row['id']] = $row;
//        return $arrRoles;
//    }
//
//    function getAllActiveProfessionalSuffixes() {
//        $this->db->select('professional_suffix.*');
//        $this->db->where('is_active', 1);
//        $this->db->order_by('suffix', 'asc');
//        $res = $this->db->get('professional_suffix');
//        return $res->result_array();
//    }
//
//    function getSuffixById($suffixId) {
//        $this->db->select('professional_suffix.suffix');
//        $this->db->where('id', $suffixId);
//        $res = $this->db->get('professional_suffix');
//        $res = $res->result_array();
//        $suffix = $res[0]['suffix'];
//        return $suffix;
//    }
//
//    function getBestTimes($kolId) {
//
//        $this->db->select('id, kol_id, day, TIME_FORMAT(time,"%h:%i %p") as time', false);
//        $this->db->where('kol_id', $kolId);
//        $result = $this->db->get('best_time');
////            pr($this->db->last_query());
////            exit();
//        $arr = array();
//        foreach ($result->result_array() as $row) {
//            $arr[$row['day']][] = $row;
//        }
//        $this->db->where('id', $id);
//        if ($this->db->update('emails', $arrEmailData)) {
//            return true;
//        } else {
//            return false;
//        }
//    }

    function updateStateLicense($id, $arrLicenseData) {
        if ($arrLicenseData['is_primary'] == "1") {
            $this->db->where('contact', $arrLicenseData['contact']);
            $this->db->update('state_licenses', array('is_primary' => "0"));
            $this->db->where('id', $arrLicenseData['contact']);
            $this->db->update('kols', array('license' => $arrLicenseData['state_license']));
        }
        $this->db->where('id', $id);
        if ($this->db->update('state_licenses', $arrLicenseData)) {
            return true;
        } else {
            return false;
        }
    }

    function updateOLKeyStatus($id, $arrStatusData) {
        $this->db->where('id', $id);
        if ($this->db->update('ol_key_statuses', $arrStatusData)) {
            return true;
        } else {
            return false;
        }
    }

    function updatePhone($id, $arrPhoneData) {
        if ($arrPhoneData['is_primary'] == "1") {
            $this->db->where('contact', $arrPhoneData['contact']);
//             $this->db->where('contact_type', $arrPhoneData['contact_type']);
            $this->db->update('phone_numbers', array('is_primary' => "0"));

            if ($arrPhoneData['contact_type'] == "kol") {
                $this->db->where('id', $arrPhoneData['contact']);
                $this->db->update('kols', array('primary_phone' => $arrPhoneData['number']));
            }
            if ($arrPhoneData['contact_type'] == "organization") {
                $this->db->where('id', $arrPhoneData['contact']);
                $this->db->update('organizations', array('phone' => $arrPhoneData['number']));
            }
        }
        $this->db->where('id', $id);
        if ($this->db->update('phone_numbers', $arrPhoneData)) {
            return true;
        } else {
            return false;
        }
    }

    function savePhone($arrPhoneData) {
        if ($arrPhoneData['is_primary'] == "1") {
            $this->db->where('contact', $arrPhoneData['contact']);
//                $this->db->where('contact_type',$arrPhoneData['contact_type']);
            $this->db->update('phone_numbers', array('is_primary' => "0"));

            if ($arrPhoneData['contact_type'] == "kol") {
                $this->db->where('id', $arrPhoneData['contact']);
                $this->db->update('kols', array('primary_phone' => $arrPhoneData['number']));
            }
            if ($arrPhoneData['contact_type'] == "organization") {
                $this->db->where('id', $arrPhoneData['contact']);
                $this->db->update('organizations', array('phone' => $arrPhoneData['number']));
            }
        }
        if ($this->db->insert('phone_numbers', $arrPhoneData)) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    function deletePhone($id, $typeId, $locId) {
        if ($id != "")
            $this->db->where('id', $id);
        if ($typeId != ""){
            $this->db->where('contact', $typeId);
            $this->db->where('location_id', $locId);
        }
        $this->db->delete('phone_numbers');
    }

    function getStaffs($id, $type) {
        $this->db->select('organizations.name as loc_name,staffs.*,kol_locations.address1,staff_title.name as staff_title,phone_type.name as phone_type,staffs.data_type_indicator,client_users.client_id,CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name',false);
//            $this->db->where('contact',$id);
//            $this->db->where('contact_type',$type);
        if ($type == 'location') {
            $this->db->where('location_id', $id);
        }
        if ($type == 'kol') {
            $this->db->where('staffs.contact', $id);
            $this->db->where('contact_type !=', 'organization');
        }
//			$this->db->where('location_id',$id);
        $this->db->join('client_users', 'staffs.created_by = client_users.id','left');
        $this->db->join("staff_title", "staff_title.id = staffs.title", "left");
        $this->db->join("phone_type", "phone_type.id = staffs.phone_type", "left");
        $this->db->join('kol_locations', 'kol_locations.id = staffs.location_id', 'left');
        $this->db->join('organizations', 'organizations.id = kol_locations.org_institution_id', 'left');
        $res = $this->db->get('staffs');
        $arrData = array();
        foreach ($res->result_array() as $row) {
            if ($row['loc_name'] == '')
                $row['loc_name'] = $row['address1'];

            $arrData[] = $row;
        }
        return $arrData;
    }

    function getPhones($id, $type) {
        $this->db->select('organizations.name,phone_numbers.*,kol_locations.address1,phone_type.name as phone_type,phone_numbers.data_type_indicator,client_users.client_id,CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name',false);
//            $this->db->where('contact',$id);
//            $this->db->where('contact_type',$type);
        if ($type == 'location') {
            $this->db->where('location_id', $id);
        }
        if ($type == 'kol') {
            $this->db->where('phone_numbers.contact', $id);
            $this->db->where('contact_type !=', 'organization');
        }
        $this->db->join('client_users', 'phone_numbers.created_by = client_users.id','left');
        $this->db->join("phone_type", "phone_type.id = phone_numbers.type", "left");
        $this->db->join('kol_locations', 'kol_locations.id = phone_numbers.location_id', 'left');
        $this->db->join('organizations', 'organizations.id = kol_locations.org_institution_id', 'left');
        $res = $this->db->get('phone_numbers');
        $arrData = array();
        foreach ($res->result_array() as $row) {
            if ($row['name'] == '')
                $row['name'] = $row['address1'];

            $arrData[] = $row;
        }
        //print $this->db->last_query();
        //exit();
        return $arrData;
    }

    function getEmails($id) {
        $this->db->select('emails.*,client_users.client_id,CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name',false);
        $this->db->join('client_users', 'emails.created_by = client_users.id','left');
        $this->db->where('emails.contact', $id);
        $res = $this->db->get('emails');
        return $res->result_array();
    }

    function getStateLicences($id) {
        $this->db->select('state_licenses.*,regions.Region as state_name,client_users.client_id,CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name',false);
        $this->db->join('client_users', 'state_licenses.created_by = client_users.id','left');
        $this->db->join('regions', 'regions.RegionID = state_licenses.region', 'left');
        $this->db->where('state_licenses.contact', $id);
        $res = $this->db->get('state_licenses');
        return $res->result_array();
    }
    function getAssignedUsers($kolId){
    	$clientId = $this->session->userdata('client_id');
    	$this->db->select("user_kols.id,user_kols.user_id,user_kols.data_type_indicator,client_users.client_id,CONCAT(client_users.first_name,' ',client_users.last_name) AS name,client_users.email,kol_user_conatct_type.name as type,kols.created_by",false);
    	$this->db->join('client_users','client_users.id=user_kols.user_id');
    	$this->db->join('kols','kols.id = user_kols.kol_id','left');
    	$this->db->join('kol_user_conatct_type','kol_user_conatct_type.id=user_kols.type','left');
    	$this->db->where('user_kols.kol_id',$kolId);
//     	if($clientId!=INTERNAL_CLIENT_ID){
//     		$this->db->where("client_users.client_id",$clientId);
//     	}
    	$arrResult = $this->db->get('user_kols');
    	return $arrResult->result_array();
    }
    function getAllKeyStatus($id) {
        $this->db->select('ol_key_statuses.*');
        $this->db->where('contact', $id);
        $res = $this->db->get('ol_key_statuses');
        return $res->result_array();
    }

    function saveEmail($arrEmailData) {
        $contact_type = $arrEmailData['contact_type'];
        unset($arrEmailData['contact_type']);
        if ($arrEmailData['is_primary'] == "1") {
            $this->db->where('contact', $arrEmailData['contact']);
//                $this->db->where('contact_type',$arrEmailData['contact_type']);
            $this->db->update('emails', array('is_primary' => "0"));
               if($contact_type == "kol") {
                    $this->db->where('id', $arrEmailData['contact']);
                    $this->db->update('kols', array('primary_email' => $arrEmailData['email']));
               }
        }
        if ($this->db->insert('emails', $arrEmailData)) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    function deleteEmail($id) {
        $this->db->where('id', $id);
        $this->db->delete('emails');
    }

    function saveStateLicense($arrLicenseData) {
        if ($arrLicenseData['is_primary'] == "1") {
            $this->db->where('contact', $arrLicenseData['contact']);
            $this->db->update('state_licenses', array('is_primary' => "0"));
            $this->db->where('id', $arrLicenseData['contact']);
            $this->db->update('kols', array('license' => $arrLicenseData['state_license']));
        }
        if ($this->db->insert('state_licenses', $arrLicenseData)) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    function deleteStateLicense($id) {
        $this->db->where('id', $id);
        $this->db->delete('state_licenses');
    }

    function deleteAssignUser($id) {
    	$this->db->where('id', $id);
    	$this->db->delete('user_kols');
    }

    function saveOLKeyStatus($arrOLKeyStatus) {
        if ($this->db->insert('ol_key_statuses', $arrOLKeyStatus)) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    function deleteOLKeyStatus($id) {
        $this->db->where('id', $id);
        $this->db->delete('ol_key_statuses');
    }

    function saveKolInfo($arrKolData) {
        if ($this->db->insert('kols', $arrKolData)) {
           
            $id = $this->db->insert_id();
            $this->db->where("id", $id);
            $this->db->set("pin", $id);
            $this->db->set("unique_id", md5($id));
            if ($this->db->update("kols")) {
                return $id;
            }
        } else {
            return false;
        }
        
    }

    function updateKolInfo($arrKolData, $kolId) {
        $this->db->where('id', $kolId);
        if ($this->db->update('kols', $arrKolData)) {
            return true;
        } else {
            return false;
        }
    }

    function getKolInfo($id) {
        $this->db->select('kols.*');
        $this->db->where('id', $id);
        $res = $this->db->get('kols');
        return $res->result_array();
    }

//    function saveContactRestrictions($arrContactData) {
//        if ($this->db->insert('contact_restrictions', $arrContactData)) {
//            return $this->db->insert_id();
//        } else {
//            return false;
//        }
//    }

    function updateContactRestrictions($arrContactData, $id) {
        $this->db->where('contact', $id);
        if ($this->db->update('contact_restrictions', $arrContactData)) {
            return true;
        } else {
            return false;
        }
    }

    function getContactRestrictions($kolId) {
        $this->db->select('contact_restrictions.*');
        $this->db->where('contact', $kolId);
        $res = $this->db->get('contact_restrictions');
        return $res->result_array();
    }

    function getAllActiveDegrees() {
        $this->db->select('degrees.*');
        $this->db->where('is_active', 1);
        $this->db->order_by('degree', 'asc');
        $res = $this->db->get('degrees');
        return $res->result_array();
    }

    function getAllActiveTitles($listAll='') {
        $client_id = $this->session->userdata('client_id');
        $this->db->select('titles.*');
        $this->db->where('is_active', 1);
        $this->db->group_by('title');
        $this->db->order_by('title', 'asc');
        $this->db->order_by('id', 'asc');
        //if ($client_id != INTERNAL_CLIENT_ID && $this->session->userdata('user_role_id') != ROLE_ADMIN)
        if ($client_id != INTERNAL_CLIENT_ID  && $listAll!='all' && $this->session->userdata('user_role_id') != ROLE_ADMIN)
            $this->db->where('client_id', $client_id);
        $res = $this->db->get('titles');
        return $res->result_array();
    }

    function getAllActiveProducts() {
        $this->db->select('products.*');
        $this->db->where('status', 1);
        $res = $this->db->get('products');
        return $res->result_array();
    }

    function getAllActiveAdditionalRoles() {
        $client_id = $this->session->userdata('client_id');
        $arrRoles = array();
        $this->db->select('additional_roles.*');
        $this->db->where('is_active', 1);
        $this->db->order_by('role_name', 'asc');
       /* if ($client_id != INTERNAL_CLIENT_ID)
            $this->db->where('client_id', $client_id);*/
        $res = $this->db->get('additional_roles');
        foreach ($res->result_array() as $row)
            $arrRoles[$row['id']] = $row;
        return $arrRoles;
    }

    function getAllActiveProfessionalSuffixes() {
        $this->db->select('professional_suffix.*');
        $this->db->where('is_active', 1);
        $this->db->order_by('suffix', 'asc');
        $this->db->group_by('suffix');
        $res = $this->db->get('professional_suffix');
        return $res->result_array();
    }

    function getSuffixById($suffixId) {
        $this->db->select('professional_suffix.suffix');
        $this->db->where('id', $suffixId);
        $res = $this->db->get('professional_suffix');
        $res = $res->result_array();
        $suffix = $res[0]['suffix'];
        return $suffix;
    }

    function getBestTimes($kolId) {

        $this->db->select('id, kol_id, day, TIME_FORMAT(time,"%h:%i %p") as time', false);
        $this->db->where('kol_id', $kolId);
        $result = $this->db->get('best_time');
//            pr($this->db->last_query());
//            exit();
        $arr = array();
        foreach ($result->result_array() as $row) {
            $arr[$row['day']][] = $row;
        }
        return $arr;
    }

    function saveBestTime($arrData) {
        if ($this->db->insert('best_time', $arrData)) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }
    
    function deleteBestTime($id) {
        $this->db->where('id', $id);
        $this->db->delete('best_time');
    }

    function deleteKolProducts($kolId) {
        $this->db->where('kol_id', $kolId);
        $this->db->delete('kol_products');
    }

    function deleteKolSpeakerProducts($kolId) {
        $this->db->where('kol_id', $kolId);
        $this->db->delete('ol_speaker_product');
    }

    function deleteKolSubSpecialty($kolId) {
    	$this->db->where('kol_id', $kolId);
    	$this->db->delete('kol_sub_specialty');
    }
    
    function insertKolProducts($kolId, $arrProducts) {
        foreach ($arrProducts as $value) {
            $this->db->insert('kol_products', array("kol_id" => $kolId,
                "product_id" => $value));
        }
    }

    function insertKolSpakerProducts($kolId, $arrProducts) {
        foreach ($arrProducts as $value) {
            $this->db->insert('ol_speaker_product', array("kol_id" => $kolId,
                "product_id" => $value));
        }
//            echo $this->db->last_query();
    }
    function insertKolSubSpecialty($kolId, $arrProducts) {
    	foreach ($arrProducts as $value) {
    		$this->db->insert('kol_sub_specialty', array("kol_id" => $kolId,
    				"kol_sub_specialty_id" => $value));
    	}
    }
    function getKolProducts($kolId) {
        $this->db->select('products.id,products.name');
        $this->db->join('kol_products', 'kol_products.product_id = products.id');
        $this->db->where('kol_products.kol_id', $kolId);
        $res = $this->db->get('products');
        $arrRes = $res->result_array();
       return $arrRes;
    }

    function getKolSeakerProducts($kolId) {
        $this->db->select('product_id');
        $this->db->where('kol_id', $kolId);
        $res = $this->db->get('ol_speaker_product');
        $arrRes = $res->result_array();


        return $arrRes;
    }

    function getAllLocationsByKolId($kolId) {
        $this->db->select('organizations.name,kol_locations.*', false);
        $this->db->join('organizations', 'kol_locations.org_institution_id = organizations.id', 'left');
        $this->db->where('kol_locations.kol_id', $kolId);
        $this->db->order_by('is_primary', "DESC");
        $result = $this->db->get('kol_locations');
        $arr = array();
        foreach ($result->result_array() as $row) {
            if ($row['name'] != '')
                $arr[$row['id']] = $row['name'];
            else
                $arr[$row['id']] = $row['address1'];
        }
        //print $this->db->last_query();
        //exit();
        return $arr;
    }

    function updateOlEmail($arrEmailData) {
        $this->db->where("is_primary", 1);
        $this->db->where("contact", $arrEmailData['contact']);
        $arrEmails = $this->db->get("emails");
        foreach ($arrEmails->result_array() as $row) {
            $id = $row['id'];
        }
        if (isset($id)) {
            $this->db->where("id", $id);
            $this->db->update("emails", $arrEmailData);
        } else {
            $this->db->insert("emails", $arrEmailData);
        }
        return true;
    }

    function updateOlPhone($arrPhoneData) {
    	$id = '';
    	$this->db->where('contact', $arrPhoneData['contact']);
    	$this->db->update('phone_numbers', array('is_primary' => "0"));
    	
    	$this->db->where("location_id", $arrPhoneData['location_id']);
        $this->db->where("contact", $arrPhoneData['contact']);
        $arrPhone = $this->db->get("phone_numbers");
        foreach ($arrPhone->result_array() as $row) {
            $id = $row['id'];
        }
        if (isset($id)) {
            $this->db->where("id", $id);
            $this->db->update("phone_numbers", $arrPhoneData);
        } else {
            $this->db->insert("phone_numbers", $arrPhoneData);
        }
        return true;
    }

    function deleteLocStaff($id) {
        $this->db->where('location_id', $id);
        $this->db->delete("staffs");
    }

    function deleteLocPhone($id) {
        $this->db->where('location_id', $id);
        $this->db->delete("phone_numbers");
    }

    function getKolPrimaryPhoneDetails($kolId) {
        $this->db->where('contact', $kolId);
        $this->db->where('is_primary', 1);
        $arrRes = $this->db->get('phone_numbers');
        $arr = array();
        foreach ($arrRes->result_array() as $row) {
            $arr = $row;
        }
        return $arr;
    }

    function checkDuplicateOL($rowData) {
        $arrResults = array();
        $this->db->select('kols.id,salutation,first_name,middle_name,last_name,org_id,kols.status,kols.profile_type,cities.City as city, regions.Region as state,specialties.specialty,kols.postal_code');
        $this->db->join('cities', 'kols.city_id = cities.CityId', 'left');
        $this->db->join('regions', 'kols.state_id = regions.RegionID', 'left');
        $this->db->join('specialties', 'kols.specialty= specialties.id', 'left');
        $this->db->where('kols.first_name', $rowData['first_name']);
//		$this->db->where('kols.middle_name', $rowData['middle_name']);
        $this->db->where('kols.last_name', $rowData['last_name']);
        if ($rowData['kol_id'] != '')
            $this->db->where('kols.id !=', $rowData['kol_id']);
        //if (!isset($rowData['state_id']))
        if (isset($rowData['specialty']))
            $this->db->where('kols.specialty', $rowData['specialty']);
        //else {
            //$this->db->where('kols.postal_code', $rowData['postal_code']);
            if (isset($rowData['city_id']) && $rowData['city_id'] != '')
                $this->db->where('kols.city_id', $rowData['city_id']);
            if (isset($rowData['state_id']) && $rowData['state_id'] != '')
                $this->db->where('kols.state_id', $rowData['state_id']);
        //}
        //$this->db->where('status !=','Not Requested');
        $results = $this->db->get('kols');
        if (is_object($results) && $results->num_rows() > 0)
            $arrResults = $results->result_array();
        return $arrResults;
    }

    function getSpeakerProducts() {
        $product = array('Abilify Maintena', 'Samsca', 'Nuedexta', 'Rexulti');
        $this->db->select('id,name');
        $this->db->where_in('name', $product);
        $res = $this->db->get('products');
        $arrRes = $res->result_array();

//           echo $this->db->last_query();
        return $arrRes;
    }

    function getKolTitleById($arrTitleId) {
        $arrTitles = array();
        $this->db->where_in('id', $arrTitleId);
//                $this->db->group_by('title');
        $arrResultSet = $this->db->get('kols');
        foreach ($arrResultSet->result_array() as $row) {
            $arrTitles[$row['title']] = $row['title'];
        }
        return $arrTitles;
    }

    function getMatchingRegions($region) {
        $this->db->select('distinct GlobalRegion,CountryId', false);
        $this->db->like('GlobalRegion', $region);
        $this->db->group_by('GlobalRegion');
        $arrResultSet = $this->db->get('countries');

        $arrTitleNames = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrTitleNames[$arrRow['CountryId']] = $arrRow['GlobalRegion'];
        }
//		echo $this->db->last_query();
        return $arrTitleNames;
    }

    function getMatchingKolTitles($title) {
        $this->db->select('distinct title', false);
        $this->db->like('title', $title);
       // $this->db->where('status', COMPLETED);
       // $arrResultSet = $this->db->get('kols');
        $arrResultSet = $this->db->get('titles');
        $arrTitleNames = array();
        foreach ($arrResultSet->result_array() as $arrRow) {
            $arrTitleNames[] = $arrRow['title'];
        }
//		echo $this->db->last_query();
        return $arrTitleNames;
    }

    function getRegionById($arrTypeId) {
        $arrTypes = array();
        $this->db->where_in('CountryId', $arrTypeId);
        $arrResultSet = $this->db->get('countries');
        foreach ($arrResultSet->result_array() as $row) {
            $arrTypes[$row['CountryId']] = $row['GlobalRegion'];
        }
        return $arrTypes;
    }
    
       function getKolsLike1CrossPlatForm($arrKolIds) {
        $sizeOfKeywords = sizeof($arrKeywords);
        if ($sizeOfKeywords > 0 && empty($arrKeywords[0])) {
            $sizeOfKeywords = 0;
        }
        $currentController = $this->uri->segment(1);
        $currentControllerIpad = $this->uri->segment(2);

        $arrKols = array();
        $client_id = $this->session->userdata('client_id');
        $user_id = $this->session->userdata('user_id');
        if ($doCount == false && $doGroupBy == false) {
            //$this->db->select('kols.*,organizations.name,specialties.specialty as specs,countries.country');
            $this->db->select('c.is_analyst,c.is_analyst,concat(m.first_name," ",m.last_name) as modified_by, concat(c.first_name," ",c.last_name) as created_by, kols.id,kols.salutation,kols.first_name,kols.middle_name,kols.last_name,kols.gender,kols.profile_image,kols.primary_phone,kols.primary_email,kols.specialty,kols.org_id,organizations.name,specialties.specialty as specs,countries.country,regions.region as state,cities.City AS city,cities.Latitude as lat,cities.Longitude as lang,cities.city,kols.profile_type, kols.created_on, kols.modified_on,kols.created_by as created_by_id,kols.status,kols.biography,kols.dob,kols.address1,kols.address2', false);
            //$this->db->join('kol_activities_count', 'kol_activities_count.kol_id = kols.id', 'left');
            $this->db->join('client_users as c', 'c.id = kols.created_by', 'left');
            $this->db->join('client_users as m', 'm.id = kols.created_by', 'left');
            //$this->db->join('cities', 'cities.cityID = kols.city_id', 'left');
        }

        $this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
        $this->db->join('specialties', 'specialties.id = kols.specialty', 'left');
        $this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
        $this->db->join('regions', 'regions.regionID = kols.state_id', 'left');
        $this->db->join('cities', 'cities.CityId = kols.city_id', 'left');

        if ($arrFilterFields != null && $arrFilterFields['education'] != null && isset($arrFilterFields['education']) && sizeof($arrFilterFields['education']) > 0 && !($doGroupBy == true && $groupByCategory == 'education')) {
            $this->db->distinct();
            $this->db->join('kol_educations', 'kol_educations.kol_id = kols.id', 'left');
            $this->db->join('institutions', 'kol_educations.institute_id = institutions.id', 'left');
            $this->db->where_in('institutions.id', $arrFilterFields['education']);
            $this->db->where('kol_educations.type', 'education');
        }
        if ($arrFilterFields != null && $arrFilterFields['event_id'] != null && isset($arrFilterFields['event_id']) && sizeof($arrFilterFields['event_id']) > 0 && !($doGroupBy == true && $groupByCategory == 'event')) {
            $this->db->distinct();
            $this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');
            $this->db->join('events', 'kol_events.event_id = events.id', 'left');
            $this->db->where_in('kol_events.event_id', $arrFilterFields['event_id']);
        }
        if ($arrFilterFields != null && $arrFilterFields['list_id'] != null && isset($arrFilterFields['list_id']) && sizeof($arrFilterFields['list_id']) > 0 && !($doGroupBy == true && $groupByCategory == 'list')) {
            $this->db->distinct();
            $this->db->join('list_kols', 'list_kols.kol_id=kols.id', 'left');
            $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
            //$this->db->where_in('list_names.list_name',$arrFilterFields['list_id']);
            $this->db->where_in('list_names.id', $arrFilterFields['list_id']);
        }
        if ($arrFilterFields != null && $arrFilterFields['type'] != null && isset($arrFilterFields['type']) && sizeof($arrFilterFields['type']) > 0 && !($doGroupBy == true && $groupByCategory == 'type')) {
            $this->db->distinct();
            $this->db->join('organization_types', 'organization_types.id=organizations.type_id', 'left');
            //$this->db->where_in('list_names.list_name',$arrFilterFields['list_id']);
            $this->db->where_in('organization_types.id', $arrFilterFields['type']);
//                      
        }
        if ($arrFilterFields != null && $arrFilterFields['title'] != null && isset($arrFilterFields['title']) && sizeof($arrFilterFields['title']) > 0 && !($doGroupBy == true && $groupByCategory == 'title')) {
            $this->db->distinct();
            $this->db->where_in('kols.title', $arrFilterFields['title']);
//                      
        }
        if ($arrFilterFields != null && $arrFilterFields['region'] != null && isset($arrFilterFields['region']) && sizeof($arrFilterFields['region']) > 0 && !($doGroupBy == true && $groupByCategory == 'region')) {
            $this->db->distinct();
            $this->db->where_in('countries.GlobalRegion', $arrFilterFields['region']);
//                      
        }




        $keywordSearchByAutoComplete = 0;
        $keywordSearchByAutoComplete = $this->session->userdata('keywordSearchByAutoComplete');
        switch ($sizeOfKeywords) {
            case 1:
                $name = trim($arrKeywords[0]);
                $where = '(kols.first_name LIKE "%' . $name . '%" OR kols.last_name LIKE "%' . $name . '" OR kols.middle_name LIKE "%' . $name . '%")';
                if ($keywordSearchByAutoComplete) {
                    $where = '(kols.first_name = "' . $name . '")';
                }
                $this->db->where($where);
                break;
            case 2:
                $name1 = trim($arrKeywords[0]);
                $name2 = trim($arrKeywords[1]);
                $where = "(kols.first_name IN('" . $name1 . "','" . $name2 . "') OR kols.last_name IN ('" . $name1 . "','" . $name2 . "') OR kols.middle_name IN ('" . $name1 . "','" . $name2 . "'))";
                if ($keywordSearchByAutoComplete) {
                    $where = '((kols.first_name = "' . $name1 . '" AND kols.last_name="' . $name2 . '") or (kols.first_name = "' . $name1 . '" AND kols.middle_name="' . $name2 . '"))';
                }
                $this->db->where($where);
                break;
            case 3:
                $name1 = trim($arrKeywords[0]);
                $name2 = trim($arrKeywords[1]);
                $name3 = trim($arrKeywords[2]);
                $where = "(kols.first_name IN('" . $name1 . "','" . $name2 . "','" . $name3 . "') OR kols.last_name IN ('" . $name1 . "','" . $name2 . "','" . $name3 . "') OR kols.middle_name IN ('" . $name1 . "','" . $name2 . "','" . $name3 . "'))";
                if ($keywordSearchByAutoComplete) {
                    $where = '(kols.first_name = "' . $name1 . '" AND kols.middle_name="' . $name2 . '" AND kols.last_name="' . $name3 . '")';
                }
                $this->db->where($where);
                break;
        }
        /*
          if(sizeof($arrKeywords)==1){
          $name=trim($arrKeywords[0]);
          $where='(kols.first_name LIKE "%'.$name.'%" OR kols.last_name LIKE "%'.$name.'" OR kols.middle_name LIKE "%'.$name.'%")';
          if($keywordSearchByAutoComplete){
          $where = '(kols.first_name = "'.$name.'")';
          }
          }else if(sizeof($arrKeywords)==2){
          $name1=trim($arrKeywords[0]);
          $name2=trim($arrKeywords[1]);
          $where="(kols.first_name IN('".$name1."','".$name2."') OR kols.last_name IN ('".$name1."','".$name2."') OR kols.middle_name IN ('".$name1."','".$name2."'))";
          if($keywordSearchByAutoComplete){
          $where = '((kols.first_name = "'.$name1.'" AND kols.last_name="'.$name2.'") or (kols.first_name = "'.$name1.'" AND kols.middle_name="'.$name2.'"))';
          }
          }else if(sizeof($arrKeywords)==3){
          $name1=trim($arrKeywords[0]);
          $name2=trim($arrKeywords[1]);
          $name3=trim($arrKeywords[2]);
          $where="(kols.first_name IN('".$name1."','".$name2."','".$name3."') OR kols.last_name IN ('".$name1."','".$name2."','".$name3."') OR kols.middle_name IN ('".$name1."','".$name2."','".$name3."'))";
          if($keywordSearchByAutoComplete){
          $where = '(kols.first_name = "'.$name1.'" AND kols.middle_name="'.$name2.'" AND kols.last_name="'.$name3.'")';
          }
          }
          $this->db->where($where);
         */
        //$this->db->like('first_name', $name, 'after');
        //$this->db->or_like('middle_name', $name, 'after');
        //$this->db->or_like('last_name', $name, 'after');
        //pr($arrFilterFields);

        if ($arrFilterFields != null && $arrFilterFields['country'] != '' && isset($arrFilterFields['country']) && sizeof($arrFilterFields['country']) > 0 && !($doGroupBy == true && $groupByCategory == 'country'))
            $this->db->where_in('countries.countryId', $arrFilterFields['country']);
        if ($arrFilterFields != null && $arrFilterFields['state'] != '' && isset($arrFilterFields['state']) && sizeof($arrFilterFields['state']) > 0 && !($doGroupBy == true && $groupByCategory == 'state')) {
            //$this->db->where_in('regions.region', $arrFilterFields['state']);
            $this->db->where_in('regions.regionID', $arrFilterFields['state']);
        }
        if ($arrFilterFields != null && $arrFilterFields['city'] != '' && isset($arrFilterFields['city']) && sizeof($arrFilterFields['city']) > 0 && !($doGroupBy == true && $groupByCategory == 'city')) {
            $this->db->where_in('cities.CityId', $arrFilterFields['city']);
        }
        if ($arrFilterFields != null && $arrFilterFields['organization'] != '' && isset($arrFilterFields['organization']) && sizeof($arrFilterFields['organization']) > 0 && !($doGroupBy == true && $groupByCategory == 'organization')) {
            //$this->db->where_in('organizations.name', $arrFilterFields['organization']);
            //$arrOrgIds	= array();
            //foreach($arrFilterFields['organization'] as $orgId=>$orgName){
            //	$arrOrgIds[]	= $orgId;
            //}
            //pr($arrFilterFields['organization']);
            $this->db->where('organizations.status', COMPLETED);
            $this->db->where_in('organizations.id', $arrFilterFields['organization']);
        }
        if ($arrFilterFields != null && $arrFilterFields['organization'] != '' && isset($arrFilterFields['organization']) && sizeof($arrFilterFields['organization']) > 0 && !($doGroupBy == true && $groupByCategory == 'organization')) {
            //$this->db->where_in('organizations.name', $arrFilterFields['organization']);
            //$arrOrgIds	= array();
            //foreach($arrFilterFields['organization'] as $orgId=>$orgName){
            //	$arrOrgIds[]	= $orgId;
            //}
            //pr($arrFilterFields['organization']);
            $this->db->where('organizations.status', COMPLETED);
            $this->db->where_in('organizations.id', $arrFilterFields['organization']);
        }
        if ($arrFilterFields != null && $arrFilterFields['specialty'] != '' && isset($arrFilterFields['specialty']) && sizeof($arrFilterFields['specialty']) > 0 && !($doGroupBy == true && $groupByCategory == 'specialty')) {
            $this->db->where_in('specialties.id', $arrFilterFields['specialty']);
        }
        if ($arrFilterFields != null && $arrFilterFields['kol_id'] != '') {
            $this->db->where_in('kols.id', $arrFilterFields['kol_id']);
        }
        if ($arrFilterFields != null && $arrFilterFields['profile_type'] != '') {
            $this->db->where('kols.profile_type', $arrFilterFields['profile_type']);
        }
        if ($arrKolIds != null && isset($arrKolIds) && sizeof($arrKolIds) > 0) {
            $this->db->where_in('kols.id', $arrKolIds);
        }
        if ($arrFilterFields != null && $arrFilterFields['global_region'] != '' && isset($arrFilterFields['global_region']) && sizeof($arrFilterFields['global_region']) > 0 && !($doGroupBy == true && $groupByCategory == 'global_region'))
            $this->db->where_in('countries.GlobalRegion', $arrFilterFields['global_region']);
        if ($doCount) {
            /*
              $this->db->distinct();
              $count=$this->db->count_all_results('kols');
             */
            if ($currentController == 'maps' or $currentControllerIpad == 'maps') {
                $this->db->where_in('kols.status', array(COMPLETED));
            } else {
                //$this->db->where_in('kols.status',array(COMPLETED,PRENEW));
                $this->db->where('kols.customer_status', "ACTV");
            }

            $this->db->select('COUNT(DISTINCT kols.id) AS count');
            if (isset($arrFilterFields) && sizeof($arrFilterFields['viewType']) > 0) {
                $this->db->where_in('kols.id', $arrFilterFields['viewType']);
            }
            if ($arrFilterFields['profile_type'] != "") {
                $this->db->where('kols.profile_type', $arrFilterFields['profile_type']);
            }
            $arrKolDetailsResult = $this->db->get('kols');
            $resultRow = $arrKolDetailsResult->row();
            $count = $resultRow->count;
//            echo $this->db->last_query();

            return $count;
        } else {
            if ($doGroupBy) {
                if ($groupByCategory == 'country') {
                    $this->db->select('kols.country_id,countries.country,COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('country_id');
                    //$this->db->where('country IS NOT NULL');
                }
                if ($groupByCategory == 'state') {
                    $this->db->select('kols.state_id,regions.region as state,COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('state_id');
                    //$this->db->where('country IS NOT NULL');
                }
                if ($groupByCategory == 'city') {
                    $this->db->select('kols.city_id,cities.City as city,COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('city_id');
                    //$this->db->where('country IS NOT NULL');
                }
                if ($groupByCategory == 'specialty') {
                    $this->db->select('kols.specialty,specialties.specialty as specs,COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('specialty');
                    //$this->db->where('specialties.specialty IS NOT NULL');
                }
                if ($groupByCategory == 'organization') {
                    $this->db->select('organizations.id as org_id,organizations.name,COUNT(DISTINCT kols.id) as count');
                    $this->db->where('organizations.status', COMPLETED);
                    $this->db->group_by('organizations.id');
                    //$this->db->where('name IS NOT NULL');
                }
                if ($groupByCategory == 'education') {
                    $this->db->select('COUNT(DISTINCT kols.id) as count,institutions.name as institute_name,kol_educations.institute_id');
                    $this->db->join('kol_educations', 'kol_educations.kol_id = kols.id', 'left');
                    $this->db->join('institutions', 'kol_educations.institute_id = institutions.id', 'left');
                    $this->db->where('kol_educations.type', 'education');
                    //$this->db->where('institutions.name IS NOT NULL');
                    $this->db->where('institutions.id > 0');
                    $this->db->group_by('kol_educations.institute_id');
                }
                if ($groupByCategory == 'event') {
                    //	$this->db->select('COUNT(DISTINCT kols.id) as count,events.name as event_name');
                    $this->db->select('COUNT(DISTINCT kols.id) as count,events.name as event_name,kol_events.event_id as event_id');
                    $this->db->join('kol_events', 'kol_events.kol_id = kols.id', 'left');
                    $this->db->join('events', 'kol_events.event_id = events.id', 'left');
                    //$this->db->where('events.name IS NOT NULL');
                    $this->db->where('events.id > 0');
                    $this->db->group_by('kol_events.event_id');
                }
                if ($groupByCategory == 'list') {
                    $this->db->select('list_kols.list_name_id,list_names.list_name,list_categories.category,COUNT(DISTINCT kols.id) AS count');
                    $this->db->join('list_kols', 'list_kols.kol_id=kols.id', 'left');
                    $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
                    $this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
                    $this->db->where('list_categories.client_id', $client_id);
                    $where = "(list_categories.user_id=$user_id OR list_categories.is_public=1)";
                    $this->db->where($where);
                    $this->db->group_by('list_kols.list_name_id');
                }
                if ($groupByCategory == 'global_region') {
                    //	$this->db->select('countries.GlobalRegion,COUNT(DISTINCT kols.id) as count');
                    //$this->db->group_by('countries.GlobalRegion');
                    //$this->db->where('country IS NOT NULL');
                }

                if ($groupByCategory == 'type') {
                    $this->db->select('organization_types.type,organization_types.id as org_type_id,COUNT(DISTINCT kols.id) as count');
                    $this->db->join('organization_types', 'organization_types.id=organizations.type_id', 'left');
//                                        $this->db->join('kols','kols.org_id=organizations.org_id','left');



                    $this->db->group_by('organization_types.id');
                }

                if ($groupByCategory == 'title') {
                    $this->db->select('kols.title,kols.id as kol_type_id,COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('kols.title');
                }

                if ($groupByCategory == 'region') {
                    $this->db->select('countries.GlobalRegion,countries.countryId as region_type_id,COUNT(DISTINCT kols.id) as count');
                    $this->db->group_by('countries.GlobalRegion');
                }

                $this->db->order_by('count', 'desc');
            } else {
                if (!$isFrmInfluenceMap)
                    $this->db->limit($limit, $startFrom);
            }
            if ($currentController == 'maps' or $currentControllerIpad == 'maps') {
                $this->db->where_in('kols.status', array(COMPLETED));
            } else {
                //$this->db->where_in('kols.status',array(COMPLETED,PRENEW));
                $this->db->where('kols.customer_status', "ACTV");
            }
            if ($arrFilterFields['profile_type'] != "") {
                $this->db->where('kols.profile_type', $arrFilterFields['profile_type']);
            }
            if (sizeof($arrQueryOptions) > 0) {
                switch ($arrQueryOptions['sort_by']) {
                    case 'name':
                        if ($this->session->userdata('name_order') == 2) {
                            $this->db->order_by('kols.last_name', $arrQueryOptions['sort_order']);
                        } else {
                            $this->db->order_by('kols.first_name', $arrQueryOptions['sort_order']);
                            $this->db->order_by('kols.middle_name', $arrQueryOptions['sort_order']);
                            $this->db->order_by('kols.last_name', $arrQueryOptions['sort_order']);
                        }
                        break;
                    case 'specialty':$this->db->order_by('specialties.specialty', $arrQueryOptions['sort_order']);
                        break;
                    case 'state':$this->db->order_by('regions.region', $arrQueryOptions['sort_order']);
                        break;
                    case 'city':$this->db->order_by('cities.City', $arrQueryOptions['sort_order']);
                        break;
                    case 'country':$this->db->order_by('countries.country', $arrQueryOptions['sort_order']);
                        break;
                }
            } else if (!$doGroupBy) {
                if ($this->session->userdata('name_order') == 2) {
                    $this->db->order_by('kols.last_name', $arrQueryOptions['sort_order']);
                } else {
                    $this->db->order_by('kols.first_name');
                }
            }
//			pr($arrFilterFields);
            if (isset($arrFilterFields) && sizeof($arrFilterFields['viewType']) > 0) {
                $this->db->where_in('kols.id', $arrFilterFields['viewType']);
            }
            $arrKolDetailsResult = $this->db->get('kols');
//			echo $this->db->last_query();
//			exit;
            foreach ($arrKolDetailsResult->result_array() as $row) {
                $arrKols[] = $row;
            }
            return $arrKols;
        }
    }

    function getKolsDetailsCount($arrKolIds){
            $this->db->select('*', false);
            $this->db->where_in('kol_id',$arrKolIds);
            $query=$this->db->get('kol_activities_count');
            $result=$query->result_array();
            return $result;
    }
    
    function getKolsEducations($arrKolIds){
        $data=array();
            $this->db->select('*,organizations.name as org_name', false);
             $this->db->join('organizations', 'organizations.id=kol_educations.institute_id', 'left');
            $this->db->where_in('kol_id',$arrKolIds);
            $query=$this->db->get('kol_educations');
            $result=$query->result_array();
           
            return $result;
    }
    
	function getMyKolsForOffline($userId){
		$this->db->select('kols.id,kols.first_name,kols.middle_name,kols.last_name,kols.title,kols.suffix,kols.primary_phone,kols.primary_email,kols.address1,kols.postal_code,kols.fax,kols.license,kols.profile_type,
		organizations.name as org_name,kols.biography,kols.research_interests,specialties.specialty,cities.city,regions.region,countries.country');
		$this->db->where('user_id',$userId);
		$this->db->join('kols','user_kols.kol_id = kols.id','left');
		$this->db->join('specialties','kols.specialty = specialties.id','left');
		$this->db->join('cities','kols.city_id = cities.cityid','left');
		$this->db->join('regions','kols.state_id = regions.regionid','left');
		$this->db->join('countries','kols.country_id = countries.countryid','left');
		$this->db->join('organizations','kols.org_id = organizations.id','left');
		//$this->db->where('kols.status',COMPLETED);
		$this->db->where('kols.customer_status',"ACTV");
		$result = $this->db->get('user_kols');
		foreach ($result->result_array() as $row){
			$arr[] = $row;  
		}
		return $arr;	
	}
          function getPublications($arrKolIds){
            $data=array();
            $this->db->select('kol_publications.kol_id,publications.id,publications.iso_abbreviation,publications.article_title,publications.abstract_text,publications.affiliation,publications.article_date', false);
             $this->db->join('publications', 'publications.id=kol_publications.pub_id', 'left');
            $this->db->where_in('kol_publications.kol_id',$arrKolIds);
            $this->db->limit(5);
            $query=$this->db->get('kol_publications');
            $result=$query->result_array();
           
            return $result;
    }
    
     function getEvents($arrKolIds){
            $data=array();
            $this->db->select('kol_events.kol_id,events.id,events.name,kol_events.session_name,kol_events.role,kol_events.start,kol_events.end,kol_events.organizer,event_topics.name as topic_name', false);
            $this->db->join('events', 'events.id=kol_events.event_id', 'left');
            $this->db->join('event_topics', 'event_topics.id=kol_events.topic', 'left');
            $this->db->where_in('kol_events.kol_id',$arrKolIds);
            $this->db->limit(5);
            $query=$this->db->get('kol_events');
            $result=$query->result_array();
           
            return $result;
    }
    
    function getTrials($arrKolIds){
            $data=array();
            $this->db->select('kol_clinical_trials.kol_id,clinical_trials.id,clinical_trials.trial_name,clinical_trials.link', false);
            $this->db->join('clinical_trials', 'kol_clinical_trials.cts_id=clinical_trials.id', 'left');
          
            $this->db->where_in('kol_clinical_trials.kol_id',$arrKolIds);
            $this->db->limit(5);
            $query=$this->db->get('kol_clinical_trials');
            $result=$query->result_array();
           
            return $result;
    }
    
    function getAff($arrKolIds){
            $data=array();
            $this->db->select('kol_memberships.kol_id,kol_memberships.department,organizations.name', false);
            $this->db->join('organizations', 'kol_memberships.kol_id=organizations.id', 'left');
          
            $this->db->where_in('kol_memberships.kol_id',$arrKolIds);
            $this->db->limit(5);
            $query=$this->db->get('kol_memberships');
            $result=$query->result_array();
           
            return $result;
    }
    
    function getKols(){
            $data=array();
            $this->db->select('kols.id,specialties.specialty,kols.first_name,kols.last_name');
            $this->db->join('specialties', 'specialties.id=kols.specialty', 'left');
            $query=$this->db->get('kols');
            $result=$query->result_array();
           
            return $result;
    }
    
     function getProducts(){
            $data=array();
            $this->db->select('name,id');
         
            $query=$this->db->get('products');
            $result=$query->result_array();
           
            return $result;
    }
    
     function getTypes(){
            $data=array();
            $this->db->select('name,id');
         
            $query=$this->db->get('interaction_types');
            $result=$query->result_array();
           
            return $result;
    }
    
     function getTopics(){
            $data=array();
            $this->db->select('name,id');
         
            $query=$this->db->get('interaction_topics');
            $result=$query->result_array();
            return $result;
    }
    
	function getSpecs(){
        $data=array();
            $this->db->select('specialty,id');
         
            $query=$this->db->get('specialties');
            $result=$query->result_array();
           
            return $result;
    }
    
    function getChannel(){
            $data=array();
            $this->db->select('name,id');
         
            $query=$this->db->get('interactions_modes');
            $result=$query->result_array();
           
            return $result;
    }
	function getMatchingkolMembers($title) {
            $this->db->select('institutions.name,kol_memberships.institute_id', false);
            $this->db->join('kol_memberships', 'kol_memberships.institute_id=institutions.id', 'left');
            $this->db->like('institutions.name', $title);
            $this->db->where('kol_memberships.type', "association");
            $this->db->group_by('kol_memberships.institute_id');
            $arrResultSet = $this->db->get('institutions');

            $arrTitleNames = array();
            foreach ($arrResultSet->result_array() as $arrRow) {
                $arrTitleNames[] = $arrRow['name']."_".$arrRow['institute_id'];
        }
//		echo $this->db->last_query();
        return $arrTitleNames;
    }
    
    function getMatchingTopics($title){
            $this->db->select('distinct event_topics.name', false);
            
            $this->db->like('event_topics.name', $title);
          
            $arrResultSet = $this->db->get('event_topics');

            $arrTitleNames = array();
            foreach ($arrResultSet->result_array() as $arrRow) {
                $arrTitleNames[] = $arrRow['name'];
        }
//		echo $this->db->last_query();
        return $arrTitleNames;
    }
    
    function getMemberName($id){
        $this->db->select('institutions.name', false);
            
            $this->db->where('institutions.id', $id);
          
            $arrResultSet = $this->db->get('institutions');

            $result=$arrResultSet->row_array();
            return $result['name'];
        }
    function checkCityIfExistElseAdd($city,$stateId,$country){
        $this->db->select('CityId');
        $this->db->where('city',$city);
        $this->db->limit(1);
        $query = $this->db->get('cities');
        $result = $query->result_array();
         
        if($result['0']['CityId'] == ""){
            $data = array(
                    'CountryID' => $country,
                    'RegionID' => $stateId,
                    'City'	=>	$city
            );
            $this->db->insert('cities', $data);
            return $this->db->insert_id();
        }else{
            return $result['0']['CityId'];
        }
    }   
	
    /*
     * Stores md5 value of kol id and store in unique id column.
     * This is used for kol consent.
     */
    function generateUniqueIdForKol(){
    	$this->db->select('id');
    	$this->db->order_by('id');
    	$arrResultSet = $this->db->get('kols');
    	foreach ($arrResultSet->result_array() as $arrRow) {
    		echo $arrRow['id'].'<br/>';
    		
    		$data = array(
    			'unique_id' => md5($arrRow['id'])
    		);
    		
    		$this->db->where('id', $arrRow['id']);
    		$this->db->update('kols', $data);
    	}
    }
    
    /*
     * Gets kol consent status for given kol id.
     */
    function getKolConsentStatus($kolId){
    	$this->db->select('consent_status');
    	$this->db->where('id', $kolId);
    	$query = $this->db->get('kols');
    	$result = $query->result_array();
    	$returnStatus = $result[0][consent_status];
    	return $returnStatus;
    }
    
    /*
     * Gets kol id for given unique id.
     */
    function getKolIdByUniqueId($uniqueId){
    	$this->db->select('id');
    	$this->db->where('unique_id', $uniqueId);
    	$query = $this->db->get('kols');
    	$result = $query->result_array();
    	$returnId = $result[0]['id'];
    	return $returnId;
    }
    /*
     * Gets unique id for given kol id.
     */
    function getUniqueIdByKolId($id){
        $this->db->select('unique_id');
        $this->db->where('id', $id);
        $query = $this->db->get('kols');
        $result = $query->result_array();
        $returnId = $result[0]['unique_id'];
    	return $returnId;
    }
    
    /*
     * Updates the kol consent data as per kol's request.
     */
    function updateKolConsent($consentData,$flag){
    	if($flag == 1){
    		$data = array(
    				'consent_notes' => $consentData['consent_notes'],
    				'consent_doc_link' => $consentData['consent_attachment_name'],
    				'consent_status' => '1'
    		);
    	}else{
    		$data = array(
    				'consent_notes' => ' ',
    				'consent_doc_link' => ' ',
    				'consent_status' => '0'
    		);
    	}
    	$this->db->where('id', $consentData['kol_id']);
    	$this->db->update('kols', $data);
    	if ($this->db->affected_rows() == '1') {
    		$status = 1;
    	}else{
    		$status = 0;
    	}
    	return $status;
    }
    
    function getAffiliationsDataById($affId){
    	//$this->db->select('kol_memberships.type as org_type,kol_memberships.institute_id,kol_memberships.department,kol_memberships.start_date,kol_memberships.end_date,kol_memberships.role,kol_memberships.engagement_id,institutions.name as org_name,engagement_types.engagement_type');
    	$this->db->select('kol_memberships.type as org_type,kol_memberships.institute_id,kol_memberships.department,kol_memberships.start_date,kol_memberships.end_date,kol_memberships.role,kol_memberships.engagement_id,institutions.name as org_name');
    	$this->db->join('institutions', 'institutions.id = kol_memberships.institute_id');
    	//$this->db->join('engagement_types', 'engagement_types.id = kol_memberships.engagement_id');
    	$this->db->where('kol_memberships.id', $affId);
    	$arrResultSet = $this->db->get('kol_memberships');
    	$result = $arrResultSet->row_array();
    	return $result;
    }
    
    function getEventDataById($eventId){
    	$this->db->select('kol_events.id as main_event_id,kol_events.event_type as event_type_id,kol_events.event_id,kol_events.session_type as session_type_id,kol_events.session_name,kol_events.role,kol_events.topic,kol_events.start,kol_events.end,kol_events.organizer,kol_events.sponsor_type,kol_events.session_sponsor,kol_events.organizer_type,kol_events.location,kol_events.address,kol_events.city_id,kol_events.state_id,kol_events.country_id,kol_events.postal_code,kol_events.url1 ,events.name as event_name,conf_event_types.event_type,conf_session_types.session_type,event_topics.name as topic_name,event_sponsor_types.type,event_organizer_types.type');
    	$this->db->join('events', 'events.id = kol_events.event_id');
    	$this->db->join('event_topics', 'event_topics.id = kol_events.topic');
    	$this->db->join('event_organizer_types', 'event_organizer_types.id = kol_events.organizer_type');
    	$this->db->join('event_sponsor_types', 'event_sponsor_types.id = kol_events.sponsor_type');
    	$this->db->join('conf_event_types', 'conf_event_types.id = kol_events.event_type');
    	$this->db->join('conf_session_types', 'conf_session_types.id = kol_events.session_type');
    	$this->db->where('kol_events.id', $eventId);
    	$arrResultSet = $this->db->get('kol_events');
    	$result = $arrResultSet->row_array();
    	return $result;
    }
   function getInteractionsCountByUsers($kolId,$group_by = false){
       $clientId = $this->session->userdata("client_id");
		$lastSixMonths = date("Y-m-d", strtotime("-6 months"));
		if($group_by)
			$this->db->select("interactions.created_by,count(interactions.id)");
		else
			$this->db->select("interactions.created_by");
		$this->db->join("interactions","interactions.id = interactions_attendees.interaction_id","left");
		$this->db->where("interactions_attendees.kol_id",$kolId);
		$this->db->where("interactions.date >",$lastSixMonths);
		$this->db->where("interactions.client_id",$clientId);
		if($group_by)
			$this->db->group_by("interactions.created_by");
		
		$arrInteractions = $this->db->get('interactions_attendees');
		return $arrInteractions->num_rows();
	}
	
	function getTopMeshTermsByKolId($kolId){
		$this->db->select("pubmed_mesh_terms.term_name,count(pubmed_mesh_terms.id) as term_count");
		$this->db->join("publications","kol_publications.pub_id = publications.id","left");
		$this->db->join("publication_mesh_terms","publications.id = publication_mesh_terms.pub_id","left");
		$this->db->join("pubmed_mesh_terms","pubmed_mesh_terms.id = publication_mesh_terms.term_id","left");
		$this->db->where("kol_publications.kol_id",$kolId);
		$this->db->group_by("pubmed_mesh_terms.id");
		$this->db->order_by("term_count","DESC");
		$this->db->limit(3);
		$arrPubTerms = $this->db->get("kol_publications");
		$arrPubTopTerms = array();
		foreach ($arrPubTerms->result_array() as $pubTerms){
			$arrPubTopTerms[] = $pubTerms;
		}
// 		pr($arrPubTopTerms);
		return $arrPubTopTerms;
	}
	
	function getKolYearsOfExperience($type,$kolId){
		$this->db->select("kol_educations.*");
		$this->db->where("kol_educations.type",$type);
		$this->db->where("kol_educations.kol_id",$kolId);
		if($type == 'education' || $type == 'training'){
			$this->db->where("(kol_educations.end_date is not null and kol_educations.end_date != '')");
			$this->db->order_by("kol_educations.end_date","ASC");
		}
		if($type == 'board_certification'){
			$this->db->where("(kol_educations.start_date is not null and kol_educations.start_date != '')");
			$this->db->order_by("kol_educations.start_date","ASC");
		}
		$arrEdu = $this->db->get("kol_educations");
		$arrEduExpe = array();
		foreach ($arrEdu->result_array() as $edu){
			$arrEduExpe[] = $edu;
		}
		return $arrEduExpe;
	}
	
	function getKolYearsOfExperienceFromAff($kolId){
		$arrMembershipDetails = array();
		$this->db->select(array('kol_memberships.*'));
		$this->db->where("(kol_memberships.start_date is not null and kol_memberships.start_date != '')");
		$this->db->where('kol_id', $kolId);
		$this->db->order_by('start_date',"ASC");
		if($arrMembershipDetailResult =	$this->db->get('kol_memberships')){
			foreach($arrMembershipDetailResult->result_array() as $arrMembership){
				$arrMembershipDetails[]=$arrMembership;
			}
			return $arrMembershipDetails;
		}
	
	}
        function getAuthPosCountByKolId($kolId){
        $this->db->where('kol_id',$kolId);
        $this->db->where_in('position_category',array('fa','la','sa'));
        $pubResult    =  $this->db->get('kol_publications');
//         echo $this->db->last_query();
        return $pubResult->num_rows();
    }
    function profileSummaryEvents($name,$kol_id){
    	$clientId = $this->session->userdata("client_id");
        	$this->db->select(' count(name) as topic_count,name,kol_events.kol_id,concat(kols.first_name," ",kols.last_name) as kol_name,specialties.specialty,regions.region as state,cities.city,regions.Code as state_code', false);
        	$this->db->join('event_topics', 'kol_events.topic=event_topics.id', 'left');
        	$this->db->join('kols', ' kols.id=kol_events.kol_id', 'left');
        	$this->db->join('specialties', 'specialties.id=kols.specialty', 'left');
        	$this->db->join('regions', 'regions.regionId=kols.state_id', 'left');
        	$this->db->join('cities', 'cities.cityId=kols.city_id', 'left');
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id=kols.id', 'left');
        	$this->db->where('kols_client_visibility.client_id', $clientId);
        	$this->db->where_not_in('kol_events.kol_id', $kol_id);
        	$this->db->where('kols.id is not null');
        	$this->db->where('event_topics.name', utf8_decode(urldecode($name)));
        	$this->db->group_by('kol_id');
        	$this->db->order_by('topic_count','desc');
        	$arrResultSet = $this->db->get('kol_events');
        	return $arrResultSet->result_array();
    }
    
    function profileSummaryPublications($name,$kol_id){
    	$clientId = $this->session->userdata("client_id");
        $this->db->select('count(publication_mesh_terms.term_id)/2 as topic_count,kol_publications.kol_id,concat(kols.first_name," ",kols.last_name) as kol_name,specialties.specialty,regions.region as state,cities.city,regions.Code as state_code', false);
        	$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = kol_publications.pub_id', 'left');
        	$this->db->join('pubmed_mesh_terms', 'pubmed_mesh_terms.id = publication_mesh_terms.term_id', 'left');
        	$this->db->join('kols', 'kols.id = kol_publications.kol_id', 'left');
        	$this->db->join('specialties', 'specialties.id=kols.specialty', 'left');
        	$this->db->join('regions', 'regions.regionId=kols.state_id', 'left');
        	$this->db->join('cities', 'cities.cityId=kols.city_id', 'left');
        	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id=kols.id', 'left');
        	$this->db->where('kols_client_visibility.client_id', $clientId);
        	$this->db->where_not_in('kol_publications.kol_id', $kol_id);
        	$this->db->where('kols.id is not null');
        	$this->db->where('kol_publications.is_deleted',0);
        	$this->db->where('kol_publications.is_verified',1);
        	$this->db->where('pubmed_mesh_terms.term_name',utf8_decode(urldecode($name)));
        	$this->db->group_by('kol_publications.kol_id');
        	$this->db->order_by('topic_count','desc');
        	$arrResultSet = $this->db->get('kol_publications');
        	return $arrResultSet->result_array();
    }
    
    function updateKolLocationLatitudeLongitude($arrKolLatLongData){
    	$this->db->where('kol_id', $arrKolLatLongData['kol_id']);
    	$this->db->where('is_primary', 1);
    	if ($this->db->update('kol_locations', $arrKolLatLongData)) {
    		return true;
    	} else {
    		return false;
    	}
    }
    //Function to fetch all client
    function getAllClients(){
    	$this->db->select('clients.id,clients.name');
    	$arrResultSet = $this->db->get('clients');
    	return $arrResultSet->result_array();
    }
    
    //Function to fetch all User on Client Id
    
    /*function listUsers($clientId){
    	if($clientId!=INTERNAL_CLIENT_ID){
    		$this->db->where("client_users.client_id",$clientId);
    	}
    	if($this->session->userdata('user_role_id')==ROLE_USER || $this->session->userdata('user_role_id')==ROLE_READONLY_USER){
    		$userId	= $this->session->userdata('user_id');
    		$this->db->where("client_users.id",$userId);
    	}
    	//	$this->db->where_in('client_users.user_from',array(1,2));
    	$this->db->where_in('client_users.status',array(ACTIVATED_USER));
    	$this->db->select("client_users.id,client_users.first_name,client_users.last_name");
    	//	$this->db->join('client_users as managers','managers.id = client_users.manager_id');
    	//	$this->db->join('clients','clients.id = client_users.client_id');
    	$this->db->order_by('client_users.first_name, client_users.last_name');
    	$arrUserResult = $this->db->get('client_users');
    	
    	return $arrUserResult->result_array();
    }*/
    function listUsers($clientId){
        $arrUsers	= array();  
        $group_ids = explode(',', $this->session->userdata('group_ids'));
        if($clientId!=INTERNAL_CLIENT_ID){
            $this->db->where("client_users.client_id",$clientId);
        }
        if($this->session->userdata('user_role_id')==ROLE_USER || $this->session->userdata('user_role_id')==ROLE_READONLY_USER){
            $userId	= $this->session->userdata('user_id');
            $this->db->where("client_users.id",$userId);
        }
        //	$this->db->where_in('client_users.user_from',array(1,2));
        $this->db->where_in('client_users.status',array(ACTIVATED_USER));
        $this->db->select("client_users.id,client_users.first_name,client_users.last_name");
        if($this->session->userdata('user_role_id')==ROLE_MANAGER){
            $this->db->join('user_groups','user_groups.user_id = client_users.id');
            $this->db->where_in("user_groups.group_id",$group_ids);
            $this->db->group_by('client_users.id');
        }
        //	$this->db->join('client_users as managers','managers.id = client_users.manager_id');
        //	$this->db->join('clients','clients.id = client_users.client_id');
        $this->db->order_by('client_users.first_name, client_users.last_name');
        $arrUserResult = $this->db->get('client_users');
        //pr($this->db->last_query());exit;
        return $arrUserResult->result_array();
    }
    //Function to fetch all User type
    function getAllClientsType(){
    	$this->db->select('id,name');
    	$arrResultSet = $this->db->get('kol_user_conatct_type');
    	return $arrResultSet->result_array();
    }
    //Function to save association or disassociation KOLs to particular client
    function saveKolClientAssociation($arrAssociationData){
    	$associationFlag = $arrAssociationData['associationFlag'];
    	$kolId = $arrAssociationData['kol_id'];
    	$clientId = $arrAssociationData['client_id'];
    	$status = '';
    	if($associationFlag == 'associate'){
    		if (strpos($kolId, ',') !== false) {
    			$arrKolIds = explode(",",$kolId);
    			foreach($arrKolIds as $kolId){
    				$arrReturnData = $this->getKolProfileType($kolId);
    				$arrData['profile_type'] = $arrReturnData[0]['profile_type'];
    				$arrData['kol_id'] = $kolId;
    				$arrData['client_id'] = $clientId;
    				$arrData['is_visible'] = '1';
    				if($this->db->insert('kols_client_visibility', $arrData)){
    					$status = 'success';
    				}else{
    					$status = 'fail';
    				}
    			}
    		}else{
    			$arrReturnData = $this->getKolProfileType($kolId);
    			$arrData['profile_type'] = $arrReturnData[0]['profile_type'];
    			$arrData['kol_id'] = $kolId;
    			$arrData['client_id'] = $clientId;
    			$arrData['is_visible'] = '1';
    			if($this->db->insert('kols_client_visibility', $arrData)){
    				$status = 'success';
    			}else{
    				$status = 'fail';
    			}
    		}
    	}else{
    		if (strpos($kolId, ',') !== false) {
    			$arrKolIds = explode(",",$kolId);
    			foreach($arrKolIds as $kolId){
	    			$this->db->where('kol_id', $kolId);
		    		$this->db->where('client_id', $clientId);
		    		if($this->db->delete('kols_client_visibility')){
		    			$status = 'success';
		    		}else{
		    			$status = 'fail';
		    		}
    			}
    		}else{
	    		$this->db->where('kol_id', $kolId);
	    		$this->db->where('client_id', $clientId);
	    		if($this->db->delete('kols_client_visibility')){
	    			$status = 'success';
	    		}else{
	    			$status = 'fail';
	    		}
    		}
    		
    	}
    	return $status;
    }
    /* Function to update biography of kol in json format */
    function updateKolProfileSummary($jsonData,$id){
        $data = array(
                "biography"=>$jsonData
        );
        $this->db->where('id', $id);
        $query	= $this->db->update('kols', $data);
        if($query){
            return true;
        }else{
            return false;
        }
    }
        function getAdditionalDetails($tableName,$id){
        	$arrData = array();
        	switch($tableName){
        		case 'phone_numbers' : $this->db->select("$tableName.*,kol_locations.address1 as name,phone_type.name as phone_type");
        		$this->db->join("kol_locations", "kol_locations.id = $tableName.location_id", "left");
        		$this->db->join("phone_type", "phone_type.id = $tableName.type", "left");
        		$this->db->where("$tableName.id", $id);
        		$resultSet = $this->db->get("$tableName");
        		if ($resultSet->num_rows() > 0){
        			$rowData = $resultSet->row();
        			$arrData['id'] = $rowData->id;
        			$arrData['type'] = $rowData->type;
        			$arrData['name'] = $rowData->name;
        			$arrData['number'] = $rowData->number;
        			$arrData['is_primary'] = $rowData->is_primary;
        			$arrData['location_id'] = $rowData->location_id;
        		}
        		break;
        		case 'staffs' : $this->db->select("$tableName.*,staff_title.name as staff_title,phone_type.name as phone_type,phone_type.id as type_id");
        		$this->db->join("staff_title", "staff_title.id = $tableName.title", "left");
        		$this->db->join("phone_type", "phone_type.id = $tableName.phone_type", "left");
        		$this->db->where("$tableName.id", $id);
        		$resultSet = $this->db->get("$tableName");
        		if ($resultSet->num_rows() > 0){
        			$rowData = $resultSet->row();
        			$arrData['id'] = $rowData->id;
        			$arrData['title'] = $rowData->title;
        			$arrData['name'] = $rowData->name;
        			$arrData['number'] = $rowData->phone_number;
        			$arrData['email'] = $rowData->email;
        			$arrData['type'] = $rowData->type_id;
        			$arrData['is_primary'] = $rowData->is_primary;
        			$arrData['location_id'] = $rowData->location_id;
        		}
        		break;
        		case 'emails' : $this->db->select("$tableName.*");
        		$this->db->where("$tableName.id", $id);
        		$resultSet = $this->db->get("$tableName");
        		if ($resultSet->num_rows() > 0){
        			$rowData = $resultSet->row();
        			$arrData['id'] = $rowData->id;
        			$arrData['type'] = $rowData->type;
        			$arrData['email'] = $rowData->email;
        			$arrData['is_primary'] = $rowData->is_primary;
        		}
        		break;
        		case 'state_licenses' : $this->db->select("$tableName.*");
        		$this->db->where("$tableName.id", $id);
        		$resultSet = $this->db->get("$tableName");
        		if ($resultSet->num_rows() > 0){
        			$rowData = $resultSet->row();
        			$arrData['id'] = $rowData->id;
        			$arrData['state_license'] = $rowData->state_license;
        			$arrData['region'] = $rowData->region;
        			$arrData['country_id'] = $rowData->country_id;
        			$arrData['is_primary'] = $rowData->is_primary;
        		}
        		break;
        		case 'user_kols' : $this->db->select("$tableName.*");
        		$this->db->where("$tableName.id", $id);
        		$resultSet = $this->db->get("$tableName");
        		if ($resultSet->num_rows() > 0){
        			$rowData = $resultSet->row();
        			$arrData['id'] = $rowData->id;
        			$arrData['user_id'] = $rowData->user_id;
        			$arrData['kol_id'] = $rowData->kol_id;
        			$arrData['type'] = $rowData->type;
        		}
        		break;
        	}
        
        	return $arrData;
        }
        
        
        
    //Returns the list of KOL Names, based on search
        function getAllKolNamesForAllAutocomplete($kolName,$restrictByRegion=0,$restrictOptInVisbility=0) {
    	$client_id = $this->session->userdata('client_id');
    	$kolName = str_replace ( ",", " ", $kolName );
    	$kolName = preg_replace ( '!\s+!', ' ', $kolName );
    	$kolName = $this->db->escape_like_str ( $kolName );
    	$arrKols = array ();
    	$this->db->select ( "kols.id,kols.unique_id,first_name,middle_name,last_name,organizations.name as name,kols.status,kols.do_not_call_flag,regions.region as state,cities.city as city,kol_locations.private_practice" );
    	$this->db->join ( 'organizations', 'kols.org_id=organizations.id', 'left' );
    	$this->db->join ( 'regions', 'regions.regionID = kols.state_id', 'left' );
    	$this->db->join ( 'cities', 'cities.cityID = kols.city_id', 'left' );
    	$this->db->join ( 'kol_locations', 'kols.id = kol_locations.kol_id', 'left' );
    	$likeNameFormatOrder	= 'first_name,middle_name,last_name';
    	$this->db->where('replace(concat(coalesce(first_name,"")," ",coalesce(middle_name,"")," ",coalesce(last_name,"")),"  "," ") like "%'.$kolName.'%"', '',false);
    	$this->db->where ('kols.customer_status', "ACTV" );
    	if(KOL_CONSENT && $restrictOptInVisbility==1){
    	    $this->db->where('(kols.opt_in_out_status = 0 OR kols.opt_in_out_status =4)','',false);
    	}
    	$nameFormat = $this->session->userdata('name_order');
    	if ($nameFormat == 1 || $nameFormat == 3)
    		$this->db->order_by("first_name",'asc');
    		else if ($nameFormat == 2)
    			$this->db->order_by("last_name",'asc');
    			if($client_id !== INTERNAL_CLIENT_ID){
    				$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
    				$this->db->where('kols_client_visibility.client_id', $client_id);
    				if($restrictByRegion==1  && $this->session->userdata('user_role_id') != ROLE_ADMIN && $this->session->userdata('user_role_id') != ROLE_READONLY_USER){
    					$group_names = explode(',', $this->session->userdata('group_names'));
    					$this->db->join ( 'countries', 'countries.CountryId=kols.country_id', 'left' );
    					$this->db->where_in( 'countries.GlobalRegion', $group_names);
    				}
    			}
    			
    			$arrKolsResult = $this->db->get ( 'kols' );
    			/* echo $this->db->last_query();
    			exit; */
    			$arrCompletedKols = array ();
    			$arrMyCustomers = array ();
    			foreach ( $arrKolsResult->result_array () as $row ) {
    				$arrMyCustomers [$row ['id']] [] = str_replace ( '  ', ' ', $this->common_helpers->get_name_format ( $row ['first_name'], $row ['middle_name'], $row ['last_name'] ) );
    					
    				if (! empty ( $row ['name'] ))
    					$arrMyCustomers [$row ['id']] [] = $row ['name'];
    					else
    						$arrMyCustomers [$row ['id']] [] = $row ['private_practice'];
    						$arrMyCustomers [$row ['id']] [] = $row ['state'];
    						$arrMyCustomers [$row ['id']] [] = $row ['city'];
    						$arrMyCustomers [$row ['id']] [] = $row ['unique_id'];
    						if ($row ['do_not_call_flag'] == 1)
    							$arrMyCustomers [$row ['id']] ['do_not_call_flag'] = "Do Not Call";
    							else
    								$arrMyCustomers [$row ['id']] ['do_not_call_flag'] = "";
    			}
    			$arrKols ['kols'] = $arrCompletedKols;
    			$arrKols ['customers'] = $arrMyCustomers;
    			return $arrKols;
    }
    
    function getAllKolIdsSpecificToClient(){
    	$clientId = $this->session->userdata('client_id');
    	$this->db->select("kols_client_visibility.kol_id");
    	$this->db->where("kols_client_visibility.client_id",$clientId);
    	$arrKolsIdsResult = $this->db->get("kols_client_visibility");
    	$arrResult = array();
    	foreach ( $arrKolsIdsResult->result_array () as $row ) {
    		$arrResult[] = $row['kol_id'];
    	}
    	return $arrResult;
    }

	function getKolsAssociatedWithClient($clientId){
		$this->db->select(array('kols.id as id', 'kols.id as kol_id', 'kols.salutation', 'concat(COALESCE(kols.first_name,"")," ", COALESCE(kols.middle_name,"")," ", COALESCE(kols.last_name,"")) as kol_name', 'specialties.specialty as kol_speciality', 'kols.gender as kol_gender', 'organizations.name as kol_org', 'concat(COALESCE(client_users.first_name,"")," ", COALESCE(client_users.last_name,"")) as kol_created_by', 'kols.pin as kol_pin', 'kols.status as kol_status','kols.is_pubmed_processed','kols.is_clinical_trial_processed'));
		$this->db->join ( 'kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left' );
		$this->db->join ( 'specialties', 'specialties.id = kols.specialty', 'left' );
		$this->db->join ( 'organizations', 'organizations.id = kols.org_id', 'left' );
		$this->db->join ( 'client_users', 'client_users.id = kols.created_by', 'left' );
		$this->db->where ( 'kols_client_visibility.client_id', $clientId );
		$this->db->order_by( 'kol_name', 'asc' );
		$arrKolsResult = $this->db->get ( 'kols' );
		//pr($this->db->last_query());exit;
		return $arrKolsResult->result_array();
	}

	function getKolsNotAssociatedWithClient($clientId){
		$this->db->select('kols.id');
		$this->db->join ( 'kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left' );
		$this->db->where ( 'kols_client_visibility.client_id', $clientId );
		$arrKolIdsResult = $this->db->get ( 'kols' );
		$arrKolIds = array();
		foreach ($arrKolIdsResult->result_array() as $row) {
			$arrKolIds[] = $row['id'];
		}
		
		$this->db->select(array('kols.id as id', 'kols.id as kol_id', 'kols.salutation', 'concat(COALESCE(kols.first_name,"")," ", COALESCE(kols.middle_name,"")," ", COALESCE(kols.last_name,"")) as kol_name', 'specialties.specialty as kol_speciality', 'kols.gender as kol_gender', 'organizations.name as kol_org', 'concat(COALESCE(client_users.first_name,"")," ", COALESCE(client_users.last_name,"")) as kol_created_by', 'kols.pin as kol_pin', 'kols.status as kol_status','kols.is_pubmed_processed','kols.is_clinical_trial_processed'));
		$this->db->join ( 'specialties', 'specialties.id = kols.specialty', 'left' );
		$this->db->join ( 'organizations', 'organizations.id = kols.org_id', 'left' );
		$this->db->join ( 'client_users', 'client_users.id = kols.created_by', 'left' );
		
		if(sizeof($arrKolIds) > 0){
			$this->db->where_not_in ( 'kols.id', $arrKolIds );
		}
		
		$this->db->order_by( 'kol_name', 'asc' );
		$arrKolsResult = $this->db->get ( 'kols' );
		//pr($this->db->last_query());exit;
		return $arrKolsResult->result_array();
	}
	
	function updateKolsStatusWithinClientVisibility($postData){
		$arrKolIds = explode(',',$postData['kol_id']);
		$size = sizeof($arrKolIds);
		
		$arrReturnData = array();
		if($postData['where'] == 'updateKolStatus' || $postData['where'] == 'updateKolStatus1'){
			$data = array('status' => $postData['update_status']);
		}
		if($postData['where'] == 'updatePubmedStatus' || $postData['where'] == 'updatePubmedStatus1'){
			$data = array('is_pubmed_processed' => $postData['update_status']);
		}
		if($postData['where'] == 'updateTrialStatus' || $postData['where'] == 'updateTrialStatus1'){
			$data = array('is_clinical_trial_processed' => $postData['update_status']);
		}
		
		if($size == '1'){
			$this->db->where('id', $postData['kol_id']);
		}else{
			$this->db->where_in('id', $postData['kol_id']);
		}
		
		if($size == '1'){
			$this->db->where('id', $postData['kol_id']);
			if($this->db->update('kols', $data)){
				$arrReturnData['status'] = 'success';
			}else{
				$arrReturnData['status'] = 'fail';
			}
		}else{
			for($i=0;$i<$size;$i++){
				$this->db->where('id', $arrKolIds[$i]);
				if($this->db->update('kols', $data)){
					$arrReturnData['status'] = 'success';
				}else{
					$arrReturnData['status'] = 'fail';
				}
			}
		}
		return $arrReturnData;
	}
	//Gets the profile type of a KOL for given KOL id
	function getKolProfileType($kolId){
		$this->db->select('profile_type');
		$this->db->where('id',$kolId);
		$arrResult = $this->db->get('kols');
		return $arrResult->result_array();
	}
	function getOrgTypeIdByName($arrTypeName){
		$orgId = 0;
		$this->db->where_in('type',$arrTypeName);
		$arrResultSet = $this->db->get('organization_types');
		foreach($arrResultSet->result_array() as $row){
			$orgId = $row['id'];
		}
		return $orgId;
	}
	
	function saveKolSpecialty($arrData){
		$checkSpecialty = $this->check_kolSpecialty($arrData['kol_sub_specialty_id'],$arrData['kol_id'],$arrData['priority']);
		if (!$checkSpecialty) {
					if($arrData['priority']==1){
	    				$this->db->where('id', $arrData['kol_id']);
	    				$this->db->update('kols', array('specialty' => $arrData['kol_sub_specialty_id']));
					}
			$this->db->insert('kol_sub_specialty',$arrData);
		}else{
			if($arrData['priority']==1){
				$get = $this->db->get_where("kol_sub_specialty",array("kol_id"=>$arrData['kol_id'],"priority"=>$arrData['priority']));
				if($get->num_rows()>0){
					$row = $get->row();
					if (isset($row))
					{
						$this->db->where('id', $row->id);
	    				$this->db->update('kol_sub_specialty', array("kol_sub_specialty_id"=>$arrData['kol_sub_specialty_id']));
					}
				}
			}
		}
	}
	
	// to check weather specialty aligned to kol with priority
	function check_kolSpecialty($specialty,$kol_id,$priority){
		$get = $this->db->get_where("kol_sub_specialty",array("kol_sub_specialty_id"=>$specialty,"kol_id"=>$kol_id,"priority"=>$priority));
		if($get->num_rows()>0){
			return true;
		}else{
			return false;
		}
	}
	
	function additionalDataInsert($arrData,$kolId){
		$this->db->where('id', $kolId);
		$this->db->update('kols',$arrData);
	}
	
	function getStaffTitle(){
		$arrDatas=array();
		$arrStaffTitle = $this->db->get('staff_title');
		foreach($arrStaffTitle->result_array() as $row){
			$arrDatas[$row['id']]	= $row['name'];
		}
		return $arrDatas;
	}
	
	function getPhoneType(){
		$arrDatas=array();
		$arrPhoneType = $this->db->get('phone_type');
		//echo $this->db->last_query();exit;
		foreach($arrPhoneType->result_array() as $row){
			$arrDatas[$row['id']]	= $row['name'];
		}
		return $arrDatas;
	}
	
	function savePhoneType($arrData) {
		$typeId = '';
		if ($this->db->insert('phone_type', $arrData)) {
			$typeId = $this->db->insert_id();
		} 
		return $typeId;
	}
	
	function saveStaffTitle($arrData) {
		$titleId = '';
		if ($this->db->insert('staff_title', $arrData)) {
			$titleId = $this->db->insert_id();
		} 
		return $titleId;
	}
	
	function getDetailsInfoById($kolIds,$type){
		switch($type){
			case 'Location':
							$this->db->select("kols.pin,organizations.name as org_name,titles.title,kol_locations.division,kol_locations.address1,kol_locations.address2,cities.City,regions.Region,countries.Country,kol_locations.postal_code");
							$this->db->select('CASE WHEN kol_locations.is_primary = 1 THEN "Yes" ELSE "No" END AS is_primary',false);
							$this->db->join("kol_locations","kol_locations.kol_id = kols.id","left");
							$this->db->join("countries","countries.CountryId = kol_locations.country_id","left");
							$this->db->join("regions","regions.RegionID = kol_locations.state_id","left");
							$this->db->join("cities","cities.CityId = kol_locations.city_id","left");
							$this->db->join("titles","titles.id = kol_locations.title","left");
							$this->db->join("organizations","organizations.id = kol_locations.org_institution_id","left");
							$this->db->where_in("kol_locations.kol_id",$kolIds);
							$query = $this->db->get("kols");
							return $query->result_array(); 
							break;
			case 'Phone':
							$this->db->select("kols.pin,phone_type.name,organizations.name as org_name,phone_numbers.number");
							$this->db->select('CASE WHEN phone_numbers.is_primary = 1 THEN "Yes" ELSE "No" END AS is_primary',false);
							$this->db->join("phone_numbers","phone_numbers.contact = kols.id","left");
							$this->db->join("kol_locations","kol_locations.id = phone_numbers.location_id","left");
							$this->db->join("organizations","organizations.id = kol_locations.org_institution_id","left");
							$this->db->join("phone_type","phone_type.id = phone_numbers.type","left");
							$this->db->where_in("phone_numbers.contact",$kolIds);
							$query = $this->db->get("kols");
							return $query->result_array();
			break;
			case 'Email':
							$this->db->select("kols.pin,emails.email,emails.type");
							$this->db->select('CASE WHEN emails.is_primary = 1 THEN "Yes" ELSE "No" END AS is_primary',false);
							$this->db->join("emails","emails.contact = kols.id","left");
							$this->db->where_in("kols.id",$kolIds);
							$query = $this->db->get("kols");
							return $query->result_array();
			break;
			case 'License':
							$this->db->select("kols.pin,state_licenses.state_license,regions.Region,countries.Country");
							$this->db->select('CASE WHEN state_licenses.is_primary = 1 THEN "Yes" ELSE "No" END AS is_primary',false);
							$this->db->join("state_licenses","state_licenses.contact = kols.id","left");
							$this->db->join("regions","regions.RegionID = state_licenses.region","left");
							$this->db->join("countries","countries.CountryId = regions.CountryId","left");
							$this->db->where_in("state_licenses.contact",$kolIds);
							$query = $this->db->get("kols");
							return $query->result_array();
			break;
			case 'Specialty':
							$this->db->select("kols.pin,specialties.specialty");
							$this->db->select('CASE WHEN kol_sub_specialty.priority = 1 THEN "Primary Specialty" WHEN  kol_sub_specialty.priority = 2 THEN "Additional Specialty" ELSE "Sub-Specialty" END AS priority',false);
							$this->db->select('CASE WHEN kol_sub_specialty.priority = 1 THEN "Yes" ELSE "No" END AS is_primary',false);
							$this->db->join("kol_sub_specialty","kol_sub_specialty.kol_id = kols.id","left");
							$this->db->join("specialties","specialties.id = kol_sub_specialty.kol_sub_specialty_id","left");
							$this->db->where_in("kol_sub_specialty.kol_id",$kolIds);
							$this->db->where("kol_sub_specialty.kol_sub_specialty_id !=",0);
							$query = $this->db->get("kols");
							return $query->result_array();
			break;
			case 'Staff':
							$this->db->select("kols.pin,staffs.name,staffs.phone_number,organizations.name as org_name,staffs.email,staff_title.name as staff_title,phone_type.name as phone_type,kol_locations.address1,kol_locations.address2,cities.City,regions.Region,countries.Country,kol_locations.postal_code");
							$this->db->join("staffs","staffs.contact = kols.id","left");
							$this->db->join("kol_locations","kol_locations.id = staffs.location_id","left");
							$this->db->join("organizations","organizations.id = kol_locations.org_institution_id","left");
							$this->db->join("countries","countries.CountryId = kol_locations.country_id","left");
							$this->db->join("regions","regions.RegionID = kol_locations.state_id","left");
							$this->db->join("cities","cities.CityId = kol_locations.city_id","left");
							$this->db->join("staff_title","staff_title.id = staffs.title","left");
							$this->db->join("phone_type","phone_type.id = staffs.phone_type","left");
							$this->db->where_in("staffs.contact",$kolIds);
							$query = $this->db->get("kols");
							return $query->result_array();
			break;
		}
	}
	
	function checkKolAissenedToUser($kolId){
	    if($client_id == INTERNAL_CLIENT_ID){
	        return true;
	    }else{
    	    $userId = $this->session->userdata('user_id');	    
    	    $get = $this->db->get_where('user_kols',array("user_id"=>$userId,"kol_id"=>$kolId));
    	    if($get->num_rows()>0){
    	       
    	        return true;
    	    }
    	    return false;
	    }
	}
	
	function getOptStatus($kolId){
		$this->db->select('CASE WHEN kols.opt_in_out_status = 1 THEN "New" WHEN kols.opt_in_out_status = 2 THEN "Requested" WHEN kols.opt_in_out_status = 3 THEN "Opted Out" WHEN kols.opt_in_out_status = 4 THEN "Opted In" ELSE "" END AS status',false);
		$this->db->where('id',$kolId);
		$query = $this->db->get('kols');
		if($query->num_rows()>0){
			$row = $query->row();
			if (isset($row))
			{
				return $row->status;
			}
		}else{
			return false;
		}
	}
	
	function getOptLogDetails($kolId){
	    $this->db->select_max('log_activities.created_on');
	    $this->db->select('log_activities.transaction_name,opt_inout.expire_date');
	    $this->db->join('opt_inout','opt_inout.kol_id = log_activities.miscellaneous1','left');
	    $this->db->where('log_activities.miscellaneous1',$kolId);
	    $this->db->where('log_activities.transaction_name !=','Visited');
	    $this->db->group_by('log_activities.transaction_name');
	    $this->db->order_by('log_activities.created_on','desc');
	    $arrResult = $this->db->get('log_activities');
	    return $arrResult->result_array();
	}
	
	function getEnableRegionForOptInOut(){
	    $arrNames = array();
	    $clientId = $this->session->userdata('client_id');
	    $this->db->select('optin_optout_settings.*,groups.group_name');
	    $this->db->join('groups','groups.group_id = optin_optout_settings.region','left');
	    $this->db->where('optin_optout_settings.isEnabled',1);
	    $this->db->where('optin_optout_settings.client_id',$clientId);
	    $arrResult = $this->db->get('optin_optout_settings');
	    foreach($arrResult->result_array() as $row){
	        $arrNames[] = $row['group_name'];
	    }
	    return $arrNames;
	}
	
	function getOptNameById($arrOptIds){
	    $arrOptNames = array();
	    $this->db->where_in('id',$arrOptIds);
	    $arrResultSet = $this->db->get('opt_inout_statuses');
	    foreach($arrResultSet->result_array() as $row){
	        $arrOptNames[$row['id']] = $row['name'];
	    }
	    return $arrOptNames;
	}
	
	function activtyTabularReport($typeId, $filters, $viewType,$activityType) {
	    $arrKols = array();
	    $this->db->select('kols.id, kols.first_name,kols.last_name,kols.middle_name,specialties.specialty,countries.Country as country,regions.Region as state, cities.City as city');
	    $this->db->join('countries', 'countries.CountryId = kols.country_id','left');
	    $this->db->join('regions', 'regions.RegionID = kols.state_id', 'left');
	    $this->db->join('cities', 'cities.CityId = kols.city_id', 'left');
	    $this->db->join('specialties', 'specialties.id = kols.specialty', 'left');
	    $this->db->where('kols.status', COMPLETED);
	    if($activityType=='country'){
	        $this->db->where('countries.Country', str_replace("%20"," ",$typeId));
	    }
	    if($activityType=='specialty'){
	        $this->db->where('specialties.specialty', str_replace("%20"," ",$typeId));
	    }
	    if (count($viewType) > 0 && !empty($viewType))
	        $this->db->where_in('kols.id', $viewType);
	        //Refine by filters
	        if ($filters != null) {
	            if(isset($filters['global_region'])){
	                $globalRegion = $filters['global_region'];
	                foreach($globalRegion as $arrGlobalRegionIds){
	                    $globalRegionSorted[] = str_replace("%20"," ",$arrGlobalRegionIds);
	                }	                
	                $isKolsJoined = true;
	                $this->db->where_in('countries.GlobalRegion', $globalRegionSorted);
	            }
	            if(isset($filters['profileType'])){
	                $profileType = $filters['profileType'];	                
	                $this->db->where_in('kols.profile_type', str_replace("%20"," ",$profileType));
	            }
	            if (isset($filters['specialty'])) {	                
	                $this->db->where_in('specialties.id', $filters['specialty']);
	            }
	            if (isset($filters['country'])) {
	                if($isKolsJoined == false)
	                    $this->db->where_in('countries.CountryId', $filters['country']);
	            }
	            if (isset($filters['state'])) {
	                $this->db->where_in('regions.RegionID', $filters['state']);
	            }
	            if (isset($filters['kol_id'])) {
	                $this->db->where_in('kols.id', $filters['kol_id']);
	            }
	            if (isset($filters['listName'])) {
	                $userId = $this->session->userdata('user_id');
	                $clientId = $this->session->userdata('client_id');
	                $this->db->join('list_kols', 'list_kols.kol_id=kols.id', 'left');
	                $this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
	                $this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
	                $this->db->where_in('list_names.id', $filters['listName']);
	                $this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
	            }
	        }
	        $this->db->group_by('kols.id');
	        $this->db->order_by('kols.first_name', 'desc');
	        $client_id = $this->session->userdata('client_id');
	        if($client_id !== INTERNAL_CLIENT_ID){
	            $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
	            $this->db->where('kols_client_visibility.client_id', $client_id);
	        }
	
	        $arrResults = $this->db->get('kols')->result_array();
	        foreach ($arrResults as $row) {
	                $row['name'] = $this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);
	                $arrKols[] = $row;
	        }
// 	        pr($arrKols);exit;
// 	        pr($this->db->last_query());exit;	        
	        return $arrKols;
	}
	
	function getLanguages(){
	    $this->db->select('*');
	    $this->db->order_by('lang_name','asc');
	    $results = $this->db->get('languages');
	    return $results->result_array();
	}
	
}




