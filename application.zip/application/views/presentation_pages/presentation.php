<?php
/**
 * HTML page to show about aissel solutions
 * 
 * @author Ramesh B
 * @since  3.2
 * @package application.controllers	
 * @created on 11-10-2011
 */
?>
<html>
<head>
	<title>KOLM - Aissel Solutions :: Presentation</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/screen.css" />
	
	<style>
	
		div#wrapper{
			margin: auto;
			display: block;
			width: 950px;
		}
		
		#headerContent, #bodyontent, #footerContent{
			float: left;
			width: 100%;
		}
		#headerContent div {
			float: left;
		}
		#preziEmbed_ea39eae996a4cf008881ea5abd52e255b9f11cec{
			margin: auto;
			margin-left: 80px;
		}
		
		#titleContent h1{
			line-height: normal;
			margin-bottom: 0px;
			margin-left: 80px;
		}
		
		#footerContent{
			text-align: center;
			margin-top: 10px;
		}
		
		#headerContent{
			margin-top: 10px;
		}
	</style>

</head>
<body>
<div id="wrapper">
	<div  id="headerContent">
		<div id="logoContent">
			<a href="http://www.aissel.com" ><img alt="Aissel Solutions" src="<?php echo base_url();?>images/kolm_logo_beta.png" /></a>
		</div>
		<div id="titleContent">
				<h1>Brief Introduction to Aissel Solutions</h1>
		</div>
	</div>
	<hr>
	<div  id="bodyontent">
		<div id="preziVideo">
			<object id="prezi_ea39eae996a4cf008881ea5abd52e255b9f11cec" 
					name="prezi_ea39eae996a4cf008881ea5abd52e255b9f11cec" 
					classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" 
					width="800" 
					height="600">
				<param name="movie" value="http://prezi.com/bin/preziloader.swf"/>
				<param name="allowfullscreen" value="true"/>
				<param name="allowscriptaccess" value="always"/>
				<param name="bgcolor" value="#ffffff"/>
				<param name="flashvars" value="prezi_id=ea39eae996a4cf008881ea5abd52e255b9f11cec&amp;lock_to_path=1&amp;color=ffffff&amp;autoplay=no&amp;autohide_ctrls=0"/>
				<embed id="preziEmbed_ea39eae996a4cf008881ea5abd52e255b9f11cec" 
						name="preziEmbed_ea39eae996a4cf008881ea5abd52e255b9f11cec" 
						src="http://prezi.com/bin/preziloader.swf" 
						type="application/x-shockwave-flash" 
						allowfullscreen="true" 
						allowscriptaccess="always" 
						width="800" 
						height="600" bgcolor="#ffffff" flashvars="prezi_id=ea39eae996a4cf008881ea5abd52e255b9f11cec&amp;lock_to_path=1&amp;color=ffffff&amp;autoplay=no&amp;autohide_ctrls=0">
				</embed>
			</object>			
		</div>
		<div>
			<p style="font-size:10px;text-align:center">Best viewed in full screen. Please  click on More & then Full screen. 
				Click anywhere on the presentation screen to move next. To view previous click on the left arrow on screen.
			</p>
		</div>
	</div>
	<div  id="footerContent">
		<b>KOL Identification | KOL Mapping | KOL Profiling | KOL Software	</b></br>
		To know more, visit &nbsp;<a href="http://www.aissel.com">www.aissel.com</a>
	</div>
</div>
</body>
</html>