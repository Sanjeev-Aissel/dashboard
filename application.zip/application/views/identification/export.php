<?php
//pr($arrProjects);
?>
<table>
	<tr>
		<th>ID Project Name</th>
		<th>Action</th>
	</tr>
	<?php 
		foreach($arrProjects as $key=>$row){
			echo '<tr>';
			echo '<td>'.$row['name'].'</td>';
			echo '<td><a href="'.base_url().'identifications/prepare_to_export/'.$row['id'].'">Export</a></td>';
			echo '</tr>';
		}
	?>
</table>