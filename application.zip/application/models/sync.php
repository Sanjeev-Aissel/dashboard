<?php
/**
 * model file for synchronization
 *
 * @Author		: Laxman K
 * @since 		: Otsuka v1.0.7
 * Created on	: 03-12-2012
 */

class Sync extends Model{
	//Constructor
	function Sync(){
		parent::Model();
	}
	function getCompleteKOLData($kolId){
		$arrMasterTables	= array('kols','kol_educations','kol_activities_count','kol_additional_contacts','kol_personal_info','kol_memberships','kol_events','kol_clinical_trials','kol_publications');
		$arrTables		= array(
									'kol_clinical_trials'	=> array('cts_sponsers','cts_mesh_terms','cts_keywords','cts_investigators','cts_interventions'),
									'kol_publications'		=> array('pubmed_article_ids','pubmed_authors','pubmed_cc','pubmed_publications_types','pubmed_mesh_terms','pubmed_substances')
								);
		$arrKolData	= array();
		foreach($arrMasterTables as $key=>$tableName){
			if($tableName!='kol_clinical_trials' || $tableName!='kol_publications'){
				$this->db->select($tableName.'.*');
			}
			switch($tableName){
				case 'kols':
						//$this->db->select('specialties.specialty as specialty_name, organizations.name as organization_name,organization_types.type as organization_type');
						$this->db->select('specialties.specialty as specialty_name, organizations.name as organization_name');
						$this->db->join('specialties','specialties.id='.$tableName.'.specialty','inner');
						$this->db->join('organizations','organizations.id='.$tableName.'.org_id','inner');
						//$this->db->join('organization_types','organization_types.id=organizations.type_id','inner');
					break;
				case 'kol_educations':
				case 'kol_memberships':
						$this->db->select('institutions.name as institution_name');
						$this->db->join('institutions','institutions.id='.$tableName.'.institute_id','left');
					break;
				case 'kol_events':
						$this->db->select('events.name as event_name,events.notes as event_note,event_topics.name as etopic_name,specialties.specialty as specialty_name');
						$this->db->join('events','events.id='.$tableName.'.event_id','inner');
						$this->db->join('event_topics','event_topics.id='.$tableName.'.topic','inner');
						$this->db->join('specialties','specialties.id=event_topics.specialty_id','left');
					break;
				case 'kol_clinical_trials':
						$this->db->select($tableName.'.kol_id,'.$tableName.'.client_id,'.$tableName.'.user_id');
						$this->db->select('clinical_trials.*,cts_statuses.status');
						$this->db->join('clinical_trials','clinical_trials.id='.$tableName.'.cts_id','inner');
						$this->db->join('cts_statuses','cts_statuses.id=clinical_trials.status_id','inner');
					break;
				case 'kol_publications':
						$this->db->select($tableName.'.kol_id,'.$tableName.'.client_id,'.$tableName.'.user_id,'.$tableName.'.pub_id,'.$tableName.'.auth_pos');
						$this->db->select('publications.*,pubmed_journals.name as journal_name');
						$this->db->where($tableName.'.is_deleted', 0);
						$this->db->where($tableName.'.is_verified',1);
						$this->db->join('publications','publications.id='.$tableName.'.pub_id','inner');
						$this->db->join('pubmed_journals','pubmed_journals.id=publications.journal_id','inner');
					break;
				case 'list_kols':
						$this->db->select('list_names.list_name,list_names.user_id as list_created_by,list_names.category_id,list_categories.category as category_name,list_categories.user_id as category_created_by,list_categories.client_id,list_categories.is_public');
						$this->db->join('list_names','list_names.id='.$tableName.'.list_name_id','inner');
						$this->db->join('list_categories','list_categories.id=list_names.category_id','inner');
					break;
			}
			switch($tableName){
				case 'kols':
							$this->db->where($tableName.'.id',$kolId);break;
				case 'kol_educations':
				case 'kol_activities_count':
				case 'kol_additional_contacts':
				case 'kol_personal_info':
				case 'kol_memberships':
				case 'kol_events':
				case 'kol_clinical_trials':
				case 'kol_publications':
				case 'list_kols':
							$this->db->where($tableName.'.kol_id',$kolId);
						break;
			}
			$arrKolTableData		= array();
			$resultSetObj			= $this->db->get($tableName);
			foreach($resultSetObj->result_array() as $row){
				$arrKolTableData[$row['id']]	= $row;
			}
			$arrKolData[$tableName]	= $arrKolTableData;
			// fetch dependent table data
			$arrMasterTableIds	= array_keys($arrKolData[$tableName]);
			foreach($arrTables[$tableName] as $tableIndex=>$tName){
				$arrData	= array();
				foreach($arrMasterTableIds as $ctIndex=>$rowId){
					switch($tName){
						case 'cts_sponsers':
								$this->db->select($tName.'.*');
								$this->db->join('ct_sponsers','ct_sponsers.sponser_id='.$tName.'.id','inner');
								$this->db->where('ct_sponsers.cts_id',$rowId);
							break;
						case 'cts_mesh_terms':
								$this->db->select($tName.'.*');
								$this->db->join('ct_mesh_terms','ct_mesh_terms.term_id='.$tName.'.id','inner');
								$this->db->where('ct_mesh_terms.cts_id',$rowId);
							break;
						case 'cts_keywords':
								$this->db->select($tName.'.*');
								$this->db->join('ct_keywords','ct_keywords.keyword_id='.$tName.'.id','inner');
								$this->db->where('ct_keywords.cts_id',$rowId);
							break;
						case 'cts_investigators':
								$this->db->select($tName.'.*');
								$this->db->join('ct_investigators','ct_investigators.investigator_id='.$tName.'.id','inner');
								$this->db->where('ct_investigators.cts_id',$rowId);
							break;
						case 'cts_interventions':
								$this->db->select($tName.'.*');
								$this->db->join('ct_interventions','ct_interventions.intervention_id='.$tName.'.id','inner');
								$this->db->where('ct_interventions.cts_id',$rowId);
							break;
						case 'pubmed_article_ids':
								$this->db->select($tName.'.*');
								$this->db->join('publication_article_ids','publication_article_ids.pub_article_id='.$tName.'.id','inner');
								$this->db->where('publication_article_ids.pub_id',$rowId);
							break;
						case 'pubmed_authors':
								$this->db->select($tName.'.*,publications_authors.position,publications_authors.alias_id as pub_alias_id, pubalias.last_name as pubalias_lname,pubalias.fore_name as pubalias_fname,pubalias.initials as pubalias_initials');
								$this->db->join('publications_authors','publications_authors.author_id='.$tName.'.id','inner');
								$this->db->join($tName.' as pubalias','pubalias.id=publications_authors.alias_id','left');
								$this->db->where('publications_authors.pub_id',$rowId);
							break;
						case 'pubmed_cc';
								$this->db->select($tName.'.*');
								$this->db->join('publications_cc','publications_cc.cc_id='.$tName.'.id','inner');
								$this->db->where('publications_cc.pub_id',$rowId);
							break;
						case 'pubmed_publications_types';
								$this->db->select($tName.'.*');
								$this->db->join('publications_types','publications_types.pub_type_id='.$tName.'.id','inner');
								$this->db->where('publications_types.pub_id',$rowId);
							break;
						case 'pubmed_mesh_terms';
								$this->db->select($tName.'.*,publication_mesh_terms.is_major,parent_meshterm.term_name as parent_term_name');
								$this->db->join('publication_mesh_terms','publication_mesh_terms.term_id='.$tName.'.id','inner');
								$this->db->join($tName.' as parent_meshterm','parent_meshterm.id='.$tName.'.parent_id','left');
								$this->db->where('publication_mesh_terms.pub_id',$rowId);
							break;
						case 'pubmed_substances';
								$this->db->select($tName.'.*');
								$this->db->join('publication_substances','publication_substances.substance_id='.$tName.'.id','inner');
								$this->db->where('publication_substances.pub_id',$rowId);
							break;
						
					}
					$arrTableData		= array();
					$resultSetObj1		= $this->db->get($tName);
					foreach($resultSetObj1->result_array() as $row){
						$arrTableData[$row['id']]	= $row;
					}
					$arrData[$rowId]	= $arrTableData;
				}
				$arrKolData[$tName]	= $arrData;
			}
		}
		return $arrKolData;
	}
	
	function syncCompleteKOLData($arrKolData){
		$this->db->database='test';
		pr($this->db->database);
		$CI =& get_instance();
		$CI->userdb	= $this->load->database($this->db);
		$this->dbSyncObj	=& $CI->userdb;
		pr($this->dbSyncObj->list_tables());
	//	$CI =& get_instance();
	//	$CI->userdb	= $this->load->database($this->dbConfigData, TRUE);
	//	$this->dbSyncObj	=& $CI->userdb;
	//	foreach($arrKolData as $tableName=>$arrTableData){
			//echo '<br />'.$tableName;
			//pr($arrTableData);
			//pr($this->dbSyncObj->list_tables());
	//	}
	}
	function saveOrUpdateKol($arrKol){
		$id				= $arrKol['id'];
		$specialtyName	= trim($arrKol['specialty_name']);
		$orgName		= $arrKol['organization_name'];
		$orgType		= $arrKol['organization_type'];
		unset($arrKol['id']);
		unset($arrKol['specialty_name']);
		unset($arrKol['organization_name']);
		unset($arrKol['organization_type']);
		if($arrKol['org_id']!=0 || !empty($arrKol['org_id'])){
			$CI =& get_instance();
    		$CI->load->model('organization','organization',true);
			$organization['name']	= $orgName;
			$arrKol['org_id']		= $CI->organization->saveOrganization($organization);
		}
		if(!empty($specialtyName)){
			$CI =& get_instance();
    		$CI->load->model('kol','kol',true);
			$arrData['specialty']	= $specialtyName;
			$arrKol['specialty']	= $CI->kol->saveSpecialty($arrData);
		}
		$this->db->select('kols.id');
		$this->db->where('kols.first_name',$arrKol['first_name']);
		$this->db->where('kols.middle_name',$arrKol['middle_name']);
		$this->db->where('kols.last_name',$arrKol['last_name']);
		$this->db->where('kols.specialty',$arrKol['specialty']);
		$this->db->where('kols.city_id',$arrKol['city_id']);
		$this->db->where('kols.state_id',$arrKol['state_id']);
		$this->db->where('kols.country_id',$arrKol['country_id']);
		if($arrKol['org_id']!=0 || !empty($arrKol['org_id'])){
			$this->db->where('organizations.name',$orgName);
			$this->db->join('organizations','organizations.id=kols.org_id','inner');
		}
		$arrKolDetail = $this->db->get('kols');
		$arrRow	= $arrKolDetail->result_array();
		if($arrKolDetail->num_rows()!=0){
			$this->db->where('id',$arrRow[0]['id']);
			$this->db->update('kols',$arrKol);
			return $arrRow[0]['id'];
		}else{
			if($this->db->insert('kols',$arrKol)){
				return $this->db->insert_id();
			}else{
				return false;
			}
		}
		
	}
	function saveOrUpdateKolEdu($arrEdu){
		$id				= $arrEdu['id'];
		$instituteName	= trim($arrEdu['institution_name']);
		unset($arrEdu['id']);
		unset($arrEdu['institution_name']);
		if($instituteName!=null || !empty($instituteName)){
			$CI =& get_instance();
    		$CI->load->model('kol','kol',true);
			$institute['name']	= $instituteName;
			$arrEdu['institute_id']		= $CI->kol->getInstituteIdElseSave($institute);
		}
		$this->db->select('kol_educations.id');
		$this->db->where('kol_educations.kol_id',$arrEdu['kol_id']);
		$this->db->where('kol_educations.type',$arrEdu['type']);
		$this->db->where('kol_educations.specialty',$arrEdu['specialty']);
		$this->db->where('kol_educations.degree',$arrEdu['degree']);
		$this->db->where('kol_educations.start_date',$arrEdu['start_date']);
		$this->db->where('kol_educations.end_date',$arrEdu['end_date']);
		$this->db->where('kol_educations.honor_name',$arrEdu['honor_name']);
		if($arrEdu['institute_id']!=0 || !empty($arrEdu['institute_id'])){
			$this->db->where('kol_educations.institute_id',$arrEdu['institute_id']);
		}
		$arrEduDetail = $this->db->get('kol_educations');
		$arrRow	= $arrEduDetail->result_array();
		if($arrEduDetail->num_rows()!=0){
			$this->db->where('kol_educations.id',$arrRow[0]['id']);
			$this->db->update('kol_educations',$arrEdu);
			return $arrRow[0]['id'];
		}else{
			if($this->db->insert('kol_educations',$arrEdu)){
				return $this->db->insert_id();
			}else{
				return false;
			}
		}
	}
	function saveOrUpdateKolProfileScore($arrProfileScore){
		$this->db->where('kol_activities_count.kol_id',$arrProfileScore['kol_id']);
		$arrProfileScoreDetail = $this->db->get('kol_activities_count');
		$arrRow	= $arrProfileScoreDetail->result_array();
		unset($arrProfileScore['id']);
		if($arrProfileScoreDetail->num_rows()!=0){
			$this->db->where('kol_activities_count.kol_id',$arrRow[0]['kol_id']);
			$this->db->update('kol_activities_count',$arrProfileScore);
			return $arrRow[0]['id'];
		}else{
			if($this->db->insert('kol_activities_count',$arrProfileScore)){
				return $this->db->insert_id();
			}else{
				return false;
			}
		}
	}
	function saveOrUpdateKolAdditionalContacts($arrAdditionalContacts){
		$this->db->where('kol_additional_contacts.kol_id',$arrAdditionalContacts['kol_id']);
		$this->db->where('kol_additional_contacts.phone',$arrAdditionalContacts['phone']);
		$this->db->where('kol_additional_contacts.email',$arrAdditionalContacts['email']);
		$arrAdditionalContactsDetail = $this->db->get('kol_additional_contacts');
		$arrRow	= $arrAdditionalContactsDetail->result_array();
		unset($arrAdditionalContacts['id']);
		if($arrAdditionalContactsDetail->num_rows()!=0){
			$this->db->where('kol_additional_contacts.kol_id',$arrRow[0]['kol_id']);
			$this->db->update('kol_additional_contacts',$arrAdditionalContacts);
			return $arrRow[0]['id'];
		}else{
			if($this->db->insert('kol_additional_contacts',$arrAdditionalContacts)){
				return $this->db->insert_id();
			}else{
				return false;
			}
		}
	}
	function saveOrUpdateKolPersonalInfo($arrPersonalInfo){
		$this->db->where('kol_personal_info.kol_id',$arrPersonalInfo['kol_id']);
		$arrPersonalInfoDetail = $this->db->get('kol_personal_info');
		$arrRow	= $arrPersonalInfoDetail->result_array();
		unset($arrPersonalInfo['id']);
		if($arrPersonalInfoDetail->num_rows()!=0){
			$this->db->where('kol_personal_info.kol_id',$arrRow[0]['kol_id']);
			$this->db->update('kol_personal_info',$arrPersonalInfo);
			return $arrRow[0]['id'];
		}else{
			if($this->db->insert('kol_personal_info',$arrPersonalInfo)){
				return $this->db->insert_id();
			}else{
				return false;
			}
		}
	}
	function saveOrUpdateKolMemberships($arrMemberships){
		$id				= $arrMemberships['id'];
		$instituteName	= $arrMemberships['institution_name'];
		unset($arrMemberships['id']);
		unset($arrMemberships['institution_name']);
		if($instituteName!=null || !empty($instituteName)){
			$CI =& get_instance();
    		$CI->load->model('kol','kol',true);
			$institute['name']	= $instituteName;
			$arrMemberships['institute_id']		= $CI->kol->getInstituteIdElseSave($institute);
		}
		$this->db->select('kol_memberships.id,kol_memberships.kol_id');
		$this->db->where('kol_memberships.kol_id',$arrMemberships['kol_id']);
		$this->db->where('kol_memberships.type',$arrMemberships['type']);
		$this->db->where('kol_memberships.department',$arrMemberships['department']);
		$this->db->where('kol_memberships.title',$arrMemberships['title']);
		$this->db->where('kol_memberships.start_date',$arrMemberships['start_date']);
		$this->db->where('kol_memberships.end_date',$arrMemberships['end_date']);
		$this->db->where('kol_memberships.role',$arrMemberships['role']);
		$this->db->where('kol_memberships.division',$arrMemberships['division']);
		if($arrMemberships['institute_id']!=0 || !empty($arrMemberships['institute_id'])){
			$this->db->where('kol_memberships.institute_id',$arrMemberships['institute_id']);
		}
		$arrMembershipDetail = $this->db->get('kol_memberships');
		$arrRow	= $arrMembershipDetail->result_array();
		if($arrMembershipDetail->num_rows()!=0){
			$this->db->where('kol_memberships.id',$arrRow[0]['id']);
			$this->db->where('kol_memberships.kol_id',$arrRow[0]['kol_id']);
			$this->db->update('kol_memberships',$arrMemberships);
			return $arrRow[0]['id'];
		}else{
			if($this->db->insert('kol_memberships',$arrMemberships)){
				return $this->db->insert_id();
			}else{
				return false;
			}
		}
	}
	function saveOrUpdateEvents($arrEvents){
		$id	= $arrEvents['id'];
		unset($arrEvents['id']);
		$CI =& get_instance();
    	$CI->load->model('kol','kol',true);
		if($arrEvents['event_id']!=0 || !empty($arrEvents['event_id'])){
			$events['name']	= $arrEvents['event_name'];
			$arrEvents['event_id']		= $CI->kol->getEventIdElseSave($events);
		}
		if($arrEvents['topic']!=0 || !empty($arrEvents['topic'])){
			$eventsTopic['name']		= $arrEvents['etopic_name'];
			$eventsTopic['specialty_id']= null;
			if(!empty($arrEvents['specialty_name']))
				$eventsTopic['specialty_id']= $CI->kol->saveSpecialty(array('specialty'=>$arrEvents['specialty_name']));
			$arrEvents['topic']			= $CI->kol->saveEventTopic($eventsTopic);
		}
		$this->db->select('kol_events.id,kol_events.kol_id');
		$this->db->where('kol_events.kol_id',$arrEvents['kol_id']);
		$this->db->where('kol_events.type',$arrEvents['type']);
		$this->db->where('kol_events.event_type',$arrEvents['event_type']);
		$this->db->where('kol_events.session_name',$arrEvents['session_name']);
		$this->db->where('kol_events.role',$arrEvents['role']);
		$this->db->where('kol_events.start',$arrEvents['start']);
		$this->db->where('kol_events.end',$arrEvents['end']);
		$this->db->where('kol_events.session_type',$arrEvents['session_type']);
		$this->db->where('kol_events.organizer',$arrEvents['organizer']);
		$this->db->where('kol_events.location',$arrEvents['location']);
		$this->db->where('kol_events.address',$arrEvents['address']);
		$this->db->where('kol_events.city_id',$arrEvents['city_id']);
		$this->db->where('kol_events.state_id',$arrEvents['state_id']);
		$this->db->where('kol_events.country_id',$arrEvents['country_id']);
		if($arrEvents['event_id']!=0 || !empty($arrEvents['event_id'])){
			$this->db->where('kol_events.event_id',$arrEvents['event_id']);
		}
		if($arrEvents['topic']!=0 || !empty($arrEvents['topic'])){
			$this->db->where('kol_events.topic',$arrEvents['topic']);
		}
	
		$arrEventDetail = $this->db->get('kol_events');
		$arrRow	= $arrEventDetail->result_array();
		unset($arrEvents['event_name']);
		unset($arrEvents['event_note']);
		unset($arrEvents['etopic_name']);
		unset($arrEvents['specialty_name']);
		if($arrEventDetail->num_rows()!=0){
			$this->db->where('kol_events.id',$arrRow[0]['id']);
			$this->db->where('kol_events.kol_id',$arrRow[0]['kol_id']);
			$this->db->update('kol_events',$arrEvents);
			return $arrRow[0]['id'];
		}else{
			if($this->db->insert('kol_events',$arrEvents)){
				return $this->db->insert_id();
			}else{
				return false;
			}
		}
	}
	function saveOrUpdateTrials($arrTrials){
		$id				= $arrTrials['id'];
		unset($arrTrials['id']);
		$this->db->select('kol_clinical_trials.id,kol_clinical_trials.cts_id,kol_clinical_trials.kol_id');
		$this->db->where('kol_clinical_trials.kol_id',$arrTrials['kol_id']);
		$this->db->where('clinical_trials.trial_name',$arrTrials['trial_name']);
		$this->db->where('clinical_trials.ct_id',$arrTrials['ct_id']);
		$this->db->where('clinical_trials.purpose',$arrTrials['purpose']);
		$this->db->where('clinical_trials.condition',$arrTrials['condition']);
		$this->db->where('clinical_trials.phase',$arrTrials['phase']);
		$this->db->where('clinical_trials.official_title',$arrTrials['official_title']);
		$this->db->where('clinical_trials.study_type',$arrTrials['study_type']);
		$this->db->where('clinical_trials.start_date',$arrTrials['start_date']);
		$this->db->where('clinical_trials.end_date',$arrTrials['end_date']);
		$this->db->where('clinical_trials.no_of_enrollees',$arrTrials['no_of_enrollees']);
		$this->db->where('clinical_trials.no_of_trial_sites',$arrTrials['no_of_trial_sites']);
		$this->db->where('clinical_trials.collaborator',$arrTrials['collaborator']);
		$this->db->where('clinical_trials.kol_role',$arrTrials['kol_role']);
		$this->db->where('clinical_trials.min_age',$arrTrials['min_age']);
		$this->db->where('clinical_trials.max_age',$arrTrials['max_age']);
		$this->db->where('clinical_trials.gender',$arrTrials['gender']);
		$this->db->where('cts_statuses.status',$arrTrials['status']);
		$this->db->join('clinical_trials','clinical_trials.id=kol_clinical_trials.cts_id','inner');
		$this->db->join('cts_statuses','cts_statuses.id=clinical_trials.status_id','inner');
		$arrTrialDetail = $this->db->get('kol_clinical_trials');
		$arrRow	= $arrTrialDetail->result_array();
		$arrKolClinicalTrials	= array();
		$arrKolClinicalTrials['kol_id']	= $arrTrials['kol_id'];
		$arrKolClinicalTrials['cts_id']	= $arrTrials['cts_id'];
		$arrKolClinicalTrials['client_id']	= $arrTrials['client_id'];
		$arrKolClinicalTrials['user_id']	= $arrTrials['user_id'];
		$arrKolClinicalTrials['is_deleted']	= $arrTrials['is_deleted'];
		$arrKolClinicalTrials['is_verified']= $arrTrials['is_verified'];
		unset($arrTrials['is_deleted']);
		unset($arrTrials['is_verified']);
		unset($arrTrials['kol_id']);
		unset($arrTrials['cts_id']);
		unset($arrTrials['status']);
		unset($arrTrials['client_id']);
		unset($arrTrials['user_id']);
		if($arrTrialDetail->num_rows()!=0){
			$this->db->where('clinical_trials.id',$arrRow[0]['cts_id']);
			$this->db->update('clinical_trials',$arrTrials);
			$this->db->where('kol_clinical_trials.id',$arrRow[0]['id']);
			$this->db->where('kol_clinical_trials.cts_id',$arrRow[0]['cts_id']);
			$this->db->where('kol_clinical_trials.kol_id',$arrRow[0]['kol_id']);
			$this->db->update('kol_clinical_trials',$arrKolClinicalTrials);
			return $arrRow[0]['cts_id'];
		}else{
			if($this->db->insert('clinical_trials',$arrTrials)){
				$arrKolClinicalTrials['cts_id']	= $this->db->insert_id();
				$this->db->insert('kol_clinical_trials',$arrKolClinicalTrials);
				return $arrKolClinicalTrials['cts_id'];
			}else{
				return false;
			}
		}
	}
	function saveOrUpdatePubs($arrPubs){
		$id	= $arrPubs['id'];
		unset($arrPubs['id']);
		if($arrPubs['journal_id']!=0 || !empty($arrPubs['journal_id'])){
			$CI =& get_instance();
    		$CI->load->model('pubmed','pubmed',true);
			$arrPubs['journal_id']		= $CI->pubmed->savejournalName($arrPubs['journal_name']);
		}
		$this->db->select('kol_publications.id,kol_publications.pub_id,kol_publications.kol_id');
		$this->db->where('kol_publications.kol_id',$arrPubs['kol_id']);
		$this->db->where('kol_publications.is_deleted',$arrPubs['is_deleted']);
		$this->db->where('kol_publications.is_verified',$arrPubs['is_verified']);
		$this->db->where('kol_publications.auth_pos',$arrPubs['auth_pos']);
		$this->db->where('publications.pmid',$arrPubs['pmid']);
		$this->db->join('publications','publications.id=kol_publications.pub_id','inner');
		if($arrPubs['journal_id']!=0 || !empty($arrPubs['journal_id'])){
			$this->db->where('publications.journal_id',$arrPubs['journal_id']);
		}
		$arrPubDetail = $this->db->get('kol_publications');
		$arrRow	= $arrPubDetail->result_array();
		$arrKolPubs	= array();
		$arrKolPubs['kol_id']	= $arrPubs['kol_id'];
		$arrKolPubs['pub_id']	= $arrPubs['pub_id'];
		$arrKolPubs['client_id']= ($arrPubs['client_id']==null || empty($arrPubs['client_id']))?INTERNAL_CLIENT_ID:$arrPubs['client_id'];
		$arrKolPubs['user_id']	= ($arrPubs['user_id']==null || empty($arrPubs['user_id']))?$this->session->userdata('user_id'):$arrPubs['client_id'];
		$arrKolPubs['is_verified']	= $arrPubs['is_verified'];
		$arrKolPubs['is_deleted']	= $arrPubs['is_deleted'];
		$arrKolPubs['auth_pos']	= $arrPubs['auth_pos'];
		unset($arrPubs['kol_id']);
		unset($arrPubs['pub_id']);
		unset($arrPubs['client_id']);
		unset($arrPubs['user_id']);
		unset($arrPubs['is_deleted']);
		unset($arrPubs['is_verified']);
		unset($arrPubs['auth_pos']);
		unset($arrPubs['journal_name']);
		if($arrPubDetail->num_rows()!=0){
			$this->db->where('publications.id',$arrRow[0]['pub_id']);
			$this->db->update('publications',$arrPubs);

			$this->db->where('kol_publications.id',$arrRow[0]['id']);
			$this->db->where('kol_publications.pub_id',$arrRow[0]['pub_id']);
			$this->db->where('kol_publications.kol_id',$arrRow[0]['kol_id']);
			$this->db->update('kol_publications',$arrKolPubs);
			//return $arrRow[0]['id'];
			return false;
		}else{
			$this->db->select('publications.id');
			$this->db->where('publications.pmid',$arrPubs['pmid']);
			$arrPubDetail = $this->db->get('publications');
			if($arrPubDetail->num_rows()==0){
				$this->db->insert('publications',$arrPubs);
				$arrKolPubs['pub_id']	= $this->db->insert_id();
			}else{
				$arrRow	= $arrPubDetail->result_array();
				$arrKolPubs['pub_id']	= $arrRow[0]['id'];
			}
			if($arrKolPubs['pub_id']!=0){
				$this->db->insert('kol_publications',$arrKolPubs);
				return $arrKolPubs['pub_id'];
			}else{
				return false;
			}
		}
	}
	function saveOrUpdateLists($arrLists){
		$id	= $arrLists['id'];
		unset($arrLists['id']);
		$this->db->select('list_names.id');
		$this->db->where('list_kols.kol_id',$arrLists['kol_id']);
		$this->db->where('list_names.list_name',$arrLists['list_name']);
		$this->db->where('list_categories.category',$arrLists['category_name']);
		$this->db->where('list_categories.user_id',$arrLists['category_created_by']);
		$this->db->where('list_categories.is_public',$arrLists['is_public']);
		$this->db->join('list_names','list_names.id=list_kols.list_name_id','inner');
		$this->db->join('list_categories','list_categories.id=list_names.category_id','inner');
		$arrListDetail = $this->db->get('list_kols');
		$arrRow	= $arrListDetail->result_array();
		$arrKolLists	= array();
		$arrKolLists['user_id']	= $arrLists['user_id'];
		$arrKolLists['kol_id']	= $arrLists['kol_id'];
		$arrKolLists['list_name_id']	= $arrLists['list_name_id'];
		$arrLists['user_id']	= $arrLists['list_created_by'];
		unset($arrLists['user_id']);
		unset($arrLists['kol_id']);
		unset($arrLists['list_name_id']);
		unset($arrLists['list_created_by']);
		unset($arrLists['category_name']);
		unset($arrLists['category_created_by']);
		if($arrListDetail->num_rows()!=0){
			$this->db->where('list_kols.list_name_id',$arrRow[0]['id']);
			$this->db->update('list_kols',$arrKolLists);
		}else{
			if($this->db->insert('list_names',$arrLists)){
				$arrKolLists['list_name_id']	= $this->db->insert_id();
				$this->db->insert('list_kols',$arrKolLists);
				return $arrKolLists['list_name_id'];
			}else{
				return false;
			}
		}
	}
}
?>