<?php
/**
 *File To Know Basics.
 *Created By:
 *Created On:3:33:20 PM
 */

?>

<style type="text/css">

.searchButton {
	background: url("<?php echo base_url();?>images/search.PNG") no-repeat scroll center center transparent;
	border: medium none;
	height: 28px;
	width: 31px;
	cursor: pointer;
}

#doSimpleSearch {
	margin-left: -5px;
}

#searchBox {
	margin: 0px;
}
/*    Following Changes are made by Laxman */
.advSearchWrapper{
	padding: 0px;
}
#searchToggleContainer{
	float: left;
}
#searchToggleContainer .sprite_iconSet{
	margin: 0px;
}
#searchToggleContainer .selectedSearch{
	border: 3px solid #bbbbbb;
	margin-top: -2px;
}
</style>
<div id="searchBox" class="searchBox">
<form action="<?php echo base_url()?>kols/search_kols" name="searchForm" method="post" class="searchForm" id="searchForm" onsubmit="return validateSearchForm();">
<?php	if(!isset($keyword)) $keyword = "Search Contacts";	?>
	<input type="hidden" name="category" value="people"> 
	<div id="searchboxholder" class="tooltip-demo tooltop-left searchboxholder">
			<div id="searchToggleContainer">
				<div class="activeButton">
				<div class="refineByKolImageInactive sprite_iconSet activeIcon selectedSearch tooltip-demo tooltop-bottom" onclick="setKolSearch(this);">
				</div>
				</div>
				<!--div>
				<div class="refineByOrgImage refineByOrgImageInactive sprite_iconSet activeIcon tooltip-demo tooltop-bottom" onclick="setOrgSearch(this);">
				</div>
				</div-->
				<input type="checkbox" id="searchCategory" onchange="toggleSearchCategory(this);" style="display: none;">
			</div>
			<div id="searchinputbox" class="searchinputbox">
				<div class="searchIcon"  onclick="validateSearchForm()"><a class="tooltipLink" rel='tooltip' title='Search Contact Name' href="#">&nbsp;</a></div>
				<!--<img id="searchicon" src="<?php echo base_url()?>images/firebugsearch.jpg" style="padding-top: 2px;" onclick="validateSearchForm()" />
				-->
				<input type="hidden" name="keywordSearchBy" id="searchByAutoComplete" value="0" />
				<input type="text" name="keyword" id="searchKeyword" class="autocompleteInputBox searchKeyword" value="<?php echo $keyword; ?>" style="margin: 0px 0 0;border:0;width: 270px;" />
				<input type="text" name="keyword" id="searchKeyword2" class="autocompleteInputBox searchKeyword" value="<?php echo $keyword; ?>" style="margin: 0px 0 0;border:0;width: 270px;display: none;" />
				<input type="hidden" name="kolIdTop" id="kolIdTop" value=''/>
				
			</div>
			<div class="advSearchWrapper">
				<div class="advSearchIcon sprite_iconSet tooltip-demo tooltop-left">
					<a class="tooltipLink" rel='tooltip' title='Advanced Search' id="advSearchLink" onclick="triggerAdvSearch(event,'<?php echo (isset($searchDockType)?$searchDockType:'headerDock')?>');return false;" href="#" >&nbsp;</a>
				</div>
			</div>
	</div>
</form>
</div>

