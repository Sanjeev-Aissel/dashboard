<?php

$queued_js_scripts = array('CalendarControl','highcharts2_2_2/highcharts3.0.5',

'highcharts2_2_2/modules/exporting3.0.5','jquery/jquery-ui-1.8.16.slider'

,'jquery/jquery-ui-1.8.16.datepicket','jquery/date','jquery.validate','i18n/grid.locale-en',

							'jquery.jqGrid.min','jquery/daterangepicker.jQuery','chosen.jquery');

	// add the JS files into queue i.e Append to the existing queue

	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));

	$autoSearchOptions = "width: 160, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {displaySelectedChart(true);}";

?>

<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />

<style type="text/css">

		div.toggleBtnWrapper{

			text-align:right;	

			margin-right: 9px;

		}

		  /* Enable Verticle separator between content and side menu list  By Laxman   */

		#contentWrapper.span-23 {

			background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");

		    background-position: 135px 50%;

		    background-repeat: repeat-y;

		}

		.ui-tabs-vertical .ui-widget-content{

			margin-left:0px;

		}

		#orgIntaerctionContainer{

			

		}

		

		#orgIntarcationTable  tr td{

			border:0px solid red;	

		}

		.about{

			padding-bottom:5px;

			margin:0;

			

		}

		

		.alignTop{

			vertical-align:top;	

			text-align: center;	

		}

		

		#orgIntarcationTable tr{

			border:1px solid gray;

		

		}

		

		.topicDetail{

		}

		.facetoFace,.facetoFace:hover{

	  		 background:#1B9ED1;

			 border: 1px solid #1285B2;

    	}

    	.phone,.phone:hover{

			background:#A0E04E;

			border: 1px solid #00A717;

    	}

    	.web,.web:hover{

			background:#ec8732;

			border: 1px solid #D84914;

    	}

    	

    	.orgIntarcationTable{

			    border-bottom: 1px solid #DDDDDD;

			    margin-bottom: 0;

			    padding: 10px 0;

		}

		.orgIntarcationTable:HOVER{

			    background-color: #D3DFED;

		}

		.space{

			margin-right: 28px;		

			font-weight: lighter;

		}

		.notes{

		 

		}

		th, td, caption {

    		padding: 4px 10px 0 0;

		}

		.toggleViewIcon {

			background: url("<?php echo base_url()?>/images/toggle_view.png") no-repeat scroll 0 0 rgba(0, 0, 0, 0);

	

		}

		.toggleGridIcon {

			background: url("<?php echo base_url()?>/images/toggle_view.png") no-repeat scroll -41px rgba(0, 0, 0, 0);

	

		}

		.togle{

			float:right;		

		}

		

		input[type="button"], input[type="submit"], input[type="reset"], button, a.blueButton{

			line-height: 15px;

			min-width: 90px;

		}

		

		div.actionIconsContainer{

			margin-left: 21px;

		}

		

		.bold{

			font-weight:bold;

		}

		.inline{

			display:inline;		

		}

		
		#container{
			min-height: 100px;
		}

</style>



<script>

	



</script>

	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url();?>css/StyleCalender.css" />

<link rel="stylesheet" href="<?php echo base_url();?>css/ui.daterangepicker.css" type="text/css" />

<script type="text/javascript">

var kolId = '<?php echo $kolId?>';

var chartsHeight = 400;

var viewType	= 'tabular';

var chartBackgroundColor = "transparent";

jqgridIds	= new Array('listInteractionsResultSet');

	$(document).ready(function(){



		

		

		// Settings for the Dialog Box

		var interactionAddEditDialogOpts = {

				title: "",

				modal: true,

				autoOpen: false,

				width: 800,

				dialogClass: "microView interactionAddModalContainer",

				position: ['center', 65],

				open: function() {

			$('.ui-datepicker-calendar').css('display','block !important');

				},

				close:function(){

					$('.ui-datepicker-calendar').css('display','none !important');

				}

		};

		

		$("#interactionEditContainer").dialog(interactionAddEditDialogOpts);

		

		$('#startDate, #endDate').daterangepicker();

		a= $('#kol-name').autocomplete(kolNameAutoCompleteOptions);



		$("#kol-name").blur(function(){

			if($(this).val() == '')

				$("#kol-id").val('');

		});



		$("#report").click(function(){

			$("#numericReportContainer").css("display","block");

			$("#pageChartContainer").css("display","none");

			generateNumericReport();

		});

		$("#chart").click(function(){

			$("#numericReportContainer").css("display","none");

			$("#pageChartContainer").css("display","block");

			generateChartReport();

		});



		$('.tabsWrapper ul.tabsContainer li').click(function (){

			var currentTab	= $(this).attr('name');

			$('.tabsWrapper ul.tabsContainer li').removeClass('current');

			$('.tabsWrapper .tabsContent div.tabContent').hide();

			$(this).addClass('current');

			$('.tabsWrapper .tabsContent div.'+currentTab).show();

		});

	});

	

	var kolNameAutoCompleteOptions = {

		serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_autocomplete',

		<?php echo $autoSearchOptions;?>,

		onSelect : function(event, ui) {

			var kolId = $(event).children('.id1').html();

			var selText = $(event).children('.kolName').html();

			selText=selText.replace(/\&amp;/g,'&');

			$('#kol-name').val(selText);

			$('#kol-id').val(kolId);

		}

	}





	function getProduct(proObject){

		$('#loadingProduct').show();

		$('#'+topicId+" option" ).remove();

		$('#'+topicId).append('<option value="">Select</option>');

		var typeId = $(proObject).val();

		var productId = 'product';

		var topicId = 'topic';



		$('#'+topicId+" option" ).remove();

		$('#'+topicId).append('<option value="">Select</option>');

		$('#'+productId+" option" ).remove();

		$('#'+productId).append('<option value="">Select</option>');

		$.ajax({

			url:'<?php echo base_url()?>/interactions/get_product_by_type/'+typeId,

			dataType:'json',

			success:function(returndata){

				// .each loops through the array

				$.each(returndata.arrProducts, function(key,value){

	  				  $('#'+productId).append($("<option></option>")

		                    .attr("value",key)

		                    .text(value));

			

				});

			},

			complete:function(){

				$('#loadingProduct').hide();

				}

		});

	}



	function getTopic(proObject){

		$('#loadingTopic').show();

		var productId = $(proObject).val();



		var groupId =  $('#grouping').val();

		var typeId = $("#objective").val();	

		var topicId = "topic";



		$('#'+topicId+" option" ).remove();

		$('#'+topicId).append('<option value="">Select</option>');

		$.ajax({

			url:'<?php echo base_url()?>/interactions/get_topic_by_type/'+typeId,

			dataType:'json',

			success:function(returndata){

				// .each loops through the array

				$.each(returndata.arrTopics, function(key,value){

				

		  				  $('#'+topicId).append($("<option></option>")

			                    .attr("value",key)

			                    .text(value));

			

				});

			},

			complete:function(){

				$('#loadingTopic').hide();

				}

		});

	}

	var interactionsByTopicData;

	var interactionsByChannelData;

	var interactionsByEmployeeData;

	var interactionsByMonthData;

	function generateChartReport() {

		

		$('#interactionsList').hide();

		if(!$("#interactionsFilterForm").validate().form()){

			return false;

		}else{

			$('label.error').remove();

			$('#chartTable').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});

			var data = {};

			var sd = $('#startDate').val();

			var sdSplits = sd.split("/");

			var ed = $('#endDate').val();

			var edSplits = ed.split("/");

			data['sd'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];

			data['ed'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];

			data['grouping'] = $('#grouping').val();

			data['mode'] = $('#mode').val();

			data['type'] = $('#objective').val();

			data['product'] = $('#product').val();

			data['topic'] = $('#topic').val();

			data['kol_id'] = $('#kol-id').val();

			data['user_id'] = $('#user-name').val();

/*

			$.ajax({

				url: base_url+'interactions/interactions_chart_report',

				dataType: 'json',

				data:data,

				type:'post',

				success: function(returnData) {

							var interByTopic 	= returnData.arrByTopic;

							var interByChannel 	= returnData.arrByChannel;

							var interByEmployee = returnData.arrByEmployee;

							var totalCount = 0;



							$.each(interByTopic,function(key, value){

								totalCount = totalCount + value[1];

							});

							interactionsByTopic(interByTopic,totalCount);

							interactionsByTopicData.redraw();

							totalCount = 0;

							$.each(interByChannel,function(key, value){

								totalCount = totalCount + value[1];

							});

							interactionsByChannel(interByChannel,totalCount);

							interactionsByChannelData.redraw();

							

							totalCount = 0;

							$.each(interByEmployee,function(key, value){

								totalCount = totalCount + value[1];

							});				

							interactionsByEmployee(interByEmployee,totalCount);

							interactionsByEmployeeData.redraw();

							

							interactionsByMonth(returnData.arrByMonth,returnData.arrMonths);

							interactionsByMonthData.redraw();

							

				}

			});

			*/



			$.ajax({

				url: base_url+'interactions/interactions_by_topic',

				dataType: 'json',

				data:data,

				type:'post',

				success: function(returnDataTopic) {

						var interByTopic 	= returnDataTopic.arrByTopic;

						var totalCount1 = 0;

						$.each(interByTopic,function(key, value){

							totalCount1 = totalCount1 + value[1];

						});

						interactionsByTopic(interByTopic,totalCount1);

						interactionsByTopicData.redraw();

				}

			});



			$.ajax({

				url: base_url+'interactions/interactions_by_channel',

				dataType: 'json',

				data:data,

				type:'post',

				success: function(returnDataChannel) {

						var interByChannel 	= returnDataChannel.arrByChannel;

						var totalCount2 = 0;

						$.each(interByChannel,function(key, value){

							totalCount2 = totalCount2 + value[1];

						});

						interactionsByChannel(interByChannel,totalCount2);

						interactionsByChannelData.redraw();

				}

			});



			$.ajax({

				url: base_url+'interactions/interactions_by_employee',

				dataType: 'json',

				data:data,

				type:'post',

				success: function(returnDataEmployee) {

						var interByEmployee = returnDataEmployee.arrByEmployee;

						var totalCount3 = 0;

						$.each(interByEmployee,function(key, value){

							totalCount3 = totalCount3 + value[1];

						});				

						interactionsByEmployee(interByEmployee,totalCount3);

						interactionsByEmployeeData.redraw();

				}

			});



			$.ajax({

				url: base_url+'interactions/interactions_by_month',

				dataType: 'json',

				data:data,

				type:'post',

				success: function(returnDataMonth) {

						interactionsByMonth(returnDataMonth.arrByMonth,returnDataMonth.arrMonths);

						interactionsByMonthData.redraw();

				}

			});

		}

		$("#chartTable").unblock();	

		return true;

	}







	

	

	

	function showView(){

		

		generateNumericReport();

	}

	function showGrid(){

		$('#hide').hide();

		$('#interactionsList').show();



		$('#gridContainer').html('<div id="listInteractionsPage"></div><table id="listInteractionsResultSet"></table>');

		$('#orgIntaerctionContainer').hide();

		$('#gridContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});



		var data = {};

		

		data['grouping'] = $('#grouping').val();

		data['mode'] = $('#mode').val();

		data['type'] = $('#objective').val();

		data['product'] = $('#product').val();

		data['topic'] = $('#topic').val();

		data['kol_id'] = kolId;

		data['user_id'] = $('#user-name').val();

		var sd = $('#startDate').val();



		if(sd!=''){

		var sdSplits = sd.split("/");

			data['sd'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];

		}



		var ed = $('#endDate').val();

		if(ed!=''){

			var edSplits = ed.split("/");

			data['ed'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];

		}

		

		var ele=document.getElementById('gridContainer');

		var gridWidth=ele.clientWidth;

	//	gridWidth+=10;

		jQuery("#listInteractionsResultSet").jqGrid({

			url:base_url+'interactions/list_interactions_by_date_range/',

			datatype: "json",

		   	colNames:['Id','','<?php echo lang("KOL");?> Name','Date','Recorded By','Interaction Type','Discussion Type',product,'Action',"<div class='tooltip-demo tooltop-bottom'><span rel='tooltip' title='Unsolicited Off\-Label Question'>UOQ</span></div>",''],

		   	colModel:[

				{name:'id',index:'id', hidden:true},

				{name:'micro',width:30, search:false,align:'center',sortable:false},

				{name:'kol_name',index:'kol_name',width:170, resizable:false},

				{name:'date',index:'date', width:70, resizable:false},

		   		{name:'recorded_by',index:'recorded_by',width:170, resizable:false},

		   		{name:'mode_name',index:'mode_name',width:100, resizable:false},

				{name:'objective_name',index:'objective_name',width:210, resizable:false},

		   		{name:'product_name',index:'product_name',width:150, resizable:false},

		   		{name:'act',width:40,align:'center',search:false},
		   		
		   		{name:'mirf',width:100,align:'center',search:false,sortable:false},

		   		{name:'eAllowed',index:'eAllowed', hidden:true},   		

		   	],

		   	postData:data,

		   	rowNum:10,

		   	rownumbers: true,

		   	autowidth: false, 

		   	loadonce:true,

		   	ignoreCase:true,

		   	hiddengrid:false,

		   	height: "auto",		 

		   	pager: '#listInteractionsPage',

		   	mtype: "POST",

		   	sortname: 'kol_name',

		    viewrecords: true,

		    sortorder: "desc",

		    shrinkToFit:true,

		    jsonReader: { repeatitems : false, id: "0" }, 

		    caption:"Interactions",

		    grouping: true, 

			groupingView : { 

				groupField : ['kol_name'], 

				groupColumnShow : [false], 

				groupText : ['<b>{0}</b>  ({1})'], 

				groupCollapse : false, 

				groupOrder: ['asc'], 

			//	groupSummary : [true], 

				groupDataSorted : true 

			},

			gridComplete: function(){

				

				//Get array of id'f from jqgrid			   

		    	var arrIds = jQuery("#listInteractionsResultSet").jqGrid('getDataIDs'); 

		    	// Loop trough each row(id) and prepare a microview, edit and delete links and update the perticular row

		    	for(var i=0;i < arrIds.length;i++){ 
		    		actionLink = '';
			    	var id = arrIds[i];		    	
			    	var rowData = jQuery("#listInteractionsResultSet").jqGrid('getRowData', id);
			    	//Edit and Delete labels 	
		    		//editDeleteLink = "<label onclick=\"editInteraction('"+id+"');\" ><img title='Edit' src='"+base_url+"images/edit.png' style='vertical-align:bottom'></label> |<label onclick=\"deleteInteraction('"+id+"');\" ><img title='Delete' src='"+base_url+"images/delete.png' style='vertical-align:bottom'></label>";
//		    		if(rowData.save_later == '1'){
//				    	editDeleteLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editInteraction('"+id+"'); return false;\"></div></div>";
//	
//			    		jQuery("#listInteractionsResultSet").jqGrid('setRowData',arrIds[i],{act:editDeleteLink});
//		    		}
                                var actionLink;
                                        if((rowData.eAllowed == 'true')){
					    	  actionLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editInteraction('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\">&nbsp;</a></div>";
					}
                                        if((rowData.dAllowed == 'true')){
//					    	 actionLink += "<div class='actionIcon deleteIcon' onclick=\"deleteInteraction('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></div>";
                                        } 
			    	jQuery("#listInteractionsResultSet").jqGrid('setRowData',arrIds[i],{act:actionLink});
		    		

		    		//Microview label	

			    	//microviewLink = "<label onclick=\"viewInteractionMicroProfile('"+id+"');\" ><img class='micro_view_icon'  title='MicroView' src='"+base_url+"images/user3.png'></label>";

		    		microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewInteractionMicroProfile('"+id+"'); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"View Interaction\">&nbsp;</a></div></label>";

			    	jQuery("#listInteractionsResultSet").jqGrid('setRowData',arrIds[i],{micro:microviewLink}); 

			    	} 

		    	jQuery("#listInteractionsResultSet").jqGrid('navGrid','hideCol',"id");

		    	//Initialize the tooltips

		    	initializeCustomToolTips();

		    	$('#gridContainer').unblock();

		    	//if(preloadAddInteractionData){

		    	//	$("#addInteractionContainer").load(base_url+'interactions/add_interaction');

		    		//preloadAddInteractionData	= false;

		    	//}

		    },

	   		rowList:[10,50,150]

		});



		//Hide the column recorded by if the logged in user role is not manager

	   	var userRole=userRoleId;

	   	var managerRoleId=ROLE_MANAGER;
	   	var adminRoleId=ROLE_ADMIN;

	   	

	   	if(userRole!=managerRoleId || userRole!=adminRoleId)	 

	   		jQuery("#listInteractionsResultSet").hideCol("recorded_by"); 

			

		jQuery("#listInteractionsResultSet").jqGrid('navGrid','#listInteractionsPage',{edit:false,add:false,del:false,search:false,refresh:false});



		//Toolbar search bar below the Table Headers

		jQuery("#listInteractionsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		

		

		//Toggle Toolbar Search 

		jQuery("#listInteractionsResultSet").jqGrid('navButtonAdd',"#listInteractionsPage",{

			caption:"Search",title:"Toggle Search",

			onClickButton:function(){ 			

				if(jQuery(".ui-search-toolbar").css("display")=="none") {

					jQuery(".ui-search-toolbar").css("display","");

				} else {

					jQuery(".ui-search-toolbar").css("display","none");

				}							

			} 

		}); 

		jQuery("#listInteractionsResultSet").jqGrid('setGridWidth',gridWidth); 

	}



	

	function generateReport(){

		

		if($('#orgIntaerctionContainer').css('display')=='block'){

			//$("#report").trigger("click");

			generateNumericReport();

			}else{

				showGrid();

			}

		}



	function generateNumericReport(){



		$('#orgIntaerctionContainer').show();

		$('#interactionsList').hide();

		

		

			$('label.error').remove();

			$('#orgIntaerctionContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});

			var data = {};

			

			var sd = $('#startDate').val();

			if(sd!=''){

					var sdSplits = sd.split("/");

					data['sd'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];

			}



			var ed = $('#endDate').val();

			if(ed!=''){

				var edSplits = ed.split("/");

				data['ed'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];

			}

			data['grouping'] = $('#grouping').val();

			data['mode'] = $('#mode').val();

			data['type'] = $('#objective').val();

			data['product'] = $('#product').val();

			data['topic'] = $('#topic').val();

			data['subtopic'] = $('#subtopic').val();

			data['kol_id'] =kolId;

			data['user_id'] = $('#user-name').val();

			data['startFrom'] = 0;

			

			$.ajax({

				url: base_url+'kols/view_interactions/'+kolId,

				dataType: 'text',

				data:data,

				type:'post',

				success: function(returnData) {

					

					if(returnData==' '){

							alert("No Interactions found");

						}

					$("#orgIntaerctionContainer").html(returnData);

					$('#orgIntaerctionContainer').unblock();

				}

			});

			return true;



			

	}



	function editInteraction(interactionId){

		$("#block").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'50%',cursor:'default'}});

			$('#addEditInteractionWrapper').show();

			$('#interactionsContainer').hide();

		//	$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");

		//	$("#interactionEditContainer").dialog("open");

		//	$("#interactinEditProfileContent").load(base_url+'interactions/edit_interaction/'+interactionId);

		//	$('#interactionsContainer').hide();

			$('#addInteractionContainer').html('');

			$("#editInteractionContainer").html('').show();

			

			$("#editInteractionContainer").load(base_url+'organizations/edit_org_interaction/'+interactionId);

			

			return false;	

		}

		function deleteInteraction(interactionId){

			var	formAction = base_url+'interactions/delete_interaction/'+interactionId;

			jQuery("#listInteractionsResultSet").jqGrid('delGridRow',interactionId,{url:formAction,afterSubmit:function(serverResponse, postdata){

				showGrid();

					$(".ui-icon-closethick").trigger('click');

			}});

			

			//$("#delmodlistInteractionsResultSet").addClass("gridConfirmFormCenterAlign");

			$("#delmodlistInteractionsResultSet").center();

		}





		

		function deleteListViewInteraction(interactionId,event){

			

			 event.stopPropagation();

			// Do something

			jConfirm('Are you sure you want to remove selected KOLs from the list?', 'Please Confirm', function(t) {

				

				if(t){

					$.ajax({

					url: base_url+'interactions/delete_interaction/'+interactionId,

					

					type:'post',

					success: function(returnData) {

						$('#orgIntarcationTable_'+interactionId).remove();

					}

				});

					}

			});

			

			

		}

		function expand(id,thisEle){

			

			if($(thisEle).attr('class')=='expand'){

				

				$(thisEle).removeClass('expand');

				$(thisEle).addClass('collapse');

				$('#expand_'+id).show();

					

				$.each($('#interactionid_'+id).find('tr.hide'),function(){

										$(this).css('display','table-row');

				});

			}else{

				

				$(thisEle).removeClass('collapse');

				$(thisEle).addClass('expand');

				$('#expand_'+id).hide();

				$.each($('#interactionid_'+id).find('tr.hide'),function(){

					$(this).hide();

				});

			}



		}



		function changeView(thisEle){

			$('.tooltip.in').hide();

	  		if(viewType=='list'){

	  			viewType	= 'tabular';

	  			$('#toggleViewIcon').removeClass('listView');

	  			generateNumericReport();

	  		}else{

	  			viewType	= 'list';

	  			$('#toggleViewIcon').addClass('listView');

	  			showGrid();

	  		}

		}



		function test(event){

			 event.stopPropagation();



		}



		$(document).ready(function() {

		    //var eventsElement = $('#resultListView');

			$(window).scroll(function(){

				

		        if  ($(window).scrollTop() == $(document).height() - $(window).height() || $(window).scrollTop() == $(document).height() - $(window).height()-1){

		        	//generateLazyLoadReport();

		        }

			}); 



		});

		var isRequest=false;

		function generateLazyLoadReport(){

			$('div#lastPostsLoader').show();

			 if(!(isRequest)){

				 isRequest=true;

				$('label.error').remove();

				//$('#orgIntaerctionContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});

				var data = {};

				var sd = $('#startDate').val();

				if(sd!=''){

						var sdSplits = sd.split("/");

						data['sd'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];

				}



				var ed = $('#endDate').val();

				if(ed!=''){

					var edSplits = ed.split("/");

					data['ed'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];

				}

			

				//data['sd'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];

				//data['ed'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];

				data['grouping'] = $('#grouping').val();

				data['mode'] = $('#mode').val();

				data['type'] = $('#objective').val();

				data['product'] = $('#product').val();

				data['topic'] = $('#topic').val();

				data['kol_id'] = $('#kol-id').val();

				data['user_id'] = $('#user-name').val();

				data['startFrom'] = $('.expand:last').attr('id');

				data['interaction_ids'] =  $('#ids').val();

				

				$.ajax({

					url: base_url+'kols/view_interactions/'+kolId,

					dataType: 'text',

					data:data,

					type:'post',

					success: function(returnData) {

						if(returnData==' '){

								alert("No Interactions found");

							}

						$("#orgIntaerctionContainer").append(returnData);

					//	$('#orgIntaerctionContainer').unblock();

						isRequest=false;

						$('div#lastPostsLoader').hide();

					}

				});

				return true;

			 }

				

		}



		function addInteraction(){

			//	$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");

			//	$("#interactionAddContainer").dialog("open");

			//	$("#interactinAddProfileContent").load(base_url+'interactions/add_interaction/'+kolId);

				$('#interactionsContainer').hide();

				$("#addInteractionContainer").show();

				if($("#addInteractionContainer").html()==''){

					$("#editInteractionContainer").html('');

					//$("#addInteractionContainer").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
					$("#container").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
					$("#addInteractionContainer").load(base_url+'interactions/add_interaction/'+kolId,function( response, status, xhr ) {
						$("#container").unblock();
					});

				}

				return false;	

			}

			function cancelAddInteraction(){

				$('#addInteractionContainer').hide();

				$('#editInteractionContainer').hide();

				$("#interactionsContainer").show();

				$("#editInteractionContainer").html('');

				var interactionContainer	= $("#listInteractionsResultSet").html();

				if(interactionContainer==''){

					listInteractions();

				}

			}

			/**

			* Opens the Modal Box with the Form to Edit ineraction details

			* @author 

			* @since

			* @param: kolId

			*/

			function editInteraction(interactionId){

			//	$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");

			//	$("#interactionEditContainer").dialog("open");

			//	$("#interactinEditProfileContent").load(base_url+'interactions/edit_interaction/'+interactionId+'/'+kolId);

				$('#interactionsContainer').hide();

				$('#addInteractionContainer').html('');

				$("#editInteractionContainer").html('').show();

				$("#container").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});

				//$("#editInteractionContainer").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'50%',cursor:'default'}});

				$("#editInteractionContainer").load(base_url+'interactions/edit_interaction/'+interactionId+'/'+kolId,function( response, status, xhr ) {
					$("#container").unblock();
				});

				return false;	

			}



			function export_excel(){



				

				var excelFilters = '';



				var sd = $('#startDate').val();



				if(sd != ''){

					var sdSplits = sd.split("/");

					var from_month_year = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];

					excelFilters += "Start Month : "+from_month_year+",";

				}



				var ed = $('#endDate').val();

				if(ed != ''){

					

					var edSplits = ed.split("/");

					var to_month_year = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];

					excelFilters += "End Month : "+to_month_year+",";

				}

			

					$(".gridWrapper .ui-jqgrid tr.ui-search-toolbar th input").each(function(){

						if($(this).val() != ''){

							var filterName = $(this).attr('name');

							var filterValue = $(this).val();

							excelFilters += filterName+" : "+filterValue+",";

						}

					});

					//$("#excel-filters").val(excelFilters);

					var selectedOPtion = $(".ui-pg-selbox").val();

					$(".ui-pg-selbox option:last").attr('selected','selected');

			    	$('.ui-pg-selbox').trigger('change');

			    	if($("#listInteractionsResultSet").html() != null )

			    		var arrIds = jQuery("#listInteractionsResultSet").jqGrid('getDataIDs');

			    	else

			    		var arrIds = jQuery("#listPaymentsResultSet").jqGrid('getDataIDs');

			    if($('#orgIntaerctionContainer').css('display')!='block'){

		    	

		    		$('#ids').val(arrIds);

		    	}



		    	

		    	

		    	var kol_name = $('#kol-name').val();

		    	if(kol_name !=''){

		    		var filterName = "Kol Name";

		    		excelFilters += filterName+" : "+kol_name+",";

			    //	$('#kolNameExport').val(kol_name );



		    	}

		    	var grouping = $('#grouping').val();

		    	

		    	if(grouping !=''){

		    		var filterName = "Interaction Category";

		    		excelFilters += filterName+" : "+$('#grouping option:selected').text()+",";



		    	}

		    	var mode = $('#mode').val();



		    	if(mode !=''){

		    		var filterName = "Interaction Mode";

		    		excelFilters += filterName+" : "+$('#mode option:selected').text()+",";



		    	}

		    	var userName = $('#user-name').val();



		    	if(userName !=''){

		    		var filterName = "Employee Name";

		    		excelFilters += filterName+" : "+$('#user-name option:selected').text()+",";



		    	}

		    	var type = $('#objective').val();



		    	if(type !=''){

		    		var filterName = "type";

		    		excelFilters += filterName+" : "+$('#objective option:selected').text()+",";

			    	

			    //	$('#typeExport').val($('#objective option:selected').text());



		    	}

		    	var product = $('#product').val();



		    	if(product !=''){

		    		var filterName = "Product";

		    		excelFilters += filterName+" : "+$('#produce option:selected').text()+",";

		    	}

		    	var topic = $('#topic').val();



		    	if(topic!=''){

		    		var filterName = "Topic";

		    		excelFilters += filterName+" : "+$('#tpoic option:selected').text()+",";



		    	}

		    	$("#excel-filters").val(excelFilters);

		    //	return false;

		    	$('#export').submit();

		    	$(".ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');

		    	$('.ui-pg-selbox').trigger('change');

			}



			function viewInteractionMicroProfile(interactionId){

				

				$('#interactionsContainer').hide();

				$("#viewInteractionContainer").show();

				$("#viewInteractionContainer").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});

				$("#viewInteractionContainer").load(base_url+'interactions/view_micro_interaction/'+interactionId);

			}	



			function showIntarctionTable(){

				$('#interactionsContainer').show();

				$('#viewInteractionContainer').hide();

			}



			function showAction(id){

				

				$('#show_'+id).show();

			}



			function hideAction(id){

				

				$('#show_'+id).hide();

			}

		function resetDropDowns(proObject){
			var topicId = $(proObject).parent().parent().parent().find('td').eq(2).find('select').attr('id');
			var subTopicId	= $(proObject).parent().parent().parent().find('td').eq(3).find('select').attr('id');
			$('#'+topicId+" option" ).remove();
			$('#'+topicId).append('<option value="">Select</option>');
			$('#subtopic option' ).remove();
			$('#subtopic').append('<option value="">Select</option>');
		}

		function getSubTopic(proObject){
			var productId = $(proObject).parent().parent().parent().find('td').eq(0).find('select').val();
			var typeId = $(proObject).parent().parent().parent().find('td').eq(1).find('select').val();
			var topicId =  $(proObject).val();
			$.ajax({
				url:'<?php echo base_url()?>/interactions/get_sub_topics/'+productId+'/'+typeId+'/'+topicId,
				dataType:'json',
				success:function(returndata){
				
					$('#subtopic option').remove();
					$('#subtopic').append('<option value="">Select</option>');
					// .each loops through the array
					$.each(returndata.arrSubTopics, function(key,value){
					
			  				  $('#subtopic').append($("<option></option>")
				                    .attr("value",key)
				                    .text(value));
				
					});
				},
				complete:function(){
				//	$('#loadingTopic').hide();
					}
			});
		}
			
		$(document).ready(function(){
				var dd = "<?php echo $this->uri->segment(5); ?>";
				if(dd){
					addInteraction();
				}else{
					$("#interactionsContainer").css("display","block");
				}
			});			

</script>

<style>

	#contentWrapper.span-23 {

		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");

	    background-position: 135px 50%;

	    background-repeat: repeat-y;

	}

/*	#interactionsContainer{

		width: 805px;

		margin-top: -75px;

		margin-top: 0px;

		float: right;

	}

*/

	#filtersContainer{

		height: 142px;

		border-bottom: 1px solid #DDDDDD;

	}

	#numericReportContainer{

		min-height:500px;

	}

	#numericReportContainer > label{

		display:block;

		background-color: #D4EAAC;

		text-align:left;

		height: 25px;

   		padding-top: 5px;

   		padding-left: 6px;

	}

	#numericReportContainer table{

		border:1px solid #eeeeee;

	}

	#numericReportContainer table th{

		background-color: #E5E5E5;

		border-left:2px solid #eeeeee;

		border-bottom:1px solid #eeeeee;

		color:black;

		width:70px;

	}

	#numericReportContainer table td{

		border-left:2px solid #eeeeee;

		border-bottom:1px solid #eeeeee;

		text-align:center;

	}

	#numericReportContainer table a{

		color:#76A2CF;

		font-weight:bold;

		text-decoration: none;

	}

	.reportLabels{

		width:150px;

		text-align:left !important;

		color: black;

	}

	.lastColumn td{

		text-align:left !important;

		border-left:0px !important;

	}

	.ui-jqgrid-titlebar{

		background: url("../images/kolm-sprite-image.png") repeat-x scroll 2px -237px transparent;

	    border-bottom: 0 none;

	    color: #111111;

	    height: 23px;

	    letter-spacing: 1px;

	    padding-top: 5px;

	    vertical-align: middle;

    }

    tr.even td{

    	background-color: #F4F4F4 !important;

    }

     #interactionsFilterForm label{

     	display: inline-table;

	    text-align: right;

	    width: 118px;

     }

    #interactionsFilterForm p{

    	float: left;

   	 	margin: 0;

    }

    p#submitButton{

    	text-align: center;

    	width: 100%;

    }

    label.error {

	    display: inline !important;

	    font-weight: normal;

	    margin-left: 103px;

	}

	#lastSelect{

		width:auto !important;

	}

	#lastSelect label{

		

	}

	#interactionsFilterForm select{

		width:139px;

	}

	#interactionsFilterForm input[type="text"]{

		width:131px;;

	}

	input.error{

		padding:0px;

	}

	.top{

		margin-right:20px !important;

	}

	 .ui-daterangepicker li{

    	text-align: left;

    }

	.ui-daterangepicker ul{

		width: 175px !important;

	}

	.ui-daterangepicker button.btnDone{

		font-size: 12px !important;

		color:#FFF !important;

		padding-bottom: 22px;

		background: -moz-linear-gradient(center top , #5689DB 0%, #4D7BD6 100%) repeat scroll 0 0 transparent !important;

	    background: -webkit-gradient(linear,left top,left bottom,color-stop(0%,#5689DB),color-stop(100%,#4D7BD6)) !important;

		background: -webkit-linear-gradient(top,#5689DB 0%,#4D7BD6 100%) !important;

		background: -o-linear-gradient(top,#5689DB 0%,#4D7BD6 100%) !important;

		background: -ms-linear-gradient(top,#5689DB 0%,#4D7BD6 100%) !important;

		filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#5689db,endColorstr=#4d7bd6,GradientType=0) !important;

		background: linear-gradient(top,#5689DB 0%,#4D7BD6 100%) !important;

	}

	

	#reportTypeTabs{

		padding-left: 20px;

		border-bottom: 1px solid #ECECEC;

    	padding-left: 20px;

	}

	#reportTypeTabs a{

		background: none repeat scroll 0 0 #ECECEC;

	    border: 1px solid #D0CCC9;

	    padding: 0 15px;

	    text-decoration: none;

	}

	#pageChartContainer td:nth-child(2n+1){

		border-right: 1px solid #eee;

	}

	#pageChartContainer td.chartHeaders{

		text-align: center;

		background-color: #eee;

		font-weight: bold;

	}

	.eachChart{

		width: 380px; 

		height: 400px;

	}

/*	

	#interactionsContainer, #addEditInteractionWrapper {

    float: right;

    margin-top: 3px;

    width: 805px;

	}

*/

	.togle a{

		display:block;	

	}

	

	.orgGridContainer{

	 margin-top: 21px;

	}

	.orgIntarcationTable .collapseSlider{

		background-color: #E6E6E6;

	}

	p{

		margin: 0;

	}

	#toggleView{

		float: right;

	    margin-top: -10px;

	    width: 37px;

	}

	#toggleViewIcon{

		padding-bottom: 3px;

	}

	

	.expand:hover,.collapse:hover{

		cursor:pointer;	

	}

	

	div#lastPostsLoader{

		background: none repeat scroll 0 0 #EEEEEE;

		text-align: center;	

	}

	

	.table tr td{

		border:0px solid gray;	

		margin:0;

		padding:1px;

	}

	

	.topicTable{

		margin:0	

	}

	

	.loadMore{

		background: none repeat scroll 0 0 #EBEBEB;

	    height: 24px;	

	}

	

	.load{

		left: 369px;

	    margin-top: -22px;

	    position: relative;

	    text-decoration: none;

	    top: 3px;	

	    color: #0084B4;	

	}

	#hide:hover{

		text-decoration:underline;

		cursor:pointer;

		color: #0084B4;	

		

	}

</style>

<div id="container">

<div id="block">

	 <div class="exportOptionsContainer">

		<ul class="pageRightOptions">

									

			<li>

				<label class="link" onclick="addInteraction();" id="addButton"><div class="actionIcon addIcon"></div>Add Interaction</label>

			</li>

			<li>

				<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="export_excel();" style="float:right">

					<a href="#" rel="tooltip" data-original-title="Export Interaction Detail into Excel format">&nbsp;</a>

				</div>

			</li>

		</ul>

	</div>

</div>							

<div id="addEditInteractionWrapper" class="clear" style="min-height 400px;">

		<div id="addInteractionContainer"></div>

		<div id="editInteractionContainer"></div>

		<div id="viewInteractionContainer"></div>

	</div>

	

<div id="interactionsContainer" class="clear">

	<form action="<?php echo base_url()?>interactions/export_interaction_details/<?php echo $arrKol['id']?>" method='post' id="export">

			<input type="hidden" id="ids" name="interaction_ids" value="<?php echo $interactionIds;?>"></input>

			<input type="hidden" name="filters" id="excel-filters" />

			<input type="hidden" name="monthlyfrom_export"  id="monthlyfromExport"/>

			<input type="hidden" name="monthto_export" id="monthlyToExport"/>

			<input type="hidden" name="kol_name_export" id="kolNameExport"/>

			<input type="hidden" name="category_export" id="categoryExport"/>

			<input type="hidden" name="mode_export" id="modeExport"/>

			<input type="hidden" name="user_name_export" id="userNameExport" />

			<input type="hidden" name="type_export" id="typeExport"/>

			<input type="hidden" name="product_export" id="productExport"/>

			<input type="hidden" name="topic_export" id="topicExport" />

		</form>

	<div id="filtersContainer">

		<form action="" name="interactionsFilterForm" id="interactionsFilterForm">

			<table class="table">

				<tr>

					<td>

						<p>

						<label for=monthlyreport>Time frame:</label>

							<input type="text" name="start_date" id="startDate" >

						</p>

					</td>

					<td>

						<p>

							

							<label for=monthlyreport>To:</label>

							<input type="text" name="end_date" id="endDate" />

						</p>

					</td>

					<td>

					<p>

						<label for="kol-name">KTL Name:</label>

						<input type="text" name="kol_name" id="kol-name" class="autocompleteInputBox" <?php echo (isset($arrKolInfo))?'value="'.$arrKolInfo['kol_name'].'" readonly="readonly"':'';?>"/>

						<input type="hidden" name="kol_id" id="kol-id" value="<?php echo (isset($arrKolInfo))?$arrKolInfo['kol_id']:'';?>" ></input>

					</p>

					</td>

				</tr>

				<tr>

					<td>

						<p>

							<label for="grouping">Interaction Category:</label>

							<select name="grouping"  id="grouping">

								<option value="">Select</option>			

								<?php foreach($arrGroupings as $row){?>

									<option value="<?php echo $row['id'];?>">

										<?php echo $row['name'];?>

									</option>

								<?php }?>

							</select>

						</p>

					</td>

					<td>

						<p>

							<label for=mode>Interaction Type:</label>

							<select name="mode"  id="mode">

								<option value="">Select</option>

								<?php foreach($arrModes as $mode){?>

									<option value="<?php echo $mode['id'];?>">

										<?php echo $mode['name'];?>

									</option>

								<?php }?>

							</select>

						</p>

					</td>

					<td>

						<p>

							<label for="user-name">Employee Name:</label>

							<select name="user_name"  id="user-name">

									<option value="">Select</option>	

								<?php foreach($arrUsers as $key=>$user){?>

									<option value="<?php echo $key;?>">

										<?php echo $user;?>

									</option>

								<?php }?>

							</select>

						</p>

					</td>

				</tr>

				<tr>
				
					<td>

						<p>

							<label for="product"><?php echo lang("Overview.Product");?>:</label>

							<select name="product"  id="product" onchange="resetDropDowns(this)">

									<option value="">Select</option>	

								<?php foreach($arrProduct as $product){?>

									<option value="<?php echo $product['id'];?>">

										<?php echo $product['name'];?>

									</option>

								<?php }?>

							</select>

						</p>

					</td>
					

					<td>

						<p>

							<label for="objective">Discussion Type:</label>

							<select name="objective"  id="objective" onchange="getTopic(this)">

								<option value="">Select</option>	

								<?php foreach($arrType as $row){?>

									<option value="<?php echo $row['id'];?>">

										<?php echo $row['name'];?>

									</option>

								<?php }?>

							</select>

						</p>

					</td>


					<td>

						<p id="lastSelect">

							<label for="topic">Topic:</label>

							<select name="topic"  id="topic" onchange="getSubTopic(this)">

									<option value="">Select</option>	

								<?php foreach($topics['topics'] as $key=>$value){?>

									<option value="<?php echo $key;?>" >

										<?php echo $value;?>

									</option>

								<?php }?>

							</select>

						</p>

						

					</td>

				

				</tr>
				
				<tr>
					<td class="alignCenter">
						<p id="lastSelect">
							<label for="topic">Sub Topic:</label>
							
							<select name="subtopic"  id="subtopic" >
								<option value="">Select</option>
							</select>
							<img id="loadingTopic" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
						</p>
					</td>
				</tr>

			

			</table>

			

			<p id="submitButton">

				<input type="button" value="Create Report" onclick="generateReport();"/>

			</p>

		</form>

	</div>

	

		<div id="toggleView" class="tooltip-demo tooltop-left">

			<div id="toggleViewIcon"><a class="list" rel='tooltip' title="Change View" href="#" onclick="changeView(this);return false;">&nbsp;</a></div>

		</div>



<div id="orgIntaerctionContainer" class="clear" style="display:block">





<?php 	$this->load->view('interactions/show_kol_interaction_details');?>





</div>

<?php if($count>10){?>

<div class="loadMore" id="hide" onclick="generateLazyLoadReport();return false">

<a class="load"  style="text-decoration:none" >Show More</a>

</div>

<?php }?>

		

<div id="lastPostsLoader" style="display: none;">

<img src="<?php echo base_url();?>images/ajax-loader-round.gif">

</div>



<div class="orgGridContainer">

		<div id="interactionsList">

			<div class="gridWrapper" id="gridContainer">

				<div id="listInteractionsPage"></div>

				<table id="listInteractionsResultSet"></table>

			</div>

			<!-- Container for the 'Interaction Micro Profile' modal box -->

			<div id="dailog1">	

				<div id="interactionMicroProfile" class="microProfileDialogBox">

					<div class="profileContent"></div>

				</div>

			</div>

			<!--End of  Container for the 'Interaction Micro Profile' modal box -->

			<!-- Container for the 'Interaction Add' modal box -->

			<div id="dailog2">	

				<div id="interactionAddContainer" class="microProfileDialogBox">

					<div class="profileContent" id="interactionAddProfileContent"></div>

				</div>

			</div>

			<!--End of  Container for the 'Interaction Addd' modal box -->

			<!-- Container for the 'Interaction Micro Edit' modal box -->

			<div id="dailog3">	

				<div id="interactionEditContainer" class="microProfileDialogBox">

					<div class="profileContent" id="interactinEditProfileContent"></div>

				</div>

			</div>

			<!--End of  Container for the 'Interaction Edit' modal box -->

		</div>

		

		<!-- Container for the 'Micro Profile'  box -->

		<div id="contentHolder" class="callOutTest microView" style="display: none;">

			<div>

				<a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeKolProfile();" class="ui-icon ui-icon-closethick">close</span></a>

				<!--<img class="ui-icon ui-icon-closethick" alt="" src="" onclick="closeKolProfile();" />

			--></div>

			<div class="profileContent"></div>

		</div>

		<div id="arraouHolder" class="callOutTest" style="display: none;"><div class="arrowMarkIcon"></div></div>

	</div>

</div>

</div>