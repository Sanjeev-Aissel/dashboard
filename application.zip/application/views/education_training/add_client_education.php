<?php
/**
 * File to 'add' Education details for client view
 *
 * @author: Ambarish
 * @created on: 02-May-11
 * @package application.views.eduaction_training
 */

	$autoSearchOptions = "width: 255, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
?>

<!--  Autocomplete Plugin -->
<!--<script type="text/javascript" src="<?php echo base_url()?>js/jquery.autocomplete.js"></script>
--><style type="text/css">
	
</style>

	<script type="text/javascript">
		// To activate the Horizontal Tabs
		$(function() {
			$( "#eduHorizontalTabs" ).tabs({
			//	selected:0,
				ajaxOptions: {
					error: function( xhr, status, index, anchor ) {
						$( anchor.hash ).html(
							"Couldn't load this tab. We'll try to fix this as soon as possible. " +
							"If this wouldn't be a demo." );
					}
				},
				spinner: 'Loading the data....',
				select: function(event, ui){ 
					//jAlert(ui.toSource());
					//jAlert("Selected Index is" + $("#tabs").tabs("option", "selected"));
					if(ui.index != 0){
						$("#pageLoader").show();
					}
				},
				load: function(event, ui){$("#pageLoader").hide();}
			});
		});

		/*
		*
		* To check start Date is > endDate.. if its true it shows an error
		* @author Ambarish
		* @since 2.2 
		*/
		function validate(endDate,id,buttonId){
			var startDate = $("#"+id+"StartDate").val();
			var endDate   = endDate;
			if(endDate!=''){	
				if(startDate > endDate){
					$("#"+id+"Date").show();
					disableButton(buttonId);
				}else{
					enableButton(buttonId);
					$("#"+id+"Date").hide();
				}
		}
		}
	
		var options, a;
	
		// Autocomplet Options for the 'Institute Name' field of type 'Education'
		// Autocomplet Options for the 'Institute Name' field searches From the lookuptable
	  	var eduInstituteNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_institute_names', <?php echo $autoSearchOptions; ?>,
				onSelect : function(event, ui) {
					var selText = $(event).children('.educations').html();
					var selId = $(event).children('.educations').attr('name');
					selText=selText.replace(/\&amp;/g,'&');
					$('#eduInstituteName').val(selText);
					$('#trainInstituteName').val(selText);
					$('#boardInstituteName').val(selText);
					$('#eduInstituteId').val(selId);
					$('#institute_id').val(selId);
					if(event.length>20){
						if(event.substring(0,21)=="No results found for "){
							$('#eduInstituteName').val('');
							$('#trainInstituteName').val('');
							$('#boardInstituteName').val('');
							return false;
						}
					}
				}
			};

		// Autocomplet Options for   'Training'
		// Autocomplet Options for the 'Degree Name' field of type 'Training'
	  	var trainDegreeAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_education_degrees/training',<?php echo $autoSearchOptions; ?>
			};

		// Autocomplet Options for the 'Specialty Name' field of type 'Training'
	  	var trainSpecialtyAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_education_specialtys/training',<?php echo $autoSearchOptions; ?>
			};			

		// Autocomplet Options for  'Board Certifications'
		// Autocomplet Options for the 'Specialty Name' field of type 'Board Certification'
	  	var boardSpecialtyAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_education_specialtys/board_certification',<?php echo $autoSearchOptions; ?>
			};		

		var validationRules	=  {
			institute_name: {
				required:true
			},
			start_date: {
				fullYear: true
			},
			end_date: {
				fullYear: true
			},
			eduUrl1: {
				url: true
			},
			eduUrl2: {
				url: true
			}
		};

		var validationMessages = {
			institute_name: {
				required: "This field is required.",
				instituteName: "",
				remote: ""
			},
			start_date: "Only full year is allowed. Ex: 2010",
			end_date: "Only full year is allowed. Ex: 2010",
			url: "Please enter a valid URL address"
		};

		function disableButton(buttonId){
			$("#"+buttonId).attr("disabled", "disabled");
		}

		function enableButton(buttonId){
			$("#"+buttonId).removeAttr("disabled");
		}	

		$(document).ready(function(){

			//Remove all the 'AutoCompleteContainer' divs' created automatically. If not, too many will get created
			$('div[id^="AutocompleteContainter_"]').remove();
			
			// Trigger the Autocompleter for 'Institute Name' field of type 'Education'
	    	a = $('#eduInstituteName').autocomplete(eduInstituteNameAutoCompleteOptions);
	    	
			// Trigger the Autocompleter for 'Institute Name' field of type 'Education'
	    	// Trigger the Autocompleter for 'Institute Name' field searches From the lookuptable
	    	a = $('#trainInstituteName').autocomplete(eduInstituteNameAutoCompleteOptions);

			// Trigger the Autocompleter for 'Degree Name' field of type 'Training'
	    	a = $('#trainDegree').autocomplete(trainDegreeAutoCompleteOptions);

			// Trigger the Autocompleter for 'Degree Name' field of type 'Training'
	    	a = $('#trainSpecialty').autocomplete(trainSpecialtyAutoCompleteOptions);

			// Trigger the Autocompleter for 'Institute Name' field of type 'Board Certification'
	    	// Trigger the Autocompleter for 'Institute Name' field searches From the lookuptable
	    	a = $('#boardInstituteName').autocomplete(eduInstituteNameAutoCompleteOptions);

			// Trigger the Autocompleter for 'Degree Name' field of type 'Board Certification'
	    	a = $('#boardSpecialty').autocomplete(boardSpecialtyAutoCompleteOptions);	

	/*		// validate signup form on keyup and submit
			$("#educationForm").validate({
				debug:true,
				onkeyup:true,
				rules: validationRules,
				messages: validationMessages
			});

			$("#trainingForm").validate({
				onkeyup:true,
				rules: validationRules,
				messages: validationMessages
			});

			$("#boardForm").validate({
				onkeyup:true,
				rules: validationRules,
				messages: validationMessages
			});

			$("#awardForm").validate({
				onkeyup:true,
				rules: validationRules,
				messages: validationMessages
			});
			*/
			$("#trainingType").change(function(){
		        $(this).find("option:selected").each(function(){
		            var optionValue = $(this).attr("value");
		            if(optionValue == 'board_certification'){
		                $(".trainingDegree").hide();
		            } else{
		            	$(".trainingDegree").show();
		            }
		        });
		    }).change();
					
		});

		/**
		* Save the 'Education Details'
		*/
		$("#saveEducation").click(function(){
			if(!$("#educationForm").validate().form()){
				return false;
			}else{
				disableButton("saveEducation");
				// Check if the Institute Name is present in Master table or not
				instituteName	=	$("#eduInstituteName").val(); 

				// URL to get the Institute ID, if Name is present				
				urlAction = '<?php echo base_url();?>kols/get_institute_id_else_save/'+instituteName;
				
				// Variable to hold the Institute Id
				instituteId	= '';
				$.post(urlAction,{name:instituteName},
						function(returnData){
							if(returnData){
								instituteId	= returnData;
								$("#eduInstituteNameNotFound").hide();
								saveEducationDetails(instituteId);
							}else{
								enableButton("saveEducation");
								
								$("#eduInstituteNameNotFound").show();

								// Set the user entered name in the 'Add New Institute' form
								$("#instituteName").val(instituteName);
								return false;
							}
						}, 
						"json");
			}
/*			
				// Disable the SAVE Button
				disableButton("saveEducation");
				
				$("#educationForm").validate().resetForm();

				if(!$("#educationForm").validate().form()){
					enableButton("saveEducation");
					return false;
				}
				// Check if the Institute Name is present in Master table or not
				instituteName	=	$("#eduInstituteName").val(); 

				// URL to get the Institute ID, if Name is present
				urlAction = '<?php echo base_url();?>kols/get_institute_id_else_save/'+instituteName;

				// Variable to hold the Institute Id
				instituteId	= '';
				$.post(urlAction,'',
						function(returnData){
							if(returnData){
								instituteId	= returnData;
								$("#eduInstituteNameNotFound").hide();
								saveEducationDetails(instituteId);
							}else{
								enableButton("saveEducation");
								
								$("#eduInstituteNameNotFound").show();

								// Set the user entered name in the 'Add New Institute' form
								$("#instituteName").val(instituteName);
								return false;
							}
						}, 
						"json");
	*/			//- End of checking the Intitute Name in Master Table
		});	
   
		function saveEducationDetails(instituteId){
			$("#eduInstituteId").val(instituteId);
			var startDate=$("#eduStartDate").val();
			var  endDate = $("#eduEndDate").val();
			if(endDate!='' && startDate!=''){
				if(startDate<=endDate){
					saveDetails('edu','educationForm','JQBlistEducationResultSet','saveEducation',instituteId,'edu');
				}else{
					$("#eduDate").show();
					enableButton("saveEducation");
				}
			}else{
					saveDetails('edu','educationForm','JQBlistEducationResultSet','saveEducation',instituteId,'edu');
				}
		}	

		/**
		* Save the 'Training Details'
		*/
		$("#saveTraining").click(function(){
			if(!$("#trainingForm").validate().form()){
				return false;
			}else{
			
				// Disable the SAVE Button
				disableButton("saveTraining");

			//	$("#trainingForm").validate().resetForm();

			//	if(!$("#trainingForm").validate().form()){
			//		enableButton("saveTraining");
			//		return false;
			//	}
			
				// Check if the Institute Name is present in Master table or not
				instituteName	=	$("#trainInstituteName").val(); 
				// URL to get the Institute ID, if Name is present
				urlAction = '<?php echo base_url();?>kols/get_institute_id_else_save/'+instituteName;

				// Variable to hold the Institute Id
				instituteId	= '';
				$.post(urlAction,{name:instituteName},
						function(returnData){
							if(returnData){
								instituteId	= returnData;
								$("#trainInstituteNameNotFound").hide();
								saveTrainingDetails(instituteId);
								location.reload();
							}else{
								enableButton("saveTraining");

								$("#trainInstituteNameNotFound").show();

								// Set the user entered name in the 'Add New Institute' form
								$("#instituteName").val(instituteName);
								return false;
							}
						}, 
						"json");
			}
			//- End of checking the Intitute Name in Master Table
		});	
		
		/**
		* Save the 'Training Details '
		*/
		function saveTrainingDetails(instituteId){
			$("#trainInstituteId").val(instituteId);
			var startDate =$("#trainStartDate").val();
			var endDate =$("#trainEndDate").val();
			if(startDate!='' && endDate!=''){
				if(startDate<=endDate){
					saveDetails('train','trainingForm','JQBlistTrainingResultSet','saveTraining',instituteId,'train');
				}else{
					$("#trainDate").show();
					enableButton("saveTraining");
				}
			}else{
				saveDetails('train','trainingForm','JQBlistTrainingResultSet','saveTraining',instituteId,'train');
			}
		};	

		/**
		* Save the 'Board Certification Details'
		*/
		$("#saveBoard").click(function(){

			if(!$("#boardForm").validate().form()){
				return false;
			}else{
				// Disable the SAVE Button
				disableButton("saveBoard");

			//	$("#boardForm").validate().resetForm();

			//	if(!$("#boardForm").validate().form()){
			//		enableButton("saveBoard");
			//		return false;
			//	}
			
				// Check if the Institute Name is present in Master table or not
				instituteName	=	$("#boardInstituteName").val(); 
				// URL to get the Institute ID, if Name is present
				urlAction = '<?php echo base_url();?>kols/get_institute_id_else_save/'+instituteName;

				// Variable to hold the Institute Id
				instituteId	= '';
				$.post(urlAction,{name:instituteName},
						function(returnData){
							if(returnData){
								instituteId	= returnData;
								$("#boardInstituteNameNotFound").hide();
								saveBoardDetails(instituteId);
							}else{
								enableButton("saveBoard");

								$("#boardInstituteNameNotFound").show();

								// Set the user entered name in the 'Add New Institute' form
								$("#instituteName").val(instituteName);
								return false;
							}
						}, 
						"json");
				//- End of checking the Intitute Name in Master Table
			}
		});	
		
		/**
		* Save the 'Board Certification Details'
		*/
		function saveBoardDetails(instituteId){
			$("#boardInstituteId").val(instituteId);
			var startDate =$("#boardStartDate").val();
			var endDate =$("#boardEndDate").val();
			if(startDate!='' && endDate!=''){
				if(startDate<=endDate){
					saveDetails('board','boardForm','JQBlistBoardResultSet','saveBoard',instituteId,'board');
					
				}else{
					$("#boardDate").show();
					enableButton("saveBoard");
				}
			}else{
				saveDetails('board','boardForm','JQBlistBoardResultSet','saveBoard',instituteId,'board');
			}
		};	

		/**
		* Save the 'Honors and Awards Details'
		*/
		$("#saveAward").click(function(){
			if(!$("#awardForm").validate().form()){
				return false;
			}else{
				disableButton("saveAward");
				var name = $("#awardHonorName").val();
				saveHonorNAwards();
// 				saveDetails('award','awardForm','JQBlistAwardResultSet','saveAward');
			}
		});		

		function saveHonorNAwards(){
			var startDate =$("#awardStartDate").val();
			var endDate =$("#awardEndDate").val();
			if(startDate!='' && endDate!=''){
				if(startDate<=endDate){
					saveDetails('award','awardForm','JQBlistAwardResultSet','saveAward');
				}else{
					$("#awardDate").show();
					enableButton("saveAward");
				}
			}else{
				saveDetails('award','awardForm','JQBlistAwardResultSet','saveAward');
			}
		}
		/*
		*common function to save/update details
		*/
		function saveDetails(idType,formId,gridId,btnId,instituteId,divId){

			$('div.eduMsgBox').removeClass('success');
			$('div.eduMsgBox').addClass('notice');
			$('div.eduMsgBox').show();
			$('div.eduMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
			
			if(idType!='award')
				$("#"+idType+"InstituteId").val(instituteId);				
			
			//If Institute Id is present then perform save or update
			id = $("#"+idType+"Id").val();
			if(id == ''){
				formAction = '<?php echo base_url();?>kols/save_education_detail';
			}else{
				formAction = '<?php echo base_url();?>kols/update_education_detail';
			}					
			
			 $.post(formAction, $("#"+formId).serialize(),
					 function(returnData){
			     		if(returnData.saved == true){
							location.reload();
							// Clear the existing form details
							if(idType!='award'){
							$("#"+idType+"InstituteName").val("");
							$("#"+idType+"Degree").val("");
							$("#"+idType+"Specialty").val("");
							$("#"+idType+"StartDate").val("");
							$("#"+idType+"EndDate").val("");
							}else{
							$("#"+idType+"HonorName").val("");
							$("#"+idType+"StartDate").val("");
							$("#"+idType+"EndDate").val("");
							}
							$("#"+idType+"Url1").val("");
							$("#"+idType+"Url2").val("");
							$("#"+idType+"Notes").val("");

							$("tr.ui-state-highlight").removeClass('ui-state-highlight');
							if(id == ''){
								var datarow = '';
								if(idType!='award'){									
								 datarow = {
										id				:	returnData.lastInsertId,
										institute_id	:	returnData.data.institute_id,
										specialty 		:	returnData.data.specialty,
										degree			:	returnData.data.degree,
										date			:	returnData.data.start_date+' - '+returnData.data.end_date,
										url1			:	returnData.data.url1,
										url2			:	returnData.data.url2,
										notes			:	returnData.data.notes,
										created_by		:	returnData.data.created_by,
										client_id		:	returnData.data.client_id,
										is_analyst		:	returnData.data.is_analyst,
										first_name		:	returnData.data.first_name,
										last_name		:	returnData.data.last_name
										
									}; 
								}else{
									 datarow = {
											id				:	returnData.lastInsertId,
											honor_name		:	returnData.data.honor_name,
										    date            :   returnData.data.start_date+' - '+returnData.data.end_date,
											url1			:	returnData.data.url1,
											url2			:	returnData.data.url2,
											notes			:	returnData.data.notes,
											created_by		:	returnData.data.created_by,
											client_id		:	returnData.data.client_id,
											is_analyst		:	returnData.data.is_analyst,
											first_name		:	returnData.data.first_name,
											last_name		:	returnData.data.last_name
										}; 
								}
								var su=jQuery("#"+gridId).jqGrid('addRowData',returnData.lastInsertId,datarow);  
								
							}else{
								//jQuery("#JQBlistEducationResultSet").trigger("reloadGrid");
								if(idType!='award'){
									jQuery("#"+gridId).jqGrid('setRowData',returnData.data.lastInsertId,{
																				id				:	returnData.data.lastInsertId,
																				institute_id	:	returnData.data.institute_id,
																				specialty 		:	returnData.data.specialty,
																				degree			:	returnData.data.degree,
																				date            :   returnData.data.start_date+' - '+returnData.data.end_date,
																				start_date		:	returnData.data.start_date,
																				end_date		:	returnData.data.end_date,
																				url1			:	returnData.data.url1,
																				url2			:	returnData.data.url2,
																				notes			:	returnData.data.notes,
																				created_by		:	returnData.data.created_by,
																				client_id		:	returnData.data.client_id,
																				is_analyst		:	returnData.data.is_analyst,
																				first_name		:	returnData.data.first_name,
																				last_name		:	returnData.data.last_name
																			}); 
									}else{
										jQuery("#"+gridId).jqGrid('setRowData',returnData.data.lastInsertId,{
																				id				:	returnData.lastInsertId,
																				honor_name		:	returnData.data.honor_name,
																				year 			:	returnData.data.year,
																				date            :   returnData.data.start_date+' - '+returnData.data.end_date,
																				url1			:	returnData.data.url1,
																				url2			:	returnData.data.url2,
																				notes			:	returnData.data.notes,
																				created_by		:	returnData.data.created_by,
																				client_id		:	returnData.data.client_id,
																				is_analyst		:	returnData.data.is_analyst,
																				first_name		:	returnData.data.first_name,
																				last_name		:	returnData.data.last_name
																			}); 
									}
								$("tr#"+returnData.data.id).addClass('ui-state-highlight');
							}

								// If we are updating
							if(id != ''){
								// Modify the text of 'Button' from 'Update' to 'Add'
								$("#"+btnId).val("Add");

								// Re-Set the Hidden Eduction Id value
								$("#"+idType+"Id").val("");									
							}
							$("div.eduMsgBox").fadeOut(1500);
							$("#"+divId+"Date").hide();
							$(".eduMsgBox ").hide();
							
					     	enableButton(btnId);
					     	setTimeout($("#clientEduAddContainer").dialog("close"), 1500);
				     	}else{
					     	enableButton(btnId);
							// Display Error Message
					     }
					},"json");				
		}	

		/**
		* Validate the text for 'Numeric Only'
		*/
		function allowNumericOnly(src) {
			
			if(!src.value.match(/^\d{4}$/)) {
				src.value=src.value.replace(/[^0-9]/g,'');  
			}
			
		}

		/**
		* Returns the list of States of the Selected Country ID
		*/
		function getStatesByCountryId(){
			// Show the Loading Image
			$("#loadingStates").show();
			
			var countryId=$('#country_id').val();
			var params = "country_id="+countryId;	
			$("#state_id").html("<option value=''>-- Select State --</option>");
			$("#city_id").html("<option value=''>-- Select City --</option>");
			var states = document.getElementById('state_id');
			$.ajax({
				url: "<?php echo base_url()?>country_helpers/get_states_by_countryid/",
				dataType: "json",
				data: params,
				type: "POST",
				success: function(responseText){					
					$.each(responseText, function(key, value) {					
						var newState = document.createElement('option');
						newState.text = value.state_name;
						newState.value = value.state_id;
						 var prev = states.options[states.selectedIndex];
						 states.add(newState, prev);				
						});
                                                
                $("#state_id option[value='']").remove();
                $("#state_id").prepend("<option value=''>-- Select State --</option>");
                $("#state_id").val("");
					
				},
				complete: function(){
					$("#loadingStates").hide();
				}
			});		
		}

		/**
		* Returns the list of Cities of the Selected State
		*/
		function getCitiesByStateId(){
			// Show the Loading Image
			$("#loadingCities").show();
			
			var stateId=$('#state_id').val();
			$("#city_id").html("<option value=''>-- Select City</option>");	
			var cities = document.getElementById('city_id');
			var params = "state_id="+stateId;	
			
			$.ajax({
				url: "<?php echo base_url()?>country_helpers/get_cities_by_stateid/",
				dataType: "json",
				data: params,
				type: "POST",
				success: function(responseText){					
					$.each(responseText, function(key, value) {	
								
					var newCity = document.createElement('option');
					newCity.text = value.city_name;
					newCity.value = value.city_id;
					 var prev = cities.options[cities.selectedIndex];
					 cities.add(newCity, prev);				
					});
                                        $("#city_id option[value='']").remove();
                    $("#city_id").prepend("<option value=''>-- Select City --</option>");
                    $("#city_id").val("");
					
				},
				complete: function(){
					$("#loadingCities").hide();
				}		
			});		
			
		}

		function saveContact(){
			if(!$("#contactForm").validate().form()){
				return false;
			}else{
				var formAction = '<?php echo base_url()?>kols/additional_contact';
				$.ajax({
					url:formAction,
					type:'post',
					dataType:'json',
					data:$('#contactForm').serialize(),
					success:function(returnData){
						if(returnData.status=='success'){
							$("#clientEduAddContainer").dialog("close");
							var datarow = {
									id		: returnData.lastInsertId,
									type	: returnData.data.type,
									address : returnData.data.address,
									phone	: returnData.data.phone,
									act		: returnData.data.act
								}; 
							jQuery("#JQBlistContactsResultSet").jqGrid('addRowData',returnData.lastInsertId,datarow); 
						}else{
							$('.msgBox').text(returnData.msg);
							$('.msgBox').fadeOut(2500);
						}
					}
				
					});
				}
		}

			
	</script>
	<style type="text/css">
		
		.ui-tabs .ui-tabs-nav {
			padding:0;
		}
		#clientEduAddProfileContent .ui-widget-content {
			border:0;
		}
/*		#horizontalTabs .ui-state-default, 
		#horizontalTabs .ui-widget-content .ui-state-default, 
		#horizontalTabs .ui-widget-header .ui-state-default{
			background: url("<?php echo base_url();?>images/nav-box-bg.gif");
			border: 1px solid;
		}
		#horizontalTabs .ui-state-active, 
		#horizontalTabs .ui-widget-content .ui-state-active, 
		#horizontalTabs .ui-widget-header .ui-state-active{
			 background: #1E7399;
			 border: 1px solid #1E7399;
		}
		
		#horizontalTabs .ui-state-default a, 
		#horizontalTabs .ui-state-default a:link, 
		#horizontalTabs .ui-state-default a:visited{
			color:#000000;
			font-weight: normal;		
		}
		
		#horizontalTabs .ui-state-active a, 
		#horizontalTabs .ui-state-active a:link, 
		#horizontalTabs .ui-state-active a:visited{
			 color:#FFFFFF;
			 font-weight: normal;
		}
*/		#editEducation{
			border: 1px solid #74B4DD !important;
		}
		
		#horizontalTabs .ui-state-active, #horizontalTabs .ui-widget-content .ui-state-active, #horizontalTabs .ui-widget-header .ui-state-active, #horizontalTabs .ui-state-default:hover, #horizontalTabs .ui-widget-content .ui-state-default:hover, #horizontalTabs .ui-widget-header .ui-state-default:hover {
		    background: none !important; 
		    border: 1px solid #74B4DD;
		}
	
		#horizontalTabs .ui-state-active a, #horizontalTabs .ui-state-default a:hover, #horizontalTabs .ui-state-active a:link, #horizontalTabs .ui-state-active a:visited {
			color:black;
			font-weight: normal;
		}
		#eduHorizontalTabs #horizontalTabs ul li a:hover{
			color:#2f86be !important;
		}
		
		#horizontalTabs .ui-state-default, #horizontalTabs .ui-widget-content .ui-state-default, #horizontalTabs .ui-widget-header .ui-state-default {
			border:  1px solid #74B4DD !important;
			border-bottom-color:#ffffff !important;
		}
		#contactForm input[type="text"]{
			width:100%;
		}
		#contactForm td label{
			display: block;
    		width: 115px !important;
		}
		#contactForm #country_id, #contactForm #state_id, #contactForm #city_id{
			width:125px;
		}
		#contactsTabId,#educationTabId,#boardTabId{
			display:none;
		}
		.board_certification{
			display:none;
		}
	</style>
		<!-- Start of Education and Training Content -->
		<!-- Container for the Horizontal Tabs of 1st tab -->
		<div id="eduHorizontalTabs" class="analystView">
			<div id="horizontalTabs" class="analystView">
				<ul class="verticalTabsContainer">
					<!-- <li><a href="#contactsTabId">Additional <span class="accessKey">C</span>ontact</a></li> -->
					<!-- <li><a href="#educationTabId" accesskey="u" id="educationNav">Ed<span class="accessKey">u</span>cation</a></li> -->
					<li><a href="#trainingTabId" accesskey="r" id="trainingNav">T<span class="accessKey">r</span>aining</a></li>
					<!-- <li><a href="#boardTabId" accesskey="c" id="boardNav">Board <span class="accessKey">C</span>ertification</a></li> -->
					<li><a href="#honorsTabId" accesskey="h" id="honorsNav"><span class="accessKey">H</span>onors and Awards</a></li>
				</ul>
			</div>
			<div id="editEducation">
				<?php /**<div id="contactsTabId">
					<div class="msgBoxContainer"><div class="eduMsgBox"></div></div>
					<form action="additional_contact" method="post" id="contactForm" name="contactForm">
						<input type="hidden" name="kol_id" id="kolEduId" value="<?php echo $kolId?>"></input>
						<table>
							<tr>
								<td class="alignRight">
									<label for="type">Type<span class="required">*</span> :</label>
								</td>
								<td>
									<select name="type" id="type_id" class="required">
										<option value="">Select type</option>
										<?php 
											foreach($locationType as $key=>$row){
												echo "<option value='".$key."' >".$row."</option>";
											}
										?>
									</select>
								</td>
								<td class="alignRight">
									<label for="title">Title :</label>
								
								</td>
								<td>
									<input type="text" name="title" id="title" value="<?php if(isset($arrKols['title'])) echo $arrKols['title']?>"></input>
								</td>
							</tr>
							<tr>
								<td class="alignRight">
									<label for="location">Location<span class="required">*</span> :</label>
								</td>
								<td colspan="3">
									<input type="text" name="location" id="location" value="<?php if(isset($arrKols['location'])) echo $arrKols['location']?>" class="required"></input>
								</td>
							</tr>
							<tr>
								<td class="alignRight">
									<label for="address1">Address<span class="required">*</span>:</label>
								
								</td>
								<td colspan="3">
									<input type="text" name="address1" id="address1" value="<?php if(isset($arrKols['address1'])) echo $arrKols['address1']?>" class="required"></input>
								</td>
							</tr>
							<tr>
								<td class="alignRight">
									<label for="primaryPhone">Phone<span class="required">*</span>:</label>
								
								</td>
								<td>
									<input type="text" name="primary_phone" id="primaryPhone" value="<?php if(isset($arrKols['primary_phone'])) echo $arrKols['primary_phone']?>" class="required"></input>
								</td>
								<td class="alignRight">
									<label for="fax">Fax :</label>
								
								</td>
								<td>
									<input type="text" name="fax" id="fax" value="<?php if(isset($arrKols['fax'])) echo $arrKols['fax']?>"></input>
								</td>
							</tr>
							<tr>
								<td class="alignRight">
									<label for="primaryEmail">Email:</label>
								
								</td>
								<td colspan="3">
									<input type="text" name="primary_email" id="primaryEmail" value="<?php if(isset($arrKols['primary_email'])) echo $arrKols['primary_email']?>" class="email"></input>
								</td>
							</tr>
							<tr>
								<td class="alignRight">
									<label for="orgName">Organization Name :</label>
								</td>
								<td colspan="3">
									<input type="text" name="org_id" id="orgName" value="<?php if(isset($arrKols['org_name'])) echo $arrKols['org_name']?>"></input>
								</td>
							</tr>
							<tr>
								<td class="alignRight">
									<label for="division">Department Name :</label>
								
								</td>
								<td colspan="3">
									<input type="text" name="division" id="division" value="<?php if(isset($arrKols['division'])) echo $arrKols['division']?>"></input>
								</td>
							</tr>
							<tr>
								<td class="alignRight">
								</td>
								<td>
									<label for="countryId1">Country<span class="required">*</span></label>
									<select name="country_id" id="country_id" onchange="getStatesByCountryId();" class="required">
										<option value="">-- Select --</option>
										<?php 
											foreach( $arrCountry as $country){
												if($country['country_id'] == $arrKols['country_id'])
													echo '<option value="'.$country['country_id'].'" selected="selected">'.$country['country_name'].'</option>';
												else
													echo '<option value="'.$country['country_id'].'">'.$country['country_name'].'</option>';
												}
										?>
									</select>
									<img id="loadingStates" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
								</td>
								<td>									
									<label for="stateId1">State / Province</label>
									<select name="state_id" id="state_id" onchange="getCitiesByStateId();">		
										<option>Select state</option>
										<?php 
											foreach( $arrStates as $state){
												if($state['state_id'] == $arrKols['state_id'])
													echo '<option value="'.$state['state_id'].'" selected="selected">'.$state['state_name'].'</option>';
												else
													echo '<option value="'.$state['state_id'].'">'.$state['state_name'].'</option>';
												}
										?>
									</select>
									<img id="loadingCities" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
								</td>
								<td class="alignRight">
									<label for="cityId1" style="width: 60% !important;">City</label>
									<select name="city_id" id="city_id">
										<option >Select city</option>		
									</select>
								</td>
							</tr>
							<tr>
								<td colspan="4">	
									<div class="formButtons">
										<input type="button" value="Save" name="submit" id="saveCostomer" onclick="saveContact();">
									</div>
								</td>
							</tr>
						</table>
					</form>
				</div>
				<!--Add Education details-->
				<div id="educationTabId">
					<div class="msgBoxContainer"><div class="eduMsgBox"></div></div>
					<form action="save_education_detail" method="post" id="educationForm" name="educationForm" class="validateForm clientForm">
						<input type="hidden" name="type" value="education"></input>
						<input type="hidden" name="id" id="eduId" value="<?php if(isset($eduData) && $type=='education') echo $eduData['id'] ?>" >
						
						<input type="hidden" name="kol_id" id="kolEduId" value="<?php echo $kolId?>"></input>
						<!-- Table for Education -->
						<table class="analystForm" id="educationTbl">
							<tr>
								<td colspan="2">	
									<p>
										<label for="eduInstituteName">Institution Name:<span class="required">*</span></label>
										<input type="hidden" name="institute_id" id="eduInstituteId" value="<?php if(isset($eduData)&& $type=='education') echo $eduData['institutionsId']?>"></input>
										<input type="text" name="institute_name" value="<?php if(isset($eduData)&& $type=='education') echo $eduData['name']?>" id="eduInstituteName" class="required institute_name autocompleteInputBox" />
									</p>
								</td>
							</tr>
							<tr>
								<td>		
									<p>
										<label for="eduDegree">Degree:</label>
										<input type="text" name="degree" value="<?php if(isset($eduData)&& $type=='education') echo $eduData['degree']?>" id="eduDegree"></input>
									</p>
								</td>
								<td>
									<p>
										<label for="eduSpecialty">Specialty:</label>
										<input type="text" name="specialty" value="<?php if(isset($eduData)&& $type=='education') echo $eduData['specialty']?>" id="eduSpecialty"></input>
									</p>
								</td>
							</tr>
							<tr>
								<td>			
									<p>
										<label for="eduStartDate">Start Year:</label>
										<input type="text" name="start_date" value="<?php if(isset($eduData)&& $type=='education') echo $eduData['start_date']?>" id="eduStartDate" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear"></input>
									</p>				
								</td>
								<td>
									<p>
										<label for="eduEndDate">End Year:</label>
										<input type="text" name="end_date" value="<?php if(isset($eduData)&& $type=='education') echo $eduData['end_date']?>" id="eduEndDate" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear" onmouseout="validate(this.value,'edu','saveEducation')"></input>
									</p>
									<div id="eduDate" class="instNotFound">Invalid Year.End Year Should be Greater than Start Year</div>
								</td>
							</tr>
							<tr>
								<td colspan="2">		
									<p>
										<label for="eduUrl1">URL:</label>
										<input type="text" name="url1" value="<?php if(isset($eduData)&& $type=='education') echo $eduData['url1']?>" id="eduUrl1" class="url"></input>
									</p>	
								</td>
							</tr>
							<tr>
								<td colspan="2">	
									<div class="formButtons">										
										<input type="button" value="Save" name="submit" id="saveEducation">
									</div>
								</td>
							</tr>
						</table>		
						<!-- End of Education table -->
					</form>	
					<!-- End of "Add Education details" form- -->
				</div>
				<!--End of Add Education details-->
				**/?>
				<!--Add Training details-->
				<div id="trainingTabId">
					<div class="msgBoxContainer"><div class="eduMsgBox"></div></div>
					<?php 
					$arrType = array();
					$arrType['training']= 'Training'; 
					$arrType['education']= 'Education';
					$arrType['board_certification']= 'Board Cerification';
					?>
					<form action="save_education_detail" method="post" id="trainingForm" name="trainingForm" class="validateForm clientForm">
						<!-- <input type="hidden" name="type" value="training"></input>-->
						<input type="hidden" name="id" id="trainId" value="<?php if(isset($eduData)) echo $eduData['id'] ?>"></input>
						<input type="hidden" name="kol_id" id="kolTrainId" value="<?php echo $kolId?>"></input>
						<!-- Table for Training -->
						<table class="analystForm" id="trainingTbl">
							<tr>
								<td colspan="2">		
									<p>
										<label for="type">Type :</label>
										<select name="type" id ="trainingType">
											<?php foreach ($arrType as $key=>$title){?>
												<option value="<?php echo $key?>" <?php if(isset($type) && $type==$key) echo "selected='selected'";?>><?php echo $title;?></option>
											<?php }?>
										</select>
									</p>
								</td>
							</tr>
							<tr>
								<td colspan="2">		
									<p>
										<label for="trainInstituteName">Institution Name:<span class="required">*</span></label>
										<input type="hidden" name="institute_id" id="trainInstituteId" value="<?php if(isset($eduData)) echo $eduData['institutionsId'] ?>"></input>
										<input type="text" name="institute_name" value="<?php if(isset($eduData)) echo $eduData['name'] ?>" id="trainInstituteName" class="required institute_name autocompleteInputBox"></input>
									</p>
								</td>
							</tr>
							<tr>
								
								<td class="trainingDegree <?php if(isset($type)) echo $type;?>">	
									<p>
										<label for="trainDegree">Degree:</label>
										<input type="text" name="degree" value="<?php if(isset($eduData)) echo $eduData['degree'] ?>" id="trainDegree"></input>
									</p>
								</td>
								<td>
									<p>
										<label for="trainSpecialty">Specialty:</label>
										<input type="text" name="specialty" value="<?php if(isset($eduData)) echo $eduData['specialty'] ?>" id="trainSpecialty"></input>
									</p>
								</td>
							</tr>
							<tr>
								<td>				
									<p>
										<label for="trainStartDate">Start Year:</label>
										<input type="text" name="start_date" value="<?php if(isset($eduData)) echo $eduData['start_date'] ?>" id="trainStartDate" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear"></input>
									</p>				
								</td>
								<td>
									<p>
										<label for="trainEndDate">End Year:</label>
										<input type="text" name="end_date" value="<?php if(isset($eduData)) echo $eduData['end_date'] ?>" id="trainEndDate" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear" onmouseout="validate(this.value,'train','saveTraining')"></input>
									</p>
									<div id="trainDate" class="instNotFound">Invalid Year.End Year Should be Greater than Start Year</div>
								</td>
							</tr>
							<tr>	
								<td colspan="2">	
									<p>
										<label for="trainUrl1">URL:</label>
										<input type="text" name="url1" value="<?php if(isset($eduData)) echo $eduData['url1'] ?>" id="trainUrl1" class="url"></input>
									</p>	
								</td>
							</tr>
							<tr>
								<td colspan="2">	
									<div class="formButtons">
										<input type="button" value="Save" name="submit" id="saveTraining">
									</div>
								</td>
							</tr>
						</table>		
						<!-- End of Training table -->
					</form>	
					<!-- End of Training Form  -->
				</div>
				<!--End of Add Training details-->	
				
				<?php /**
				<!--Add Board Certification details-->
				<div id="boardTabId">
					<div class="msgBoxContainer"><div class="eduMsgBox"></div></div>
					
					<form action="save_education_detail" method="post" id="boardForm" name="boardForm" class="validateForm clientForm">
						<input type="hidden" name="type" value="board_certification"></input>
						<input type="hidden" name="id" id="boardId" value="<?php if(isset($eduData) && $type=='board') echo $eduData['id'] ?>"></input>
						<input type="hidden" name="kol_id" id="kolBoardId" value="<?php echo $kolId?>"></input>
						<!-- Table for Board Certification -->
						<table class="analystForm" id="boardTbl">
							<tr>	
								<td colspan="2">	
									<p>
										<label for="boardInstituteName">Institution Name:<span class="required">*</span></label>
										<input type="hidden" name="institute_id" id="boardInstituteId" value="<?php if(isset($eduData) && $type=='board') echo $eduData['institutionsId'] ?>"></input>
										<input type="text" name="institute_name" value="<?php if(isset($eduData) && $type=='board') echo $eduData['name'] ?>" id="boardInstituteName" class="required institute_name autocompleteInputBox"></input>
									</p>
								</td>
							</tr>
							<tr>
								<td colspan="2">
									<p>
										<label for="boardSpecialty">Specialty:</label>
										<input type="text" name="specialty" value="<?php if(isset($eduData) && $type=='board') echo $eduData['specialty'] ?>" id="boardSpecialty"></input>
									</p>
								</td>
							</tr>
							<tr>
								<td>			
									<p>
										<label for="boardStartDate">Start Year:</label>
										<input type="text" name="start_date" value="<?php if(isset($eduData) && $type=='board') echo $eduData['start_date'] ?>" id="boardStartDate" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear"></input>
									</p>				
								</td>
								<td>
									<p>
										<label for="boardEndDate">End Year:</label>
										<input type="text" name="end_date" value="<?php if(isset($eduData) && $type=='board') echo $eduData['end_date'] ?>" id="boardEndDate" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear" onmouseout="validate(this.value,'board','saveBoard')"></input>
									</p>	
									<div id="boardDate" class="instNotFound">Invalid Year.End Year Should be Greater than Start Year</div>		
								</td>
							</tr>
							<tr>		
								<td colspan="2">
									<p>
										<label for="boardUrl1">URL:</label>
										<input type="text" name="url1" value="<?php if(isset($eduData) && $type=='board') echo $eduData['url1'] ?>" id="boardUrl1" class="url"></input>
									</p>	
								</td>		
							</tr>
							<tr>												
								<td colspan="2">	
									<div class="formButtons">
										<input type="button" value="Save" name="submit" id="saveBoard">
									</div>
								</td>
							</tr>
						</table>
						<!-- End of table "Board Certification" -->
					</form>	
					<!-- End of Board Certification form -->
				</div>
				<!--End of Add Board Certification details-->	
				**/?>
				<!--Add Honors and Awards details-->
				<div id="honorsTabId">
					<div class="msgBoxContainer"><div class="eduMsgBox"></div></div>
					
					<form action="save_education_detail" method="post" id="awardForm" name="awardForm" class="validateForm clientForm">
						<input type="hidden" name="type" value="honors_awards"></input>
						<input type="hidden" name="id" id="awardId" value="<?php if(isset($eduData) && $type=='honors') echo $eduData['id'] ?>"></input>
						<input type="hidden" name="kol_id" id="awardId" value="<?php echo $kolId?>"></input>
						<table class="analystForm" id="awardTbl">			
							<tr>	
								<td colspan="2">	
									<p>
										<label for="awardHonorName">Name:<span class="required">*</span></label>
										<input type="text" name="honor_name" value="<?php if(isset($eduData) && $type=='honors') echo $eduData['honor_name'] ?>" id="awardHonorName" class="required institute_name"></input>
									</p>
								</td>
							</tr>
							<tr>
								<td>			
									<p>
										<label for="awardStartDate">Start Year:</label>
										<input type="text" name="start_date" value="<?php if(isset($eduData) && $type=='honors') echo $eduData['start_date'] ?>" id="awardStartDate" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear"></input>
									</p>				
								</td>
								<td>
									<p>
										<label for="awardEndDate">End Year:</label>
										<input type="text" name="end_date" value="<?php if(isset($eduData) && $type=='honors') echo $eduData['end_date'] ?>" id="awardEndDate" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear" onmouseout="validate(this.value,'award','saveAward')"></input>
									</p>
									<div id="awardDate" class="instNotFound">Invalid Year.End Year Should be Greater than Start Year</div>
								</td>
							</tr>
							
							
							<tr>
								<td colspan="2">
									<p>
										<label for="awardUrl1">URL:</label>
										<input type="text" name="url1" value="<?php if(isset($eduData) && $type=='honors') echo $eduData['url1'] ?>" id="awardUrl1" class="url"></input>
									</p>	
								</td>
							</tr>
							<tr>
								<td colspan="2">													
									<div class="formButtons">
										<input type="button" value="Save" name="submit" id="saveAward">
									</div>
								</td>
							</tr>
						</table>
					</form>
				</div>
				<!--End of Add Honors and Awards details-->	
		
			</div>
		</div> 
		<!-- End of Container for the Horizontal Tabs -->
