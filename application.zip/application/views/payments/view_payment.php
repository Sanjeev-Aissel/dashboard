<?php
/**
 * File to 'view' Payment details
 *
 * @author: Ambarish
 * @Created on: 01-03-11
 */
?>

	<!-- Table for Payment -->
	<table class="analystForm" id="paymentTbl">
		<tr>
			<td>	
				<label for="paymentType">Type:</label>
				<?php echo $arrPayment['name'];?>
			</td>
			<td>	
				<label for="paymentType">Interaction-Id:</label>
				<?php echo $arrPayment['interaction_id'];?>
			</td>
		</tr>
		<tr>
			<td>		
				<p>
					<label for="paymentDate">Date:</label>
					<?php echo $arrPayment['date'];?>
				</p>
			</td>
			<td>
				<p>
					<label for="paymentReason">Reason:</label>
					<?php echo $arrPayment['reason'];?>
				</p>
			</td>
		</tr>
		<tr>
			<td>			
				<p>
					<label for="paymentPayment">Payment:</label>
					<?php echo $arrPayment['payment'];?>
				</p>				
			</td>
			<td>
				<p>
					<label for="paymentThreshholdRate">Threshhold Rate:</label>
					<?php echo $arrPayment['threshhold_rate'];?>
				</p>
			</td>
		</tr>
		<tr>
			<td>		
				<p>
					<label for="paymentRate">Rate:</label>
					<?php echo $arrPayment['rate'];?>
				</p>	
			</td>
			<td>		
				<p>
					<label for="paymentDuration">Duration:</label>
					<?php echo $arrPayment['duration'];?>
				</p>	
			</td>
		</tr>
		<tr>
			<td>		
				<p>
					<label for="paymentDuration">KOL:</label>
					<?php echo $arrPayment['kol_name'];?>
				</p>	
			</td>
		</tr>
	</table>		
	<!-- End of Payment table -->