<?php
/*
 *  View page to Add Users
 * 	@autor Vinayak Malladad
 * 	@since 1.5
 * 
 * 
 */
$userRoleId = $this->session->userdata('user_role_id');
?>
	<style type="text/css">
	
	.userTable{
	  <?php if($userRoleId == ROLE_ADMIN){?>
		margin-left:240px;
	  <?php } else { ?>
                margin-left:40px;
          <?php } ?>
	}
        .formButtons{
              <?php if($userRoleId == ROLE_ADMIN){?>
                text-align: left;
              <?php } ?>
        }
	.userTable .labelForfields{
		float:left;
		font-size:16px;
		margin-right:38px;
		text-align:right;
		width:100px;
		font-family:lucida Grande;
                <?php if (!IS_IPAD_REQUEST) { ?>
                    margin-top:-2px;
                <?php } else { ?>
                     margin-top:5px;
                <?php } ?>
	}
	  
                
	.userTable input[type="text"],input[type="password"]{
		margin-left:-29px;
		margin-top:0;
		<?php if (!IS_IPAD_REQUEST) { ?>
                  width:160px; 
                <?php } else { ?>
                   width:200px; 
                <?php } ?>
	
	}
	
	.userTable select{
		margin-left:-29px;
		margin-top:0;
                <?php if (!IS_IPAD_REQUEST) { ?>
                  width:160px; 
                <?php } else { ?>
                   width:200px; 
                <?php } ?>
		
	}
	.userTable input[type="button"]{
              <?php if($userRoleId != ROLE_ADMIN){?>
		margin-right:48px;
                
              <?php } else { ?>
                margin-left: 58px;
              <?php } ?>
                width:70px;
		text-align:center;
		
	}
	
	
	.userTable label.error {
		background:none repeat scroll 0 0 transparent;
		border:0 none;
		color:red;
		font-weight:normal;
		margin:0;
		padding:0;
		text-align:center;
	}
	select.error{
		padding:0px;
	}
        <?php if (IS_IPAD_REQUEST) { ?>
        .ipadCSS{
            
    /* display: block; */
    width: 100%;
    height: 30px;
    padding:0px !important; 
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
    border: 1px solid #ccc;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;

        }
        <?php } ?>
	</style>
	<script type="text/javascript">

	function getClientManagers(){
		$('#managerId').html("<option value=''>Select<option>");
		var clientId = $('#clientId').val();
		$.ajax({
			url : baseUrl+'client_users/get_client_managers/'+clientId,
			type:'text',
			success:function(returnData){
				$('#managerId').html(returnData);
			}
		});
	}

	function addRemoveMyself(){ 
		if($("#userRoleId").val() == 2 || $("#userRoleId").val() == 3){
			//$("#managerId").append("<option value='-1'>Myself</option>");
			$("#managerId").removeClass("required");
			$("#managerId").removeClass("error");
			$("#managerId + .error").hide();
		}else{
			$("#managerId").addClass("required");
		}
	}
	
	
	/**
	* Validate the text for 'Numeric Only'
	*/
	function allowNumericOnly(src) {
		if(!src.value.match(/^\d*$/)) {
			src.value=src.value.replace(/[^0-9]/g,'');  
		}
	}

	var validationRules	=  {
			first_name: {
				required:true
			},
			last_name: {
				required:true
			},
			title: {
				required:true
			},
			company_name: {
				required:true
			},
			phone: {
				required:true
			},
			email: {
				required:true
			},
			country: {
				required:true
			},
			password: {
				required:true
			},
			confirm_password: {
				required:true
			},
			user_name: {
				required:true
			}
		};
	
		var validationMessages = {
				first_name: {
					required: "Required field cannot be left blank"
				},
				last_name: {
					required: "Required field cannot be left blank"
				},
				user_name: {
					required: "Required field cannot be left blank"
				},
				
				title: {
					required: "Required field cannot be left blank"
				},
				country: {
					required: "Required field cannot be left blank"
				},
				password: {
					required: "Required field cannot be left blank"
				},
				confirm_password: {
					required: "Required field cannot be left blank"
				},
				title: {
					required: "Required field cannot be left blank"
				},
				company_name: {
					required: "Required field cannot be left blank"
				},
				phone: {
					required: "Required field cannot be left blank"
				},
				email: {
					required: "Required field cannot be left blank"
				}
		};


		$(document).ready(function(){
			$("#saveUser").validate({
				debug:true,
				//onkeyup:true,
				rules: validationRules,
				messages: validationMessages
			});
		});
		
</script>


<!-- <h1>Add New User</h1> -->
	<div class="clientUserMsgBox"></div>
<form action="<?php echo base_url()?>client_users/<?php if($arrUsers==null) echo "save_user"; else echo "update_user";?>"   method="post" name="saveUser" id="saveUser" class="validateForm">
	<input type="hidden" name="id" id="userId" value="<?php if($arrUsers!=null) echo $arrUsers['id'];?>"></input>
		<table class="anaylystForm clientTbl userTable">
			<tr>
				<td>	
					<p>
						<div class="labelForfields">Clients:</div>
						<select name="client_id" class="required ipadCSS" id="clientId" onchange="getClientManagers();">
							<option value="">--- Select ---</option>
							<?php foreach ($arrClients as $clients){
									if($clients['id'] == $arrUsers['client_id'])
										echo '<option value="'.$clients["id"].'" selected="selected">'.$clients["name"].'</option>';
								 
                                                                        else{
                                                                            if($userRoleId != ROLE_ADMIN){
										echo '<option value="'.$clients["id"].'">'.$clients["name"].'</option>';
                                                                            }
                                                                        } 
                                                                                
							}?>
						</select>
					</p>
				</td>	
			</tr>		
			<tr>
				<td>	
					<p>
						
						<div class="labelForfields">Role:</div>
						<select name="user_role_id" class="required ipadCSS" onchange="addRemoveMyself();"  id="userRoleId">
							<option value="">--- Select ---</option>
							<?php if($arrUsers['user_role_id']!='' ){
							
								if($arrUsers['user_role_id']==2){
									echo '<option value="2" selected="selected">Manager</option>';
									echo '<option value="1" >User</option>';
                                                                        echo "<option value='3'>Admin</option>";
                                                                        echo "<option value='0'>Read-Only User</option>";
								}else if($arrUsers['user_role_id']==1) {
									
									echo '<option value="1" selected="selected">User</option>';
									echo "<option value='2'>Manager</option>";
                                                                        echo "<option value='3'>Admin</option>";
                                                                        echo "<option value='0'>Read-Only User</option>";
								}
                                                                else if($arrUsers['user_role_id']==0) {
									
									echo '<option value="1">User</option>';
									echo "<option value='2'>Manager</option>";
                                                                        echo "<option value='3'>Admin</option>";
                                                                        echo '<option value="0" selected="selected">Read-Only User</option>';
								}else if($arrUsers['user_role_id']==3) {
									
									echo '<option value="1">User</option>';
									echo "<option value='2'>Manager</option>";
                                                                        echo '<option value="3" selected="selected">Admin</option>';
                                                                        echo "<option value='0'>Read-Only User</option>";
								}
                                                                
							}else{
									
							
                                                        echo "<option value='3'>Admin</option>";
							echo "<option value='2'>Manager</option>";
							
							echo "<option value='1'>User</option>";
                                                        echo "<option value='0'>Read-Only User</option>";
					}?>
						</select>
					</p>
				</td>	
			</tr>
			<tr>
				<td>
					<p>
						<div class="labelForfields">Manager:</div>
                                                <select name="manager_id" id="managerId" class="ipadCSS" <?php if($arrUsers['user_role_id'] !=2) echo 'class="required "'; ?>>
							<option value="">Select</option>
							<?php if($arrManagers != null){ foreach ($arrManagers as $key => $name){
									if($key == $arrUsers['manager_id'])
										echo '<option value="'.$key.'" selected="selected">'.$name.'</option>';
									else
										echo '<option value="'.$key.'">'.$name.'</option>';
							}}?>
						</select>
						<br />	
					</p>
					
				</td>
			</tr>
                        <?php if($userRoleId != ROLE_ADMIN){?>
			<tr>
				<td>
					<p>
						<div class="labelForfields">Territory:</div>
						<input type="text" name="territory" id="territory" value="<?php if($arrUsers!=null) echo $arrUsers['territory'];?>" class="ipadCSS"></input>
						<br />	
					</p>
					
				</td>
			</tr>	
                        <?php }?>
			<tr>
				<td>
					<p>
						<div class="labelForfields">First Name:</div>
						<input type="text" name="first_name" id="firstName" value="<?php if($arrUsers!=null) echo $arrUsers['first_name'];?>" class="required ipadCSS"></input>
						<br />	
					</p>
					
				</td>
			</tr>
			<tr>
				<td>
					<p>
						<div class="labelForfields">Last Name:</div>
						<input type="text" name="last_name" id="lastName" value="<?php if($arrUsers!=null) echo $arrUsers['last_name'];?>" class="required ipadCSS"></input>
						<br />	
					</p>
					
				</td>
			</tr>
			<tr>
				<td>
					<p>
						<div class="labelForfields">Username:</div>
						<input type="text" name="user_name" id="userName" value="<?php if($arrUsers!=null) echo $arrUsers['user_name'];?>" class="required ipadCSS"></input>
						<br />	
					</p>
					
				</td>
			</tr>
			
			<tr>
				<td>
					<p>
						<div class="labelForfields">Title:</div>
						<input type="text" name="title" id="title" value="<?php if($arrUsers!=null) echo $arrUsers['title'];?>" class="required ipadCSS"></input>
						<br />	
					</p>
					
				</td>
			</tr>
			<tr>
				<td>
					<p>
						<div class="labelForfields">Company Name:</div>
						<input type="text" name="company_name" id="companyName" value="<?php if($arrUsers!=null) echo $arrUsers['company_name'];?>" class="required ipadCSS"></input>
						<br />	
					</p>
					
				</td>
			</tr>
			<tr>
				<td>
					<div class="labelForfields">Country:</div>
					<select name="country" id="countryId1"  class="required ipadCSS">
						<option value="">-- Select --</option>
						<?php foreach( $arrCountry as $country ){ ?>
							<?php if($arrUsers['country']==$country['country_id']){?>
							<option value="<?php echo $country['country_id']?>" selected="selected"><?php echo $country['country_name']?></option>
							<?php }?>
							<option value="<?php echo $country['country_id'];?>">
								<?php echo $country['country_name'];?>
							</option>
						<?php }?>
					</select>
				</td>
			</tr>
			
			<tr>
				<td>
					<p>
					
						<div class="labelForfields">Email:</div>
						<input type="text" name="email" id="userEmail" value="<?php if($arrUsers!=null) echo $arrUsers['email'];?>" class="email ipadCSS"></input>
					</p>
				</td>
			</tr>
			<tr>
				<td>		
					<p>
					
						<div class="labelForfields">Contact:</div>
                                                <input type="text" name="contact" id="userContact" value="<?php if($arrUsers!=null) echo $arrUsers['contact'];?>" onkeyup="allowNumericOnly(this)" class="ipadCSS"></input>
					</p>
				</td>
			</tr>
                        <?php if($this->session->userdata('client_id')==INTERNAL_CLIENT_ID){?>
			<tr>
				<td>
					<p>
						
						<div class="labelForfields">Password:</div>
						<input type="password" name="password" id="userPassword" value="" class="required"></input>
						<br />
					</p>
					<div id="msg"></div>
				</td>
			</tr>
                        <?php }?>
			<tr>
				<td>
					<div class="formButtons">
                                            <input type="button" value="Save" name="submit" onclick="saveUserDetail();" class="ipadCSS"></input>
                                            <?php if($userRoleId == ROLE_ADMIN){?>
                                                <input type="button" value="Cancel" name="cancel" onclick="cancelUserDetail();"  class="ipadCSS"></input>
                                            <?php }?>
                                        </div>
				</td>
			</tr>
	</table>
<!-- End of Table -->
</form>
<!-- End of User Form -->