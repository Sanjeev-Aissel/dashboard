<style>
td{
	vertical-align: top;
}
.exportOptionsContainer, #rightSideBarWrapper{
	display: none;
}
td img{
        vertical-align: bottom;
        margin-left: 20px;
        cursor: pointer;
}
.microView .ui-dialog-content{
    background: #ffffff;
}
</style>
<script>
$(document).ready(function(){
	var microProfileDialogOpts = {
			title: "Add Products",
			modal: true,
			autoOpen: false,
			width: 400,
			dialogClass: "microView",
			open: function() {
				//display correct dialog content
			}
	};	
	$("#microProfile").dialog(microProfileDialogOpts);	
});
function viewMicroProfile(type,html){
	$("#intractionProduct").html(html);	
	$("#microProfile").dialog("open");	
	return false;
}
function addModal(type){
	var html='';
	if(type=='products'){
		html = '<h5>Add Product</h5><input type="text" id="name" /><br/><input type="button" value="Add" onclick=save("product")>';
	}else if(type=='dtype'){
		html = '<h5>Add Discussion Type</h5><input type="text" id="name" /><br/><input type="button" value="Add" onclick=save("dtype")>';	
	}else{
		html = '<h5>Add Topics</h5><input type="text" id="name" /><br/><input type="button" value="Add" onclick=save("topic")>';
	}	
	viewMicroProfile(type,html);
}
function save(type){
	var url = "<?php echo base_url();?>/interactions/add_product_topic_discussionType/"+type;
	var name = $("#name").val();
	if(name!=''){
    	$.ajax({
    		url:url,
    		type:'post',
    		dataType:'json',
    		data : {name:name},
    		success:function(returnData){
    			if(returnData.status!=false){
    				$("#microProfile").dialog("close");	
    				jAlert("Added Sucessfully");
    				if(type=='product'){
    					$('.'+type).append('<input type="checkbox" name="product_ids[]" value="'+returnData.status+'" />'+name+'<br />');
    				}else if(type=='dtype'){
    					$('.'+type).append('<input type="checkbox" name="type_ids[]" value="'+returnData.status+'" />'+name+'<br />');
        			}else{
        				$('.'+type).append('<input type="checkbox" name="topic_ids[]" value="'+returnData.status+'" />'+name+'<br />');
            		}
    			}else{
    				jAlert("Entered name aleredy exists.");
    			}
    		}
    	});
	}else{
		$("#intractionProduct").prepend("<span style='color:red'>Name Required!!</span>");
	}
}
</script>
<form method="post" name="asscoiate_topics" action="<?php echo base_url();?>user_settings/save_associate_teams_to_products">
	<table>
		<tr>
			<td colspan="3"><center><input type="submit" value="Associate Products" /></center></td>
		</tr>
		<tr>
			<td colspan="3">&nbsp;</td>
		</tr>
		<tr>
			<td><span><b>Team</b></span></td>
			<td><span><b>Products</b></span></td>
		</tr>
		<tr>
			<td valign="top" class="topic"><?php
			//pr($arrTeam);
				foreach($arrTeam as $key=>$value){
					echo '<input type="checkbox" name="team_ids[]" value="'.$value['group_id'].'" />'.$value['group_name'].'<br />';
				}
			?></td>
			<td class="product"><?php 
				foreach($arrProducts as $key=>$value){
					echo '<input type="checkbox" name="product_ids[]" value="'.$key.'" />'.$value.'<br />';
				}
			?></td>		
		
		</tr>
		<tr>
			<td colspan="3"><center><input type="submit" value="Associate Products" /></center></td>
		</tr>
	</table>
</form>
<div id="microProfile" class="microProfileDialogBox">
	<div id="intractionProduct" class="profileContent"></div>
</div>