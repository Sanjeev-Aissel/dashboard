<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta charset="utf-8">
  <title>Bootply snippet - Bootply Bootstrap Preview</title>
  <meta name="generator" content="Bootply" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta name="description" content="" />
  <link href="https://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" rel="stylesheet">

  <!--[if lt IE 9]>
  <script src="https://html5shim.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->
  <link rel="apple-touch-icon" href="/bootstrap/img/apple-touch-icon.png">
  <link rel="apple-touch-icon" sizes="72x72" href="/bootstrap/img/apple-touch-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="114x114" href="/bootstrap/img/apple-touch-icon-114x114.png">


  <!-- CSS code from Bootply.com editor -->

  <style type="text/css">
  @import url(https://fonts.googleapis.com/css?family=Antic+Slab);

  html,body {
    height:100%;
  }

  h1 {
    font-family: 'Antic Slab', serif;
    font-size:80px;
    color:#DDCCEE;
  }

  .lead {
    color:#DDCCEE;
  }


  /* Custom container */
  .container-full {
    margin: 0 auto;
    width: 100%;
    min-height:100%;
    /* background-color:#110022;*/
    color:#eee;
    overflow:hidden;
  }

  .container-full a {
    color:#efefef;
    text-decoration:none;
  }

  .v-center {
    margin-top:7%;
  }

  </style>
</head>

<!-- HTML code from Bootply.com editor -->

<body >

  <div class="container">

    <hr>

<div class="row">
  <div class="col-md-8">
      <div class="panel panel-default">
        <div class="panel-heading">
          <div class="row">
            <div class="col-md-8"><h3>
              Ms. Forsyth, Cathryn Jane
            </h3>
          </div>
          <div class="col-md-4"></div>
        </div>
      </div>
      <div class="panel-body">
        <div class="row">
          <div class="col-md-2">
            <img src="#" height="100" width="100">
          </div>
          <div class="col-md-10">
            Dental Therapy<br>
            Sydney, New South Wales<br>
            The University of Sydney Faculty of Dentistry
          </div>
        </div>
        <div class="row">
        <div class="col-md-12">
          <br />
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Request</button>
              </div>
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Edit</button>
              </div>
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Delete</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="panel-footer">
        <div class="row">
          <div class="col-md-3">
            <span class="glyphicon glyphicon glyphicon-star-empty" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star-empty" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star-empty" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star-empty" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star-empty" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            12 <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            1234 <span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            2 <span class="glyphicon glyphicon-comment" aria-hidden="true"></span>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-md-8">
      <div class="panel panel-default">
        <div class="panel-heading">
          <div class="row">
            <div class="col-md-8"><h3>
              Ms. Forsyth, Cathryn Jane
            </h3>
          </div>
          <div class="col-md-4"></div>
        </div>
      </div>
      <div class="panel-body">
        <div class="row">
          <div class="col-md-2">
            <img src="#" height="100" width="100">
          </div>
          <div class="col-md-10">
            Dental Therapy<br>
            Sydney, New South Wales<br>
            The University of Sydney Faculty of Dentistry
          </div>
        </div>
        <div class="row">
        <div class="col-md-12">
          <br />
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Request</button>
              </div>
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Edit</button>
              </div>
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Delete</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="panel-footer">
        <div class="row">
          <div class="col-md-3">
            <span class="glyphicon glyphicon glyphicon-star-empty" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star-empty" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star-empty" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star-empty" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star-empty" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            12 <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            1234 <span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            2 <span class="glyphicon glyphicon-comment" aria-hidden="true"></span>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<div class="row">
  <div class="col-md-8">
      <div class="panel panel-info">
        <div class="panel-heading">
          <div class="row">
            <div class="col-md-8"><h3>
              Ms. Forsyth, Cathryn Jane
            </h3>
          </div>
          <div class="col-md-4"></div>
        </div>
      </div>
      <div class="panel-body">
        <div class="row">
          <div class="col-md-2">
            <img src="#" height="100" width="100">
          </div>
          <div class="col-md-10">
            Dental Therapy<br>
            Sydney, New South Wales<br>
            The University of Sydney Faculty of Dentistry
          </div>
        </div>
        <div class="row">
        <div class="col-md-12">
          <br />
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Request</button>
              </div>
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Edit</button>
              </div>
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Delete</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="panel-footer">
        <div class="row">
          <div class="col-md-3">
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star-empty" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star-empty" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            12 <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            1234 <span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            2 <span class="glyphicon glyphicon-comment" aria-hidden="true"></span>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-md-8">
      <div class="panel panel-info">
        <div class="panel-heading">
          <div class="row">
            <div class="col-md-8"><h3>
              Ms. Forsyth, Cathryn Jane
            </h3>
          </div>
          <div class="col-md-4"></div>
        </div>
      </div>
      <div class="panel-body">
        <div class="row">
          <div class="col-md-2">
            <img src="#" height="100" width="100">
          </div>
          <div class="col-md-10">
            Dental Therapy<br>
            Sydney, New South Wales<br>
            The University of Sydney Faculty of Dentistry
          </div>
        </div>
        <div class="row">
        <div class="col-md-12">
          <br />
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Request</button>
              </div>
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Edit</button>
              </div>
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Delete</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="panel-footer">
        <div class="row">
          <div class="col-md-3">
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star-empty" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star-empty" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            12 <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            1234 <span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            2 <span class="glyphicon glyphicon-comment" aria-hidden="true"></span>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-md-8">
      <div class="panel panel-info">
        <div class="panel-heading">
          <div class="row">
            <div class="col-md-8"><h3>
              Ms. Forsyth, Cathryn Jane
            </h3>
          </div>
          <div class="col-md-4"></div>
        </div>
      </div>
      <div class="panel-body">
        <div class="row">
          <div class="col-md-2">
            <img src="#" height="100" width="100">
          </div>
          <div class="col-md-10">
            Dental Therapy<br>
            Sydney, New South Wales<br>
            The University of Sydney Faculty of Dentistry
          </div>
        </div>
        <div class="row">
        <div class="col-md-12">
          <br />
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Request</button>
              </div>
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Edit</button>
              </div>
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Delete</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="panel-footer">
        <div class="row">
          <div class="col-md-3">
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star-empty" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star-empty" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            12 <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            1234 <span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            2 <span class="glyphicon glyphicon-comment" aria-hidden="true"></span>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-md-8">
      <div class="panel panel-success">
        <div class="panel-heading">
          <div class="row">
            <div class="col-md-8"><h3>
              Ms. Forsyth, Cathryn Jane
            </h3>
          </div>
          <div class="col-md-4"></div>
        </div>
      </div>
      <div class="panel-body">
        <div class="row">
          <div class="col-md-2">
            <img src="#" height="100" width="100">
          </div>
          <div class="col-md-10">
            Dental Therapy<br>
            Sydney, New South Wales<br>
            The University of Sydney Faculty of Dentistry
          </div>
        </div>
        <div class="row">
        <div class="col-md-12">
          <br />
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Request</button>
              </div>
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Edit</button>
              </div>
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Delete</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="panel-footer">
        <div class="row">
          <div class="col-md-3">
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            12 <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            1234 <span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            2 <span class="glyphicon glyphicon-comment" aria-hidden="true"></span>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-md-8">
      <div class="panel panel-success">
        <div class="panel-heading">
          <div class="row">
            <div class="col-md-8"><h3>
              Ms. Forsyth, Cathryn Jane
            </h3>
          </div>
          <div class="col-md-4"></div>
        </div>
      </div>
      <div class="panel-body">
        <div class="row">
          <div class="col-md-2">
            <img src="#" height="100" width="100">
          </div>
          <div class="col-md-10">
            Dental Therapy<br>
            Sydney, New South Wales<br>
            The University of Sydney Faculty of Dentistry
          </div>
        </div>
        <div class="row">
        <div class="col-md-12">
          <br />
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Request</button>
              </div>
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Edit</button>
              </div>
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Delete</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="panel-footer">
        <div class="row">
          <div class="col-md-3">
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            12 <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            1234 <span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            2 <span class="glyphicon glyphicon-comment" aria-hidden="true"></span>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-md-8">
      <div class="panel panel-success">
        <div class="panel-heading">
          <div class="row">
            <div class="col-md-8"><h3>
              Ms. Forsyth, Cathryn Jane
            </h3>
          </div>
          <div class="col-md-4"></div>
        </div>
      </div>
      <div class="panel-body">
        <div class="row">
          <div class="col-md-2">
            <img src="#" height="100" width="100">
          </div>
          <div class="col-md-10">
            Dental Therapy<br>
            Sydney, New South Wales<br>
            The University of Sydney Faculty of Dentistry
          </div>
        </div>
        <div class="row">
        <div class="col-md-12">
          <br />
            <div class="btn-group btn-group-justified" role="group" aria-label="...">
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Request</button>
              </div>
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Edit</button>
              </div>
              <div class="btn-group" role="group">
                <button type="button" class="btn btn-default">Delete</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="panel-footer">
        <div class="row">
          <div class="col-md-3">
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
            <span class="glyphicon glyphicon glyphicon-star" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            12 <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            1234 <span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>
          </div>
          <div class="col-md-3">
            2 <span class="glyphicon glyphicon-comment" aria-hidden="true"></span>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script type='text/javascript' src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>


<script type='text/javascript' src="https://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>



<script type='text/javascript' src="https://ajax.googleapis.com/ajax/libs/angularjs/1.2.1/angular.min.js"></script>



<!-- JavaScript jQuery code from Bootply.com editor  -->

<script type='text/javascript'>

$(document).ready(function() {



});

</script>


</body>
</html>
