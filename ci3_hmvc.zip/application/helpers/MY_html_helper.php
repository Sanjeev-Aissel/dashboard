<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
function __construct() {
	$this->CI = & get_instance ();
}
if ( ! function_exists('pr'))
{
	function pr($data)
	{
		echo '<pre>';	print_r($data);		echo '</pre>';
	}
}
if ( ! function_exists('nf'))
{
	function nf($first_name,$middle_name,$last_name)
	{
		$CI =& get_instance();
		$nameOrder = $CI->session->userdata('name_order');
// 		$nameOrder=3;
		switch($nameOrder){
			case 1: return $first_name." ".$last_name;
			break;
			case 2:
				if($last_name == '')
					return $first_name;
				else
					return $last_name.", ".$first_name;
				break;
			case 3: return $first_name." ".$middle_name." ".$last_name;
			break;
		}
	}
}
if ( ! function_exists('date_display'))
{
	function date_display($date)
	{
		if($date == 0){
			
			$date=' ';
		}
		return $date;
	}
}
if ( ! function_exists('app_date_to_sql_date'))
{
	function app_date_to_sql_date($appDate)
	{
		$date = $appDate;
		if($appDate != ""){
			if(APP_DATE_FORMAT == "MM/DD/YYYYY"){
				$arrDateDate = explode("/",$appDate);
				return $arrDateDate[2]."-".$arrDateDate[0]."-".$arrDateDate[1];
			}
		}
		return $date;
	}
}
if ( ! function_exists('get_html_form'))
{
	function get_html_form($form_details = '')
	{
		$html_form='<form method="post"  class="validateForm"  id="'.$form_details['form_id'].'" ';
		if($form_details['is_multipart']==1){
                    	$html_form.='enctype="multipart/form-data"';
		}
						$html_form.='>';
		$html_form.=form_hidden($form_details['hidden_ids']);
		foreach ($form_details['form_inputs_details'] as $fieldDetails){
			$html_form.='<div class="form-group row" id="'.$fieldDetails['div_id'].'">
		<label class="col-sm-4 col-form-label">'.$fieldDetails['label']['label_name'];
			if($fieldDetails['label']['required']==1){
			$html_form.='<span class="reqd-field-indicator">*</span>';
			}
			$html_form.=':</label>
		<div class="col-sm-8">';
			if(($fieldDetails['type'])=='textarea'){
				$html_form.=form_textarea($fieldDetails['data']);
			}
			elseif(($fieldDetails['type'])=='file'){
				$html_form.=form_upload($fieldDetails['data']);
			}
			else if(($fieldDetails['type'])=='select'){
				$html_form.=form_dropdown($fieldDetails['name'],$fieldDetails['options'],$fieldDetails['selected'],$fieldDetails['data'],$fieldDetails['disabled_options']);
			}
			else if(($fieldDetails['type'])=='radio'){
				foreach ($fieldDetails['options'] as $name=>$value){
					$is_checked=false;
					if($value == $fieldDetails['value'])
						$is_checked=true;
					$html_form.=form_radio($fieldDetails['name'],$value,$is_checked,$fieldDetails['data']);
					$html_form.=$name;
				}
			}
			else if(($fieldDetails['type'])=='checkbox'){
				foreach ($fieldDetails['options'] as $name=>$value){
					$html_form.=form_checkbox($fieldDetails['name'],$value,in_array($value,$fieldDetails['values']),$fieldDetails['data']);
					$html_form.=$name;
				}
			}else if(($fieldDetails['type'])=='choosen'){
				$html_form.='<select name="'.$fieldDetails['name'].'" 
		     			id="'. $fieldDetails['id'].'" 
		     			class="required form-control chosenMultipleSelect" 
		     			multiple="multiple" 
						data-placeholder="'.$fieldDetails['place_holder'].'"';	
		    	 		foreach ($fieldDetails['extra_attributes'] as  $text=>$opt_value){ 
		    	 			$html_form.=$text.'='.$opt_value.' ' ;
		    	 		}
		    	 $html_form.='>';
		    	 foreach ($fieldDetails['options'] as $opt_value=>$text){
				$html_form.='<option value="'.$opt_value.'">'.$text.'</option>';
						 }
				$html_form.='</select>';
			}else if($fieldDetails['type']=='daterange'){
				foreach ($fieldDetails['options'] as  $name=>$value){
						$html_form.='<input type="text" name="'. $name.'" id="'. $name.'" value="'. $value.'" class="required form-control" style="width: 34%;display: inline">';
						$html_form.='&nbsp &nbsp &nbsp';
				}
			}else{
				$html_form.=form_input($fieldDetails['data']);
			}
			$html_form.='     </div>
</div>
';
		}
		$html_form.='<div class="form-group row">
					   			<label class="col-sm-4 col-form-label"></label>
						   		<div class="col-sm-8">
						     		<button type="submit" class="btn btn-primary"  onclick="'.$form_details['submit_function'].'return false;">Save</button>
					         		<button  class="btn btn-primary" onclick="'.$form_details['cancel_function'].'return false;">Cancel</button>
						    	</div>
					 		</div>
                   </form>';
		return  $html_form;
	}
}
if ( ! function_exists('generate_prim_menu'))
{
	function generate_prim_menu($data)
	{
		$page_content="<nav class='navbar navbar-default'>\n<div class='container-fluid'><div class='navbar-header'>\n<button type='button' class='navbar-toggle collapsed' data-toggle='collapse' data-target='#bs-example-navbar-collapse-1' aria-expanded='false'>\n<span class='sr-only'>Toggle navigation</span>\n<span class='icon-bar'></span>\n<span class='icon-bar'></span>\n<span class='icon-bar'></span>\n</button>\n</div>\n<div class='collapse navbar-collapse' id='bs-example-navbar-collapse-1'>\n<ul class='nav navbar-nav'>\n";
		foreach($data as $sub_key=>$sub_value){
			$page_content.="<li><a href='<?php echo base_url();?>".$sub_value[0]."'>".$sub_key."</a></li>\n";
		}
		$page_content.="</ul>\n</div>\n</div>\n</nav>";
		return  $page_content;
	}
}
if ( ! function_exists('generate_sec_menu'))
{
	function generate_sec_menu($data)
	{
// 		print_r($data);exit;
		$secNavContent='<?php
							$current_tab= ltrim($_SERVER["PATH_INFO"],"/");
							$uri_elements=explode("/",$current_tab);
							$url_id=implode("_",$uri_elements);
							$currentModule	= $uri_elements[0];
							$currentController	= $uri_elements[1];
							$currentMethod	= $uri_elements[2];
							$param1	= $uri_elements[3]==""?"":"/".$uri_elements[3];
							$param2	= $uri_elements[4]==""?"":"/".$uri_elements[4];
							$menuGenerator	= "";
							switch ($current_tab) {
										';
		foreach($data as $key=>$value){
			if (!is_numeric($key)) {
				if(sizeof($value)==2){
					continue;
				}
				if($value[1]==1){
					///URL of primary nav
					$prim_uri_elements=explode('/',$value[0]);
					$secNavContent.='case (';
					foreach ($prim_uri_elements as $uri_key=>$uri_value){
						if($uri_value!='$1')
						$secNavContent.='($uri_elements['.$uri_key.']=="'.$uri_value.'") && ';
					}
					$secNavContent.='true):';
				}
				///URLs of secondary navs
				foreach($value as $sub_key=>$sub_value){
					if (!is_numeric($sub_key)) {
						$sec_uri_elements=explode('/',$sub_value[0]);
						$secNavContent.='
										case (';
						foreach ($sec_uri_elements as $uri_key=>$uri_value){
							if($uri_value!='$1'){
								$secNavContent.='($uri_elements['.$uri_key.']=="'.$uri_value.'") && ';
							}else{
								$secNavContent.='($uri_elements['.$uri_key.']!="") && ';
							}
						}
						$secNavContent.='true):';
						///URLs of tertiary navs
						foreach($sub_value as $sub_sub_key=>$sub_sub_value){
							if (!is_numeric($sub_sub_key)) {
								$tert_uri_elements=explode('/',$sub_sub_value[0]);
								$secNavContent.='
										case (';
								foreach ($tert_uri_elements as $uri_key=>$uri_value){
									if($uri_value!='$1'){
										$secNavContent.='($uri_elements['.$uri_key.']=="'.$uri_value.'") && ';
									}else{
										$secNavContent.='($uri_elements['.$uri_key.']!="") && ';
									}
								}
								$secNavContent.='true):';
							}
						}
					}
				}
				$secNavContent.='
															$menuGenerator	.= \' <div id="MainMenu"><div class="list-group panel">';
				foreach($value as $sub_key=>$sub_value){
					if (!is_numeric($sub_key)) {
						//if it contains tertiary navs add caret icon
						if(sizeof($sub_value)>1){
							$secNavContent.='
																<a href="#'.$sub_key.'" class="list-group-item list-group-item-default strong" data-toggle="collapse" data-parent="#MainMenu">
																'.$sub_key.'<span class="caret"></span>';
						}
						else{
							$sub_value[0]=str_replace("/$1","'.\$param1.'",$sub_value[0]);
							
							$url_id=str_replace("/$1","'.$param1.'",$sub_value[0]);
							$url_id=str_replace("/","_",$url_id);
							$url_id=str_replace("\$param1","str_replace('/','_',\$param1)",$url_id);
							
							$secNavContent.='
																<a id="'.$url_id.'" href="\'.base_url().\''.$sub_value[0].'" class="list-group-item list-group-item-default strong '.$url_id.'">
																'.$sub_key;
						}
						$secNavContent.='
																</a>';
						if(sizeof($sub_value)==1){
							continue;
						}
						$secNavContent.='<div class="collapse" id="'.$sub_key.'">
																	';
						foreach($sub_value as $sub_sub_key=>$sub_sub_value){
							if (!is_numeric($sub_sub_key)) {
								$sub_sub_value[0]=str_replace("/$1","'.\$param1.'",$sub_sub_value[0]);
								
								$url_id=str_replace("/$1","'.$param1.'",$sub_sub_value[0]);
								$url_id=str_replace("/","_",$url_id);
								$url_id=str_replace("\$param1","str_replace('/','_',\$param1)",$url_id);
								
								$secNavContent.='<a id="'.$url_id.'" href="\'.base_url().\''.$sub_sub_value[0].'" class="list-group-item '.$url_id.'">'.$sub_sub_key.'
																			 </a>
																			';
							}
						}
						$secNavContent.="</div> ";
					}
				}
				$secNavContent.='
															</div></div> \';
														';
				$secNavContent.='break;
										';
			}
		}
		$secNavContent.=' }
			if(!empty($menuGenerator)){
				echo \'<td class="col-sm-2"><div id="secondaryMenuWrapper">\'.$menuGenerator.\'</div></td>\';
			}
			?>
			<script type="text/javascript">
			var url_id=\'<?php echo $url_id;?>\';
			$(document).ready(function(){
			    $("."+url_id).addClass("highlight_subtab");
			    
			    $("."+url_id).parent().prev().removeClass("collapsed");    
			    $("."+url_id).parent().prev().attr("aria-expanded","true");
			    $("."+url_id).parent().prev().addClass("active");
			
			    $("."+url_id).parent().removeClass("collapse");
			    $("."+url_id).parent().addClass("collapse in");
			});
			</script>	
		';
		return  $secNavContent;
	}
}
if ( ! function_exists('export_as_xls'))
{
	function export_as_xls($arr_export_details,$is_email=false)
	{
// 		pr($arr_export_details);exit;
		require_once APPPATH."third_party/PHPExcel_1.8.0/Classes/PHPExcel.php";
		$objPHPExcel = new PHPExcel();
		foreach ($arr_export_details['sheets'] as $key=>$sheet){
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objPHPExcel->setActiveSheetIndex($key); 
			$objWorksheet->setTitle($sheet['title']);
			$objWorksheet->fromArray($sheet['content'], null,'A1');
			$objPHPExcel->addSheet($objWorksheet);
			
			$objPHPExcel->setActiveSheetIndexByName($sheet['title']);
			$last_column =	$objWorksheet->getHighestColumn();
			$objPHPExcel->getActiveSheet()->getStyle('A1:'.$last_column.'1')->applyFromArray(
					array(
							'font' => array('bold' => true),
							'alignment' => array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER),
							'borders' => array('bottom' => array('style' => PHPExcel_Style_Border::BORDER_MEDIUM)),
						)
					);
		}
		$objPHPExcel->setActiveSheetIndexByName('Worksheet');
		$sheetIndex = $objPHPExcel->getActiveSheetIndex();
		$objPHPExcel->removeSheetByIndex($sheetIndex);
		$objPHPExcel->setActiveSheetIndex(0); 
		
		$filename=$arr_export_details['file_name']; //save our workbook as this file name
		header('Content-Type: application/vnd.ms-excel'); //mime type
		header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name
		header('Cache-Control: max-age=0'); //no cache
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,'Excel2007');
		if($is_email){
			$filePath	= APPPATH."documents/kol_personal_documents/".$filename;
			$objWriter->save($filePath);
			return $filePath;
		}else{
			$objWriter->save('php://output');
		}
	}
}
if ( ! function_exists('export_as_pdf'))
{
	function export_as_pdf($filename,$html)
	{
		require_once APPPATH."third_party/dompdf/dompdf_config.inc.php";
		spl_autoload_register('DOMPDF_autoload');
		$dompdf = new DOMPDF();
		$dompdf->load_html($html);
		$dompdf->render();
		$dompdf->stream("$filename.pdf");
		$CI->load->helper('file');
		write_file("", $dompdf->output());
	}
}
if ( ! function_exists('sql_date_to_app_date'))
{
	function sql_date_to_app_date($sqlDate)
	{
		$sqlDateEl = explode(" ",$sqlDate);
		$sqlDate = $sqlDateEl[0];
		$date = $sqlDate;
		if($sqlDate != ""){
			$arrDateDate = explode("-",$sqlDate);
			if(APP_DATE_FORMAT == "MM/DD/YYYYY"){
				return $arrDateDate[1]."/".$arrDateDate[2]."/".$arrDateDate[0];
			}
		}
		return $date;
	}
}
if ( ! function_exists('get_html_form2'))
{
	function get_html_form2($form_details = '')
	{
		$html_form='<form method="post"  class="validateForm"  id="'.$form_details['form_id'].'" ';
		if($form_details['is_multipart']==1){
			$html_form.='enctype="multipart/form-data"';
		}
		$html_form.='>';
		$html_form.=form_hidden($form_details['hidden_ids']);
		$html_form.='<div class="form-group" id="'.$fieldDetails['div_id'].'">';
		foreach ($form_details['form_inputs_details'] as $fieldDetails){
		$html_form.='<label class="col-sm-3 col-form-label">'.$fieldDetails['label']['label_name'];
			if($fieldDetails['label']['required']==1){
				$html_form.='<span class="reqd-field-indicator">*</span>';
			}
			$html_form.=':</label>
		<div class="col-sm-3" style="margin-bottom: 20px;">';
			if(($fieldDetails['type'])=='textarea'){
				$html_form.=form_textarea($fieldDetails['data']);
			}
			elseif(($fieldDetails['type'])=='file'){
				$html_form.=form_upload($fieldDetails['data']);
			}
			else if(($fieldDetails['type'])=='select'){
				$html_form.=form_dropdown($fieldDetails['name'],$fieldDetails['options'],$fieldDetails['selected'],$fieldDetails['data'],$fieldDetails['disabled_options']);
			}
			else if(($fieldDetails['type'])=='radio'){
				foreach ($fieldDetails['options'] as $name=>$value){
					$html_form.=form_radio($fieldDetails['name'],$value,set_radio($fieldDetails['name'],$fieldDetails['value'],true),$fieldDetails['data']);
					$html_form.=$name;
				}
			}
			else if(($fieldDetails['type'])=='checkbox'){
				foreach ($fieldDetails['options'] as $name=>$value){
					$html_form.=form_checkbox($fieldDetails['name'],$value,in_array($value,$fieldDetails['values']),$fieldDetails['data']);
					$html_form.=$name;
				}
			}else if(($fieldDetails['type'])=='choosen'){
				$html_form.='<select name="'.$fieldDetails['name'].'"
		     			id="'. $fieldDetails['id'].'"
		     			class="required form-control chosenMultipleSelect"
		     			multiple="multiple"
						data-placeholder="'.$fieldDetails['place_holder'].'"';
				foreach ($fieldDetails['extra_attributes'] as  $text=>$opt_value){
					$html_form.=$text.'='.$opt_value.' ' ;
				}
				$html_form.='>';
				foreach ($fieldDetails['options'] as $opt_value=>$text){
					$html_form.='<option value="'.$opt_value.'">'.$text.'</option>';
				}
				$html_form.='</select>';
			}else if($fieldDetails['type']=='daterange'){
				foreach ($fieldDetails['options'] as  $name=>$value){
					$html_form.='<input type="text" name="'. $name.'" id="'. $name.'" value="'. $value.'" class="required form-control" style="width: 34%;display: inline">';
					$html_form.='&nbsp &nbsp &nbsp';
				}
			}else{
				$html_form.=form_input($fieldDetails['data']);
			}
			$html_form.='
</div>
';
		}
		$html_form.='</div>
';
		$html_form.='<div class="form-group row">
						   		<div class="col-sm-12" style="text-align: center;">
						     		<button type="submit" class="btn btn-primary"  onclick="'.$form_details['submit_function'].'return false;">Save</button>
					         		<button  class="btn btn-primary" onclick="'.$form_details['cancel_function'].'return false;">Cancel</button>
						    	</div>
					 		</div>
                   </form>';
		return  $html_form;
	}
}

if(! function_exists('email_config_initializer'))
{
	function email_config_initializer($email_for){
		switch($email_for){
			case 'optinout':
				$config['protocol']  = OPTINOUT_PROTOCOL;
				$config['smtp_host'] = OPTINOUT_HOST;
				$config['smtp_port'] = OPTINOUT_PORT;
				$config['smtp_user'] = OPTINOUT_USER;
				$config['smtp_pass'] = OPTINOUT_PASS;
				$config['mailtype']	 = 'html';
				$config['newline'] = "\r\n";
				$config['crlf'] = "\n";
				$config['charset'] = 'utf-8';
				return $config;
				break;
			case 'profile_request':
				$config['protocol']  = PROFILE_REQUEST_PROTOCOL;
				$config['smtp_host'] = PROFILE_REQUEST_HOST;
				$config['smtp_port'] = PROFILE_REQUEST_PORT;
				$config['smtp_user'] = PROFILE_REQUEST_USER;
				$config['smtp_pass'] = PROFILE_REQUEST_PASS;
				$config['mailtype']	 = 'html';
				return $config;
				break;
			case 'alerts':
				$config['protocol']  = PROTOCOL;
				$config['smtp_host'] = HOST;
				$config['smtp_port'] = PORT;
				$config['smtp_user'] = USER;
				$config['smtp_pass'] = PASS;
				$config['mailtype']	 = 'html';
				return $config;
				break;
			case 'support':
				$config['protocol']  = SUPPORT_PROTOCOL;
				$config['smtp_host'] = SUPPORT_HOST;
				$config['smtp_port'] = SUPPORT_PORT;
				$config['smtp_user'] = SUPPORT_USER;
				$config['smtp_pass'] = SUPPORT_PASS;
				$config['mailtype']	 = 'html';
				return $config;
				break;
			case 'notification':
				$config['protocol']  = NOTIFICATION_PROTOCOL;
				$config['smtp_host'] = NOTIFICATION_HOST;
				$config['smtp_port'] = NOTIFICATION_PORT;
				$config['smtp_user'] = NOTIFICATION_USER;
				$config['smtp_pass'] = NOTIFICATION_PASS;
				$config['mailtype']	 = 'html';
				return $config;
				break;
		}
	}
}