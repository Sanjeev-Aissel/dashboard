<script>
function save_filter(){
	var data={};
	var filter_data={};
	filter_data['postData'] =document.getElementsByName('filterData')[0].value;
	data['filter_name']		=$("#filter_name").val();
	data['filter_data']		=filter_data;
	data['filter_id']		=document.getElementsByName('filter_id')[0].value;
	$.ajax({
		type:'POST',
		url:base_url+'kols/kols/save_filters',
		dataType:'json',
		data:data,
		success:function(respData){
			if(respData.status){
				 $("#responseMsg").html('<div class="alert alert-success" role="alert">Filter is successfully saved</div>');
			}else{
				 $("#responseMsg").html('<div class="alert alert-danger" role="alert">Error in saving filter</div>');
			}
		},
		error:function()
		{
			$("#responseMsg").html('<div class="alert alert-danger" role="alert">Error......!!!!!</div>');
		}
	});
}
function close_dialog(){
	$("#userContainer").dialog("close");
}
</script>
<?php echo $html_form;?>
<div id="responseMsg">
</div>