<?php
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter1(-1);}";
// prepare array of JS files to insert into queue
$queued_js_scripts = array('jquery-ui-1.8.16/ui/jquery.ui.accordion', 'chosen.jquery',
    'jquery/jquery.validate1.9.min','jquery/jquery.maskedinput.min',
    'jQuery.ptTimeSelect/src/jquery.ptTimeSelect');


// add the JS files into queue i.e Append to the existing queue
$prevjs = $this->config->item('js_files_to_load');
if ($prevjs == null)
    $prevjs = array();
    $this->config->set_item('js_files_to_load', array_merge($prevjs, $queued_js_scripts));
    
    $currentMethod = $this->uri->segment(4);
    
    ?>
<link href="<?php echo base_url(); ?>css/chosen.css" media="screen" rel="stylesheet" />
<link href="<?php echo base_url(); ?>js/jQuery.ptTimeSelect/src/jquery.ptTimeSelect.css" media="screen" rel="stylesheet" />
<style>
    #location th {
        text-align: center !important;;
    }
    .ui-jqgrid-title {
        font-size: 13px;
    }
    #time {
        width: 80px;
    }
    .time_data_view tr td{
        text-align: center;
    }
    .time_data_view {
        margin-top: 27px;
    }
    #bestTime>tbody>tr>th{
        border-left: 1px solid #ddd;
    } 
    #bestTime>tbody>tr>th:last-child{
        border-right: 1px solid #ddd;
    } 

    th>span.required{
        color: red !important;
    }
    .saveIcon {
        /*background: url("<?php echo base_url(); ?>images/kolm-sprite-image.png") repeat scroll -223px -30px rgba(0, 0, 0, 0) !important;*/
    }
    #detailsContainer table h6, #dispShortDetail caption, .sectionHeaderTitle {
        /*background:url("<?php echo base_url(); ?>images/kolm-sprite-image.png") repeat-x scroll -2px -236px transparent;*/
        background: #ececec none repeat scroll 0 0;
        box-shadow: 0 0 4px #d1d1d1 inset;
        font-weight: bold;
        color: #222222;
        padding: 4px 10px 4px 5px;
    }
    #detailsContainer table td{
        vertical-align: top;
    }
    #phoneForm table tr td:last{
        width: 50px;
    }
    #detailsContainer form A span, .add_time_data a span {
        /*background: transparent url("<?php echo base_url(); ?>/images/all_icons.png") repeat scroll 24% 36%;
        display: inline-block;
        height: 20px;
        vertical-align: middle;
        width: 20px;*/

        background: url("<?php echo base_url(); ?>/images/add_active.png") no-repeat;
        display: inline-block;
        height: 20px;
        vertical-align: middle;
        width: 20px;
        background-size: 20px;
    }
    #detailsContainer form A span:hover, .add_time_data a span:hover{ 
        background: url("<?php echo base_url(); ?>/images/add_inactive.png") no-repeat;
        display: inline-block;
        height: 20px;
        vertical-align: middle;
        width: 20px;
        background-size: 20px;
    }


    .add_time_data a span {
        margin-right: 11px;
    }

    #detailsContainer form A:hover > span{
        background: url("<?php echo base_url(); ?>/images/add_inactive.png") no-repeat;
        display: inline-block;
        height: 20px;
        vertical-align: middle;
        width: 20px;
        background-size: 20px;
    }
    #detailsContainer form > a.actionIcon {
        margin-top: -15px;
    }
    #dispShortDetail th{
        width: 150px;
        vertical-align: top;
        text-align: right;
    }
    #gridWrapper tr th{
        text-align: center !important;
    }
    #dispShortDetail td{
        vertical-align: top;
    }
    .is_kol_no{
        background-image: url("<?php echo base_url(); ?>images/delete.gif");
        background-repeat: no-repeat;
        display: inline-block;
        width: 20px;
    }
    .is_kol_yes{
        background-image: url("<?php echo base_url(); ?>images/approve.png");
        background-repeat: no-repeat;
        display: inline-block;
        width: 20px;
    }
    #dispShortDetail td img, #detailsContainer td img{
        height: 20px;
        width: 20px;
        cursor: pointer;
        margin-left: 3px;
    }
    .alignRight{
        text-align: right !important;
    }
    #bestTime th {
        text-align: center;
        vertical-align: top;
    }
    .ui-widget-header {
        color: #222222;
        font-weight: bold;
    }
    #best_time td{
        padding:0px !important;
    }

    .time_picker_last {
        left: 1035px !important;
    }

    #disp_phones tr td{
        width: 20%;
    }
    #disp_phones tr th{
        width: 20%;
    }
    #phone_table tr td{
        width: 20%;
    }
    #disp_staffs tr td{
        width: 20%;
    }
    #disp_staffs tr th{
        width: 20%;
    }
    #staff_table tr td{
        width: 20%;
    }
    #disp_emails tr td{
        width: 25%;
    }
    #disp_emails tr th{
        width: 25%;
    }
    #email_table tr td{
        width: 25%;
    }
    #disp_licenses tr td{
        width: 	25%;
    }
    #disp_licenses tr th{
        width: 	25%;
    }
    #license_table tr td{
        width: 	25%;
    }
    #disp_status tr td{
        width: 	20%;
    }
    #disp_status tr th{
        width: 	20%;
    }
    #key_status_table tr td{
        width: 	20%;
    }
     #kol_form .error {
        /* background-image: url(../images/error_medium.gif); */
        background-position: 10px center;
        background-repeat: no-repeat;
        padding: initial !important;
        display: inline;
    }
    #kol_form .error, #kol_form .notice, #kol_form .success {
        padding: .8em;
        background:transparent !important;
        margin-bottom: 0em !important;
    }
    #kol_form table caption{
        background:url("<?php echo base_url(); ?>images/kolm-sprite-image.png") repeat-x scroll -2px -236px transparent;
        font-weight: bold;
        color: #222222;
    }

    #kol_form td label{
        display: block;
        text-align:right;
        padding-right:6px;
        padding-top:2px;
    }
    #kol_form input[type='text']{
        width: 200px;
    }

    #kol_form select{
        width: 210px;
    }
    .contact_restrictions label {
        display: inline-block !important;
        width: 150px;
    }
    .contact_restrictions td {
        text-align: center;
    }
    .ui-disabled{
		opacity: .3;
	    cursor: default!important;
	    pointer-events: none;
	}
	table{
		margin-bottom:0px;
	}
	table.tabularGrid caption {
	    background: #ececec;
	    color: #111111;
	    padding-top: 0px;
	    box-shadow: 0 0 4px #d1d1d1 inset;
	    font-size: 13px;
	    padding: .3em .2em .2em .3em;
	    line-height:21px;
	}
	table.tabularGrid {
		border:0px;
    	border-bottom: 2px solid #DDDDDD;
	}
	#contentWrapper.span-23{
	background-image:none !important;
	}
	#popup_container{
	   word-wrap: break-word;
	}
</style>

<script type="text/javascript">
var primaryStateId = '';
var primaryCityId = '';
var previous_time = "";
var emailCount=0;var phoneCount=0;
$(function () {
	 var validationRules = {
	            first_name: {
	                required: true
	            },
	            last_name: {
	                required: true
	            },
	            email: {
	                officialemail: true
	            },
	            country_id: {
	            	required: true
	            },
	            salutation:{
	            	required: true
	            },
	            lang_id:{
	            	required: true
	            }
	        };
	        var validationMessages = {
	            first_name: {
	                required: "Required"
	            },
	            last_name: {
	                required: "Required"
	            },
	            country_id: {
	                required: "Required"
	            },
	            email: {
	            	required: "Required"
	            },
	            salutation:{
	            	required: "Required"
	            },
	            lang_id:{
	            	required: "Required"
	            }
	        };
    $("#kol_form").validate({
        debug: true,
        onkeyup: false,
        rules: validationRules,
        messages: validationMessages
    });

    jQuery.validator.addMethod("officialemail", function (value, element) {
        if (value != "") {
            var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            return regex.test(value);
        } else {
            return true;
        }
    }, "Invalid email");

});
function langFunction(elem){
	var savetype = $(elem).attr("id");
	  var myselect = document.getElementById("lang_id");
	  var langId = myselect.options[myselect.selectedIndex].value;
	  $.ajax({
          url: '<?php echo base_url() ?>kols/set_lang_url_link/'+langId,
          type: 'post',
          dataType: 'json',
          success: function (returnData) {
        	  saveKolData(savetype);
          }
	  });
}
function saveKolData(savetype){
	var emailSaved = '';
    if (!$("#kol_form").validate().form()) {
    	$('html, body').animate({
            scrollTop: $("#kol_form .error").first().offset().top-30
        });
		 $("#kol_form .error").first().focus();
        return false;
    }
    $('.msgBox').removeClass('success');
    $('.msgBox').addClass('notice');
    $('.msgBox').show();
    $('.msgBox').html('Saving the data... <img src="<?php echo base_url() ?>images/ajax_loader_black.gif" />');
    $.ajax({
        url: '<?php echo base_url() ?>kols/save_opt_ol',
        type: 'post',
        dataType: 'json',
        data: $('#kol_form').serialize() + "&savetype=" + savetype,
        success: function (returnData) {
        	if (returnData.status == true) {
        		emailSaved = returnData.emailId;
        		$('.msgBox').html('<?php echo lang("HCP");?> data saved successfully');
                $('.msgBox').fadeOut(1500);
        	}else {
                $('.msgBox').html('Error saving HCP data');
                $('.msgBox').fadeOut(1500);
            }
        },
        complete: function () {
        	if(typeof emailSaved==='undefined'){
        		window.location	= "<?php echo base_url().'kols/list_kols_client_view';?>";
            }else{
            	jAlert('One time Opt-in/Opt-out link has been generated and sent to '+emailSaved, '', function(result) {
            		window.location	= "<?php echo base_url().'kols/list_kols_client_view';?>";
                });
            }
        }
    });
}

</script>
<div class="msgBox"></div>
<div id="dispShortDetail" class="<?php echo $subContentPage;?>">  
<?php if($displayType=='view') {?>
	<table>
        <tr>
            <td>
                <table>
                    <tr>
                        <th>First Name :</th>
                        <td><?php echo $arrKolData['first_name']; ?></td>
                    </tr>
                    
                    <tr>
                         <th>Middle Name :</th>
                         <td><?php echo $arrKolData['middle_name']; ?></td>
                    </tr>
                    
                </table>
            </td>
            <td>
                <table>
                   <tr>
                        <th>Last Name :</th>
                        <td><?php echo $arrKolData['last_name']; ?></td>
                    </tr>
                    
                    <tr>
                        <th>Email :</th>
                        <td><?php echo $arrKolData['primary_email'];?></td>
                    </tr>
                    
                </table>
            </td>
        </tr>
   </table>
<?php } else {?>
	<form id="kol_form" name="kol_form" action="save_kol" method="post">	
	<table>	
		<input type="hidden" name='profile_type' value="<?php echo $arrKolData['profile_type'];?>"/>
		<input type="hidden" id="kolIdForSave" name="kol_id" value="<?php echo $arrKolData['id']; ?>"/>
		<tr>
            <td style="width: 50%;">
                <table>
                	<tr>
                        <td><label for = "salutation">Salutation<span class = "required">*</span>:</label></td>
                        <td>
							<select name="salutation" id="salutation" class = "required">
								<option value="">-- Select Salutation --</option>
						    	<?php foreach ($arrSalutations as $k=>$row){
						    	if($row!=''){  ?>
						    		<option value="<?php echo $k?>" <?php if($row==$arrSalutations[$arrKolData['salutation']]) echo "Selected" ?>><?php echo $row ?></option>
						    	<?php }} ?>
						    </select>
                        </td>
                    </tr>
                    <tr>
                        <td><label for = "last_name">Last Name<span class = "required">*</span>:</label></td>
                        <td><input type = "text" name = "last_name" id = 'last_name' class = "required" value='<?php echo $arrKolData['last_name'];?>'/>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="email">Country<span class = "required">*</span>:</label></td>
                        <td>
                        	<select name="country_id" id="country_id" class="required">
                        		<option value="">-- Select Country --</option>
                        		
                        		<?php 
                        		if(isset($arrKolData['country_id']) && $arrKolData['country_id']>0){
                        		    $selectedCountryId	= $arrKolData['country_id'];
                        		}
                        		foreach ($arrCountries as $country) { ?>
                                    <option value="<?php echo $country['country_id']; ?>"
                                    <?php
                                    if ($selectedCountryId == $country['country_id'])
                                        echo "selected";
                                    ?>
                                    >
                                    <?php echo $country['country_name']; ?>
                                    </option>
                            	<?php } ?>
                        	</select>
    					</td>
                    </tr>
                </table>
            </td>
            <td style="width: 50%;">
                <table>
                    <tr>
                        <td><label for = "first_name">First Name<span class = "required">*</span>:</label></td>
                        <td><input type = "text" name = "first_name" id = 'first_name' class = "required" value='<?php echo $arrKolData['first_name'];?>'/>
                        </td>
                    </tr>
                    <tr>
                        <td><label for="email">Email<span class = "required">*</span>:</label></td>
                        <td><input type="text" name="email" id="email" class="primaryEmail required" value='<?php echo $arrKolData['primary_email'];?>'/></td>
                    </tr>
                    <tr>
                    	<td><label for="language">Language<span class = "required">*</span>:</label></td>
                    	<td>
                    		<select name="lang_id" id="lang_id" class="required language">
                    			<option value="">-- Select Language --</option>
                    			<?php foreach($languages as $row){ ?>
                    			<?php if(isset($arrKolData['primary_language_id']) && $arrKolData['primary_language_id'] > 0) $selected = $arrKolData['primary_language_id']; else $selected = 4;?>
                        		<option value="<?php echo $row['id']?>" <?php if ($selected == $row['id']) echo "selected";?>><?php echo $row['lang_name'];?></option>
                        		<?php }?>
                        	</select>
                    	</td>
                    </tr>
                    
                </table>
            </td>
	        </tr>
	        <tr>
                    <td colspan="2" style="text-align: center;">
                        <a class="blueButton save_kol" rel="tooltip" href="#" data-original-title="Save <?php echo lang("HCP");?>" id= "save_data" onclick="langFunction(this);">Save</a>
                        <a class="blueButton save_kol" rel="tooltip" href="#" data-original-title="Save and Create Opt-in Link" id="send_email" onclick="langFunction(this);">Save and Create Opt-in Link</a>
                        <a class="blueButton" rel="tooltip" href="<?php echo base_url(); ?>kols/list_kols_client_view" data-original-title="Cancel">Cancel</a>
                    </td>
		                
	        </tr>
	</table>
	</form>
<?php }?>
</div>