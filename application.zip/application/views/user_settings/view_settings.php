<script type="text/javascript" src="<?php echo base_url()?>js/jquery/jquery.validate1.9.min.js"></script>
<style type="text/css">
.menuContainers{
	float: left;
    list-style: none outside none;
    margin-bottom: 0;
    margin-right: 0;
    padding: 0;
    position: relative;
    margin-top: 18px;
}
.menuContainers li{
	/*border-right: 1px solid #CCCCCC;*/
    cursor: pointer;
    margin: 5px 0;
    padding: 5px 10px 5px 0;
    text-align: right;
    width: 141px;
}
.menuContainers li:HOVER{
	background-color: #DDE7F5;
}
.label{
		text-align: right;
	}
.userDetails{
	margin-top: 20px;
}
.userDetails tr th{
	text-align: right;
	margin-left:20px;
}
.userDetails tr td{
	text-align: left;
}
.selectedMenu{
	border-right: 0 !important;
	background-color: #DDE7F5 !important;
	font-weight: bold;
	width: 138px !important;
}
#settingsContainer #settingsContentHolder{
	/*background-color: #D0E5F5;*/
/*    border-left: 1px solid #CCCCCC;*/
    margin-left: 160px;
    min-height: 580px;
}
#settingsContentHolder .profileContent{
	padding: 0px 10px 10px 10px;
	min-height: 250px;
}
.pageWrapper{
	width: 85%; 
	margin: auto;
}
#contentWrapper.span-23 {
	background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
    background-position: 169px 50%;
    background-repeat: repeat-y;
}
</style>
<script type="text/javascript">
	$(document).ready(function(){
		<?php if($type=='password'){?>
		$('#general').removeClass('selectedMenu');
		$('#password').addClass('selectedMenu');
		call_selected_setting("change_password");
		
		<?php }else{?>
		call_selected_setting("general");
		<?php }?>
			$(".menuContainers li.tab").click(function(){
				$(".menuContainers li.tab").removeClass("selectedMenu");
				$(this).addClass("selectedMenu");
			});
		});
	function call_selected_setting(data){
		
			switch(data){
			case 'general': 
				$("#settingsContentHolder .profileContent").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
				$("#settingsContentHolder .profileContent").load(base_url+"user_settings/general");
				break;
			case 'oioo': 
				$("#settingsContentHolder .profileContent").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
				$("#settingsContentHolder .profileContent").load(base_url+"user_settings/optin_optout");
				break;	
			case 'user_profile': 
				$("#settingsContentHolder .profileContent").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
				$("#settingsContentHolder .profileContent").load(base_url+"user_settings/edit_user_profile");
				break;
			case 'change_password':
				$("#settingsContentHolder .profileContent").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
				$("#settingsContentHolder .profileContent").load(base_url+"user_settings/edit_user_password");
				break;
			case 'language': 
				$("#settingsContentHolder .profileContent").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
				$("#settingsContentHolder .profileContent").load(base_url+"user_settings/edit_language");
				break;
			case 'groups': 
				$("#settingsContentHolder .profileContent").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
				$("#settingsContentHolder .profileContent").load(base_url+"user_settings/get_all_users_groups/group");
				break;
			case 'teams':
				$("#settingsContentHolder .profileContent").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
				$("#settingsContentHolder .profileContent").load(base_url+"user_settings/get_all_users_groups/team");
				break;	
			case 'support_email_configure': 
				$("#settingsContentHolder .profileContent").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
				$("#settingsContentHolder .profileContent").load(base_url+"user_settings/support_email_configure");
				break;
			case 'name_format': 
				$("#settingsContentHolder .profileContent").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
				$("#settingsContentHolder .profileContent").load(base_url+"user_settings/name_format");
				break;
                        case 'medintel': 
                              $("#settingsContentHolder .profileContent").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
                              $("#settingsContentHolder .profileContent").load(base_url+"user_settings/medintel");
                              break;
			}
		}
</script>
<?php 
	$userRoleId = $this->session->userdata('user_role_id');
	$clientId   = $this->session->userdata('client_id');
?>
<div id="container">
	<div id="settingsContainer">
		<div id="subContainer">
			<ul class="menuContainers">
				<li class="tab selectedMenu" id="general" onclick="call_selected_setting('general');return false;">General</li>
				<?php
				if(KOL_CONSENT && isset($arrUsersToOptInOptOut)){
					if(in_array($this->session->userdata('user_id'),$arrUsersToOptInOptOut)){
				?>
				<li class="tab" id="oioo" onclick="call_selected_setting('oioo');return false;">Opt-in Process</li>
				<?php } 
				}
				?>
				<li class="tab" id="profile" onclick="call_selected_setting('user_profile');return false;">User Profile</li>
				<li class="tab" onclick="call_selected_setting('change_password');return false;" id="password">Change Password</li>
				<?php if($clientId == INTERNAL_CLIENT_ID){?>
				<li class="tab" onclick="call_selected_setting('language');return false;">Language</li>
				<?php } ?>
				<?php if($clientId == INTERNAL_CLIENT_ID){?>
				<li class="tab userGroups" onclick="call_selected_setting('groups');return false;">Groups</li>
				<?php } ?>
				<?php if($clientId == INTERNAL_CLIENT_ID){?>
				<li class="tab" onclick="call_selected_setting('teams');return false;">Teams</li>
				<?php }?>
				<?php if($clientId == INTERNAL_CLIENT_ID){?>
				<li class="tab" onclick="call_selected_setting('support_email_configure');return false;">Support Email</li>
				<?php }?>
				<?php if($clientId == INTERNAL_CLIENT_ID){?>
				<li class="tab" onclick="call_selected_setting('name_format');return false;">Name Format</li>
				<?php }?>
                <?php if($clientId == INTERNAL_CLIENT_ID){?>
                <li class="tab" onclick="call_selected_setting('users');return false;">Users</li>
                <?php }?>
                                <li class="tab" onclick="call_selected_setting('medintel');return false;">Media Email Alerts</li>
			</ul>
			<div id="settingsContentHolder">
				<div class="profileContent"></div>
			</div>
		</div>
	</div>
</div>