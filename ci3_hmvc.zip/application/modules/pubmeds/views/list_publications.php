<?php
/**
 * File to 'add' Social Media details
 *
 * @author: Ramesh B
 * @created on: 10-01-11
 * @package application.views.publications
 */

	//To show row list in jqgrid
	function listRecordsPerPage($maxRecords=100,$increament=10){
		$rowList="";
		for($i=10;$i<=$maxRecords;$i+=$increament){
			$rowList.=$i.",";
		}
		$rowList=substr($rowList,0,-1);
		return $rowList;
	} 

?>	
<style>
.navbar-global {
  background-color: indigo;
}

.navbar-global .navbar-brand {
  color: white;
}

.navbar-global .navbar-user > li > a
{
  color: white;
}

.navbar-primary {
  background-color: #ccc;
  bottom: 0px;
  left: 0px;
  position: absolute;
  top: 88px;
  width: 200px;
  z-index: 8;
  overflow: hidden;
  -webkit-transition: all 0.1s ease-in-out;
  -moz-transition: all 0.1s ease-in-out;
  transition: all 0.1s ease-in-out;
}

.navbar-primary.collapsed {
  width: 60px;
}

.navbar-primary.collapsed .glyphicon {
  font-size: 22px;
}

.navbar-primary.collapsed .nav-label {
  display: none;
}

.btn-expand-collapse {
    position: absolute;
    display: block;
    left: 0px;
    bottom:0;
    width: 100%;
    padding: 8px 0;
    border-top:solid 1px #666;
    color: grey;
    font-size: 20px;
    text-align: center;
}

.btn-expand-collapse:hover,
.btn-expand-collapse:focus {
    background-color: #222;
    color: white;
}

.btn-expand-collapse:active {
    background-color: #111;
}

.navbar-primary-menu,
.navbar-primary-menu li {
  margin:0; padding:0;
  list-style: none;
}

.navbar-primary-menu li a {
  display: block;
  padding: 10px 18px;
  text-align: left;
  border-bottom:solid 1px #e7e7e7;
  color: #333;
}

.navbar-primary-menu li a:hover {
  background-color: #fff;
  text-decoration: none;
  color: #000;
}

.navbar-primary-menu li a .glyphicon {
  margin-right: 6px;
}

.navbar-primary-menu li a:hover .glyphicon {
  color: #4285F4;
}

.main-content {
  margin-left: 200px;
  padding: 5px 20px;
}

.collapsed + .main-content {
  margin-left: 60px;
}
.nav-tabs { 
	border-bottom: 2px solid #DDD; 
}
.nav-tabs > li.active > a, .nav-tabs > li.active > a:focus, .nav-tabs > li.active > a:hover { 
	border-width: 0;
}
.nav-tabs > li > a { 
	border: none; 
	color: #666; 
}
.nav-tabs > li.active > a, .nav-tabs > li > a:hover {
	border: none; 
	color: #4285F4 !important; 
	background: transparent; 
}
.nav-tabs > li > a::after { 
	content: ""; 
	background: #4285F4; 
	height: 2px; 
	position: absolute; 
	width: 100%; 
	left: 0px; 
	bottom: -1px; 
	transition: all 250ms ease 0s; 
	transform: scale(0); 
}
.nav-tabs > li.active > a::after, .nav-tabs > li:hover > a::after {
 	transform: scale(1); 
}
.tab-nav > li > a::after { 
	background: #21527d none repeat scroll 0% 0%; 
	color: #fff; 
}
.tab-pane {
	padding: 10px 0; 
}
.tab-content{
	padding:10px 20px;
}
img.add-org {
    position: absolute;
    left: 23pc;
    top: 23px;
}
.form-group {
    margin-bottom: 5px;
}
.imageUpload {
    margin-top: 35px;
}
.alert {
    padding: 10px  !important;
    margin-bottom: 0px !important;
    }
.close {
    top: 0px  !important;
    right: 0px  !important;
    font-size:18px;
}  
input#saveContact {
    position: absolute;
    top: 22px;
}  
.gridData{
	padding:0px 0px !important;
}
.panel-heading .colpsible-panel:after {
    
    font-family: 'Glyphicons Halflings'; 
    content: "\e114";    
    float: right;        
    color: #4285f4;         
}
.panel-heading .colpsible-panel.collapsed:after {
    content: "\e080"; 
}
.gridWrapper {
    width: 100% !important;
}
	</style>
	<script type="text/javascript">
	var kolId = '<?php echo $arrKol['vid']?>'; 
		$(function() {
			// Initiate the 'Ternary Navigation
			$("#kolEventsTernaryNav").tabs().addClass("ui-tabs-vertical ui-helper-clearfix" );
		
			// Remove the Surrounding Border
			$("#kolEventsTernaryNav" ).removeClass("ui-widget-content");
		
			// Remove the Round Corner
			$("#kolEventsTernaryNav ul").removeClass("ui-corner-all ui-widget-header");
			
			$("#kolEventsTernaryNav li").removeClass( "ui-corner-top" );
		
			// Add the Custom Class to control View
			$("#kolEventsTernaryNav > div").addClass( "span-20 last" );
		
	
		/*
		* To Move Selcted records into Verifeid publications list
		* @author Vinayak Malladad
		* @since 1.5.2
		* @created on 21/3/2011
		*/
		$("#verify").click(function(){						
			$("#delmodJQBlistPublicationResultSet").remove();
			var sr = jQuery("#JQBlistPublicationResultSet").getGridParam('selarrrow');	
			action = '<?php echo base_url();?>/pubmeds/verified_publications';
			var data = {};
			data['pub_id' ] = sr;
			data['kol_id' ] = kolId;
			
			jQuery.jgrid.del = {
				    caption: "verify",
				    msg: "Move selected record(s) into Verified List?",
				    bSubmit: "Verify",
				    bCancel: "Cancel",
				    processData: "Processing...",
				    top:400,
				    left:500,
				    url:action,
				    delData:data,
				    reloadAfterSubmit:true,
				    afterSubmit:function(response, postdata){				    		
			    		var success=true;
			    		var message="sucess";
			    		var new_id=2;
			    		jQuery("#JQBlistPublicationResultSet").trigger("reloadGrid");
			    		//jQuery("#JQBlistPublicationResultSet").setGridParam({page: 1});
			    		return [success,message,new_id];				    		
			    	}
				};
			
			jQuery("#JQBlistPublicationResultSet").delGridRow( sr, {} );
			//$(".dData").click();
			//$(".ui-icon-closethick").click();			
		});
	
			/*
			* To Move Selcted records into Deleted publications list
			* @author Vinayak Malladad
			* @since 1.5.2
			* @created on 21/3/2011
			*/
			$("#deleteUnVerifiedRecords").click(function(){
				//Get all the selected id's from jqGrid manually
				/*
				var pubValues = new Array();
				$("input.cbox:checked").each(function(){
					var idName=this.id;
					var mySplitResult = idName.split("_");
					
					pubValues.push(mySplitResult[2]);
				});
				*/
				$("#delmodJQBlistPublicationResultSet").remove();
				var delUrl='<?php echo base_url();?>pubmeds/delete_publications';
				var sr = jQuery("#JQBlistPublicationResultSet").getGridParam('selarrrow');
				var data={};
				data['pub_id']=sr;
				data['kol_id' ] = kolId;
				
				jQuery.jgrid.del = {
					    caption: "Delete",
					    msg: "Move selected record(s) into Deleted List?",
					    bSubmit: "Delete",
					    bCancel: "Cancel",
					    processData: "Processing...",
					    url:delUrl,
					    delData:data,
					    reloadAfterSubmit:true,
					    afterSubmit:function(response, postdata){				    		
				    		var success=true;
				    		var message="sucess";
				    		var new_id=2;
				    		jQuery("#JQBlistPublicationResultSet").trigger("reloadGrid");
				    		//jQuery("#JQBlistPublicationResultSet").setGridParam({page: 1});
				    		return [success,message,new_id];				    		
				    	}
					};				
				jQuery("#JQBlistPublicationResultSet").delGridRow( sr, {} );
			});

			
			
			/*
			* To Move Selcted records into Unvarifeid publications list
			* @author Vinayak Malladad
			* @since 1.5.2
			* @created on 21/3/2011
			*/
			$("#unVerify").click(function(){
				$("#delmodJQBlistVarifiedPublicationResultSet").remove();
				var sr = jQuery("#JQBlistVarifiedPublicationResultSet").getGridParam('selarrrow');	
				action = '<?php echo base_url();?>/pubmeds/un_verified_publications';
				var data = {};
				data['pub_id' ] = sr;
				data['kol_id' ] = kolId;
				
				jQuery.jgrid.del = {
					    caption: "Unverify ",
					    msg: "Move selected record(s) into Unverified List?",
					    bSubmit: "Unverify",
					    bCancel: "Cancel",
					    processData: "Processing...",
					    url:action,
					    delData:data,
					    reloadAfterSubmit:true,
					    afterSubmit:function(response, postdata){				    		
				    		var success=true;
				    		var message="sucess";
				    		var new_id=2;
				    		jQuery("#JQBlistPublicationResultSet").trigger("reloadGrid");
				    		//jQuery("#JQBlistPublicationResultSet").setGridParam({page: 1});
				    		return [success,message,new_id];				    		
				    	}
					};
				
				jQuery("#JQBlistVarifiedPublicationResultSet").delGridRow( sr, {} );
			});
	
			/*
			* To Move Selcted records into Deleted publications list
			* @author Vinayak Malladad
			* @since 1.5.2
			* @created on 21/3/2011
			*/
			$("#deleteVerifiedRecords").click(function(){
				$("#delmodJQBlistVarifiedPublicationResultSet").remove();
				var delUrl='<?php echo base_url();?>pubmeds/delete_publications';
				var sr = jQuery("#JQBlistVarifiedPublicationResultSet").getGridParam('selarrrow');	
				var data={};
				data['pub_id']=sr;
				data['kol_id' ] = kolId;
				jQuery.jgrid.del = {
					    caption: "Delete",
					    msg: "Move selected record(s) into Deleted List?",
					    bSubmit: "Delete",
					    bCancel: "Cancel",
					    processData: "Processing...",
					    url:delUrl,
					    delData:data,
					    reloadAfterSubmit:true,
					    afterSubmit:function(response, postdata){				    		
				    		var success=true;
				    		var message="sucess";
				    		var new_id=2;
				    		jQuery("#JQBlistPublicationResultSet").trigger("reloadGrid");
				    		//jQuery("#JQBlistPublicationResultSet").setGridParam({page: 1});
				    		return [success,message,new_id];				    		
				    	}
					};
				
				jQuery("#JQBlistVarifiedPublicationResultSet").delGridRow( sr, {} );
			});
	
			/*
			* To Move  deleted records into Verified publications list
			* @author Vinayak Malladad
			* @since 1.5.2
			* @created on 21/3/2011
			*/
			$("#deleteToVerify").click(function(){
				$("#delmodJQBlistDeletedPublicationResultSet").remove();
				var delUrl='<?php echo base_url();?>pubmeds/verified_publications';
				var sr = jQuery("#JQBlistDeletedPublicationResultSet").getGridParam('selarrrow');	
				var data={};
				data['pub_id']=sr;
				data['kol_id' ] = kolId;
				jQuery.jgrid.del = {
					    caption: "Verify",
					    msg: "Move selected record(s) into Verified List?",
					    bSubmit: "Verify",
					    bCancel: "Cancel",
					    processData: "Processing...",
					    url:delUrl,
					    delData:data,
					    reloadAfterSubmit:true,
					    afterSubmit:function(response, postdata){				    		
				    		var success=true;
				    		var message="sucess";
				    		var new_id=2;
				    		jQuery("#JQBlistPublicationResultSet").trigger("reloadGrid");
				    		//jQuery("#JQBlistPublicationResultSet").setGridParam({page: 1});
				    		return [success,message,new_id];				    		
				    	}
					};

				jQuery("#JQBlistDeletedPublicationResultSet").delGridRow( sr, {} );
			});
	
			/*
			* To Move  deleted records into Verify publications list
			* @author Vinayak Malladad
			* @since 1.5.2
			* @created on 21/3/2011
			*/
			$("#deleteToUnVerify").click(function(){
				$("#delmodJQBlistDeletedPublicationResultSet").remove();
				var delUrl='<?php echo base_url();?>pubmeds/un_verified_publications';
				var sr = jQuery("#JQBlistDeletedPublicationResultSet").getGridParam('selarrrow');	
				var data={};
				data['pub_id']=sr;
				data['kol_id' ] = kolId;
				jQuery.jgrid.del = {
					    caption: "Unverify",
					    msg: "Move selected record(s) into Unverified List?",
					    bSubmit: "Unverify",
					    bCancel: "Cancel",
					    processData: "Processing...",
					    url:delUrl,
					    delData:data,
					    reloadAfterSubmit:true,
					    afterSubmit:function(response, postdata){				    		
				    		var success=true;
				    		var message="sucess";
				    		var new_id=2;
				    		jQuery("#JQBlistPublicationResultSet").trigger("reloadGrid");
				    		//jQuery("#JQBlistPublicationResultSet").setGridParam({page: 1});
				    		return [success,message,new_id];				    		
				    	}
					};
				
				jQuery("#JQBlistDeletedPublicationResultSet").delGridRow( sr, {} );
			});
	
		});	
			/*
			* Listing of Un Verified Publications
			* @author Vinayak Malladad
			* @since 1.5.2
			* @created on 21/3/2011
			*/
			function listUnvarifiedPublications(){
				kolId = '<?php echo $arrKol['vid']?>'; 
						/*
						*jqgrid for Education table
						*/
						jQuery("#JQBlistPublicationResultSet").jqGrid({
						   	url:'<?php echo base_url();?>pubmeds/list_publication_details_analyst/unVerified/'+kolId,
							datatype: "json",
						   	colNames:['Id','','PMID','Journal Name','Article Title', 'Affiliation','Date','Authors','Auth Position','Action'],
						   	colModel:[
								{name:'id',index:'id', hidden:true},
								{name:'is_manual',index:'is_manual', hidden:true},
						   		{name:'pmid',index:'pmid', width:100,editable:true},
						   		{name:'journal_name',index:'journal_name',width:250,editable:true,searchoptions: { sopt: ['eq', 'ne', 'cn']}},
						   		{name:'article_title',index:'article_title',width:300,editable:true},
						   		{name:'affiliation',index:'affiliation',width:300,editable:true,searchoptions: { sopt: ['eq', 'ne', 'cn']}},
						   		{name:'date',index:'date',width:100,editable:true},
						   		{name:'authors',index:'authors',width:200,editable:true},
						   		{name:'auth_pos',index:'auth_pos',width:80,editable:true},
						   		{name:'act',resizable:true,width:80 <?php if($isClientView) echo ' ,hidden:true';?>}		   			
						   	],
						   	rowNum:10,
						   	rowList:paginationValues,
						   	rownumbers: true,
						   	sortable: true, 
						   	autowidth: true, 
						   	loadonce:true,
						   	multiselect: true,
						   	ignoreCase:true,
						   	hiddengrid:false,
						   	height: "auto",	
						   	cellEdit: false, 
						   	cellsubmit: 'clientArray', 	   
						   	pager: '#listlistPublicationPage',
						   	mtype: "POST",
						   	sortname: 'name',
						    viewrecords: true,
						    sortorder: "desc",
						    gridComplete: function(){						     
							    var ids = jQuery("#JQBlistPublicationResultSet").jqGrid('getDataIDs'); 
							    	for(var i=0;i < ids.length;i++){ 
								    	var cl = ids[i];
								    	var ret = jQuery("#JQBlistPublicationResultSet").jqGrid('getRowData', cl);
								    	val = ret.is_manual;	
								    	if(val == 0){								    	
								    		be = "<label onclick=\"deletePublication('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";	
								    	}else{
								    		be = "<label onclick=\"deletePublication('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";	
								    		be += "&nbsp; | &nbsp;";	
								    		be += "<label onclick=\"editPublication('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png' class='editIcon'></label>";
								    	}		    	
								    	jQuery("#JQBlistPublicationResultSet").jqGrid('setRowData',ids[i],{act:be}); 
								    	} 
							    	jQuery("#JQBlistPublicationResultSet").jqGrid('navGrid','hideCol',"id"); 
							    	}, 
							loadComplete: function() {
							    	    $("option[value=100000000]").text('All');
							    	},
							    	
							    							    	
						    jsonReader: { repeatitems : false, id: "0" }, 
						    editurl:"#"		    
						});
						
					
						//jQuery("#JQBlistPublicationResultSet").searchGrid( {multipleSearch:true, overlay:false});
	
	
						//Toolbar search bar below the Table Headers
						jQuery("#JQBlistPublicationResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
						//Toolbar search bar above the Table Headers
						//jQuery("#t_JQBlistPublicationResultSet").height(25).jqGrid('filterGrid',"JQBlistPublicationResultSet",{gridModel:true,gridToolbar:true});
						
						//Toggle Toolbar Search 
						jQuery("#JQBlistPublicationResultSet").jqGrid('navButtonAdd',"#listlistPublicationPage",{
							caption:"Search",title:"Toggle Search",
							onClickButton:function(){ 			
								if(jQuery(".ui-search-toolbar").css("display")=="none") {
									jQuery(".ui-search-toolbar").css("display","");
								} else {
									jQuery(".ui-search-toolbar").css("display","none");
								}							
							} 
						}); 	
						jQuery("#JQBlistPublicationResultSet").jqGrid('gridResize',{minWidth:800,maxWidth:800,minHeight:80, maxHeight:350});
		}
	
	
			/*
			* Listing of  Verified Publications
			* @author Vinayak Malladad
			* @since 1.5.2
			* @created on 21/3/2011
			*/
			function listVerifiedPublications(){
				kolId = '<?php echo $arrKol['vid']?>'; 
				/*
				*jqgrid for Education table
				*/
				jQuery("#JQBlistVarifiedPublicationResultSet").jqGrid({
				   	url:'<?php echo base_url();?>pubmeds/list_publication_details_analyst/verified/'+kolId,
					datatype: "json",
				   	colNames:['Id','','','PMID','Journal Name','Article Title', 'Affiliation','Date','Authors','Auth Position','Action'],
				   	colModel:[
						{name:'id',index:'id', hidden:true},
						{name:'pub_id',index:'pub_id', hidden:true},
						{name:'is_manual',index:'is_manual', hidden:true},
				   		{name:'pmid',index:'pmid', width:100,editable:true},
				   		{name:'journal_name',index:'journal_name',width:250,editable:true,searchoptions: { sopt: ['eq', 'ne', 'cn']}},
				   		{name:'article_title',index:'article_title',width:300,editable:true},
				   		{name:'affiliation',index:'affiliation',width:300,editable:true,searchoptions: { sopt: ['eq', 'ne', 'cn']}},
				   		{name:'date',index:'date',width:100,editable:true},
				   		{name:'authors',index:'authors',width:200,editable:true},
				   		{name:'auth_pos',index:'auth_pos',width:80,editable:true},
				   		{name:'act',resizable:true,width:80 <?php if($isClientView) echo ' ,hidden:true';?>}		   			
				   	],
				   	rowNum:10,
				   	rowList:paginationValues,
				   	rownumbers: true,
				   	autowidth: true, 
				   	loadonce:true,
				   	multiselect: true,
				   	ignoreCase:true,
				   	hiddengrid:false,
				   	height: "auto",		   
				   	pager: '#listVariedPublicationPage',
				   	mtype: "POST",
				   	sortname: 'name',
				    viewrecords: true,
				    sortorder: "desc",
				    gridComplete: function(){						     
					    var ids = jQuery("#JQBlistVarifiedPublicationResultSet").jqGrid('getDataIDs'); 
					    
					    	for(var i=0;i < ids.length;i++){ 
						    	var cl = ids[i];	
						    	var ret = jQuery("#JQBlistVarifiedPublicationResultSet").jqGrid('getRowData', cl);
								var id1= ret.pub_id;
						    	val = ret.is_manual;	
						    	if(val == 0){								    	
						    		be = "<label onclick=\"deletePublication('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";	
						    	}else{
						    		be = "<label onclick=\"deletePublication('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png'class='deleteIcon'></label>";	
						    		be += "&nbsp; | &nbsp;";	
						    		be += "<label onclick=\"editPublication('"+id1+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png' class='editIcon'></label>";
						    	}							    	
						    	jQuery("#JQBlistVarifiedPublicationResultSet").jqGrid('setRowData',ids[i],{act:be}); 
						    	} 
					    	jQuery("#JQBlistVarifiedPublicationResultSet").jqGrid('navGrid','hideCol',"id"); 
					    	}, 
					loadComplete: function() {
					    	    $("option[value=100000000]").text('All');
					    	},
					    							    	
				    jsonReader: { repeatitems : false, id: "0" }, 
				    editurl:"#"		    
				});
	
				//jQuery("#JQBlistVarifiedPublicationResultSet").searchGrid( {multipleSearch:true, overlay:false});
	
				//Toolbar search bar below the Table Headers
				jQuery("#JQBlistVarifiedPublicationResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
				//Toolbar search bar above the Table Headers
				//jQuery("#t_JQBlistPublicationResultSet").height(25).jqGrid('filterGrid',"JQBlistPublicationResultSet",{gridModel:true,gridToolbar:true});
				
				//Toggle Toolbar Search 
				jQuery("#JQBlistVarifiedPublicationResultSet").jqGrid('navButtonAdd',"#listVariedPublicationPage",{
					caption:"Search",title:"Toggle Search",
					onClickButton:function(){ 			
						if(jQuery(".ui-search-toolbar").css("display")=="none") {
							jQuery(".ui-search-toolbar").css("display","");
						} else {
							jQuery(".ui-search-toolbar").css("display","none");
						}							
					} 
				}); 	
	
				jQuery("#JQBlistVarifiedPublicationResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000});
				
		
		}
	
			/*
			* Listing of Deleted Publications
			* @author Vinayak Malladad
			* @since 1.5.2
			* @created on 21/3/2011
			*/
			function listDeletedPublications(){
				kolId = '<?php echo $arrKol['vid']?>'; 
				/*
				*jqgrid for Education table
				*/
				jQuery("#JQBlistDeletedPublicationResultSet").jqGrid({
				   	url:'<?php echo base_url();?>pubmeds/list_publication_details_analyst/deleted/'+kolId,
					datatype: "json",
				   	colNames:['Id','','PMID','Journal Name','Article Title', 'Affiliation','Date','Authors','Auth Position','Action'],
				   	colModel:[
						{name:'id',index:'id', hidden:true},
						{name:'is_manual',index:'is_manual', hidden:true},
				   		{name:'pmid',index:'pmid', width:100,editable:true},
				   		{name:'journal_name',index:'journal_name',width:250,editable:true,searchoptions: { sopt: ['eq', 'ne', 'cn']}},
				   		{name:'article_title',index:'article_title',width:300,editable:true},
				   		{name:'affiliation',index:'affiliation',width:300,editable:true,searchoptions: { sopt: ['eq', 'ne', 'cn']}},
				   		{name:'date',index:'date',width:100,editable:true},
				   		{name:'authors',index:'authors',width:200,editable:true},
				   		{name:'auth_pos',index:'auth_pos',width:80,editable:true},
				   		{name:'act',resizable:true,width:80 <?php if($isClientView) echo ' ,hidden:true';?>}		   			
				   	],
				   	rowNum:10,
				   	rowList:paginationValues,
				   	rownumbers: true,
				   	autowidth: true, 
				   	loadonce:true,
				   	multiselect: true,
				   	ignoreCase:true,
				   	hiddengrid:false,
				   	height: "auto",		   
				   	pager: '#listDeletedPublicationPage',
				   	mtype: "POST",
				   	sortname: 'name',
				    viewrecords: true,
				    sortorder: "desc",
				    gridComplete: function(){						     
					    var ids = jQuery("#JQBlistDeletedPublicationResultSet").jqGrid('getDataIDs'); 
					    	for(var i=0;i < ids.length;i++){ 
						    	var cl = ids[i];	
						    	var ret = jQuery("#JQBlistDeletedPublicationResultSet").jqGrid('getRowData', cl);
						    	val = ret.is_manual;	
						    	if(val == 0){
						    		be = "<label onclick=\"deletePublication('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";				    	
						    	}else{
						    		be = "<label onclick=\"deletePublication('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";	
						    		be += "&nbsp; | &nbsp;";	
						    		be += "<label onclick=\"editPublication('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png' class='editIcon'></label>";			    			    	
						    	}						    	
						    	jQuery("#JQBlistDeletedPublicationResultSet").jqGrid('setRowData',ids[i],{act:be}); 
						    	} 
					    	jQuery("#JQBlistDeletedPublicationResultSet").jqGrid('navGrid','hideCol',"id"); 
					    	}, 
					loadComplete: function() {
					    	    $("option[value=100000000]").text('All');
					    	},
					    							    	
				    jsonReader: { repeatitems : false, id: "0" }, 
				    editurl:"#"		    
				});
				var delUrl='<?php echo base_url();?>pubmeds/delete_publications';
			
				jQuery("#JQBlistDeletedPublicationResultSet").jqGrid('navGrid','#listDeletedPublicationPage',{edit:false,add:false,search:false,refresh:false}, {},{}, {reloadAfterSubmit:false, url:delUrl, onclickSubmit : function(eparams) {
				    var retarr = {};					  
				    var sr = jQuery("#JQBlistDeletedPublicationResultSet").getGridParam('selarrrow');				  
				        retarr = {slr:sr};					   
				   		 return retarr;
					}
				}, {multipleSearch:true} );
				
				/*jQuery("#JQBlistPublicationResultSet").jqGrid('navGrid',
																'#listlistPublicationPage',
																{del:false,add:false,edit:false},
																{},{},{},
																{multipleSearch:true});
				*/
	
				//jQuery("#JQBlistDeletedPublicationResultSet").searchGrid( {multipleSearch:true, overlay:false});
	
	
				//Toolbar search bar below the Table Headers
				jQuery("#JQBlistDeletedPublicationResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
				//Toolbar search bar above the Table Headers
				//jQuery("#t_JQBlistPublicationResultSet").height(25).jqGrid('filterGrid',"JQBlistPublicationResultSet",{gridModel:true,gridToolbar:true});
				
				//Toggle Toolbar Search 
				jQuery("#JQBlistDeletedPublicationResultSet").jqGrid('navButtonAdd',"#listDeletedPublicationPage",{
					caption:"Search",title:"Toggle Search",
					onClickButton:function(){ 			
						if(jQuery(".ui-search-toolbar").css("display")=="none") {
							jQuery(".ui-search-toolbar").css("display","");
						} else {
							jQuery(".ui-search-toolbar").css("display","none");
						}							
					} 
				}); 	
	
				jQuery("#JQBlistDeletedPublicationResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000});
		
		}
	
				/**
				* Delete the 'Education Details'
				*/
				function deletePublication(id){								
					var formAction = '<?php echo base_url();?>pubmeds/delete_publication/'+id;						
					jQuery("#JQBlistPublicationResultSet").jqGrid('delGridRow',id,{reloadAfterSubmit:false,url:formAction});
						  
				}	
	
			$(document).ready(function(){
				$(".nav-tabs li a").click(function(){
					loadSelectedTab(this);
				});
				listUnvarifiedPublications();

				// Settings for the Add publication Dialog Box
				var publicationAddOpts = {
						title: "ADD PUBLICATION",
						modal: true,
						autoOpen: false,
						width: 800,
						dialogClass: "microView",
						position: ['center', 80],
						open: function() {
							//display correct dialog content
						}
				};
				
				$("#publicationAddContainer").dialog(publicationAddOpts);

				$(".ui-icon-closethick").click(function(){
					$("#publicationAddContainer").dialog('option','width',800);
				});
				
			});
	
		
	
			/*
			* To load Seleted tab when clicked
			* @author Vinayak Malladad
			* @since 1.5.2
			* @created on 21/3/2011
			*/
			function loadSelectedTab(selected){
				$("#JQBlistPublicationResultSet").setGridParam({loadonce:false});
				//var select    = $("#kolEventsTernaryNav").tabs("option","selected");
				var select= $(selected).attr('aria-controls');
				switch(select){
					case 'unverified'	:	// As the 'reload' method didn't work for the 'jqgrid', the Table will be removed and will be appended again
								// The method to list the publications will be called once again with the new Year Range values
						
								// Remove the whole JQGrid List content
								$("#genericGridContainer").html("");

								$("#genericGridContainer").html('<table id="JQBlistPublicationResultSet"></table><div id="listlistPublicationPage"></div>');

								listUnvarifiedPublications();
								break;
								
					case 'verified'	: 	$("#genericGridContainer").html("");

								$("#genericGridContainer").html('<table id="JQBlistVarifiedPublicationResultSet"></table><div id="listVariedPublicationPage"></div>');

								listVerifiedPublications();
								break;
					
					case 'deleted'	:	$("#genericGridContainer").html("");

								$("#genericGridContainer").html('<table id="JQBlistDeletedPublicationResultSet"></table><div id="listDeletedPublicationPage"></div>');
		
								listDeletedPublications();
								break;
					case 'un-proce-auth'	:	loadUnprocessedCoAuthPage();
								break;
					case 'proce-auth'	:	loadProcessedCoAuthPage();
								break;
					case 'name-combinations'  :   loadNameCombinations();
								break;
								
					default :	listUnvarifiedPublications();
		
				}
				$("#JQBlistPublicationResultSet").setGridParam({loadonce:true});
			}
			
			function loadUnprocessedCoAuthPage(){
				$('#unProceAuth').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(<?php echo base_url()?>images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
				kolId = '<?php echo $arrKol['vid']?>';
				$("#unProceAuth").load("<?php echo base_url()?>pubmeds/get_unprocessed_co_authors_page/"+kolId,{},
						function(){	$('#unProceAuth').unblock(); }
				);
			}

			function loadProcessedCoAuthPage(){
				$('#proceAuth').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(<?php echo base_url()?>images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
				kolId = '<?php echo $arrKol['vid']?>';
				$("#proceAuth").load("<?php echo base_url()?>pubmeds/get_processed_co_authors_page/"+kolId,{},
						function(){	$('#proceAuth').unblock(); }
				);
			}

			//get selected coAuthors and AliasId and send ajax request to associate
			function associateCoAuthors(){
				kolId = '<?php echo $arrKol['vid']?>';
				var coAuthsIds=$("#unproceCoAuthsList").val();
				var aliasCoAuthId=$("#aliasCoAuthsList").val();
				var data={};
				data['co_auths_ids']=coAuthsIds;
				data['alias_id']=aliasCoAuthId;
				$('#unProceAuth').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(<?php echo base_url()?>images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
				$.ajax({
					url:'<?php echo base_url();?>pubmeds/associate_co_authors/'+kolId,
					data:data,
					type:'post',
					datType:'json',
					success:function(returnData){
						//loadUnprocessedCoAuthPage();
						//remove the processed co authors from the both list
						$("#unproceCoAuthsList option:selected").each(function(){
							$(this).remove();
						 }); 
						for(var i=0; i<coAuthsIds.length; i++) {
							var value = coAuthsIds[i];
							$("#aliasCoAuths option").each(function(){
								if(this.value==value){
									if(this.value != aliasCoAuthId)
										$(this).remove();
								}
							}); 
						}
						$('#unProceAuth').unblock();
					}
				});
			}

			//disassociate the co author from associated co author
			function disassociateCoAuthor(coAuthorId){
				kolId = '<?php echo $arrKol['vid']?>';
				var ele=document.getElementById("proceCoAuthTable");
				var tabHieght=ele.clientHeight;
				var tabWidth=ele.clientWidth;
				var data={};
				data['co_author_id']=coAuthorId;
				jConfirm("Are you sure you want to disassociate?","Please confirm",function(r){
						if(r){
							$('#proceAuth').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(<?php echo base_url()?>images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
							$.ajax({
								url:'<?php echo base_url();?>pubmeds/disassociate_co_author/'+kolId,
								data:data,
								type:'post',
								datType:'json',
								success:function(returnData){
									if(returnData==1){
										$("#coAuth"+coAuthorId).remove();
									}
									$('#proceAuth').unblock();
								}
							});
							}else{
								return false;
								}
					});
			}

		function addPublication(kolId){
			$("#publicationAddProfileContent").val("");
			$(".profileContent").val("");
			$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
			$("#publicationAddContainer").dialog("open");
			$("#publicationAddProfileContent").load('<?php echo base_url()?>/pubmeds/add_publication_analyst/'+kolId);
			return false;	
		}
		function editPublication(id){
			kolId = '<?php echo $arrKol['vid']?>';
			$("#publicationAddProfileContent").val("");
			$(".profileContent").val("");
			$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
			$("#publicationAddContainer").dialog("open");
			$("#publicationAddProfileContent").load('<?php echo base_url()?>pubmeds/edit_publication_manual/'+id+'/'+kolId);
			return false;	
		}

		function crawlPMIDs(){
			$("#publicationAddProfileContent").val("");
			$(".profileContent").val("");
			$(".profileContent").html("<div class='ctmicroViewLoading'>Loading...</div>");
			$("#publicationAddContainer").dialog("open");
			var data = '<h3>Add PMIDs for Crawling</h3><div><center>Enter PMID(s) : <textarea cols="50" rows="3" id="pmids"></textarea> comma(,) separated<br /><button onclick="displayAndProcessPMIDs();">Save and Crawl</button></center></div>';
			$("#publicationAddProfileContent").html(data);
			return false;	
		}

		function displayAndProcessPMIDs(){
			var textareaPmids = $("#pmids").val();
			var arrPmids = textareaPmids.split(",");
			var i=0;
			var batchSize = 10;
			var batchCounter = 0;
			var batchNumber = 1;
			var batchIds = new Array();
			var pmidsLength = arrPmids.length;
			$("#publicationAddProfileContent").html("<div id='pmidsList'> </div>");
			for(i=0; i<pmidsLength; i++){
				batchIds.push(arrPmids[i]);
				batchCounter++;
				if(batchCounter == 10){
					batchCounter = 0;
					displayPmids(batchIds,batchNumber);
					batchNumber++;
					batchIds = new Array();
				}
			}
			if(batchCounter < 10){
				displayPmids(batchIds,batchNumber);
			}

			processPMIDs();
		}

		function displayPmids(batchIds,batchNumber){
			$("#pmidsList").append("<div id='batch"+batchNumber+"' class='pmidBatch pendingBatch'></div>");
			$('#batch'+batchNumber).append("<ul></ul>");
			for(i=0; i<batchIds.length; i++){
				var pmidData = '<li id="'+batchIds[i]+'"> <span class="pmidholder">'+batchIds[i]+'</span> </li>';
				$('#batch'+batchNumber+" ul").append(pmidData);
			}
		}

		function processPMIDs(){
			var data = {};
			var batchIds = new Array();
			$(".pendingBatch:first .pmidholder").each(function(){
				batchIds.push($(this).html());
			});

			if(batchIds.length > 0){
				$(".pendingBatch:first").removeClass("pendingBatch").addClass("currentBatch");
				data['pmids'] =  batchIds;
				$.ajax({
					url:'<?php echo base_url()?>pubmeds/process_pmids/'+kolId,
					data:data,
					type:'post',
					dataType:'json',
					success:function(returnData){
						if(returnData.status == true){
							$(".currentBatch").removeClass("currentBatch").addClass("completedBatch");
							processPMIDs();
						}else{
							$(".currentBatch").addClass("errorBatch");
						}
					},
					error:function(){
						$(".currentBatch").addClass("errorBatch");
					}
				});
			}
		}

		function loadNameCombinations(){
			$('#nameCombinations').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(<?php echo base_url()?>images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
			kolId = '<?php echo $arrKol['vid']?>';
			$("#nameCombinations").load("<?php echo base_url()?>pubmeds/get_name_combinations/"+kolId,{},
					function(){	$('#nameCombinations').unblock(); }
			);
		}
	</script>
<?php $this->load->view('kols/secondary_menu');?>	
<div class="main-content">
	<div class="row">
		<div id="kolTernaryNav" class="col-md-12">
        <!-- Start Nav tabs -->
               <ul class="nav nav-tabs" role="tablist">
                  <li role="Details" class="active"><a href="#unverified" aria-controls="unverified" role="tab" data-toggle="tab">Unverified</a></li>
                  <li role="Details"><a href="#verified" aria-controls="verified" role="tab" data-toggle="tab">Verified</a></li>
                  <li role="Details"><a href="#deleted" aria-controls="deleted" role="tab" data-toggle="tab">Deleted</a></li>
               </ul>
		<!-- End Nav tabs -->
               <div class="tab-content">
               <div>
               	<h5 style="font-weight:bold;color:#656565;">Profile of : Kols Name</h5>
               </div>
        <!-- Start Tab panels -->
                  <div role="tabpanel" class="tab-pane active" id="unverified">
                  			<button id="verify" class="button">Verify</button>	 <button id="deleteUnVerifiedRecords" class="button">Delete</button>		  		
                  </div>
                  <div role="tabpanel" class="tab-pane" id="verified">
                  			<button id="unVerify" class="button">Unverify</button>  <button id="deleteVerifiedRecords" class="button">Delete</button>	
                  </div>
                  <div role="tabpanel" class="tab-pane" id="deleted">
                  			<button id="deleteToVerify" class="button">Verify</button>  <button id="deleteToUnVerify" class="button">Unverify</button>	
                  </div>
        <!-- End Tab panels --> 
        <!-- Generic Grid Panel to load all four respective grid content --> 
			<div class="col-md-12 gridData">
                  <div class="gridWrapper" id="genericGridContainer">
					<table id="JQBlistPublicationResultSet"></table>
					<div id="listlistPublicationPage"></div>
				  </div>
            </div>
		<!-- End of Grid Panel -->   
               </div>     
        </div>
	</div>
</div>	
	<!-- Container for the 'Add publication' modal box -->
	<div id="publicationDailog">	
		<div id="publicationAddContainer" class="microProfileDialogBox">
			<div class="profileContent" id="publicationAddProfileContent"></div>
		</div>
	</div>
	
	<!--End of  Container for the 'Add publication' modal box -->