<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class profile_ratings extends MX_Controller{
	function __construct()
	{
		parent::__construct();
		$this->load->model('profile_rating');
		$this->load->model('helpers/common_helper');
	}
	function show_profile_score_chart($kolId,$specialtyId,$forDashboard = false){
		$data['kolId'] = $kolId;
		$data['specailtyId'] = $specialtyId;
		$data['forDashboard'] = $forDashboard;
		
		$arrAllParameter=array();
		$arr = $this->profile_rating->getCountOfAllParameter($kolId);
		
		$arrSalutations				= array(0=>'',1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$maxCategoriesCount  		= $this->profile_rating->getmaxCategoriesCounts($specialtyId);		
		$maxCountOfIndivdaulParam 	= $this->profile_rating->getMaxCountBySpecialty($specialtyId);
		foreach($arr as $key=>$value){			
			$professional = 'Professional Experience';
			$events = 'Events Presence';
			$research = "Research";
			//Start of Professional
			$arrAllParameter[$professional]['practiseCount'] = $value['practiseCount'];
			$arrAllParameter[$professional]['practiseScore'] = round(((($value['practiseCount']/$maxCountOfIndivdaulParam[0]['max(practiseCount)'])*100)))."%";
			
			
			$arrAllParameter[$professional]['teachingCount'] = $value['teachingCount'];
			$arrAllParameter[$professional]['teachingScore'] = round(((($value['teachingCount']/$maxCountOfIndivdaulParam[0]['max(teachingCount)'])*100)))."%";
			
			$arrAllParameter[$professional]['socialComitteCount'] = $value['socialComitteCount'];
			$arrAllParameter[$professional]['socialComitteScore'] = round((($value['socialComitteCount']/$maxCountOfIndivdaulParam[0]['max(socialComitteCount)'])*100))."%";
			
			$arrAllParameter[$professional]['socialBoardCount'] = $value['socialBoardCount'];
			$arrAllParameter[$professional]['socialBoardScore'] = round((($value['socialBoardCount']/$maxCountOfIndivdaulParam[0]['max(socialBoardCount)'])*100))."%";
			
			$arrAllParameter[$professional]['guidelineCount'] = $value['guidelineCount'];
			$arrAllParameter[$professional]['guidelineBoardScore'] = round((($value['guidelineCount']/$maxCountOfIndivdaulParam[0]['max(guidelineCount)'])*100))."%";
			
			$arrAllParameter[$professional]['governmentCount'] = $value['governmentCount'];
			$arrAllParameter[$professional]['governmentScore'] = round((($value['governmentCount']/$maxCountOfIndivdaulParam[0]['max(governmentCount)'])*100))."%";
			
			$arrAllParameter[$professional]['totalProfessionalCount'] = $value['totalProfessionalCount'];
			$arrAllParameter[$professional]['professionalScore'] = round((($value['totalProfessionalCount']/$maxCategoriesCount[0]['maxProfessionalCount'])*100))."%";
			
			//End of Professional
			
			//Start of Events
			
			$arrAllParameter[$events]['executiveCount']    = $value['executiveCount'];
			$arrAllParameter[$events]['executiveScore']    = round((($value['executiveCount']/$maxCountOfIndivdaulParam[0]['max(executiveCount)'])*100))."%";
			
			$arrAllParameter[$events]['speakingCount']    = $value['speakingCount'];
			$arrAllParameter[$events]['speakingScore']    = round((($value['speakingCount']/$maxCountOfIndivdaulParam[0]['max(speakingCount)'])*100))."%";
			
			$arrAllParameter[$events]['facultyCount']    = $value['facultyCount'];
			$arrAllParameter[$events]['facultyScore']    = round((($value['facultyCount']/$maxCountOfIndivdaulParam[0]['max(facultyCount)'])*100))."%";
			
			$arrAllParameter[$events]['panelistCount']    = $value['panelistCount'];
			$arrAllParameter[$events]['panelistScore']    = round((($value['panelistCount']/$maxCountOfIndivdaulParam[0]['max(panelistCount)'])*100))."%";
			
			$arrAllParameter[$events]['totalEvents']    = $value['totalEvents'];
			$arrAllParameter[$events]['eventScore']    = round((($value['totalEvents']/$maxCategoriesCount[0]['maxEventsPresenceCount'])*100))."%";;
			//end of events
			
			//Start of Research
			$arrAllParameter[$research]['authPosCount']    = $value['authPosCount'];
			$arrAllParameter[$research]['authPosScore']    = round((($value['authPosCount']/$maxCountOfIndivdaulParam[0]['max(authPosCount)']))*100)."%";
			
			
			$arrAllParameter[$research]['trialCount']    = $value['trialCount'];
			$arrAllParameter[$research]['trialScore']    = round((($value['trialCount']/$maxCountOfIndivdaulParam[0]['max(trialCount)'])*100))."%";
			
			$arrAllParameter[$research]['totalResearch']    = $value['totalResearch'];
			$arrAllParameter[$research]['researchScore']    = round((($value['totalResearch']/$maxCategoriesCount[0]['maxResearchCount'])*100))."%";
			$arrAllParameter['Total'] = $value['totalAllScore'];
			$arrAllParameter['kol_name'] = $arrSalutations[$value['salutation']]." ".$value['first_name']." ".$value['middle_name']." ".$value['last_name'];
			
			//echo $kolTotalActivitiesCount;
			$spcilatyId  = $this->profile_rating->gerSpecilatyIdByKol($kolId);
			$maxCount = $this->profile_rating->getMaxTotalCountOfKolBySpecialty($spcilatyId);
			
			//$summMxCountOfAllIndividualParam = array_sum($maxCountOfAllIndividualParam[0]);
			//s$arrAllParameter['Profile Score'] = $value['practiseCount'];
			$arrAllParameter['Profile score'] =round(($arrAllParameter['Total']/$maxCount)*100)."%";
		}
		$data['arrAllParameter'] = $arrAllParameter;
		if($forDashboard){
			$this->load->view('profile_ratings/profile_score_chart',$data);
		}else{
			return $arrAllParameter;
		}
	}
}
?>