<?php
?>
<style type="text/css">
	.record_name{
		padding-left: 5px;
		font-weight:bold;
		letter-spacing:0.5px;
		color:#000099;
		text-decoration:underline;
	}
	#searchResultsContainer {
		margin-top: 0px;
	}
	table.listResultSet {
		margin-top: 0px;
		border: 0px;
	}
	table.listResultSet td{
		border-right: 0px;
	}
	table.listResultSet tr{
		border-bottom: 1px;
	}
	table.listResultSet tr:hover{
		background-color: #d0e5f5;
		background-color: #D3DFED;
	}
	tr.searchPagination:hover{
		background-color: white;
	}
	tr.selectedRow{
		background:#d8dfea repeat-x scroll 50% 50% !important;
	}
	.blockUI .blockMsg .blockPage {
		border: 0px;
	}
	
	#searchResultsContainer .searchResultsMsg {
		padding-right:0px;
		margin-right: 0px;
	}

</style>
	<div class="searchResultsMsg">
			<?php 	if($eventsCount==0) 
						echo "No Events found";
					else{
						if(trim($msg['resFor']) != "Search results for")
							echo "<div id='resFor'>".$msg['resFor']." </div>";
						echo "<div id='countMsg'>".$msg['countMsg']." </div>";
					}
			?>
	</div>
	<?php if($eventsCount!=0){?>
		<table class="listResultSet">
			<tbody>
			<!-- Sart of loop trough each search result, and displaying as a row result -->
				<?php 
					$evenOrOddRow	= true;
					foreach($arrEvents as $eventDetails) {
						if($evenOrOddRow){
							$evenOrOddRow	= false;
						}else{
							$evenOrOddRow	= true;
						}					
				?>
						<tr class="<?php echo ($evenOrOddRow)?'evenRow':'oddRow';?>">
							<td width="1%">
								<div class="microViewIcon" onClick="viewEventMicroProfile('<?php echo $eventDetails['id'];?>'); return false;"></div>
								<!--<label onClick="viewEventMicroProfile('<?php echo $eventDetails['id'];?>');"><img class="micro_view_icon" src="<?php echo base_url().'images/user3.png'?>" /></label>
								-->
							</td>
							<td width="90%">
								<span class="record_name"><?php echo $eventDetails['name'];?></span>
								<?php echo "<br />"; ?>
								<?php echo $eventDetails['session_type'];
									if($eventDetails['session_type'] !='' && $eventDetails['session_name'] !='')
										echo ', '; ?>
								<?php echo $eventDetails['session_name'];
									if($eventDetails['session_name'] !='' && $eventDetails['country']!='')
										echo ', '; ?>
								<?php echo $eventDetails['country']?>
							</td>
							
						</tr>
				<?php }?>
					<tr class="searchPagination" style="background-color: white;">
						<td colspan="4">
							<select id="noOfRecordsPerPage" name="noOfRecordsPerPage" onchange="updateRecordsPerPage()">	
								<?php 
									
									for($i=10;$i<151;$i+=10){
										if($i==$this->ajax_pagination->per_page){
											echo '<option value="'.$i.'" selected="selected">'.$i.'</option>';
										}else{
											echo '<option value="'.$i.'" >'.$i.'</option>';
										}
									}	
									echo '</select> Records Per Page ';
						
									$config['first_link'] = 'First';
									$config['div'] = 'searchResultsContainer'; //Div tag id
									$urlPrfix="";
									if($searchType=='simple')
										$urlPrfix="filter_search_events";
									else
										$urlPrfix="filter_adv_search_events";
									$config['base_url'] = base_url()."kols/".$urlPrfix;
									$config['total_rows'] = $eventsCount;
									$config['per_page'] = $this->ajax_pagination->per_page;
									$config['postVar'] = 'page';
									
									$this->ajax_pagination->initialize($config);
									print $this->ajax_pagination->create_links();
								
								?>		
						</td>
					</tr>
			</tbody>
		</table>
		<?php }?>	