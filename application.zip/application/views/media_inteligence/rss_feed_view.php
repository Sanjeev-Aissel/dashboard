<?php
/**
 * media_ineteligence/rss_feed_view
 * Created By: Yuvaraj M
 * Created On:10-04-2015 11:00 AM
 * Updated on:21-04-2015
 */
?>
<?php
global $controller;

$controller = $this->uri->segment(1);
;
global $pop;
$pop=$popup;
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {reloadSection();}";
?>
<?php
// prepare array of JS files to insert into queue
$queued_js_scripts = array('index/client_index', 'jquery/jquery-ui-1.8.16.datepicket');
// add the JS files into queue i.e Append to the existing queue
$this->config->set_item('js_files_to_load', array_merge($this->config->item('js_files_to_load'), $queued_js_scripts));
?>
<!-- RSS Feeds CSS and JS -->
<!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<link href="http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel="stylesheet">
      <script src="http://code.jquery.com/jquery-1.10.2.js"></script>
      <script src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>-->

<style>
    .ignore_message{
        margin-top: 53px;
        margin-right: 22px;
    }

    .ignore_list{
        border:1px solid;
        margin-top: 48px;
    }

    <?php
    if ($mediaSet == true) {
        echo '.book_mark{display:none !important}';
        echo '.applied_filters{width:98% !important}';
        echo '.left_content{width:100% !important}';
    } else {
        echo '.applied_filters{width:623px !important}';
        echo '.left_content{width:640px !important}';
    }
    ?>
    #table_entity_val{
        float: left;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        width: 100%;
    }
    .entity_mouse_hover{
        background-color: #cccccc;
    }
    .bkmakr_container{
        color: #5f5c5c;
        float: unset;
        margin-left: 130px;
        margin-top: -21px;
    }
    .book_mark_hide{
        color:#fff;
        border-color: #fff;
    }
    /*    label:hover{
            background-color: #898989;
        }*/

    .display_more_entities{
        // overflow-y: auto;
        height:auto;
        border:1px solid #D0CCC9;
        border-color: #D0CCC9;

        width:600px;
    }
    .entity_highlight{
        background-color: #898989;
    }
    .sel_option{
        margin:0px;
        float:left;
        margin-left:34px;
        width:130px;
    }
    select{
        margin: 0px;
        //font-weight: bold;
        color:#000;

    }

    .load_more_entity:hover{
        background-color: #D5DBEC;
    }
    .pople_disease_top_border
    {
        border-top: 1px solid;
        border-color: #C3B8B0;
    }
    h2{
        margin:0;
    }
    #entity_name{
        float:left;
        margin:2px;
    }
    #entity_image{
        float:left;
        margin:4px;
    }
    #entity_val{
        float:left;


    }
    .book_img{
        float:right;
        // margin-left:20px;
        margin-top: 2px;
        margin-right: 3px;
    }
    .do_not_show_img{
        float:left;
        cursor:pointer;
        margin-left:27px;
        margin-top: 3px;

    }
    #entity_count{
        float: left;
        /* margin: 2px; */
        width: 77px;
        /* margin-left: 10px; */
        margin-right: -39px;
        margin-left: 43px;
        color: #847B7B;

    }
    .table_all_cat_count{
        margin-top: 10px;
        text-align: center;
        font-weight: normal;
        color: rgb(124, 124, 124);
    }
    .table_cat_count_font{
        font-size: 16px;
        color: rgb(97, 96, 96);
        font-weight: normal;
    }
    .article_image{
        border-style: ridge;
        margin-right:16px;
        // margin:4px;
        width:100px;
        height:100px;
        border-color:#D0CCC9;
    }
    .entities_list{
        color:#000;

    }
    .fav_image{
        margin-right:5px;

    }
    #hyper{
        font-size: 15px;
    }
    .rss_feed{

        width:1327px;

        height:auto;

        margin-top:30px;


    }
    .refined_more_entities{
        border:1px solid;
        margin-top: 48px;

    }
    h5{
        cursor:pointer;
        margin:4px;
        float:left;
        color:#0000FF;
    }
    .filters{
        margin-left:21px;
        float:left;
        width:1251px;
    }
    .category_group{
        min-height:283px;
        height:auto;
        margin-top: -6px;
        overflow: auto;
    }
    .book_mark{
        float:left;
        margin:10px;
        //width:620px;
        margin-left:15px;
        min-height:1000px;
        height:auto;
        margin-top:-59px;
        border-color:#D0CCC9;
        position: relative;
    }
    .left_content{
        float:left;
        margin:10px;
        width:640px;
        margin-top:0px;
        border-style: ridge;
        //border:2px solid #898989 ;
        height:auto;

        border-color:#D0CCC9;
        margin-left:20px;
    }
    .show_more{
        cursor: pointer;
        background-color: #D0CCC9;

        height:30px;
        text-align:center;
        margin:10px;
        border-style: ridge;


    }
    .table-responsive {
        min-height: .01%;
        /*overflow-x: auto;*/
    }
    label{
        cursor: pointer;
        font-weight: normal;
        margin: 3px;
    }
    .showmore_table_header{
        margin-left: 370px;
    }
    .feed_url{
        margin:10px;

        border-bottom: 1px solid;
        border-color:#D0CCC9;
        text-wrap: normal;
        height:auto;
    }
    .article_content{
        height:auto;
        min-height: 100px;
    }
    /*    .product{
            float:left;
            width:250px;
            height: 283px;
             border:2px solid #898989 ;
             border-color:#D0CCC9;
             margin:10px;
        }*/
    /*    .people{
            float:left;
            width:250px;
            height:auto;
            min-height: 283px;
             border:2px solid #898989 ;
             border-color:#D0CCC9;
             margin:10px;
        }*/
    .cat_class {
        float: left;
        width: 286px;
        height: auto;
        min-height: 242px;
        /* border: 2px solid #898989; */
        /* border-bottom: rgb(186, 169, 147); */
        border-bottom: 1px solid;
        //border-top: 1px solid;
        border-color: #C3B8B0;
        margin: 10px;
    }
    .show_more:hover{
        background-color: #D5DBEC;
    }
    /*     .disease{
            float:left;
            width:250px;
            height:auto;
            min-height: 283px;
             border:2px solid #898989 ;
             border-color:#D0CCC9;
             margin:10px;
        }
         .organization{
            float:left;
            width:250px;
            height: 283px;
             border:2px solid #898989 ;
             border-color:#D0CCC9;
             margin:10px;
        }
        .companies{
            float:left;
            width:250px;
            height: 283px;
             border:2px solid #898989 ;
             border-color:#D0CCC9;
             margin:10px;
        }
        .technology{
            float:left;
            width:250px;
            height: 283px;
             border:2px solid #898989 ;
             border-color:#D0CCC9;
             margin:10px;
        }*/
    .cat_name{
        cursor: pointer;
        color:#000;
        margin:5px;
        height:22px;
    }
    #count{
        float:right;
    }

    #rssfeed_content{
        border:1px solid #1A5C76;
        border-top:5px solid #1A5C76;
        padding-left:10px;
    }

    #tabs1 a{
        display:block;
        width:100px;
        float:left;
        border:1px solid #D0CCC9;
        text-align: center;
        margin-right:5px;
        background-color: #EFEFEF;
        padding: 5px 0;
        text-decoration: none;
        margin-right:0px;
        cursor: pointer;
    }

    #tabs1 div.divider{
        display: inline;
        width: 3px;
        border: 0px;
        border-bottom: 1px solid #D0CCC9;
        display: block;
        float: left;
        height: 29px;
    }
    #tabs1 a.current{
        background-color: #FFFFFF;
        border-bottom:1px solid #FFFFFF;
        z-index: 100;
        color:#1A5C76;
        font-weight: bold;
    }
    /*    #tabs1 div.lastRight{
            width: 188px;
        }
    */
    #tabs1 div.firstRight{
        width: 20px;
    }
    #tabs1{
        padding-left:20px;
        z-index: 1;
        padding-bottom: 29px;
        border-bottom: 1px solid #D0CCC9;
        color:#898989;
        float: left;
        padding-bottom: 0px;
        border-bottom: 0px;
        padding-left:0px;
    }
    #rssfeed_content1 p{
        display: none;
    }
    #rssfeed_content1 ul{
        padding-left: 5px;
        list-style: none;
    }
    #rssfeed_content1 ul{
        list-style: none;
    }
    #rssfeed_content1{
        min-height: 300px;
    }

    .rssFeed{
        border:1px solid #D0CCC9;
        border-top:0px;
        padding-left:20px;
        padding-top: 10px;
    }
    #RSSFEED4 map img{
        display: none;
    }
    .submit{
        float:left;
        display:inline-block;
    }
    .date_picker1 label,.date_picker1 input{
        float:left;
        width:130px;

        display:inline-block;

    }
    .date_picker2 label,.date_picker2 input{
        float: left;
        margin-left: 0px;
        width: 130px;
        display: inline-block;
    }
    .date_picker1 label{
        margin:0px;
        width:50px;
        font-weight: bold;
    }
    .date_picker2 label{
        margin:0px;
        width:50px;
        margin-left:10px;
        font-weight: bold;
    }
    .load_more_entity{
        cursor: pointer;
        background-color: #D0CCC9;
        height:31px;
        margin:10px;
        margin-top:17px;
        text-align:center;

        border-style: ridge;

    }
    .load_more_user_entity{
        cursor: pointer;
        background-color: #D0CCC9;
        border-color: #1A5C76;
        margin:10px;
        margin-top:166px;
        text-align:center;

        border-style: ridge;
        border:2px solid #1A5C76 ;
    }
    h6{
        margin:0;
    }
    #book_mark_content{
        height:auto;
        margin-top: 9px;
    }
    textarea{
        margin:2px;
        resize: vertical;

        width: 579px;
    }
    .previous_comments
    {   margin:8px;
        margin-left:5px;
        width: 579px;
        height:auto;
        border:1px solid;
        min-height: 50px;
        border-color: #D0CCC9;
    }
    .comments{
        display:none;

    }
    #comment_click{
        cursor:pointer;
        font-size: 15px;
        color: #ABABBD;
        margin-left: 13px;
        //margin-top: 32px;
    }
    #comment_submit{

        position:relative;
    }
    .comment_info{
        font-size: 10px;
        color: #898989;
        //margin-top:28px;
    }
    .comment_info b{
        font-size: 10px;
        color: #1A5C76;
        margin:4px;

    }
    .selected_entity{
        background-color: rgb(209, 220, 234);

    }
    .arrowMarkIconMedia{
        background: url("<?php echo base_url() ?>/images/kolm-sprite-image.png") repeat scroll -86px -87px transparent;
        transform: rotate(90deg);
        width: 23px;
        height: 30px;
    }
    .arrowMarkIconTags{
        transform: rotate(90deg);
    }
    .ignore_settings{
        float:left;
        margin-left:580px;
    }
    .tags:hover{
        cursor:pointer;
        color: #0000FF;
    }
    .applied_filters{
        width: 623px;
        margin-top: 14px;
        min-height: 27px;
        margin-bottom: -10px;
        margin-left: 20px;
        color: #C8BFBF;
        border-bottom: 2px solid;


    }
    .arrowMarkIconTags {
        background: url("../images/kolm-sprite-image.png") repeat scroll -86px -87px transparent;
        width: 23px;
        height: 30px;
    }
    #statForm{
        height:auto;
    }
    a{
        cursor:pointer;
    }
    .show_tags tr{
        border:1px solid greenyellow;
        border-style: ridge;

        color:#000;
    }
    .bk_horizontal_line {
        width: 601px;
        height: 2px;
        background-color: #C8BFBF;

    }
    #showStatForm > div {
        margin-bottom: 8px;
        // margin-left: 140px;
    }
    .table_entity_name {
        display: inline-block;
        width: 375px;
        text-wrap: normal;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        margin: -3px;
        margin-left: 2px;
        margin-top:1px;
    }
    .table_show_more {
        height: 29px;
        width: 335px;
    }
    .table_cat_show_more {

        cursor: pointer;
        display: inline-table;

        font-weight: normal;
        margin-right: 11px;
        margin-top: 5px;
    }
    .table_entity_count {
        color:#847B7B;
        display: inline-block;
        width: 52px;
    }
    .entity_name {
        display: inline-block;
        width: 142px;;
        text-wrap: normal;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        margin: -3px;
        margin-left: 2px;
        margin-top:1px;
    }


    .entity_count {
        color:#847B7B;
        display: inline-block;
        width: 52px;
    }
    .cat_show_more:hover{
        color:#847B7B;
    }
    .cat_show_more{
        margin-top: 5px;
        font-weight: normal;
        display: inline-table;
        /* margin-right: 28px; */
        float: right;
        margin-right: 11px;
        color:#0000FF;
        cursor:pointer;
    }
    .show_more_feeds{
        margin-top: 5px;
        font-weight: normal;
        display: inline-table;
        /* margin-right: 28px; */

        margin-right: 11px;
        color:#0000FF;
        cursor:pointer;
    }
    .unbookmark{
        margin-top:20px;
        margin-left: 123px;
        cursor:pointer;
    }
    .ignore_restore{
        margin-top: 10px;
        margin-left: 5px;
        height: 30px;
    }
    h5 img{
        margin: 4px;
        margin-left: 5px;
    }
    h6 input{
        width:270px;
    }
</style>
<?php
$userSettings = $this->session->userdata('userSettings');
if (!isset($userSettings['walkthrough'])) {
    $userSettings['walkthrough'] = 0;
};
?>
<script>
    var onpageLoad = 0;
    var oneMonthStartDate = '';
    var oneMonthEndDate = '';
    var entityName = '';
    $(window).load(function () {
        //insert all your ajax callback code here. 
        //Which will run only after page is fully loaded in background.
        ;
        var myNewsSet='<?php echo $newsExists?>';
        $('.applied_filters').empty();
        onpageLoad = 1;
        if(myNewsSet!='1')
            $("#reset").trigger('click');
        else{
            $('#select_feed_type').val('1');
            $('#select_feed_type').trigger('change');
        }
            

//        var cont = "<?php echo $controller ?>";
//
//        if (cont == "medintel" && localStorage.getItem("disabled") != 1)
//            emailSettings();
    });
    $(document).ready(function () {


        var walkthrough = <?php echo $userSettings['walkthrough'] ?>;
        if (walkthrough !== 1) {
            starthints('overall_introduction');
        }
        var summaryMicroviewDialogOpts = {
            title: "",
            modal: true,
            autoOpen: false,
            width: 600,
            dialogClass: "microView",
            position: ['center', modalBoxTopPosition],
            open: function () {
                //display correct dialog content
            }
        };
        //Initialize the Dialog boxes
        $("#eventContainer").dialog(summaryMicroviewDialogOpts);







    });

    function emailSettings() {
        $.ajax({
            url: "<?php echo base_url() ?>media_intel_extractions/email_option/",
            type: "post",
            async: false,
            dataType: "json",
            success: function (data) {
//											
                if (data.option == 'yes')
                    return false;
                else {
                    if (onpageLoad == 0) {
                        onpageLoad = 1;
                        $("#eventContainer ").html("<div class='microViewLoading'>Loading...</div>");
                        $("#eventContainer").dialog("open");
                        $("#eventContainer").load('<?php echo base_url() ?>user_settings/medintel/1', function () {
                            $("#medintel").append("<center><p>You can always change this preference in settings.</p></center><br/><input onclick='dismiss()' type='checkbox'  >Do not show this message again.");
                        });
                    }
                }
            }
        });




        return false;
    }

    function dismiss() {
        //localStorage.setItem("disabled", "1");
        $('body').trigger('click');
         $.ajax({
            url: "<?php echo base_url() ?>media_intel_extractions/disable_popup/",
            type: "post",
            dataType: "json",
            success: function (data) {

            }
        });
// Retrieve

    }
</script>
<div>





    <div class="filters">
        <form action="" name="topFilters" id="topFilters">
            <div class="date_picker1">
                <label>From:</label>
                <input id="datepicker1" type="text" placeholder="Select date" name="start_date"/>
            </div>
            <div class="date_picker2">
                <label>To:</label>
                <input id="datepicker2" type="text" placeholder="Select date" name="end_date"/>
            </div>
            <div class="submit">

                <input id="submit_date" type="button" value="Go" onclick="loadDataDatewise();"/>
            </div>
            <div class="sel_option">
                <select id="select_feed_type" onchange="loadRssFeeds(null);" name="sel_option" >
                    <option disabled >Select your News</option>
                    <option value="0">All News</option>
                    <option value="1" <?php if (!empty($selectedOption)) echo "selected"; ?>>My News</option>

                </select>
            </div>
            <?php if ($mediaSet == true) { ?>
                <div style="float:right">
                    <input type="button" onclick="openNewTab();
                                return false;" value="View All News" />
                </div>
            <?php } ?>
        </form>

    </div><br/>
    <div >
        <b style="font-weight: normal;margin-left:20px;float:left">Results filtered by:&nbsp;&nbsp</b>
        <div class='applied_filters'>

        </div>
    </div>
    <div class="rss_feed">
        <div class="left_content">
            <?php
            $commentFlag = 0;
            $base = base_url();

            foreach ($result as $value) {
                $date = explode(' ', $value['date']);
                $dateNew = date_create($date[0]);
//                    $old_date_timestamp = strtotime($value['date']);
//                    $new_date = date('M d, Y ', $old_date_timestamp);   
                $new_date = date_format($dateNew, "M d, Y");
                ;
                echo "<div class=\"feed_url\">";
                echo "<img class=\"article_image\" src=" . $value["img_url"] . " align=\"left\" />";


                echo "<div class=\"article_content\">";
                echo "<a id=\"hyper\" target=\"_blank\" onclick=\"logArtcile('" . $value["rss_feed_url"] . "')\" href=" . $value["rss_feed_url"] . "><b>" . $value['title'] . "</b></a><br/>";
                echo "<b>" . $value["publisher"] . ":&nbsp;</b> " . $new_date . "<br/>";
                echo "<p><b></b>" . $value["description"] . "</p><br/>";
                echo "</div>";


                echo "<div id='comment_click' onclick=\"userComments('" . $value["rss_feed_url_id"] . "')\"><img  style='margin-right:5px' src=\"$base/css/images/Coment.png\"  />Comments &nbsp;(";
                foreach ($comment_count as $commentCount) {
                    if ($value["rss_feed_url_id"] == $commentCount["feed_id"]) {
                        echo $commentCount["comment_count"];
                        $commentFlag = 1;
                    }
                }
                if ($commentFlag != 1) {
                    echo "0";
                }

                echo ")";
                if (count($value['bookmarks']) > 0) {
                    //pr($value['bookmarks']['entName']);


                    echo "&nbsp;&nbsp;<img class=\"fav_image\" src=\"$base/css/images/fav.svg\"  />";
                    echo "<b style='color:#0F5FFD'>Fav:&nbsp;</b>";
                    foreach ($value['bookmarks']['entName'] as $bookmark) {
                        foreach ($bookmark as $key => $innerValues) {
                            if ($innerValues == "MedicalCondition") {
                                $category = "disease";
                            }
                            if ($innerValues == "Person") {
                                $category = "people";
                            }
                            if ($innerValues == "Organization") {
                                $category = "organization";
                            }
                            if ($innerValues == "Technology") {
                                $category = "technology";
                            }
                            if ($innerValues == "Company") {
                                $category = "company";
                            }
                            if ($innerValues == "Product") {
                                $category = "product";
                            }
                            $entityIdName = explode("_", $key);
                            $id = $entityIdName[0];
                            $entName = $entityIdName[1];
                            echo "<a onclick=\"loadArticleEntity('$id','$category','$entName')\">" . $entName . "</a>,";
                        }
                    }
                    echo "<b style='color:#0F5FFD'>Tags:</b>" . " ";
                    foreach ($value['bookmarks']["tags"] as $tags) {
                        echo "<i id='$tags' onclick=\"showTags('$tags',this)\" class='tags'>#" . $tags . ",</i> ";
                    }
                    //echo "<br/><br/>";
                }
                echo "</div>";

                echo "<span id='" . $value["rss_feed_url_id"] . "error'></span>";
                echo "<div class='" . $value["rss_feed_url_id"] . "'></div><div id='" . $value["rss_feed_url_id"] . "' class='comments'/><textarea  name='comments' rows='1' cols='10'></textarea><input  id='comment_submit' value='Post' type='button'/>&nbsp;&nbsp;<input  id='cancel_submit' value='Clear' style='background-color:#ff0000 !important' type='button'/></div>";
                echo " </div>";
                $commentFlag = 0;
            }
            ?>

            <div id="load_more" class="show_more" >
                <img  style ="float:left;margin:5px;" src="<?php echo base_url() ?>/css/images/showmore.png"  /><h3><div > <b class="show_more_feeds "  >Show More</b></div></h3>
            </div>
        </div>
        <div class="book_mark">
            <div style="float:left"><h2>In the news  </h2></div><div style="float:right"><div style="float:left;  margin-top: 12px;">Ignored topics list &nbsp;</div><img id="ignore_icon" style="margin-top:10px;margin-right:24px;cursor:pointer" src="<?php echo base_url() ?>/css/images/settings.png" onclick="showIgnoredEntities(this)" /></div>

            <form action="" name="statForm" id="statForm">
                <hr class="bk_horizontal_line"/>
                <div style='float: right;margin-right: 23px;position: absolute;right: 0;'>
                    <div style="float:left">Reset &nbsp;</div><img id="reset" onclick="reset_filters()"  style="cursor:pointer" src="<?php echo base_url(); ?>/css/images/Reset.png"  />
                </div>
                <div id="book_mark_content">
                    <div class="category_group">
                        <div class="people cat_class ">
                            <div id="entity_image">
                                <img  src="<?php echo base_url(); ?>images/contact.svg"  />  
                            </div>
                            <div id="entity_name" class="person_header">
                                <h2>People</h2> <?php
                                foreach ($highlights as $cat_count) {
                                    if ($cat_count['category_name'] == "Person") {
                                        echo "(" . count($person) . " " . " " . "People in" . " " . $cat_count["num"] . "&nbsp;articles)";
                                    }
                                }
                                ?>

                            </div>

                            <hr/>
                            <div id="empty_person">
                                <?php
                                $i = 0;
                                $black_list = 0;
                                foreach ($person as $values) {
                                    foreach ($black_lists as $list_values) {
                                        if ($values["id"] == $list_values["entity_id"])
                                            $black_list = 1;
                                    }
                                    if ($black_list != 1) {
                                        echo "<div class='cat_name' id='" . $values["id"] . "'>";
                                        echo "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id='" . $values["entity_name"] . "'  name='people[]' hidden value='" . $values["id"] . "'/><label title='" . $values["entity_name"] . "' id='" . $values["entity_name"] . "' for='" . $values["entity_name"] . "'><span class='entity_name'>" . $values["entity_name"] . "</span> <span class='entity_count'>" . $values["numc"] . "&nbsp;articles</span> </label></div>";
                                        foreach ($book_marks as $marks) {

                                            if (in_array($values["id"], $marks)) {
                                                echo "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity('" . $values["id"] . "',this)\" class=" . $values["id"] . " src=\"$base/css/images/fav.svg\"  /> </div>";
                                                $flag = 1;
                                            }
                                        }
                                        if ($flag == 0) {
                                            echo "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity('" . $values["id"] . "',this)\" class=" . $values["id"] . " src=\"$base/css/images/unfav.svg\"  /> </div>";
                                        }
                                        $flag = 0;
                                        //echo "<div id='entity_count'>".$values["numc"]." articles </div>";
                                        echo "<div id='abc' class='do_not_show_img '><img  onclick=\"do_not_show_entity('" . $values["id"] . "')\"  src=\"$base/css/images/do_not_show.png\"  /> </div>";
                                        echo "</div>";
                                        $i++;
                                        if ($i > 4) {
                                            $i = 0;
                                            break;
                                        }
                                    }
                                    $black_list = 0;
                                }
                                ?> <b  id="people"  onclick="load_more_refined_entity('people')" class="cat_show_more" >Show More</b>
                            </div>



                        </div>
                        <div class="disease cat_class ">
                            <div id="entity_image">
                                <img  src="<?php echo base_url(); ?>images/stethescope.svg"  />  
                            </div>
                            <div id="entity_name" class="disease_header">
                                <h2>Diseases
                                </h2> 
                                <?php
                                foreach ($highlights as $cat_count) {
                                    if ($cat_count['category_name'] == "MedicalCondition")
                                        echo "(" . count($medical_condition) . " " . "Diseases in" . $cat_count["num"] . "&nbsp;articles)";
                                }
                                ?>
                            </div>

                            <hr/>
                            <div id="empty_disease">
                                <?php
                                $i = 0;
                                $black_list = 0;
                                foreach ($medical_condition as $values) {
                                    foreach ($black_lists as $list_values) {
                                        if ($values["id"] == $list_values["entity_id"])
                                            $black_list = 1;
                                    }
                                    if ($black_list != 1) {
                                        echo "<div class='cat_name' id='" . $values["id"] . "'>";
                                        echo "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id='" . $values["entity_name"] . "'  name='disease[]' hidden value='" . $values["id"] . "'/><label title='" . $values["entity_name"] . "' id='" . $values["entity_name"] . "' for='" . $values["entity_name"] . "'><span class='entity_name'>" . $values["entity_name"] . "</span> <span class='entity_count'>" . $values["numc"] . "&nbsp;articles</span> </label></div>";
                                        foreach ($book_marks as $marks) {

                                            if (in_array($values["id"], $marks)) {
                                                echo "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity('" . $values["id"] . "',this)\" class=" . $values["id"] . " src=\"$base/css/images/fav.svg\"  /> </div>";
                                                $flag = 1;
                                            }
                                        }
                                        if ($flag == 0) {
                                            echo "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity('" . $values["id"] . "',this)\" class=" . $values["id"] . " src=\"$base/css/images/unfav.svg\"  /> </div>";
                                        }
                                        $flag = 0;
                                        //echo "<div id='entity_count'>".$values["numc"]." articles </div>";
                                        echo "<div id='abc' class='do_not_show_img '><img  onclick=\"do_not_show_entity('" . $values["id"] . "')\"  src=\"$base/css/images/do_not_show.png\"  /> </div>";
                                        echo "</div>";
                                        $i++;
                                        if ($i > 4) {
                                            $i = 0;
                                            break;
                                        }
                                    }
                                    $black_list = 0;
                                }
                                ?>  <b id="disease"  onclick="load_more_refined_entity('disease')" class="cat_show_more" >Show More</b>
                            </div>



                        </div>
                    </div>
                    <div class="category_group">
                        <div class="product cat_class">
                            <div id="entity_image">
                                <img  src="<?php echo base_url(); ?>images/product.png"  />  
                            </div>
                            <div id="entity_name" class="product_header">
                                <h2>Product</h2> 
                                <?php
                                foreach ($highlights as $cat_count) {
                                    if ($cat_count['category_name'] == "Product")
                                        echo "(" . count($product) . " " . "Products in &nbsp;" . $cat_count["num"] . "&nbsp;articles)";
                                }
                                ?>
                            </div>

                            <hr/>
                            <div id="empty_product">
                                <?php
                                $i = 0;
                                $black_list = 0;
                                foreach ($product as $values) {
                                    foreach ($black_lists as $list_values) {
                                        if ($values["id"] == $list_values["entity_id"])
                                            $black_list = 1;
                                    }
                                    if ($black_list != 1) {
                                        echo "<div class='cat_name' id='" . $values["id"] . "'>";
                                        echo "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id='" . $values["entity_name"] . "'  name='product[]' hidden value='" . $values["id"] . "'/><label title='" . $values["entity_name"] . "' id='" . $values["entity_name"] . "' for='" . $values["entity_name"] . "'><span class='entity_name'>" . $values["entity_name"] . "</span> <span class='entity_count'>" . $values["numc"] . "&nbsp;articles</span></label></div>";
                                        // echo "<div id='entity_count'>".$values["numc"]." articles</div>";
                                        foreach ($book_marks as $marks) {

                                            if (in_array($values["id"], $marks)) {
                                                echo "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity('" . $values["id"] . "',this)\" class=" . $values["id"] . " src=\"$base/css/images/fav.svg\"  /> </div>";
                                                $flag = 1;
                                            }
                                        }
                                        if ($flag == 0) {
                                            echo "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity('" . $values["id"] . "',this)\" class=" . $values["id"] . " src=\"$base/css/images/unfav.svg\"  /> </div>";
                                        }
                                        echo "<div id='abc' class='do_not_show_img '><img  onclick=\"do_not_show_entity('" . $values["id"] . "')\"  src=\"$base/css/images/do_not_show.png\"  /> </div>";
                                        $flag = 0;

                                        echo "</div>";
                                        $i++;
                                        if ($i > 4) {
                                            $i = 0;
                                            break;
                                        }
                                    }
                                    $black_list = 0;
                                }
                                ?> <b id="product"  onclick="load_more_refined_entity('product')" class="cat_show_more" >Show More</b>
                            </div>



                        </div>
                        <div class="technology cat_class">
                            <div id="entity_image">
                                <img  src="<?php echo base_url(); ?>images/technology.svg"  />  
                            </div>
                            <div id="entity_name" class="technology_header">
                                <h2>Technology</h2> 
                                <?php
                                foreach ($highlights as $cat_count) {
                                    if ($cat_count['category_name'] == "Technology")
                                        echo "(" . count($technology) . " " . "Technologies in &nbsp;" . $cat_count["num"] . "&nbsp;articles)";
                                }
                                ?>
                            </div>

                            <hr/>
                            <div id="empty_technology">
                                <?php
                                $i = 0;
                                $black_list = 0;
                                foreach ($technology as $values) {
                                    foreach ($black_lists as $list_values) {
                                        if ($values["id"] == $list_values["entity_id"])
                                            $black_list = 1;
                                    }
                                    if ($black_list != 1) {
                                        echo "<div class='cat_name' id='" . $values["id"] . "'>";
                                        echo "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id='" . $values["entity_name"] . "'  name='technology[]' hidden value='" . $values["id"] . "'/><label title='" . $values["entity_name"] . "' id='" . $values["entity_name"] . "' for='" . $values["entity_name"] . "'><span class='entity_name'>" . $values["entity_name"] . "</span> <span class='entity_count'>" . $values["numc"] . "&nbsp;articles</span></label></div>";
                                        //echo "<div id='entity_count'>".$values["numc"]." articles</div>";
                                        foreach ($book_marks as $marks) {

                                            if (in_array($values["id"], $marks)) {
                                                echo "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity('" . $values["id"] . "',this)\" class=" . $values["id"] . " src=\"$base/css/images/fav.svg\"  /> </div>";
                                                $flag = 1;
                                            }
                                        }
                                        if ($flag == 0) {
                                            echo "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity('" . $values["id"] . "',this)\" class=" . $values["id"] . " src=\"$base/css/images/unfav.svg\"  /> </div>";
                                        }
                                        echo "<div id='abc' class='do_not_show_img '><img  onclick=\"do_not_show_entity('" . $values["id"] . "')\"  src=\"$base/css/images/do_not_show.png\"  /> </div>";
                                        $flag = 0;

                                        echo "</div>";
                                        $i++;
                                        if ($i > 4) {
                                            $i = 0;
                                            break;
                                        }
                                    }
                                    $black_list = 0;
                                }
                                ?>
                                <b id="technology"  onclick="load_more_refined_entity('technology')" class="cat_show_more" >Show More</b>
                            </div>



                        </div>
                    </div>
                    <div class="category_group">
                        <div class="organization cat_class" >
                            <div id="entity_image">
                                <img  src="<?php echo base_url(); ?>images/organization.svg"  />  
                            </div>
                            <div id="entity_name" class="organization_header">
                                <h2>Organization</h2> 
                                <?php
                                foreach ($highlights as $cat_count) {
                                    if ($cat_count['category_name'] == "Organization")
                                        echo "(" . count($organization) . " " . "Organizations in &nbsp;" . $cat_count["num"] . "&nbsp;articles)";
                                }
                                ?>
                            </div>

                            <hr/>

                            <div id="empty_organization">
                                <?php
                                $i = 0;
                                $black_list = 0;
                                foreach ($organization as $values) {

                                    foreach ($black_lists as $list_values) {
                                        if ($values["id"] == $list_values["entity_id"])
                                            $black_list = 1;
                                    }
                                    if ($black_list != 1) {
                                        echo "<div class='cat_name' id='" . $values["id"] . "'>";
                                        echo "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id='" . $values["entity_name"] . "'  name='organization[]' hidden value='" . $values["id"] . "'/><label title='" . $values["entity_name"] . "' id='" . $values["entity_name"] . "' for='" . $values["entity_name"] . "'><span class='entity_name'>" . $values["entity_name"] . "</span> <span class='entity_count'>" . $values["numc"] . "&nbsp;articles</span></label></div>";
                                        foreach ($book_marks as $marks) {

                                            if (in_array($values["id"], $marks)) {
                                                echo "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity('" . $values["id"] . "',this)\" class=" . $values["id"] . " src=\"$base/css/images/fav.svg\"  /> </div>";
                                                $flag = 1;
                                            }
                                        }
                                        if ($flag == 0) {
                                            echo "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity('" . $values["id"] . "',this)\" class=" . $values["id"] . " src=\"$base/css/images/unfav.svg\"  /> </div>";
                                        }
                                        $flag = 0;
                                        //echo "<div id='entity_count'>".$values["numc"]." articles</div>";
                                        echo "<div id='abc' class='do_not_show_img '><img  onclick=\"do_not_show_entity('" . $values["id"] . "')\"  src=\"$base/css/images/do_not_show.png\"  /> </div>";
                                        echo "</div>";
                                        $i++;
                                        if ($i > 4) {
                                            $i = 0;
                                            break;
                                        }
                                    }
                                    $black_list = 0;
                                }
                                ?>
                                <b id="organization"  onclick="load_more_refined_entity('organization')" class="cat_show_more" >Show More</b>
                            </div>



                        </div>
                        <div class="companies cat_class">
                            <div id="entity_image">
                                <img  src="<?php echo base_url(); ?>images/companies.svg"  />  
                            </div>
                            <div id="entity_name" class="company_header">
                                <h2>Companies</h2> 
                                <?php
                                foreach ($highlights as $cat_count) {
                                    if ($cat_count['category_name'] == "Company")
                                        echo "(" . count($company) . " " . "Companies in &nbsp;" . $cat_count["num"] . "&nbsp;articles)";
                                }
                                ?>
                            </div>

                            <hr/>
                            <div id="empty_company">
                                <?php
                                $i = 0;
                                $black_list = 0;
                                foreach ($company as $values) {
                                    foreach ($black_lists as $list_values) {
                                        if ($values["id"] == $list_values["entity_id"])
                                            $black_list = 1;
                                    }
                                    if ($black_list != 1) {
                                        echo "<div class='cat_name' id='" . $values["id"] . "'>";
                                        echo "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id='" . $values["entity_name"] . "'  name='company[]' hidden value='" . $values["id"] . "'/><label title='" . $values["entity_name"] . "' id='" . $values["entity_name"] . "' for='" . $values["entity_name"] . "'><span class='entity_name'>" . $values["entity_name"] . "</span> <span class='entity_count'>" . $values["numc"] . "&nbsp;articles</span></label></div>";
                                        foreach ($book_marks as $marks) {

                                            if (in_array($values["id"], $marks)) {
                                                echo "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity('" . $values["id"] . "',this)\" class=" . $values["id"] . " src=\"$base/css/images/fav.svg\"  /> </div>";
                                                $flag = 1;
                                            }
                                        }
                                        if ($flag == 0) {
                                            echo "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity('" . $values["id"] . "',this)\" class=" . $values["id"] . " src=\"$base/css/images/unfav.svg\"  /> </div>";
                                        }
                                        $flag = 0;
                                        //echo "<div id='entity_count'>".$values["numc"]." articles </div>";
                                        echo "<div id='abc' class='do_not_show_img '><img  onclick=\"do_not_show_entity('" . $values["id"] . "')\"  src=\"$base/css/images/do_not_show.png\"  /> </div>";
                                        echo "</div>";
                                        $i++;
                                        if ($i > 4) {
                                            $i = 0;
                                            break;
                                        }
                                    }
                                    $black_list = 0;
                                }
                                ?><b id="company"  onclick="load_more_refined_entity('company')" class="cat_show_more" >Show More</b>
                            </div>



                        </div>
                    </div>

                    <div class="category_group" <?php if ($client_id != 1) echo "style='display:none'" ?>>
                        <div class="source cat_class" >
                            <div id="entity_image">
                                <img  src="<?php echo base_url(); ?>images/organization.svg"  />  
                            </div>
                            <div id="entity_name" class="source_header">
                                <h2>Source</h2> 

                                <?php
                                $sourceCount = 0;
                                foreach ($source_links as $source) {

                                    $sourceCount = $sourceCount + $source['numc'];
                                }


                                echo "(" . $sourceCount . " " . "articles  from &nbsp;" . count($source_links) . "&nbsp;sources)";
                                ?>
                            </div>


                            <hr/>

                            <div id="empty_source">
                                <?php
                                $black_list = 0;
                                $i = 0;
                                foreach ($source_links as $values) {



                                    echo "<div class='cat_name ' id='" . $values["id"] . "'>";
                                    echo "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id='" . $values["publisher"] . "'  name='link[]' hidden value='" . $values["id"] . "'/><label title='" . $values["publisher"] . "' id='" . $values["publisher"] . "' for='" . $values["publisher"] . "'><span class='entity_name'>" . $values["publisher"] . "</span> <span class='entity_count'>" . $values["numc"] . "&nbsp;articles</span></label></div>";
                                    echo "</div>";

                                    if ($i > 3)
                                        break;
                                    $i++;
                                }
                                ?>  <b id="source"  onclick="load_more_refined_entity('source')" class="cat_show_more" >Show More</b>
                            </div>



                        </div>
                    </div>
                </div>
                <div id="gridKolsListings">
                    <div class="gridWrappers">
                        <div id="gridKolsListingsPagintaions"></div>
                        <table id="gridKolsListingsResultSets"></table>
                    </div>
                </div>
            </form>
        </div>


    </div>
</div>
<div id="contentHolder"  class="callOutTest microView contentHolder" style="  border-radius: 6px;min-height:173px;position: absolute; top: 231px; left: 319.5px; display: none;width:272px">
    <div>
        <a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeTagDialog();" class="ui-icon ui-icon-closethick">close</span></a>
        <!--<img class="ui-icon ui-icon-closethick" alt="" src="" onclick="closeKolProfile();" />
        -->

    </div>
    <div class="content">
    </div>


<!--    <input type="text" class="autocompleteInputBox" id="tagName" />-->
    <style type="text/css">
        .contactNumber, .faxNumber, .emailId{
            margin-top: 0px;
        }
        #emailHolder{
            display: inline !important;
        }
        .microView .microViewTbl{
            margin-top: 10px;
            margin-bottom: 0px;
            clear: both;
        }
        .microView .microViewTbl th{
            padding-right: 0px;
            padding-left: 0px;
        }
        .microView .microViewTbl span{
            text-align: center;
            background-color: #e3e3e3;
        }
        .microView .kolSpecialty{
            margin-top: 0px;
        }
        .suffix{
            vertical-align: sub;
            font-weight: normal;
            font-size: 10px;
        }
        p.kolName{
            color: #333333;
            font-size: 13px;
            font-weight: bold;
        }
        .microView table td{
            padding-top: 0px;
        }
        .microView .kolAddress{
            background-position:44% 26%;
        }
        /*
        #talkbubble {
        width: 120px;
        height: 80px;
        background: red;
        position: relative;
        -moz-border-radius: 10px;
        -webkit-border-radius: 10px;
        border-radius: 10px;
        }
        #talkbubble:before {
        content:"";
        position: absolute;
        right: 50%;
        top: 100%;
        width: 0;
        height: 0;
        border-left: 13px solid transparent;
        border-right: 13px solid red;
        border-bottom: 26px solid transparent;
        } 
        */
    </style>
    <!-- Start of Micro View -->

</div>
<div id="arraouHolder" class="callOutTest" style="min-height:100px;position: absolute; top: 221px; left: 308.5px; display: none;"><div class="arrowMarkIconMedia "></div></div>
<div id="arraouHolderTags" class="callOutTest" style="min-height:100px;position: absolute; top: 221px; left: 308.5px; display: none;"><div class="arrowMarkIconTags "></div></div>
<script src="<?php echo base_url() ?>js/i18n/grid.locale-en.js" type="text/javascript"></script>	
<script src="<?php echo base_url() ?>js/jquery.jqGrid.min_3.8.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>js/date.format.js" type="text/javascript"></script>
<script type="text/javascript">
            // $('#datepicker1').val(new Date('M d, yy'));
            //  $("#datepicker1").datepicker('setDate', new Date());
            var startDate = new Date();

            $('#datepicker2').val(startDate.format('M j, Y'))

            var myDate = new Date();
            myDate.setDate(myDate.getDate() - 30);
            $('#datepicker1').val("<?php echo date('M j, Y', strtotime("-$fromFilterData days"));?>")

            var show_init_offset = 0;
            var s_i = 1;
            var isShowSet = 0;
            var init_offset = 10;
            var i = 1;
            var datewise_init_offset = 10;
            var d_i = 1;
            var start_date, end_date;
            var flag = 0;
            var reset_values = 0;
            var option = 0;
            var commentResult = 0;
            var socialTagCount = 0;
            var tagClick;
            var tag_name;
            var clickValue = 0;
            var isFromEmail = 0;
            var categoryName = '';
            function displaySelectedFilters(tag_name) {
                var msg = '';
                var separator = '';
                var People = '';
                var Disease = '';
                var Technology = '';
                var Company = '';
                var Organization = '';
                var Product = '';

                //if($('#projectSelection option:selected').text() != "All Projects") 



                var dateFrom = $('#datepicker1').val();
                oneMonthStartDate = dateFrom;

                if (dateFrom != '')
                {
                    dateFrom = new Date(dateFrom);
                    var from = dateFrom.toDateString()
                    from = from.slice(3)
                }
                var dateTo = $('#datepicker2').val();
                oneMonthEndDate = dateTo;


                if (dateTo != '')
                {
                    dateTo = new Date(dateTo);
                    var to = dateTo.toDateString()
                    to = to.slice(3)
                }
                option = $("#select_feed_type option:selected").val();
                $(".rss_feed input[name='people[]']").each(function () {
                    var isChecked = $(this).attr('checked') ? true : false
                    if (isChecked)
                    {
                        People += $(this).attr('id') + "<br/>";
                    }
                });
                $(".rss_feed input[name='disease[]']").each(function () {
                    var isChecked = $(this).attr('checked') ? true : false
                    if (isChecked)
                    {
                        Disease += $(this).attr('id') + "<br/>";
                    }
                });
                $(".rss_feed input[name='organization[]']").each(function () {
                    var isChecked = $(this).attr('checked') ? true : false
                    if (isChecked)
                    {
                        Organization += $(this).attr('id') + "<br/>";
                    }
                });
                $(".rss_feed input[name='technology[]']").each(function () {
                    var isChecked = $(this).attr('checked') ? true : false
                    if (isChecked)
                    {
                        Technology += $(this).attr('id') + "<br/>";
                    }
                });
                $(".rss_feed input[name='company[]']").each(function () {
                    var isChecked = $(this).attr('checked') ? true : false
                    if (isChecked)
                    {
                        Company += $(this).attr('id') + "<br/>";
                    }
                });
                $(".rss_feed input[name='product[]']").each(function () {
                    var isChecked = $(this).attr('checked') ? true : false
                    if (isChecked)
                    {
                        Product += $(this).attr('id') + "<br/>";
                    }
                });
                if (option == 0)
                {
                    msg += '<a  onclick="return false;" rel="tooltip" data-original-title="All news">View Type</a>&nbsp;&nbsp;';
                }
                if (option == 1)
                {
                    msg += '<a  onclick="return false;" rel="tooltip" data-original-title="My news">View Type</a>&nbsp;&nbsp;';
                }
                if (People != '')
                {
                    msg += '<a  onclick="return false;" rel="tooltip" data-original-title="' + People + '">People</a>&nbsp;&nbsp;';
                }
                if (Disease != '')
                {
                    msg += '<a  onclick="return false;" rel="tooltip" data-original-title="' + Disease + '">Disease</a>&nbsp;&nbsp;';
                }
                if (Organization != '')
                {
                    msg += '<a  onclick="return false;" rel="tooltip" data-original-title="' + Organization + '">Organization</a>&nbsp;&nbsp;';
                }
                if (Company != '')
                {
                    msg += '<a  onclick="return false;" rel="tooltip" data-original-title="' + Company + '">Company</a>&nbsp;&nbsp;';
                }
                if (Technology != '')
                {
                    msg += '<a  onclick="return false;" rel="tooltip" data-original-title="' + Technology + '">Technology</a>&nbsp;&nbsp;';
                }
                if (Product != '')
                {
                    msg += '<a  onclick="return false;" rel="tooltip" data-original-title="' + Product + '">Product</a>&nbsp;&nbsp;';
                }

                if (typeof from !== 'undefined' && typeof to !== 'undefined')
                {
                    msg += '<a  onclick="return false;" rel="tooltip" data-original-title="From:&nbsp;' + from + '<br/>To:&nbsp;' + to + '">Date</a>&nbsp;&nbsp;';
                }

                if (typeof tag_name !== 'undefined')
                {
                    msg += '<a  onclick="return false;" rel="tooltip" data-original-title="' + tag_name + '">Tag</a>&nbsp;&nbsp;';
                }
                msg += ' &nbsp;&nbsp;';
                $('.applied_filters').html(msg);
            }

            $("#cancel_submit").live('click', function () {

                $("textarea").val('');


            });

            function loadArticleEntity(entity_id, cat_name, entity_name)
            {
                reset_filters(1);
                var html;
                html = "<input checked=\"checked\" class='load_article' style=\"opacity:0;\" type='checkbox' onclick=\"entity_refine(this)\" id='" + entity_name + "'  name='" + cat_name + "[]' hidden value='" + entity_id + "'/><label style=\"opacity:0;\" id='" + entity_name + "' for='" + entity_name + "'>" + entity_name + " ,</label>";
                $("#statForm").append(html);


                loadRssFeeds();
                loadStats(0, 0, 0, 1);
                $('.load_article').removeAttr('checked');
            }

            function logArtcile(articleUrl)
            {
                $.ajax({
                    url: '<?php echo base_url(); ?>media_intel_extractions/log_article_clicks/',
                    type: 'POST',
                    dataType: 'TEXT',
                    data: {articleUrl: articleUrl},
                    success: function (returnData) {
                        if (returnData == true)
                        {

                        } else
                        {

                        }
                    }
                });
            }
            function loadRssFeeds(offset, filter, tag_name) {
                var start_date = jQuery('input[name="start_date"]').val();
                var end_date = jQuery('input[name="end_date"]').val();
                var date1 = new Date(start_date);
                var date2 = new Date(end_date);
                var timeDiff = Math.abs(date2.getTime() - date1.getTime());
                var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
//                if (diffDays >= 60)
//                    jAlert("Search greater than 60 days might cause some delay in displaying of data.")

                var filterData = {};
                var statFilterss = $("#statForms").serialize();
                if (statFilterss != null && statFilterss != '')
                    filterData += '&' + statFilterss;
                var topFilters = $("#topFilters").serialize();

                if (topFilters != null && topFilters != '')
                    filterData += '&' + topFilters;
                var statFilters = $("#statForm").serialize();
                if (statFilters != null && statFilters != '')
                    filterData += '&' + statFilters;
                var showStatFilters = $("#showStatForm").serialize();
                if (showStatFilters != null && showStatFilters != '')
                    filterData += '&' + showStatFilters;
                if (offset != null)
                {
                    filterData += '&offset=' + offset;
                    if (typeof tagClick !== 'undefined')
                        filterData += '&tag_name=' + tagClick;
                }
                if (typeof tag_name !== 'undefined')
                {
                    filterData += '&tag_name=' + tag_name;
                    tagClick = tag_name;
                }
                $(".applied_filters").empty();

                displaySelectedFilters(tag_name);


                var sel_option = $("#select_feed_type option:selected").val();

                $('.feed_url').block({message: ' ', overlayCSS: {backgroundColor: '#F7F7F7 ', cursor: 'default'}, css: {backgroundImage: 'url(' + base_url + 'images/ajax-loader-round.gif)', backgroundPosition: 'center', backgroundRepeat: 'no-repeat', backgroundColor: 'transparent', border: '0px', height: '30%', cursor: 'default'}});
                $.ajax({
                    url: '<?php echo base_url(); ?>media_intel_extractions/get_feeds/',
                    type: 'POST',
                    dataType: 'JSON',
                    data: filterData,
                    ajax: false,
                    success: function (returnData) {
                        if (returnData == null)
                        {
                            $('.left_content .show_more').hide();//
                            if (offset == null)
                                $('.left_content').empty();
                            $('.left_content').append("<center><h3>No Data to load<center></h3>");
                            $('.feed_url').unblock();
                        } else
                        {
                            if (offset == null)
                                $(".left_content").empty();
                            var i = 0;
                            $('.applied_filters').append("<b style='color:#000;float:right;font-weight:normal'>Displaying:&nbsp;" + returnData[0].feedCount + "&nbsp;article(s)</b>");

                            for (var result in returnData)
                            {
                                i++;
                                var html, feed_id;
                                html = "<div class=\"feed_url\">";
                                html += "<img class='article_image' src='" + returnData[result].img_url + "' align='left' /><br/>";
                                html += "<div class='article_content'>";
                                html += "<a id='hyper' onclick=\"logArtcile('" + returnData[result].rss_feed_url + "');\" target='_blank' href='" + returnData[result].rss_feed_url + "'><b>" + returnData[result].title + "</b></a><br/>";
                                html += "<b>" + returnData[result].publisher + ":</b>" + returnData[result].date + "<br/>";
                                html += "<p>" + returnData[result].description + "</p><br/>";


                                feed_id = returnData[result].rss_feed_url_id;

                                html += "<span id='" + feed_id + "error'></span>";
                                if (returnData[result].commentCount != null)
                                    html += "<div id='comment_click' onclick=\"userComments('" + feed_id + "')\"><img  style='margin-right:5px' src='" + base_url + "/css/images/Coment.png'  />Comments &nbsp;(" + returnData[result].commentCount + ")";
                                else
                                    html += "<div id='comment_click' onclick=\"userComments('" + feed_id + "')\"><img  style='margin-right:5px' src='" + base_url + "/css/images/Coment.png'  />Comments &nbsp;(" + 0 + ")";
                                if (returnData[result].bookmarks !== null) {

                                    html += "<div class='bkmakr_container'><img class='fav_image' src='" + base_url + "/css/images/fav.svg' />";

                                    html += "<b style='color:#0F5FFD'>Fav:&nbsp;</b>";

                                    for (var result1 in returnData[result].bookmarks["entName"])
                                    {
                                        for (var result2 in returnData[result].bookmarks["entName"][result1])
                                        {


                                            var cat;

                                            if (returnData[result].bookmarks["entName"][result1][result2] == "MedicalCondition")
                                            {
                                                cat = "disease";
                                            }
                                            if (returnData[result].bookmarks["entName"][result1][result2] == "Organization")
                                            {
                                                cat = "organization";
                                            }
                                            if (returnData[result].bookmarks["entName"][result1][result2] == "Company")
                                            {
                                                cat = "company";
                                            }
                                            if (returnData[result].bookmarks["entName"][result1][result2] == "Technology")
                                            {
                                                cat = "technology";
                                            }
                                            if (returnData[result].bookmarks["entName"][result1][result2] == "Person")
                                            {
                                                cat = "people";
                                            }
                                            if (returnData[result].bookmarks["entName"][result1][result2] == "Product")
                                            {
                                                cat = "product";
                                            }
                                            var entityNameId = result2.split("_");
                                            var id = entityNameId[0];
                                            var entName = entityNameId[1];
                                            html += "<a onclick=\"loadArticleEntity('" + id + "','" + cat + "','" + entName + "')\">" + entName + "</a>,&nbsp;";


                                        }
                                    }

                                    html += "<b style='color:#0F5FFD'>Tags:</b>" + " ";
                                    for (var tagResult in returnData[result].bookmarks["tags"])
                                        html += "<i id='" + returnData[result].bookmarks["tags"][tagResult] + "' onclick=\"showTags('" + returnData[result].bookmarks["tags"][tagResult] + "',this)\" class='tags'  >#" + returnData[result].bookmarks["tags"][tagResult] + ",</i> ";
                                    html += "</div>";

                                }
                                html += "</div>";
                                html += "<div class='" + feed_id + "'></div><div id='" + feed_id + "' class='comments'><textarea  name='comments' rows='1' cols='10'></textarea><input  id='comment_submit' value='Post' type='button'/>&nbsp;&nbsp;<input  id='cancel_submit' value='Clear' style='background-color:#ff0000 !important' type='button'/>";
                                html += " </div>";
                                commentResult = 0;
                                if (offset == null)
                                {
                                    $(".left_content").append(html);


                                } else
                                {
                                    $('.left_content .show_more').before(html);

                                }

                            }
                            if (offset == null && i > 5)
                                $('.left_content').append("<div id='load_more'   class='show_more'> <img  style ='float:left;margin:5px;'  src='" + base_url + "/css/images/showmore.png'  /><h3><div > <b class=\"show_more_feeds\" >Show More</b></div></h3></div>");


                        }
                        $('.feed_url').unblock();
                    }
                });

            }

            function loadDataDatewise() {
                if ($('#datepicker1').val() == '') {

                    alert("Please Select Start Date");
                    return false;
                }
                if ($('#datepicker2').val() == '') {
                    alert("Please Select End Date");
                    return false;
                }





                if ($('#datepicker2').val() == '' && $('#datepicker1').val() == '') {
                    var startDate = new Date();

                    $('#datepicker2').val(startDate.format('M j, Y'))

                    var myDate = new Date();
                    myDate.setDate(myDate.getDate() - 30);
                    $('#datepicker1').val("<?php echo date('M j, Y', strtotime("-$fromFilterData days"));?>")
                }
                loadRssFeeds();
                loadStats(0, 1);
            }



            var SearchTagNames = {
                serviceUrl: base_url + 'media_intel_extractions/get_tag_names',
                //    <?php echo $autoSearchOptions; ?>,
                onSelect: function (event, ui) {


                    var selText = $(event).children('.tags').html();
                    var selId = $(event).children('.tags').attr('name');
                    selText = selText.replace(/\&amp;/g, '&');
                    $('#tagName').val(selText);
                    $('#specialtyId').val(selId);
                    if (event.length > 20) {
                        if (event.substring(0, 21) == "No results found for ") {
                            return false;
                        } else {
                            $('#tagName').val(selText);
                            var filterElem = '<tr class="tags' + selId + '"><td class="textAlignRight"><input type="checkbox" checked="checked" value="' + selId + '" id="specialty' + selId + '" class="specialtyElement hideCheckbox" name="specialty[]">&nbsp;' + selText + '</td><td class="histoGram"><div class="filterBar"><div class="progress"><div style="width: 0%;" class="bar"></div></div></div></td><td>0</td></tr>'
                            $("#categotySpecialty tbody").append(filterElem);
                            reloadSection();
                        }
                    } else {
                        $('#tagName').val(selText);
                        var filterElem = '<tr class="tags' + selId + '"><td class="textAlignRight"><input type="checkbox" checked="checked" value="' + selId + '" id="specialty' + selId + '" class="specialtyElement hideCheckbox" name="specialty[]">&nbsp;' + selText + '</td><td class="histoGram"><div class="filterBar"><div class="progress"><div style="width: 0%;" class="bar"></div></div></div></td><td>0</td></tr>'
                        $("#categotySpecialty tbody").append(filterElem);
                        reloadSection();
                    }
                }
            }
            var SearchEntityName = {
                serviceUrl: '<?php echo base_url(); ?>media_intel_extractions/search_entity_name/' + categoryName,
<?php echo $autoSearchOptions; ?>,
                        onSelect: function (event, ui) {


                            var selText = $(event).html();
                            var selId = $(event).children('input').attr('id');
                            selText = selText.replace(/\&amp;/g, '&');
                            entityName = $(selText).attr('id');
                            $('#entName').val(selText);
                            $('#specialtyId').val(selId);
                            if (event.length > 20) {
                                if (event.substring(0, 21) == "No results found for ") {
                                    return false;
                                } else {
                                    var idExists = $("tr ." + selId).length
                                    $("#statForm").append("<div class=\"search\" >" + $(event).html() + "</div>");

                                    loadStats();
                                    loadRssFeeds();
                                    // $('.refined_more_entities').hide();
                                    // $('#book_mark_content').show();
                                    load_more_refined_entity(categoryName);

                                    $('.search').empty();

                                    $('#entName').val(selText);
                                    var filterElem = '<tr class="tags' + selId + '"><td class="textAlignRight"><input type="checkbox" checked="checked" value="' + selId + '" id="specialty' + selId + '" class="specialtyElement hideCheckbox" name="specialty[]">&nbsp;' + selText + '</td><td class="histoGram"><div class="filterBar"><div class="progress"><div style="width: 0%;" class="bar"></div></div></div></td><td>0</td></tr>'
                                    $("#categotySpecialty tbody").append(filterElem);
//                                    reloadSection();
                                }
                            } else {
                                $('#entName').val(selText);
                                var filterElem = '<tr class="tags' + selId + '"><td class="textAlignRight"><input type="checkbox" checked="checked" value="' + selId + '" id="specialty' + selId + '" class="specialtyElement hideCheckbox" name="specialty[]">&nbsp;' + selText + '</td><td class="histoGram"><div class="filterBar"><div class="progress"><div style="width: 0%;" class="bar"></div></div></div></td><td>0</td></tr>'
                                $("#categotySpecialty tbody").append(filterElem);
//                                reloadSection();
                            }


                        }
            }
            $(document).ready(function () {

                $('.applied_filters').append("<b style='color:#000;float:right;font-weight:normal'>Displaying:&nbsp;" +<?php echo $feedCount ?> + "&nbsp;article(s)</b>");

<?php if ($selectedOption == "1") { ?>
                    isFromEmail = 1;
<?php } ?>
                if (isFromEmail == 1)
                {
                    loadRssFeeds();
                    loadStats();
                }
                $("#rightSideBar").hide();
                $("#rightSideBarEnableDisable").hide();

                $("h5 img").live({
                    mouseenter: function () {
                        $(this).attr("src", "<?php echo base_url() ?>/css/images/back_active.png");
                        ;
                    },
                    mouseleave: function () {
                        $(this).attr("src", "<?php echo base_url() ?>/css/images/back.png");
                    }
                });
                $(".unbookmark img").live({
                    mouseenter: function () {
                        $(this).attr("src", "<?php echo base_url() ?>/css/images/unbookmark_active.png");
                    },
                    mouseleave: function () {
                        $(this).attr("src", "<?php echo base_url() ?>/css/images/unbookmark.png");
                    }
                });
                $("#ignore_icon").live({
                    mouseenter: function () {
                        $(this).attr("src", "<?php echo base_url() ?>/css/images/settings-active.svg");
                        ;
                    },
                    mouseleave: function () {
                        $(this).attr("src", "<?php echo base_url() ?>/css/images/settings.svg");
                    }
                });
                $("#reset").live({
                    mouseenter: function () {
                        $(this).attr("src", "<?php echo base_url() ?>/css/images/reset_active.svg");
                        ;
                    },
                    mouseleave: function () {
                        $(this).attr("src", "<?php echo base_url() ?>/css/images/Reset.svg");
                    }
                });
                $(".do_not_show_img img").live({
                    mouseenter: function () {
                        $(this).attr("src", "<?php echo base_url() ?>/css/images/delete_active.svg");
                        ;
                    },
                    mouseleave: function () {
                        $(this).attr("src", "<?php echo base_url() ?>/css/images/do_not_show.svg");
                    }
                });
                $("i").live({
                    mouseenter: function () {
                        var tagName = $(this).attr("id");
                        showTagEntitiesOnHover(tagName, this);
                    },
                    mouseleave: function () {
                        closeTagDialog();
                    }
                });
                $("#tagName").live('click', function () {

                    var id = $(this).attr("id");
                    $('#' + id).autocomplete(SearchTagNames);
                });
                $("#entName").live('click', function () {

                    var id = $(this).attr("id");
                    var people = [];
                    var disease = [];
                    var product = [];
                    var technology = [];
                    var organization = [];
                    var company = [];
                    $("#statForm input[name='people[]']:checked").each(function () {
                        people.push($(this).val());

                    });
                    $("#statForm input[name='disease[]']:checked").each(function () {
                        disease.push($(this).val());

                    });
                    $("#statForm input[name='organization[]']:checked").each(function () {
                        organization.push($(this).val());
                    });
                    $("#statForm input[name='product[]']:checked").each(function () {
                        product.push($(this).val());
                    });
                    $("#statForm input[name='technology[]']:checked").each(function () {
                        technology.push($(this).val());
                    });
                    $("#statForm input[name='company[]']:checked").each(function () {
                        company.push($(this).val());
                    });
                    var start_date = jQuery('input[name="start_date"]').val();
                    var end_date = jQuery('input[name="end_date"]').val();
                    var loadMoreClick = 1;
                    var sel_option = $("#select_feed_type option:selected").val();
                    if (people.length == 0)
                        people.push(0);
                    if (disease.length == 0)
                        disease.push(0);
                    if (technology.length == 0)
                        technology.push(0);
                    if (product.length == 0)
                        product.push(0);
                    if (company.length == 0)
                        company.push(0);
                    if (organization.length == 0)
                        organization.push(0);
                    if (start_date == '')
                        start_date = 0;
                    if (end_date == '')
                        end_date = 0;
                    SearchEntityName.serviceUrl = '<?php echo base_url(); ?>media_intel_extractions/search_entity_name/' + categoryName + '/' + people + '/' + organization + '/' + company + '/' + product + '/' + technology + '/' + disease + '/' + sel_option + '/' + start_date + '/' + end_date;
                    $('#' + id).autocomplete(SearchEntityName);

                });
                $(" .cat_name").live({
                    mouseenter: function () {
                        $(this).addClass("entity_mouse_hover");
                    },
                    mouseleave: function () {
                        $(this).removeClass("entity_mouse_hover");
                    }
                });

                $('#select_feed_type').change(function () {
                    $('.display_more_entities').hide();
                    $('#book_mark_content').show();

                    option = $("#select_feed_type option:selected").val();
                    if (option == "0")
                    {

                        flag = 0;

                        $('#empty_disease').empty();
                        $('#empty_product').empty();
                        $('#empty_technology').empty();
                        $('#empty_organization').empty();
                        $('#empty_company').empty();
                        $('#Person').show();
                        $('#MedicalCondition').show();
                        $('#Product').show();
                        $('#technology').show();
                        $('#Organization').show();
                        $('#Company').show();
                        $('.load_more_user_entity').hide();

                        loadStats();

                    } else
                    {

                        loadStats();

                    }

                });




                $('#comment_submit').live("click", function () {
                    var feed_id = $(this).closest('div').attr('id');
                    var comment = $("#" + feed_id + " textarea").val();
                    if (comment == '')
                    {
                        $('#' + feed_id + "error").empty();
                        $('#' + feed_id + "error").append("<b style='color:#ff0000'>Comment cannot be left blank</b>");
                    } else
                    {
                        $('#' + feed_id + "error").empty();
                        $.ajax({
                            url: '<?php echo base_url(); ?>media_intel_extractions/user_comments/',
                            type: 'POST',
                            dataType: 'JSON',
                            data: {feed_id: feed_id, comment: comment},
                            success: function (returnData) {
                                $("." + feed_id).prepend("<div class='previous_comments'><div class='comment_info'><b>Posted by" + " " + returnData.first_name + "&nbsp;" + returnData.last_name + "</b></div>" + "<p style='margin:4px;  margin-bottom: -18px;'>" + comment + "</p>" + "<br/> " + "<p style='font-size:9px;margin:4px'>" + returnData.date + "</p>" + "</div>");
                                $("#" + feed_id + " textarea").val('');
                            }
                        });

                    }


                });




                $("#datepicker1").click(function () {
                    $('#datepicker1').datepicker({dateFormat: 'M d, yy'});
                    $('#datepicker1').datepicker("show");



                });
                $("#datepicker2").click(function () {
                    $('#datepicker2').datepicker({dateFormat: 'M d, yy'});
                    $('#datepicker2').datepicker("show");



                });




            });
            $('#load_more').live('click', function () {

                var offset = init_offset * i;
                loadRssFeeds(offset);
                i++;
            });

            function load_more_datewise()
            {

                var offset = datewise_init_offset * d_i;
                loadRssFeeds(offset);
                d_i++;


            }
            ;

            var filter = [];

            function entity_refine(thisEle, eName, showMoreClick)
            {
                init_offset = 10;
                i = 1;
                datewise_init_offset = 10;
                d_i = 1;
                //alert(showMoreClick);
//         var   id= $('.search input').attr("id");
//         $("#"+id).remove();
                loadRssFeeds(null, 1);
                //$(thisEle).removeAttr("checked");

                // $(thisEle).closest('tr').addClass('.entity_highlight');
                //$(thisEle).aClass('.entity_highlight');

                if (showMoreClick == 1)
                {
                    $('#empty_person').remove();
                    $('#empty_disease').remove();
                    $('#empty_product').remove();
                    $('#empty_technology').remove();
                    $('#empty_organization').remove();
                    $('#empty_company').remove();

                    // loadStats(1,0,0);    
                }
                if (showMoreClick == 2)
                {

                    $(thisEle).parent().parent().removeClass("selected_entity");
//                $('#empty_person').empty();
//                $('#empty_disease').empty();
//                $('#empty_product').empty();
//                $('#empty_technology').empty();
//                $('#empty_organization').empty();
//                $('#empty_company').empty();
                    // 
                    if ($('.' + eName).closest('tr').hasClass('selected_entity'))
                    {
                        $('.' + eName).closest('tr').removeClass('selected_entity');
                        $(thisEle).removeAttr("checked");
                    } else
                    {
                        $('.' + eName).closest('tr').addClass('selected_entity');
                        $(thisEle).attr("checked", 'checked');
                    }
                    //loadStats(1);    
                }
                // 
                //$(thisEle).attr('checked', true);
                if (showMoreClick != 1 && showMoreClick != 2)
                {
                    loadStats(null, null, 1);

                }

            }
            function showTagEntitiesOnHover(tag_name, thisEle)
            {
                var pos = getElementAbsolutePos(thisEle);
                var html, cat_name;
                $(".content ").empty();

                //jAlert(pos.x);


                var offset = $(thisEle).offset();
                var height = $(thisEle).height();

                var xPos = pos.x - 20;
                //            var yPos=pos.y-49;
                var yPos = offset.top + height + 14;
                $('#contentHolder').block({message: ' ', overlayCSS: {backgroundColor: '#F7F7F7 ', cursor: 'default'}, css: {backgroundImage: 'url(' + base_url + 'images/ajax-loader-round.gif)', backgroundPosition: 'center', backgroundRepeat: 'no-repeat', backgroundColor: 'transparent', border: '0px', height: '30%', cursor: 'default'}});
                $.ajax({
                    url: '<?php echo base_url(); ?>media_intel_extractions/get_tag_entities/',
                    type: 'POST',
                    dataType: 'JSON',
                    ajax: false,
                    data: {tag_name: tag_name},
                    success: function (returnData) {
                        //alert(returnData);


                        html = "<center style=\"color:#0F5FFD;font-size:15px\">In&nbsp;#" + returnData[0].tag_name + "</center>";
                        html += "<table class='show_tags'>";
                        html += "<tr><th>Name</th><th>Category</th></tr>"
                        for (var result in returnData)
                        {
                            if (returnData[result].category_name == "MedicalCondition")
                                cat_name = "Disease";
                            if (returnData[result].category_name == "Facility")
                                cat_name = "Organization";
                            if (returnData[result].category_name == "Person")
                                cat_name = "People";
                            if (returnData[result].category_name == "Organization")
                                cat_name = "Organization";
                            if (returnData[result].category_name == "Technology")
                                cat_name = "Technology";
                            if (returnData[result].category_name == "Company")
                                cat_name = "Company";
                            if (returnData[result].category_name == "Product")
                                cat_name = "Product";
                            html += "<tr><td>" + returnData[result].entity_name + "</td><td>" + cat_name + "</td></tr>";
                        }
                        html += "</table>";
                        $(".content ").append(html);
                        //$( "tr:odd" ).css( "background-color", "#EAF1F1" );
                        $('#contentHolder').unblock();
                    }

                });
                //$("#callOutTest").css({'position': 'absolute','top':yPos,'left':xPos});
                //$("#callOutTest").show();
                //$("#contentHolder").empty();
                $("#arraouHolderTags").css({'position': 'absolute', 'top': yPos - 14, 'left': xPos + 30});
                $("#contentHolder").css({'position': 'absolute', 'top': yPos, 'left': xPos});


                //$("#arraouHolder").css({'position': 'absolute','top':yPos-15,'left':xPos+50});
                //$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos+30});
                $("#arraouHolderTags").show();
                $("#contentHolder").show();
                //$("#contentHolder").empty();
                $('#ignore').empty();
                $("#contentHolder .profileContent").html("");


                //$("#contentHolder").html("<div class='microViewLoading'>Loading...</div>");
                $('#contentHolder .profileContent').block({message: ' ', overlayCSS: {backgroundColor: '#F7F7F7', cursor: 'default'}, css: {backgroundImage: 'url(../images/ajax-loader-round.gif)', backgroundPosition: 'center', backgroundRepeat: 'no-repeat', backgroundColor: 'transparent', border: '0px', height: '30%', cursor: 'default'}});
                $('#contentHolder .profileContent').unblock();
            }

            function load_more_refined_entity(cat_name, offset, isShowSet)
            {


                categoryName = cat_name;
                var filterData = {};
                if (isShowSet == 1)
                {
                    s_i++;
                    show_init_offset = show_init_offset + 10;
                    cat_name = cat_name.slice(0, -9);
                    categoryName = cat_name;
                }
                var topFilters = $("#topFilters").serialize();
                if (topFilters != null && topFilters != '')
                    filterData += '&' + topFilters;
                var statFilters = $("#statForm").serialize();
                var statFilterss = $("#statForms").serialize();
                if (statFilterss != null && statFilterss != '')
                    filterData += '&' + statFilterss;
                if (statFilters != null && statFilters != '')
                    filterData += '&' + statFilters;
                var showStatFilters = $("#showStatForm").serialize();
                if (showStatFilters != null && showStatFilters != '')
                    filterData += '&' + showStatFilters;
                filterData += '&loadMoreClick=' + 1;
                filterData += '&loadMoreCat=' + cat_name;
                filterData += '&show_more_offset=' + show_init_offset;
                $('.book_mark').block({message: ' ', overlayCSS: {backgroundColor: '#F7F7F7 ', cursor: 'default'}, css: {backgroundImage: 'url(' + base_url + 'images/ajax-loader-round.gif)', backgroundPosition: 'center', backgroundRepeat: 'no-repeat', backgroundColor: 'transparent', border: '0px', height: '30%', cursor: 'default'}});
                $.ajax({
                    url: '<?php echo base_url(); ?>media_intel_extractions/ajax_entity_filters/',
                    type: 'POST',
                    dataType: 'JSON',
                    data: filterData,
                    success: function (returnData) {
                        if (returnData == '')
                        {
                            alert("no data");
//                    $('.show_more').hide();
//                    $('.left_content').append("<center><h3>No more data to load<center></h3>");
//                    $('.feed_url').unblock();
                        } else
                        {

                            $('.ignore_message').empty();
                            $('.ignore_list').empty();
                            $('.load_more_entity').hide();

                            if (returnData.hasOwnProperty('People'))
                            {


                                var html;

                                if (isShowSet != 1)
                                {
                                    show_init_offset = 0;
                                    $('h5').show();
                                    html = "<h5  onclick=\"hide_more_entities()\">Close</h5>";
                                    html = "<div class='refined_more_entities'>";
                                    html += "<h5  title='back' onclick=\"hide_more_entities()\"><img src='<?php echo base_url() ?>/css/images/back.png' /><h6 class='table_all_cat_count'><input  class='autocompleteInputBox people' autocomplete='off' id='entName'  name='entName' placeholder='Seach for people' type='text'/><b class='table_cat_count_font'>People</b>&nbsp(" + returnData["entity_count"].people + "&nbsp;people &nbsp;in&nbsp;" + returnData.count["people"] + "&nbsp;articles)</h6></h5>";
                                    html += "<hr/>";
                                    html += "<form  action='' name='showStatForm' id='showStatForm'>";
                                }



                                if (cat_name == "people")
                                {
                                    if (isShowSet != 1)
                                    {

                                        html += "<table cellspacing=0  data-role='table' class='ui-responsive'>";
                                        html += "<tbody id=" + cat_name + "_showmore><tr style='font-size:13px;font-weight:normal'><th>Name <b class='showmore_table_header'></b></th><th>Bookmark</th><th>Ignore</th><th></th></tr>";
                                    }

                                    if (isShowSet != 1)
                                        $(' .refined_more_entities').remove();
                                    $('#empty_person').empty();
                                    $('#book_mark_content').hide();
                                    //$("#empty_person").empty();
                                    var anyEntity=0;
                                   
                                    for (var cat_res in returnData['People'])
                                    {
                                
// alert($("."+returnData['People'][cat_res].id).length+" "+returnData['People'][cat_res].id);
                                        // alert(returnData['person'][cat_res].img_url);
                                        if ((returnData['People'][cat_res] != "No entities") && (returnData['People'][cat_res].isblacklisted != true) &&  ($("#people_showmore .selected_entity input ").val()!=returnData['People'][cat_res].id) )
                                        {

                                            if (returnData['People'][cat_res].selected)
                                                html += "<tr data-inset='false' class='selected_entity'><td><div class='cat_name selected_entity'>";
                                            else
                                                html += "<tr style='height: 33px;' class='cat_name " + returnData['People'][cat_res].id + " '><td><div >";
                                            //html="<div class='cat_name'>";
                                            // html+= "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id="+returnData['People'][cat_res].entity_name+"  name='people[]' hidden  value='"+returnData['People'][cat_res].entity_name+"'/><label id='$values->entity_name' for="+returnData['People'][cat_res].entity_name+">"+returnData['People'][cat_res].entity_name+" </label></div>";
                                            html += "<div id='table_entity_val' >";
                                            if (returnData['People'][cat_res].selected)
                                                html += "<input type='checkbox' onclick=\"entity_refine(this,'" + returnData['People'][cat_res].id + "','2')\" id='" + returnData['People'][cat_res].entity_name + "'  name='people[]' hidden  value='" + returnData['People'][cat_res].id + "' checked='checked'/>";
                                            else
                                                html += "<input type='checkbox' onclick=\"entity_refine(this,'" + returnData['People'][cat_res].id + "','2')\" id='" + returnData['People'][cat_res].entity_name + "'  name='people[]' hidden  value='" + returnData['People'][cat_res].id + "'/>";
                                            html += "<label title='asdasd' id='$values->entity_name' for='" + returnData['People'][cat_res].entity_name + "'><span class='table_entity_name' >" + returnData['People'][cat_res].entity_name + "</span> <span class='table_entity_count'>(" + returnData['People'][cat_res].numc + ")</span> </label></td>";
                                            html += "</div>";
                                            if (returnData['People'][cat_res].isbookmarked == true)
                                                html += "<td align='center'><div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['People'][cat_res].id + ",this)\" class=" + returnData['People'][cat_res].id + " src='<?php echo base_url() ?>/css/images/fav.svg'  /> </div></td>";
                                            else
                                                html += "<td align='center'><div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['People'][cat_res].id + ",this)\" class=" + returnData['People'][cat_res].id + " src='<?php echo base_url() ?>/css/images/unfav.svg'  /> </div></td>";
                                            //html+="<td><div id='entity_count'><b >"+returnData['People'][cat_res].numc+"</b> </div></td>"
                                            html += "<td><div  class='do_not_show_img '><img  onclick=\"do_not_show_entity(" + returnData['People'][cat_res].id + ")\"  src='<?php echo base_url() ?>/css/images/do_not_show.png'  /></div> </td>";


                                            html += "</div></tr>";


                                                anyEntity=1;



                                        }

                                    }

                                    if (isShowSet != 1)
                                        html += "</tbody></table>";

                                    //html+="<div><button  class='table_show_more' onclick=\"load_more_refined_entity('people_showmore',"+offset+",1);return false;\">Show More</button></div>";
                                    html += "       <div  onclick=\"load_more_refined_entity('people_showmore'," + offset + ",1);return false;\" class=\"show_more\" >"
                                    html += '      <img  style ="float:left;margin:5px;" src="<?php echo base_url() ?>/css/images/showmore.png"  /><h3><div > <b class="table_cat_show_more" >Show More</b></div></h3>';
                                    html += "   </div>";
                                    if (isShowSet != 1)
                                        html += "</form>";
                                    html += "</div>";

                                    if (isShowSet != 1)
                                    {
                                        $('.book_mark').append(html);
                                    } else
                                    {
                                        isShowSet = 0;
                                        if (returnData['People'].length > 1 && anyEntity!=0) {
                                            $('#' + cat_name + '_showmore').append(html);
                                        } else {
                                            $('.refined_more_entities .show_more').remove();
                                            show_init_offset = 0;
                                        }
                                    }


                                    // $.mobile.loading( 'hide', {});
                                    $('.book_mark').unblock();
                                }
                            }
                            if (returnData.hasOwnProperty('MedicalCondition'))
                            {


                                var html;

                                if (isShowSet != 1)
                                {
                                    show_init_offset = 0;

                                    $('h5').show();
                                    html = "<h5  onclick=\"hide_more_entities()\">Close</h5>";
                                    html = "<div class='refined_more_entities'>";
                                    html += "<h5  title='back' onclick=\"hide_more_entities()\"><img src='<?php echo base_url() ?>/css/images/back.png' /><h6 class='table_all_cat_count'><input  class='autocompleteInputBox people' autocomplete='off' id='entName'  name='entName' placeholder='Seach for disease' type='text'/><b class='table_cat_count_font'>Disease</b>&nbsp(" + returnData["entity_count"].disease + "&nbsp;disease &nbsp;in&nbsp;" + returnData.count["disease"] + "&nbsp;articles)</h6></h5>";
                                    html += "<hr/>";
                                    html += "<form  action='' name='showStatForm' id='showStatForm'>";
                                }



                                if (cat_name == "disease")
                                {
                                    if (isShowSet != 1)
                                    {

                                        html += "<table cellspacing=0  data-role='table' class='ui-responsive'>";
                                        html += "<tbody id=" + cat_name + "_showmore><tr style='font-size:13px;font-weight:normal'><th>Name <b class='showmore_table_header'></b></th><th>Bookmark</th><th>Ignore</th><th></th></tr>";
                                    }

                                    if (isShowSet != 1)
                                        $(' .refined_more_entities').remove();
                                    $('#empty_disease').empty();
                                    $('#book_mark_content').hide();
                                    //$("#empty_person").empty();
                                     var anyEntity=0;
                                    for (var cat_res in returnData['MedicalCondition'])
                                    {

                                         
                                        if ((returnData['MedicalCondition'][cat_res] != "No entities") && (returnData['MedicalCondition'][cat_res].isblacklisted != true)  && ($("#disease_showmore .selected_entity input ").val()!=returnData['MedicalCondition'][cat_res].id))
                                        {
//console.log(returnData['MedicalCondition'][cat_res]);
                                            if (returnData['MedicalCondition'][cat_res].selected)
                                                html += "<tr data-inset='false' class='selected_entity'><td><div class='cat_name selected_entity'>";
                                            else
                                                html += "<tr style='height: 33px;' class='cat_name " + returnData['MedicalCondition'][cat_res].id + " '><td><div >";
                                            //html="<div class='cat_name'>";
                                            // html+= "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id="+returnData['People'][cat_res].entity_name+"  name='people[]' hidden  value='"+returnData['People'][cat_res].entity_name+"'/><label id='$values->entity_name' for="+returnData['People'][cat_res].entity_name+">"+returnData['People'][cat_res].entity_name+" </label></div>";
                                            html += "<div id='table_entity_val' >";
                                            if (returnData['MedicalCondition'][cat_res].selected)
                                                html += "<input type='checkbox' onclick=\"entity_refine(this,'" + returnData['MedicalCondition'][cat_res].id + "','2')\" id='" + returnData['MedicalCondition'][cat_res].entity_name + "'  name='disease[]' hidden  value='" + returnData['MedicalCondition'][cat_res].id + "' checked='checked'/>";
                                            else
                                                html += "<input type='checkbox' onclick=\"entity_refine(this,'" + returnData['MedicalCondition'][cat_res].id + "','2')\" id='" + returnData['MedicalCondition'][cat_res].entity_name + "'  name='disease[]' hidden  value='" + returnData['MedicalCondition'][cat_res].id + "'/>";
                                            html += "<label title='asdasd' id='$values->entity_name' for='" + returnData['MedicalCondition'][cat_res].entity_name + "'><span class='table_entity_name' >" + returnData['MedicalCondition'][cat_res].entity_name + "</span> <span class='table_entity_count'>(" + returnData['MedicalCondition'][cat_res].numc + ")</span> </label></td>";
                                            html += "</div>";
                                            if (returnData['MedicalCondition'][cat_res].isbookmarked == true)
                                                html += "<td align='center'><div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['MedicalCondition'][cat_res].id + ",this)\" class=" + returnData['MedicalCondition'][cat_res].id + " src='<?php echo base_url() ?>/css/images/fav.svg'  /> </div></td>";
                                            else
                                                html += "<td align='center'><div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['MedicalCondition'][cat_res].id + ",this)\" class=" + returnData['MedicalCondition'][cat_res].id + " src='<?php echo base_url() ?>/css/images/unfav.svg'  /> </div></td>";
                                            //html+="<td><div id='entity_count'><b >"+returnData['People'][cat_res].numc+"</b> </div></td>"
                                            html += "<td><div  class='do_not_show_img '><img  onclick=\"do_not_show_entity(" + returnData['MedicalCondition'][cat_res].id + ")\"  src='<?php echo base_url() ?>/css/images/do_not_show.png'  /></div> </td>";


                                            html += "</div></tr>";

                                            anyEntity=1;




                                        }

                                    }

                                    if (isShowSet != 1)
                                        html += "</tbody></table>";

                                    //html+="<div><button  class='table_show_more' onclick=\"load_more_refined_entity('people_showmore',"+offset+",1);return false;\">Show More</button></div>";
                                    html += "       <div  onclick=\"load_more_refined_entity('disease_showmore'," + offset + ",1);return false;\" class=\"show_more\" >"
                                    html += '      <img  style ="float:left;margin:5px;" src="<?php echo base_url() ?>/css/images/showmore.png"  /><h3><div > <b class="table_cat_show_more" >Show More</b></div></h3>';
                                    html += "   </div>";
                                    if (isShowSet != 1)
                                        html += "</form>";
                                    html += "</div>";

                                    if (isShowSet != 1)
                                    {
                                        $('.book_mark').append(html);
                                    } else
                                    {
                                        isShowSet = 0;
                                        if (returnData['MedicalCondition'].length > 1 && anyEntity!=0) {
                                            $('#' + cat_name + '_showmore').append(html);
                                        } else {
                                            $('.refined_more_entities .show_more').remove();
                                            show_init_offset = 0;
                                        }
                                    }
                                    // $.mobile.loading( 'hide', {});
                                    $('.book_mark').unblock();
                                }
                            }
                            if (returnData.hasOwnProperty('Product'))
                            {


                                var html;

                                if (isShowSet != 1)
                                {
                                    show_init_offset = 0;

                                    $('h5').show();
                                    html = "<h5  onclick=\"hide_more_entities()\">Close</h5>";
                                    html = "<div class='refined_more_entities'>";
                                    html += "<h5  title='back' onclick=\"hide_more_entities()\"><img src='<?php echo base_url() ?>/css/images/back.png' /><h6 class='table_all_cat_count'><input  class='autocompleteInputBox people' autocomplete='off' id='entName'  name='entName' placeholder='Seach for product' type='text'/><b class='table_cat_count_font'>Product</b>&nbsp(" + returnData["entity_count"].product + "&nbsp;product &nbsp;in&nbsp;" + returnData.count["product"] + "&nbsp;articles)</h6></h5>";
                                    html += "<hr/>";
                                    html += "<form  action='' name='showStatForm' id='showStatForm'>";
                                }



                                if (cat_name == "product")
                                {
                                    if (isShowSet != 1)
                                    {

                                        html += "<table cellspacing=0  data-role='table' class='ui-responsive'>";
                                        html += "<tbody id=" + cat_name + "_showmore><tr style='font-size:13px;font-weight:normal'><th>Name <b class='showmore_table_header'></b></th><th>Bookmark</th><th>Ignore</th><th></th></tr>";
                                    }

                                    if (isShowSet != 1)
                                        $(' .refined_more_entities').remove();
                                    $('#empty_product').empty();
                                    $('#book_mark_content').hide();
                                    //$("#empty_person").empty();
                                     var anyEntity=0;
                                    for (var cat_res in returnData['Product'])
                                    {

                                        // alert(returnData['person'][cat_res].img_url);
                                        if ((returnData['Product'][cat_res] != "No entities") && (returnData['Product'][cat_res].isblacklisted != true)&& ($("#product_showmore .selected_entity input ").val()!=returnData['Product'][cat_res].id) )
                                        {

                                            if (returnData['Product'][cat_res].selected)
                                                html += "<tr data-inset='false' class='selected_entity'><td><div class='cat_name selected_entity'>";
                                            else
                                                html += "<tr style='height: 33px;' class='cat_name " + returnData['Product'][cat_res].id + " '><td><div >";
                                            //html="<div class='cat_name'>";
                                            // html+= "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id="+returnData['People'][cat_res].entity_name+"  name='people[]' hidden  value='"+returnData['People'][cat_res].entity_name+"'/><label id='$values->entity_name' for="+returnData['People'][cat_res].entity_name+">"+returnData['People'][cat_res].entity_name+" </label></div>";
                                            html += "<div id='table_entity_val' >";
                                            if (returnData['Product'][cat_res].selected)
                                                html += "<input type='checkbox' onclick=\"entity_refine(this,'" + returnData['Product'][cat_res].id + "','2')\" id='" + returnData['Product'][cat_res].entity_name + "'  name='product[]' hidden  value='" + returnData['Product'][cat_res].id + "' checked='checked'/>";
                                            else
                                                html += "<input type='checkbox' onclick=\"entity_refine(this,'" + returnData['Product'][cat_res].id + "','2')\" id='" + returnData['Product'][cat_res].entity_name + "'  name='product[]' hidden  value='" + returnData['Product'][cat_res].id + "'/>";
                                            html += "<label title='asdasd' id='$values->entity_name' for='" + returnData['Product'][cat_res].entity_name + "'><span class='table_entity_name' >" + returnData['Product'][cat_res].entity_name + "</span> <span class='table_entity_count'>(" + returnData['Product'][cat_res].numc + ")</span> </label></td>";
                                            html += "</div>";
                                            if (returnData['Product'][cat_res].isbookmarked == true)
                                                html += "<td align='center'><div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['Product'][cat_res].id + ",this)\" class=" + returnData['Product'][cat_res].id + " src='<?php echo base_url() ?>/css/images/fav.svg'  /> </div></td>";
                                            else
                                                html += "<td align='center'><div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['Product'][cat_res].id + ",this)\" class=" + returnData['Product'][cat_res].id + " src='<?php echo base_url() ?>/css/images/unfav.svg'  /> </div></td>";
                                            //html+="<td><div id='entity_count'><b >"+returnData['People'][cat_res].numc+"</b> </div></td>"
                                            html += "<td><div  class='do_not_show_img '><img  onclick=\"do_not_show_entity(" + returnData['Product'][cat_res].id + ")\"  src='<?php echo base_url() ?>/css/images/do_not_show.png'  /></div> </td>";


                                            html += "</div></tr>";



anyEntity=1;


                                        }

                                    }

                                    if (isShowSet != 1)
                                        html += "</tbody></table>";

                                    //html+="<div><button  class='table_show_more' onclick=\"load_more_refined_entity('people_showmore',"+offset+",1);return false;\">Show More</button></div>";
                                    html += "       <div  onclick=\"load_more_refined_entity('product_showmore'," + offset + ",1);return false;\" class=\"show_more\" >"
                                    html += '      <img  style ="float:left;margin:5px;" src="<?php echo base_url() ?>/css/images/showmore.png"  /><h3><div > <b class="table_cat_show_more" >Show More</b></div></h3>';
                                    html += "   </div>";
                                    if (isShowSet != 1)
                                        html += "</form>";
                                    html += "</div>";

                                    if (isShowSet != 1)
                                    {
                                        $('.book_mark').append(html);
                                    } else
                                    {
                                        isShowSet = 0;
                                        if (returnData['Product'].length > 1 && anyEntity!=0) {
                                            $('#' + cat_name + '_showmore').append(html);
                                        } else {
                                            $('.refined_more_entities .show_more').remove();
                                            show_init_offset = 0;
                                        }
                                    }
                                    // $.mobile.loading( 'hide', {});
                                    $('.book_mark').unblock();
                                }
                            }
                            if (returnData.hasOwnProperty('source'))
                            {


                                var html;
                                $('h5').show();
                                html = "<h5  onclick=\"hide_more_entities()\">Close</h5>";
                                html = "<div class='refined_more_entities'>";
                                html += "<h5  title='back' onclick=\"hide_more_entities()\"><img src=\"" + base_url + "/css/images/back.png\" /></h5>";
                                html += "<hr/>";
                                html += "<form  action='' name='showStatForm' id='showStatForm'>";


                                if (cat_name == "source")
                                {
                                    html += "<table ><tr><th>Source <b class='showmore_table_header'>Articles</b></th><th></th><th></th><th></th></tr>";
                                    $(' .refined_more_entities').empty();
                                    $('#empty_source').empty();
                                    $('#book_mark_content').hide();
                                    //$("#empty_person").empty();
                                    for (var cat_res in returnData['source'])
                                    {

                                        // alert(returnData['person'][cat_res].img_url);
//                                       if((returnData['People'][cat_res]!="No entities")&&(returnData['People'][cat_res].isblacklisted!=true))
//                                       {

                                        if (returnData['source'][cat_res].selected)
                                            html += "<tr class='selected_entity'><td><div class='cat_name selected_entity'>";
                                        else
                                            html += "<tr class='cat_name " + returnData['source'][cat_res].id + " '><td><div >";
                                        //html="<div class='cat_name'>";
                                        // html+= "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id="+returnData['People'][cat_res].entity_name+"  name='people[]' hidden  value='"+returnData['People'][cat_res].entity_name+"'/><label id='$values->entity_name' for="+returnData['People'][cat_res].entity_name+">"+returnData['People'][cat_res].entity_name+" </label></div>";
                                        html += "<div id='table_entity_val' >";
                                        if (returnData['source'][cat_res].selected)
                                            html += "<input type='checkbox' onclick=\"entity_refine(this,'" + returnData['source'][cat_res].id + "','2')\" id='" + returnData['source'][cat_res].id + "'  name='link[]' hidden  value='" + returnData['source'][cat_res].id + "' checked='checked'/>";
                                        else
                                            html += "<input type='checkbox' onclick=\"entity_refine(this,'" + returnData['source'][cat_res].id + "','2')\" id='" + returnData['source'][cat_res].id + "'  name='link[]' hidden  value='" + returnData['source'][cat_res].id + "'/>";
                                        html += "<label title='asdasd' id='$values->entity_name' for='" + returnData['source'][cat_res].id + "'><span class='table_entity_name' >" + returnData['source'][cat_res].publisher + "</span> <span class='table_entity_count'>" + returnData['source'][cat_res].numc + "</span> </label></td>";
                                        html += "</div>";
                                        //html+="<td><div id='entity_count'><b >"+returnData['People'][cat_res].numc+"</b> </div></td>"
                                        // html+="<td><div  class='do_not_show_img '><img  onclick=\"do_not_show_entity("+returnData['source'][cat_res].id+")\"  src=\""+base_url+"/css/images/do_not_show.png\"  /></div> </td>";


                                        html += "</div></tr>";






                                        // }

                                    }

                                    html += "</table>";
                                    html += "</form>";
                                    html += "</div>";
                                    $('.book_mark').append(html);
                                    $('.book_mark').unblock();
                                }
                            }
                            if (returnData.hasOwnProperty('Technology'))
                            {


                                var html;

                                if (isShowSet != 1)
                                {
                                    show_init_offset = 0;

                                    $('h5').show();
                                    html = "<h5  onclick=\"hide_more_entities()\">Close</h5>";
                                    html = "<div class='refined_more_entities'>";
                                    html += "<h5  title='back' onclick=\"hide_more_entities()\"><img src='<?php echo base_url() ?>/css/images/back.png' /><h6 class='table_all_cat_count'><input  class='autocompleteInputBox people' autocomplete='off' id='entName'  name='entName' placeholder='Seach for technology' type='text'/><b class='table_cat_count_font'>Technology</b>&nbsp(" + returnData["entity_count"].technology + "&nbsp;technology &nbsp;in&nbsp;" + returnData.count["technology"] + "&nbsp;articles)</h6></h5>";
                                    html += "<hr/>";
                                    html += "<form  action='' name='showStatForm' id='showStatForm'>";
                                }



                                if (cat_name == "technology")
                                {
                                    if (isShowSet != 1)
                                    {

                                        html += "<table cellspacing=0  data-role='table' class='ui-responsive'>";
                                        html += "<tbody id=" + cat_name + "_showmore><tr style='font-size:13px;font-weight:normal'><th>Name <b class='showmore_table_header'></b></th><th>Bookmark</th><th>Ignore</th><th></th></tr>";
                                    }

                                    if (isShowSet != 1)
                                        $(' .refined_more_entities').remove();
                                    $('#empty_technology').empty();
                                    $('#book_mark_content').hide();
                                    //$("#empty_person").empty();
                                   var anyEntity=0;
                                    for (var cat_res in returnData['Technology'])
                                    {

                                        // alert(returnData['person'][cat_res].img_url);
                                        if ((returnData['Technology'][cat_res] != "No entities") && (returnData['Technology'][cat_res].isblacklisted != true)&& ($("#technology_showmore .selected_entity input ").val()!=returnData['Technology'][cat_res].id)) 
                                        {

                                            if (returnData['Technology'][cat_res].selected)
                                                html += "<tr data-inset='false' class='selected_entity'><td><div class='cat_name selected_entity'>";
                                            else
                                                html += "<tr style='height: 33px;' class='cat_name " + returnData['Technology'][cat_res].id + " '><td><div >";
                                            //html="<div class='cat_name'>";
                                            // html+= "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id="+returnData['People'][cat_res].entity_name+"  name='people[]' hidden  value='"+returnData['People'][cat_res].entity_name+"'/><label id='$values->entity_name' for="+returnData['People'][cat_res].entity_name+">"+returnData['People'][cat_res].entity_name+" </label></div>";
                                            html += "<div id='table_entity_val' >";
                                            if (returnData['Technology'][cat_res].selected)
                                                html += "<input type='checkbox' onclick=\"entity_refine(this,'" + returnData['Technology'][cat_res].id + "','2')\" id='" + returnData['Technology'][cat_res].entity_name + "'  name='technology[]' hidden  value='" + returnData['Technology'][cat_res].id + "' checked='checked'/>";
                                            else
                                                html += "<input type='checkbox' onclick=\"entity_refine(this,'" + returnData['Technology'][cat_res].id + "','2')\" id='" + returnData['Technology'][cat_res].entity_name + "'  name='technology[]' hidden  value='" + returnData['Technology'][cat_res].id + "'/>";
                                            html += "<label title='asdasd' id='$values->entity_name' for='" + returnData['Technology'][cat_res].entity_name + "'><span class='table_entity_name' >" + returnData['Technology'][cat_res].entity_name + "</span> <span class='table_entity_count'>(" + returnData['Technology'][cat_res].numc + ")</span> </label></td>";
                                            html += "</div>";
                                            if (returnData['Technology'][cat_res].isbookmarked == true)
                                                html += "<td align='center'><div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['Technology'][cat_res].id + ",this)\" class=" + returnData['Technology'][cat_res].id + " src='<?php echo base_url() ?>/css/images/fav.svg'  /> </div></td>";
                                            else
                                                html += "<td align='center'><div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['Technology'][cat_res].id + ",this)\" class=" + returnData['Technology'][cat_res].id + " src='<?php echo base_url() ?>/css/images/unfav.svg'  /> </div></td>";
                                            //html+="<td><div id='entity_count'><b >"+returnData['People'][cat_res].numc+"</b> </div></td>"
                                            html += "<td><div  class='do_not_show_img '><img  onclick=\"do_not_show_entity(" + returnData['Technology'][cat_res].id + ")\"  src='<?php echo base_url() ?>/css/images/do_not_show.png'  /></div> </td>";


                                            html += "</div></tr>";


anyEntity=1;



                                        }

                                    }

                                    if (isShowSet != 1)
                                        html += "</tbody></table>";

                                    //html+="<div><button  class='table_show_more' onclick=\"load_more_refined_entity('people_showmore',"+offset+",1);return false;\">Show More</button></div>";
                                    html += "       <div  onclick=\"load_more_refined_entity('technology_showmore'," + offset + ",1);return false;\" class=\"show_more\" >"
                                    html += '      <img  style ="float:left;margin:5px;" src="<?php echo base_url() ?>/css/images/showmore.png"  /><h3><div > <b class="table_cat_show_more" >Show More</b></div></h3>';
                                    html += "   </div>";
                                    if (isShowSet != 1)
                                        html += "</form>";
                                    html += "</div>";

                                    if (isShowSet != 1)
                                    {
                                        $('.book_mark').append(html);
                                    } else
                                    {
                                        isShowSet = 0;
                                        if (returnData['Technology'].length > 1 && anyEntity!=0) {
                                            $('#' + cat_name + '_showmore').append(html);
                                        } else {
                                            $('.refined_more_entities .show_more').remove();
                                            show_init_offset = 0;
                                        }
                                    }
                                    // $.mobile.loading( 'hide', {});
                                    $('.book_mark').unblock();
                                }
                            }
                            if (returnData.hasOwnProperty('Organization'))
                            {


                                var html;

                                if (isShowSet != 1)
                                {
                                    show_init_offset = 0;

                                    $('h5').show();
                                    html = "<h5  onclick=\"hide_more_entities()\">Close</h5>";
                                    html = "<div class='refined_more_entities'>";
                                    html += "<h5  title='back' onclick=\"hide_more_entities()\"><img src='<?php echo base_url() ?>/css/images/back.png' /><h6 class='table_all_cat_count'><input  class='autocompleteInputBox people' autocomplete='off' id='entName'  name='entName' placeholder='Seach for organization' type='text'/><b class='table_cat_count_font'>Organization</b>&nbsp(" + returnData["entity_count"].organization + "&nbsp;organization &nbsp;in&nbsp;" + returnData.count["organization"] + "&nbsp;articles)</h6></h5>";
                                    html += "<hr/>";
                                    html += "<form  action='' name='showStatForm' id='showStatForm'>";
                                }



                                if (cat_name == "organization")
                                {
                                    if (isShowSet != 1)
                                    {

                                        html += "<table cellspacing=0  data-role='table' class='ui-responsive'>";
                                        html += "<tbody id=" + cat_name + "_showmore><tr style='font-size:13px;font-weight:normal'><th>Name <b class='showmore_table_header'></b></th><th>Bookmark</th><th>Ignore</th><th></th></tr>";
                                    }

                                    if (isShowSet != 1)
                                        $(' .refined_more_entities').remove();
                                    $('#empty_organization').empty();
                                    $('#book_mark_content').hide();
                                    //$("#empty_person").empty();
                                    var anyEntity=0;
                                    for (var cat_res in returnData['Organization'])
                                    {

                                        // alert(returnData['person'][cat_res].img_url);
                                        if ((returnData['Organization'][cat_res] != "No entities") && (returnData['Organization'][cat_res].isblacklisted != true) && ($("#organization_showmore .selected_entity input ").val()!=returnData['Organization'][cat_res].id))
                                        {

                                            if (returnData['Organization'][cat_res].selected)
                                                html += "<tr data-inset='false' class='selected_entity'><td><div class='cat_name selected_entity'>";
                                            else
                                                html += "<tr style='height: 33px;' class='cat_name " + returnData['Organization'][cat_res].id + " '><td><div >";
                                            //html="<div class='cat_name'>";
                                            // html+= "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id="+returnData['People'][cat_res].entity_name+"  name='people[]' hidden  value='"+returnData['People'][cat_res].entity_name+"'/><label id='$values->entity_name' for="+returnData['People'][cat_res].entity_name+">"+returnData['People'][cat_res].entity_name+" </label></div>";
                                            html += "<div id='table_entity_val' >";
                                            if (returnData['Organization'][cat_res].selected)
                                                html += "<input type='checkbox' onclick=\"entity_refine(this,'" + returnData['Organization'][cat_res].id + "','2')\" id='" + returnData['Organization'][cat_res].entity_name + "'  name='organization[]' hidden  value='" + returnData['Organization'][cat_res].id + "' checked='checked'/>";
                                            else
                                                html += "<input type='checkbox' onclick=\"entity_refine(this,'" + returnData['Organization'][cat_res].id + "','2')\" id='" + returnData['Organization'][cat_res].entity_name + "'  name='organization[]' hidden  value='" + returnData['Organization'][cat_res].id + "'/>";
                                            html += "<label title='asdasd' id='$values->entity_name' for='" + returnData['Organization'][cat_res].entity_name + "'><span class='table_entity_name' >" + returnData['Organization'][cat_res].entity_name + "</span> <span class='table_entity_count'>(" + returnData['Organization'][cat_res].numc + ")</span> </label></td>";
                                            html += "</div>";
                                            if (returnData['Organization'][cat_res].isbookmarked == true)
                                                html += "<td align='center'><div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['Organization'][cat_res].id + ",this)\" class=" + returnData['Organization'][cat_res].id + " src='<?php echo base_url() ?>/css/images/fav.svg'  /> </div></td>";
                                            else
                                                html += "<td align='center'><div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['Organization'][cat_res].id + ",this)\" class=" + returnData['Organization'][cat_res].id + " src='<?php echo base_url() ?>/css/images/unfav.svg'  /> </div></td>";
                                            //html+="<td><div id='entity_count'><b >"+returnData['People'][cat_res].numc+"</b> </div></td>"
                                            html += "<td><div  class='do_not_show_img '><img  onclick=\"do_not_show_entity(" + returnData['Organization'][cat_res].id + ")\"  src='<?php echo base_url() ?>/css/images/do_not_show.png'  /></div> </td>";


                                            html += "</div></tr>";


anyEntity=1;


                                        }

                                    }

                                    if (isShowSet != 1)
                                        html += "</tbody></table>";

                                    //html+="<div><button  class='table_show_more' onclick=\"load_more_refined_entity('people_showmore',"+offset+",1);return false;\">Show More</button></div>";
                                    html += "       <div  onclick=\"load_more_refined_entity('organization_showmore'," + offset + ",1);return false;\" class=\"show_more\" >"
                                    html += '      <img  style ="float:left;margin:5px;" src="<?php echo base_url() ?>/css/images/showmore.png"  /><h3><div > <b class="table_cat_show_more" >Show More</b></div></h3>';
                                    html += "   </div>";
                                    if (isShowSet != 1)
                                        html += "</form>";
                                    html += "</div>";

                                    if (isShowSet != 1)
                                    {
                                        $('.book_mark').append(html);
                                    } else
                                    {
                                        isShowSet = 0;
                                        if (returnData['Organization'].length > 1 && anyEntity!=0) {
                                            $('#' + cat_name + '_showmore').append(html);
                                        } else {
                                            $('.refined_more_entities .show_more').remove();
                                            show_init_offset = 0;
                                        }
                                    }
                                    // $.mobile.loading( 'hide', {});
                                    $('.book_mark').unblock();
                                }
                            }
                            if (returnData.hasOwnProperty('Company'))
                            {


                                var html;

                                if (isShowSet != 1)
                                {
                                    show_init_offset = 0;

                                    $('h5').show();
                                    html = "<h5  onclick=\"hide_more_entities()\">Close</h5>";
                                    html = "<div class='refined_more_entities'>";
                                    html += "<h5  title='back' onclick=\"hide_more_entities()\"><img src='<?php echo base_url() ?>/css/images/back.png' /><h6 class='table_all_cat_count'><input  class='autocompleteInputBox people' autocomplete='off' id='entName'  name='entName' placeholder='Seach for company' type='text'/><b class='table_cat_count_font'>Company</b>&nbsp(" + returnData["entity_count"].company + "&nbsp;organization &nbsp;in&nbsp;" + returnData.count["company"] + "&nbsp;articles)</h6></h5>";
                                    html += "<hr/>";
                                    html += "<form  action='' name='showStatForm' id='showStatForm'>";
                                }



                                if (cat_name == "company")
                                {
                                    if (isShowSet != 1)
                                    {

                                        html += "<table cellspacing=0  data-role='table' class='ui-responsive'>";
                                        html += "<tbody id=" + cat_name + "_showmore><tr style='font-size:13px;font-weight:normal'><th>Name <b class='showmore_table_header'></b></th><th>Bookmark</th><th>Ignore</th><th></th></tr>";
                                    }

                                    if (isShowSet != 1)
                                        $(' .refined_more_entities').remove();
                                    $('#empty_company').empty();
                                    $('#book_mark_content').hide();
                                    //$("#empty_person").empty();
                                    var anyEntity=0;
                                    for (var cat_res in returnData['Company'])
                                    {

                                        // alert(returnData['person'][cat_res].img_url);
                                        if ((returnData['Company'][cat_res] != "No entities") && (returnData['Company'][cat_res].isblacklisted != true) && ($("#company_showmore .selected_entity input ").val()!=returnData['Company'][cat_res].id))
                                        {

                                            if (returnData['Company'][cat_res].selected)
                                                html += "<tr data-inset='false' class='selected_entity'><td><div class='cat_name selected_entity'>";
                                            else
                                                html += "<tr style='height: 33px;' class='cat_name " + returnData['Company'][cat_res].id + " '><td><div >";
                                            //html="<div class='cat_name'>";
                                            // html+= "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id="+returnData['People'][cat_res].entity_name+"  name='people[]' hidden  value='"+returnData['People'][cat_res].entity_name+"'/><label id='$values->entity_name' for="+returnData['People'][cat_res].entity_name+">"+returnData['People'][cat_res].entity_name+" </label></div>";
                                            html += "<div id='table_entity_val' >";
                                            if (returnData['Company'][cat_res].selected)
                                                html += "<input type='checkbox' onclick=\"entity_refine(this,'" + returnData['Company'][cat_res].id + "','2')\" id='" + returnData['Company'][cat_res].entity_name + "'  name='company[]' hidden  value='" + returnData['Company'][cat_res].id + "' checked='checked'/>";
                                            else
                                                html += "<input type='checkbox' onclick=\"entity_refine(this,'" + returnData['Company'][cat_res].id + "','2')\" id='" + returnData['Company'][cat_res].entity_name + "'  name='company[]' hidden  value='" + returnData['Company'][cat_res].id + "'/>";
                                            html += "<label title='asdasd' id='$values->entity_name' for='" + returnData['Company'][cat_res].entity_name + "'><span class='table_entity_name' >" + returnData['Company'][cat_res].entity_name + "</span> <span class='table_entity_count'>(" + returnData['Company'][cat_res].numc + ")</span> </label></td>";
                                            html += "</div>";
                                            if (returnData['Company'][cat_res].isbookmarked == true)
                                                html += "<td align='center'><div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['Company'][cat_res].id + ",this)\" class=" + returnData['Company'][cat_res].id + " src='<?php echo base_url() ?>/css/images/fav.svg'  /> </div></td>";
                                            else
                                                html += "<td align='center'><div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['Company'][cat_res].id + ",this)\" class=" + returnData['Company'][cat_res].id + " src='<?php echo base_url() ?>/css/images/unfav.svg'  /> </div></td>";
                                            //html+="<td><div id='entity_count'><b >"+returnData['People'][cat_res].numc+"</b> </div></td>"
                                            html += "<td><div  class='do_not_show_img '><img  onclick=\"do_not_show_entity(" + returnData['Company'][cat_res].id + ")\"  src='<?php echo base_url() ?>/css/images/do_not_show.png'  /></div> </td>";


                                            html += "</div></tr>";


                                                anyEntity=1;



                                        }

                                    }

                                    if (isShowSet != 1)
                                        html += "</tbody></table>";

                                    //html+="<div><button  class='table_show_more' onclick=\"load_more_refined_entity('people_showmore',"+offset+",1);return false;\">Show More</button></div>";
                                    html += "       <div  onclick=\"load_more_refined_entity('company_showmore'," + offset + ",1);return false;\" class=\"show_more\" >"
                                    html += '      <img  style ="float:left;margin:5px;" src="<?php echo base_url() ?>/css/images/showmore.png"  /><h3><div > <b class="table_cat_show_more" >Show More</b></div></h3>';
                                    html += "   </div>";
                                    if (isShowSet != 1)
                                        html += "</form>";
                                    html += "</div>";

                                    if (isShowSet != 1)
                                    {
                                        $('.book_mark').append(html);
                                    } else
                                    {
                                        isShowSet = 0;
                                        if (returnData['Company'].length > 1 && anyEntity!=0) {
                                            $('#' + cat_name + '_showmore').append(html);
                                        } else {
                                            $('.refined_more_entities .show_more').remove();
                                            show_init_offset = 0;
                                        }
                                    }
                                    // $.mobile.loading( 'hide', {});
                                    $('.book_mark').unblock();
                                }
                            }
//                              if(returnData.hasOwnProperty('MedicalCondition'))
//                            { 
//                                 
//                               
//                                var html;
//                                 $('h5').show();
//                                 html="<h5  onclick=\"hide_more_entities()\">Close</h5>";
//                                 html="<div class='refined_more_entities'>";
//                                  html+="<h5  title='back' onclick=\"hide_more_entities()\"><img src=\""+base_url+"/css/images/back.png\" /><h6 class='table_all_cat_count'><b class='table_cat_count_font'>Disease</b>&nbsp("+returnData["MedicalCondition"].length+"&nbsp;diseases &nbsp;in&nbsp;"+returnData.count["disease"]+"&nbsp;articles)</h6></h5>";
//                                   html+="<hr/>";
//                                html+="<form  action='' name='showStatForm' id='showStatForm'>";
//                               
//                               
//                               if(cat_name=="disease")
//                               {   
//                                    html+="<table ><tr><th>Disease<b class='showmore_table_header'>Articles</b></th><th></th><th></th><th></th></tr>";
//                                    $(' .refined_more_entities').empty();  
//                                   $('#empty_disease').empty();
//                                    $('#book_mark_content').hide();
//                                    //$("#empty_person").empty();
//                                for(var cat_res in returnData['MedicalCondition'])
//                                {      
//                                       // alert(returnData['person'][cat_res].img_url);
//                                       if((returnData['MedicalCondition'][cat_res]!="No entities")&&(returnData['MedicalCondition'][cat_res].isblacklisted!=true))
//                                       {
//                                           
//                                            if(returnData['MedicalCondition'][cat_res].selected)
//                                           html+="<tr class='selected_entity'><td><div class='cat_name selected_entity'>";
//                                       else
//                                           html+="<tr class='cat_name "+returnData['MedicalCondition'][cat_res].id+" '><td><div >";
                            //  html="<div class='cat_name'>";
                            //   html+= "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id="+returnData['People'][cat_res].entity_name+"  name='people[]' hidden  value='"+returnData['People'][cat_res].entity_name+"'/><label id='$values->entity_name' for="+returnData['People'][cat_res].entity_name+">"+returnData['People'][cat_res].entity_name+" </label></div>";
//                                         html+= "<div id='table_entity_val' >";
//                                           if(returnData['MedicalCondition'][cat_res].selected)
//                                               html+= "<input type='checkbox' onclick=\"entity_refine(this,'"+returnData['MedicalCondition'][cat_res].id+"',2)\" id='"+returnData['MedicalCondition'][cat_res].entity_name+"'  name='disease[]' hidden  value='"+returnData['MedicalCondition'][cat_res].id+"' checked='checked'/>";
//                                           else
//                                               html+= "<input type='checkbox' onclick=\"entity_refine(this,'"+returnData['MedicalCondition'][cat_res].id+"',2)\" id='"+returnData['MedicalCondition'][cat_res].entity_name+"'  name='disease[]' hidden  value='"+returnData['MedicalCondition'][cat_res].id+"'/>";
//                                           html+= "<label id='$values->entity_name' for='"+returnData['MedicalCondition'][cat_res].entity_name+"'><span class='table_entity_name'>"+returnData['MedicalCondition'][cat_res].entity_name+"</span> <span class='table_entity_count'>"+returnData['MedicalCondition'][cat_res].numc+"</span> </label></td>";
//                                       html+= "</div>";
//                                        //html+="<td><div id='entity_count'><b >"+returnData['MedicalCondition'][cat_res].numc+"</b> </div></td>"
//                                         html+="<td><div  class='do_not_show_img '><img  onclick=\"do_not_show_entity("+returnData['MedicalCondition'][cat_res].id+")\"  src=\""+base_url+"/css/images/do_not_show.png\"  /></div> </td>";
//                                        if(returnData['MedicalCondition'][cat_res].isbookmarked==true)
//                                            html+="<td><div id='abc' class='book_img '><img  onclick=\"bookmark_entity("+returnData['MedicalCondition'][cat_res].id+",this)\" class="+returnData['MedicalCondition'][cat_res].id+" src=\""+base_url+"/css/images/fav.svg\"  /> </div></td>";
//                                        else
//                                             html+="<td><div id='abc' class='book_img '><img  onclick=\"bookmark_entity("+returnData['MedicalCondition'][cat_res].id+",this)\" class="+returnData['MedicalCondition'][cat_res].id+" src=\""+base_url+"/css/images/unfav.svg\"  /> </div></td>";
//                                        
//                                        html+="</div></tr>";
//                                        
//                                       
//                                        
//                                      
//                                       
//                                        
//                                    }
//                                     
//                                }
//                                
//                                html+="</table>";
//                                html+="</form>";
//                                html+="</div>";
//                                $('.book_mark').append(html);
//                                 $('.book_mark').unblock();
//                            }
//                            }






                            if (entityName != '') {
                                $('#entName').val(entityName);
                                entityName = '';
                            }
                        }
                    }
                });
            }
            $('input[type=checkbox]').click(function () {
                var id = $(this).closest(".cat_name").attr("id");
                //alert(id);
                if ($(this).is(":not(:checked)")) {
                    // alert("hi");
                    $("#" + id).removeClass('selected_entity');
                }
            });
            function loadStats(entity_click, date_click, entity_refine_click, article_entity_click) {
                var filterData = {};

                var topFilters = $("#topFilters").serialize();
                if (topFilters != null && topFilters != '')
                    filterData += '&' + topFilters;
                var statFilters = $("#statForm").serialize();
                var statFilterss = $("#statForms").serialize();
                if (statFilterss != null && statFilterss != '')
                    filterData += '&' + statFilterss;
                if (statFilters != null && statFilters != '')
                    filterData += '&' + statFilters;
                var showStatFilters = $("#showStatForm").serialize();
                if (showStatFilters != null && showStatFilters != '')
                    filterData += '&' + showStatFilters;

                $('.cat_show_more').remove();
                //filter.push($('input:checkbox:checked').val());
                //$('.feed_url').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});

                $('.book_mark').block({message: ' ', overlayCSS: {backgroundColor: '#F7F7F7 ', cursor: 'default'}, css: {backgroundImage: 'url(' + base_url + 'images/ajax-loader-round.gif)', backgroundPosition: 'center', backgroundRepeat: 'no-repeat', backgroundColor: 'transparent', border: '0px', height: '30%', cursor: 'default'}});
                $.ajax({
                    url: '<?php echo base_url(); ?>media_intel_extractions/ajax_entity_filters/',
                    type: 'POST',
                    dataType: 'JSON',
                    data: filterData,
                    success: function (returnData) {
                        if (returnData == '')
                        {
                            alert("no data");
//                    $('.show_more').hide();
//                    $('.left_content').append("<center><h3>No more data to load<center></h3>");
//                    $('.feed_url').unblock();
                        } else
                        {   //$('.feed_url').hide();
                            //$('.show_more').hide();
                            flag = 0;
                            $('#empty_person').empty();
                            $('#empty_disease').empty();
                            $('#empty_product').empty();
                            $('#empty_technology').empty();
                            $('#empty_organization').empty();
                            $('#empty_company').empty();
                            var count_person = 0;
                            var count_disease = 0;
                            var count_product = 0;
                            var count_organization = 0;
                            var count_technology = 0;
                            var count_company = 0;
                            var article_count_person = 0;
                            var article_count_disease = 0;
                            var article_count_product = 0;
                            var article_count_organization = 0;
                            var article_count_technology = 0;
                            var article_count_company = 0;

                            for (var result in returnData)
                            {
                                if ((result != "Person") && (result != "Technology") && (result != "MedicalCondition") && (result != "Product") && (result != "Organization") && (result != "Company"))
                                {


                                }
                            }
                            $('.load_more_entity').hide();

                            if (returnData.hasOwnProperty('People'))
                            {
                                $('#empty_person').empty();


                                var i = 0;
                                for (var cat_res in returnData['People'])
                                {
                                    if (returnData['People'][cat_res].selected_source == true)
                                    {
                                        var link_id = returnData["People"][cat_res].rss_link_id;
                                        //alert(link_id);
                                        $("#" + link_id).addClass("selected_entity")
                                    }
                                    if ((returnData['People'][cat_res] != "No entities") && (returnData['People'][cat_res].isblacklisted != true)  )
                                    {
                                        count_person++;
                                        if (returnData['People'][cat_res].selected)
                                            html = "<div class='cat_name selected_entity'>";
                                        else
                                            html = "<div class='cat_name'>";
                                        //html="<div class='cat_name'>";
                                        // html+= "<div id='entity_val' ><input type='checkbox' onclick=\"entity_refine(this)\" id="+returnData['People'][cat_res].entity_name+"  name='people[]' hidden  value='"+returnData['People'][cat_res].entity_name+"'/><label id='$values->entity_name' for="+returnData['People'][cat_res].entity_name+">"+returnData['People'][cat_res].entity_name+" </label></div>";
                                        html += "<div id='entity_val' >";
                                        if (returnData['People'][cat_res].selected)
                                            html += "<input type='checkbox' onclick=\"entity_refine(this)\" id='" + returnData['People'][cat_res].entity_name + "'  name='people[]' hidden  value='" + returnData['People'][cat_res].id + "' checked='checked'/>";
                                        else
                                            html += "<input type='checkbox' onclick=\"entity_refine(this)\" id='" + returnData['People'][cat_res].entity_name + "'  name='people[]' hidden  value='" + returnData['People'][cat_res].id + "'/>";
                                        html += "<label title='" + returnData['People'][cat_res].entity_name + "' id='$values->entity_name' for='" + returnData['People'][cat_res].entity_name + "'><span class='entity_name'>" + returnData['People'][cat_res].entity_name + "</span> <span class='entity_count'>" + returnData['People'][cat_res].numc + "&nbsp;articles</span></label>";
                                        html += "</div>";
                                        //html+="<div id='entity_count'>"+returnData['People'][cat_res].numc+"&nbsp;articles</div>"

                                        if (returnData['People'][cat_res].isbookmarked == true)
                                            html += "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['People'][cat_res].id + ",this)\" class=" + returnData['People'][cat_res].id + " src=\"" + base_url + "/css/images/fav.svg\"  /> </div>";
                                        else
                                            html += "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['People'][cat_res].id + ",this)\" class=" + returnData['People'][cat_res].id + " src=\"" + base_url + "/css/images/unfav.svg\"  /> </div>";
                                        html += "<div  class='do_not_show_img '><img  onclick=\"do_not_show_entity(" + returnData['People'][cat_res].id + ")\"  src=\"" + base_url + "/css/images/do_not_show.png\"  /></div> ";
                                        html += "</div>";
                                        article_count_person = article_count_person + parseInt(returnData['People'][cat_res].numc);
                                        if (i < 5 && entity_click != 1 && article_entity_click == 1)
                                        {
                                            $('#empty_person').append(html);
                                        }
                                        if (i < 5 && entity_click != 1 && article_entity_click != 1)
                                        {
                                            $('#empty_person').append(html);
                                        }
                                        if (i >= 5 && returnData['People'][cat_res].selected)
                                        {

                                            $('#empty_person').append(html);
                                        }


                                        //flag=1;
                                        i++;
                                        //alert(i);
                                          $('.cat_show_more').remove();
                                        if (i == 5)
                                        {

                                            $('.people').append("<b id=\"people\"  onclick=\"load_more_refined_entity('people')\" class=\"cat_show_more\" >Show More</b>");
                                        }

                                    }

                                }
                                if (i == 0)
                                {
                                    $('#empty_person').empty();
                                    $('#empty_person').append("No entities found");

                                }
                                $('.person_header').empty();
                                $('.person_header').append("<h2>People</h2>(" + returnData.entity_count["people"] + " " + "People in" + " " + returnData.count["people"] + "&nbsp;articles)");

                            }
                            if (returnData.hasOwnProperty('MedicalCondition'))
                            {
                                $('#empty_disease').empty();
                                //$('.load_more_entity').hide();

                                var i = 0;

                                for (var cat_res in returnData['MedicalCondition'])
                                {
                                    if ((returnData['MedicalCondition'][cat_res] != "No entities") && (returnData['MedicalCondition'][cat_res].isblacklisted != true))
                                    {     //alert(returnData['person'][cat_res].img_url);
                                        count_disease++;

                                        article_count_disease = article_count_disease + parseInt(returnData['MedicalCondition'][cat_res].numc);
                                        var html;
                                        //if(returnData['MedicalCondition'][cat_res].isbookmarked==true)
                                        //{ 
                                        //count_disease++;
                                        if (returnData['MedicalCondition'][cat_res].selected)
                                            html = "<div class='cat_name selected_entity'>";
                                        else
                                            html = "<div class='cat_name'>";

                                        html += "<div id='entity_val' >";
                                        if (returnData['MedicalCondition'][cat_res].selected)
                                            html += "<input type='checkbox' onclick=\"entity_refine(this)\" id='" + returnData['MedicalCondition'][cat_res].entity_name + "'  name='disease[]' hidden  value='" + returnData['MedicalCondition'][cat_res].id + "' checked='checked'/>";
                                        else
                                            html += "<input type='checkbox' onclick=\"entity_refine(this)\" id='" + returnData['MedicalCondition'][cat_res].entity_name + "'  name='disease[]' hidden  value='" + returnData['MedicalCondition'][cat_res].id + "'/>";
                                        html += "<label title='" + returnData['MedicalCondition'][cat_res].entity_name + "' id='$values->entity_name' for='" + returnData['MedicalCondition'][cat_res].entity_name + "'><span class='entity_name'>" + returnData['MedicalCondition'][cat_res].entity_name + "</span> <span class='entity_count'>" + returnData['MedicalCondition'][cat_res].numc + "&nbsp;articles</span> </label>";
                                        html += "</div>";
                                        //html+="<div id='entity_count'>"+returnData['MedicalCondition'][cat_res].numc+"&nbsp;articles</div>"
                                        if (returnData['MedicalCondition'][cat_res].isbookmarked == true)
                                            html += "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['MedicalCondition'][cat_res].id + ",this)\" class=" + returnData['MedicalCondition'][cat_res].id + " src=\"" + base_url + "/css/images/fav.svg\"  /> </div>";
                                        else
                                            html += "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['MedicalCondition'][cat_res].id + ",this)\" class=" + returnData['MedicalCondition'][cat_res].id + " src=\"" + base_url + "/css/images/unfav.svg\"  /> </div>";
                                        html += "<div  class='do_not_show_img '><img  onclick=\"do_not_show_entity(" + returnData['MedicalCondition'][cat_res].id + ")\"  src=\"" + base_url + "/css/images/do_not_show.png\"  /></div> ";
                                        html += "</div>";
                                        //article_count_disease=article_count_disease+parseInt(returnData['disease'][cat_res].numc);
//                                        if(i<5  && entity_click!=1 && article_entity_click==1)
                                        $('#empty_disease').append(html);


//                                        if(i>=5 && returnData['MedicalCondition'][cat_res].selected)
//                                        {
//                                            $('#empty_disease').append(html);
//                                        }
                                        //flag=1;
                                        i++;
                                        //}
                                        if (i == 5)
                                        {

                                            $('.disease').append("<b id=\"disease\"  onclick=\"load_more_refined_entity('disease')\" class=\"cat_show_more\" >Show More</b>");

                                        }
                                    }

                                }
                                if (i == 0)
                                {
                                    $('#empty_disease').empty();
                                    $('#empty_disease').append("<center>No entities found</center>");
                                }
                                $('.disease_header').empty();
                                $('.disease_header').append("<h2>Disease</h2>(" + returnData.entity_count["disease"] + " " + "Diseases in" + " " + returnData.count["disease"] + "&nbsp;articles)");

                            }
                            var source_article_count = 0;
                            if (returnData.hasOwnProperty('source'))
                            {
                                $('#empty_source').empty();
                                //$('.load_more_entity').hide();

                                z = 0;


                                for (var cat_res in returnData['source'])
                                {
                                    source_article_count = source_article_count + parseInt(returnData['source'][cat_res].numc);


//                                   if((returnData['MedicalCondition'][cat_res]!="No entities")&&(returnData['MedicalCondition'][cat_res].isblacklisted!=true))
//                                {     //alert(returnData['person'][cat_res].img_url);

                                    var html;
                                    //if(returnData['MedicalCondition'][cat_res].isbookmarked==true)
                                    //{ 
                                    //count_disease++;
                                    if (returnData['source'][cat_res].selected)
                                        html = "<div class='cat_name selected_entity'>";
                                    else
                                        html = "<div class='cat_name'>";

                                    html += "<div id='entity_val' >";
                                    if (returnData['source'][cat_res].selected)
                                        html += "<input type='checkbox' onclick=\"entity_refine(this)\" id='" + returnData['source'][cat_res].id + "'  name='link[]' hidden  value='" + returnData['source'][cat_res].id + "' checked='checked'/>";
                                    else
                                        html += "<input type='checkbox' onclick=\"entity_refine(this)\" id='" + returnData['source'][cat_res].id + "'  name='link[]' hidden  value='" + returnData['source'][cat_res].id + "'/>";
                                    html += "<label title='" + returnData['source'][cat_res].publisher + "' id='$values->entity_name' for='" + returnData['source'][cat_res].id + "'><span class='entity_name'>" + returnData['source'][cat_res].publisher + "</span> <span class='entity_count'>" + returnData['source'][cat_res].numc + "&nbsp;articles</span> </label>";
                                    html += "</div>";
                                    //html+="<div id='entity_count'>"+returnData['MedicalCondition'][cat_res].numc+"&nbsp;articles</div>"

//                                         html+="<div  class='do_not_show_img '><img  onclick=\"do_not_show_source("+returnData['source'][cat_res].id+")\"  src=\""+base_url+"/css/images/do_not_show.png\"  /></div> ";
                                    html += "</div>";
                                    //article_count_disease=article_count_disease+parseInt(returnData['disease'][cat_res].numc);
                                    if (z <= 5 && entity_click != 1 && article_entity_click == 1)
                                        $('#empty_source').append(html);

                                    if (z <= 5 && entity_click != 1 && article_entity_click != 1)
                                    {
                                        $('#empty_source').append(html);
                                    }
//                                        if(z>=5 && returnData['source'][cat_res].selected)
//                                        {
//                                            $('#empty_source').append(html);
//                                        }
                                    //flag=1;
                                    if (z == 5)
                                    {

                                        $('.source').append("<b id=\"source\"  onclick=\"load_more_refined_entity('source')\" class=\"cat_show_more\" >Show More</b>");

                                    }
                                    z++;
                                }

                                // }

                            }
//                            if(i==0)
//                                {
//                                    $('#empty_disease').empty();
//                                    $('#empty_disease').append("<center>No entities found</center>");
//                                }
                            $('.source_header').empty();
                            $('.source_header').append("<h2>Source</h2>(" + source_article_count + " " + "articles &nbsp;from" + " " + returnData["source_count"] + "&nbsp;sources)");

                            //  }
                            if (returnData.hasOwnProperty('Technology'))
                            {
                                $('#empty_technology').empty();
                                //$('.load_more_entity').hide();



                                var i = 0;
                                for (var cat_res in returnData['Technology'])
                                {
                                    if ((returnData['Technology'][cat_res] != "No entities") && (returnData['Technology'][cat_res].isblacklisted != true))
                                    {
                                        // alert(returnData['person'][cat_res].img_url);
                                        var html;
                                        //if(returnData['MedicalCondition'][cat_res].isbookmarked==true)
                                        //{ 
                                        count_technology++;
                                        article_count_technology = article_count_technology + parseInt(returnData['Technology'][cat_res].numc);
                                        if (returnData['Technology'][cat_res].selected)
                                            html = "<div class='cat_name selected_entity'>";
                                        else
                                            html = "<div class='cat_name'>";

                                        html += "<div id='entity_val' >";
                                        if (returnData['Technology'][cat_res].selected)
                                            html += "<input type='checkbox' onclick=\"entity_refine(this)\" id='" + returnData['Technology'][cat_res].entity_name + "'  name='technology[]' hidden  value='" + returnData['Technology'][cat_res].id + "' checked='checked'/>";
                                        else
                                            html += "<input type='checkbox' onclick=\"entity_refine(this)\" id='" + returnData['Technology'][cat_res].entity_name + "'  name='technology[]' hidden  value='" + returnData['Technology'][cat_res].id + "'/>";
                                        html += "<label title='" + returnData['Technology'][cat_res].entity_name + "' id='$values->entity_name' for='" + returnData['Technology'][cat_res].entity_name + "'><span class='entity_name'>" + returnData['Technology'][cat_res].entity_name + "</span> <span class='entity_count'>" + returnData['Technology'][cat_res].numc + "&nbsp;articles</span></label>";
                                        html += "</div>";
                                        //html+="<div id='entity_count'>"+returnData['Technology'][cat_res].numc+"&nbsp;articles </div>"
                                        if (returnData['Technology'][cat_res].isbookmarked == true)
                                            html += "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['Technology'][cat_res].id + ",this)\" class=" + returnData['Technology'][cat_res].id + " src=\"" + base_url + "/css/images/fav.svg\"  /> </div>";
                                        else
                                            html += "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['Technology'][cat_res].id + ",this)\" class=" + returnData['Technology'][cat_res].id + " src=\"" + base_url + "/css/images/unfav.svg\"  /> </div>";
                                        html += "<div  class='do_not_show_img '><img  onclick=\"do_not_show_entity(" + returnData['Technology'][cat_res].id + ")\"  src=\"" + base_url + "/css/images/do_not_show.png\"  /></div> ";
                                        html += "</div>";
                                        //article_count_disease=article_count_disease+parseInt(returnData['disease'][cat_res].numc);
                                        if (i < 5 && entity_click != 1 && article_entity_click == 1)
                                            $('#empty_technology').append(html);
                                        if (i < 5 && entity_click != 1 && article_entity_click != 1)
                                        {
                                            $('#empty_technology').append(html);
                                        }
                                        if (i >= 5 && returnData['Technology'][cat_res].selected)
                                        {
                                            $('#empty_technology').append(html);
                                        }
                                        i++;
                                        if (i == 5)
                                        {

                                            $('.technology').append("<b id=\"technology\"  onclick=\"load_more_refined_entity('technology')\" class=\"cat_show_more\" >Show More</b>");

                                        }
                                    }

                                }
                                if (i == 0)
                                {
                                    $('#empty_technology').empty();
                                    $('#empty_technology').append("No entities found");
                                }
                                $('.technology_header').empty();
                                $('.technology_header').append("<h2>Technology</h2>(" + returnData.entity_count["technology"] + " " + "Technologies in" + " " + returnData.count["technology"] + "&nbsp;articles)");
//                           
                            }
                            if (returnData.hasOwnProperty('Organization'))
                            {
                                $('#empty_organization').empty();
                                // $('.load_more_entity').hide();


                                var i = 0;
                                for (var cat_res in returnData['Organization'])
                                {
                                    //alert(returnData['person'][cat_res].img_url);
                                    if (returnData['Organization'][cat_res] != "No entities")
                                    {
                                        var html;
                                        //if(returnData['MedicalCondition'][cat_res].isbookmarked==true)
                                        //{ 
                                        count_organization++;
                                        article_count_organization = article_count_organization + parseInt(returnData['Organization'][cat_res].numc);
                                        if (returnData['Organization'][cat_res].selected)
                                            html = "<div class='cat_name selected_entity'>";
                                        else
                                            html = "<div class='cat_name'>";

                                        html += "<div id='entity_val' >";
                                        if (returnData['Organization'][cat_res].selected)
                                            html += "<input type='checkbox' onclick=\"entity_refine(this)\" id='" + returnData['Organization'][cat_res].entity_name + "'  name='organization[]' hidden  value='" + returnData['Organization'][cat_res].id + "' checked='checked'/>";
                                        else
                                            html += "<input type='checkbox' onclick=\"entity_refine(this)\" id='" + returnData['Organization'][cat_res].entity_name + "'  name='organization[]' hidden  value='" + returnData['Organization'][cat_res].id + "'/>";
                                        html += "<label title='" + returnData['Organization'][cat_res].entity_name + "' id='$values->entity_name' for='" + returnData['Organization'][cat_res].entity_name + "'><span class='entity_name'>" + returnData['Organization'][cat_res].entity_name + "</span> <span class='entity_count'>" + returnData['Organization'][cat_res].numc + "&nbsp;articles</span> </label>";
                                        html += "</div>";
                                        //html+="<div id='entity_count'>"+returnData['Organization'][cat_res].numc+"&nbsp;articles</div>"
                                        if (returnData['Organization'][cat_res].isbookmarked == true)
                                            html += "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['Organization'][cat_res].id + ",this)\" class=" + returnData['Organization'][cat_res].id + " src=\"" + base_url + "/css/images/fav.svg\"  /> </div>";
                                        else
                                            html += "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['Organization'][cat_res].id + ",this)\" class=" + returnData['Organization'][cat_res].id + " src=\"" + base_url + "/css/images/unfav.svg\"  /> </div>";
                                        html += "<div  class='do_not_show_img '><img  onclick=\"do_not_show_entity(" + returnData['Organization'][cat_res].id + ")\"  src=\"" + base_url + "/css/images/do_not_show.png\"  /></div> ";
                                        html += "</div>";
                                        //article_count_disease=article_count_disease+parseInt(returnData['disease'][cat_res].numc);
                                        if (i < 5 && entity_click != 1 && article_entity_click == 1)
                                            $('#empty_organization').append(html);
                                        if (i < 5 && entity_click != 1 && article_entity_click != 1)
                                        {
                                            $('#empty_organization').append(html);
                                        }
                                        if (i >= 5 && returnData['Organization'][cat_res].selected)
                                        {
                                            $('#empty_organization').append(html);
                                        }
                                        i++;
                                        if (i == 5)
                                        {

                                            $('.organization').append("<b id=\"organization\"  onclick=\"load_more_refined_entity('organization')\" class=\"cat_show_more\" >Show More</b>");

                                        }
                                    }

                                }
                                if (i == 0)
                                {
                                    $('#empty_organization').empty();
                                    $('#empty_organization').append("No entities found");
                                }
                                $('.organization_header').empty();
                                $('.organization_header').append("<h2>Organization</h2>(" + returnData.entity_count["organization"] + " " + "Organizations in" + " " + returnData.count["organization"] + "&nbsp;articles)");
//                         
                            }

                            if (returnData.hasOwnProperty('Company'))
                            {
                                var i = 0;
                                $('#empty_company').empty();
                                // $('.load_more_entity').hide();

                                for (var cat_res in returnData['Company'])
                                {
                                    //alert(returnData['person'][cat_res].img_url);
                                    if ((returnData['Company'][cat_res] != "No entities") && (returnData['Company'][cat_res].isblacklisted != true))
                                    {
                                        var html;
                                        //if(returnData['MedicalCondition'][cat_res].isbookmarked==true)
                                        //{ 
                                        count_company++;
                                        article_count_company = article_count_company + parseInt(returnData['Company'][cat_res].numc);
                                        if (returnData['Company'][cat_res].selected)
                                            html = "<div class='cat_name selected_entity'>";
                                        else
                                            html = "<div class='cat_name'>";

                                        html += "<div id='entity_val' >";
                                        if (returnData['Company'][cat_res].selected)
                                            html += "<input type='checkbox' onclick=\"entity_refine(this)\" id='" + returnData['Company'][cat_res].entity_name + "'  name='company[]' hidden  value='" + returnData['Company'][cat_res].id + "' checked='checked'/>";
                                        else
                                            html += "<input type='checkbox' onclick=\"entity_refine(this)\" id='" + returnData['Company'][cat_res].entity_name + "'  name='company[]' hidden  value='" + returnData['Company'][cat_res].id + "'/>";
                                        html += "<label title='" + returnData['Company'][cat_res].entity_name + "' id='$values->entity_name' for='" + returnData['Company'][cat_res].entity_name + "'><span class='entity_name'>" + returnData['Company'][cat_res].entity_name + "</span> <span class='entity_count'>" + returnData['Company'][cat_res].numc + "&nbsp;articles</span> </label>";
                                        html += "</div>";
                                        // html+="<div id='entity_count'>"+returnData['Company'][cat_res].numc+"&nbsp;articles</div>"
                                        if (returnData['Company'][cat_res].isbookmarked == true)
                                            html += "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['Company'][cat_res].id + ",this)\" class=" + returnData['Company'][cat_res].id + " src=\"" + base_url + "/css/images/fav.svg\"  /> </div>";
                                        else
                                            html += "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['Company'][cat_res].id + ",this)\" class=" + returnData['Company'][cat_res].id + " src=\"" + base_url + "/css/images/unfav.svg\"  /> </div>";
                                        html += "<div  class='do_not_show_img '><img  onclick=\"do_not_show_entity(" + returnData['Company'][cat_res].id + ")\"  src=\"" + base_url + "/css/images/do_not_show.png\"  /></div> ";
                                        html += "</div>";
                                        //article_count_disease=article_count_disease+parseInt(returnData['disease'][cat_res].numc);
                                        if (i < 5 && entity_click != 1 && article_entity_click == 1)
                                            $('#empty_company').append(html);
                                        if (i < 5 && entity_click != 1 && article_entity_click != 1)
                                        {
                                            $('#empty_company').append(html);
                                        }
                                        if (i >= 5 && returnData['Company'][cat_res].selected)
                                        {
                                            $('#empty_company').append(html);
                                        }
                                        i++;
                                        if (i == 5)
                                        {

                                            $('.companies').append("<b id=\"company\"  onclick=\"load_more_refined_entity('company')\" class=\"cat_show_more\" >Show More</b>");

                                        }
                                    }


                                }
                                if (i == 0)
                                {

                                    $('#empty_company').append("No entities found");
                                }
                                $('.company_header').empty();
                                $('.company_header').append("<h2>Company</h2>(" + returnData.entity_count["company"] + " " + "Companies in" + " " + returnData.count["company"] + "&nbsp;articles)");

                            }

                            if (returnData.hasOwnProperty('Product'))
                            {
                                $('#empty_product').empty();
                                //$('.load_more_entity').hide();

                                var i = 0;

                                for (var cat_res in returnData['Product'])
                                {
                                    if ((returnData['Product'][cat_res] != "No entities") && (returnData['Product'][cat_res].isblacklisted != true))
                                    {     //alert(returnData['person'][cat_res].img_url);
                                        count_disease++;
                                        article_count_disease = article_count_disease + parseInt(returnData['Product'][cat_res].numc);
                                        var html;
                                        //if(returnData['MedicalCondition'][cat_res].isbookmarked==true)
                                        //{ 
                                        //count_disease++;
                                        if (returnData['Product'][cat_res].selected)
                                            html = "<div class='cat_name selected_entity'>";
                                        else
                                            html = "<div class='cat_name'>";

                                        html += "<div id='entity_val' >";
                                        if (returnData['Product'][cat_res].selected)
                                            html += "<input type='checkbox' onclick=\"entity_refine(this)\" id='" + returnData['Product'][cat_res].entity_name + "'  name='product[]' hidden  value='" + returnData['Product'][cat_res].id + "' checked='checked'/>";
                                        else
                                            html += "<input type='checkbox' onclick=\"entity_refine(this)\" id='" + returnData['Product'][cat_res].entity_name + "'  name='product[]' hidden  value='" + returnData['Product'][cat_res].id + "'/>";
                                        html += "<label id='$values->entity_name' for='" + returnData['Product'][cat_res].entity_name + "'><span class='entity_name'>" + returnData['Product'][cat_res].entity_name + "</span> <span class='entity_count'>" + returnData['Product'][cat_res].numc + "&nbsp;articles</span> </label>";
                                        html += "</div>";
                                        //html+="<div id='entity_count'>"+returnData['MedicalCondition'][cat_res].numc+"&nbsp;articles</div>"
                                        if (returnData['Product'][cat_res].isbookmarked == true)
                                            html += "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['Product'][cat_res].id + ",this)\" class=" + returnData['Product'][cat_res].id + " src=\"" + base_url + "/css/images/fav.svg\"  /> </div>";
                                        else
                                            html += "<div id='abc' class='book_img '><img  onclick=\"bookmark_entity(" + returnData['Product'][cat_res].id + ",this)\" class=" + returnData['Product'][cat_res].id + " src=\"" + base_url + "/css/images/unfav.svg\"  /> </div>";
                                        html += "<div  class='do_not_show_img '><img  onclick=\"do_not_show_entity(" + returnData['Product'][cat_res].id + ")\"  src=\"" + base_url + "/css/images/do_not_show.png\"  /></div> ";
                                        html += "</div>";
                                        //article_count_disease=article_count_disease+parseInt(returnData['disease'][cat_res].numc);
                                        if (i < 5 && entity_click != 1 && article_entity_click == 1)
                                            $('#empty_product').append(html);

                                        if (i < 5 && entity_click != 1 && article_entity_click != 1)
                                        {
                                            $('#empty_product').append(html);
                                        }
                                        if (i >= 5 && returnData['Product'][cat_res].selected)
                                        {
                                            $('#empty_product').append(html);
                                        }
                                        //flag=1;
                                        i++;
                                        //}
                                        if (i == 5)
                                        {

                                            $('.product').append("<b id=\"product\"  onclick=\"load_more_refined_entity('product')\" class=\"cat_show_more\" >Show More</b>");

                                        }
                                    }

                                }
                                if (i == 0)
                                {
                                    $('#empty_product').empty();
                                    $('#empty_product').append("<center>No entities found</center>");
                                }
                                $('.product_header').empty();
                                $('.product_header').append("<h2>Product</h2>(" + returnData.entity_count["product"] + " " + "Products in" + " " + returnData.count["product"] + "&nbsp;articles)");

                            }
                            // $('.left_content').append("<div id='load_more_filterd_feeds' onclick=''  class='show_more'><h3><div > <b class="cat_show_more" >Show More</b></div></h3></div>");
                            $(".book_mark").unblock();
                        }
                    }
                });

            }

            function hide_more_entities(isIgnoreSet, ignoreBackSet) {
                show_init_offset = 0;
                $('.refined_more_entities').hide();
                $('.refined_more_entities').hide();
                $('.display_more_entities').hide();
                $(".ignore_message").empty();
                $(".ignore_list").hide();
                $('#book_mark_content').show();
                $("#ignore").empty();
                $('h5').hide();
                if (!isIgnoreSet)
                    loadStats(0, 0, 1, 0);
                if (ignoreBackSet == "1")
                    loadStats();
                $('.refined_more_entities').empty();
            }
            function remove_bookmark(ent_id)
            {

                jConfirm("Are you sure you want to remove this topic from your favorites?", "Please confirm", function (r) {
                    if (r) {
                        $.ajax({
                            url: '<?php echo base_url(); ?>media_intel_extractions/remove_bookmarks/',
                            type: 'POST',
                            dataType: 'JSON',
                            async: false,
                            data: {entity_id: ent_id, remove: false},
                            success: function (returnData) {

                                $("." + ent_id).attr('src', '<?php echo base_url(); ?>/css/images/unfav.svg');
                                closeTagDialog();
                                loadRssFeeds();
                                var clientId = "<?php echo $this->session->userdata('client_id') ?>";
                                var role = "<?php echo INTERNAL_CLIENT_ID ?>";
                                if (clientId == role) {
                                    removeBookMarkForAllUsers(ent_id);
                                }

                            }
                        });
                    } else {
                        return false;
                    }
                });



            }

            function removeBookMarkForAllUsers(ent_id) {
                $.ajax({
                    url: '<?php echo base_url(); ?>media_intel_extractions/user_bookmarks_all_users/',
                    type: 'POST',
                    dataType: 'JSON',
                    data: {entity_id: ent_id, remove: true},
                    success: function (returnData) {


                    }
                });
            }
            function bookmark_entity(ent_id, thisEle)
            {



               
                //alert(ent_id);
                //$("."+ent_id).attr('src','<?php echo base_url(); ?>/css/images/unfav.svg');
                $.ajax({
                    url: '<?php echo base_url(); ?>media_intel_extractions/user_bookmarks/',
                    type: 'POST',
                    async: false,
                    dataType: 'JSON',
                    data: {entity_id: ent_id},
                    success: function (returnData) {

                        if (returnData.status == 'bookmarked') {
                            remove_bookmark(ent_id);
                            return false;

                        }
                         var cont = "<?php echo $controller ?>";
                         var pop="<?php echo $pop ?>";
                if (cont == "medintel" && pop != "true")
                    emailSettings();
                        var pos = getElementAbsolutePos(thisEle);
                        //jAlert(pos.x);

                        //var yPos=pos.y-45;
                        var offset = $(thisEle).offset();
                        var height = $(thisEle).height();

                        var xPos = pos.x - 250;
                        //            var yPos=pos.y-49;
                        var yPos = offset.top + height + 09;

                        //$("#callOutTest").css({'position': 'absolute','top':yPos,'left':xPos});
                        //$("#callOutTest").show();

                        $(".content ").empty();
                        $("#arraouHolder").css({'position': 'absolute', 'top': yPos - 64, 'left': xPos + 247});
                        $("#contentHolder").css({'position': 'absolute', 'top': yPos, 'left': xPos});

                        //$("#arraouHolder").css({'position': 'absolute','top':yPos-15,'left':xPos+50});
                        //$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos+30});
                        $("#arraouHolder").show();
                        $("#contentHolder").show();
                        //$("#contentHolder").empty();
                        $('#ignore').empty();
                        $("#contentHolder .profileContent").html("");
                        $(".tag_info").empty();
                        var html;
                        html = "<div class='unbookmark'>";
                        //html += "<img  title='remove bookmark' onclick=\"remove_bookmark(" + ent_id + ")\" src=\"" + base_url + "/css/images/unbookmark.png\"  />";

                        html += "</div>";
                        html += "<hr/>";
                        html += "<div class='tag_info'>";
                        html += "<form id='tagForm' method='post' action=''>";
                        html += "<h3 style='font-weight:normal;text-align:center'>You can add an optional tag to your favorite.</h3>";
                        html += "<span id='tagError'></span>";
                        html += "<center><input id='tagName' name='tagName' class='autocompleteInputBox' autocomplete='off' type='text' placeholder='Enter Tag Name' /></center><br/>";
                        html += "<p><center><input onclick=\"tagSubmit(" + ent_id + ")\" type=\"button\" value=\"Save\"/>&nbsp;<input onclick=\"closeTagDialog()\" type=\"button\" value=\"Cancel\"/></center></p>";
                        html += "</form>";
                        html += "</div>";
                        $(".content ").append(html);
                        //$("#contentHolder").html("<div class='microViewLoading'>Loading...</div>");
                        $('#contentHolder .profileContent').block({message: ' ', overlayCSS: {backgroundColor: '#F7F7F7', cursor: 'default'}, css: {backgroundImage: 'url(../images/ajax-loader-round.gif)', backgroundPosition: 'center', backgroundRepeat: 'no-repeat', backgroundColor: 'transparent', border: '0px', height: '30%', cursor: 'default'}});
                        $('#contentHolder .profileContent').unblock();

                        //	$("#contentHolder .profileContent").load(base_url+'kols/view_kol_micro/'+kolId,{},
                        //	function(){	$('#contentHolder .profileContent').unblock(); }
                        //	);
                        $("." + ent_id).attr('src', '<?php echo base_url(); ?>/css/images/fav.svg');
                        // }
                        var clientId = "<?php echo $this->session->userdata('client_id') ?>";
                        var role = "<?php echo INTERNAL_CLIENT_ID ?>";
                        if ((clientId == role) && returnData.status != 'bookmarked') {
                            bookMarkForAllUsers(ent_id);
                        }
                    }
                });
                loadRssFeeds();
            }

            function bookMarkForAllUsers(ent_id) {

                $.ajax({
                    url: '<?php echo base_url(); ?>media_intel_extractions/user_bookmarks_all_users/',
                    type: 'POST',
                    dataType: 'JSON',
                    data: {entity_id: ent_id, remove: false},
                    success: function (returnData) {


                    }
                });
            }
            function closeTagDialog() {
                $("#arraouHolder").hide();
                $("#arraouHolderTags").hide();
                $("#contentHolder  .profileContent").html("");
                $("#contentHolder").hide();
            }
            function do_not_show_entity(do_not_show_ent_id)
            {

                jConfirm('Are you sure you want to ignore?', 'Confirmation Dialog', function (r) {
                    if (r == true)
                    {
                        $.ajax({
                            url: '<?php echo base_url(); ?>media_intel_extractions/blacklist_entities/',
                            type: 'POST',
                            dataType: 'JSON',
                            data: {entity_id: do_not_show_ent_id},
                            success: function (returnData) {
                                //alert(returnData);
                                $("." + do_not_show_ent_id).parents(".cat_name").hide();
                                ;


                            }
                        });
                    }
                });





            }
            function removeEntityFromBlackList(ent_id, ignore_id)
            {


                $.ajax({
                    url: '<?php echo base_url(); ?>media_intel_extractions/remove_blacklists/',
                    type: 'POST',
                    dataType: 'TEXT',
                    data: {ent_id: ent_id},
                    success: function (returnData) {
                        //alert(returnData);
                        if (returnData == true)
                        {
                            $("#" + ignore_id).hide();
                            ;
                        }

                    }
                });
            }
function checkAll(ele) {
                var checkboxes = document.getElementsByTagName('input');
                if (ele.checked) {
                    for (var i = 0; i < checkboxes.length; i++) {
                        if (checkboxes[i].type == 'checkbox') {
                            checkboxes[i].checked = true;
                        }
                    }
                } else {
                    for (var i = 0; i < checkboxes.length; i++) {
                        console.log(i)
                        if (checkboxes[i].type == 'checkbox') {
                            checkboxes[i].checked = false;
                        }
                    }
                }
            }
            function showIgnoredEntities(thisEle)
            {
                hide_more_entities(1);

                $('#book_mark_content').hide();
                $('h5').show();
                $('.ignore_message').empty();
                $('.ignore_list').empty();
                $.ajax({
                    url: '<?php echo base_url(); ?>media_intel_extractions/get_ignored_entites/',
                    type: 'POST',
                    dataType: 'JSON',
                    ajax: false,
                    success: function (returnData) {
                        //alert(returnData);
                        if (returnData == '')
                        {
                            html = "<div class='ignore_message'>";
                            html += "<h5  title='back' onclick=\"hide_more_entities(0,1)\"><img src=\"" + base_url + "/css/images/back.png\" /></h5>";
                            html += "<hr/>";
                            html += "<center style='color:#000'>You haven't ignored any names.<center>";
                            html += "</div>";
                            $(".book_mark ").append(html);

                        } else
                        {
                            var html;
                            html = "<div class='ignore_list'>";
                            html += "<form id='ignore_list' method='post'>";
                            //html+="<input type='button' value='Restore Selected'/>";
                            html += "<h5  title='back' onclick=\"hide_more_entities()\"><img src=\"" + base_url + "/css/images/back.png\" /></h5>";
                            html += "<hr/>";
                            html += "<div class='ignore_restore'>";
                            html += "<input type='checkbox' onchange=\"checkAll(this)\" name=\"chk[]\" />Select All";
                            html += "&nbsp;&nbsp;&nbsp;<input onclick=\"restoreSelected()\" type='button' value='Restore Selected'/>";
                            html += "</div>";
                            html += "<div id='ignore'>";

                            //html+="<center style='color:#000'><b>IGNORE LIST</b></center>"
                            html += "<table>";
                            html += "<tr ><th></th><th>Name</th><th>Category Name</th><th>Restore</th></tr>";
                            for (var result in returnData)
                            {
                                html += "<tr id='" + returnData[result].id + "ignore'><td><input type='checkbox' name=entities[] value='" + returnData[result].id + "'/></td><td>" + returnData[result].entity_name + "</td><td>" + returnData[result].category_name + "</td><td><div  class='do_not_show_img '><img  onclick=\"removeEntityFromBlackList(" + returnData[result].id + ",'" + returnData[result].id + "ignore')\"  src=\"" + base_url + "/css/images/do_not_show.png\"  /></div>     </td></tr>";

                            }
                            html += "<table>";
                            html += "</form>";
                            html += "</div>";
                            $(".book_mark ").append(html);
                            $("tr:odd").css("background-color", "#E9E9E9");

                        }
                    }
                });




            }
            var commentExpanded = false;
            var idArray = new Array();
            function restoreSelected()
            {
                if($('#ignore input[type="checkbox"]:checked').length>0){
                var entities = $('#ignore_list').serialize();
                $.ajax({
                    url: '<?php echo base_url(); ?>media_intel_extractions/remove_blacklists/',
                    type: 'POST',
                    dataType: 'JSON',
                    data: entities,
                    success: function (returnData) {
                        //alert(returnData);
                        hide_more_entities();
                        showIgnoredEntities();

                    }
                });
                }
                else{
                jAlert("Please select atleast one entity to restore");
                }

            }
            function openNewTab() {
                var url = "<?php echo base_url() ?>" + 'medintel';
                window.location.href = url;
            }
            function userComments(id)
            {

                var i = 0;
                for (i; i < idArray.length; i++) {
                    if (idArray[i] == id) {
                        idArray.splice(i, 1);
                        $('#' + id).slideUp().hide();
                        $('.' + id).empty();
                        return false;
                    }

                }
                var result;
                $('#' + id).slideDown().show();
                idArray.push(id);
                $.ajax({
                    url: '<?php echo base_url(); ?>media_intel_extractions/get_comments/',
                    type: 'POST',
                    dataType: 'JSON',
                    data: {feed_id: id},
                    success: function (returnData) {
                        //alert(returnData);
                        $('.' + id).empty();
                        for (result in returnData)
                            $('.' + id).append("<div class='previous_comments'><div class='comment_info'><b>Posted by" + " " + returnData[result].first_name + "&nbsp;" + returnData[result].last_name + "</b></div>" + "<p style='margin:4px;  margin-bottom: -18px;'>" + returnData[result].comment + "</p>" + "<br/> " + "<p style='font-size:9px;margin:4px'>" + returnData[result].date + "</p>" + "</div>");

                    }
                });


            }
            function tagSubmit(ent_id)
            {
                var name = $('#tagName').val();
                if(name==''){
         closeTagDialog();
                    return false;
                
                
                }
                //alert(name);
                name = name.replace("#", " ");
                //alert(name);
                if (name != '')
                {
                    $('#tagError').empty();
                    $.ajax({
                        url: '<?php echo base_url(); ?>media_intel_extractions/save_tags/',
                        type: 'POST',
                        dataType: 'JSON',
                        data: {ent_id: ent_id, tag_name: name},
                        success: function (returnData) {
                            if (returnData == true)
                            {
                                $('#tagError').append("<center style='color:#077F41'><b>Tag saved successfully</b></center>").show();
                                $('#tagError').fadeOut(4000);
                            } else
                            {
                                $('#tagError').append("<center style='color:#ff0000'><b>You have already tagged</b></center>").show();
                                $('#tagError').fadeOut(4000);
                            }

                        }
                    });

                } else
                {
                    $('#tagError').append("<center style='color:#ff0000'>Please enter a tag name</center>");
                }
                loadRssFeeds();
            }
            function reset_filters(filter)
            {
                $('.applied_filters').empty();
                if (onpageLoad != 1) {
                    var startDate = new Date();

                    $('#datepicker2').val(startDate.format('M j, Y'))

                    var myDate = new Date();
                    myDate.setDate(myDate.getDate() - 30);
                    $('#datepicker1').val("<?php echo date('M j, Y', strtotime("-$fromFilterData days"));?>")

                } else {
                    onpageLoad = 0;
                }

                $(".ignore_message").empty();
                $(".refined_more_entities").remove();
                $(".ignore_list").hide();
                reset_value = 1;
     
                $('input:checkbox').remove();
     
                if (filter != 1)
                {
                    $('.left_content').empty();
                    $("#select_feed_type").val("0").change();
                    $("#select_feed_type").click();

                }

            }
            function showTags(tag_name)
            {

                loadRssFeeds(null, null, tag_name);
                //loadStats();
            }
//        function codeAddress() {
//            
//            $( "#select_feed_type").val("0").trigger('change').click();
//            $("#select_feed_type").click();
//        }
//        window.onload = codeAddress();
//      
</script>
<script>


</script>
<div id="eventContainer">

</div>
