<script language="javascript" type="text/javascript"
	src="<?php echo base_url() ?>js/chosen.jquery.js"></script>
<script language="javascript" type="text/javascript"
	src="<?php echo base_url() ?>js/jquery/jquery.validate1.9.min.js"></script>
<link href="<?php echo base_url();?>css/chosen.css" media="screen"
	rel="stylesheet" />
<style type="text/css">
select.chosenMultipleSelect {
	width: 200px;
}

.show {
	display: block;
}

.hide {
	display: none;
}

.microView .ui-dialog-content {
	background-color: white;
}

.users {
	list-style-type: none;
	margin: 0;
	padding: 0
}

.users li {
	float: left;
}

.editIcon {
	margin-left: 3px;
}
</style>
<div class="addClientsMsgBox"></div>
<script type="text/javascript">
$(document).ready(function (){
	$('.chosenMultipleSelect').chosen({
		allow_single_deselect: true
	});
});
</script>
<form>
	<div align="center">
		<caption>Merge Email Types</caption>
	</div>
	<table class="anaylystForm merge_emailTbl">
		<tr>
			<td>
				<p>
				
				<div align="center">
					<span id="responseMessage"></span> <input type="hidden"
						id="hiddenSid" readonly="readonly">
				</div>
						<table><tr><td><label>Email Type:</label></td>
					<td><select name="emailtype[]" multiple="multiple" id="emailTypesId"
						class="chosenMultipleSelect" data-placeholder="Select emailtype">
						<option disabled="disabled" value="">Select email type</option>					
			            <?php foreach($arrEmailTypes as $EmailTypes){ ?>
			            <option value="<?php echo $EmailTypes['id'];?>"><?php echo $EmailTypes['type']; ?></option>
			            <?php } ?>
            			</select>
            			</td>
            			</tr>
            			</table>
				</p>
			</td>
		</tr>
		<tr>
			<td>
				<div class="formButton" align="center">
					<input type="button" value="Save" name="submit"
						onclick="mergeEmailType();"></input><input type="button"
						value="Cancel" name="submit" onclick="closeModal();"></input>
				</div>
			</td>
		</tr>
	</table>
	<!-- End of Table -->
</form>
<!-- End of User Form -->
