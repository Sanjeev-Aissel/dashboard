<?php
class My_list_kol extends CI_Model {
	function listCategories($userId,$clientId){
		$arrCategories=array();
		$this->db->where('user_id',$userId);
		$this->db->where('client_id',$clientId);
		$arrCategoriesResult=$this->db->get('list_categories');
		foreach($arrCategoriesResult->result_array() as $row){
			$row['count']=$arrCategoriesResult->num_rows();
			$arrCategories[]=$row;
		}
		return $arrCategories;
	}	
	function getListNames($categoryId){
		$arrlist=array();
		$arrListResult=$this->db->query('select list_names.*,list_categories.is_public
											from list_names
											left join list_categories on list_categories.id=list_names.category_id
											where list_names.category_id='.$categoryId.'');
		if($arrListResult->num_rows()!=0){
			foreach($arrListResult->result_array() as $row){
				$arrlist[]=$row;
			}
			return $arrlist;
		}else{
			$this->db->where('id',$categoryId);
			$reult=$this->db->get('list_categories');
			foreach($reult->result_array() as $row){
				$arrlist[]=$row;
			}
			return $arrlist;
		}
	}
	function getListsByCatogoryId($categoryId,$arrFilter,$start,$limit,$sidx,$sord,$count=false){
		$this->db->select('list_names.id,list_names.list_name,COUNT(list_kols.kol_id) as kols_count');
		$this->db->where('list_names.category_id',$categoryId);
		$this->db->join('list_kols','list_kols.list_name_id=list_names.id','left');
		$this->db->group_by('list_names.id');
		foreach($arrFilter as $columnName=>$columnValue){
			$this->db->like($columnName,$columnValue);
		}
		if($count)
		{
			$query = $this->db->get('list_names');
// 			echo $this->db->last_query();
			return $query->num_rows();
		}
		else
		{
			$this->db->limit($limit);
			$this->db->order_by($sidx,$sord);
			return $this->db->get('list_names',$limit,$start);
		}
	}
	function getKolsByListId($listId,$arrFilter,$start,$limit,$sidx,$sord,$count=false){
		$this->db->select('list_kols.id,kols_client_visibility.unique_id as kols_client_visibility_unique_id,kols_client_visibility.id as kols_client_visibility_id,kols.first_name,kols.middle_name,kols.last_name,specialties.specialty,kols.primary_phone,kols.primary_email,countries.country,');
		$this->db->where('list_kols.list_name_id',$listId);
		$this->db->join('kols_client_visibility','kols_client_visibility.kol_id=kols.id','left');
		$this->db->join('list_kols','list_kols.kol_id=kols_client_visibility.id','left');
		$this->db->join('specialties','kols.specialty=specialties.id','left');
		$this->db->join('countries','countries.countryId=kols.country_id','left');
		if (array_key_exists('specialty', $arrFilter)) {
			$arrFilter['specialties.specialty']	= $arrFilter['specialty'];
			unset($arrFilter['specialty']);
		}
		if (array_key_exists('kol_name', $arrFilter)) {
			$arrFilter["concat(kols.first_name,' ',kols.last_name)"]= $arrFilter['kol_name'];
			unset($arrFilter['kol_name']);
		}
		foreach($arrFilter as $columnName=>$columnValue){
			$this->db->like($columnName,$columnValue);
		}
		
		if($count)
		{
			$query = $this->db->get('kols');
// 			echo $this->db->last_query();
			return $query->num_rows();
		}
		else
		{
			$this->db->limit($limit);
			$this->db->order_by($sidx,$sord);
			return $this->db->get('kols',$limit,$start);
		}
	}
	function getListCatogories($arrFilter,$start,$limit,$sidx,$sord,$count=false){
		$this->db->select('list_categories.*,COUNT(list_names.id) as lists_count');
		$this->db->where('list_categories.user_id',$this->session->userdata('user_id'));
		$this->db->where('list_categories.client_id',$this->session->userdata('client_id'));
		$this->db->join('list_names','list_names.category_id=list_categories.id','left');
		$this->db->group_by('list_categories.id');
		if (array_key_exists('is_public', $arrFilter)) {
			$pattern = '/'.$arrFilter['is_public'].'/i';
			if(($arrFilter['is_public']=="p") || ($arrFilter['is_public']=="P")){
				unset($arrFilter['is_public']);
			}else if(preg_match($pattern, "Private")) {
				$arrFilter['is_public']	= 0;
			}else if(preg_match($pattern, "Public")) {
				$arrFilter['is_public']	= 1;
			}else{
				$arrFilter['is_public']	= -1;
			}
		}
		foreach($arrFilter as $columnName=>$columnValue){
			$this->db->like($columnName,$columnValue);
		}
		if($count)
		{
			$query = $this->db->get('list_categories');
			return $query->num_rows();
		}
		else
		{
			$this->db->limit($limit);
			$this->db->order_by($sidx,$sord);
			return $this->db->get('list_categories',$limit,$start);
		}
	}
	function saveListOfKols($arrKols,$lastInsertId){
		foreach($arrKols as $kols){
			$arrKol['user_id']=$this->session->userdata('user_id');
			$arrKol['kol_id']=$kols;
			$arrKol['list_name_id']=$lastInsertId;
			$this->db->insert('list_kols',$arrKol);
		}
		return true;
	}
	function removeKolsFromMyList($arrDetails,$list_id){
		$this->db->where('list_name_id',$list_id);
		$this->db->where_in('kol_id', $arrDetails['ids']);
		$this->db->delete('list_kols');
		return true;
	}
	function deleteRecord($arrDetails){
		$this->db->where('id', $arrDetails['id']);
		$this->db->delete($arrDetails['table']);
		return true;
	}
	function exportKolsProfile($kol_ids){
		$this->db->select('kols_client_visibility.id as kols_client_visibility_id,kols.first_name,kols.middle_name,kols.last_name,specialties.specialty,kols.primary_phone,kols.primary_email,countries.country,');
		$this->db->where_in('kols_client_visibility.id',$kol_ids);
		$this->db->join('kols_client_visibility','kols_client_visibility.kol_id=kols.id','left');
		$this->db->join('specialties','kols.specialty=specialties.id','left');
		$this->db->join('countries','countries.countryId=kols.country_id','left');
		$result=$this->db->get('kols');
		return $result->result_array();
	}
}
?>