<?php
class requested_kol extends CI_Model {
	function updateClientPreKol($arrKol){
		$id = $arrKol['id'];
		unset($arrKol['id']);
		$this->db->where('id',$id);
		if($this->db->update('kols',$arrKol)){
			return true;
		}else{
			return false;
		}
	}
	function getAnalystManagerEmailId(){
		$emails = array();
		$this->db->distinct();
		$this->db->select('email');
		$this->db->where('client_id',1);
		$this->db->where('user_role_id',2);
		$emailResultSet = $this->db->get('client_users');
		foreach($emailResultSet->result_array() as $row){
			$emails[] = $row['email'];
		}
		$emails = array_unique($emails);
		$arrEmails = array();
		foreach($emails as $email){
			$arrEmails[] = array('email' => $email);
		}
		return $arrEmails;
	}
	function listAll(){
		$arrResults = array();
		$clientId = $this->session->userdata('client_id');
		//$this->db->select('user_requests.*,client_users.*,kols.salutation,kols.first_name as kol_first_name,kols.middle_name as kol_middle_name,kols.last_name as kol_last_name');
		$this->db->select('user_requests.status,user_requests.request_for,user_requests.comments,user_requests.is_re_request,user_requests.profile_type,kols.salutation,client_users.first_name as user_first_name,client_users.last_name as user_last_name,client_users.manager_id,user_requests.id,kols.id as kol_id,kols.first_name,kols.middle_name,kols.last_name,kols.specialty,client_users.user_name as user_full_name,organizations.name,countries.country, approvers.user_name as approved_by,approvers.first_name as approver_first_name,approvers.last_name as approver_last_name,user_requests.requested_on,user_requests.rej_or_appr_on');
		$this->db->join('client_users','client_users.id = user_requests.requested_by','left');
		$this->db->join('client_users as approvers','approvers.id = user_requests.rej_or_appr_by','left');
		$this->db->join('kols','kols.id = user_requests.kol_id','left');
		$this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
		$this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
		if($clientId != INTERNAL_CLIENT_ID)
			$this->db->where('client_users.client_id',$clientId);
			$this->db->order_by("user_requests.rej_or_appr_on","desc");
			$results = $this->db->get('user_requests');
			//echo $this->db->last_query();
			if(is_object($results) && $results->num_rows() > 0)
				$arrResults = $results->result_array();
				return $arrResults;
	}
	function getNonProfiledKols($profileStatus ,$clientId,$limit=null,$startFrom=null,$doCount=null,$sidx = '',$sord = '',$where = ''){
		$arrKols = array();
		$this->db->select('countries.country,kols.salutation,kols.primary_email,kols.address1,kols.primary_phone,specialties.specialty,organizations.name,client_users.first_name as user_first_name,client_users.last_name as user_last_name,kols.id as kol_id,kols.first_name,kols.middle_name,kols.last_name,kols.created_by,client_users.id,client_users.email,client_users.user_role_id,client_users.client_id,,client_users.first_name as user_full_name,kols.status');
		$this->db->join('client_users','client_users.id=kols.created_by','left');
		$this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
		$this->db->join('countries', 'countries.countryId = kols.country_id', 'left');
		$this->db->join('specialties','specialties.id=kols.specialty','left');
		if(is_array($profileStatus)){
			$this->db->where_in("kols.status",$profileStatus);
		}else{
			$this->db->where("(kols.status='".$profileStatus ."' or kols.status='".REJECT."')");
		}
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("(client_users.client_id=$clientId or client_users.client_id=".INTERNAL_CLIENT_ID.")");
		}
		if(!empty($where)){
			if(isset($where['kol_name'])){
				$this->db->where("(kols.first_name LIKE '%".$where['kol_name']."%' or kols.middle_name LIKE '%".$where['kol_name']."%' or kols.last_name LIKE '%".$where['kol_name']."%')");
			}
			if(isset($where['name']))
				$this->db->like('organizations.name',$where['name']);
				if(isset($where['specialty']))
					$this->db->like('specialties.specialty',$where['specialty']);
					if(isset($where['country']))
						$this->db->like('countries.Country',$where['country']);
						if(isset($where['primary_phone']))
							$this->db->like('kols.primary_phone',$where['primary_phone']);
							if(isset($where['primary_email']))
								$this->db->like('kols.primary_email',$where['primary_email']);
								if(isset($where['user_full_name'])){
									$cliId = INTERNAL_CLIENT_ID;
									$whereUsername	= "(concat(client_users.first_name,' ',client_users.last_name) LIKE '%".$where['user_full_name']."%' or (concat('Aissel Analyst',' ',client_users.first_name,' ',client_users.last_name) LIKE '%".$where['user_full_name']."%') AND client_users.client_id=".$cliId.")";
									$this->db->where($whereUsername);
								}
								if(isset($where['status'])){
									$str = $where['status'];
									if (preg_match("/$str/i","Requested")) {
										$this->db->where("(kols.status LIKE '%New%' OR kols.status LIKE '%".$where['status']."%')");
									}else if (preg_match("/$str/i","New")){
										$this->db->where("(kols.status NOT LIKE '%New%' AND kols.status LIKE '%".$where['status']."%')");
									}else{
										$this->db->like('kols.status',$where['status']);
									}
								}
		}
		if($limit != null){
			$this->db->limit($limit);
		}
		if($startFrom != null){
			$this->db->offset($startFrom);
		}
	
		if($sidx != null){
			switch($sidx){
				case 'name' : $this->db->order_by("organizations.name",$sord);
				break;
				case 'kol_name' : $this->db->order_by("kols.first_name",$sord);
				break;
				case 'specialty' : $this->db->order_by("specialties.specialty",$sord);
				break;
				case 'country' : $this->db->order_by("countries.Country",$sord);
				break;
				case 'primary_phone' : $this->db->order_by("kols.primary_phone",$sord);
				break;
				case 'primary_email' : $this->db->order_by("kols.primary_email",$sord);
				break;
				case 'status' :
					$this->db->order_by("kols.status",$sord);
					break;
				case 'user_full_name' :
					$this->db->order_by("client_users.client_id",$sord);
					$this->db->order_by("client_users.first_name",$sord);
					break;
			}
		}
		if(!$doCount){
			$resultSet = $this->db->get('kols');
			//			echo $this->db->last_query();
			//			exit();
			foreach($resultSet->result_array() as $row){
				$arrKols[]	= $row;
			}
			return $arrKols;
		}else{
			$resultSet = $this->db->count_all_results('kols');
			return $resultSet;
		}
	}
	function get($id, $idType = false){
		$rowData = array();
		//Flag is set to differentiate KolId and userRequestId
		if($idType == 'userRequestId'){
			$this->db->where('id',$id);
		}else{
			$this->db->where('kol_id',$id);
		}
		$results = $this->db->get('user_requests');
		if($results->num_rows() > 0)
			$rowData = $results->row_array();
				
			return $rowData;
	}
	function update($rowData){
		$this->db->where('id',$rowData['id']);
		if($this->db->update('user_requests',$rowData))
			return true;
			else
				return false;
	}
}
?>