<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/custom_overwrite.css" media="screen" />
<style>
.box-container {
    margin-top: 20px;
}
.inline{
	display: inline;
}
p.inline.title {
    font-weight: bold;
}
.ui-jqgrid .ui-jqgrid-pager .ui-pg-div span.ui-icon {
    margin: -1px 2px !important;
}
table.ui-pg-table {
    font-size: 11px;
}
.listingType{
	list-style: none;
}
</style>
<script>
$(document).ready(function(){
	// Settings for the Dialog Box
	var modalBoxAddOpts = {
			title: "",
			modal: true,
			autoOpen: false,
			width: 600,
			dialogClass: "microView",
			position: ['center', 160],
			open: function() {
				//display correct dialog content
			}
	};
	$("#exportKolsContainer").dialog(modalBoxAddOpts);
	
	list_kols_grid();
});
/** 
* Show/Hide the Search Tool Bar in the JQGrid
*/
function showKolImportBox(){
	$("#exportKolsContainer .profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#exportKolsContainer").dialog("open");
	$("#exportKolsProfileContent").load('<?php echo base_url();?>kols/analyst_kol_import_page');
	
	return false;	
}

function listRecordsPerPage(maxRecords,increament){
	var rowList=new Array();
 	for(i=increament;i<=maxRecords;i+=increament){
 		rowList.push(i);
 	} 	
 	return rowList;
}

/** 
* Show/Hide the Search Tool Bar in the JQGrid
*/
function toggleSearchToolbar(){ 			
	if(jQuery(".ui-search-toolbar").css("display")=="none") {
		jQuery(".ui-search-toolbar").css("display","");
	} else {
		jQuery(".ui-search-toolbar").css("display","none");
	}
};
function deleteSelectedKols(kolIds){
	jConfirm("Are you sure you want to delete selected KOL's?","Please confirm",function(r){
		if(r){
			/*$.ajax({
				url:'<?php echo base_url()?>kols/delete_kols/'+kolIds,
				type:'post',
				dataType:"json",
				success:function(returnMsg){
						list_kols_grid();
					}
			});*/
			$("#exportKolsContainer .profileContent").html("<div class='microViewLoading'>Loading...</div>");
			$("#exportKolsContainer").dialog("open");
			$("#exportKolsProfileContent").load('<?php echo base_url();?>kols/show_kol_delete_opts/'+kolIds);
		}else{
			return false;
		}
	});
}
function list_kols_grid(){
	var lastsel2;
	$('#gridKolsListing').html('');
    $('#gridKolsListing').html('<div class="gridWrapper"><div id="gridKolsListingPagintaion"></div><table id="gridKolsListingResultSet"></table><div>');
    grid = $("#gridKolsListingResultSet"),
    getUniqueNames = function(columnName) {
        var texts = grid.jqGrid('getCol',columnName), uniqueTexts = [],
            textsLength = texts.length, text, textsMap = {}, i;
     //   jAlert(texts.toSource());
        for (i=0;i<textsLength;i++) {
            text = texts[i];
            if (text !== undefined && textsMap[text] === undefined) {
                // to test whether the texts is unique we place it in the map.
                textsMap[text] = true;
                uniqueTexts.push(text);
            }
        }
        return uniqueTexts;
    },
    buildSearchSelect = function(uniqueNames) {
        var values=":All";
        $.each (uniqueNames, function() {
            values += ";" + this + ":" + this;
        });
        return values;
    },
    /*setSearchSelect = function(columnName) {
        grid.jqGrid('setColProp', columnName,
                    {
                        stype: 'select',
                        searchoptions: {
                            value:buildSearchSelect(['Yes','No','Re crawl']),
                            sopt:['eq']
                        }
                    }
        );
    };*/
    grid.jqGrid({
		url:'<?php echo base_url();?>analysts/kols/list_kols_grid',
		datatype: "json",
		colNames:['Id','Name','Specialty','Gender','Organizations', 'Pubmed ?','Trials ?','Created By','Pin','Status','Action'],
	   	colModel:[
			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},
			{name:'kol_name',index:'kol_name',search:true,
	   			formatter: function (cellvalue, options, rowObject) {
//	   				jAlert(rowObject.is_imported);
	   				if(rowObject.is_imported == parseInt(1)){
		   				 return "<a href='"+base_url+"/kols/view/"+rowObject.id+"' target='_NEW' class='link' title='" + $.jgrid.stripHtml(cellvalue) + "'>" +
				         $.jgrid.htmlEncode(cellvalue) + "</a> <span class='highlightImported'> (xls)<span>";
		   			}
				        return "<a href='"+base_url+"/kols/view/"+rowObject.id+"' target='_NEW' class='link' title='" + $.jgrid.stripHtml(cellvalue) + "'>" +
			            $.jgrid.htmlEncode(cellvalue) + "</a>";
	    	},firstsortorder:'asc'},
	   		{name:'specialty',index:'specialty',width:110, search:true},
	   		{name:'gender',index:'gender',search:true,width:50, resizable:false},
	   		{name:'organization',index:'organization',search:true},
	   		{name:'pubmed_processed',index:'pubmed_processed',width:90, editable: false, edittype:"select", editoptions:{value:"0:No;1:Yes;2:Re Crawl"}},
			{name:'trial_processed',index:'trial_processed',width:50,search:true, align:'center',resizable:false},
			{name:'created_by',index:'created_by',width:80,search:true},
			{name:'pin',index:'pin',search:true},
			{name:'status',index:'status',width:60,search:true},
			{name:'action',index:'action',width:45, align:'center',search:false, resizable:false}
			
	   	],
	   	onSelectRow: function(id){
		   	
        if(id && id!==lastsel2){
          grid.restoreRow(lastsel2);
          grid.editRow(id,true);
          lastsel2=id;
        }
       },
       onCellSelect: function(id){
				var option=$("option[value='0']", $('#'+id+'_pubmed_processed'));
				option.attr("disabled","disabled");
       },
       
       editurl: '<?php echo base_url();?>pubmeds/chnage_kol_pubmed_status',
	   	rowNum:10,
	   	multiselect: true,
	   	rownumbers: true,
	   	autowidth: true, 
	   	loadonce:false,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",		 
	   	pager: '#gridKolsListingPagintaion',
	   	mtype: "POST",
	   	sortname: 'name',
	    viewrecords: true,
	    sortorder: "desc",
	    shrinkToFit:true,
	    jsonReader: { repeatitems : false, id: "0" }, 
	    caption:"KOL Profiles",
	    gridComplete: function(){	
	    },
		rowList:paginationValues
	});
    grid.jqGrid('navGrid','#gridKolsListingPagintaion',{edit:false,add:false,del:false,search:false,refresh:false});
	//Toolbar search bar below the Table Headers
	//setSearchSelect('pubmed_processed');
	grid.jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
	grid.jqGrid('navButtonAdd',"#gridKolsListingPagintaion",{caption:"Delete",buttonicon : "ui-icon-trash", title:"Delete Select Row(s)",
		onClickButton:function (){
			var selectedKOLs	= $(this).getGridParam('selarrrow');
			/* if(selectedKOLs.length>0){
				deleteSelectedKols(selectedKOLs);
			}else{
				jAlert('Please select atleast one KOL');
			} */
			if(selectedKOLs.length>0){
				$("#exportKolsContainer .profileContent").html("<div class='microViewLoading'>Loading...</div>");
				$("#exportKolsContainer").dialog("open");
				$("#exportKolsProfileContent").load('<?php echo base_url();?>kols/show_kol_delete_opts/'+selectedKOLs);
			}else{
				jAlert('Please select atleast one KOL');
			}
		}
	});
	grid.jqGrid('navButtonAdd',"#gridKolsListingPagintaion",{caption:"Export",buttonicon:"ui-icon-document", title:"Export Select Row(s)",
		onClickButton:function (){
			var selectedKOLs	= $(this).getGridParam('selarrrow');
			if(selectedKOLs!=''){
				$("#exportKolsContainer .profileContent").html("<div class='microViewLoading'>Loading...</div>");
				$("#exportKolsContainer").dialog("open");
				$("#exportKolsProfileContent").load('<?php echo base_url();?>kols/show_kol_export_opts/'+selectedKOLs);
			}else{
				jAlert('Please select atleast one KOL');
			}
		}
	}); 
	/* grid.jqGrid('navButtonAdd',"#gridKolsListingPagintaion",{caption:"Assign to Clients",buttonicon:"ui-icon-transferthick-e-w", title:"Assign to Clients",
		onClickButton:function (){
			associateOrDisassociateKols();
		}
	});  */
	//Toggle Toolbar Search 
	grid.jqGrid('navButtonAdd',"#gridKolsListingPagintaion",{caption:"Search",buttonicon:"ui-icon-search",title:"Toggle Search",
		onClickButton:toggleSearchToolbar
	});
}
function makeStausAsCompleted(){


	var selectedKOLs	= $("#gridKolsListingResultSet").getGridParam('selarrrow');

	if(selectedKOLs == ""){
		jAlert("Please select atleast one KOL");
		return false;	
	}
	$('.msgBox').removeClass('success');
	$('.msgBox').addClass('notice');
	$('.msgBox').show();

	$('.msgBox').html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');

	var data={};
	data['kolIds']= selectedKOLs;
	$.ajax({
		url:'<?php echo base_url()?>requested_kols/update_kol_status_as_completed',
		type:'post',
		data:data,
		dataType:'json',
		success:function(returndata){
				if(returndata.status==true){
					$('.msgBox').text("Updated Successfully");
					$('.msgBox').fadeOut(1500);
					var status='<?php echo COMPLETED?>';
						$.each(selectedKOLs,function(key,value){
							jQuery("#gridKolsListingResultSet").jqGrid('setRowData',value,{status:status}); 
						});
					}
			}
		});
		
	return false;
}

//Ajax request to chnage the pubmed processing of the KOL
function chnagePubmedStatus(thisObj){
	var status = $(thisObj).parent().children(".pubmed-status").val();
	var kolId = $(thisObj).parent().parent().attr('id');
	var data={};
	data['kol_id']	=	kolId;
	data['status'] 	=	status;
	if(status != 'No'){
		$(thisObj).attr("disabled","disabled");
		$(thisObj).addClass('processing');
		$.ajax({
			url:'<?php echo base_url();?>pubmeds/chnage_kol_pubmed_status',
			type:'post',
			dataType:'text',
			data:data,
			success:function(returnData){
				$(thisObj).removeAttr('disabled');
				$(thisObj).removeClass('processing');
			}
		});
	}

	return false;
}

function caluculteProfileScore(){
	var selectedKOLs	= $("#gridKolsListingResultSet").getGridParam('selarrrow');

	if(selectedKOLs == ""){
		jAlert("Please select atleast one KOL");
		return false;	
	}
	$('.msgBox').removeClass('success');
	$('.msgBox').addClass('notice');
	$('.msgBox').show();

	$('.msgBox').html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
	var data={};
	data['sel'] = selectedKOLs;
	$.ajax({
		url:'<?php echo base_url()?>analysts/kols/caluculateAndInsertActivitesCount',
		dataType:'json',
		type:'post',
		data:data,
		success:function(returnData){
			if(returnData.status==true){
				$('.msgBox').text("Updated Successfully");
				$('.msgBox').fadeOut(1500);
			}else{
				$('.msgBox').text("Not Updated...");
				$('.msgBox').fadeOut(1500);
			}
		}
		});

}
function activityChartData(){
	$(".activityChartContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#activityContainer").dialog("open");
	$(".activityChartContent").load('<?php echo base_url()?>client_users/activity_chart_client_list');
	return false;

}

function updateStatus(){
	var status = $('#status').val();
	var kolId	= grid.getGridParam('selarrrow');
	if(kolId==''){
		jAlert("Please select at least one KTL");
		return false;
	}
	if(status==''){
		jAlert("Please select status");
		return false;
	}
	var data ={};
	data['kolId'] = kolId;
	data['status'] = status;
	data['send_mail'] = false;
	$('.msgBox').removeClass('success');
	$('.msgBox').addClass('notice');
	$('.msgBox').show();

	$('.msgBox').html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
	
	$.ajax({
		url:'<?php echo base_url()?>analysts/kols/update_status',
		data:data,
		type:'post',
		dataType:'json',
		success:function(){
			$.each(kolId,function(key,value){
				console.log(value);
				$('#'+value).find('td').eq(11).html(status);
			});
			$('.msgBox').text("Updated Successfully");
			$('.msgBox').fadeOut(1000);
		}
	});

}

function updatePubmedStatus(){
	var status = $('#pubmed_status').val();
	var kolId	= grid.getGridParam('selarrrow');
	if(kolId==''){
		jAlert("Please select at least one KTL");
		return false;
	}
	if(status==''){
		jAlert("Please select status");
		return false;
	}
	var data ={};
	data['kolId'] = kolId;
	data['status'] = status;
	$('.msgBox').removeClass('success');
	$('.msgBox').addClass('notice');
	$('.msgBox').show();

	$('.msgBox').html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
	
	$.ajax({
		url:'<?php echo base_url()?>pubmeds/update_kol_pubmed_status',
		data:data,
		type:'post',
		dataType:'json',
		success:function(){
			if(status == 0)
				status = "No";
			if(status == 1)
				status = "Yes";
			if(status == 2)
				status = "Recrawl";
			$.each(kolId,function(key,value){
				$('#'+value).find('td').eq(7).html(status);
			});
			$('.msgBox').text("Updated Successfully");
			$('.msgBox').fadeOut(1000);
		}
	});
}

function updateTrialStatus(){
	var status = $('#trial_status').val();
	var kolId	= grid.getGridParam('selarrrow');
	if(kolId==''){
		jAlert("Please select at least one KTL");
		return false;
	}
	if(status==''){
		jAlert("Please select status");
		return false;
	}
	var data ={};
	data['kolId'] = kolId;
	data['status'] = status;
	$('.msgBox').removeClass('success');
	$('.msgBox').addClass('notice');
	$('.msgBox').show();

	$('.msgBox').html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
	
	$.ajax({
		url:'<?php echo base_url()?>clinical_trials/update_kol_trial_status',
		data:data,
		type:'post',
		dataType:'json',
		success:function(){
			if(status == 0)
				status = "No";
			if(status == 1)
				status = "Yes";
			$.each(kolId,function(key,value){
				$('#'+value).find('td').eq(8).html(status);
			});
			$('.msgBox').text("Updated Successfully");
			$('.msgBox').fadeOut(1000);
		}
	});
}
function updatekoldataStatus(){
	var status = $('#kol_data_status').val();
	var udateDate = $('#updateDate').val();
	var kolId	= grid.getGridParam('selarrrow');
	if(kolId==''){
		jAlert("Please select at least one KTL");
		return false;
	}
	if(status==''){
		jAlert("Please select status");
		return false;
	}
	if(udateDate==''){
		jAlert("Please enter the date in mm/dd/yyyy format!");
		return false;
	}
	var checkDate = isValidDate(udateDate);
	if(checkDate==false){
		return false;
	}
	var data ={};
	data['kolId'] = kolId;
	data['status'] = status;
	data['user_date'] = udateDate;
	$('.msgBox').removeClass('success');
	$('.msgBox').addClass('notice');
	$('.msgBox').show();

	$('.msgBox').html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
	
	$.ajax({
		url:'<?php echo base_url()?>requested_kols/update_kol_data_status',
		data:data,
		type:'post',
		dataType:'json',
		success:function(){
			$('.msgBox').text("Data Status Changed Successfully");
			$('.msgBox').fadeOut(1000);
		}
	}); 
}
function dateFormat(e,src) {		
	if (!e) var e = window.event
	if (e.keyCode) code = e.keyCode;
	else if (e.which) code = e.which;
	
	if(code != 37 && code != 38 && code != 39 && code != 40) { 
		if(!src.value.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
			src.value=src.value.replace(/[^0-9\/]/g,'');  
		
			if(code!=8 && code!=46) // not backspace or delete
			{	
				src.value=src.value.replace(/[^0-9]/g,'');
				
				if (src.value.length == 2) {
			        src.value += "/";
			    }
			    				
				if (src.value.length > 2) {
					if(src.value.indexOf('/') != 2) {
						src.value = src.value.substring(0,2) + "/" + src.value.substring(2,src.value.length);
					}
				}
				
				if (src.value.length == 5) {
			        src.value += "/";
			    }
			    
				if (src.value.length > 5) {
					if(src.value.lastIndexOf('/') != 5) {
						src.value = src.value.substring(0,5) + "/" + src.value.substring(5,src.value.length);
					}
				}
				
				if(src.value.length >= 10)
				{
					return false;
				}
			}  
		}
	}
	return true;
}
function isValidDate(date){
	var month=date.substring(0,2);
	var day=date.substring(3,5);
	var year=date.substring(6);
	var isDateValid=true;
	
	if(month>12)
		isDateValid=false;
	if(day>31)
		isDateValid=false;
	if(year.length<4)
		isDateValid=false;
	if(date!='' && !isDateValid){
		$('#updateDate').val('');
		jAlert("Invalid Date");
		return false;
	}
}
</script>
<div class="box-container">
		<div class="col-md-12"> 
		<?php $userRoleId = $this->session->userdata('user_role_id');?>
				<div class="inline">
					<p class="inline title">Set Status:</p>
						<select name="updatestats" id="status" class="form-control inline" style="width:100px;">
							<option value="">Select</option>
							<option value="<?php echo New1?>">New</option>
							<?php if($userRoleId==ROLE_MANAGER || $userRoleId == ROLE_ADMIN){?>
							<option value="<?php echo APPROVED?>">Approved</option>
							<?php }?>
							<option value="<?php echo PROFILING?>">Profiling</option>
							<option value="<?php echo REVIEW?>">Review</option>
								<?php if($userRoleId==ROLE_MANAGER || $userRoleId == ROLE_ADMIN){?>
							<option value="<?php echo COMPLETED?>">Completed</option>
							<?php }?>
						</select>
					<button onclick="updateStatus()" class="btn btn-primary"><span class="glyphicon glyphicon-save"></span> Save</button>
				</div>
				<div class="inline">
					<p class="inline title">Pubmed Status:</p>
						<select id="pubmed_status" class="form-control inline" style="width:100px;">
							<option value="">Select</option>
							<option value="0">No</option>
							<option value="1">Yes</option>
							<option value="2">Recrawl</option>
						</select>
					<button onclick="updatePubmedStatus()" class="btn btn-primary"><span class="glyphicon glyphicon-save"></span> Save</button>
				</div>
				<div class="inline">
					<p class="inline title">Trial Status:</p>
						<select id="trial_status" class="form-control inline" style="width:100px;">
							<option value="">Select</option>
							<option value="0">No</option>
							<option value="1">Yes</option>
						</select>
					<button onclick="updateTrialStatus()" class="btn btn-primary"><span class="glyphicon glyphicon-save"></span> Save</button>
				</div>
				<div class="inline">
					<p class="inline title">Update Status:</p>
						<select id="kol_data_status"  class="form-control inline" style="width:100px;">
							<option value="">Select</option>
							<option value="1">Crawled</option>
							<option value="2">Updated</option>
						</select> 
						<p class="inline title">Date:</p>
						<input type="text" name="update_date" value="" placeholder="mm/dd/yyyy" id="updateDate" class="form-control inline" size="10" maxlength="10" onkeyup="dateFormat(event,this)" onmouseout="isValidDate(this.value)" style="width:100px;"></input>
						
					<button onclick="updatekoldataStatus()" class="btn btn-primary"><span class="glyphicon glyphicon-save"></span> Save</button>
				</div>
				
		</div>
		<div class="col-md-12"> 
			<div class="col-md-12">
				<button class="btn btn-default pull-right clearfix"><span class="green glyphicon glyphicon-plus-sign"></span> <b>Add New Profile</b></button>
			</div>
			<div class="clearfix" style="margin:10px 0px;"></div>
			<div>
				<div id="gridKolsListing">
					<div class="gridWrapper">
						<div id="gridKolsListingPagintaion"></div>
						<table id="gridKolsListingResultSet"></table>
					</div>
				</div>
			</div>
		</div>
		
		<div class="col-md-12"> 
				<div class="col-md-4">
					<ul class="listingType">
							<li><a href="<?php echo base_url();?>clinical_trials/process_CITDs_only_KOLs">Process Clinical Trials</a></li>
							<li><a href="<?php echo base_url();?>pubmeds/process_pubmeds"> Process Publications</a></li>
							<li><a href="#" onclick="caluculteProfileScore()"> Process Profile Score</a></li>
							<li><a href="<?php echo base_url();?>feedbacks/list_feedbacks"> Feedbacks</a></li>
							<li><a target="_new" href="<?php echo base_url();?>kols/calculate_dashboard_data">Recalculate KOLs dashboard data</a></li>
							<!-- a target="_new" href="<?php echo base_url();?>reports/calculate_reports_chart_data">Recalculate Activity Charts Data</a-->						
							<li><a href="javascript:void(0)" onclick="activityChartData()">Recalculate Activity Charts Data</a></li>
					</ul>
				</div>
				<div class="col-md-4">
				<ul  class="listingType">
	<!--					<a href="<?php echo base_url();?>login/list_all_user_analytics" target="_new">User Analytics</a>-->
							<li><a href="<?php echo base_url();?>login/list_all_user_analytics_grid_view" target="_new">User Analytics</a></li>
							<!-- li><a href="<?php echo base_url();?>cli/list_cron_jobs" target="_new">Cron Jobs</a></li> -->
							<li><a href="<?php echo base_url();?>kols/add_events_to_affiliations" target="_new">Process Industry Events</a></li>
							<li><a href="<?php echo base_url();?>kols/updateKolLatLong" target="_new">Process Bulk Lat Long</a></li>
							<li><a href="<?php echo base_url();?>pubmeds/re_crawl_publications_types"> Process Publications Type</a></li>
				</ul>
			</div>
			<div class="col-md-4" style="margin-top:12px;"> 
				<button class="btn btn-default pull-right"><span class="green glyphicon glyphicon-plus-sign"></span> <b>Add New Profile</b></button>
			</div>	
		</div>
</div>
<!-- Container for the 'Kol's Export' modal box -->
	<div id="exportKolsDialog">	
		<div id="exportKolsContainer" class="microProfileDialogBox">
			<div class="profileContent" id="exportKolsProfileContent"></div>
		</div>
	</div>