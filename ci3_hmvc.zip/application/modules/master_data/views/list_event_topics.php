<script type="text/javascript">
function list_event_topics_grid(){
	$('#gridKolsListing').html('');
    $('#gridKolsListing').html('<div class="gridWrapper"><div id="gridKolsListingPagintaion"></div><table id="gridKolsListingResultSet"></table><div>');
    grid = $("#gridKolsListingResultSet")
    
    grid.jqGrid({
		url:'<?php echo base_url();?>master_data_controller/load_grid_event_topics',
		datatype: "json",
		colNames:['Id','Name','Action'],
	   	colModel:[
			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},			
	   		{name:'name',index:'name',width:75, search:true},	   		
			{name:'action',index:'action',width:10, align:'center',search:false, resizable:false}
			
	   	],       
	   	rowNum:10,
	   	multiselect: true,
	   	rownumbers: true,
	   	autowidth: true, 
	   	loadonce:false,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",		 
	   	pager: '#gridKolsListingPagintaion',
	   	mtype: "POST",
	   	sortname: 'name',
	    viewrecords: true,
	    sortorder: "asc",
	    shrinkToFit:true,
	    jsonReader: { repeatitems : false, id: "0" }, 
	    caption:"List_Event_Topics ",
	    gridComplete: function(){	
	    },
		rowList:paginationValues
	});
	    grid.jqGrid('navGrid','#gridKolsListingPagintaion',{edit:false,add:false,del:false,search:false,refresh:false});
    	 grid.jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
}
$(document).ready(function(){	
	var eventDialogOpts = {
			title: "Add/Edit Event_Topics",
			modal: true,
			autoOpen: false,
			height: 300,
			width: 350,
			dialogClass: "microView",
			open: function() {
				//display correct dialog content
			},
			close:function(){
			}
	};
	$("#eventContainer").dialog(eventDialogOpts);
	list_event_topics_grid();	
});
function editEventTopic(id,type){
	$(".addEventTopicsContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#eventContainer").dialog("open");
	$(".addEventTopicsContent").load('<?php echo base_url().'master_data_controller/edit_event_topics'?>',function(){
		$("#hiddenId").val(id);
		$("#eventtopics").val(type);
	});
	return false;	
}
function saveEventTopics(){
	var topic = $('#eventtopics').val();
	var id = $('#hiddenId').val();
	id = id == '' ? 0 : id;		
	var url = 'master_data_controller/save_event_topics';
	//var confirmed = confirm('Are you sure to Update ?');	
		eventTopic(id,topic,url,false);
}
function eventTopic(id,topic,action,isDel){
	$.ajax({
		type:'post',
		url:'<?php echo base_url();?>'+action,
		data:"topic="+topic+"&id="+id,
//			dataType:'json',
		success:function(returnData){
// 			console.log("Response : "+returnData);
			if(!isDel){
				$('#responseMessage').html(returnData);
			} else {
				alert(returnData);
			}
			list_event_topics_grid();
	 	},
	 	error:function(){
		 	alert("already exist");
		}
	 });
}
function deleteSelectedEventTopics(id){
	if(id == 0){
		$('#responseMessage').html("Record cannot be deleted");
		return;
	}
	var url = 'master_data_controller/delete_event_topics';
	var confirmed = confirm('Are you sure to Delete ?');
	if(confirmed){
		eventTopic(id,'',url,true);
	} else {
		alert("Operation Cancelled");
	}
}
function closeModal(){
	$("#eventContainer").dialog("close");
	
}
</script>
<style>
.ui-jqgrid .ui-jqgrid-btable{
        table-layout:auto;
    }
    .ui-jqgrid .ui-jqgrid-htable{
        table-layout:auto;
    }
</style>
<div>
	<div class="extraOptions">
		<div class="rightSideOptions">
			<a class="addLink" style="cursor: pointer;"
				onclick="editEventTopic();return false;"><img
				src="<?php echo base_url();?>images/bullet_add.png" border="0"
				style="height: 30px; vertical-align: middle;" />Add_Event_Topic </a>
		</div>
	</div>
	<div id="gridKolsListing">
		<div class="gridWrapper">
			<div id="gridKolsListingPagintaion"></div>
			<table id="gridKolsListingResultSet"></table>
		</div>
	</div>
</div>
<!-- Modal content -->
<div id="eventContainer" class="microViewLoading">
	<div class="addEventTopicsContent"></div>
</div>
<div id="specclientContainer" class="microViewLoading">
	<div class="addSpecclientContent"></div>
</div>
