<?php
/*
 * To add surveys
 *  
 * @Author		: Laxman K
 * @since 		: KOLM v5.5 Otsuka 1.0.11
 * Created on	: 18-03-2013
 *  
 */
?>
<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array('surveys/list',
							'jquery/date',
							'jquery/jquery-ui-1.8.16.datepicket',
							'jquery/daterangepicker.jQuery',
							'i18n/grid.locale-en',
							'jquery.jqGrid.min',
							'chosen.jquery',
							'jquery/jquery.validate1.9.min'
							);
	// add the JS files into queue i.e Append to the existing queue
	$prevjs = $this->config->item('js_files_to_load');
	if($prevjs == null)
		$prevjs = array();
	$this->config->set_item('js_files_to_load',array_merge($prevjs,$queued_js_scripts));
?>
	<!-- JQGrid Plugins -->
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
	<link rel="stylesheet" href="<?php echo base_url();?>css/ui.daterangepicker.css" type="text/css" />
	<style type="text/css">
		#contentWrapper.span-23 {
			background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
		    background-position: 135px 50%;
		    background-repeat: repeat-y;
		}
		.addLink {
			width:314px;
			float: right;
		}
		.buttonsWarpper{
			float: right;
			width: 350px;
		}
		#surveysList{
			clear:both;
		}
		#gridContainer,#subgridContainer{
			/*float: left;*/
			position: relative;
		}
		#subgridContainer{
			top:-125px;
	/*		left:815px;*/
		}
		#backButton{
			display: none;
		}
		#surveyContainer{
			overflow: hidden;
			position: relative;
		}
		.addLink{
			height: 25px;
			text-align: right;
			margin-bottom: 5px;
		}
		#surveyContainer .kolRequestIcon{
			background-position: -181px 120px;
			margin-left: 0px;
		}
		#surveyContainer .orgRequestIcon {
	    	background-position: -354px 119px;
	    	margin-left: 0px;
	    }
		.gridWrapper .ui-jqgrid tr.jqgrow td div.microViewIcon{
			background-position: 3px 2px !important;
		    height: 22px !important;
		    width: 25px !important;
		}
		#subgridContainer div.actionIconsContainer{
			width: 90px;
		}
		div.calToday{
			background: url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat scroll -73px -32px transparent;
			width: 16px;
			float: right;
		}
		#tooltip-list-surveys{
			left: 71px;
		    position: absolute;
		    top: 4px;
		    z-index: 1001;
		}
		#tooltip-create-survey{
		    /*position: absolute;
		    right: 133px;
    		top: 3px;*/
    		display: inline-block;
    		float: right;
		}
		.microViewIcon{margin-right: 8px !important;}
	</style>
	<?php
		$surveyId	 = 0;
		$surveyName	 = '';
		if(isset($arrSurveyData[0]['id'])){
			$surveyId	= $arrSurveyData[0]['id'];
			$surveyName	= $arrSurveyData[0]['name'];
		}
	?>
	<script type="text/javascript">
		var userRoleId	= <?php echo $this->session->userdata('user_role_id');?>;
		var userId	= <?php echo $this->session->userdata('user_id');?>;
		var surveyId	= <?php echo $surveyId;?>;
		var surveyName	= "<?php echo $surveyName;?>";
		// Grid title and header
		var surveyTile = "<?php echo lang("Surveys");?>";
		var nameHeader = "<?php echo lang("Surveys.Name");?>";
		var startDateHeader = "<?php echo lang("track.StartDate");?>";
		var endDateHeader = "<?php echo lang("track.EndDate");?>";
		var statusHeader = "<?php echo lang("Surveys.Status");?>";
		var createdByHeader = "<?php echo lang("Surveys.CreatedBy");?>";
		var actionHeader = "<?php echo lang("Overview.Action");?>";
		var respondentTitle = "<?php echo lang("Surveys.RespondentTitle");?>";
		var respondentHeader = "<?php echo lang("Surveys.Respondent");?>";
		var organizationHeader = "<?php echo lang("Surveys.Organization");?>";
		var cityHeader = "<?php echo lang("Surveys.City");?>";
		var stateHeader = "<?php echo lang("Surveys.State");?>";
		jqgridIds	= new Array('listSurveysResultSet','listSurveyRespondentsResultSet');
 	</script>
	<?php $helpLink = "<a class='help-link' href='".getSSOUrl($this->session->userdata('user_full_name'), $this->session->userdata('email'))."&redirect_to=/support/solutions/articles/129921-creating-new-surveys' target='_new'>View Additional Help</a>"; ?>
<div id="container">
	<div id="surveyContainer">
		<div class="buttonsWarpper">
			<div class="addLink">
<!--				<button id="backButton" onclick="togglegrids();">Back To Questions</button>-->
				<a href="#" class="blueButton" id="toggleGridBtn" style="display:none;" onclick="togglegrids();">Back To Questions</a>
				<?php if($this->session->userdata('user_role_id')==ROLE_MANAGER || $this->session->userdata('user_role_id')==ROLE_ADMIN){?>
					<span id="tooltip-create-survey" class="map-info tooltop-bottom"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>You can create as many influence mapping surveys as you want. Click to create a new survey.<?php echo $helpLink;?></span>">&nbsp;</a></span>
<!--					<label class="link" onclick="addSurvey();"><div class="actionIcon addIcon"></div>Create New Question</label>-->
					<a href="#" class="NewBlueButton NewAddIcon" onclick="addSurvey();">Create New Question</a>
				<?php }?>
				<!--<button id="surveyButton" onclick="gotoSurvey();">Start Survey</button>
			--></div>
		</div>
		<div id="surveysList">
			<div class="gridWrapper" id="gridContainer">
				<span id="tooltip-list-surveys" class="map-info tooltop-bottom"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>This is a list of all the influence surveys conducted. Click on the survey name to view a list of all individuals who have responded (Respondents).</span>">&nbsp;</a></span>
				<div id="listSurveysPage"></div>
				<table id="listSurveysResultSet"></table>
			</div>
			<div class="gridWrapper" id="subgridContainer">
				<div id="listSurveyRespondentsPage"></div>
				<table id="listSurveyRespondentsResultSet"></table>
			</div>
			<!-- Container for the 'Interaction Add' modal box -->
			<div id="dailog1">	
				<div id="addSurveyContainer" class="microProfileDialogBox">
					<div class="profileContent" id="addSurveyProfileContent"></div>
				</div>
			</div>
		</div>
	</div>
	<div id="dailog2">
		<!-- Container for the 'Micro Profile'  box -->
		<div id="contentHolder" class="callOutTest microView" style="display: none;">
			<div>
				<a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeKolProfile();" class="ui-icon ui-icon-closethick">close</span></a>
			</div>
			<div class="profileContent"></div>
		</div>
		<div id="arraouHolder" class="callOutTest" style="display: none;"><div class="arrowMarkIcon"></div></div>
	</div>
	<div id="addNewKol" class="microProfileDialogBox">
		<div class="addNewKolContent profileContent"></div>
	</div>
	<div id="addNewOrg" class="microProfileDialogBox">
		<div class="addNewOrg profileContent"></div>
	</div>
</div>