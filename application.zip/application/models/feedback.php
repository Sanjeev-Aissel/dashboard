<?php
/**
 * File Description : modal for feedback controller
 * 
 * @author		Laxman K
 * @since		5.0
 * @Created on  Aug 21, 2012
 */


class Feedback extends Model{

	//Constructor
	function Feedback(){
		parent::Model();
		
	}
	
	function getFeedbackTypes(){
		$results = $this->db->get('feedback_types');
		foreach($results->result_array() as $row){
			$arrData[$row['id']] = $row;
		}
		return $arrData;
	}
	
	function saveFeedbackDetails($rowData){
 		if($this->db->insert('feedbacks',$rowData))
			return $this->db->insert_id();
		else
			return false;
	}
	
	function getAllFeedbacks(){
		$this->db->select('clients.name as clientName, feedbacks.*,feedback_types.name as feedback_type, client_users.first_name,  client_users.last_name');
		$this->db->join('clients', 'clients.id = feedbacks.client_id', 'left');
		$this->db->join('client_users', 'client_users.id = feedbacks.created_by', 'left');
		$this->db->join('feedback_types','feedback_types.id=feedbacks.type_id','left');
		$results = $this->db->get('feedbacks');
		//echo $this->db->last_query();
		foreach($results->result_array() as $row){
			$row['user_full_name'] = $row['first_name'].' '.$row['last_name'];
			$arrData[] = $row;
		}
		return $arrData;
	}
	function getFeedbackDetails($id){
		$this->db->select('clients.name as clientName, feedbacks.*,feedback_types.name as feedback_type, client_users.first_name,  client_users.last_name');
		$this->db->join('clients', 'clients.id = feedbacks.client_id', 'left');
		$this->db->join('client_users', 'client_users.id = feedbacks.created_by', 'left');
		$this->db->join('feedback_types','feedback_types.id=feedbacks.type_id','left');
		$this->db->where('feedbacks.id',$id);
		$results	= $this->db->get('feedbacks');
		$row		= $results->result_array();
		$row[0]['user_full_name'] = $row['first_name'].' '.$row['last_name'];
		return $row[0];
	}
	
	function getFeedbackSenderMailId($userId){
		$this->db->where('client_users.id', $userId);
		$this->db->select('client_users.email');
		$results = $this->db->get('client_users');
		foreach($results->result_array() as $row){
			$arrData = $row;
		}
		return $arrData;
	}
	
	function getSupportEmailIdByClientId($clientId){
		$supporMailId	= '';
		$this->db->select('support_email_id');	
		$this->db->where('id',$clientId);
		$result = $this->db->get("clients");
		foreach ($result->result_array() as $row){
			$supporMailId = $row['support_email_id'];
		}
		return $supporMailId;
	}
}