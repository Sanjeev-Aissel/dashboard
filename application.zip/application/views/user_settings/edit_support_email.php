<style type="text/css">
	#submitBtn{
		display: none;
	}
	#supportEmailId .text{
		font-weight: bold;
	}
	#supportEmailId td{
		border-bottom: 1px solid #CCCCCC;
		border-right: 1px solid #CCCCCC;
	}
	#supportEmailId tr td:FIRST-CHILD{
		border-left: 1px solid #CCCCCC;
	}
	#supportEmailId tr:FIRST-CHILD td{
		border-top: 1px solid #CCCCCC;
	}
	div.saveIcon{
		background: url("<?php echo base_url()?>images/kolm-sprite-image.png") repeat scroll -220px -30px rgba(0, 0, 0, 0)
	}
	tr.headerBg th {
	    text-align: center;
	}
	#supportEmailId tr:hover{
		background-color: #d3dfed;
	}
</style>
<script type="text/javascript">

	var prevId = '';
	var prevVal = '';
	function editEmailId(thisEle,id){
			$("#"+prevId).children("td").eq(2).html(prevVal);
			var tdVal = $("#"+id).children("td").eq(2).text();
			$("#"+id).children("td").eq(2).html("<input type='text' value='"+tdVal+"' size='30'></input>");
			$("#"+prevId).children("td").eq(3).find("div").replaceWith('<div onclick="editEmailId(this,'+prevId+'); return false;" class="actionIcon editIcon tooltip-demo tooltop-left"><a rel="tooltip" class="tooltipLink" href="#" data-original-title="Settings"></a></div>');
			$(thisEle).replaceWith('<div style="float: left;" onclick="updateFilter('+id+');return false;" class="actionIcon saveIcon"><a rel="tooltip" class="tooltipLink" href="#" data-original-title="Save Changes">&nbsp;</a></div>');
			prevId = id; 
			prevVal = tdVal;
		}

	function updateFilter(id){
		 var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		 var data = {}; 
		 data['id'] = id;
		 data['emailAddress'] = $("#"+id).children("td").eq(2).find("input").val();
		  if(regex.test(data['emailAddress'])){
				jConfirm("Are you sure you want to change the email address for Support?","Please Confirm",function(r){
						if(r){
							$("#settingsContentHolder").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
								$.ajax({
										url:base_url+"user_settings/update_support_email_address",
										data: data,
										type: "post",
										dataType: "json",
										success: function(returnData){
											if(returnData.status){
												prevId = '';
												prevVal = '';
												$("#"+id).children("td").eq(2).html(data['emailAddress']);
												$("#"+id).children("td").eq(3).find("div").replaceWith('<div onclick="editEmailId(this,'+id+'); return false;" class="actionIcon editIcon tooltip-demo tooltop-left"><a rel="tooltip" class="tooltipLink" href="#" data-original-title="Settings"></a></div>');
												$("#settingsContentHolder").unblock();	
											}		
									}
									});
							}
					});
			  }else{
				  jAlert("Please enter the valid email address");
				  }
		}	
</script>
<div class="topHeader">
	<div class="headerTitle">
		<div class="titleOfPage"><h3>Configure Support Email address</h3></div>
	</div>
</div>
<div class="pageWrapper" style="margin-top: 20px;">
	<table id="supportEmailId">
		<tr class="headerBg">
			<th class="text">Sl No.</th>
			<th class="text">Client name</th>
			<th class="text">Support e-mail id</th>
			<th class="text">Action</th>
		</tr>
		<?php $i=1;
		$rowType = 0; 
		foreach($arrSupporEmailId as $clients){
			if($rowType){
				$rowType	= 0;
				$rowClass	= 'oddRow';
			}else{
				$rowType	= 1;
				$rowClass	= 'evenRow';
			}
		?>
		<tr id='<?php echo $clients['id'];?>' class="<?php echo $rowClass?>">
			<td><?php echo $i;?></td>
			<td><?php echo $clients['name'];?></td>
			<td style="min-width: 200px;"><?php echo $clients['support_email_id'];?></td>
			<td>
				<div onclick="editEmailId(this,<?php echo $clients['id'];?>); return false;" class="actionIcon editIcon tooltip-demo tooltop-left">
					<a rel="tooltip" class="tooltipLink" href="#" data-original-title="Settings"></a>
				</div>
			</td>
		</tr>
		<?php $i++;}?>
	</table>
	<table class="userDetails">
		<tr>
			<td colspan="2">
				<div id="submitBtn" style="margin-left: 155px">
					<input type="button" name="fg" onclick="cancelEdit();"  value="Cancel">
					<input type="button" onclick="updateUserData();" value="Submit">
				</div>
			</td>
		</tr>
	</table>
</div>
