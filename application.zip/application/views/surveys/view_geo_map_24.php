<?php
/*
 * Page to show survey network map
 *  
 * @Author		: Ramesh B
 * @since 		: KOLM v5.5 Otsuka 1.0.11
 * Created on	: 15-05-2013
 *  
 */
?>
<?php
	//jit.forecedirected&rgraph_mix
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array('jit',
							'jquery.autocomplete',
							'surveys/view_report',
							'jquery/jquery.validate1.9.min'
							);
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
	
	$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {getOrganizationInfluenceData();}";
?>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet">
<script type="text/javascript" src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>
<!--[if (IE)]>
	<script language="javascript" type="text/javascript" src="<?php echo base_url()?>js/excanvas.js"></script>
<![endif]-->
<script type="text/javascript">
var baseUrl='<?php echo base_url();?>';

function getSurveyGeoData(){
	$('#chartFooter').slideToggle('slow');
	if(!$('#queryOptContainer').html() != '')
		$('#queryOptContainer').prepend($('#queryContainer').html());
	//$('#surveyNetworkMap').slideToggle('slow');

	animateMicroviewBoxHide();
var pinInfoBox;  //the pop up info box
    var infoboxLayer = new Microsoft.Maps.EntityCollection();
    var pinLayer = new Microsoft.Maps.EntityCollection();
    var apiKey = "Ar8w95fg_ASilxr_0WM12V18M3vRQ9RC3hE0zbHzvXztyzbURm9qK7x5JEt3yn2b";

        map = new Microsoft.Maps.Map(document.getElementById("myMap"), {credentials: apiKey});
        
        map.setView({ zoom: 3, center: new Microsoft.Maps.Location(39.2102, -81.6642) })
        // Create the info box for the pushpin
        pinInfobox = new Microsoft.Maps.Infobox(new Microsoft.Maps.Location(0, 0), { visible: false });
        infoboxLayer.push(pinInfobox);

        method = base_url+'maps/filter_map_kols';
		$.post(method,function(returnData){
			var mark='';
			$.each(returnData,function(key,value){
				//Loop through each kol and get the Latitude and Longitude
				$.each(value,function(key2,value2){
					//create a point by setting the Latitude and Longitude values
					//var point = new GLatLng(value.Latitude, value.Longitude);
					//alert(value.connections);
					
				        var latLon = new Microsoft.Maps.Location(value2.latitude, value2.longitude);
			            var pin = new Microsoft.Maps.Pushpin(latLon);
			            pin.Title = value2.id;//usually title of the infobox
			          //  pin.Description = "<div id=kolImage>"+"<img class='micro_view_icon' width='80' title='MicroView' src='"+base_url+"images/kol_images/resized/"+value.profile_image+"'>"+" <br /> <a target='_new' href='"+base_url+"kols/view/"+value.id+"'><img width='80' height='20' style='padding-left:1px;' src='"+base_url+"images/view.gif'/></a></div>"+"<div id=addrssInfo>"+"<b>"+value.kolName+"<br/></b>"+value. specialty+"<br/>"+value.address1+" "+value.address2+"<br/>"+value.city+", "+value.postal_code+" <br/>"+value.Region+" "+value.Country+"</div> " ;; //information you want to display in the infobox
			           // pin.Description = "<div id=kolImage>"+value2.name+value2.id+"</div>"
			            pinLayer.push(pin); //add pushpin to pinLayer
			            Microsoft.Maps.Events.addHandler(pin, 'click', displayInfobox);
			            var pushpinClick= Microsoft.Maps.Events.addHandler(pin, 'mouseout', hide); 
			           // var pushpinClick= Microsoft.Maps.Events.addHandler(pin, 'mouseover',displayEventInfo);
			               
			            	//$.each(value2.connections,function(key,value1){
				            //var polyline = new Microsoft.Maps.Polyline([new Microsoft.Maps.Location(value2.latitude, value2.longitude),new Microsoft.Maps.Location(value1.latitude, value1.longitude)], {strokeThickness:1}); 
				            //map.setView( {zoom:8}); 
				          //  map.entities.push(polyline);
				            //var pushpinClick= Microsoft.Maps.Events.addHandler(pin, 'mouseout', hide); 
			               // });
			              
			            var pushpinClick= Microsoft.Maps.Events.addHandler(pin, 'mouseout', hide); 
			            // latlon = map.getCenter(); 
			           // alert(value.connections.toSource());
			           
			            $.each(value2.connections,function(key,value1){
			            	
			            	
				            var polyline = new Microsoft.Maps.Polyline([new Microsoft.Maps.Location(value2.latitude, value2.longitude),new Microsoft.Maps.Location(value1.latitude, value1.longitude)], {strokeThickness:1}); 
				            //map.setView( {zoom:8}); 
				            map.entities.push(polyline);
				          //  var latLon = new Microsoft.Maps.Location(value1.latitude, value1.longitude);
				            var pin = new Microsoft.Maps.Pushpin(latLon);
				            pin.Title = value1.kol_id;//usually title of the infobox
				          //  pin.Description = "<div id=kolImage>"+"<img class='micro_view_icon' width='80' title='MicroView' src='"+base_url+"images/kol_images/resized/"+value1.profile_image+"'>"+" <br /> <a target='_new' href='"+base_url+"organizations/view/"+value1.id+"'><img width='80' height='20' style='padding-left:1px;' src='"+base_url+"images/view.gif'/></a></div>"+"<div id=addrssInfo>"+"<b>"+value1.name+"<br/></b><br/>"+value1.address+"<br/>"+value1.city+", "+value1.postal_code+" <br/>"+value.region+" "+value1.country+"</div> " ;; //information you want to display in the infobox
				          //  pin.Description = "<div id=kolImage>"+value1.name+value1.kol_id+"</div>"
				            pinLayer.push(pin); //add pushpin to pinLayer
				            Microsoft.Maps.Events.addHandler(pin, 'click', displayInfobox);
				            });
			           //var polyline = new Microsoft.Maps.Polyline([new Microsoft.Maps.Location(value.latitude, value.longitude),new Microsoft.Maps.Location(40.4008,-75.8851)], {strokeThickness:1}); 
			            //map.setView( {zoom:8}); 
			          //  map.entities.push(polyline);
			          //  polyline.setOptions({visible: false}); 
			           
				 });
		 	});
	  	},"json");	
       
		
        map.entities.push(pinLayer);
        map.entities.push(infoboxLayer);

        
}
   

    function hide(e){
    	
    	  var polygon= map.entities.get(map.entities.getLength()-1);
          //set the visible property to true to view polygon 
          polygon.setOptions({visible: false}); 
    }
    
    function displayEventInfo1(){
    	 var polyline = new Microsoft.Maps.Polyline([new Microsoft.Maps.Location(-9.433, 159.95),new Microsoft.Maps.Location(51.838,-1.804)], null); 
         // map.setView( {zoom:8}); 
          map.entities.push(polyline);
    	
    }
    function displayInfobox(e) {
    	e.target.Description = "<div id=kolImage>ssss</div>";
    	pinInfobox.setOptions({title: e.target.Title, description: e.target.Description, visible:true, offset: new Microsoft.Maps.Point(0,25)});
        pinInfobox.setLocation(e.target.getLocation());
    }

    function hideInfobox(e) {
        pinInfobox.setOptions({ visible: false });
    }


	$("#listSurveysResultSet .jqgrow td::nth-child(4)").live('click',function(){
		var id = $(this).parent().attr("id");
		showIndivisualSurveyMap(id);
	});
	







</script>

<style>
	#mapsContent{
		float: left;
	}
	#addrssInfo{
		text-align: left;
		color:#000000;
		font-family:arial,helvetica,sans-serif;
		font-size:13px;
		padding-left: 94px;
		margin-top: 12px;
	}
	#kolImage{
		float: left;
		vertical-align: bottom;
	}
	
	#myMap{
	position:relative; 
	width:750px; 
	height:750px;
	}
	.Infobox{
		width:356px !important;	
	}
	
	
div.filterSearchIcon {
    display: inline-block;
    float: none;
    margin-bottom: -2px;
    margin-right: -20px;
    position: relative;
}
div.filterSearchIcon {
    background: url("../images/kolm-sprite-image.png") repeat scroll -52px -3px transparent;
    float: left;
    height: 16px;
    margin-left: 1px;
    margin-top: 5px;
    position: absolute;
    width: 16px;
}
#organization {
    padding-left: 15px;
    width: 278px;
}

#orgSelectArea{
	 margin-left: 143px;

}
	}
</style>


<div id="searchContainer1">
	<div id="searchTopMenus1"></div>
		<div class="myKolLists11">
			<div id="searchResultsContainer1" >
				
			<div id="mapsContent">			
				<div id='myMap' style=""></div>
			</div>
		
			</div>
			
		</div>
	<div class="clear">&nbsp;</div>
</div>
	
				
<style>
#contentWrapper.span-23 {
    background-image: url("http://203.129.219.11/kolm_otsuka/images/verticlesep_terNav.jpg");
    background-position: 135px 50%;
    background-repeat: repeat-y;
}
</style>