  <!doctype html>
    <html>
    <head>
    <meta charset="utf-8">
    <title>Move from one select box to another</title>
    <style type="text/css">
  #left,#right   {
        width: 200px;
        float: left;
    }
    input{
        margin-top:501px;
        margin-left:-331px;
        
    }
    #mergedList{
       height:600px;
        overflow: scroll;
    }
  
    select{
        overflow-x:auto;
        
    }
    </style>
<!--    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js">
    </script>-->
    
<script>
$(function () {
$('select').listbox({'
searchbar': true // enable a search bar to filter & search items
});
});
</script>
    <script>
   
   function restoreEntity(aliasEntityName,id)
   {
       $('#'+id).hide();
       $.ajax({                    
                            url:'<?php echo base_url();?>media_intel_extractions/restore_merged_entities/',
                            type:'POST',
                            dataType :'JSON',
                             data:{data:aliasEntityName},
                            success:function(returnData){
                                
                            }
                           // $('#entities').unblock();
                        });
   }
    function mergedEntityList()
    {
         $.ajax({                    
                            url:'<?php echo base_url();?>media_intel_extractions/get_merged_entities/',
                            type:'POST',
                            dataType :'JSON',
                             
                            success:function(returnData){
                              var html;
                               $('#entities').hide(); 
                               html="<div id='mergedList'>";
                               html+="<a onclick=\"getEntities()\">All entities</a>";
                               html+="<hr/>";
                                html+="<table  style='width:400px;margin-left:250px'><th>Alias Entity Name</th><th>Similar Entity Name</th><th>Category</th><th>Action</td>";

                                for(var result in returnData)
                                {   
                                    
                                        html+="<tr style='height:35px' id='"+returnData[result].id+"'><td>"+returnData[result].not_merged_entity_name+"</td><td>"+returnData[result].merged_entity_name+"</td><td>"+returnData[result].cat_name+"</td><td><a style='cursor:pointer' onclick=\"restoreEntity('"+returnData[result].merged_entity_name+"',"+returnData[result].id+")\">Restore</a></td></tr>";

                               // $("#right option").append(html);
                                }  
                                 html+="</table>";
                                 html+="</div>";
                               $("#data").append(html);
                            }
                           // $('#entities').unblock();
                        });
    }
    function getEntities(reload)
    {  $('#entities').show(); 
         $('#mergedList').hide(); 
        var cat=   $( "#cat option:selected" ).val();
         var html;
         var base_url		= "<?php echo base_url()?>";
           $('#data').block({ message: 'Getting entity list...',overlayCSS: { backgroundColor: '#F7F7F7 ',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
       $.ajax({                    
                            url:'<?php echo base_url();?>media_intel_extractions/get_entities/',
                            type:'POST',
                            dataType :'JSON',
                             data: {cat:cat},
                            success:function(returnData){
                              
                                $("#left option").remove();
                                $("#right option").remove();  
                                for(var result in returnData)
                                {   
                                     html="<option value='"+returnData[result].id+"'>"+returnData[result].entity_name+"</option>";
                                     $("#left").append(html);
                                     $("#right").append(html);
                               // $("#right option").append(html);
                                }  
                                
                                 $('#data').unblock();  
                               
                            }
                           // $('#entities').unblock();
                          
                        });
                        
    }
    function mergeEntities()
        {    var mergeData = {};
            var leftForm=$("#leftForm").serialize();
             var rightForm=$("#rightForm").serialize();
var cat=$( "#cat option:selected" ).val();
             mergeData += '&'+leftForm;
                mergeData += '&'+rightForm;
mergeData+='&cat='+cat;
            $('#data').block({ message: 'Merge in progress.. ',overlayCSS: { backgroundColor: '#F7F7F7 ',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
             $.ajax({                    
                            url:'<?php echo base_url();?>media_intel_extractions/merge_selected_entities/',
                            type:'POST',
                            dataType :'JSON',

                             data: mergeData,
                            success:function(returnData){

                                  getEntities(1); 
//                                  
                            }
                           
                        });
             
        }
    </script>
    </head>
    
    <body>
          <div id="data">
              <div id="entities" >
         <a style='cursor:pointer' onclick="mergedEntityList()" style="margin-left:22px">Restore Entities</a>
         <b style="margin-left:78px;">Select Similar entity</b>
          <b style="margin-left:297px;">Select Alias entity</b>
          <select id="cat" style="margin-left:75px" onchange="getEntities()"   >
              <option disabled>Select Category</option>
              
              <option value='Person'>People</option>
              <option value='MedicalCondition'>Disease</option>
              <option value='Company'>Company</option>
              <option value='Product'>Product</option>
              <option value='Organization'>Organization</option>
              <option value='Technology'>Technology</option>
          </select>
      <hr/>
     
      
        <form id="leftForm" method="post" > 
            <select style='margin-left:150px;width:250px;' multiple id="right" size="30" name="rightForm[]">
            
            <?php 
        foreach($person as $values)
        {
      echo "<option value='".$values["id"]."'>".$values["entity_name"]."</option>";
        }
     ?>
        </select>
    <select style="margin-left:150px;width:250px;" name='leftForm[]'  size="30" id="left">
        <?php 
        foreach($person as $values)
        {
      echo "<option value='".$values["id"]."'>".$values["entity_name"]."</option>";
        }
     ?>
    </select>
 
   
        
        
     <input type='button' value='Merge' onclick="mergeEntities()" />
        </form> 
    </div>
      </div>
    </body>
    </html>