<?php


/**
 * This class contains the methods for Contract module activites 
 * 
 * @author Ramesh B
 * @since  1.5	
 * @package application.controllers	
 * @created on  28-02-11
 * 
 */

class contracts extends Controller {
	
	function contracts(){
		parent::Controller();
		$this->load->model('common_helpers');		
		$this->load->model('contract');
		$this->load->model('kol');
		$this->load->model('client_user');
		$this->loggedUser = $this->session->userdata['user_name'];
	}
	
	/**
	 * Load the list_contract page
	 *
	 * @author Vinayak
	 * @created 24-11-2011
	 * @since	3.4
	 *
	 */
	function show_contracts($subContentPage=''){
		$data['contentPage'] 	=	'contracts/list_contracts';
		$data['subContentPage']	=	$subContentPage;
		
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => 'List Contract',
				'status' => STATUS_SUCCESS,
				'transaction_id' => '',
				'transaction_name' => "List Contract",
				'form_data' => ''
		);
		$this->config->set_item('log_details', $arrLogDetails);		
		$this->load->view('layouts/client_view', $data);
		//$this->load->view('contracts/list_contracts',$data);
	}
	
	/**
	 * Prepare the contract data and passed to view for listing
	 *
	 * @author Vinayak
	 * @created 24-11-2011
	 * @since	3.4
	 * @return JSON
	 */
	function list_contracts($kolID='',$contractType){
		$page				= (int)$this->input->post('page'); // get the requested page 
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$arrInteractions	= array();
		$data				= array();
		if(!is_numeric($kolID)){
		    $contractType = 'track';
		}
		$arrContractsResult = $this->contract->listContracts($kolID,$contractType);
// 		echo $this->db->last_query($arrContractsResult);
		$arrContracts=array();
		foreach($arrContractsResult as $row){
		    if($row['kol_id']>0){
		        $row['contract_type'] = 'kol';
		    }else{
		        $row['contract_type'] = 'org';
		    }
			$row['eAllowed'] = $this->common_helpers->isActionAllowed('contract', 'edit', $row);
			$row['dAllowed'] = $this->common_helpers->isActionAllowed('contract', 'delete', $row);
			if($row['end_date']!='0000-00-00'){
			$todays_date = date("Y-m-d"); 
			$today = strtotime($todays_date); 
			$expiration_date = strtotime($row['end_date']); 
			if ($expiration_date >= $today) {
				 $row['is_expired'] ='Not expired';
			 } else  { 
			 	$row['is_expired'] ='Expired'; 
			 }
			 
			 
			} 
			
			
			$row['start_date']=$this->common_helpers->convertDateToMM_DD_YYYY($row['start_date']);
			
			if($row['start_date']=='00/00/0000'){
				$row['start_date']='';
			}
			
			$row['end_date']=$this->common_helpers->convertDateToMM_DD_YYYY($row['end_date']);
			
			if($row['end_date']=='00/00/0000'){
				$row['end_date']=' ';
			}
			
			if($row["contract_file"]!=null){
			    $url='#';
			    if($this->common_helpers->isActionAllowed('contract', 'download', $row)){
                    $url = base_url().'contracts/file_download/'.$row["id"];    
			    }
				$row['contract_file']='<div class="actionIcon downloadIcon tooltip-demo tooltop-left"><a class="tooltipLink" rel="tooltip" title="Download Contract" href="'.$url.'"></a></div>';
			}
			$arrContracts[]=$row;
		}
	
		
			$count=sizeof($arrContracts);				
			if( $count >0 ){ 
				$total_pages = ceil($count/$limit); 
			}else{ 
				$total_pages = 0; 
			} 
			$data['records']=$count;
			$data['total']=$total_pages;
			$data['page']=$page;				
			$data['rows']=$arrContracts;  
		
	
		echo json_encode($data);
	}

	/* 
	 * 
	 * Email Notifictaion for Exppiry
	 * 
	 */
	
	
	
	/**
	 * load view page for adding contract deatils
	 *
	 * @author Vinayak
	 * @created 24-11-2011
	 * @since	3.4
	 * 
	 */
	function add_contract($kolId='',$contractType){
		$data['arrContract']='';
		if(is_numeric($kolId)!=''){
		    if($contractType=='kol'){
    		    $data['kolId'] = $kolId;
    		    $arrKols = $this->contract->getAllKolsName1();
    		    $data['kol_name'] = $arrKols[$kolId];
    		    $data['contract_type'] = $contractType;
    		    $kols_or_org_type = 'Kol';
    		    $kols_or_org_id = $kolId;
		    }else{
		        $data['kolId'] = $kolId;
		        $arrKols = $this->contract->getAllOrgName1();
		        $data['kol_name'] = $arrKols[$kolId];
		        $data['contract_type'] = $contractType;
		        $kols_or_org_type = 'Organization';
		        $kols_or_org_id = $kolId;
		    }
		}else{		
		  $data['contract_type'] = 'track';
		  $kols_or_org_type = '';
		  $kols_or_org_id = 0;
		}
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited ".lang('HCP')." adding contract Page",
				'status' => STATUS_SUCCESS,
    		    'kols_or_org_type' => $kols_or_org_type,
    		    'kols_or_org_id' => $kols_or_org_id,
				'transaction_name' => "View ".lang('HCP')." adding contract"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('contracts/add_contract',$data);
	}
	
	/**
	 * Passed contract details to Model for saving
	 *
	 * @author Vinayak
	 * @created 24-11-2011
	 * @since	3.4
	 * @return JSON
	 */
	function save_contract($id,$contractType){
		$arrContract['contract_name'] 	= $this->input->post('contract_name');
		$arrContract['kol_name'] 		= $this->input->post('kol_name');
		$kolId = $this->input->post('kol_id');
		if(!empty($kolId)){
    		if(!is_numeric($kolId)){
    		    $kolId = $this->common_helpers->getKolIdByUniqueId($kolId);
    		}
    		$arrContract['kol_id'] 		= $kolId;
		}else{
		    $arrContract['kol_id'] = 0;
		}
		$arrContract['org_id'] 		= $this->input->post('org_id');
		if(empty($arrContract['org_id'])){
		    $arrContract['org_id']=0;
		}
		$arrContract['start_date'] 		= $this->input->post('start_date');
		$arrContract['end_date']	 	= $this->input->post('end_date');
		
		$arrContract['contract_description']	= $this->input->post('contract_description');
		$arrContract['start_date'] =app_date_to_sql_date($arrContract['start_date']);
		$arrContract['end_date'] =app_date_to_sql_date($arrContract['end_date']);
		
		if($_FILES["contract_file"]['name']!=''){
			$target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/contract_documents/";
			$path_info = pathinfo($_FILES["contract_file"]['name']);
			$newFileName	= random_string('unique', 20).".".$path_info['extension'];
			$overview_file_target_path = $target_path ."/". $newFileName; 
			move_uploaded_file($_FILES['contract_file']['tmp_name'],$overview_file_target_path);
			$arrContract['contract_file'] = $newFileName;
		}
		$arrContract['doc_name'] = $_FILES["contract_file"]['name'];
		$contract_id	= $this->contract->saveContract($arrContract);
		//$this->update->insertUpdateEntry(KOL_PROFILE_CONTACT_ADD,$arrContract['id'], MODULE_KOL_OVERVIEW, $arrContract['kol_id']);
		//$this->show_contracts();
		if($arrContract['kol_id'] > 0){
		    $transactionName = 'New Contract';
		    $kol_org_type = 'Kol';
		    $kols_or_org_id = $arrContract['kol_id'];
		    $parentObjectId = $arrContract['kol_id'];
		    $urlLink = '<a href="'.base_url().'kols/view/'.$kols_or_org_id.'/show_contracts">click here</a>';
		}else{
		    $transactionName = 'New Org Contract';
		    $kol_org_type = 'Organization';
		    $kols_or_org_id=$arrContract['org_id'];
		    $parentObjectId = $arrContract['org_id'];
		    $urlLink = '<a href="'.base_url().'organizations/view/'.$kols_or_org_id.'/show_contracts">click here</a>';
		}
		$arrLogDetails = array(
		        'type' => ADD_RECORD,
		        'description' => $transactionName,
		        'status' => STATUS_SUCCESS,
    		    'kols_or_org_type' => $kol_org_type,
    		    'kols_or_org_id' => $kols_or_org_id,
				'transaction_id' => $contract_id,
		        'transaction_table_id' => CONTRACTS,
		        'transaction_name' => $transactionName,
				'form_data' => json_encode($this->input->post),
		        'parent_object_id' => $parentObjectId
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null, true);
		
		//New Recorded Email
		$arrReturnResult	= $this->contract->getAssignedUsersForType($kols_or_org_id,$kol_org_type);
		$user_email	= $arrReturnResult['user_details'];
		$type_name	= $arrReturnResult['type_name'];
		$arrConfig = $this->common_helpers->getMailConfig(USER,PASS);
		$arrInfo = array (
		    'FROM' => USER,
		    'FROM_NAME' => SENDER,
		    'TO' => $user_email,
		    'CC' => array(""),
		    'SUBJECT' => "New Contract : $type_name",
		    'MAIL_BODY' => "<html>
									<head>
										<style>
											table {color: #333; font-family: Helvetica, Arial, sans-serif; width: 640px; border-collapse: collapse; border-spacing: 0;}
											td, th { border: 1px solid #CCC; height: 30px; }
											th { background: #F3F3F3; font-weight: bold; }
											td { background: #FAFAFA; text-align: center;}
										</style>
									</head>
									<body>
										<div>
											Hi, <br/><br/> This is a notification about a contract that has been recorded with $type_name.<br><br>
                                            Please $urlLink to view the contract.<br/><br/>
											<br>Regards,<br>Aissel Support Team<br>
										</div>
									</body>
								</html>"
		);
		$mailStatus = $this->common_helpers->sendMailService($arrConfig,$arrInfo);
		
		
		if($this->input->post('withInProfile')){
		    if($contractType=='kol'){
    		    $kolId = $this->common_helpers->getUniqueIdByKolId($arrContract['kol_id']);
    		    redirect('kols/view/'.$kolId.'/show_contracts');
		    }else{
		        redirect('organizations/view/'.$id.'/show_contracts');
		    }
		}
		redirect('contracts/show_contracts');
		//return true;
	}
	
	/**
	 * Get th Contract Id from view and passed Id to model to get Contrac details
	 * @author Vinayak
	 * @created 24-11-2011
	 * @since	3.4
	 * 
	 */
	function edit_contract($contractId,$kolId,$contractType){
	
		$arrContracts = $this->contract->getContractDetailsById($contractId);
		$arrContracts['start_date']=$this->common_helpers->convertDateToMM_DD_YYYY($arrContracts['start_date']);
		if($arrContracts['start_date']=='00/00/0000'){
			$row['start_date']='';
		}
		
		$arrContracts['end_date']=$this->common_helpers->convertDateToMM_DD_YYYY($arrContracts['end_date']);
		if($arrContracts['end_date']=='00/00/0000'){
			$arrContracts['end_date']=' ';
		}
		$data['arrContract'] = $arrContracts;
		if(is_numeric($kolId)){
		  $data['kolId'] = $kolId;
		  if($data['arrContract']['kol_id'] > 0){
		      $kol_org_type = 'Kol';
		      $kols_or_org_id=$data['arrContract']['kol_id'];
		      $data['contract_type'] = 'kol';
		  }else{
		      $kol_org_type = 'Organization';
		      $kols_or_org_id=$data['arrContract']['org_id'];
		      $data['contract_type'] = 'org';
		  }
		}else{
	          $data['contract_type'] = 'track';
		}
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited ".lang('HCP')." add contract Page",
				'status' => STATUS_SUCCESS,
    		    'kols_or_org_type' => $kol_org_type,
    		    'kols_or_org_id' => $kols_or_org_id,
				'transaction_name' => "View ".lang('HCP')." add contract"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('contracts/add_contract',$data);
	}
	
	/**
	 * Update the Contract details
	 * @author Vinayak
	 * @created 24-11-2011
	 * @since	3.4
	 * @return JSON
	 */
	function update_contract($kolOrgId='',$contractType){
		$arrContract['id'] 	= $this->input->post('id');
		$arrContract['contract_name'] 	= $this->input->post('contract_name');
		$arrContract['kol_name'] 		= $this->input->post('kol_name');
		$kolId = $this->input->post('kol_id');
		if(!empty($kolId)){
		    if(!is_numeric($kolId)){
		        $kolId = $this->common_helpers->getKolIdByUniqueId($kolId);
		    }
		    $arrContract['kol_id'] 		= $kolId;
		}else{
		    $arrContract['kol_id'] = 0;
		}
		$arrContract['start_date'] 		= $this->input->post('start_date');
		$arrContract['end_date']	 	= $this->input->post('end_date');
		$arrContract['org_id'] 		= $this->input->post('org_id');
		$arrContract['contract_description']	= $this->input->post('contract_description');
		$arrContract['start_date'] =app_date_to_sql_date($arrContract['start_date']);
		$arrContract['end_date'] =app_date_to_sql_date($arrContract['end_date']);
		if($_FILES["contract_file"]['name']!=''){
			$target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/contract_documents/";
			$path_info = pathinfo($_FILES["contract_file"]['name']);
			$newFileName	= random_string('unique', 20).".".$path_info['extension'];
			$overview_file_target_path = $target_path ."/". $newFileName; 
			move_uploaded_file($_FILES['contract_file']['tmp_name'],$overview_file_target_path);
			$arrContract['contract_file'] = $newFileName;
			$arrContract['doc_name'] = $_FILES["contract_file"]['name'];
		}		
		$this->contract->updateContract($arrContract);
		
		if($arrContract['kol_id'] > 0){
		    $transactionName = 'Update Contract';
		    $kol_org_type = 'Kol';
		    $kols_or_org_id = $arrContract['kol_id'];
		    $parentObjectId = $arrContract['kol_id'];
		}else{
		    $transactionName = 'Update Org Contract';
		    $kol_org_type = 'Organization';
		    $kols_or_org_id=$arrContract['org_id'];
		    $parentObjectId = $arrContract['org_id'];
		}
		//$this->update->insertUpdateEntry(KOL_PROFILE_CONTACT_UPDATE,$arrContract['id'], MODULE_KOL_OVERVIEW, $arrContract['kol_id']);
		//$this->show_contracts();
		$arrLogDetails = array(
		        'type' => EDIT_RECORD,
		        'description' => $transactionName,
		        'status' => STATUS_SUCCESS,
    		    'kols_or_org_type' => $kol_org_type,
    		    'kols_or_org_id' => $kols_or_org_id,
				'transaction_id' => $arrContract['id'],
				'transaction_table_id' => CONTRACTS,
		        'transaction_name' => $transactionName,
				'form_data' => json_encode($arrContract),
		        'parent_object_id' => $parentObjectId
		);
		
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null, true);
		if(is_numeric($kolOrgId)>0){
    		if($this->input->post('withInProfile')){
    		    
    		    if($contractType=='kol'){
    		        $kolId = $this->common_helpers->getUniqueIdByKolId($arrContract['kol_id']);
    		        redirect('kols/view/'.$kolId.'/show_contracts');
    		    }else{
    		        redirect('organizations/view/'.$arrContract['org_id'].'/show_contracts');
    		    }
    		}
		}
		redirect('contracts/show_contracts');
	}
	
	/**
	 * to get the Contract Id form view and Passed to model for deleting
	 * @author Vinayak
	 * @created 24-11-2011
	 * @since	3.4
	 * @return JSON
	 */
	function delete_contract($contractId){
		if($this->contract->deteleteContract($contractId)){
			$arr['mes']=true;
		}else{
			$arr['mes']=false;
		}
		echo json_encode($arr);
	}
	
	function delete_file($fileName,$contractId){
		$arrContract['contract_file'] 	= '';
		$arrContract['id']	 	=$contractId;
		if($this->contract->updateContract($arrContract)){
			
			unlink($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/contract_documents/".$fileName);
			//$this->update->insertUpdateEntry(KOL_PROFILE_CONTACT_DELETE,$arrContract['id'], MODULE_KOL_OVERVIEW, $arrContract['kol_id']);
			$data['saved']=true;
		}else{
			$data['saved']=false;
		}
		echo json_encode($data);	

	}
	
	function file_download($contractId){
		$arrContracts = $this->contract->getContractDetailsById($contractId);
		$this->load->helper('download');		
		$data =  file_get_contents($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/contract_documents/".$arrContracts['contract_file']);
		$name = $arrContracts['doc_name'];
		force_download($name, $data);
	}
	
	function email_contracts(){
	    $NewDate = Date('Y-m-d', strtotime("+6 days"));
	    $arrContractsResultForEmail = $this->contract->listContractsEmail($NewDate);
	    //pr($arrContractsResultForEmail);
	    //$managerId = $this->session->userdata("user_id");
	    $new_formate_date = strftime("%d-%B-%Y", strtotime($NewDate));
	    foreach($arrContractsResultForEmail as $row){
	        $email = $row['email'];
	        $name = $row['kol_name'];
	        $id = $row['id'];
	        $contract_id = $row['cont_id'];
	        $createdBy = $row['created_by'];
	        $managerEmail = $this->contract->getManagerEmail($createdBy);
	       // pr($managerEmail);exit;
	    foreach($managerEmail as $manager){
		    	$ccManager = $manager['email'];
		    	$user = $manager['id'];
		        $firstName = $row['first_name'];
		        $config['protocol'] = PROTOCOL;
		        $config['smtp_host'] = HOST;
		        $config['smtp_port'] = PORT;
		        $config['smtp_user'] = USER;
		        $config['smtp_pass'] = PASS;
		        $config['mailtype'] = 'html';
		        $this->load->library('email', $config);
		        $this->email->set_newline("\r\n");
		        $this->email->initialize($config);
		        $this->email->clear();
		        $this->email->set_newline("\r\n");
		        $this->email->from(USER);
		        if($user == $createdBy){
		        	$this->email->to($ccManager);
		        	$emailDescription = "To- ".$ccManager;
		        }else{
		        	$this->email->to($email);
		        	$this->email->cc($ccManager);
		        	$emailDescription = "To- ".$email."CC- ".$ccManager;
		        }
		        $this->email->subject($name.': Contract expires on '.$new_formate_date);
		        $this->email->message('Hi&nbsp;'.$firstName.',<br /><br /> This email is regarding your contract with '.$name.'<br /><br />
				This contract will expire on&nbsp;'.$new_formate_date.'<br /><br />
				Please <a href="' .base_url(). 'contracts/show_contracts">click here</a> to view the contract list<br /><br />
				Note: Please write to <a href="mailto:support@aissel.com" target="_top">support@aissel.com</a> if you have any questions.	<br /><br />
	
				Regards,<br />
				Aissel Support Team		
				');
		        if ($this->email->send()){
		            //Record log Activity
		            $arrLogDetails = array(
		                'type' => CRON_JOBS,
		                'description' => 'Contract Email Sent',
		                'status' => STATUS_SUCCESS,
		                'transaction_id' => $contract_id,
		                'transaction_table_id' => CONTRACTS,
		                'transaction_name' => "Contract Email Sent",
		                'parent_object_id' => $contract_id,
		                'miscellaneous2' => $emailDescription
		            );
		            $this->config->set_item('log_details', $arrLogDetails);
		            //     		    log_user_activity(null, true);
		        } else {
		            //Record log Activity
		            $arrLogDetails = array(
		                'type' => CRON_JOBS,
		                'description' => 'Contract Email Sent',
		                'status' => STATUS_FAIL,
		                'transaction_id' => $contract_id,
		                'transaction_table_id' => CONTRACTS,
		                'transaction_name' => "Contract Email Sent",
		                'parent_object_id' => $contract_id,
		                'miscellaneous2' => $emailDescription
		            );
		            $this->config->set_item('log_details', $arrLogDetails);
		            //     		    log_user_activity(null, true);
		        }
		        $this->email->clear(TRUE);
	    	}
	    }
	}
	
	function get_all_kol_org_names_for_autocomplete($restrictByRegion=0,$restrictOptInVisbility=0,$kolName) {
	    $kolName = utf8_urldecode($this->input->post('keyword'));
	    $arrKolNames1 = array();
	    //     	echo $kolName;exit;
	    $arrKolNames = $this->interaction->getAllKolNamesForAutocomplete($kolName,$restrictByRegion,$restrictOptInVisbility);
	    $arrOrgNames = $this->kol->getOrganizationNamesWithStateCity($kolName,$restrictByRegion);
	    $flag = 1;
	    foreach ($arrKolNames['customers'] as $key => $row) {
	        if ($flag) {
	            $arrKolNames1[] = "<div class='autocompleteHeading'>KTL's</div><div class='dataSet'><label name='" . $row[4] . "' type='kol' class='organizations' style='display:block'>$row[0]</label><p class='orgName'>$row[1]</p><span style='display:none' class='id1'>$key</span></div>";
	            $flag = 0;
	        } else {
	            $arrKolNames1[] = "<div class='dataSet'><label name='" . $row[4] . "' type='kol' class='organizations' style='display:block'>$row[0]</label><p class='orgName'>$row[1]</p><label style='color: red;display:block'>" . $row['do_not_call_flag'] . "</label><span style='display:none' class='id1'>$key</span></div>";
	        }
	    }
	    $flag = 1;
	    foreach ($arrOrgNames as $row) {
	        $cityState=$row['city'];
	        if(isset($row['city']) && isset($row['state']))
	            $cityState.= ', ';
	            $cityState.=$row['state'];
	            if ($flag) {
	                $arrKolNames1[] = '<div class="autocompleteHeading">Organizations</div><div class="dataSet"><label name="' . $row['id'] . '" type="org" class="organizations" style="display:block">' . $row['name'] . "</label><label>$cityState</label><span style='display:none' class='id1'>".$row['id']."</span></div>";
	                $flag = 0;
	            } else {
	                $arrKolNames1[] = '<div class="dataSet"><label name="' . $row['id'] . '" class="organizations" style="display:block">' . $row['name'] . "</label><label>$cityState</label><span style='display:none' class='id1'>". $row['id']."</span></div>";
	            }
	    }
	    $arr['query'] = $kolName;
	    $arr['suggestions'] = $arrKolNames1;
	    echo json_encode($arr);
	}
	
		
}