<?php
if($arrKol['salutation'] != 0)
	$salutation	= $arrSalutations[$arrKol['salutation']];
else
	$salutation = "";
$firstName	= $arrKol['first_name'];
$middleName	= htmlspecialchars( $arrKol['middle_name']);
$lastName	=  htmlspecialchars( $arrKol['last_name'],ENT_QUOTES,'UTF-8');
$fullName = $this->common_helper->get_name_format($firstName,$middleName,$lastName);
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<style type="text/css">
			html, body, div, span, object, iframe, h1, h2, h3, h4, h5, h6, p, blockquote, pre, a, abbr, acronym, address, code, del, dfn, em, img, q, dl, dt, dd, ol, ul, li, fieldset, form, label, legend, table, caption, tbody, tfoot, thead, tr, th, td, article, aside, dialog, figure, footer, header, hgroup, nav, section {
				border:0 none;
				font-family:inherit;
				font-size:100%;
				font-style:inherit;
				font-weight:inherit;
				margin:0;
				padding:0;
				vertical-align:baseline;
			}
			body, html{
				font-family:"Times New Roman", serif, sanserif, helvetica;
				margin:48px 28px;
			}
			table.overviewDetails{
				width:100%;
				border:0px solid red;
				border-collapse:collapse;
			}
			table.overviewDetails td{
				vertical-align:top;
				border: 0px solid red;
			}
			.profileDetails{
				color:#444;
				font-size: 0.85em;
			}
			.profileDetails {
				color: gray;
				font-family: tahoma;
				font-size: 12px;
				font-weight: bold;
				margin-top: 10px;
				text-transform: uppercase;
			}
			.kolName{
				font-weight:bold;
				font-size:1.2em;
			}
			.mainHeading {
				background-color: #CCCCCC;
				font-family: Tahoma;
				font-size: 12px;
				font-weight:bold;
				padding: 4px;
				text-transform: uppercase;
				letter-spacing: 1px;
			}
			.mainHeading2 {
				background-color: #CCCCCC;
				font-family: Tahoma;
				font-size: 12px;
				font-weight:bold;
				padding: 4px;
				letter-spacing: 1px;
			}
			.bio,.clinical{
				font-family: Tahoma;
				font-size: 14px;
				font-weight: bold;
			}
			.header{
				border-bottom:1px solid black;
				font-size:11pt;
				font-stretch:ultra-expanded;
				font-weight:bold;
				margin-bottom:5px;
				padding-bottom:2px;
				text-align:left;
				width:100%;
			}
			table.records{
				width:100%;
				border:0px solid blue;
				page-break-after:auto;
			}
			table.records tbody{
			}
			table.records tbody td{
				border:0px solid yellow;
				padding:5px 2px;
				width:25%;
				font-size:11pt;
			}
			#logo{
				text-align:right;
				margin-top:-30px;
			}
			.education{
				background-color:#ccc;
				text-transform: uppercase;
			}
			p{
				font-size:11pt;
			}
			b{
			font-size:11pt;
			}
			.clinical,.bio{
			
			}
			.adressDetails{
				color: gray;
				font-size: 10pt;
				font-weight: bold;
			}
			.bgColorBlack{
				color:black;
			}
			.bgColorGray{
				color:gray;
			}
			#sub{
				font-weight:normal;
				font-size:8px;
			}
			table.records1 tbody td{
				border:0px solid yellow;
				font-size:11pt;
				padding:5px 2px;
				width:25%;
			}
			.flyleaf {
				page-break-after: always;
			}
			.header1, .footer {
				position: fixed;
			}
			.header1 {
				top: -18px;
			}
			.footer {
				bottom: 0;
			}
			.autoBio li span{
				font-size:11pt !important;
			}
			.autoBio p{
			    margin-left: -18px;
			    margin-top: 10px;
			    font-size:11pt;
			}
	</style>
</head>
<body>
<script type="text/php">
		if(isset($pdf)) {
  $font = Font_Metrics::get_font("verdana");
  // If verdana isn't available, we'll use sans-serif.
  if (!isset($font)) { Font_Metrics::get_font("sans-serif"); }
  $size = 9;
  $color = array(0.5,0.5,0.5);
  $text_height = Font_Metrics::get_font_height($font, $size);

  $foot = $pdf->open_object();
  
  $w = $pdf->get_width();
  $h = $pdf->get_height();

  // Draw a line along the bottom
  $y = $h - 2 * $text_height - 24;
  $pdf->line(16, $y, $w - 16, $y, $color, 0.5);

  $y += $text_height;
  $pdf->close_object();
  $pdf->add_object($foot, "all");
  global $initials;
  $initials = $pdf->open_object();
  $pdf->close_object();
  $pdf->add_object($initials);
  $text = "Page {PAGE_NUM} of {PAGE_COUNT}";  
  // Center the text
  $width = Font_Metrics::get_text_width("Page 1 of 2", $font, $size);
  $pdf->page_text($w/1.035  - $width/1.035 , $y, $text, $font, $size, $color);
}
</script>
<div class="header1" style="width:91%;margin-left:18px;margin-bottom:10px;">
	<table width="100%">
		<tr>
			<td class="bgColorGray kolNameForConsent" style="font-size:9pt">
				<?php echo $salutation . ' ' . $fullName ;?>
			</td>
			<td align="right" style="vertical-align:top ">
				<?php 
				$fullImagePath= $_SERVER ['DOCUMENT_ROOT']."/".'images/kolm_logo_beta.png'; 
				$rootFolder	=$_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path');
				$logoPath	= $rootFolder."images/logo/kolm_logo_beta.png";
				?>
				<img style="margin-right: 25px;" src="<?php echo $logoPath;?>">
			</td>
		</tr>
	</table>					
</div>
<div class="footer"></div>

<!-- Start of overviewDetails Table -->
<table class="overviewDetails" cellspacing="5" cellpadding="5">
	<tr>
		<td style="font-size:11px;color:gray;">Profile Type :
			<?php 
			if($arrKol['profile_type']=='Full Profile'){
				$profilType = 'Full';
			}elseif($arrKol['profile_type']=='Basic Plus'){
				$profilType = 'Basic +';
			}elseif($arrKol['profile_type']=='Basic'){
				$profilType = 'Basic';
			}elseif($arrKol['profile_type']=='User Added'){
			    $profilType = 'User Added';
			}elseif ($arrKol['profile_type']=='Legacy'){
			    $profilType = 'Legacy';
			}
			echo $profilType;
			?>
		</td>
	</tr>
	<tr>
		<td width="20%">
			<?php if($arrKol['profile_image']!=''){
				$fullImagePath =  $_SERVER['DOCUMENT_ROOT'].'/'.$this->config->item('app_folder_path').'images/kol_images/resized/'.$arrKol['profile_image'];
				?>
			<img src="<?php echo $fullImagePath;?>" >
			<?php }?>
		</td>
		<td width="100%">
			<p class="kolName"><?php echo $salutation . ' ' . $fullName ?> <sub id="sub" style="vertical-align:bottom"><?php echo $arrKol['suffix'];?></sub></p>
			<p class="adressDetails"><?php echo $arrKol['title'];?> </p>
			<p class="adressDetails"><?php echo $arrKol['division'];?> </p>
			<p class="adressDetails"><?php echo $arrKol['org_name'];?> </p>
			<p class="adressDetails"><?php if($arrKol['country_id']!='0') echo $arrKol['country_id']; else echo '';?></p>
		</td>
		<td align="right"></td>
	</tr>
	<tr>
		<td rowspan="2">
			<h4 class="profileDetails">SPECIALTY</h4>
			<p class='bgColorGray'><?php echo $arrKol['specialtyName'];?></p>
			<h4 class="profileDetails">SUB-SPECIALTY</h4>
			<p class='bgColorGray'>
				<?php if($arrKol['sub_specialty']!='') echo implode(", ",$arrKol['sub_specialty']);
				else echo '&nbsp;';?>
			</p>
			<h4 class="profileDetails">ADDRESS</h4>								
			<?php if(!empty($arrKol['address1']) && isset($arrKol['address1'])) 
						echo "<p class='bgColorGray'>".$arrKol['address1'].",</p>";
				  if(!empty($arrKol['address2']) && isset($arrKol['address2']))
						echo "<p class='bgColorGray'>".$arrKol['address2'].",</p>";
			?>
			<p class='bgColorGray'>
			<?php if(!empty($arrKol['city_id']))
					echo $arrKol['city_id'].', ';
				  if($arrKol['state_id']!='' && $arrKol['postal_code']!='')
					echo $arrKol['state_id']. " ". $arrKol['postal_code'];
				  else
					echo $arrKol['state_id'];
			?>
			</p>
			<?php if(!empty($arrKol['country_id']))
					echo "<p class='bgColorGray'>".$arrKol['country_id']."</p>";
			?>								
			<h4 class="profileDetails">PHONE</h4>
			<p class="bgColorGray"><?php echo $arrKol['primary_phone'];?></p>
		
			<h4 class="profileDetails">FAX</h4>
			<p class="bgColorGray"><?php echo $arrKol['fax'];?></p>
			
			<h4 class="profileDetails">Email</h4>
			<p class="bgColorGray">
			<?php if(isset($arrKol['primary_email']))
					echo $arrKol['primary_email'];
				  else
					echo '&nbsp;';
			?>
			</p>
		</td>
		<td colspan="2">
			<h1 class="bio" style="text-align: justify">PROFILE SUMMARY</h1>
			<ul class="autoBio bgColorGray" style="text-align: justify;margin-left: 15px;font-size: 10pt;"><?php echo $arrKol['biography'];?></ul>
		</td>
	</tr>
	<?php if(HIDE_CLINICAL_RESERCH_INTERESTS) {?>
    <br/>
		<tr>
			<td colspan="2">
				<h1 class="clinical">CLINICAL RESEARCH INTERESTS</h1>
				<p class="bgColorGray"><?php echo $arrKol['research_interests'];?></p>
			</td>
		</tr>
	<?php }?>
</table>
<!-- End of overview Details Table -->
		
<!-- Start of Educations  Details Table -->
<h1 class="mainHeading" style="background-color: #CCCCCC;">EDUCATION & TRAINING</h1>	
<p>&nbsp;</p>
<?php 
	$education='';	
	foreach($arrEducation as $result):
		if($result['type']=='education'):
			$education='';	
			$education=$result['type'];
		endif;
	endforeach;
?>
<?php if($education=='education'){?>
	<h4 class="header">Education</h4>
<?php }?>
<table class="records">
	<tbody>
		<?php foreach($arrEducation as $result):
				if($result['type']=='education'):?>
				<tr>
					<td colspan="3" style="color:black"> <?php echo $result['institute_id']; ?></td>
				</tr>
				<tr>	
					<td class="bgColorGray"> <?php echo $result['specialty']; ?></td>
					<td class="bgColorGray" align="center"> <?php echo $result['degree']; ?></td>
					<td class="bgColorGray" align="right"> <?php echo $result['date']; ?></td>
				</tr>
				<tr>
					<td colspan="3"></td>
				</tr>
		<?php endif; 
 		endforeach;?>
	</tbody>
</table>
<!-- End of Educations  Details Table -->

<!-- Start of Training  Details Table -->
<p>&nbsp;</p>
<?php 
$training='';	
foreach($arrEducation as $result):
	if($result['type']=='training'):
		$training='';	
		$training=$result['type'];
	endif;
endforeach;
?>
<?php if($training=='training'){?>
		 <h4 class="header">Training</h4>
<?php }?>

<table class="records">
	<tbody>
	<?php foreach($arrEducation as $result):
			if($result['type']=='training'):?>
			<tr>
				<td colspan="3" style="color:black"> <?php echo $result['institute_id']; ?></td>
			</tr>
			<tr>	
				<td class="bgColorGray"> <?php echo $result['specialty']; ?></td>
				<td class="bgColorGray" align="center"> <?php echo $result['degree']; ?></td>
				<td class="bgColorGray" align="right"> <?php echo $result['date']; ?></td>
			</tr>
			<tr>
				<td colspan="3"> </td>
			</tr>										
	<?php  endif;
	endforeach;?>
	</tbody>
</table>
<!-- End of Training  Details Table -->

<!-- Start of Board Certification  Details Table -->
<p>&nbsp;</p>
<?php 
$board='';	
foreach($arrEducation as $result):
	if($result['type']=='board_certification'):
		$board='';	
		$board=$result['type'];
	
	endif;
endforeach;
?>
<?php if($board=='board_certification'){?>
	<h4 class="header">Board Certification</h4>
<?php }?>
<table class="records">				
	<tbody>
	<?php foreach($arrEducation as $result):
			if($result['type']=='board_certification'):?>
			<tr>
				<td colspan="3" style="color:black"> <?php echo $result['institute_id']; ?></td>
			</tr>
			<tr>	
				<td class="bgColorGray"> <?php echo $result['specialty']; ?></td>
				<td class="bgColorGray" align="center"> <?php echo $result['degree']; ?></td>
				<td class="bgColorGray" align="right"> <?php echo $result['date']; ?></td>
			</tr>
			<tr>
				<td colspan="3"></td>
			</tr>
		<?php endif;
		 endforeach;?>
	</tbody>
</table>
<!-- End of Board Certification  Details Table -->

<!-- Start of Honors  Awards  Details Table -->
<p>&nbsp;</p>
<?php 
$honors='';	
foreach($arrEducation as $result):
	if($result['type']=='honors_awards'):
		$honors='';	
		$honors=$result['type'];
	endif;
endforeach;
?>
<?php if($honors=='honors_awards'){?>
	<h4 class="header">Honors and Awards</h4>
<?php }?>
<table class="records">
	<tbody>
	<?php foreach($arrEducation as $result):
			if($result['type']=='honors_awards'):?>
			<tr>
				<td>&nbsp;<?php echo $result['honor_name']; ?></td>
				<td align="right" class="bgColorGray">&nbsp;<?php echo $result['date']; ?></td>
			</tr>
	<?php  endif;
 		endforeach;?>
	</tbody>
</table>
<p>&nbsp;</p>
<!-- End of Honors  Awards  Details Table -->
<!-- END OF Education & Traning -->
		
<!-- START OF PROFESSIONAL AFFILIATIONS -->
<h1 class="mainHeading">PROFESSIONAL AFFILIATIONS</h1>
<p>&nbsp;</p>
<!-- Start OF University / Hospitals Table-->
<?php 
$university='';
foreach($arrMembership as $result):
	if($result['type']=='university'):
		$university=$result['type'];
	endif;
endforeach;?>
<?php  if($university=='university'){?>
	<h4 class="header">University / Hospitals</h4>
<?php }?>
<table class="records" >
	<tbody>
	<?php foreach($arrMembership as $result):
			if($result['type']=='university'):?>
			<tr>
				<td class="bgColorBlack" width="65px"> <?php echo $result['engagement_type']; ?></td>
				<td class="bgColorBlack" width="500px"> <?php echo $result['institute_id'];if($result['department']!='')echo ", ".$result['department']; ?></td>
				<td width="65px">&nbsp;</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td align="left" class="bgColorGray"> <?php echo $result['role']; ?></td>
				<td align="right" class="bgColorGray"> <?php echo $result['date']; ?></td>
			<tr>
				<td colspan="3"> </td>
			</tr>
	<?php endif;
		 endforeach;?>
	</tbody>
</table>
<!-- ENd OF University / Hospitals Table-->

<!-- Start OF Associations / Societies Table-->
<p>&nbsp;</p>
<?php 
$association='';
foreach($arrMembership as $result):
	if($result['type']=='association'):
		$association=$result['type'];
	endif;
endforeach;?>
<?php if($association=='association'){?>
	<h4 class="header">Associations / Societies</h4>
<?php }?>
<table class="records">
	<tbody>
	<?php foreach($arrMembership as $result):
			if($result['type']=='association'):?>	
			<tr>
				<td class="bgColorBlack" width="65px"> <?php echo $result['engagement_type']; ?></td>
				<td class="bgColorBlack" width="500px"> <?php echo $result['institute_id'];if($result['department']!='')echo ", ".$result['department']; ?></td>
				<td width="65px">&nbsp;</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td align="left" class="bgColorGray"> <?php echo $result['role']; ?></td>
				<td align="right" class="bgColorGray"> <?php echo $result['date']; ?></td>
			<tr>
				<td colspan="3"> </td>
			</tr>
	<?php endif;
		endforeach;?>
	</tbody>						
</table>
<p>&nbsp;</p>
<!-- Start OF Industry Table-->	
<?php 
$reullt1='';
foreach($arrMembership as $result):
	if($result['type']=='industry'):
		$reullt1=$result['type'];
	endif;
endforeach;?>
<?php if($reullt1=='industry'){?>
<h4 class="header">Industry</h4>
<?php }?>
<table class="records">
	<tbody>
	<?php foreach($arrMembership as $result):				
			if($result['type']=='industry'):?>
			<tr>
				<td class="bgColorBlack" width="65px"> <?php echo $result['engagement_type']; ?></td>
				<td class="bgColorBlack" width="500px"> <?php echo $result['institute_id'];if($result['department']!='')echo ", ".$result['department']; ?></td>
				<td width="65px">&nbsp;</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td align="left" class="bgColorGray"> <?php echo $result['role']; ?></td>
				<td align="right" class="bgColorGray"> <?php echo $result['date']; ?></td>
			<tr>
				<td colspan="3"></td>
			</tr>
	<?php endif;
		 endforeach;?>
	</tbody>
</table>
<p>&nbsp;</p>
<!-- ENd OF Industry Table-->

<!-- Start OF Government Table-->		
<?php 
$government='';	
foreach($arrMembership as $result):
	if($result['type']=='government'):
		$government='';	
		$government=$result['type'];
	endif;
endforeach;
?>
<?php if($government=='government'){?>
	<h4 class="header">Government</h4>
<?php }?>
<table class="records">
	<tbody>
	<?php foreach($arrMembership as $result):
		if($result['type']=='government'):?>
		<tr>
			<td class="bgColorBlack" width="65px"> <?php echo $result['engagement_type']; ?></td>
			<td class="bgColorBlack" width="500px"> <?php echo $result['institute_id'];if($result['department']!='')echo ", ".$result['department']; ?></td>
			<td width="65px">&nbsp;</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td align="left" class="bgColorGray"> <?php echo $result['role']; ?></td>
			<td align="right" class="bgColorGray"> <?php echo $result['date']; ?></td>
		<tr>
			<td colspan="3"> </td>
		</tr>							
	<?php endif;
	endforeach;?>
	</tbody>
</table>
<!-- ENd OF Government Table-->
<p>&nbsp;</p>
<!-- Start OF Others Table-->
<?php 
$others='';	
foreach($arrMembership as $result):
	if($result['type']=='others'):
		$others='';	
		$others=$result['type'];
	endif;
endforeach;
?>
<?php if($others=='others'){?>
	<h4 class="header">Others</h4>
<?php }?>
<table class="records">
	<tbody>
		<?php foreach($arrMembership as $result):
				if($result['type']=='others'):?>
				<tr>
					<td class="bgColorBlack" width="65px"> <?php echo $result['engagement_type']; ?></td>
					<td class="bgColorBlack" width="500px"> <?php echo $result['institute_id'];if($result['department']!='')echo ", ".$result['department']; ?></td>
					<td width="65px">&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td align="left" class="bgColorGray"> <?php echo $result['role']; ?></td>
					<td align="right" class="bgColorGray"> <?php echo $result['date']; ?></td>
				<tr>
					<td colspan="3"></td>
				</tr>
		<?php endif;
		endforeach;?>
	</tbody>
</table>
<!-- ENd OF Others Table-->
<p>&nbsp;</p>


<!-- START OF Events -->
<?php if($this->common_helper->check_module("events")){?>
	<h1 class="mainHeading2">EVENTS (Recent 20 only)</h1>
	<p>&nbsp;</p>
	<!-- Start OF Congresses / Conferences Table-->
	<?php  if(!(empty($arrEvent))){?>
		<h4 class="header">Congresses / Conferences</h4>
	<?php }?>
	<table class="records" >
		<tbody>
		<?php foreach($arrEvent as $result):				
				if($result['type']=='conference'):?>
				<tr>
					<td class="bgColorBlack" width="80px"><?php echo $result['session_type']; ?></td>
					<td colspan="3" width="550px"><?php echo $result['name']?></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td colspan="3" class="bgColorGray"><?php echo $result['session_name']?></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td class="bgColorGray"><?php echo $result['role']?></td>
					<td align="center" class="bgColorGray"><?php echo $result['Country']?></td>
					<td class="bgColorGray" align="right"><?php echo $result['date']?></td>
				</tr>
				<tr>
					<td colspan="4">&nbsp;</td>
				</tr>
			<?php endif;
				endforeach;?>
		</tbody>
	</table>
	<!-- End OF Congresses / Conferences Table-->
<?php }?>
<!-- END OF Events -->	
	
<p>&nbsp;</p>

<!-- START OF publications -->
<?php if($this->common_helper->check_module("pubmeds")){?>		
	<h1 class="mainHeading2">PUBLICATIONS (Recent 20 only)</h1>
	<p>&nbsp;</p>
	<?php if(isset($arrPublications)):
			foreach($arrPublications as $result):?>
					<p><?php echo $result['article_title'];?></p><br />
					<p class="bgColorGray"><?php echo $result['authors'];?></p> <br />
					<p class="bgColorGray">
						<?php echo $result['journal_name'];
			              if($result['date']!='')echo '; '.$result['date'];
					      if($result['volume']!='')echo '; '.$result['volume'].'('.$result['issn_number'].')';?>
					</p><br /><br />
	<?php endforeach;
		endif;?>
	<p>&nbsp;</p>
	<p>&nbsp;</p>
	<h1 class="mainHeading">KEYWORDS IN PUBLICATIONS</h1>
	<p>&nbsp;</p>
	<p class="bgColorGray" style="text-align: justify;"><?php echo $arrMajorTerms?></p>	
	<p>&nbsp;</p>
<?php }?>
<!-- END OF Publications -->

<!-- START OF Clinical trials -->
<?php if($this->common_helper->check_module("clinical_trials")){?>
	<?php if(HIDE_CLINICAL_TRIALS){?>
		<h1 class="mainHeading">CLINICAL TRIALS</h1>
		<p>&nbsp;</p>
		<?php if(isset($arrClinicalTrials)):
				foreach($arrClinicalTrials as $result):?>	
					<p><b><?php echo $result['trial_name'];?></b><?php if($result['date']!=' ') echo ', '.$result['date'];?></p><br />
					<p class="bgColorGray" ><b>Official Title: </b><?php echo $result['official_title'];?></p><br />
					<p class="bgColorGray"><b>Condition: </b><?php echo $result['condition'];?></p><br />
					<p class="bgColorGray"><b>Intervention: </b><?php echo $result['interventions'];?></p><br />
					<p class="bgColorGray"><b>Phase: </b><?php echo $result['phase'];?></p><br />
					<p class="bgColorGray"><b>Role: </b><?php echo $result['kol_role'];?></p><br />
					<p class="bgColorGray" ><b>Sponsor: </b><?php echo $result['sponsors'];?></p><br /><br /> 
		<?php endforeach;
				endif;?>	
	<?php }?>
<?php }?>
<!-- END OF  Clinical trials -->


<!-- START OF Details -->
<h1 class="mainHeading2">DETAILS</h1>
<p>&nbsp;</p>
<?php  if(!(empty($locationData))){?>
	<h4 class="header">Location</h4>
<?php } if(sizeof($locationData) > 0){?>
<table class="records" >
	<tbody>
		<?php foreach($locationData as $result):
			$type = '';
			if($result['is_primary']=='Yes'){
				$type = ' (Primary)';
			}?>
			<tr>
				<td colspan="4"><?php echo $result['org_name'].$type;?></td>
			</tr>
			<tr>
				<td colspan="4" class="bgColorGray"><?php echo $result['address1'].', '.$result['address2'].', '.$result['City'].', '.$result['Region'].', '.$result['Country'].', '.$result['postal_code'];?></td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
		<?php endforeach;?>
	</tbody>
</table>
<?php } ?>
<!-- END OF Details-->
		
<!-- Phone -->
<?php  if(!(empty($phoneData))){?>
	<h4 class="header">Phone</h4>
<?php }if(sizeof($phoneData) > 0){?>
	<table class="records" >
		<tbody>
			<?php   
				foreach($phoneData as $result):
				$type = '';
				if($result['is_primary']=='Yes'){
					$type = ' (Primary)';
				}?>
				<tr>
					<td colspan="4"><?php echo $result['org_name'].$type?></td>
				</tr>
				<tr>
					<td colspan="4" class="bgColorGray"><?php echo $result['name'].' : '.$result['number'];?></td>
				</tr>
				<tr>
					<td colspan="4">&nbsp;</td>
				</tr>
			<?php endforeach;?>
		</tbody>
	</table>
<?php } ?>
		
<!-- Email -->
<?php  if(!(empty($emailData))){?>
	<h4 class="header">Email</h4>
<?php } if(sizeof($emailData) > 0){?>
	<table class="records" >
		<tbody>
			<?php foreach($emailData as $result):?>
				<tr>
					<td colspan="4"><?php echo $result['type'].' : '.$result['email'];?></td>
				</tr>
				<tr>
					<td colspan="4">&nbsp;</td>
				</tr>
			<?php endforeach;?>
		</tbody>
	</table>
<?php } ?>

<!-- License -->
<?php if(KOLS_STATE_LICENSE) {?>
	<?php  if(!(empty($licenseData))){?>
		<h4 class="header">License</h4>
	<?php } if(sizeof($licenseData) > 0){?>
		<table class="records" >
			<tbody>
				<?php   
					foreach($licenseData as $result):
					$type = '';
					if($result['is_primary']=='Yes'){
						$type = ' (Primary)';
					}
				?>
				<tr>
					<td colspan="1" class="bgColorBlack"><?php echo $result['state_license']; ?></td>
					<td colspan="3" class="bgColorGray"><?php echo $result['Region'].', '.$result['Country'].$type;?></td>
				</tr>
				<tr>
					<td colspan="4">&nbsp;</td>
				</tr>
				<?php endforeach;?>
			</tbody>
		</table>
	<?php } ?>
<?php }?>

<!-- Specialty -->
<?php  if(!(empty($specialtyData))){?>
	<h4 class="header">Specialty</h4>
<?php } if(sizeof($specialtyData) > 0){?>
	<table class="records" >
		<tbody>
			<?php   
				$arrSubSpecialty = '';
				foreach($specialtyData as $result):
				if($result['priority'] == 'Sub-Specialty'){
					$arrSubSpecialty.= $result['specialty'].', ';
				}else{?>
					<tr>
						<td colspan="4"><?php echo $result['priority'].' : '.$result['specialty'];?></td>
					</tr>
					<tr>
						<td colspan="4">&nbsp;</td>
					</tr>
			<?php }
				endforeach;
				if(!empty($arrSubSpecialty)){?>
				 	<tr>
						<td colspan="4"><?php echo 'Sub-Specialty : '.rtrim($arrSubSpecialty,", ");;?></td>
					</tr>
					<tr>
						<td colspan="4">&nbsp;</td>
					</tr>
				<?php } ?>
		</tbody>
	</table>
<?php } ?>
		
				
<!-- Staff -->
<?php  if(!(empty($staffData))){?>
	<h4 class="header">Staff</h4>
<?php } if(sizeof($staffData) > 0){?>
	<table class="records" >
		<tbody>
			<?php foreach($staffData as $result):?>
				<tr>
					<td colspan="4"><?php echo $result['org_name']?></td>
				</tr>
				<tr>
					<td colspan="4" class="bgColorGray"><?php echo $result['staff_title'].', '.$result['phone_type'].' : '.$result['phone_number'].', '.$result['email'].', '.$result['address1'].', '.$result['address2'].', '.$result['City'].', '.$result['Region'].', '.$result['Country'].', '.$result['postal_code'];?></td>
				</tr>
				<tr>
					<td colspan="4">&nbsp;</td>
				</tr>
			<?php endforeach;?>
		</tbody>
	</table>
<?php } ?>



	</body>
</html>