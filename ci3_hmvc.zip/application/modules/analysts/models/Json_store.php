<?php
class json_store extends CI_Model {
	function deleteFromStore($referenceId, $filter = null){
		$this->db->where('ref_id',$referenceId);
		if($filter != null)
			$this->db->where('filter',$filter);
		if($this->db->delete('json_store'))
			return true;
		else
			return false;
	}
	function insertJsonToStore($rowData){
		$this->db->insert("json_store",$rowData);
	}
}
?>