<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array('i18n/grid.locale-en',
							'jquery.jqGrid.min',
							'CalendarControl',
							//'jquery.validate',
							'jquery/jquery.validate1.9.min',
							'jquery/jquery-ui-1.8.16.slider'
							);
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet" />
<style type="text/css">
    #addPlansForm input[type="text"]{
        width:155px;
    }
    .required{
        color:#ff0000;
    }
 .add-icon{
        background-image: url("<?php echo base_url(); ?>images/add_active.png");
        background-repeat: no-repeat;
        background-size: 20px auto;
        cursor: pointer;
        display: inline-block;
        height: 27px;
        vertical-align: middle;
        width: 25px;
        background-size: 21px;
        background-repeat: no-repeat;
    }
 .remove-icon{
        background-image: url("<?php echo base_url(); ?>images/delete_active.png");
        background-repeat: no-repeat;
        background-size: 20px auto;
        cursor: pointer;
        display: inline-block;
        height: 27px;
        vertical-align: middle;
        width: 25px;
        background-size: 21px;
    }
    /*	div.addIcon {
                    margin-top: 24px;
            }
    */
    #createPlansContiner #plansDetails tr td select{
        width:190px;
    }
    div.actionIcon{
        margin-top: 15px;
    }
    .pd{
        width:75px;
    }
     table.tabularGrid caption{
        /*background:url("<?php echo base_url(); ?>images/kolm-sprite-image.png") repeat-x scroll -2px -236px transparent;*/
        background: #ececec none repeat scroll 0 0;
    	box-shadow: 0 0 4px #d1d1d1 inset;
    	color: #333333;
    	padding-left: 5px;
    }
    table.tabularGrid td:FIRST-CHILD{
        padding-left: 5px;
    }
    table.interactionDetails td:nth-child(1){
        width: 150px !important;
    }
    table.interactionDetails td:nth-child(2){
        width: 300px !important;
    }
    table.interactionDetails td:nth-child(3){
        width: 150px !important;
    }
    #interactionMicroProfileContent table.highlightHeadings tr th{
        background-color: #eee;
    }
    h5.heading{
        background: none repeat scroll 0 0 #D8E5F4;
        color: #2D53AF;
        margin-bottom: 2px;
        padding: 5px;
    }

    #historyContainer > div > div{
        border-bottom: 1px solid #bbbbbb;
    }
    #historyContainer ul{
        list-style: none;
    }
    #CalendarControlIFrame{
		display: none;
	}
</style>

<script>

   $(document).ready(function () {
        $('table.tabularGrid caption div.collapseSlider').click(function () {
            if ($(this).attr('class') != "collapseSlider") {
                $(this).parent().parent().find('tbody').hide('slow');
                $(this).find('a').attr('data-original-title', 'Expand');
            } else {
                $(this).parent().parent().find('tbody').show('slow');
                $(this).find('a').attr('data-original-title', 'Collapse');
            }
            $(this).toggleClass('expandSlider');
        });
        var data = {plan_id:<?php echo $planDetails[0]['id'] ?>};
        jQuery("#listInteractionsResultSet").jqGrid({
			url:base_url+'interactions/list_interactions_by_date_range/',
			datatype: "json",
		   	colNames:['Id','','','KTL / Org Name',"Interaction Date","Employee Name",'Interaction Type','Discussion Type','Product','Recorded By','Quality',"<div class='tooltip-demo tooltop-bottom'><span rel='tooltip' title='Unsolicited Off\-Label Question'>UOQ</span></div>",'','','','',''], 
		   	colModel:[
				{name:'generic_id',index:'generic_id', hidden:false,width:90},
				{name:'save_later',index:'save_later', hidden:true},
				{name:'micro',width:30, search:false,align:'center',sortable:false},
				{name:'kol_name',index:'kol_name',width:170, resizable:false},
				{name:'date',index:'date', width:120, resizable:false},
		   		{name:'recorded_by',index:'recorded_by',width:100, resizable:false},
		   		{name:'mode_name',index:'mode_name',width:100, resizable:false},
				{name:'objective_name',index:'objective_name',width:180, resizable:false},
		   		{name:'product_name',index:'product_name',width:150, resizable:false},
		   		{name:'recorded_by',index:'recorded_by',width:100, resizable:false},
		   		{name:'quality_interaction',index:'quality_interaction',width:100, resizable:false,hidden:true},
		   		{name:'mirf',width:60,align:'center',align:'left',search:true,sortable:true,hidden:true, formatter: function (cellvalue, options, rowObject) {
			   		var mirfText = '';
			   		if(rowObject.mirfAllowed){
						if(cellvalue =="Add"){
							mirfText = "<a href='"+base_url+"interactions/add_mirf/"+rowObject.id+"' title='"+cellvalue+" Unsolicited Off-Label Question'>"+cellvalue+"</a>";
						}else{
							if(rowObject.save_later == 1)
								mirfText = "<a href='"+base_url+"interactions/add_mirf/"+rowObject.id+"' title='"+cellvalue+" Unsolicited Off-Label Question'>"+cellvalue+"Edit</a>"+" "+"<a href='"+base_url+"interactions/view_mirf/"+rowObject.id+"' title='"+"View"+" Unsolicited Off-Label Question'>"+"View"+"</a>";
							else
								mirfText = "<a href='"+base_url+"interactions/view_mirf/"+rowObject.id+"' title='"+"View"+" Unsolicited Off-Label Question'>"+"View"+"</a>";
							//mirfText += "<a href='"+base_url+"interactions/add_mirf/"+rowObject.id+"' title='"+cellvalue+" Unsolicited Off-Label Question'>"+cellvalue+"</a>"+" "+"<a href='"+base_url+"interactions/view_mirf/"+rowObject.id+"' title='"+"View"+" Unsolicited Off-Label Question'>"+"Edit"+"</a>";
						}
					}else{
						if(rowObject.mirf_id != null)
							mirfText = "<a href='"+base_url+"interactions/view_mirf/"+rowObject.id+"' title='"+"View"+" Unsolicited Off-Label Question'>"+"View"+"</a>";
                                   }
	            return mirfText;
	            }},	          
	            {name:'mirfAllowed',width:60,align:'center',hidden:true},
		   		{name:'mirf_id',width:60,align:'center',hidden:true},
		   		{name:'eAllowed',width:100,index:'eAllowed', hidden:true,search:false},
		   		{name:'id',index:'id', hidden:true},
                                {name:'msl_id',index:'msl_id', hidden:true}
		   	],
			postData:data,
		   	rowNum:10,
		   	rownumbers: true,
		   	autowidth: false, 
		   	loadonce:false,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",		 
		   	pager: '#listInteractionsPage',
		   	mtype: "POST",
		   	sortname: 'date',
		    viewrecords: true,
		    sortorder: "desc",
		    shrinkToFit:true,
		    jsonReader: { repeatitems : false, id: "0" }, 
		    caption:'Interactions',
		    grouping: false, 
			groupingView : { 
				groupField : ['kol_name'], 
				groupColumnShow : [false], 
				groupText : ['<b>{0}</b>  ({1})'], 
				groupCollapse : false, 
				groupOrder: ['asc'], 
			//	groupSummary : [true], 
				groupDataSorted : true 
			},
			gridComplete: function(){
				//Get array of id'f from jqgrid			   
		    	var arrIds = jQuery("#listInteractionsResultSet").jqGrid('getDataIDs'); 
		    	// Loop trough each row(id) and prepare a microview, edit and delete links and update the perticular row
		    	for(var i=0;i < arrIds.length;i++){ 
		    		actionLink = '';
			    	var id = arrIds[i];
			    	var rowData = jQuery("#listInteractionsResultSet").jqGrid('getRowData', id);
			    	//Microview label  	
		    		microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewInteractionMicroProfile('"+rowData.id+"'); return false;\" ><a href='<?php echo base_url();?>interactions/view_micro_interaction/"+rowData.id+"/plan' target='_Blank' class=\"tooltipLink\" rel='tooltip' title=\"View Interaction\">&nbsp;</a></div></label>";	
			    	jQuery("#listInteractionsResultSet").jqGrid('setRowData',arrIds[i],{micro:microviewLink}); 

			    }
		    	
		    },
	   		rowList:paginationValues
				
		});

		var ele=document.getElementById('gridContainer');
		var gridWidth=ele.clientWidth+20;
        jQuery("#listInteractionsResultSet").jqGrid('setGridWidth',gridWidth); 
    });




</script>
<div id="createPlansContiner">
    <form name="addPlansForm" id="addPlansForm" action="<?php echo base_url() ?>plannings/save_plans" >
        <div class="msgBoxContainer"><div class="planMsgBox"></div></div>
        <input type="hidden" name="number_of_plans" value="1" id="numberOfPlans"></input>
        <p id="objectivesSelect">
<!--			<label>Plan Name :<span class="required">*</span></label>
                <select name="objective_id" id="objectiveId" class="required">
                        <option value="">Select Objective</option>
            <?php if (isset($arrObjectives)) { ?>
                <?php foreach ($arrObjectives as $key => $value) { ?>
                                                <option value="<?php echo $key; ?>"><?php echo $value; ?></option>
                <?php } ?>
            <?php } ?>
                </select>-->

        
           
                 <table class="highlightHeadings tabularGrid">
        <caption>Plan Details
            <div id="collapseExpandButton" class="expandSlider collapseSlider">
                <a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
            </div>
        </caption>
               

                    <tr>
                        <td class='pd'><b>Plan Name</b> :</td><td><?php echo $planDetails[0]['plan_name'] ?></td>
                    </tr>
                    <tr>
                        <td class='pd'><b>Start Date</b> :</td><td class=''><?php echo $planDetails[0]['plan_start'] ?></td>
                        <td class='pd'><b>End Date</b> :</td><td><?php echo $planDetails[0]['plan_end'] ?></td>
                    </tr>
                    <tr>
                       
                    </tr>
                    <tr>
                        <td class='pd'><b>Description</b>:</td><td><?php echo $planDetails[0]['plan_description'] ?></td>
                    </tr>

                </table>
            
        
        </p>

       <table class="highlightHeadings tabularGrid">
            <caption>Objectives
                <div id="collapseExpandButton" class="expandSlider collapseSlider">
                    <a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
                </div>
            </caption>
           
            <?php foreach($arrObj as $data) {?>
                <tr>
                    <td><?php echo $data['name']  ?></td>
                   
                </tr>
                
             <?php }?>
            

        </table>
    </form>
    
       <table class="highlightHeadings tabularGrid">
        <caption>Assigned Profiles
            <div id="collapseExpandButton" class="expandSlider collapseSlider">
                <a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
            </div>
        </caption>
        <tr>
        	
            <th>
               KTL
            </th>
            <th>Email</th>
            <th>Assigned To</th>
             <th>Status</th>
            <!--<th>Note</th>-->
             <?php 
             $totalCount = count($planDetails);
             $i=1;
             foreach($planDetails as $data) { 
             	$totalKolsCount = count(explode(',', $data['kols']));
           		$arrKolFirstName = explode(',', $data['first_name']);
           		$arrKolMiddleName = explode(',', $data['middle_name']);
           		$arrKolLastName = explode(',', $data['last_name']);
           		$arrKolPrimaryEmail = explode(',', $data['primary_email']);
           		$kolFullName = NULL;
           		$kolPrimaryEmail = NULL;
           		for($j=0;$j<$totalKolsCount;$j++){
           			$kolFullName .= $arrKolFirstName[$j].' '.$arrKolMiddleName[$j].' '.$arrKolLastName[$j].'<br>';
           			$kolPrimaryEmail .= $arrKolPrimaryEmail[$j].'<br>';
           		}
             	?>
             
                <tr>
                    <td><?php echo $kolFullName;  ?></td>
                    <td><?php echo $kolPrimaryEmail;  ?> </td>
                    <td><?php echo $data['user_first_name']." ".$data['user_last_name']  ?> </td>
                    <td><?php echo ucfirst($data['status']) ?> </td>
                </tr>
                
             <?php }?>
        </tr>
        
    </table>   
    <div id="gridTabContainer clear" style="margin-top: 20px;">
		<div class="gridWrapper" id="gridContainer">

			<div id="listInteractionsPage"></div>

			<table id="listInteractionsResultSet"></table>

		</div>
	</div>
     
</div>