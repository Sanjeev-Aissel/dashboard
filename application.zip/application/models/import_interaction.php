<?php
class Import_interaction extends Model {

	function Import_interaction() {
		parent::Model();
		$this->load->model('common_helpers');
		$this->load->model('calendar');
		$this->load->model('update');
		$this->load->model('Client_User');
		$this->load->model('planning');
		$this->load->library('SimpleLoginSecure');
	}
	function getUserDetails($username){
		$id = '';
		$name = explode(" ",$username);
		foreach($name as $key=>$row){
			if($key == 0){
				$first_name = $row;
			}else{
				$last_name = $row;
			}
		}
		$this->db->select('id');
		$this->db->where('first_name',$first_name);
		$this->db->where('last_name',$last_name);
		$query = $this->db->get('client_users');
		//     	echo $this->db->last_query();exit;
		if($query->num_rows()==0){
			$arrUser = array();
			$hasher = new PasswordHash(PHPASS_HASH_STRENGTH, PHPASS_HASH_PORTABLE);
			$arrUser['first_name'] = $first_name;
			$arrUser['last_name'] = $last_name;
			$arrUser['client_id']		=	17;
			$arrUser['user_name'] = str_replace(" ","_",strtolower($username));
			$arrUser['password']		=	$hasher->HashPassword('colgate@468');
			$arrUser['created_on']		=	date('Y-m-d H:i:s');
			$arrUser['user_role_id']	=	1;
			$arrUser['about']	=	'User for legacy data';
			$arrUser['is_activated'] = 0;
			$arrUser['status'] = 1;
			$arrUser['user_from'] = 2;
			$id= $this->Client_User->saveUser($arrUser);
		}else{
			$row = $query->row_array();
			$id = $row['id'];
		}
		return $id;
	}
	
	function getObjectiveId($arrObjDetails){
		$objId = '';
		$this->db->select('id');
		$this->db->where('unique_id',$arrObjDetails['unique_id']);
		$query = $this->db->get('objectives');
		if($query->num_rows()==0){
			$objId= $this->planning->saveObjective($arrObjDetails);
		}else{
			$row = $query->row_array();
			$objId = $row['id'];
		}
		return $objId;
	}
	
	function getPlanId($arrPlanDetails){
		$planId ='';
		$this->db->select('id');
		$this->db->where('plan_name',$arrPlanDetails['plan_name']);
		$this->db->where('client_id',$arrPlanDetails['client_id']);
		$results=$this->db->get('plan_details');
		if($results->num_rows()==0){
			$planId= $this->planning->savePlan($arrPlanDetails);
		}else{
			$row = $results->row_array();
			$planId = $row['id'];
		}
		return $planId;
	}
	
	function savePlanObjective($arrPlanObjAssociate){
		$planObjId = $this->planning->savePlanObjective($arrPlanObjAssociate);
		return $planObjId;
	}
	
	function getInteractionTypes($name){
		$arrTypeNames = array();
		 $this->db->where('status', 1);
		 $interactionTypeList = $this->db->get('interaction_types');
		 foreach($interactionTypeList->result_array() as $row){
		 	$arrTypeNames[$row['id']]	= $row['name'];
		 }
		 return $arrTypeNames;
	}
	
 	function saveInteraction($arrInteractionDetails) {
 		$interactionId = '';
		$this->db->select('id');
		$this->db->where('generic_id',$arrInteractionDetails['generic_id']);
		$query = $this->db->get('interactions');
		if($query->num_rows()==0){
			if ($this->db->insert('interactions', $arrInteractionDetails)) {
	            $interactionId	= $this->db->insert_id();
			}
		}else{
			$row = $query->row_array();
			$interactionId = $row['id'];
		}
		return $interactionId;
    }
    
	function getInteractionIdByGenericId($genericId=0){
		$interactionId = '';
		$this->db->select('id');
		$this->db->where('generic_id',$genericId);
		$query = $this->db->get('interactions');
		if($query->num_rows()>0){
			$row = $query->row_array();
			$interactionId = $row['id'];
		}
		return $interactionId;
	}
 	function saveTopic($name=''){
 		$topicId = '';
 		if(!empty($name)){
	 		$arrInteractionTopicDetails['name']	= $name;
	 		$arrInteractionTopicDetails['status']	= 0;
			$this->db->select('id');
			$this->db->where('name',$name);
			$query = $this->db->get('interaction_topics');
			if($query->num_rows()==0){
				if ($this->db->insert('interaction_topics', $arrInteractionTopicDetails)) {
		            $topicId	= $this->db->insert_id();
				}
			}else{
				$row = $query->row_array();
				$topicId = $row['id'];
			}
 		}
		return $topicId;
    }
}
?>