<?php
/**
 * Used to display the short information of the Organization Profile
 */
?>
	<?php 
		if($arrOrganization['type_id'] != 0)
			$organizationType	= $arrOrganizationTypes[$arrOrganization['type_id']];
		else
			$organizationType = "";
		
	?>
	<style>
	.profileImage {
		height: auto;
	}
	</style>
	<div id="organizationShortDetails">
		<div class="profileImage">
			<?php 
				if($arrOrganization['company_logo'] != ''){
					echo '<img alt="Image" width=120" src="'. base_url(). 'images/organization_images/resized/'. $arrOrganization['company_logo'].'"/>';
				}else{?>
					<img alt="Image" src="<?php echo base_url()?>images/organization_logo.png" width="120px" />
					<?php 
				}
			?>
		</div>
		<p class="profileName">
			<?php echo $arrOrganization['name']; ?> <br />
			<?php echo $organizationType; ?>
		</p>
	</div>