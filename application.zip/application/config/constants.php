<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/
define('FILE_READ_MODE', 0644);
define('FILE_WRITE_MODE', 0666);
define('DIR_READ_MODE', 0755);
define('DIR_WRITE_MODE', 0777);

/*
|--------------------------------------------------------------------------
| File Stream Modes
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
|
*/

define('FOPEN_READ', 							'rb');
define('FOPEN_READ_WRITE',						'r+b');
define('FOPEN_WRITE_CREATE_DESTRUCTIVE', 		'wb'); // truncates existing file data, use with care
define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE', 	'w+b'); // truncates existing file data, use with care
define('FOPEN_WRITE_CREATE', 					'ab');
define('FOPEN_READ_WRITE_CREATE', 				'a+b');
define('FOPEN_WRITE_CREATE_STRICT', 			'xb');
define('FOPEN_READ_WRITE_CREATE_STRICT',		'x+b');

/*
 * Product Name, Version etc For release support reference
 */
define('PRODUCT_NAME','KOLM');
define('PRODUCT_VERSION','KOLM v7.0');
define('KOLM_VERSION','KOLM V7.0');
define('APP_PRODUCT_INFO_HEADER',PRODUCT_NAME);
define('APP_PRODUCT_INFO_FOOTER',KOLM_VERSION.' ('.PRODUCT_NAME.')');
define('COPYRIGHT','2017');
/*
|---------------------------------------------------------------------------- 
| Holds the Client_id for Aissel and Guest
|---------------------------------------------------------------------------- 
*/
define('INTERNAL_CLIENT_ID', '1');
define('INTERNAL_USER_ID', '8');


define('GUEST_CLIENT_ID', '2');

define('ROLE_ADMIN', '3');
define('ROLE_MANAGER', '2');
define('ROLE_USER', '1');
define('ROLE_READONLY_USER', '0');

//define('ANALYST_EMAIL_ID', 'rameshb@aissel.com');
define('FEEDBACK_EMAIL_ID', 'dev@aissel.com');
define('ANALYST_EMAIL_ID', 'contentservice@aissel.com');

/*
|---------------------------------------------------------------------------- 
| Holds the Id to determine App is in Maintenance
|---------------------------------------------------------------------------- 
*/
define('UNDER_MAINTENANCE', '0');
/*
|---------------------------------------------------------------------------- 
| Determine Apps ENVIRONMENT ('development','testing','production')
|---------------------------------------------------------------------------- 
*/
define('ENVIRONMENT','production');

/*
|--------------------------------------------------------------------------
| Calendar Event Types
|--------------------------------------------------------------------------
|
| These types are used while saving the calendar event
|
*/
define('EVENT_TYPE_GENERAL', 'EVENT_TYPE_GENERAL');
define('EVENT_TYPE_INTERACTION', 'EVENT_TYPE_INTERACTION');
define('EVENT_TYPE_BIRTHDAY', 'EVENT_TYPE_BIRTHDAY');
define('EVENT_TYPE_ANNIVERSARY', 'EVENT_TYPE_ANNIVERSARY');

/* End of file constants.php */
/* Location: ./system/application/config/constants.php */

/*
|--------------------------------------------------------------------------
| Constants used for Mobile App
|--------------------------------------------------------------------------
||
*/
define('KOLS_PER_REQUEST_MOBILE', 5);
define('LIST_RECORDS_PER_SHOWMORE_REQUEST_MOBILE', 5);
define('MOBILE_URL_SEGMENT', 'm');
define('MOBILE_APP_FOLDER', 'mobile');
define('IPAD_URL_SEGMENT', 'i');
define('IPAD_APP_FOLDER', 'ipad');

/*
|--------------------------------------------------------------------------
| Constants used For Staus
|--------------------------------------------------------------------------
||
*/
define('COMPLETED', 'Completed');
define('REVIEW', 'Review');
define('New1', 'New');
define('APPROVED', 'Approved');
define('PROFILING', 'Profiling');
define('PRENEW', 'Not Requested');
define('REJECT','Rejected');
define('RE_REQUEST','Re-request');
define('REQUESTED','Requested');
define('CREATED','Created');
define('UPDATED','Updated');
define('RESPONDED','Responded');

define('STATUS_COMPLETED', 100);
define('STATUS_REVIEW', 101);
define('STATUS_NEW', 102);
define('STATUS_APPROVED', 103);
define('STATUS_PROFILING', 104);
define('STATUS_REJECTED', 105);
define('STATUS_REQUESTED', 106);
define('STATUS_CREATED', 107);
define('STATUS_UPDATED', 108);
define('STATUS_RESPONDED', 109);

define('REQUEST_TYPE_PROFILE', 100);
define('REQUEST_TYPE_UPGRADE', 101);

/*
|--------------------------------------------------------------------------
| Constants used For Email
|--------------------------------------------------------------------------
||
*/
define('NOTIFICATION_SENDER', 'Notifications');
define('NOTIFICATION_PROTOCOL', 'smtp');
define('NOTIFICATION_HOST', 'ssl://smtp.bizmail.yahoo.com');
define('NOTIFICATION_PORT', 465);
define('NOTIFICATION_USER', 'contentservice@aissel.com');
define('NOTIFICATION_PASS', 'content@aissel');
/*
define('OPTINOUT_SENDER', 'Hills');
define('OPTINOUT_PROTOCOL', 'smtp');
define('OPTINOUT_HOST', 'mail.aisselkolm.com');
define('OPTINOUT_PORT', 25);
define('OPTINOUT_USER', 'hillsoptin@aisselkolm.com');
define('OPTINOUT_PASS', 'hillsoptin@aisselkolm.com');
*/
define('OPTINOUT_SENDER', 'Hills');
define('OPTINOUT_PROTOCOL', 'smtp');
define('OPTINOUT_HOST', 'ssl://smtp.bizmail.yahoo.com');
define('OPTINOUT_PORT', 465);
define('OPTINOUT_USER', 'contentservice@aissel.com');
define('OPTINOUT_PASS', 'content@aissel');

define('PROFILE_REQUEST_SENDER', 'noreply@aissel.com');
define('PROFILE_REQUEST_PROTOCOL', 'smtp');
define('PROFILE_REQUEST_HOST', 'ssl://smtp.bizmail.yahoo.com');
define('PROFILE_REQUEST_PORT', 465);
define('PROFILE_REQUEST_USER', 'contentservice@aissel.com');
define('PROFILE_REQUEST_PASS', 'content@aissel');

define('SUPPORT_SENDER', 'Production Support');
define('SUPPORT_PROTOCOL', 'smtp');
define('SUPPORT_HOST', 'ssl://smtp.bizmail.yahoo.com');
define('SUPPORT_PORT', 465);
define('SUPPORT_USER', 'vinodh@aissel.com');
define('SUPPORT_PASS', 'Aissel123');

/* define('SUPPORT_SENDER', 'Production Support');
define('SUPPORT_PROTOCOL', 'smtp');
define('SUPPORT_HOST', 'mail.aisselkolm.com');
define('SUPPORT_PORT', 25);
define('SUPPORT_USER', 'productionsupport@aisselkolm.com');
define('SUPPORT_PASS', 'vdpr@057'); */

/* define('SENDER', 'noreply@aissel.com');
define('PROTOCOL', 'smtp');
define('HOST', 'ssl://smtp.mail.aisselkolm.com');
define('PORT', 465);
define('USER', 'no-reply@aisselkolm.com');
define('PASS', 'no-reply@aisselkolm.com'); */
define('SENDER', 'noreply@aissel.com');
define('PROTOCOL', 'smtp');
define('HOST', 'ssl://smtp.bizmail.yahoo.com');
define('PORT', 465);
define('USER', 'contentservice@aissel.com');
define('PASS', 'content@aissel');
// define('USER', 'no-reply@aissel.com');
// define('PASS', 'Ais_Norep@123');

define('MEDINTEL','medintelnews@aissel.com');
define('MEDINTELPASS','Hubli@123');
/*define('PROTOCOL', 'smtp');
define('HOST', 'smtp.bizmail.yahoo.com');
define('PORT', 587);
define('USER', 'kolm@aissel.com');
define('PASS', 'aissel123');*/
/*
To work with local system
define('HOST', '192.168.1.90');		// When you are behind the proxy
define('PORT', 25);
define('USER', 'developer@aisselkolm.com#mail.aisselkolm.com');
define('PASS', 'dev123');
*/
/*
|--------------------------------------------------------------------------
| Constants used for Updates/Activities section
|--------------------------------------------------------------------------
||
*/
define('KOL_PROFILE_IMPORT', 100);
define('KOL_PROFILE_ADD', 101);
define('KOL_PROFILE_DELETE', 102);
define('KOL_PROFILE_OVERVIEW_UPDATE', 103);
define('KOL_PROFILE_CONTACT_ADD', 104);
define('KOL_PROFILE_CONTACT_UPDATE', 105);
define('KOL_PROFILE_CONTACT_DELETE', 106);
define('KOL_PROFILE_EDUCATION_ADD', 107);
define('KOL_PROFILE_EDUCATION_UPDATE', 108);
define('KOL_PROFILE_EDUCATION_DELETE', 109);
define('KOL_PROFILE_AFFILITION_ADD', 110);
define('KOL_PROFILE_AFFILITION_UPDATE', 111);
define('KOL_PROFILE_AFFILITION_DELETE', 112);
define('KOL_PROFILE_EVENT_ADD', 113);
define('KOL_PROFILE_EVENT_UPDATE', 114);
define('KOL_PROFILE_EVENT_DELETE', 115);
define('KOL_PROFILE_SOCIAL_MEDIA_UPDATE', 116);
define('KOL_PROFILE_PUBLICATION_ADD', 117);
define('KOL_PROFILE_PUBLICATION_DELETE', 118);
define('KOL_PROFILE_PUBLICATION_VERIFY', 119);
define('KOL_PROFILE_PUBLICATION_UNVERIFY', 120);
define('KOL_PROFILE_TRIAL_ADD', 121);
define('KOL_PROFILE_TRIAL_UPDATE', 122);
define('KOL_PROFILE_TRIAL_DELETE', 123);
define('KOL_PERSONAL_INFO_ADD', 124);
define('KOL_PERSONAL_INFO_UPDATE', 125);
define('KOL_PROFILE_PUBLICATION_UPDATE', 126);

define('KOL_STATUS_UPDATE', 127);


define('ORG_IMPORT', 200);
define('ORG_ADD', 201);
define('ORG_DELETE', 202);
define('ORG_ABOUT_UPDATE', 203);
define('ORG_ADDRESS_UPDATE', 204);
define('ORG_CONTACT_ADD', 205);
define('ORG_CONTACT_UPDATE', 206);
define('ORG_CONTACT_DELETE', 207);
define('ORG_SOCIAL_MEDIA_UPDATE', 208);
define('ORG_KEY_PEOPLE_ADD', 209);
define('ORG_KEY_PEOPLE_UPDATE', 210);
define('ORG_KEY_PEOPLE_DELETE', 211);
define('ORG_ENROLLEMET_ADD', 212);
define('ORG_ENROLLEMET_UPDATE', 213);
define('ORG_ENROLLEMET_DELETE', 214);

define('ORG_FORMULARY_ADD', 215);
define('ORG_FORMULARY_UPDATE', 216);
define('ORG_FORMULARY_DELETE', 217);

define('ORG_DISEASE_ADD', 218);
define('ORG_DISEASE_UPDATE', 219);
define('ORG_DISEASE_DELETE', 220);

define('ORG_NOTES_ADD', 221);
define('ORG_NOTES_UPDATE', 222);
define('ORG_NOTES_DELETE', 223);


define('ORG_PUBLICATION_ADD', 224);
define('ORG_PUBLICATION_UPDATE', 225);
define('ORG_PUBLICATION_DELETE', 226);


define('ORG_TRIAL_ADD', 227);
define('ORG_TRIAL_UPDATE', 228);
define('ORG_TRIAL_DELETE', 229);

define('ORG_PUBLICATION_VERIFY', 230);
define('ORG_PUBLICATION_UNVERIFY', 231);

define('ORG_COLLABARATION_ADD', 232);


define('USER_ADD', 300);
define('USER_UPDATE', 301);
define('USER_DELETE', 302);
define('CLIENT_ADD', 303);
define('CLIENT_UPDATE', 304);
define('CLIENT_DELETE', 305);

define('KOL_LIST_CREATE', 400);
define('KOL_LIST_UPDATE', 401);
define('KOL_LIST_ADD', 402);
define('KOL_LIST_DELETE', 403);

define('OBJECTIVE_ADD', 500);
define('OBJECTIVE_UPDATE', 501);
define('OBJECTIVE_DELETE', 502);

define('PLAN_ADD', 503);
define('PLAN_UPDATE', 504);
define('PLAN_DELETE', 505);

define('INTERACTION_ADD', 506);
define('INTERACTION_UPDATE', 507);
define('INTERACTION_DELETE', 508);

define('PAYMENT_ADD', 509);
define('PAYMENT_UPDATE', 510);
define('PAYMENT_DELETE', 511);

define('CLIENT_EVENT_ADD', 512);
define('CLIENT_EVENT_UPDATE', 513);
define('CLIENT_EVENT_DELETE', 514);

define('CONTRACT_ADD', 515);
define('CONTRACT_UPDATE', 516);
define('CONTRACT_DELETE', 517);

define('CALENDER_EVENT_ADD', 518);
define('CALENDER_EVENT_UPDATE', 119);
define('CALENDER_EVENT_DELETE', 520);

/*
|--------------------------------------------------------------------------
| Constants used for modules
|--------------------------------------------------------------------------
||
*/
define('MODULE_KOL_OVERVIEW', 100);
define('MODULE_KOL_EDUCATION', 101);
define('MODULE_KOL_EVENT', 102);
define('MODULE_KOL_AFFILIATION', 103);
define('MODULE_KOL_PUBLICATION', 104);
define('MODULE_KOL_TRIAL', 105);
define('MODULE_INTERACTION', 106);
define('MODULE_PAYMENT', 107);
define('MODULE_PLANNING', 108);
define('MODULE_ORGANIZATION', 109);
define('MODULE_CLIENT_USERS', 110);
define('MODULE_KOL_REQUEST', 111);

define('ORG_STATUS_UPDATE', 130);
define('MODULE_ORG_REQUEST',131);
define('SURVEY_STATUS_UPDATE', 140);
define('SURVEY_STATUS_ADD', 142);
define('SURVEY_STATUS_RESPONDED',143);
define('MODULE_SURVEY',141);

define('MODULE_ORG_ENROLLMENT', 112);
define('MODULE_ORG_FORMULARY', 113);
define('MODULE_ORG_DISEASE', 114);
define('MODULE_ORG_NOTES', 115);
define('MODULE_ORG_KEY_PEOPLE', 116);
define('MODULE_ORG_PUBLICATION', 117);
define('MODULE_ORG_TRIAL', 118);
define('MODULE_ORG_COLLABARATION', 119);

/*
|--------------------------------------------------------------------------
| Constants used for Json Store
|--------------------------------------------------------------------------
||
*/
define('JSON_STORE_DASHBOARD', 100);
define('JSON_STORE_ACTIVITY', 101);
define('JSON_STORE_ACTIVITY_REPORT', 102);
define('JSON_STORE_PUBLICATIONS_BY_YEAR', 103);
define('JSON_STORE_PUBLICATIONS_BY_KEYWORDS', 104);
define('JSON_STORE_PUBLICATIONS_BY_SUBSTANCES', 105);
define('JSON_STORE_PUBLICATIONS_BY_JOURNALS', 106);
define('JSON_STORE_PUBLICATIONS_BY_TYPE', 107);



/*
|--------------------------------------------------------------------------
| Constants used for Date format defination
|--------------------------------------------------------------------------
||
*/
define('APP_DATE_FORMAT', 'MM/DD/YYYYY');

/*
|--------------------------------------------------------------------------
| Constants used for table based pagination dropdown values
|--------------------------------------------------------------------------
||
*/
define('PAGINATION_VALUES','10,50,100,150');

/*
|--------------------------------------------------------------------------
|	To check whether the request is ajax request or page request
|--------------------------------------------------------------------------
*/
define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest');

/*
|--------------------------------------------------------------------------
|	To check whether the HTTP User agent is iPad. i.e. request is from iPad
|--------------------------------------------------------------------------
*/
define('IS_IPAD_REQUEST',(bool) strpos($_SERVER['HTTP_USER_AGENT'],'iPad'));



/*
|--------------------------------------------------------------------------
| Constants used for Org Payors dropdown values
|--------------------------------------------------------------------------
||
*/
define('CLAIMS', 1);
define('DATA_PROCESSING', 2);
define('DRUG_TIER', 1);
define('PA_CRITERIA', 2);

define('DISEASE_MANAGEMENT_PLATFORMS', 1);
define('IDENTIFICATION', 2);
define('INTERVENTION', 3);
define('MEASUREMENT', 4);

define('PAYOR', 8);

/*
|--------------------------------------------------------------------------
| Constants used for Organization Profile Type values
|--------------------------------------------------------------------------
||
*/

define('BASIC', 1);
define('FULL', 2);
define('MARKET_ACCESS', 'Market Access');
define('USER_ADDED', 'User Added');
define('LEGACY', 'Legacy');
define('DISCOVERY', 'Discovery');

/*
 * 	Constans used for Modal Box
 * /
 */

define('POSITION_TOP',155);

define("CHART_COLOR_CODES",'["#537FB2","#E77368","#FBCC42","#7DCAA7","#F79820","#C3C4C6","#23885B","#0487C9","#D97000"]');

/* Diffrent color combination
 * "['#058DC7', '#50B432', '#ED561B', '#DDDF00', '#24CBE5', '#64E572','#FF9655', '#FFF263', '#6AF9C4']"

/* Name constant configuaration
*/
define('FIRST_ORDER','first_name');
define('SECOND_ORDER','middle_name');
define('THIRD_ORDER','last_name');

// Constants for Allign Kols/Orgs
define('MY_RECORDS',1);
define('ALL_RECORDS',2);

define('USER_LOGS',true);
define('SURVEY_ADD',1);
define('SURVEY_ADD_FAILED',11);
define('SURVEY_UPDATE',2);
define('SURVEY_UPDATE_FAILED',22);

define('SURVEY_QUESTION_ADD',3);
define('SURVEY_QUESTION_FAILED',33);
define('SURVEY_QUESTION_UPDATE',4);
define('SURVEY_QUESTION_UPDATE_FAILED',44);

//Survey Delete
define('SURVEY_DELETE',5);
define('SURVEY_RESPOND',6);

// defining api url constatn
define("API_URL","http://203.129.219.9/poland/");

// defining app key kolmcore
define("APP_KEY", "zyxwvukolmcorelkjihgfedcba9876543210");

// Active/Deactive/Deleted Users

define("ACTIVATED_USER","0");
define("DEACTIVATED_USER","1");
define("DELETED_USER","2");

/*
 * Constant for Notifications/Errors/Informations/Messages 
 */
// Survey
define('NOTE_FOR_ADDING_INFLUENCERS','Please provide 3 to 5 names or more if applicable.');
define('NOTE_FOR_LEAVING_SURVEYFORM','Please note: All data will be cleared on refresh or using the "Back" button.');
define('NOTE_FOR_MANDATORY_FILEDS','* mandatory fields.');

define('ALERT_FOR_MANDATORY_FILEDS','Fill all mandatory fields.');

define('CONFIRM_BEFORE_LEAVING_SURVEYFORM','All data will be lost, Are you sure you want to move to the previous screen?');

define('MSG_FOR_RECORDS_NOT_FOUND','Records not found.');
define('MSG_ON_SUBMITTING_SURVEY','Responses submitted successfully.');

define('SALES_REPORT_GROUP_NAME','Sales Report Team');
define('HCP_REPORT_GROUP_NAME','HCP Report Team');
/*
 * Near me feature constants
 */

define('NEAR_ME_DISTANCE_RADIUS',3);
define('NEAR_ME_RECORDS_LIMIT_PER_REQUEST',100);

define('DISCLAIMER','<p class="poweredByDisclaimer">Powered by <a href="http://www.aissel.com/" target="_new">Aissel</a></p>');

/*
 * Enable/Disable user activity
 */
define('LOG_USER_ACTIVITY',TRUE);

/*
 * Looging feature constants
 */
define('Add_Log',"add");
define('Update_Log',"update");
define('View_Log',"view");
define('List_Log',"list");


/*
 *  Button Labels
 */
define('SUBMIT_BUTTON_LABEL',"Save");


/**
 * Recorder by constant
 */
define('CREATED_BY',"Recorded By");
define('CREATED_ON',"Recorded On");

/*
 *  Default Icons 
 * /
 */
define('DEFAULT_ADDITIONAL_PANEL_ICON','ui-icon-custom-additional-panel');

/*
 *  Set Length or input fields
 * 
 */
define("MAX_LENGTH_INPUT",50);
define("MAX_LENGTH_TEXTAREA",200);

//define('KOL_ID_COLUMN','id');
define('KOL_ID_COLUMN','id');

//define('ORG_ID_COLUMN','id');
define('ORG_ID_COLUMN','id');

define('RESET_PASSWORD_AFTER_NO_OF_DAYS',100);
define('BLOCK_ON_NO_OF_FAILED_ATTEMPTS',5);
define('RESTRICT_NO_OF_PASSWORDS_TO_REUSE',5);

//set assessment module constant 1:enabled 0:disabled
define('ASSESSMENT_STATUS',0);

//Support application constant
define('LIVE_SUPPORT_URL', 'http://live-support.aisselkolm.com/');

//Kol user conatct type default value
define('DEFAULT_ASSIGN_TYPE',2);

//Enable or disable clinical trials
define('HIDE_CLINICAL_TRIALS',1);
define('HIDE_CLINICAL_RESERCH_INTERESTS',0);
define('HIDE_ORGANIZATION',1);
define('HIDE_ORGANIZATION_INTERACTION_EXPORT',0);
define('CUSTOMER_CLIENT_ID',17);
define('CRM_LABEL',1);

//List of approvar user ids comma separated
//define('APPROVER_IDS','232');
define('KOL_CONSENT',1);
define('KOL_CONSENT_REGION_VISBILITY','Europe');

//ENABLE / DISABLE Orgs Visibility Feature
define('ORGS_VISIBILITY',FALSE);

//Hills Specific enable disable
define('HILLS_SPECIFIC',TRUE);

//Force log out session timeout
define('IDLE_SESSION_TIMEOUT', 14400);

//ENABLE / DISABLE Orgs Contract Feature
define('ORGS_CONTRACT',TRUE);

//ENABLE / DISABLE State License in Kols
define('KOLS_STATE_LICENSE',TRUE);

//ENABLE / DISABLE Kols Delete functionality
define('KOLS_DELETE_FUNCTIONALITY',TRUE);

//ENABLE / DISABLE Kols Delete functionality
define('IDENTIFY_ENABLE',TRUE);

//ENABLE / DISABLE Cooke consent
define('COOKE_CONSENT',TRUE);

//ENABLE / DISABLE Future Requirnments
define('FUTURE_REQ_SET',TRUE);

//Activity Log Type
define('ADD_RECORD','ADD');
define('EDIT_RECORD','EDIT');
define('DELET_RECORD','DELET');
define('LIST_RECORD','LIST');
define('VIEW_RECORD','VIEW');
define('EXPORT_RECORD','EXPORT');
define('IMPORT_RECORD','IMPORT');
define('CRON_JOBS','JOBS');
define('REQUEST_PROFILE','REQUESTED');
define('REJECT_PROFILE','REJECTED');
define('APPROVE_PROFILE','APPROVED');
define('STATUS_SUCCESS','SUCCESS');
define('STATUS_FAIL','FAILURE');
define('LOG_ACTIVITY_EMAIL','EMAIL');

