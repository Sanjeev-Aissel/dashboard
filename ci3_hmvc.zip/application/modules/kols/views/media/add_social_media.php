<?php
/**
 * File to 'add' Social Media details
 *
 * @author: Ambarish
 * @created on: 9-12-10
 * @package application.views.media
 */
?>
<style>
	.navbar-global {
  background-color: indigo;
}

.navbar-global .navbar-brand {
  color: white;
}

.navbar-global .navbar-user > li > a
{
  color: white;
}

.navbar-primary {
  background-color: #ccc;
  bottom: 0px;
  left: 0px;
  position: absolute;
  top: 88px;
  width: 200px;
  z-index: 8;
  overflow: hidden;
  -webkit-transition: all 0.1s ease-in-out;
  -moz-transition: all 0.1s ease-in-out;
  transition: all 0.1s ease-in-out;
}

.navbar-primary.collapsed {
  width: 60px;
}

.navbar-primary.collapsed .glyphicon {
  font-size: 22px;
}

.navbar-primary.collapsed .nav-label {
  display: none;
}

.btn-expand-collapse {
    position: absolute;
    display: block;
    left: 0px;
    bottom:0;
    width: 100%;
    padding: 8px 0;
    border-top:solid 1px #666;
    color: grey;
    font-size: 20px;
    text-align: center;
}

.btn-expand-collapse:hover,
.btn-expand-collapse:focus {
    background-color: #222;
    color: white;
}

.btn-expand-collapse:active {
    background-color: #111;
}

.navbar-primary-menu,
.navbar-primary-menu li {
  margin:0; padding:0;
  list-style: none;
}

.navbar-primary-menu li a {
  display: block;
  padding: 10px 18px;
  text-align: left;
  border-bottom:solid 1px #e7e7e7;
  color: #333;
}

.navbar-primary-menu li a:hover {
  background-color: #fff;
  text-decoration: none;
  color: #000;
}

.navbar-primary-menu li a .glyphicon {
  margin-right: 6px;
}

.navbar-primary-menu li a:hover .glyphicon {
  color: #4285F4;
}

.main-content {
  margin-left: 200px;
  padding: 5px 20px;
}

.collapsed + .main-content {
  margin-left: 60px;
}
.nav-tabs { 
	border-bottom: 2px solid #DDD; 
}
.nav-tabs > li.active > a, .nav-tabs > li.active > a:focus, .nav-tabs > li.active > a:hover { 
	border-width: 0;
}
.nav-tabs > li > a { 
	border: none; 
	color: #666; 
}
.nav-tabs > li.active > a, .nav-tabs > li > a:hover {
	border: none; 
	color: #4285F4 !important; 
	background: transparent; 
}
.nav-tabs > li > a::after { 
	content: ""; 
	background: #4285F4; 
	height: 2px; 
	position: absolute; 
	width: 100%; 
	left: 0px; 
	bottom: -1px; 
	transition: all 250ms ease 0s; 
	transform: scale(0); 
}
.nav-tabs > li.active > a::after, .nav-tabs > li:hover > a::after {
 	transform: scale(1); 
}
.tab-nav > li > a::after { 
	background: #21527d none repeat scroll 0% 0%; 
	color: #fff; 
}
.tab-pane {
	padding: 10px 0; 
}
.tab-content{
	padding:10px 20px;
}
img.add-org {
    position: absolute;
    left: 23pc;
    top: 23px;
}
.form-group {
    margin-bottom: 5px;
}
.imageUpload {
    margin-top: 35px;
}
.alert {
    padding: 10px  !important;
    margin-bottom: 0px !important;
    }
.close {
    top: 0px  !important;
    right: 0px  !important;
    font-size:18px;
}  
input#saveContact {
    position: absolute;
    top: 22px;
}  
.gridData{
	padding:0px 0px !important;
}
.panel-heading .colpsible-panel:after {
    
    font-family: 'Glyphicons Halflings'; 
    content: "\e114";    
    float: right;        
    color: #4285f4;         
}
.panel-heading .colpsible-panel.collapsed:after {
    content: "\e080"; 
}
.gridWrapper {
    width: 100% !important;
}
</style>	
	<script type="text/javascript">
		function saveSocialMedia(){
			if(!$("#socialMediaForm").validate().form()){
				return false;
			}
			formAction = '<?php echo base_url();?>kols/save_social_media';
			$('.verticalTabDataWrapper div.msgBox').removeClass('success');
			$('.verticalTabDataWrapper div.msgBox').addClass('notice');
			$('.verticalTabDataWrapper div.msgBox').show();
			$('.verticalTabDataWrapper div.msgBox').html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
			
			$.ajax({
				type: "post",
				data: $("#socialMediaForm").serialize(),
				url: formAction,
				success: function(returnData){
					if(returnData){
						$('.verticalTabDataWrapper div.msgBox').addClass('success');
						$('.verticalTabDataWrapper div.msgBox').text('Updated the data successfully');
					}
				},
				complete: function(){
					$('.verticalTabDataWrapper div.msgBox').fadeOut(1300);
					$(".msgBox").hide();
					$('.formError').hide();
				}
				
			});
		}

	</script>
			
	<style type="text/css">
		#socialMediaForm label img{
			height:28px;
			vertical-align: text-top;
		}	
		.analystForm input[type="text"], .analystForm select {
		    width: 400px;
		}
		#contentWrapper.span-24 {
		    background-image: url("<?php echo base_url();?>images/verticlesep.jpg");
		    background-position: 168px 50%;
		    background-repeat: repeat-y;
		}
	</style>
	<script type="text/javascript">
		var validationRules	=  {
				eduUrl1: {
					url: true
				},
				eduUrl2: {
					url: true
				}
			};
	
			var validationMessages = {
				url: "Please enter a valid URL address"
			};
	
		$(document).ready(function(){
				$("#socialMediaForm").validate({
					onkeyup:true,
					rules: validationRules,
					messages: validationMessages
				});
	
		});
	</script>	
	<?php $this->load->view('kols/secondary_menu');?>
<div class="main-content">
	<div class="row">
		<div id="kolTernaryNav" class="col-md-12">
        <!-- Start Nav tabs -->
               <ul class="nav nav-tabs" role="tablist">
                  <li role="Details" class="active"><a href="#social-links" aria-controls="social-links" role="tab" data-toggle="tab">Social Networking Links</a></li>          
               </ul>
		<!-- End Nav tabs -->
               <div class="tab-content">
               <div>
               	<h5 style="font-weight:bold;color:#656565;">Profile of : Kols Name</h5>
               </div>
        <!-- Start Tab panels -->
                  <div role="tabpanel" class="tab-pane active" id="social-links">
                  			<div class="panel panel-default"> 
	                  			<div class="panel-heading">
									<h3 class="panel-title"><a class="colpsible-panel" data-toggle="collapse" data-parent="#accordion" href="#collapse3" title="Click to Expand">Add Social Networking Links</a></h3> 
	                  				</a>
	                  			</div> 
	                  			<div id="collapse3" class="panel-collapse">
	                  			<div class="panel-body">
	                  				<div class="col-md-8 col-md-offset-2">
		                  				<form action="save_social_media" method="post" id="socialMediaForm" name="socialMediaForm" class="validateForm form-horizontal">
									 	   	<input type="hidden" name="kol_id" id="kolId" value="<?php echo $arrKol['id']?>"></input>
											 	<div class="analystForm" id="socialTbl">
											 		<div class="form-group">
															<label class="control-label col-sm-2"><img src="<?php echo base_url()?>images/social/blogger.png" title="Blog"/></label>
															<input style="margin-top: 5px;" type="text" name="blog" value="<?php echo $arrKol['blog'];?>" id="mediaBlog" class="col-sm-10 url form-control"></input>
													</div>
													<div class="form-group">
															<label class="control-label col-sm-2"><img src="<?php echo base_url()?>images/social/linkedin.png" title="Blog"/></label>
															<input style="margin-top: 5px;" type="text" name="linked_in" value="<?php echo $arrKol['linked_in'];?>" id="mediaLinkedIn" class="col-sm-10 url form-control"></input>
													</div>
													<div class="form-group">
															<label class="control-label col-sm-2"><img src="<?php echo base_url()?>images/social/facebook.png" title="Blog"/></label>
															<input style="margin-top: 5px;" type="text" name="facebook" value="<?php echo $arrKol['facebook'];?>" id="mediaFacebook" class="col-sm-10 url form-control"></input>
													</div>
													<div class="form-group">
															<label class="control-label col-sm-2"><img src="<?php echo base_url()?>images/social/twitter.png" title="Blog"/></label>
															<input style="margin-top: 5px;" type="text" name="twitter" value="<?php echo $arrKol['twitter'];?>" id="mediaTwitter" class="col-sm-10 url form-control"></input>
													</div>
													<div class="form-group">
															<label class="control-label col-sm-2"><img src="<?php echo base_url()?>images/social/myspace.png" title="Blog"/></label>
															<input style="margin-top: 5px;" type="text" name="myspace" value="<?php echo $arrKol['myspace'];?>" id="mediaMyspace" class="col-sm-10 url form-control"></input>
													</div>
													<div class="form-group">
															<label class="control-label col-sm-2"><img src="<?php echo base_url()?>images/social/youtube.png" title="Blog"/></label>
															<input style="margin-top: 5px;" type="text" name="you_tube" value="<?php echo $arrKol['you_tube'];?>" id="mediaYouTube" class="col-sm-10 url form-control"></input>
													</div>
													<div class="form-group">
															<input type="button" onClick="saveSocialMedia();" value="Save" name="submit" id="saveOnline" class="btn btn-primary col-sm-offset-4"/>
													</div>
											 	</div>
										 </form>
	                  				</div>
	                  			</div> 
	                  			</div>
	                  		</div>	
                  </div>
        <!-- End Tab panels --> 
               </div>     
        </div>
	</div>
</div>	