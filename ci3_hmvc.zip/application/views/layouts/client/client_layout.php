<!DOCTYPE html>
<html lang="en">
<head>
<title>Hmvc Application</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/jquery-ui-1.8.4.custom.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>css/client_layout.css">
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>bootstrap/js/popper.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>js/jquery-3.3.1.min.js" ></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>bootstrap/js/bootstrap.min.js"></script>
<script>	
var jqueryConflict = jQuery.noConflict();
</script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>jqgrid/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>jqgrid/jquery-ui-1.8.4.custom.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().ASSETS;?>js/custom_js/custom.js"></script>
</head>
<style>
#footerWrapper{
	border-top:1px solid;
}
.row_padding{
padding:10px 0px;
}
#primaryNavigationWrapper > div{
	padding:0px;
}
#primaryNavigationWrapper > div .navbar{
	margin-bottom:0px;
	border-radius:0px; 
}
#pageContentWrapper, #secondaryMenuWrapper, #rightSideBarWrapper{
	min-height: 500px;
}
.navbar-default {
  background-color: #f8f8f8;
  border-color: #e7e7e7;
  border-left: none;
  border-right: none;
}
.popover{
max-width:30%;
}
</style>
<script type="text/javascript">
	var chartColors=<?php echo CHART_COLOR_CODES ?>;
	var isiPad			= false;
	var base_url		= "<?php echo base_url()?>";
	var paginationValues = '<?php echo PAGINATION_VALUES;?>';
	var profileRequestConfirmMessage = 'Do you want to submit this request for a Full Profile to be built for this Contact?';
	var orgRequestConfirmMessage = 'Do you want to submit this request for a Profile to be built for this Organization?';
	$(document).ready(function(){
	    jqueryConflict('[data-toggle="tooltip"]').tooltip();   
	});
	function data_type_indicator(dataTypeIndicator){	
		$UserAdded=0;		
    	if(dataTypeIndicator == '' || dataTypeIndicator == 'Legacy'){
        	return '<a data-toggle="tooltip" data-placement="right" title="Legacy Data"><span class="badge">L</span></a>';
    	}else if(dataTypeIndicator == 'User Added'){
    		return '';
    	}else if(dataTypeIndicator == 'Aissel Analyst'){
        	return '<span class="badge" data-toggle="tooltip" data-placement="right" title="Added by: Aissel Analyst">A</span>';
    	}	
	}
	function hide_right_side_div(){
		if ($('#right_side_bar_div').css('display') == 'none') {
			$('#right_side_bar_div').show();
		}else{
			$('#right_side_bar_div').hide();
		}
	}
	function goBack() {
	    window.history.back();
	}
</script>
<body>
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-3">
				 <img src="<?php echo base_url().APPLICATION_IMAGES;?>logo/kolm_logo_beta.png" class="rounded float-left" alt="LOGO">
			</div>
			<div class="col-sm-5 col-sm-offset-1" style="margin-top: 20px;">
			 <form action="/action_page.php" class="form-inline">
			  <span class="glyphicon glyphicon-user"></span>
			    <div class="input-group">
			      <input type="text" class="form-control" placeholder="Search Contacts" name="search">
			      <div class="input-group-btn">
			        <button class="btn btn-default" type="submit" title="Advance search">
			        <i class="glyphicon glyphicon-search"></i></button>
			      </div>
			    </div>
			  </form>
			 </div>
			<div class="col-sm-3" style="margin-top: 20px;">
			<?php $this->load->view('layouts/client/settings',array('is_analyst_page'=>false));?>
			</div>
		</div>
		<div class="row" id="primaryNavigationWrapper">
			<div class="col-lg-12">
				<?php 
					  echo $this->load->view(CUSTOM_APP_CACHE.strtolower($this->session->userdata('client_name')).'/'.'navigations/primary_navigation',$data);
				?>
			</div>
		</div>
		<div class="row row_padding">
	 		<?php  if(isset($options_page) && $options_page!=''){
	 			echo $this->load->view($options_page,$options_data); ?>
	 		<?php }?>	
		</div>
		<div class="row">
			<div class="container-fluid">
			<table class="table no_border">
			        <tr>
				        <?php echo $this->load->view(CUSTOM_APP_CACHE.strtolower($this->session->userdata('client_name')).'/'.'navigations/secondary_navigation',$data);?>
			            <td>
				            <div id="pageContentWrapper">
				            	<?php echo $this->load->view($contentPage,$contentData);?>
				            </div>
			            </td>
			            <?php
			            if(isset($right_side_bar_page)){?>
				           <td class="col-sm-3" id="right_side_bar_div">
				            <?php  echo $this->load->view($right_side_bar_page,$right_side_bar_data); ?>	
				          </td>
			           <?php } ?> 
			        </tr>
			 </table>
			</div>
		</div>
		<div class="row" id="footerWrapper">
			<div class="col-sm-12">
			<footer>
				<div style="float:right;">
					<a href="<?php echo base_url()?>client_users/show_terms_page/terms" style="text-decoration: none;" class="privacy" target="new">Terms of Service</a> |  Copyright &copy;  <a style="text-decoration: none;" href="http://www.aissel.com" target="new">Aissel</a> Technologies | Powered by <a style="text-decoration: none;" href="https://www.aissel.com" target="new">Aissel</a>
				</div>
			</footer>			
			</div>
		</div>
	</div>	
<!-- --MOdal Box -->
<div id="modalBox" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"></h4>
      </div>
      <div class="modal-body"></div>
    </div>
  </div>
</div>
<div id="pop_over_content1"></div>
<div id="modalBoxContainer" class="microViewLoading">
	<div class="modalBoxContent"></div>
</div>
	<?php
		// 	Load all JS files from the queue		 
		foreach($this->config->item('js_files_to_load') as $key => $js_files){
			echo '<script type="text/javascript" src="'.base_url().ASSETS.''.$js_files.'.js"></script>';
		}
	?>