<?php
/**
 * Organization publications analyst applicaton page
 *
 * @author: Ramesh B
 * @created on: 30-03-2013
 * @package application.views.organizations
 */

	//To show row list in jqgrid
	function listRecordsPerPage($maxRecords=100,$increament=10){
		$rowList="";
		for($i=10;$i<=$maxRecords;$i+=$increament){
			$rowList.=$i.",";
		}
		$rowList=substr($rowList,0,-1);
		return $rowList;
	} 

?>	
<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/custom_overwrite.css" media="screen" />
	<script>
	var orgId = '<?php echo $arrOrganization['id']?>'; 
	
	$(document).ready(function(){
			$(".nav-tabs li a").click(function(){
				loadSelectedTab(this);
			});
			listUnvarifiedPublications();
		});
	
	$(function(){
		/*
		* To Move Selcted records into Verifeid publications list
		* @author Vinayak Malladad
		* @since 1.5.2
		* @created on 21/3/2011
		*/
		$("#verify").click(function(){						
			$("#delmodJQBlistPublicationResultSet").remove();
			var sr = jQuery("#JQBlistPublicationResultSet").getGridParam('selarrrow');	
			action = '<?php echo base_url();?>analysts/pubmeds/verified_publications';
			var data = {};
			data['pub_id' ] = sr;
			data['org_id' ] = orgId;
			
			jQuery.jgrid.del = {
				    caption: "verify",
				    msg: "Move selected record(s) into Verified List?",
				    bSubmit: "Verify",
				    bCancel: "Cancel",
				    processData: "Processing...",
				    top:400,
				    left:500,
				    url:action,
				    delData:data,
				    reloadAfterSubmit:true,
				    afterSubmit:function(response, postdata){				    		
			    		var success=true;
			    		var message="sucess";
			    		var new_id=2;
			    		jQuery("#JQBlistPublicationResultSet").trigger("reloadGrid");
			    		//jQuery("#JQBlistPublicationResultSet").setGridParam({page: 1});
			    		return [success,message,new_id];				    		
			    	}
				};
			
			jQuery("#JQBlistPublicationResultSet").delGridRow( sr, {} );
			//$(".dData").click();
			//$(".ui-icon-closethick").click();			
		});
		
		/*
		* To Move Selcted records into Deleted publications list
		* @author Vinayak Malladad
		* @since 1.5.2
		* @created on 21/3/2011
		*/
		$("#deleteUnVerifiedRecords").click(function(){
			//Get all the selected id's from jqGrid manually
			/*
			var pubValues = new Array();
			$("input.cbox:checked").each(function(){
				var idName=this.id;
				var mySplitResult = idName.split("_");
				
				pubValues.push(mySplitResult[2]);
			});
			*/
			$("#delmodJQBlistPublicationResultSet").remove();
			var delUrl='<?php echo base_url();?>pubmeds_org/delete_publications';
			var sr = jQuery("#JQBlistPublicationResultSet").getGridParam('selarrrow');
			var data={};
			data['pub_id']=sr;
			data['org_id' ] = orgId;
			
			jQuery.jgrid.del = {
				    caption: "Delete",
				    msg: "Move selected record(s) into Deleted List?",
				    bSubmit: "Delete",
				    bCancel: "Cancel",
				    processData: "Processing...",
				    url:delUrl,
				    delData:data,
				    reloadAfterSubmit:true,
				    afterSubmit:function(response, postdata){				    		
			    		var success=true;
			    		var message="sucess";
			    		var new_id=2;
			    		jQuery("#JQBlistPublicationResultSet").trigger("reloadGrid");
			    		//jQuery("#JQBlistPublicationResultSet").setGridParam({page: 1});
			    		return [success,message,new_id];				    		
			    	}
				};				
			jQuery("#JQBlistPublicationResultSet").delGridRow( sr, {} );
		});
		
		/*
		* To Move Selcted records into Unvarifeid publications list
		* @author Vinayak Malladad
		* @since 1.5.2
		* @created on 21/3/2011
		*/
		$("#unVerify").click(function(){
			$("#delmodJQBlistVarifiedPublicationResultSet").remove();
			var sr = jQuery("#JQBlistVarifiedPublicationResultSet").getGridParam('selarrrow');	
			action = '<?php echo base_url();?>/pubmeds_org/un_verified_publications';
			var data = {};
			data['pub_id' ] = sr;
			data['org_id' ] = orgId;
			
			jQuery.jgrid.del = {
				    caption: "Unverify ",
				    msg: "Move selected record(s) into Unverified List?",
				    bSubmit: "Unverify",
				    bCancel: "Cancel",
				    processData: "Processing...",
				    url:action,
				    delData:data,
				    reloadAfterSubmit:true,
				    afterSubmit:function(response, postdata){				    		
			    		var success=true;
			    		var message="sucess";
			    		var new_id=2;
			    		jQuery("#JQBlistPublicationResultSet").trigger("reloadGrid");
			    		//jQuery("#JQBlistPublicationResultSet").setGridParam({page: 1});
			    		return [success,message,new_id];				    		
			    	}
				};
			
			jQuery("#JQBlistVarifiedPublicationResultSet").delGridRow( sr, {} );
		});

		/*
		* To Move Selcted records into Deleted publications list
		* @author Vinayak Malladad
		* @since 1.5.2
		* @created on 21/3/2011
		*/
		$("#deleteVerifiedRecords").click(function(){
			$("#delmodJQBlistVarifiedPublicationResultSet").remove();
			var delUrl='<?php echo base_url();?>pubmeds_org/delete_publications';
			var sr = jQuery("#JQBlistVarifiedPublicationResultSet").getGridParam('selarrrow');	
			var data={};
			data['pub_id']=sr;
			data['org_id' ] = orgId;
			jQuery.jgrid.del = {
				    caption: "Delete",
				    msg: "Move selected record(s) into Deleted List?",
				    bSubmit: "Delete",
				    bCancel: "Cancel",
				    processData: "Processing...",
				    url:delUrl,
				    delData:data,
				    reloadAfterSubmit:true,
				    afterSubmit:function(response, postdata){				    		
			    		var success=true;
			    		var message="sucess";
			    		var new_id=2;
			    		jQuery("#JQBlistPublicationResultSet").trigger("reloadGrid");
			    		//jQuery("#JQBlistPublicationResultSet").setGridParam({page: 1});
			    		return [success,message,new_id];				    		
			    	}
				};
			
			jQuery("#JQBlistVarifiedPublicationResultSet").delGridRow( sr, {} );
		});

		/*
		* To Move  deleted records into Verified publications list
		* @author Vinayak Malladad
		* @since 1.5.2
		* @created on 21/3/2011
		*/
		$("#deleteToVerify").click(function(){
			$("#delmodJQBlistDeletedPublicationResultSet").remove();
			var delUrl='<?php echo base_url();?>pubmeds_org/verified_publications';
			var sr = jQuery("#JQBlistDeletedPublicationResultSet").getGridParam('selarrrow');	
			var data={};
			data['pub_id']=sr;
			data['org_id' ] = orgId;
			jQuery.jgrid.del = {
				    caption: "Verify",
				    msg: "Move selected record(s) into Verified List?",
				    bSubmit: "Verify",
				    bCancel: "Cancel",
				    processData: "Processing...",
				    url:delUrl,
				    delData:data,
				    reloadAfterSubmit:true,
				    afterSubmit:function(response, postdata){				    		
			    		var success=true;
			    		var message="sucess";
			    		var new_id=2;
			    		jQuery("#JQBlistPublicationResultSet").trigger("reloadGrid");
			    		//jQuery("#JQBlistPublicationResultSet").setGridParam({page: 1});
			    		return [success,message,new_id];				    		
			    	}
				};

			jQuery("#JQBlistDeletedPublicationResultSet").delGridRow( sr, {} );
		});

		/*
		* To Move  deleted records into Verify publications list
		* @author Vinayak Malladad
		* @since 1.5.2
		* @created on 21/3/2011
		*/
		$("#deleteToUnVerify").click(function(){
			$("#delmodJQBlistDeletedPublicationResultSet").remove();
			var delUrl='<?php echo base_url();?>pubmeds_org/un_verified_publications';
			var sr = jQuery("#JQBlistDeletedPublicationResultSet").getGridParam('selarrrow');	
			var data={};
			data['pub_id']=sr;
			data['org_id' ] = orgId;
			jQuery.jgrid.del = {
				    caption: "Unverify",
				    msg: "Move selected record(s) into Unverified List?",
				    bSubmit: "Unverify",
				    bCancel: "Cancel",
				    processData: "Processing...",
				    url:delUrl,
				    delData:data,
				    reloadAfterSubmit:true,
				    afterSubmit:function(response, postdata){				    		
			    		var success=true;
			    		var message="sucess";
			    		var new_id=2;
			    		jQuery("#JQBlistPublicationResultSet").trigger("reloadGrid");
			    		//jQuery("#JQBlistPublicationResultSet").setGridParam({page: 1});
			    		return [success,message,new_id];				    		
			    	}
				};
			
			jQuery("#JQBlistDeletedPublicationResultSet").delGridRow( sr, {} );
		});
	});	
	/* Grid Functions */
	/*
	* Listing of Un Verified Publications
	* @author Vinayak Malladad
	* @since 1.5.2
	* @created on 21/3/2011
	*/
	function listUnvarifiedPublications(){
		/*
		*jqgrid for Education table
		*/
		jQuery("#JQBlistPublicationResultSet").jqGrid({
		   	url:'<?php echo base_url();?>analysts/pubmeds/list_publication_details_analyst/unVerified/'+orgId,
			datatype: "json",
		   	colNames:['Id','','','PMID','Journal Name','Article Title', 'Affiliation','Date','Authors','Action'],
		   	colModel:[
				{name:'id',index:'id', hidden:true},
				{name:'pub_id',index:'pub_id', hidden:true},
				{name:'is_manual',index:'is_manual', hidden:true},
		   		{name:'pmid',index:'pmid', width:100,editable:true},
		   		{name:'journal_name',index:'journal_name',width:250,editable:true},
		   		{name:'article_title',index:'article_title',width:300,editable:true},
		   		{name:'affiliation',index:'affiliation',width:300,editable:true},
		   		{name:'date',index:'date',width:100,editable:true},
		   		{name:'authors',index:'authors',width:200,editable:true},
		   		{name:'act',resizable:true,search:false,width:80 <?php if($isClientView) echo ' ,hidden:true';?>}		   			
		   	],
		   	rowNum:10,
		   	rowList:paginationValues,
		   	rownumbers: true,
		   	sortable: true, 
		   	autowidth: true, 
		   	loadonce:true,
		   	multiselect: true,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",	
		   	cellEdit: false, 
		   	cellsubmit: 'clientArray', 	   
		   	pager: '#listlistPublicationPage',
		   	mtype: "POST",
		   	sortname: 'name',
		    viewrecords: true,
		    sortorder: "desc",
		    gridComplete: function(){						     
			    var ids = jQuery("#JQBlistPublicationResultSet").jqGrid('getDataIDs'); 
			    	for(var i=0;i < ids.length;i++){ 
				    	var cl = ids[i];
				    	var ret = jQuery("#JQBlistPublicationResultSet").jqGrid('getRowData', cl);
				    	var id1= ret.pub_id;
				    	val = ret.is_manual;	
				    	if(val == 0){								    	
				    		be = "<label onclick=\"deletePublication('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";	
				    	}else{
				    		be = "<label onclick=\"deletePublication('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";	
				    		be += "&nbsp; | &nbsp;";	
				    		be += "<label onclick=\"editPublication('"+id1+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png' class='editIcon'></label>";
				    	}		    	
				    	jQuery("#JQBlistPublicationResultSet").jqGrid('setRowData',ids[i],{act:be}); 
				    	} 
			    	jQuery("#JQBlistPublicationResultSet").jqGrid('navGrid','hideCol',"id"); 
			    	}, 
			loadComplete: function() {
			    	    $("option[value=100000000]").text('All');
			    	},
			    	
			    							    	
		    jsonReader: { repeatitems : false, id: "0" }, 
		    editurl:"#"		    
		});
	
		//Toolbar search bar below the Table Headers
		jQuery("#JQBlistPublicationResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
		//Toolbar search bar above the Table Headers
		//jQuery("#t_JQBlistPublicationResultSet").height(25).jqGrid('filterGrid',"JQBlistPublicationResultSet",{gridModel:true,gridToolbar:true});
		
		//Toggle Toolbar Search 
		jQuery("#JQBlistPublicationResultSet").jqGrid('navButtonAdd',"#listlistPublicationPage",{
			caption:"Search",title:"Toggle Search",
			onClickButton:function(){ 			
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}							
			} 
		}); 	
		jQuery("#JQBlistPublicationResultSet").jqGrid('gridResize',{minWidth:800,maxWidth:800,minHeight:80, maxHeight:350});
	}
	
	
	/*
	* Listing of  Verified Publications
	* @author Vinayak Malladad
	* @since 1.5.2
	* @created on 21/3/2011
	*/
	function listVerifiedPublications(){
		/*
		*jqgrid for Education table
		*/
		jQuery("#JQBlistVarifiedPublicationResultSet").jqGrid({
		   	url:'<?php echo base_url();?>analysts/pubmeds/list_publication_details_analyst/verified/'+orgId,
			datatype: "json",
		   	colNames:['Id','','','PMID','Journal Name','Article Title', 'Affiliation','Date','Authors','Action'],
		   	colModel:[
				{name:'id',index:'id', hidden:true},
				{name:'pub_id',index:'pub_id', hidden:true},
				{name:'is_manual',index:'is_manual', hidden:true},
		   		{name:'pmid',index:'pmid', width:100,editable:true},
		   		{name:'journal_name',index:'journal_name',width:250,editable:true},
		   		{name:'article_title',index:'article_title',width:300,editable:true},
		   		{name:'affiliation',index:'affiliation',width:300,editable:true},
		   		{name:'date',index:'date',width:100,editable:true},
		   		{name:'authors',index:'authors',width:200,editable:true},
		   		{name:'act',resizable:true,search:false,width:80 <?php if($isClientView) echo ' ,hidden:true';?>}		   			
		   	],
		   	rowNum:10,
		   	rowList:paginationValues,
		   	rownumbers: true,
		   	autowidth: true, 
		   	loadonce:true,
		   	multiselect: true,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",		   
		   	pager: '#listVariedPublicationPage',
		   	mtype: "POST",
		   	sortname: 'name',
		    viewrecords: true,
		    sortorder: "desc",
		    gridComplete: function(){						     
			    var ids = jQuery("#JQBlistVarifiedPublicationResultSet").jqGrid('getDataIDs'); 
			    
			    	for(var i=0;i < ids.length;i++){ 
				    	var cl = ids[i];	
				    	var ret = jQuery("#JQBlistVarifiedPublicationResultSet").jqGrid('getRowData', cl);
						var id1= ret.pub_id;
				    	val = ret.is_manual;	
				    	if(val == 0){								    	
				    		be = "<label onclick=\"deletePublication('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";	
				    	}else{
				    		be = "<label onclick=\"deletePublication('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png'class='deleteIcon'></label>";	
				    		be += "&nbsp; | &nbsp;";	
				    		be += "<label onclick=\"editPublication('"+id1+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png' class='editIcon'></label>";
				    	}							    	
				    	jQuery("#JQBlistVarifiedPublicationResultSet").jqGrid('setRowData',ids[i],{act:be}); 
				    	} 
			    	jQuery("#JQBlistVarifiedPublicationResultSet").jqGrid('navGrid','hideCol',"id"); 
			    	}, 
			loadComplete: function() {
			    	    $("option[value=100000000]").text('All');
			    	},
			    							    	
		    jsonReader: { repeatitems : false, id: "0" }, 
		    editurl:"#"		    
		});


		//Toolbar search bar below the Table Headers
		jQuery("#JQBlistVarifiedPublicationResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
		//Toolbar search bar above the Table Headers
		//jQuery("#t_JQBlistPublicationResultSet").height(25).jqGrid('filterGrid',"JQBlistPublicationResultSet",{gridModel:true,gridToolbar:true});
		
		//Toggle Toolbar Search 
		jQuery("#JQBlistVarifiedPublicationResultSet").jqGrid('navButtonAdd',"#listVariedPublicationPage",{
			caption:"Search",title:"Toggle Search",
			onClickButton:function(){ 			
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}							
			} 
		}); 	

		jQuery("#JQBlistVarifiedPublicationResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000});
	}
	
	/*
	* Listing of Deleted Publications
	* @author Vinayak Malladad
	* @since 1.5.2
	* @created on 21/3/2011
	*/
	function listDeletedPublications(){
		/*
		*jqgrid for Education table
		*/
		jQuery("#JQBlistDeletedPublicationResultSet").jqGrid({
		   	url:'<?php echo base_url();?>analysts/pubmeds/list_publication_details_analyst/deleted/'+orgId,
			datatype: "json",
		   	colNames:['Id','','','PMID','Journal Name','Article Title', 'Affiliation','Date','Authors','Action'],
		   	colModel:[
				{name:'id',index:'id', hidden:true},
				{name:'pub_id',index:'pub_id', hidden:true},
				{name:'is_manual',index:'is_manual', hidden:true},
		   		{name:'pmid',index:'pmid', width:100,editable:true},
		   		{name:'journal_name',index:'journal_name',width:250,editable:true},
		   		{name:'article_title',index:'article_title',width:300,editable:true},
		   		{name:'affiliation',index:'affiliation',width:300,editable:true},
		   		{name:'date',index:'date',width:100,editable:true},
		   		{name:'authors',index:'authors',width:200,editable:true},
		   		{name:'act',resizable:true,search:false,width:80 <?php if($isClientView) echo ' ,hidden:true';?>}		   			
		   	],
		   	rowNum:10,
		   	rowList:paginationValues,
		   	rownumbers: true,
		   	autowidth: true, 
		   	loadonce:true,
		   	multiselect: true,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",		   
		   	pager: '#listDeletedPublicationPage',
		   	mtype: "POST",
		   	sortname: 'name',
		    viewrecords: true,
		    sortorder: "desc",
		    gridComplete: function(){						     
			    var ids = jQuery("#JQBlistDeletedPublicationResultSet").jqGrid('getDataIDs'); 
			    	for(var i=0;i < ids.length;i++){ 
				    	var cl = ids[i];
				    	var ret = jQuery("#JQBlistDeletedPublicationResultSet").jqGrid('getRowData', cl);
				    	var id1= ret.pub_id;
				    	val = ret.is_manual;	
				    	if(val == 0){
				    		be = "<label onclick=\"deletePublication('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";				    	
				    	}else{
				    		be = "<label onclick=\"deletePublication('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";	
				    		be += "&nbsp; | &nbsp;";	
				    		be += "<label onclick=\"editPublication('"+id1+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png' class='editIcon'></label>";			    			    	
				    	}						    	
				    	jQuery("#JQBlistDeletedPublicationResultSet").jqGrid('setRowData',ids[i],{act:be}); 
				    	} 
			    	jQuery("#JQBlistDeletedPublicationResultSet").jqGrid('navGrid','hideCol',"id"); 
			    	}, 
			loadComplete: function() {
			    	    $("option[value=100000000]").text('All');
			    	},
			    							    	
		    jsonReader: { repeatitems : false, id: "0" }, 
		    editurl:"#"		    
		});
		var delUrl='<?php echo base_url();?>pubmeds_org/delete_publications';
	
		jQuery("#JQBlistDeletedPublicationResultSet").jqGrid('navGrid','#listDeletedPublicationPage',{edit:false,add:false,search:false,refresh:false}, {},{}, {reloadAfterSubmit:false, url:delUrl, onclickSubmit : function(eparams) {
		    var retarr = {};					  
		    var sr = jQuery("#JQBlistDeletedPublicationResultSet").getGridParam('selarrrow');				  
		        retarr = {slr:sr};					   
		   		 return retarr;
			}
		}, {multipleSearch:true} );
		
		/*jQuery("#JQBlistPublicationResultSet").jqGrid('navGrid',
														'#listlistPublicationPage',
														{del:false,add:false,edit:false},
														{},{},{},
														{multipleSearch:true});
		*/

		//Toolbar search bar below the Table Headers
		jQuery("#JQBlistDeletedPublicationResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
		//Toolbar search bar above the Table Headers
		//jQuery("#t_JQBlistPublicationResultSet").height(25).jqGrid('filterGrid',"JQBlistPublicationResultSet",{gridModel:true,gridToolbar:true});
		
		//Toggle Toolbar Search 
		jQuery("#JQBlistDeletedPublicationResultSet").jqGrid('navButtonAdd',"#listDeletedPublicationPage",{
			caption:"Search",title:"Toggle Search",
			onClickButton:function(){ 			
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}							
			} 
		}); 	

		jQuery("#JQBlistDeletedPublicationResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000});
	}	

		/*
		* To load Seleted tab when clicked
		* @author Vinayak Malladad
		* @since 1.5.2
		* @created on 21/3/2011
		*/
		function loadSelectedTab(selected){
			$("#JQBlistPublicationResultSet").setGridParam({loadonce:false});
			var select= $(selected).attr('aria-controls');
			switch(select){
				case 'unverified':	$("#genericGridContainer").html("");
									$("#genericGridContainer").html('<table id="JQBlistPublicationResultSet"></table><div id="listlistPublicationPage"></div>');
									listUnvarifiedPublications();
							break;
							
				case 'verified': 	$("#genericGridContainer").html("");
									$("#genericGridContainer").html('<table id="JQBlistVarifiedPublicationResultSet"></table><div id="listVariedPublicationPage"></div>');
									listVerifiedPublications();
							break;
				
				case 'deleted':		$("#genericGridContainer").html("");
									$("#genericGridContainer").html('<table id="JQBlistDeletedPublicationResultSet"></table><div id="listDeletedPublicationPage"></div>');
									listDeletedPublications();
							break;			
				default :	listUnvarifiedPublications();
	
			}
			$("#JQBlistPublicationResultSet").setGridParam({loadonce:true});
		}

		/**
		* Delete the 'Education Details'
		*/
		function deletePublication(id){								
			var formAction = '<?php echo base_url();?>pubmeds_org/delete_publication/'+id;						
			jQuery("#JQBlistPublicationResultSet").jqGrid('delGridRow',id,{reloadAfterSubmit:false,url:formAction});
				  
		}	
		function loadUnprocessedCoAuthPage(){
			$('#unProceAuth').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(<?php echo base_url()?>images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
			$("#unProceAuth").load("<?php echo base_url()?>pubmeds_org/get_unprocessed_co_authors_page/"+orgId,{},
					function(){	$('#unProceAuth').unblock(); }
			);
		}

		function loadProcessedCoAuthPage(){
			$('#proceAuth').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(<?php echo base_url()?>images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
			$("#proceAuth").load("<?php echo base_url()?>pubmeds_org/get_processed_co_authors_page/"+orgId,{},
					function(){	$('#proceAuth').unblock(); }
			);
		}

		//get selected coAuthors and AliasId and send ajax request to associate
		function associateCoAuthors(){
			var coAuthsIds=$("#unproceCoAuthsList").val();
			var aliasCoAuthId=$("#aliasCoAuthsList").val();
			var data={};
			data['co_auths_ids']=coAuthsIds;
			data['alias_id']=aliasCoAuthId;
			$('#unProceAuth').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(<?php echo base_url()?>images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
			$.ajax({
				url:'<?php echo base_url();?>pubmeds_org/associate_co_authors/'+orgId,
				data:data,
				type:'post',
				datType:'json',
				success:function(returnData){
					//loadUnprocessedCoAuthPage();
					//remove the processed co authors from the both list
					$("#unproceCoAuthsList option:selected").each(function(){
						$(this).remove();
					 }); 
					for(var i=0; i<coAuthsIds.length; i++) {
						var value = coAuthsIds[i];
						$("#aliasCoAuths option").each(function(){
							if(this.value==value){
								if(this.value != aliasCoAuthId)
									$(this).remove();
							}
						}); 
					}
					$('#unProceAuth').unblock();
				}
			});
		}

		//disassociate the co author from associated co author
		function disassociateCoAuthor(coAuthorId){
			var ele=document.getElementById("proceCoAuthTable");
			var tabHieght=ele.clientHeight;
			var tabWidth=ele.clientWidth;
			var data={};
			data['co_author_id']=coAuthorId;
			jConfirm("Are you sure you want to disassociate?","Please confirm",function(r){
					if(r){
						$('#proceAuth').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(<?php echo base_url()?>images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
						$.ajax({
							url:'<?php echo base_url();?>pubmeds_org/disassociate_co_author/'+orgId,
							data:data,
							type:'post',
							datType:'json',
							success:function(returnData){
								if(returnData==1){
									$("#coAuth"+coAuthorId).remove();
								}
								$('#proceAuth').unblock();
							}
						});
						}else{
								return false;
							}
				});
		}

		function addPublication(){
			$("#modal-box").addClass("modal-lg");
			$(".modal-body").html("<div class='ctmicroViewLoading'>Loading...</div>");
			$(".modal-title").html("Add Publication");
			$('.modal-body').load('<?php echo base_url()?>analysts/pubmeds/add_org_publication/'+orgId);	
		}
		function editPublication(id){
			$("#publicationAddProfileContent").val("");
			$(".profileContent").val("");
			$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
			$("#publicationAddContainer").dialog("open");
			$("#publicationAddProfileContent").load('<?php echo base_url()?>pubmeds_org/edit_publication_manual/'+id+'/'+orgId);
			return false;	
		}
	
		function crawlPMIDs(){
			$(".modal-body").html("<div class='ctmicroViewLoading'>Loading...</div>");
			$(".modal-title").html("Add PMIDs for Crawling");
			$(".modal-body").html("<div><div class='form-group'><label>Enter PMID(s):</label><textarea cols='50' rows='3' id='pmids' class='form-control'></textarea><span class='pull-right'>comma(,) separated</span></div> <button onclick='displayAndProcessPMIDs();' class=\"btn btn-primary\"><span class='glyphicon glyphicon-save'></span> Save and Crawl</button></div>");
			return false;	
		}
	
		function displayAndProcessPMIDs(){
			var textareaPmids = $("#pmids").val();
			var arrPmids = textareaPmids.split(",");
			var i=0;
			var batchSize = 10;
			var batchCounter = 0;
			var batchNumber = 1;
			var batchIds = new Array();
			var pmidsLength = arrPmids.length;
			$("#publicationAddProfileContent").html("<div id='pmidsList'> </div>");
			for(i=0; i<pmidsLength; i++){
				batchIds.push(arrPmids[i]);
				batchCounter++;
				if(batchCounter == 10){
					batchCounter = 0;
					displayPmids(batchIds,batchNumber);
					batchNumber++;
					batchIds = new Array();
				}
			}
			if(batchCounter < 10){
				displayPmids(batchIds,batchNumber);
			}
	
			processPMIDs();
		}
	
		function displayPmids(batchIds,batchNumber){
			$("#pmidsList").append("<div id='batch"+batchNumber+"' class='pmidBatch pendingBatch'></div>");
			$('#batch'+batchNumber).append("<ul></ul>");
			for(i=0; i<batchIds.length; i++){
				var pmidData = '<li id="'+batchIds[i]+'"> <span class="pmidholder">'+batchIds[i]+'</span> </li>';
				$('#batch'+batchNumber+" ul").append(pmidData);
			}
		}
	
		function processPMIDs(){
			var data = {};
			var batchIds = new Array();
			$(".pendingBatch:first .pmidholder").each(function(){
				batchIds.push($(this).html());
			});
	
			if(batchIds.length > 0){
				$(".pendingBatch:first").removeClass("pendingBatch").addClass("currentBatch");
				data['pmids'] =  batchIds;
				$.ajax({
					url:'<?php echo base_url()?>pubmeds_org/process_pmids/'+orgId,
					data:data,
					type:'post',
					dataType:'json',
					success:function(returnData){
						if(returnData.status == true){
							$(".currentBatch").removeClass("currentBatch").addClass("completedBatch");
							processPMIDs();
						}else{
							$(".currentBatch").addClass("errorBatch");
						}
					},
					error:function(){
						$(".currentBatch").addClass("errorBatch");
					}
				});
			}
		}
	
		function loadNameCombinations(){
			//$('#nameCombinations').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(<?php echo base_url()?>images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
			$("#nameCombinations").load("<?php echo base_url()?>pubmeds_org/get_name_combinations/"+orgId
					//function(){	$('#nameCombinations').unblock(); }
			);
		}
	</script>
	<!-- Start of Html Content -->
<?php $this->load->view('kols/secondary_menu'); ?>
<div class="main-content">
	<div class="row">
		<div class="col-md-12">
        <!-- Start Nav tabs -->
               <ul class="nav nav-tabs" role="tablist">
                   <li role="Details" class="active"><a href="#unverified" aria-controls="unverified" role="tab" data-toggle="tab">Unverified</a></li>
                  	<li role="Details"><a href="#verified" aria-controls="verified" role="tab" data-toggle="tab">Verified</a></li>
                  	<li role="Details"><a href="#deleted" aria-controls="deleted" role="tab" data-toggle="tab">Deleted</a></li>          
               </ul>
		<!-- End Nav tabs -->
               <div class="tab-content">
	               <div>
	               	<h5 style="font-weight:bold;color:#656565;">Profile of : <?php echo $arrKol['first_name'].' '.$arrKol['middle_name'].' '.$arrKol['last_name']; ?></h5>
	               </div>
	                <div id="publicationAddLink" class="pull-right">
					<label onclick="crawlPMIDs();" style="float:left;" data-toggle="modal" data-target="#analystModelBox"><img height="26" src="http://localhost/demo/images/bullet_add.png" border="0">Add PMIDs</label>
					<label onclick="addPublication(250);" style="padding-left:5px;"  data-toggle="modal" data-target="#analystModelBox"><img height="26" src="http://localhost/demo/images/bullet_add.png" border="0">Add New Publication</label>
				</div>
        <!-- Start Tab panels -->
	                  <div role="tabpanel" class="tab-pane active" id="unverified">
	                  			<button id="verify" class="btn btn-default"><span class='icon green glyphicon glyphicon-eye-open'></span> Verify</button> <button id="deleteUnVerifiedRecords" class="btn btn-default"><span class='icon red glyphicon glyphicon-trash'></span> Delete</button>		  		
	                  </div>
	                  <div role="tabpanel" class="tab-pane" id="verified">
	                  			<button id="unVerify" class="btn btn-default"><span class='icon red glyphicon glyphicon-eye-close'></span> Unverify</button>  <button id="deleteVerifiedRecords" class="btn btn-default"><span class='icon red glyphicon glyphicon-trash'></span> Delete</button>	
	                  </div>
	                  <div role="tabpanel" class="tab-pane" id="deleted">
	                  			<button id="deleteToVerify" class="btn btn-default"><span class='icon green glyphicon glyphicon-eye-open'></span>  Verify</button>  <button id="deleteToUnVerify" class="btn btn-default"><span class='icon red glyphicon glyphicon-eye-close'></span>  Unverify</button>	
	                  </div>
	        <!-- End Tab panels --> 
         <!-- Generic Grid Panel to load all four respective grid content --> 
			<div class="col-md-12 gridData">
                  <div class="gridWrapper" id="genericGridContainer">
					<table id="JQBlistPublicationResultSet"></table>
					<div id="listlistPublicationPage"></div>
				  </div>
            </div>
		<!-- End of Grid Panel -->     
               </div>     
        </div>
	</div>
</div>
<!-- End of Html Content -->
<div>
</div>	  