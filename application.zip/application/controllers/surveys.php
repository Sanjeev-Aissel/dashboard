<?php
/*
 * Controller for Survey Mapping
 *
 * @Author		: Laxman K
 * @since 		: KOLM v5.5 Otsuka 1.0.11
 * Created on	: 14-03-2013
 *
 */
class Surveys extends Controller{
	private $loggedUserId	= null;
	private $isUserAllowedForSalesReport	= false;
	private $isUserAllowedForHCPReport	= false;
	private $arrSurveyTypes	= array(
									1=>'Local',
									2=>'National'/*,
									3=>'Global'*/
								);
	// constructor to initialize the data
	function Surveys(){
		parent::Controller();
		$this->load->model('survey');
		$this->load->model('country_helper');
		$this->load->model('kol');
		$this->load->model('common_helpers');
		$this->loggedUserId = $this->session->userdata('user_id');
		$clientId		= $this->session->userdata('client_id');
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->isUserAllowedForSalesReport	= $this->survey->isLoggedInUserExistsInGroup(SALES_REPORT_GROUP_NAME);
			$this->isUserAllowedForHCPReport	= $this->survey->isLoggedInUserExistsInGroup(HCP_REPORT_GROUP_NAME);
		}else{
			$this->isUserAllowedForSalesReport	= true;
			$this->isUserAllowedForHCPReport	= true;
		}
		$this->session->set_userdata('is_allowed_for_sales_report',$this->isUserAllowedForSalesReport);
		$this->session->set_userdata('is_allowed_for_hcp_report',$this->isUserAllowedForHCPReport);
	}
	
	function index(){
		$surveyDefaultURL	= base_url().'surveys/report'; 
		if(IS_IPAD_REQUEST){
			$surveyDefaultURL	= base_url().'surveys/report';
		}
		redirect($surveyDefaultURL);
	}
	
	/*
	 * To populate selected KOL Information in survey form
	 */
	function getKolData(){
		$addressId = $this->input->post('addressId');
		$intKolId	= $this->input->post('kol_id');
		ob_start('ob_gzhandler');
		$this->load->model('kol');
		echo json_encode($this->survey->kolDetails($intKolId,false,$addressId));
	}
	
	/*
	 * To display survey form where user can answer 
	 * @param $id	- survey id
	 */
	function survey_form($id,$returnQuestions=false){
		
		if($this->session->userdata("is_from_kol") == 1){
			
			$this->session->unset_userdata("is_from_kol");
			$kolId = $this->session->userdata("kolId");
			$arrKol = $this->kol->editKol($kolId);
			$arrIcont = $this->survey->getIcontactByNpiNumOrByName($arrKol);
			
			if($arrIcont){
				$arrRespondent = $this->survey->getRespondents($id,$arrIcont["kol_id"]);
				if(count($arrRespondent) > 0){
					redirect(base_url()."/surveys/edit_survey_data/".$id."/".$arrIcont["kol_id"]);
				}else{
					$arrData				= array();
					$arrSurveyData			= array();
					$arrSurveyData			= $this->survey->getActiveSurveyQuestions($id);
					$arrData['arrRespondent'][0]	= $this->survey->getRespondentsById($arrIcont["id"]);
					$arrData['arrRespondent'][0]['from_kol'] = true;
					$arrData['arrTypes']		= $this->arrSurveyTypes;
					$arrData['arrSurveys']		= $arrSurveyData['arrQuestionData'];
					$arrData['surveyId']		= $arrSurveyData['surveyId'];
					$arrData['arrSurveyData']['name']	= $arrSurveyData['surveyName'];
					$arrData['showReports'] = true;
					$arrData['contentPage']	= 'surveys/survey_form';
					//Add Log activity
					$arrLogDetails = array(
							'type' => VIEW_RECORD,
							'description' => "Visited survey form where user can answer Page",
							'status' => STATUS_SUCCESS,
							'kols_or_org_type' => 'Kol',
							'kols_or_org_id' => $kolId,
							'transaction_name' => "View survey form"
					);
					$this->config->set_item('log_details', $arrLogDetails);
					$this->load->view('layouts/client_view', $arrData);
				}
			}else{
				$arr = array();
				$arr['survey_id'] 		= $surveyId;
				$arr['first_name'] 		= $arrKol['first_name'];
				$arr['middle_name'] 	= $arrKol['middle_name'];
				$arr['last_name'] 		= $arrKol['last_name'];
				$arr['country'] 		= $this->survey->getCountryNameById($arrKol['country_id']);
				$arr['state'] 			= $this->survey->getStateNameById($arrKol['state_id']);
				$arr['city'] 			= $this->survey->getCityNameById($arrKol['city_id']);
				$arr['postal_code'] 	= $arrKol['postal_code'];
				$arr['organization'] 	= $this->survey->getOrgNameByOrgId($arrKol['org_id']);
				$arr['specialty'] 		= $this->survey->getSpecialtyById($arrKol['specialty']);
				$arrInsertedData = $this->survey->saveStagingContact($arr);
				$arrData = array();
				$arrData['id'] 						= $arrInsertedData['id'];
				$arrData['created_by'] 				= $this->session->userdata("user_id");
				$arrData['respondent'] 				= $arrInsertedData['name'];
				$arrData['respondent_country'] 		= $arr['country'];
				$arrData['respondent_state'] 		= $arr['state'];
				$arrData['respondent_city'] 		= $arr['city'];
				$arrData['respondent_postal'] 		= $arrKol['postal_code'];
				$arrData['isStaging'] 				= true;
				$arrData['arrRespondent'][]= $arrData;
				$arrSurveyData			= array();
				$arrSurveyData			= $this->survey->getActiveSurveyQuestions($id);
				$arrData['arrTypes']		= $this->arrSurveyTypes;
				$arrData['arrSurveys']		= $arrSurveyData['arrQuestionData'];
				$arrData['surveyId']		= $arrSurveyData['surveyId'];
				$arrData['arrSurveyData']['name']	= $arrSurveyData['surveyName'];
				$arrData['showReports'] = true;
				$arrData['contentPage']	= 'surveys/survey_form';
				//Add Log activity
				$arrLogDetails = array(
						'type' => VIEW_RECORD,
						'description' => "Visited survey form where user can answer Page",
						'status' => STATUS_SUCCESS,
						'kols_or_org_type' => 'Kol',
						'kols_or_org_id' => $kolId,
						'transaction_name' => "View survey form"
				);
				$this->config->set_item('log_details', $arrLogDetails);
				$this->load->view('layouts/client_view', $arrData);
			}
		}else{
			$arrData				= array();
			$arrSurveyData			= array();
			$arrSurveyData			= $this->survey->getActiveSurveyQuestions($id);
			
			$arrData['arrTypes']		= $this->arrSurveyTypes;
			$arrData['arrSurveys']		= $arrSurveyData['arrQuestionData'];
			$arrData['surveyId']		= $arrSurveyData['surveyId'];
			$arrData['arrSurveyData']['name']	= $arrSurveyData['surveyName'];
			$arrData['showReports'] = true;
			if($returnQuestions){
				$this->load->view('surveys/survey_questions', $arrData);
			}else{
				$arrData['contentPage']	= 'surveys/survey_form';
				//Add Log activity
				$arrLogDetails = array(
						'type' => VIEW_RECORD,
						'description' => "Visited survey form where user can answer Page",
						'status' => STATUS_SUCCESS,
						'kols_or_org_type' => 'Kol',
						'kols_or_org_id' => $kolId,
						'transaction_name' => "View survey form"
				);
				$this->config->set_item('log_details', $arrLogDetails);
				$this->load->view('layouts/client_view', $arrData);
			}
		}
	}
	
	/*
	 * To save survey answers
	 */
	function save_answers($isSubmitted=1,$redirectToKolId=0){
//		pr($_POST);
		$arrTerritoryData        = $this->survey->getUserTerritory($this->session->userdata('user_id'));
        $territoryId    = $arrTerritoryData['id'];
        $territory    = $arrTerritoryData['territory'];
		if($this->input->post('is_stging') != 1){
			$missingInfluencerIds = $this->input->post("missing_influencer");
			$preparedStatements	= '';
			$respondentId	= 0;
			$separator		= '';
			$createdOn		= date("Y-m-d H:i:s");
			$isExists			= $this->input->post('update');
			$userId			= $this->input->post('created_by');
			if($isExists==false || empty($userId)){
				$userId		= $this->session->userdata('user_id');
			}
			$activeSurveyId	= $this->input->post('active_survey_id');
			$arrQuestionIds	= explode(',',$this->input->post('surveyIds'));
			$surveyRespondentId	= $this->input->post('survey_respondent_id');
			$respondentAndAdressid		= $this->input->post('respondent_id');
			$respondents = explode('-',$respondentAndAdressid);
			
			$respondentId = $respondents[0];
			$repsAdressId = $respondents[1];
			$respMDMNumber = $this->survey->getMDMByAddressId($repsAdressId);
			$respKolId = 0;
			if($respMDMNumber != '' && $respMDMNumber != null)
				$respKolId = $this->kol->getKolIdByMDM($respMDMNumber);
			$updated = true;
			//pr()
			$preparedStatements	= "insert into survey_answers(question_id,nominee_id,respondent_id,created_by,created_on,survey_id,is_submitted,nom_address_id,resp_address_id,territory,territory_id,zeroInfluencers,nom_kol_id,resp_kol_id,is_iprofile) values ";
			foreach($arrQuestionIds as $key=>$questionId){
				$count	= 0;
				$noOfAnswers	= $this->input->post('count_'.$questionId);
				$arrKolIds		= $this->input->post('kol_id_'.$questionId);
				//$arrKolNames	= $this->input->post('kol_name_'.$questionId);
				foreach($arrKolIds as $index=>$id){
					if($noOfAnswers>$count){
						$count++;
						$nomineeId	= 0;
						if(empty($arrKolIds[$index])){
							$arrKolIds[$index]	= 0;
						}
					
						//$nomineeId = $id;
						$nominessAndAdress = explode('-',$id);
						if(count($nominessAndAdress)==2){
							$nomineeId = $nominessAndAdress[0];
							$nmineeAdressId = $nominessAndAdress[1];
							$nomMDMNumber = $this->survey->getMDMByAddressId($nmineeAdressId);
							$nomKolId = 0;
							if($nomMDMNumber != '' && $nomMDMNumber != null)
								$nomKolId = $this->kol->getKolIdByMDM($nomMDMNumber);
							if(!in_array($nomineeId,$missingInfluencerIds)){
								if($nomineeId!=''){
									$preparedStatements	.= $separator.'("'.$questionId.'","'.$nomineeId.'","'.$respondentId.'","'.$userId.'","'.$createdOn.'","'.$activeSurveyId.'","'.$isSubmitted.'","'.$nmineeAdressId.'","'.$repsAdressId.'","'.$territory.'","'.$territoryId.'","","'.$nomKolId.'","'.$respKolId.'",1)';
									$separator		= ',';
								}
							}
						}
						else{
							if($updated){
								$preparedUpdateStatements = "UPDATE survey_answers SET zeroInfluencers = NULL WHERE created_by='".$userId."' AND respondent_id='".$respondentId."' AND survey_id='".$activeSurveyId."'";
								$this->db->query($preparedUpdateStatements);
							}
							$updated = false;
						}
					}
				}
			}
//			echo $preparedStatements;
//			exit;
			$this->db->query($preparedStatements);
			//$this->survey->saveAnswers($activeSurveyId,$respondentId,$userId,$preparedStatements,$surveyRespondentId);
			$status = STATUS_RESPONDED;
			$this->update->insertUpdateEntry(SURVEY_STATUS_RESPONDED,$status, MODULE_SURVEY, $activeSurveyId,$status);
			//return false;
			
			if(USER_LOGS){
					$arrLogs = userLogData();
					$arrLogs['type_id'] = $activeSurveyId;
					$arrLogs['type'] = SURVEY_RESPOND;
					$arrLogs['note'] = "Ading Survey responce";
					$this->survey->saveUserLog($arrLogs);
					
			}
			if($redirectToKolId>0){
				redirect('kols/view/'.$redirectToKolId);
			}else{
//				redirect('surveys/view/'.$activeSurveyId.'/'.$respondentId.'/'.$userId);
				redirect('surveys/list_active_surveys');
			}
		}else{
//			pr($_POST);
			$arrQuestionIds	= explode(',',$this->input->post('surveyIds'));
			$respondentAndAdressid		= $this->input->post('respondent_id');
			foreach($arrQuestionIds as $key=>$questionId){
				$count	= 0;
				$noOfAnswers	= $this->input->post('count_'.$questionId);
				$arrKolIds		= $this->input->post('kol_id_'.$questionId);
				//$arrKolNames	= $this->input->post('kol_name_'.$questionId);
				foreach($arrKolIds as $index=>$id){
					if (strpos($id,'-') !== false) {
					    $arrData = array();
					    $id = explode("-",$id);
					    $activeSurveyId	= $this->input->post('active_survey_id');
					    $arrData = $this->survey->getIcontactDetailsById($id[1]);
					    $arrData['staging_respondent_id'] = $respondentAndAdressid;
					    $arrData['survey_influencer_id'] = $id[0];
					    $arrData['survey_influencer_address_id'] = $id[1];
					    $arrData['survey_id'] = $activeSurveyId;
					    $arrData['survey_question_id'] = $questionId; 
					    $this->survey->saveStagingContact($arrData,false);
					}
				}
			}
			redirect('surveys/list_active_surveys');
		}
	}
	
	function save_answers_no_names(){
//		pr($_POST);
//		exit;
		$activeSurveyId			= $this->input->post('active_survey_id');
		$arrQuestionIds			= explode(',',$this->input->post('surveyIds'));
		$surveyRespondentId		= $this->input->post('survey_respondent_id');
		$respondentAndAdressid	= $this->input->post('respondent_id');
		$createdOn				= date("Y-m-d H:i:s");
		$isExists				= $this->input->post('update');
		$userId					= $this->input->post('created_by');
		if($isExists==false || empty($userId)){
			$userId				= $this->session->userdata('user_id');
		}
		$arrData	= array();
		$arrData['survey_id']	= $activeSurveyId;
		$arrData['respondent_id']	= $respondentAndAdressid;
		$arrData['resp_address_id']	= 0;
		$arrData['created_by']	= $userId;
		$arrData['created_on']	= $createdOn;
		$arrData['zeroInfluencers']	= $this->input->post('no_names');
		if($this->input->post('is_stging') != 1){
			$arrData['is_submitted']	= 1;
			$respondents = explode('-',$respondentAndAdressid);
			$respondentId = $respondents[0];
			$repsAdressId = $respondents[1];
			$arrData['respondent_id']	= $respondentId;
			$arrData['resp_address_id']	= $repsAdressId;
//			$this->survey->saveAnswers($activeSurveyId,$respondentId,$userId,$preparedStatements,$surveyRespondentId);
			if(!empty($surveyRespondentId)){
				$this->db->where('respondent_id',$surveyRespondentId);
			}else{
				$this->db->where('respondent_id',$respondentId);
			}
			$this->db->where('survey_id',$activeSurveyId);
			$this->db->where('created_by',$userId);
			$this->db->delete('survey_answers');
			$this->survey->addRespondentToSurvey($arrData);
//			redirect('surveys/view/'.$activeSurveyId.'/'.$respondentId.'/'.$userId);
			redirect('surveys/list_active_surveys');		
		}else{
			$this->survey->addRespondentToSurvey($arrData,true);
			redirect('surveys/list_active_surveys');
		}		
	}
	/*
	 * To list surveys
	 */
	function list_surveys($id=''){
		$arrData	= array();
		
		if(!empty($id)){
			$arrData['arrSurveyData']	= $this->survey->getSurveys($id);
		}
		$arrData['showReports'] = true;
		$arrData['contentPage']	= 'surveys/list';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited list of all surveys Page",
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
				'kols_or_org_id' => '',
				'transaction_name' => "View list of all surveys Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/client_view', $arrData);
	}
	
	/*
	 * To list active/Enabled surveys to users
	 */
	function list_active_surveys(){
		$arrData	= array();
		$arrData['arrSurveys']		= $this->survey->getActiveSurveys();
		$arrData['disc']			= $this->session->userdata("disc");
		if($arrData['disc'] == 1){
			$this->session->unset_userdata("disc");
		} 
		$arrData['contentPage']		= 'surveys/active_surveys';
		$arrData['showReports'] = true;
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited list of all active surveys Page",
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
				'kols_or_org_id' => '',
				'transaction_name' => "Viewed list of all active surveys"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/client_view', $arrData);
	}
	
	/*
	 * To load surveys data in grid
	 */
	function load_survey_grid(){
		$arrSurveys	= array();
		$arrData	= array();
		$page		= (int)$this->input->post('page'); // get the requested page 
		$limit		= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		if($arrSurveysResults=$this->survey->getSurveys()){
			foreach($arrSurveysResults as $arrRow){
				$today		= strtotime(date("Y-m-d"));
				$startDate	= strtotime($arrRow['start_date']);
				$endDate	= strtotime($arrRow['end_date']); 
				if (($startDate <= $today && $endDate >= $today) && ($arrRow['is_active']==1)){
						$arrRow['is_active']	= 'Live';
				 }else if (($startDate > $today) && ($arrRow['is_active']==1)){
				 		$arrRow['is_active']	= 'Ready';
				 }else if (($endDate < $today) && ($arrRow['is_active']==1)){
				 		$arrRow['is_active']	= COMPLETED;
				 }else if($arrRow['is_active']==0){
				 	$arrRow['is_active']	= 'Draft';
				 }
				 if($arrRow['start_date']!="0000-00-00"){
					$arrRow['start_date']	= sql_date_to_app_date($arrRow['start_date']);
				 }else{
				 	$arrRow['start_date']	= '';
				 }
				 if($arrRow['end_date']!="0000-00-00"){
					$arrRow['end_date']		= sql_date_to_app_date($arrRow['end_date']);
				 }else{
				 	$arrRow['end_date']	= '';
				 }
				//$arrRow['name']	= '<a href="#" onclick="loadRespondents('.$arrRow['id'].',\''.$arrRow['name'].'\'); return false;">'.$arrRow['name'].'</a>';
				//$arrRow['name'] = 
				 $arrSurveys[]	= $arrRow;
			}
			$count				= sizeof($arrSurveys);
			if( $count >0 ){
				$total_pages	= ceil($count/$limit);
			}else{
				$total_pages	= 0;
			}
			$arrData['records']	= $count;
			$arrData['total']	= $total_pages;
			$arrData['page']	= $page;
			$arrData['rows']	= $arrSurveys;
		}
		ob_start('ob_gzhandler');
		echo json_encode($arrData);
	}
	
	/*
	 * To add new question
	 */
	function add_question_form(){
		$arrData	= array();
		$arrData['arrCategories']	= $this->survey->getAllCategories();
		$arrData['arrRoles']		= $this->survey->getAllRoles();
		$arrData['arrTypes']		= $this->arrSurveyTypes;
		$this->load->view('surveys/add_question_form',$arrData);
	}
	
	/*
	 * To save new category
	 */
	function save_category(){
		$arrData		= array();
		$categoryName	= trim($this->input->post('category_name'));
		$arrData		= $this->survey->saveCategory($categoryName);
		ob_start('ob_gzhandler');
		echo json_encode($arrData);
	}
	
	/*
	 * To save/update question
	 * @param $id	- question id
	 */
	function save_question($id=null){
		$arrData		= array();
		$arrSurveyData	= array();
		$arrSurveyData['type_id']		= $this->input->post('type_id');
		$arrSurveyData['category_id']	= $this->input->post('category_id');
		$arrSurveyData['role_id']		= $this->input->post('role_id');
		$arrSurveyData['question']		= trim($this->input->post('question'));
		if(!empty($id) && $id!=null){
			$arrSurveyData['id']	= $id;
			$arrData		= $this->survey->updateQuestion($arrSurveyData);
			if(USER_LOGS){
				
				$arrLogs = userLogData();
				$arrLogs['type_id'] = $arrSurveyData['id'];
				
				if($arrData['status']=='saved'){
					
					$arrLogs['type'] = SURVEY_QUESTION_UPDATE;
					$arrLogs['note'] = "Udated Survey Question";
					$this->survey->saveUserLog($arrLogs);
					//echo $this->db->last_query();
				}else{
					$arrLogs['type'] = SURVEY_QUESTION_UPDATE_FAILED;
					$arrLogs['note'] = "Failed to Update Question";
					$this->survey->saveUserLog($arrLogs);
				}
			}
		}else{
			$arrData		= $this->survey->saveQuestion($arrSurveyData);
			if(USER_LOGS){
				
				$arrLogs = userLogData();
				$arrLogs['type_id'] = $arrData['id'];
				
				if($arrData['status']=='saved'){
					
					$arrLogs['type'] = SURVEY_QUESTION_ADD;
					$arrLogs['note'] = "Added Survey Question";
					$this->survey->saveUserLog($arrLogs);
					//echo $this->db->last_query();
				}else{
					$arrLogs['type'] = SURVEY_QUESTION_FAILED;
					$arrLogs['note'] = "Failed to Update Question";
					$this->survey->saveUserLog($arrLogs);
				}
			}
		}
		ob_start('ob_gzhandler');
		echo json_encode($arrData);
	}
	
	/*
	 * To populate question in form to edit/modify
	 * @param $id	- question id
	 */
	function edit_question_form($id){
		$arrData		= array();
		$arrData['arrTypes']		= $this->arrSurveyTypes;
		$arrData['arrCategories']	= $this->survey->getAllCategories();
		$arrData['arrData']			= $this->survey->getSurveyQuestion($id);
		$this->load->view('surveys/add_question_form',$arrData);
	}
	
	/*
	 * To delete question
	 * @param $id	- question id
	 */
	function delete_question($id){
		if(!empty($id) && $id>0){
			$this->survey->deleteSurveyQuestion($id);
		}
	}
	
	/*
	 * To add new survey
	 */
	function add_survey(){
		if($this->session->userdata('user_role_id')==ROLE_MANAGER || $this->session->userdata('user_role_id')==ROLE_ADMIN){
			$arrData		= array();
			$clientId		= $this->session->userdata('client_id');
			$arrData['arrCategories']	= $this->survey->getAllQuestions();
			$arrData['arrTypes']		= $this->arrSurveyTypes;
			$arrData['arrSpecialties']	= $this->survey->getAllCategories();
			$arrData['arrRoles']		= $this->survey->getAllRoles();
			$arrData['arrGroups']		= $this->survey->listGroups($clientId);
			$arrData['arrClientUsers']	= $this->survey->listUserGroups($clientId);
			$arrData['contentPage']		= 'surveys/add_survey_form';
			//Add Log activity
			$arrLogDetails = array(
					'type' => VIEW_RECORD,
					'description' => "Visited add survey form Page",
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => '',
					'transaction_name' => "View add survey form Page"
			);
			$this->config->set_item('log_details', $arrLogDetails);
			$this->load->view('layouts/client_view', $arrData);
		}else{
			redirect('surveys/list_surveys');
		}
	}
	
	/*
	 * To edit survey
	 * @param $id	- survey id
	 */
	function edit_survey($id){
		if($this->session->userdata('user_role_id')==ROLE_MANAGER || $this->session->userdata('user_role_id')==ROLE_ADMIN){
			$arrData		= array();
			$arrSurveyData	= array();
			$clientId		= $this->session->userdata('client_id');
			$arrSurveyData	= $this->survey->getSurveys($id);
			$arrSurveyData	= $arrSurveyData[0];
			$arrData['arrCategories']	= $this->survey->getAllQuestions();
			$arrData['arrTypes']		= $this->arrSurveyTypes;
			$arrData['arrSpecialties']	= $this->survey->getAllCategories();
			$arrData['arrRoles']		= $this->survey->getAllRoles();
			$arrData['surveyData']		= $arrSurveyData;
			$arrData['surveyData']['start_date']	= sql_date_to_app_date($arrSurveyData['start_date']);
			$arrData['surveyData']['end_date']		= sql_date_to_app_date($arrSurveyData['end_date']);
			$arrData['surveyData']['arrQuestionIds']= array_flip(explode(',',$arrSurveyData['question_ids']));
			$arrData['arrSelectedQuestions']		= $this->survey->getAllQuestions(explode(',',$arrSurveyData['question_ids']));
			$arrData['arrSelectedGroups']		= explode(',',$arrSurveyData['group_ids']);
			$arrData['arrSelectedClientUsers']	= explode(',',$arrSurveyData['user_ids']);
			$arrData['arrGroups']		= $this->survey->listGroups($clientId);
			$arrData['arrClientUsers']	= $this->survey->listUserGroups($clientId);
			$arrData['contentPage']	= 'surveys/add_survey_form';
			//Add Log activity
			$arrLogDetails = array(
					'type' => VIEW_RECORD,
					'description' => "Visited add survey form Page",
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => '',
					'transaction_name' => "View add survey form Page"
			);
			$this->config->set_item('log_details', $arrLogDetails);
			$this->load->view('layouts/client_view', $arrData);
		}else{
			redirect('surveys/list_surveys');
		}
	}
	
	/*
	 * To save survey information
	 * @param $id	- survey id
	 */
	function save_survey($id=null){
		$arrSurveyData	= array();
		$arrSurveyData['name']			= trim($this->input->post('survey_name'));
		$arrSurveyData['question_ids']	= implode(',',$this->input->post('question_ids'));
		$arrSurveyData['description']	= trim($this->input->post('description'));
		$arrSurveyData['is_active']		= $this->input->post('is_active');
		$arrSurveyData['start_date']	= app_date_to_sql_date($this->input->post('start_date'));
		$arrSurveyData['end_date']		= app_date_to_sql_date($this->input->post('end_date'));
		$arrSurveyData['user_ids']		= implode(',',$this->input->post('users'));
		$arrSurveyData['group_ids']		= implode(',',$this->input->post('groups'));
		$arrSurveyData['survey_from']	= 1; //Flag to identify that this survey is from iProfile
		//pr($arrSurveyUsers);
		if($id!=null && $id>0){
			$arrSurveyData['id']		= $id;
			$arrReturnData = $this->survey->updateSurvey($arrSurveyData);
			//Add Log activity
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Update Survey',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => '',
					'transaction_id' =>  $arrSurveyData['id'],
					'transaction_table_id' => SURVEYS,
					'transaction_name' => 'Update Survey',
					'form_data' => json_encode($arrSurveyData),
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
				if($arrSurveyData['is_active'] == 1){
					$status = STATUS_CREATED;
					$this->update->insertUpdateEntry(SURVEY_STATUS_ADD,$status, MODULE_SURVEY, $id,$status);					
				}
				
				if(USER_LOGS){
					
					$arrLogs = userLogData();
					$arrLogs['type_id'] = $arrReturnData['id'];
				
					if($arrReturnData['status']=='saved'){
						
						$arrLogs['type'] = SURVEY_UPDATE;
						$arrLogs['note'] = "Updated Survey";
						$this->survey->saveUserLog($arrLogs);
						//echo $this->db->last_query();
					}else{
						$arrLogs['type'] = SURVEY_UPDATE_FAILED;
						$arrLogs['note'] = "Failed to update Survey";
						$this->survey->saveUserLog($arrLogs);
					}
				}
				
				
		}else{
			//pr($this->session->userdata);
			$data = $this->survey->saveSurvey($arrSurveyData);
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add New Survey',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => '',
					'transaction_id' =>  $data['id'],
					'transaction_table_id' => SURVEYS,
					'transaction_name' => 'Add New Survey',
					'form_data' => json_encode($arrSurveyData),
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
			if(USER_LOGS){
				
				$arrLogs = userLogData();
				$arrLogs['type_id'] = $data['id'];
			
				if($data['status']=='saved'){
					$arrLogs['type'] = SURVEY_ADD;
					$arrLogs['note'] = "Added Survey";
					$this->survey->saveUserLog($arrLogs);					
					//echo $this->db->last_query();
				}else{
					$arrLogs['type'] = SURVEY_ADD_FAILED;
					$arrLogs['note'] = "Failed to add Survey";
					$this->survey->saveUserLog($arrLogs);					
				}
			}
		}
		redirect('surveys/list_surveys');
	}
	
	/*
	 * To delete survey
	 * @param $id	- survey id
	 */
	function delete_survey($id){
		if(!empty($id) && $id>0){
			$this->survey->deleteSurvey($id);
			if(USER_LOGS){
				
				$arrLogs = userLogData();
				//$arrLogs['type_id'] = $data['id'];
			
				$arrLogs['type'] = SURVEY_DELETE;
				$arrLogs['note'] = "Deleted Survey";
				$this->survey->saveUserLog($arrLogs);
					//echo $this->db->last_query();
				
			}
		}
	}
	/*
	 * To delete respondent of survey
	 * @param $surveyId,$respondentId,$createdBy
	 */
	function delete_survey_respondent($surveyId=0,$respondentId=0,$createdBy=0){
		$this->survey->deleteSurveyRespondent($surveyId,$respondentId,$createdBy);
	}
	/*
	 * Load respondent data in grid
	 * @param $surveyId
	 */
function load_respondent_grid($surveyId){
		ini_set('max_execution_time', 0);
		ini_set('memory_limit', '-1');
		$page		= (int)$this->input->post('page'); // get the requested page 
		$limit		= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$arrData	= array();     	
		$arrRespondents	= array();
		$clientId = $this->session->userdata('client_id');
		$roleId	= $this->session->userdata('user_role_id');
		if(!empty($surveyId) && $surveyId>0){
			if($arrSurveyRespondentsResults=$this->survey->getRespondents($surveyId)){
				$today		= strtotime(date("Y-m-d"));
				foreach($arrSurveyRespondentsResults as $arrRow){
					$endDate	= strtotime($arrRow['end_date']);
					$respondent	= '';
					$arrRow['microview']	= '';
					/*if($arrRow['status']==COMPLETED){
						$kolGender	= 'Male';
						if(isset($arrRow['gender']) && !empty($arrRow['gender'])){
							$kolGender	= $arrRow['gender'];
						}
						$arrRow['microview']	= '<div class="tooltip-demo tooltop-right '.$kolGender.' microViewIcon" onclick="showMicroProfile('.$arrRow['kol_id'].',this); return false;"><a href="#" class="tooltipLink" rel="tooltip" data-original-title="Profile Snapshot">&nbsp;</a></div>';
						//$respondent	.= '<a href="'.base_url().'kols/view/'.$arrRow['kol_id'].'" target="_new">'.$arrRow['respondent'].'</a>';
						$respondent	= $arrRow['respondent'];
					}else{
						$arrRow['microview']	= '<div class="tooltip-demo tooltop-right requestProfile sprite_iconSet" onclick="addNewKolProfile('.$arrRow['id'].',this); return false;"><a href="#" class="tooltipLink" rel="tooltip" data-original-title="Request Profile">&nbsp;</a></div>';
						$respondent	= $arrRow['respondent'];
					}
					$arrRow['respondent']	= $respondent;
					$arrRow['org_microview']	= '';
					$arrRow['org_name']			= $arrRow['org_name'];
					if(!empty($arrRow['org_name']) && isset($arrRow['org_name'])){
						if($arrRow['org_status']==COMPLETED){
							$arrRow['org_microview']	= '<div class="tooltip-demo tooltop-right orgProfile sprite_iconSet" onclick="showOrgMicroProfile('.$arrRow['org_id'].',this); return false;"><a href="#" class="tooltipLink" rel="tooltip" data-original-title="Organization Snapshot">&nbsp;</a></div>';
							//$arrRow['org_name']			= '<a href="'.base_url().'organizations/view/'.$arrRow['org_id'].'" target="_new">'.$arrRow['org_name'].'</a>';
							//$arrRow['org_name']			= $arrRow['org_name'];
						}else{
							$arrRow['org_microview']	= '<div class="tooltip-demo tooltop-right orgProfileRequest sprite_iconSet" onclick="addNewOrgProfileRequest('.$arrRow['survey_org_id'].',this); return false;"><a href="#" class="tooltipLink" rel="tooltip" data-original-title="Request Organization Profile">&nbsp;</a></div>';
							//$arrRow['org_name']			= $arrRow['org_name'];
						}
					}
					if($arrRow['org_name']==null){
						$arrRow['org_name']	= "Not Available";
					}*/
					$act	= '<div style="float:left;margin-right:0px;" class="tooltip-demo tooltop-right microViewIcon"><a class="tooltipLink" rel="tooltip" data-original-title="View" href="'.base_url().'surveys/view/'.$surveyId.'/'.$arrRow['id'].'/'.$arrRow['created_by'].'">&nbsp;</a></div>';
					if(($endDate >= $today) && $arrRow['created_by']==$this->session->userdata('user_id')){
						//$act	.= "<div class='actionIcon editIcon' onclick=\"editSurveyData(".$arrRow['id'].",".$surveyId.",".$arrRow['created_by']."); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' data-original-title=\"Edit\">&nbsp;</a></div><div class='actionIcon deleteIcon' onclick=\"deleteSurveyData(".$arrRow['id'].",".$surveyId.",".$arrRow['created_by']."); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' data-original-title=\"Delete\">&nbsp;</a></div>";
						$act	.= "<div class='actionIcon editIcon' onclick='editSurveyData(".$arrRow['id'].",".$surveyId.",".$arrRow['created_by']."); return false;'><a href='#' class='tooltipLink' rel='tooltip' data-original-title='Edit'></a></div><div class='actionIcon deleteIcon' onclick='deleteSurveyData(".$arrRow['id'].",".$surveyId.",".$arrRow['created_by']."); return false;'><a href='#' class='tooltipLink' rel='tooltip' data-original-title='Delete'></a></div>";
					}else if($clientId==INTERNAL_CLIENT_ID && ($roleId==ROLE_MANAGER || $roleId==ROLE_ADMIN)){
						$act	.= "<div class='actionIcon editIcon' onclick='editSurveyData(".$arrRow['id'].",".$surveyId.",".$arrRow['created_by']."); return false;'><a href='#' class='tooltipLink' rel='tooltip' data-original-title='Edit'></a></div>";
					}
					$arrRow['act']	= '<div class="actionIconsContainer tooltip-demo tooltop-left">'.$act.'</div>';
					
					$kolGender = 'Male';
					if(isset($arrRow['gender'])){
						$kolGender	= $arrRow['gender'];
					}
					$arrRow['status'] = '';
					if($arrRow['kol_id'] != null && $arrRow['kol_id'] != 0){
						$kolStatus = $this->kol->getKolStatus($arrRow['kol_id']);
						$arrRow['status'] = $kolStatus;
						if($arrRow['source_table'] == 'kols')
							$arrRow['microview']	= '<div class="tooltip-demo tooltop-right '.$kolGender.' microViewIcon" onclick="showMicroProfile('.$arrRow['source_table_id'].',this); return false;"><a href="#" class="tooltipLink" rel="tooltip" title="Profile Snapshot">&nbsp;</a></div>';
						else
							$arrRow['microview']	= '<div class="tooltip-demo tooltop-right requestProfile sprite_iconSet" onclick="addNewKolProfile('.$arrRow['id'].',this); return false;"><a href="#" class="tooltipLink" rel="tooltip" title="Request Profile">&nbsp;</a></div>';
					}else
						$arrRow['microview']	= '<div class="tooltip-demo tooltop-right requestProfile sprite_iconSet" onclick="addNewKolProfile('.$arrRow['id'].',this); return false;"><a href="#" class="tooltipLink" rel="tooltip" title="Request Profile">&nbsp;</a></div>';
				
					$arrRespondents[]		= $arrRow;
				}
				//pr($arrRespondents);
				$count				= sizeof($arrRespondents);
				if( $count >0 ){
					$total_pages	= ceil($count/$limit);
				}else{
					$total_pages	= 0;
				}
				$arrData['records']	= $count;
				$arrData['total']	= $total_pages;
				$arrData['page']	= $page;
				$arrData['rows']	= $arrRespondents;
			}
		}
		ob_start('ob_gzhandler');
		echo json_encode($arrData);
	}
	
	/*
	 * View survey
	 * @param $surveyId
	 * @param $respondentId
	 * @param $createdBy
	 */
	function view($surveyId,$respondentId,$createdBy){
		$today		= strtotime(date("Y-m-d"));
		$data['editAllowed']	= false;
		$data['arrRespondent']	= $this->survey->getRespondents($surveyId,$respondentId,'');
		$data['arrSurveyData']	= $this->survey->viewSurveyResult($surveyId,$respondentId,'');
		foreach($data['arrSurveyData']['arrAnswerData'] as $key => $answeres){
			foreach($answeres as $akey =>  $row){
				$kolId = $data['arrSurveyData']['arrAnswerData'][$key][$akey]['nom_kol_id'];
				$data['arrSurveyData']['arrAnswerData'][$key][$akey]['status'] = $this->kol->getKolStatus($kolId);
				$data['arrSurveyData']['arrAnswerData'][$key][$akey]['kol_id'] = $kolId;
			}
		}
		$endDate	= strtotime($data['arrSurveyData']['arrSurveyData']['end_date']);
		if(($endDate >= $today)){
			$data['editAllowed']	= true;
		}
		$data['showReports'] = true;
		$data['contentPage']	= 'surveys/view_survey';
		$this->load->view('layouts/client_view', $data);
	}
	/*
	 * Edit survey
	 * @param $surveyId
	 * @param $respondentId
	 * @param $createdBy
	 */
	function edit_survey_data($surveyId,$respondentId,$createdBy){
		$data['surveyId']		= $surveyId;
		$data['created_by']		= $createdBy;
		$data['arrTypes']		= $this->arrSurveyTypes;
		$data['arrRespondent']	= $this->survey->getRespondents($surveyId,$respondentId,$createdBy);
		$arrData				= $this->survey->viewSurveyResult($surveyId,$respondentId,$createdBy);
		$data['arrSurveys']		= $arrData['arrQuestionData'];
		$data['arrSurveyData']	= $arrData['arrSurveyData'];
		$data['arrSurveyAnswers']	= $arrData['arrAnswerData'];
		$data['type']	= 'update';
// 		pr($data);
// 		exit;
		$data['contentPage']	= 'surveys/survey_form';
		$data['showReports'] = true;
		$this->load->view('layouts/client_view', $data);
	}
	/*
	 * To check whether the respondent is already responded to survey
	 * @param $surveyId
	 */
	function isRespondentAlreadySurveyed($surveyId,$respondentId = '',$resAddressId = ''){
		
     /*       $arrData['created_by']		= $this->session->userdata('user_id');
		//$arrData['respondent_name']	= $this->input->post('respondent');
                $arrData['respondent_id']	= $this->input->post('respondent_id');
		$arrData['survey_id']		= $surveyId;
                
		$arrMsg		= $this->survey->isRespondentAlreadySurveyed($arrData);
		ob_start('ob_gzhandler');
		echo json_encode($arrMsg);
		*/
		$arrData['created_by']		= $this->session->userdata('user_id');
		if($respondentId == '1')
			$arrData['respondent_id']	= $this->input->post('respondent_id');
		else
			$arrData['respondent_id']	= $respondentId;
			
		$arrData['survey_id']		= $surveyId;
		//$arrMsg		= $this->survey->isRespondentAlreadySurveyed($arrData);
		$arrMsg		= $this->survey->isRespondentAlreadySurveyedNew($arrData);
		if($arrMsg['created_by'] == $arrData['created_by']){
			$arrMsg['created_by'] = true;
		}else{
			$arrMsg['respondent_id'] = $respondentId;
			$arrMsg['resp_address_id'] = $resAddressId;
			$arrMsg['created_by'] = false;
		}
			
		ob_start('ob_gzhandler');
		echo json_encode($arrMsg);
	}
	/*
	 * To check uniqueness of survey name
	 * @param $id	- survey id
	 */
	function validate_survey($id=''){
		if(!empty($id) && $id>0){
			$arrData['id']		= $id;
		}
		$arrData['survey_name']	= trim($this->input->post('survey_name'));
		$arrData['start_date']	= app_date_to_sql_date($this->input->post('start_date'));
		$arrData['end_date']	= app_date_to_sql_date($this->input->post('end_date'));
		if(empty($arrData['start_date'])){
			$arrData['start_date']	= '0000-00-00';
		}
		if(empty($arrData['end_date'])){
			$arrData['end_date']	= '0000-00-00';
		}
		$arrMsg		= $this->survey->isValidateSurveyName($arrData);
		ob_start('ob_gzhandler');
		echo json_encode($arrMsg);
	}
	/*
	 * To view Reports of survey
	 */
	function view_reports(){
		$data['arrCompletedSurveys']	= $this->survey->getCompletedSurveys();
		$data['arrTypes']				= $this->arrSurveyTypes;
		$data['contentPage']			= 'surveys/view_report';
		$this->load->view('layouts/client_view', $data);
	}
	/*
	 * To load selected report data
	 */
	function reports_data(){
		$arrReportData	= array();
		$arrReturnData	= array();
		$surveyId		= $this->input->post('id');
		$chartType		= $this->input->post('chart_type');
		$arrSelections	= $this->formatFilterSelections($_POST);
		
		switch($chartType){
			case '1':	$arrReportData['respondentsCount']	= $this->survey->actualRespondentsCount($surveyId,$arrSelections);
							//echo $this->db->last_query();
							
						$arrReportData['usersCount']		= $this->survey->actualUsersRespondedCount($surveyId,$arrSelections);
						//echo $this->db->last_query();
						
						$arrReportData['nomineesCount']		= $this->survey->actualNomineesCount($surveyId,$arrSelections);
						//echo $this->db->last_query();
						//pr($arrReportData);
						
					//	$arrReportData['specialty']			= $this->survey->nomineesBySpecialty($surveyId,$arrSelections);
						
						$arrReportData['specialty']			= $this->survey->respondentByState($surveyId,$arrSelections);
						
						$arrReportData['state']				= $this->survey->nomineesByState($surveyId,$arrSelections);
						
					//
						//pr($arrReportData);
						//echo $this->db->last_query();
				break;
			case '2':	$arrReturnData	=  $this->survey->topNominees($surveyId,$arrSelections);
			//echo $this->db->last_query();
			//pr($arrReturnData);
				if(!empty($arrReturnData)){
							foreach($arrReturnData as $row){
								$arrReportData['chartdata']['nominees'][]	= $row['name'];
								$arrReportData['chartdata']['count'][]		= (int)$row['count'];
							}
				}else{
					$arrReportData['chartdata']['nominees']='';
				}
						$arrReportData['filters']['specialty']			= $this->survey->getSpecialties($surveyId);
						$arrReportData['filters']['state']				= $this->survey->getNomineesStates($surveyId);
						
				break;
			case '3':	$arrReturnData	=  $this->survey->userNominees($surveyId);
						$uniqueUsers	= array();
						$arrData		= array();
						$arrRow			= array();
						foreach($arrReturnData as $row){
							if(!isset($uniqueUsers[$row['username']])){
								$uniqueUsers[$row['username']]	= $row['username'];
							}
							$arrData[$row['name']][$row['username']][]	= (int)$row['count']; 
						}
						foreach($arrData as $key => $row){
							foreach($uniqueUsers as $index=>$value){
								if(isset($row[$value])){
									$arrRow[$key][]	= $row[$value][0];
								}else{
									$arrRow[$key][]	= 0;
								}
							}
							$arrReportData['data'][]	= array('name'=>$key,'data'=>$arrRow[$key]); 
						}
						$arrReportData['username']	= array_values($uniqueUsers);
				break;
			case '4':	$arrReturnData	=  $this->survey->userRespondents($surveyId);
						$uniqueUsers	= array();
						$arrData		= array();
						$arrRow			= array();
						$arrRow1		= array();
						foreach($arrReturnData as $row){
							if(!isset($uniqueUsers[$row['username']])){
								$uniqueUsers[$row['username']]	= $row['username'];
							}
							$arrData[$row['name']][$row['username']][]	= (int)$row['count']; 
						}
						foreach($arrData as $key => $row){
							foreach($uniqueUsers as $index=>$value){
								if(isset($row[$value])){
									$arrRow1[$key.$value][]	= $row[$value][0];
									$arrReportData['nominated_count'][$key.$value][]	= $row[$value][0];
									$arrRow[$key][]	= 1;
								}else{
									$arrRow1[$key.$value][]	= 0;
									$arrReportData['nominated_count'][$key.$value][]	= 0;
									$arrRow[$key][]	= 0;
								}
							}
							$arrReportData['data'][]	= array('name'=>$key,'data'=>$arrRow[$key]); 
						}
						$arrReportData['username']	= array_values($uniqueUsers);
				break;
		}
		//pr($arrReportData['respondentsCount']);
		//echo $this->db->last_query();
		ob_start('ob_gzhandler');
		echo json_encode($arrReportData);
	}
	/*
	 * Refined filter for survey
	 * @param $isFromFilters
	 */
	function load_filter_data($isFromFilters=''){
		$this->load->model('My_list_kol');
		$filterData		= array();
		$specialty		= trim($this->input->post('specialty'));
		$country		= trim($this->input->post('country'));
		$state			= trim($this->input->post('state_id'));
		$listName		= trim($this->input->post('list_name'));
		$arrCountries	= $this->input->post('countries');
		if($arrCountries!='')
			$arrCountries	= explode(",",$arrCountries);
		if($country!='')
			$arrCountries[]	= $country;
			
		$arrStates			= $this->input->post('states');
		if($arrStates!='')
			$arrStates		= explode(",",$arrStates);
		if($state!='')
			$arrStates[]	= $state;
		
		$arrSpecialties		= $this->input->post('specialties');
		if($arrSpecialties!='')
			$arrSpecialties	= explode(",",$arrSpecialties);
		if($specialty!=''){
				$arrSpecialties[]	= $specialty;
			}
		
		$arrLists					= $this->input->post('lists');
		if($arrLists!='')
			$arrLists				= explode(",",$arrLists);
		if($listName!=''){
			if(stripos($listName, '(')){
				$arrListDetails		= explode("(",$listName);
				$listName			= trim($arrListDetails[0]);
				$categoryName		= trim($arrListDetails[1],") ");
				$listName			= $this->My_list_kol->getListName($listName,$categoryName);
			}
			$arrLists[]				= $listName;
		}
		
		//Prepare array of filter fields, ehich will be used for querying
		$arrFilterFields['specialty']	= $arrSpecialties;
		$arrFilterFields['country']		= $arrCountries;
		$arrFilterFields['state']		= $arrStates;
		$arrFilterFields['list']		= $arrLists;
		
		$arrKolsByCountryCount		= $this->survey->loadFilterData($arrFilterFields,'country');
		$arrKolsByStateCount		= $this->survey->loadFilterData($arrFilterFields,'state');
		$arrKolsBySpecialtyCount	= $this->survey->loadFilterData($arrFilterFields,'specialty');
		$arrKolsByListCount			= $this->survey->loadFilterData($arrFilterFields,'list');
		
		//Preparing the kols by category results as required by the filter page and aso getting the total count for category
		$allCountryCount	= 0;
		$assoArrKolsByCountryCount							= array();
		foreach($arrKolsByCountryCount as $row){
			$assoArrKolsByCountryCount[$row['country']]		= $row;
			$allCountryCount+=$row['count'];
		}
		$allStateCount		= 0;
		$assoArrKolsByStateCount							= array();
		foreach($arrKolsByStateCount as $row){
			$assoArrKolsByStateCount[$row['state']]			= $row;
			$allStateCount+=$row['count'];
		}
		$allSpecialtyCount	= 0;
		$assoArrKolsBySpecialtyCount						= array();
		foreach($arrKolsBySpecialtyCount as $row){
			$assoArrKolsBySpecialtyCount[$row['specs']]		= $row;
			$allSpecialtyCount								+= $row['count'];
		}
		$allListCount		= 0;
		$assoArrKolsByListCount								= array();
		foreach($arrKolsByListCount as $row){
			$assoArrKolsByListCount[$row['list_name_id']]	= $row;
			$allListCount									+= $row['count'];
		}
		
		//Setting all the required data and forwording in to respective page
		$filterData['allCountryCount']			= $allCountryCount;
		$filterData['allStateCount']			= $allStateCount;
		$filterData['allSpecialtyCount']		= $allSpecialtyCount;
		$filterData['allListCount']				= $allListCount;
		$filterData['arrKolsByCountryCount']	= $assoArrKolsByCountryCount;
		$filterData['arrKolsByStateCount']		= $assoArrKolsByStateCount;
		$filterData['arrKolsBySpecialtyCount']	= $assoArrKolsBySpecialtyCount;
		$filterData['arrKolsByListCount']		= $assoArrKolsByListCount;
		$filterData['selectedCountries']		= $arrCountries;
		$filterData['selectedStates']			= $arrStates;
		$filterData['selectedSpecialties']		= $arrSpecialties;
		$filterData['selectedLists']			= $arrLists;
		$filterData['arrFilterFields']   		= $arrFilterFields;
		if(!empty($isFromFilters)){
			echo $this->load->view('surveys/survey_filters_li_style', $filterData,true);
		}else{
			return $this->load->view('surveys/survey_filters_li_style', $filterData,true);
		}
	}
	/*
	 * To populate data for report builder
	 * @param $surveyId
	 */
	function load_custom_query_data($surveyId){
		$arrData	= array();
		$userId		= $this->session->userdata('user_id');
		$arrData['savedquery']	= $this->survey->loadSavedQuery($userId);
		$arrCustomQueryData		= $this->survey->loadCustomQueryData($surveyId);
		$arrData['querydata']	= $arrCustomQueryData;
		ob_start('ob_gzhandler');
		echo json_encode($arrData);
	}
	/*
	 * Load data based on report builder query
	 */
	function load_query_result(){
		$arrData	= array();
		$arrData['survey_id']			= $this->input->post('survey_id');
		$arrData['nominee']['name']		= $this->input->post('nominee_Name');
		$arrData['nominee']['city']		= $this->input->post('nominee_city');
		$arrData['nominee']['country']	= $this->input->post('nominee_country');
		$arrData['nominee']['postal']	= $this->input->post('nominee_postal');
		$arrData['nominee']['specialty']= $this->input->post('nominee_specialty');
		$arrData['nominee']['state']	= $this->input->post('nominee_state');
		$arrData['nominee']['type']		= $this->input->post('nominee_type');
		$arrData['respondent']['id']	= $this->input->post('respondent_id');
		$arrData['respondent']['state']	= $this->input->post('respondent_state');
		$arrData['respondent']['city']	= $this->input->post('respondent_city');
		$arrData['respondent']['postal']= $this->input->post('respondent_postal');
		$arrResult	= $this->survey->load_query_result($arrData);
		unset($arrData['survey_id']);
		$arrReturnData	= array('data'=>$arrResult,'query'=>$arrData);
		ob_start('ob_gzhandler');
		echo json_encode($arrReturnData);
	}
	/*
	 * To save new role
	 */
	function save_role(){
		$roleName	= trim($this->input->post('role_name'));
		$arrData	= $this->survey->saveRole($roleName);
		ob_start('ob_gzhandler');
		echo json_encode($arrData);
	}
	/*
	 * Load summary details such as respondents, Influencers and Users participated
	 */
	function load_summery_details(){
//		error_reporting(E_ALL);
		ini_set('memory_limit', "-1");
        ini_set("max_execution_time", 0);
		$arrData	= array();
		$arrData['survey_id']	= $this->input->post('survey_id');
		$arrData['participant']	= $this->input->post('participant');
		$arrData['influencer_name']	= $this->input->post('influencer_name');
		$arrData['influencer_ids']	= $this->input->post('influencer_ids');
		$arrData['state_ids']	= $this->input->post('state_ids');
		$arrData['city_ids']	= $this->input->post('city_ids');
		$arrData['postalcode_ids']	= $this->input->post('postalcode_ids');
		$arrData['respondent_ids']	= $this->input->post('respondent_ids');
		$arrSelections			= $this->formatFilterSelections($_POST);
	//	$arrSelections['users']['user'] = $this->session->userdata('user_full_name');
		//$arrResult	= $this->survey->loadSummeryDetails($arrData,$arrSelections);
		$arrResult	= $this->survey->loadSurveySummaryDetails($arrData,$arrSelections);
		//pr($arrResult);exit;
		//pr($this->db->last_query());exit;
		$resWithKolDetails = array();
		foreach($arrResult as $row){
			$row['microview'] = '';
			if($row['source_table'] == "kols"){
				$row['microview']	= '<div class="tooltip-demo tooltop-right '.$kolGender.' microViewIcon" onclick="showMicroProfile('.$row['kolId'].',this); return false;"><a href="#" class="tooltipLink" rel="tooltip" title="Profile Snapshot">&nbsp;</a></div>';
			}else{
				$row['microview']	= '<div class="tooltip-demo tooltop-right requestProfile sprite_iconSet" onclick="addNewKolProfile('.$row['kolId'].',this); return false;"><a href="#" class="tooltipLink" rel="tooltip" title="Request Profile">&nbsp;</a></div>';
			}
			$resWithKolDetails[] = $row;
		}
		/* foreach($arrResult as $row){
			$kolGender = 'Male';
			$row['microview'] = '';
			$row['status'] = '';
			if($row['kol_id'] != null && $row['kol_id'] != 0){
				$kolStatus = $this->kol->getKolStatus($row['kol_id']);
				$row['status'] = $kolStatus;
				if($kolStatus == COMPLETED)
					$row['microview']	= '<div class="tooltip-demo tooltop-right '.$kolGender.' microViewIcon" onclick="showMicroProfile('.$row['kol_id'].',this); return false;"><a href="#" class="tooltipLink" rel="tooltip" title="Profile Snapshot">&nbsp;</a></div>';
				else
					$row['microview']	= '<div class="tooltip-demo tooltop-right requestProfile sprite_iconSet" onclick="addNewKolProfile('.$row['id'].',this); return false;"><a href="#" class="tooltipLink" rel="tooltip" title="Request Profile">&nbsp;</a></div>';
			}else
				$row['microview']	= '<div class="tooltip-demo tooltop-right requestProfile sprite_iconSet" onclick="addNewKolProfile('.$row['id'].',this); return false;"><a href="#" class="tooltipLink" rel="tooltip" title="Request Profile">&nbsp;</a></div>';
			$resWithKolDetails[] = $row;
		} */
		//echo $this->db->last_query();
		ob_start('ob_gzhandler');
		echo json_encode($resWithKolDetails);
	}
	/*
	 * Returns the list of kol Names, from kols and key_people tables
	 * @author Laxman
	 * @since KOLM v5.5 Otsuka 1.0.10
	 * @created 12-04-2013
	 * @param $kolName
	 *
	 */
	function get_kol_names_for_autocomplete_old($kolName){
		$kolName		= trim(utf8_urldecode($this->input->post($kolName)));
		$arrKolNames1	= array();
		$flag			= 1;
		$arrKolNames	= $this->survey->getAllKolNamesForAutocomplete($kolName);
		//$arrKolNames['keypeoples']	= $this->survey->getAllKeyPeopleNamesForAutocomplete($kolName);
		//$arrKolNames['surveynames']	= $this->survey->getAllSurveyNamesForAutocomplete($kolName);
		foreach($arrKolNames['kols'] as $key=>$row){
			if($flag){
				$arrKolNames1[]	= "<div class='autocompleteHeading'>Contacts</div><div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='orgName'>$row[1]</label><span style='display:none' class='id1'>$key</span></div>";
				$flag	= 0;
			}else{
				$arrKolNames1[]	= "<div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='orgName'>$row[1]</label><span style='display:none' class='id1'>$key</span></div>";
			}
		}
		$flag			= 1;
		
		if((sizeof($arrKolNames['kols'])<1)){
			$arrKolNames1[]		= "<div style='padding-left:5px;'>No results found for ".$kolName."</div><div><label name='No results found for ".$kolName."' class='kolName' style='display:block'></label><label class='orgName'></label><span style='display:none' class='id1'></span></div>";
		}
		$arr['query']		= $kolName;
		$arr['suggestions']	= $arrKolNames1;
		//echo $this->db->last_query();
		ob_start('ob_gzhandler');
		echo json_encode($arr);
	}
	/*
	 * get respondent id from respondent name
	 */
	function getRespondentId(){
		$name		= trim($this->input->post('respondent'));
		$arrData	= $this->survey->getRespondentId($name);
		ob_start('ob_gzhandler');
		echo json_encode($arrData);
	}
	function getRespondentIdNew(){
		$name		= trim($this->input->post('respondent'));
		$arrData	= $this->survey->getRespondentIdNew($name);
		ob_start('ob_gzhandler');
		echo json_encode($arrData);
	}
	/*
	 * Load Top influencers chart based on filters
	 */
	function reload_top_influencers_chart(){
		$arrReportData	= array();
		$arrReturnData	= array();
		$surveyId		= $this->input->post('id');
		$arrFilters['states']		= $this->input->post('states');
		$arrFilters['specialties']	= $this->input->post('specialties');
		$arrReturnData	=  $this->survey->topNominees($surveyId,$arrFilters);
		foreach($arrReturnData as $row){
			$arrReportData['nominees'][]	= $row['name'];
			$arrReportData['count'][]		= (int)$row['count'];
		}
		ob_start('ob_gzhandler');
		echo json_encode($arrReportData);
	}
	/*
	 * To populate the influencer information to request profile form
	 */
	function add_client_pre_kol_request($id){
		$this->load->model('Specialty');
		$this->load->model('Country_helper');
		$arrKolDetail	= $this->survey->getNameDetails($id);
		//if($arrKolDetail['kol_id']>0){
		//	$this->load->model('kol');
		//	$arrKolDetail = $this->kol->editKol($arrKolDetail['kol_id']);
		//}else{
			$countryID	= $this->Country_helper->getConcountryId($arrKolDetail['country']);
			$stateID	= $this->Country_helper->getStateId($arrKolDetail['state']);
			if(empty($countryID)){
				$countryID	= 0;
			}
			if(empty($stateID)){
				$stateID	= 0;
			}
			$arrKolDetail['country_id']	= $countryID;
			$arrKolDetail['state_id']	= $stateID;
			$arrName	= explode(' ',$arrKolDetail['name']);
			$arrKolDetail['first_name'] = $arrName[0];
			switch(sizeof($arrName)){
				case 2:
					$arrKolDetail['last_name'] = $arrName[1];
					break;
				case 3:
					$arrKolDetail['middle_name'] = $arrName[1];
					$arrKolDetail['last_name'] = $arrName[2];
					break;
				case 4:
					$arrKolDetail['middle_name'] = $arrName[1];
					$arrKolDetail['last_name'] = $arrName[2].' '.$arrName[3];
					break;
				case 5:
					$arrKolDetail['middle_name'] = $arrName[1];
					$arrKolDetail['last_name'] = $arrName[2].' '.$arrName[3];
					$arrKolDetail['first_name'] .= ' '.$arrName[4];
					break;
			}
			$arrKolDetail['org_name']        	=	$arrKolDetail['org_name'];
		//}
		$arrKolDetail['profile_type']	= 'Full Profile';
		$this->session->set_flashdata('arrData', $arrKolDetail);
		//pr($arrKolDetail);
		redirect('requested_kols/request_kol_profile');
		//$this->load->view('kols/client_pre_kol',$data);
		//$this->load->view('organizations/add_client_kol',$data);
	}
	function add_client_pre_kol($id){
		$this->load->model('Specialty');
		$this->load->model('Country_helper');
		$data					= array();
		$arrStates 				= array();
		$arrCities				= array();
		$data['arrSalutations']	= array(1=>'Dr.', 2=>'Prof.', 3=>'Mr.', 4=>'Ms.');
		$data['arrCountry']		= $this->Country_helper->listCountries();
		$data['arrSpecialties']	= $this->Specialty->getAllSpecialties();
		$arrKolDetail	= $this->survey->getNameDetails($id);
		$arrKolDetail['org_name'] = '';
		if($arrKolDetail['kol_id']>0){
			$this->load->model('kol');
			$arrKolDetail = $this->kol->editKol($arrKolDetail['kol_id']);
			if($arrKolDetail['org_id']!=0){
				$this->load->model('organization');
				$arrKolDetail['org_name'] = $this->organization->getOrgNameByOrgId($arrKolDetail['org_id']);
			}
		}else{
			$countryID	= $this->Country_helper->getConcountryId($arrKolDetail['country']);
			$stateID	= $this->Country_helper->getStateId($arrKolDetail['state']);
			if(empty($countryID)){
				$countryID	= 0;
			}
			if(empty($stateID)){
				$stateID	= 0;
			}
			$arrKolDetail['country_id']	= $countryID;
			$arrKolDetail['state_id']	= $stateID;
			$arrName	= explode(' ',$arrKolDetail['name']);
			$arrKolDetail['first_name'] = $arrName[0];
			switch(sizeof($arrName)){
				case 2:
						$arrKolDetail['last_name'] = $arrName[1];
					break;
				case 3:
						$arrKolDetail['middle_name'] = $arrName[1];
						$arrKolDetail['last_name'] = $arrName[2];
					break;
				case 4:
						$arrKolDetail['middle_name'] = $arrName[1];
						$arrKolDetail['last_name'] = $arrName[2].' '.$arrName[3];
					break;
				case 5:
						$arrKolDetail['middle_name'] = $arrName[1];
						$arrKolDetail['last_name'] = $arrName[2].' '.$arrName[3];
						$arrKolDetail['first_name'] .= ' '.$arrName[4];
					break;
			}
		}
		if($arrKolDetail['country_id'] != 0){
			$arrStates = $this->Country_helper->getStatesByCountryId($arrKolDetail['country_id']);
		}
		if($arrKolDetail['state_id'] 	!= 0){
			$arrCities 					= $this->Country_helper->getCitiesByStateId($arrKolDetail['state_id']);
		}
		$arrKolDetail['profile_type']	= 'Full Profile';
		$data['arrStates']	= $arrStates;
		$data['arrCities']	= $arrCities;
		$data['arrKols']	= $arrKolDetail;
		$data['kolId']		= 0;
		//$this->load->view('kols/client_pre_kol',$data);
		$this->load->view('surveys/add_client_kol',$data);
	}
	function add_client_org($orgId){
		$arrData['orgData']	= $this->survey->getOrgName($orgId);
		$arrData['arrCountry']	= $this->Country_helper->listCountries();
		if($arrData['orgData']['org_id']>0){
			$arrData['orgData']		= $this->survey->getOrgDataByOrgId($arrData['orgData']['org_id']);
			if($arrData['orgData']['state_id'] != 0){
				$arrData['arrState']	= $this->Country_helper->getStatesByCountryId($arrData['orgData']['country_id']);
			}
			if($arrData['orgData']['city_id'] != 0){
				$arrData['arrCity']	= $this->Country_helper->getCitiesByStateId($arrData['orgData']['state_id']);
			}
		}
		$this->load->view('organizations/add_client_org',$arrData);
	}
	function add_client_org_request($orgId){
		$arrData['orgData']		= $this->survey->getOrgDataByOrgId($orgId);
		$arrData['arrCountry']	= $this->Country_helper->listCountries();
		if($arrData['orgData']['state_id'] != 0){
			$arrData['arrState']	= $this->Country_helper->getStatesByCountryId($arrData['orgData']['country_id']);
		}
		if($arrData['orgData']['city_id'] != 0){
			$arrData['arrCity']	= $this->Country_helper->getCitiesByStateId($arrData['orgData']['state_id']);
		}
//		pr($arrData['orgData']);
		$this->load->view('organizations/add_client_org',$arrData);
	}
	function extend_date(){
		$arrData['id']		= $this->input->post('id');
		$arrData['endDate']	= $this->input->post('end_date');
		echo $this->load->view('surveys/extend_survey',$arrData,false);
	}
	function save_extended_date(){
		$arrData['id']			= $this->input->post('survey_id');
		$arrData['end_date']	= app_date_to_sql_date($this->input->post('end_date'));
		$this->survey->saveExtendedDate($arrData);
		$status = STATUS_UPDATED;
		$this->update->insertUpdateEntry(SURVEY_STATUS_UPDATE,$status, MODULE_SURVEY, $arrData['id'],$status);
		redirect('surveys/list_surveys');
	}
	function autosave_survey($id=null){
		$arrSurveyData	= array();
		$arrReturnData	= array();
		$arrSurveyData['name']			= trim($this->input->post('survey_name'));
		$arrSurveyData['question_ids']	= implode(',',$this->input->post('question_ids'));
		$arrSurveyData['description']	= trim($this->input->post('description'));
	//	$arrSurveyData['is_active']		= $this->input->post('is_active');
		$arrSurveyData['start_date']	= app_date_to_sql_date($this->input->post('start_date'));
		$arrSurveyData['end_date']		= app_date_to_sql_date($this->input->post('end_date'));
		$arrUserIds						= $this->input->post('users');
		$arrGroupIds					= $this->input->post('groups');
		if(!empty($arrUserIds)){
			$arrSurveyData['user_ids']		= implode(',',$arrUserIds);
		}
		if(!empty($arrUserIds)){
			$arrSurveyData['group_ids']		= implode(',',$arrGroupIds);
		}
		if($id!=null && $id>0){
			$arrSurveyData['id']		= $id;
			$arrReturnData	= $this->survey->updateSurvey($arrSurveyData);
			if(USER_LOGS){
				
				$arrLogs = userLogData();
				$arrLogs['type_id'] = $id;
				//pr($arrLogs);
				if($arrReturnData['status']=='saved'){
					
					$arrLogs['type'] = SURVEY_UPDATE;
					$arrLogs['note'] = "Updated Survey";
					$this->survey->saveUserLog($arrLogs);
					//echo $this->db->last_query();
				}else{
					$arrLogs['type'] = SURVEY_UPDATE_FAILED;
					$arrLogs['note'] = "Failed to Update Survey";
					$this->survey->saveUserLog($arrLogs);
				}
			}
		}else{
			
			$arrReturnData	= $this->survey->saveSurvey($arrSurveyData);
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add New Survey',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => '',
					'transaction_id' =>  $arrReturnData['id'],
					'transaction_table_id' => SURVEYS,
					'transaction_name' => 'Add New Survey',
					'form_data' => json_encode($arrSurveyData),
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
			if(USER_LOGS){
				
				$arrLogs = userLogData();
				//pr($arrLogs);
				$arrLogs['type_id'] = $arrReturnData['id'];
			
				if($arrReturnData['status']=='saved'){
					
					$arrLogs['type'] = SURVEY_ADD;
					$arrLogs['note'] = "Added Survey";
					$this->survey->saveUserLog($arrLogs);
					//echo $this->db->last_query();
				}else{
					$arrLogs['type'] = SURVEY_ADD_FAILED;
					$arrLogs['note'] = "Failed to add Survey";
					$this->survey->saveUserLog($arrLogs);
				}
			}
		}
		ob_start('ob_gzhandler');
		echo json_encode($arrReturnData);
	}
	function save_query(){
		$arrData	= array();
		$arrQuery	= array();
		$arrData['created_by']	= $this->session->userdata('user_id');
		$arrData['type']		= trim($this->input->post('is_predefined'));
		$arrData['name']		= trim($this->input->post('query_name'));
		$arrQuery['nominee_name']		= $this->input->post('nominee_Name');
		$arrQuery['nominee_specialty']	= $this->input->post('nominee_specialty');
		$arrQuery['nominee_type']		= $this->input->post('nominee_type');
		$arrQuery['nominee_country']	= $this->input->post('nominee_country');
		$arrQuery['nominee_state']		= $this->input->post('nominee_state');
		$arrQuery['nominee_city']		= $this->input->post('nominee_city');
		$arrQuery['nominee_postal']		= $this->input->post('nominee_postal');
		$arrQuery['respondent_id']		= $this->input->post('respondent_id');
		$arrQuery['respondent_state']	= $this->input->post('respondent_state');
		$arrQuery['respondent_city']	= $this->input->post('respondent_city');
		$arrQuery['respondent_postal']	= $this->input->post('respondent_postal');
		$arrData['query']	= json_encode($arrQuery);
		$this->survey->saveQuery($arrData);
	}
	function name_combination($arrWords,$base_string){
		$arrNameCombinations= array();
		$numOfWords 		= sizeof($arrWords);
	    foreach ($arrWords as $key => $elem){
	    	if(!empty($elem)){
		        $new_string = trim($base_string . " " . $elem);
		        $wordsCount	= explode(' ',$new_string);
		       // if(sizeof($wordsCount)>1){
		        	$arrNameCombinations[] = $new_string;
		       // }
		        $new_array = $arrWords;
		        unset($new_array[$key]);
		        $arrNameCombinations = array_merge($arrNameCombinations, $this->name_combination ($new_array, $new_string));
	    	}
	    }
		return $arrNameCombinations;
	}
	function load_search_names_old(){
		$page				= (int)$this->input->post('page'); // get the requested page
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$arrData['limit']	= $limit;
		$arrData['offset']	= $page*$limit;
		$arrName			= explode(' ',trim($this->input->post('name')));
		if(sizeof($arrName)==1 && $arrName[0]==""){
			$arrData['name']	= '';
		}else{
			$arrData['name']	= $arrName;
		}
		$arrData['orgname']		= trim($this->input->post('orgname'));
		$arrData['country']		= trim($this->input->post('country'));
		$arrData['state']		= trim($this->input->post('state'));
		$arrData['city']		= trim($this->input->post('city'));
		$arrData['postal']		= trim($this->input->post('postal'));
		$arrResult	= $this->survey->searchNames($arrData);
		$count		= sizeof($arrResult);
		if( $count >0 ){
			$total_pages = ceil($count/$limit);
		}else{
			$total_pages = 0;
		}
		$data['records']= $count;
		$data['total']  = $total_pages;
		$data['page']	= $page;
		$data['rows']	= $arrResult;
		ob_start('ob_gzhandler');
		echo json_encode($data);
	}
	function search_names($isRespondentOrInfluencer,$appendId){
		$arrData['name']		= trim($this->input->post('name'));
		$arrData['orgname']		= trim($this->input->post('orgname'));
		$arrData['country']		= trim($this->input->post('country'));
		$arrData['state']		= trim($this->input->post('state'));
		$arrData['city']		= trim($this->input->post('city'));
		$arrData['postal']		= trim($this->input->post('postal'));
		$arrData['isRespondentOrInfluencer']		= $isRespondentOrInfluencer;
		$arrData['appendId']	= $appendId;
		$arrData['queryData']	= $arrData;
		$this->load->view('surveys/searched_name_results',$arrData);
	}
	
	/*
	 * Loads the survey influence map page
	 * @author Ramesh B
	 * @since Otsuka
	 * @created 15-05-2012
	 */
	function view_network_map(){
		$data['arrCompletedSurveys']	= $this->survey->getCompletedSurveys();
		$data['arrTypes']				= $this->arrSurveyTypes;
		$data['contentPage']			= 'surveys/view_network_map';
		$this->load->view('layouts/client_view', $data);
	}
	
	/*
	 * Prepares the survey influence data using the given submitted parameters as a filters
	 * @author Ramesh B
	 * @since Otsuka
	 * @created 16-05-2012
	 */
	function get_survey_influence_data(){
		ini_set("max_execution_time",86400);
		//Get all the filters submited as a post data
		$arrData	= array();
		$arrData['survey_id']	= $this->input->post('survey_id');
		
		
		/*$arrData['specialty']	= $this->input->post('nominee_specialty');
		$arrData['respondent_state']	= $this->input->post('respondent_state');
		$arrData['respondent_city']		= $this->input->post('respondent_city');
		$arrData['respondent_postal']	= $this->input->post('respondent_postal');*/
		
		$arrFilters = $_POST;
		$arrData['type']		= $this->input->post('influencer_type');
		if(isset($arrFilters['influencer_ids'])){
			$arrData['name']		= $this->input->post('influencer_ids');
			if($arrData['name'][0] == "All Influencers")
				array_shift($arrData['name']);
		}
		if(isset($arrFilters['country_ids'])){
			$arrData['country']		= $this->input->post('country_ids');
			if($arrData['country'][0] == "All Countries")
				array_shift($arrData['country']);
				
		}
		if(isset($arrFilters['state_ids'])){
			$arrData['state']		= $this->input->post('state_ids');
			if($arrData['state'][0] == "All States")
				array_shift($arrData['state']);
				
		}
		if(isset($arrFilters['city_ids'])){
			$arrData['city']		= $this->input->post('city_ids');
			if($arrData['city'][0] == "All Cities")
				array_shift($arrData['city']);
				
		}
		
		if(isset($arrFilters['postalcode_ids'])){
			$arrData['postal']		= $this->input->post('postalcode_ids');
			if($arrData['postal'][0] == "All Postalcodes")
				array_shift($arrData['postal']);
				
		}
		if(isset($arrFilters['respondent_ids'])){
			$arrData['respondent_id']		= $this->input->post('respondent_ids');
			if($arrData['respondent_id'][0] == "All Respondents")
				array_shift($arrData['respondent_id']);
				
		}
		if(isset($arrFilters['user_ids'])){
			$arrData['user_ids']		= $this->input->post('user_ids');
			if($arrData['user_ids'][0] == "All Users")
				array_shift($arrData['user_ids']);
				
		}
		//pr($arrData);
		
		if(empty($arrData['user_ids']) && empty($arrData['type']) && empty($arrData['state']) && empty($arrData['city']) && empty($arrData['respondent_id']) && empty($arrData['name'])){
		
			$userId = $this->session->userdata('user_id');
					//$userId=44;
			$stateId = $this->session->userdata('state_id');
			//$stateId=$this->session->userdata('state_id');
			//$stateId =$this->session->userdata('user_id');
			$stateName = $this->session->userdata('state');
			$name = $this->session->userdata('user_full_name');
			$count = $this->survey->chkCountOfNombers($arrFilters['survey_id'],$userId,$stateId,true);
			if($count==0){
					if($stateId!=''){
						$count = $this->survey->chkCountOfNombers($arrFilters['survey_id'],$userId,$stateId,false);
					//echo $this->db->last_query();
					}else{
						$count=0;
					}
					if($count==0){
						//$stateName =$this->survey->getTopState($arrFilters['survey_id']);
						//echo $this->db->last_query();
						//if($stateName!=''){
							//$arrData['state'][]=$stateName;
						//}
						$arrData['type']=2;
					}else{
						$arrData['state'][]=$stateName;
					}
				}else{
					$arrData['user_ids'][]=$name;
					//$arrData['state_ids'][]=$stateName;
				}		
		}
		//Get the array result of connections by passing the filter parameters
		$startTime=microtime(true);
		$arrResults = $this->survey->getSurveyNomineesToRespondentConnnecions($arrData['survey_id'],$arrData);
		//echo $this->db->last_query();
		$timeTaken=microtime(true)-$startTime;
		//echo "Total time taken by query : ".$timeTaken."<br />";	
		//echo  $this->db->last_query()."<br />";
		
		//Prepare an array of connections with respect to each unique nomineeId as a key
		//$startTime=microtime(true);
		$arrConnectonData =array();
		//Array to hold unique pairs, used for checking the bi-directonal/2 way influence
		$arrPairs = array();
		foreach($arrResults as $row){
			$arrConnectonData[$row['nominee_id']][] = $row;
			$arrPairs[] = $row['nominee_id'].$row['respondent_id'];
		}
		if(empty($arrData['user_ids'])){
			$name = $this->session->userdata('user_full_name');
			$arrData['user_ids'][]=$name;
		}
		//Prepare the data as per the map requirement
		$timeTaken1=microtime(true)-$startTime;
		//echo "Total time taken for first array preparation : ".$timeTaken1."<br />";
		$startTime=microtime(true);
		$arrData = array();
		$arrRespondents = array();
		foreach($arrConnectonData as $nomineeId => $arrConnections){
			$nomKolId = $arrConnections[0]['nom_kol_id'];
			//Create Nominee node details
			$nodeDetails= array();
			$nodeDetails['name'] = $arrConnections[0]['nom_name'];
			//if the nomines is not profiled, show that in different color
			if($nomKolId != 0 && $arrConnections[0]['nom_status'] == COMPLETED){
				$nodeDetails['id'] = "kol-".$nomKolId;
				$nodeDetails['data']['$color'] = '#7DA8EB';
			}else{
				$nodeDetails['id'] = "req-".$nomineeId;
				$nodeDetails['data']['$color'] = '#E36C6A';
			}
			
			//Prepare Nominee connections details
			$arrAdjecencies = array();
			foreach($arrConnections as $connection){
				$respKolId = $connection['resp_kol_id'];
				$respondentId = $connection['respondent_id'];;
				$adjecencyDetails = array();
				//if the respondent is not profiled
				if($respKolId != 0  && $connection['resp_status'] == COMPLETED){
					$adjecencyDetails['nodeTo'] = "kol-".$respKolId;
					//$adjecencyDetails['data']['$direction'] = array("kol-".$respKolId,$nodeDetails['id']);
					$adjecencyDetails['data']['$direction'] = array($nodeDetails['id'],"kol-".$respKolId);
				}
				else{
					$adjecencyDetails['nodeTo'] = "req-".$respondentId;
					//$adjecencyDetails['data']['$direction'] = array("req-".$respondentId,$nodeDetails['id']);
					$adjecencyDetails['data']['$direction'] = array($nodeDetails['id'],"req-".$respondentId);
				}
				//check if the influencer is infleunced repsondent in the survey, i.e identify bi-directonal/2 way influence
				/*if($this->checkIsByDirectional($nomineeId,$arrConnectonData[$respondentId]))
					$adjecencyDetails['data']['$type'] = 'double_arrow';
				else{
					$adjecencyDetails['data']['$type'] = 'arrow';
				}*/
				if(in_array($respondentId.$nomineeId,$arrPairs))
					$adjecencyDetails['data']['$type'] = 'double_arrow';
				else{
					$adjecencyDetails['data']['$type'] = 'arrow';
				}
				
				//$adjecencyDetails['data']['$color'] = '#4F81BD';
				$adjecencyDetails['data']['$dim'] = 8;
				$adjecencyDetails['data']['$lineWidth'] = 0.6;
				$adjecencyDetails['data']['conn'] = $connection['num_noms'];
				$arrAdjecencies[] = $adjecencyDetails;
				//collect respondent details
				$arrRespondents[$connection['respondent_id']] = $connection;
			}
			$nodeDetails['adjacencies'] = $arrAdjecencies;
			$nodeDetails['data']['$dim'] = 3;
			$arrData[] = $nodeDetails;
		}
		//add remaining respondents as nodes, these are the respondents who don't have any nominations
		foreach($arrRespondents as $id => $connection){
			//proceed only if it is not an nominee, i.e node details are not added
			if (!array_key_exists($id, $arrConnectonData)) {
				$respKolId = $connection['resp_kol_id'];
				$respondentId = $connection['respondent_id'];;
			    $nodeDetails= array();
				$nodeDetails['name'] = $connection['resp_name'];
				//if the nominess is not profiled, show that in different color
				if($respKolId != 0 && $connection['resp_status'] == COMPLETED){
					$nodeDetails['id'] = "kol-".$respKolId;
					$nodeDetails['data']['$color'] = '#7DA8EB';
				}
				else{
					$nodeDetails['id'] = "req-".$respondentId;
					$nodeDetails['data']['$color'] = '#E36C6A';
				}
				$nodeDetails['data']['$dim'] = 3;
				$arrData[] = $nodeDetails;
			}
		}
		
		$timeTaken=microtime(true)-$startTime;
		//echo "Total time taken to Prepare the data: ".$timeTaken."<br />";
		
		ob_start('ob_gzhandler');
		echo json_encode($arrData);
	}
	
	function get_survey_influence_data_mobile(){
		ini_set("max_execution_time",86400);
		//Get all the filters submited as a post data
		$arrData	= array();
		$arrData['survey_id']	= $this->input->post('survey_id');
		
		//$arrData['survey_id']=18;
		
		/*$arrData['specialty']	= $this->input->post('nominee_specialty');
		$arrData['respondent_state']	= $this->input->post('respondent_state');
		$arrData['respondent_city']		= $this->input->post('respondent_city');
		$arrData['respondent_postal']	= $this->input->post('respondent_postal');*/
		
		$arrFilters = $_POST;
		if($arrData['survey_id']=='undefined'){
			$details['arrSurveys']	= $this->survey->getCompletedSurveys();
			$arrData['survey_id']					= $details['arrSurveys'][0]['id'];
			$arrFilters['survey_id'] = $arrData['survey_id'];
		}
		$arrData['type']		= $this->input->post('influencer_type');
		if(isset($arrFilters['influencer_ids'])){
			$arrData['name']		= $this->input->post('influencer_ids');
			if($arrData['name'][0] == "All Influencers")
				array_shift($arrData['name']);
		}
		if(isset($arrFilters['country_ids'])){
			$arrData['country']		= $this->input->post('country_ids');
			if($arrData['country'][0] == "All Countries")
				array_shift($arrData['country']);
				
		}
		if(isset($arrFilters['state_ids'])){
			$arrData['state']		= $this->input->post('state_ids');
			if($arrData['state'][0] == "All States")
				array_shift($arrData['state']);
				
		}
		if(isset($arrFilters['city_ids'])){
			$arrData['city']		= $this->input->post('city_ids');
			if($arrData['city'][0] == "All Cities")
				array_shift($arrData['city']);
				
		}
		
		if(isset($arrFilters['postalcode_ids'])){
			$arrData['postal']		= $this->input->post('postalcode_ids');
			if($arrData['postal'][0] == "All Postalcodes")
				array_shift($arrData['postal']);
				
		}
		if(isset($arrFilters['respondent_ids'])){
			$arrData['respondent_id']		= $this->input->post('respondent_ids');
			if($arrData['respondent_id'][0] == "All Respondents")
				array_shift($arrData['respondent_id']);
				
		}
		if(isset($arrFilters['user_ids'])){
			$arrData['user_ids']		= $this->input->post('user_ids');
			if($arrData['user_ids'][0] == "All Users")
				array_shift($arrData['user_ids']);
		}
		if(isset($arrFilters['territory_ids'])){
			$arrData['territory_ids']		= $this->input->post('territory_ids');
			if($arrData['territory_ids'][0] == "All Territories")
				array_shift($arrData['territory_ids']);
		}
		if(isset($arrFilters['region_ids'])){
			$arrData['region_ids']		= $this->input->post('region_ids');
			if($arrData['region_ids'][0] == "All Regions")
				array_shift($arrData['region_ids']);
		}
		if(isset($arrFilters['district_ids'])){
			$arrData['district_ids']		= $this->input->post('district_ids');
			if($arrData['district_ids'][0] == "All Districts")
				array_shift($arrData['district_ids']);
		}
		
		//if(empty($arrData['user_ids']) && empty($arrData['type']) && empty($arrData['state']) && empty($arrData['city']) && empty($arrData['respondent_id']) && empty($arrData['name']) && empty($arrData['territory_ids']) && empty($arrData['region_ids']) && empty($arrData['district_ids'])){
		if(empty($arrData['user_ids']) && empty($arrData['type']) && empty($arrData['state']) && empty($arrData['city']) && empty($arrData['respondent_id']) && empty($arrData['name'])){
		
			$userId = $this->session->userdata('user_id');
					//$userId=44;
			$stateId = $this->session->userdata('state_id');
			//$stateId=$this->session->userdata('state_id');
			//$stateId =$this->session->userdata('user_id');
			$stateName = $this->session->userdata('state');
			$name = $this->session->userdata('user_full_name');
			$count = $this->survey->chkCountOfNombers($arrFilters['survey_id'],$userId,$stateId,true);
			if($count==0){
					$arrData['user_ids'][]=$name;
					$arr['topauthors'] ='';
				
					$arr['links'] = '';
					$arr['names'] = '';
					$arr['names'] = $arrNames;
					
				//	pr($arr);
					ob_start('ob_gzhandler');
					echo json_encode($arr);
					return false;
				}else{
					$arrData['user_ids'][]=$name;
					//$arrData['state_ids'][]=$stateName;
				}		
		}
		//Get the array result of connections by passing the filter parameters
		$startTime=microtime(true);
		$arrResults = $this->survey->getSurveyNomineesToRespondentConnnecions($arrData['survey_id'],$arrData);
		//echo $this->db->last_query();
		//pr($arrResults);
		
		$links = array();
		$arrNames = array();
		foreach($arrResults as $row){
			$arrLinks = array();
			if( $row['nom_kol_id']!=''){
			$arrLinks['source'] = $row['nom_kol_id'];
			$arrLinks['target'] = $row['respondent_id'];
			$arrLinks['type'] = 'licensing';
			$links[]=$arrLinks;
			}
			//$arrNames[]
		}
		
		foreach($arrResults as $row){
			if( $row['nom_kol_id']!=''){
			$arrNames[$row['nom_kol_id']]['name'] = $row['nom_name'];
			$arrNames[$row['nom_kol_id']]['city'] = $row['city'];
			$arrNames[$row['nom_kol_id']]['state'] = $row['nstate_name'];
			$arrNames[$row['nom_kol_id']]['postal'] = $row['nom_postal'];
					$arrNames[$row['nom_kol_id']]['mid'] = $row['nmid'];
			//$arrNames[$row['nom_kol_id']]['city'] = $row['city_name'];
			$arrNames[$row['respondent_id']]['city'] = $row['respondent_city'];
			$arrNames[$row['respondent_id']]['state'] = $row['rstate_name'];
			$arrNames[$row['respondent_id']]['postal'] = $row['resp_postal'];
			$arrNames[$row['respondent_id']] ['name']= $row['resp_name'];
			$arrNames[$row['respondent_id']]['mid'] = $row['rmid'];
		
			}
			
		}
	
		foreach($arrResults as $row){
			$topAuthors[$row['nom_kol_id']][]=$row;
		}
		foreach($topAuthors  as $key=>$value){
			$topAuthors1[(string)($key)] = count($value);
		}
		arsort($topAuthors1);
		//pr($topAuthors1);
		$topAuthors3=array_flip($topAuthors1);
		//pr($topAuthors3);
		$topAuthors4 = array_slice($topAuthors3,0,10);
	//pr($topAuthors2);
		//pr($topAuthors4);
		foreach($topAuthors4 as $row){
			$topAuthors5[]=(string)$row;
		}
		
		//	pr($topAuthors5);
		$arr['topauthors'] =$topAuthors5;
	//	pr($topAuthors1);
		$arr['links'] = $links;
		$arr['names'] = $arrNames;
		
	//	pr($arr);
		ob_start('ob_gzhandler');
		echo json_encode($arr);
		
		
		
		//echo json_encode($arrData);
	}
	
	/*
	 * Checks if the influencer is infleunced repsondent in the survey, i.e identify bi-directonal/2 way influence
	 * @author Ramesh B
	 * @since Otsuka
	 * @created 16-05-2012
	 */
	function checkIsByDirectional($nomineeId,$respondentConnections,$respondentId = null){
		$hasConnection = false;
		if($respondentId == null){
			foreach($respondentConnections as $connection){
				if($connection['respondent_id'] == $nomineeId){
					$hasConnection = true;
					break;
				}
			}
		}else{
			$count = 0;
			foreach($respondentConnections as $connection){
				if(($connection['nominee_id'] == $nomineeId && $connection['respondent_id'] == $respondentId) || ($connection['nominee_id'] == $respondentId && $connection['respondent_id'] == $nomineeId)){
					$count++;
				}
				if($count == 2){
					$hasConnection = true;
					break;
				}
			}
		}
		return $hasConnection;
	}
	
	/*
	 * Prepares the indivisual person survey influence data using the given submitted parameters as a filters
	 * @author Ramesh B
	 * @since Otsuka
	 * @created 17-05-2012
	 */
	function get_indivisual_survey_influence_data($id){
		ini_set("max_execution_time",86400);
		//Get all the filters submited as a post data
		$arrData	= array();
		$arrData['survey_id']	= $this->input->post('survey_id');
		$arrData['inf_org']		= trim($this->input->post('inf_org'));
		$arrData['inf_state']	= trim($this->input->post('inf_state'));
		$arrData['inf_city']	= trim($this->input->post('inf_city'));
		$arrData['inf_country']	= trim($this->input->post('inf_country'));
		$arrData['inf_postal']	= trim($this->input->post('inf_postal'));
		
		$arrData['nomineeId']	= $id;
		
		$arrFilters = $_POST;
		$arrData['type']		= $this->input->post('influencer_type');
		if(isset($arrFilters['influencer_ids'])){
			$arrData['name']		= $this->input->post('influencer_ids');
			if($arrData['name'][0] == "All Influencers")
				array_shift($arrData['name']);
		}
		if(isset($arrFilters['country_ids'])){
			$arrData['country']		= $this->input->post('country_ids');
			if($arrData['country'][0] == "All Countries")
				array_shift($arrData['country']);
				
		}
		if(isset($arrFilters['state_ids'])){
			$arrData['state']		= $this->input->post('state_ids');
			if($arrData['state'][0] == "All States")
				array_shift($arrData['state']);
				
		}
		if(isset($arrFilters['city_ids'])){
			$arrData['city']		= $this->input->post('city_ids');
			if($arrData['city'][0] == "All Cities")
				array_shift($arrData['city']);
				
		}
		
		if(isset($arrFilters['postalcode_ids'])){
			$arrData['postal']		= $this->input->post('postalcode_ids');
			if($arrData['postal'][0] == "All Postalcodes")
				array_shift($arrData['postal']);
				
		}
		if(isset($arrFilters['respondent_ids'])){
			$arrData['respondent_id']		= $this->input->post('respondent_ids');
			if($arrData['respondent_id'][0] == "All Respondents")
				array_shift($arrData['respondent_id']);
				
		}
		if(isset($arrFilters['user_ids'])){
			$arrData['user_ids']		= $this->input->post('user_ids');
			if($arrData['user_ids'][0] == "All Users")
				array_shift($arrData['user_ids']);
				
		}
		
		//Get the array result of connections by passing the filter parameters
		$arrResults = $this->survey->getSurveyNomineesToRespondentConnnecions($arrData['survey_id'],$arrData);
		$arrRespIds = array();
		foreach ($arrResults as $row){
			$arrRespIds[] = $row['respkolid'];
		}
		$arr1 = $this->survey->getTopNomineeByRespIds($arrRespIds);
		$arrRes = array();
		$dupResults = $arrResults;
		if(count($arr1)>0){
			foreach ($arr1 as $row){
				foreach ($arrResults as $k => $row1){
					if($row1['respondent_id'] == $row['nomkolid']){
						$arrRes[] = $row1;
						unset($dupResults[$k]);
					}
				}
			}
		}
		if(count($arrRes) > 0){
			$arrResults = array_merge(array_values($arrRes),array_values($dupResults));
		}
		//Prepare the data as per the map requirement
		$arrData = array();
		$parentNodeDetails = array();
		$surveyKolNameDetails = $this->survey->getNameDetails($id);
		//if the nominess is not profiled, show that in different color
		if($surveyKolNameDetails['kol_id'] != 0){
			//$parentNodeDetails['id'] = "kol-".$surveyKolNameDetails['kol_id'];
			$parentNodeDetails['id'] = "req-".$id;
			$parentNodeDetails['data']['$color'] = '#7DA8EB';
		}else{
			$parentNodeDetails['id'] = "req-".$id;
			$parentNodeDetails['data']['$color'] = '#E36C6A';
		}
		$parentNodeDetails['name'] = $surveyKolNameDetails['name'];
		$parentNodeDetails['data']['$dim'] = 5;
		$arrAdjacencies = array();
		$arrConnectionNodes = array();
		$z = 1;
		$arrIds = array();
		//pr($arrResults);exit;
		foreach($arrResults as $connection){
			//pr($connection);exit;
			if($z <= 20){
				$adjecencyDetails= array();
				$connectionNode = array();
				$nomKolId = $connection['nom_kol_id'];
				$nomineeId = $connection['nomkolid'];
				$respKolId = $connection['respkolid'];
				$respondentId = $connection['respkolid'];
				if($nomineeId == $respondentId)
					continue;
				if( $nomineeId == $id){
					
					//if the nominess is not profiled, show that in different color
					if($respKolId != 0){
						$adjecencyDetails['nodeTo'] = "req-".$respondentId;
						//$adjecencyDetails['data']['$direction'] = array("req-".$respondentId,$parentNodeDetails['id']);
						$adjecencyDetails['data']['$direction'] = array($parentNodeDetails['id'],"req-".$respondentId);
						$connectionNode['data']['$color'] = '#7DA8EB';
					}
					else{
						$adjecencyDetails['nodeTo'] = "req-".$respondentId;
						//$adjecencyDetails['data']['$direction'] = array("req-".$respondentId,$parentNodeDetails['id']);
						$adjecencyDetails['data']['$direction'] = array($parentNodeDetails['id'],"req-".$respondentId);
						$connectionNode['data']['$color'] = '#E36C6A';
					}
					//check if the influencer is infleunced repsondent in the survey, i.e identify bi-directonal/2 way influence
					if($this->checkIsByDirectional($nomineeId,$arrResults,$respondentId))
						$adjecencyDetails['data']['$type'] = 'double_arrow';
					else{
						$adjecencyDetails['data']['$type'] = 'arrow';
					}
					//add connection node
					$connectionNode['id'] = $adjecencyDetails['nodeTo'];
					$connectionNode['name'] = $connection['resp_name'];
					//$connectionNode['data']['$dim'] = 5;
					$arrConnectionNodes[] = $connectionNode;
					
				}else{
					//pr($connection);exit;
					//check if the influencer is infleunced repsondent in the survey
					if($this->checkIsByDirectional($respondentId,$arrResults,$nomineeId)){
						$adjecencyDetails['data']['$type'] = 'double_arrow';
						//if the nominess is not profiled, show that in different color
						if($nomKolId != 0){
							$adjecencyDetails['nodeTo'] = "req-".$nomineeId;
							//$adjecencyDetails['data']['$direction'] = array($parentNodeDetails['id'],"req-".$nomineeId);
							$adjecencyDetails['data']['$direction'] = array("req-".$nomineeId,$parentNodeDetails['id']);
							$connectionNode['data']['$color'] = '#7DA8EB';
						}
						else{
							$adjecencyDetails['nodeTo'] = "req-".$nomineeId;
							//$adjecencyDetails['data']['$direction'] = array($parentNodeDetails['id'],"req-".$nomineeId);
							$adjecencyDetails['data']['$direction'] = array("req-".$nomineeId,$parentNodeDetails['id']);
							$connectionNode['data']['$color'] = '#E36C6A';
						}
						//add connection node
						$connectionNode['id'] = $adjecencyDetails['nodeTo'];
						$connectionNode['name'] = $connection['nom_name'];
						$arrConnectionNodes[] = $connectionNode;
					}else
						continue;
				}
				
				$adjecencyDetails['data']['$lineWidth'] = 1;
				$adjecencyDetails['data']['conn'] = $connection['num_noms'];
				$arrAdjacencies[] = $adjecencyDetails;
			}
			$z++;
			$arrIds[]=$connection['respondent_id'];
		}
		$parentNodeDetails['adjacencies'] = $arrAdjacencies;
		$arrData[] = $parentNodeDetails;
		$arrData['data'] = array_merge($arrData, $arrConnectionNodes);
//		$arrData['ids'] = $arrIds;
		$gridData = array();
		foreach ($arrResults as $row){
			if($row['respondent_id'] != $id)
			$gridData[] = $row; 
		}
		$arrData['gridData']=$gridData;
//		pr($gridData);
//		exit;
		ob_start('ob_gzhandler');
		echo json_encode($arrData);	
	}
	
	function get_geo_influence_data(){
		ini_set("max_execution_time",86400);
		//Get all the filters submited as a post data
		$arrData	= array();
		$arrData['survey_id']	= $this->input->post('survey_id');
		
		
		/*$arrData['specialty']	= $this->input->post('nominee_specialty');
		$arrData['respondent_state']	= $this->input->post('respondent_state');
		$arrData['respondent_city']		= $this->input->post('respondent_city');
		$arrData['respondent_postal']	= $this->input->post('respondent_postal');*/
		
		$arrFilters = $_POST;
		if($arrData['survey_id']=='undefined'){
			$details['arrSurveys']	= $this->survey->getCompletedSurveys();
			$arrData['survey_id']					= $details['arrSurveys'][0]['id'];
			$arrFilters['survey_id'] = $arrData['survey_id'];
		}
		$arrData['type']		= $this->input->post('influencer_type');
		if(isset($arrFilters['influencer_ids'])){
			$arrData['name']		= $this->input->post('influencer_ids');
			if($arrData['name'][0] == "All Influencers")
				array_shift($arrData['name']);
		}
		if(isset($arrFilters['country_ids'])){
			$arrData['country']		= $this->input->post('country_ids');
			if($arrData['country'][0] == "All Countries")
				array_shift($arrData['country']);
				
		}
		if(isset($arrFilters['state_ids'])){
			$arrData['state']		= $this->input->post('state_ids');
			if($arrData['state'][0] == "All States")
				array_shift($arrData['state']);
				
		}
		if(isset($arrFilters['city_ids'])){
			$arrData['city']		= $this->input->post('city_ids');
			if($arrData['city'][0] == "All Cities")
				array_shift($arrData['city']);
				
		}
		
		if(isset($arrFilters['postalcode_ids'])){
			$arrData['postal']		= $this->input->post('postalcode_ids');
			if($arrData['postal'][0] == "All Postalcodes")
				array_shift($arrData['postal']);
				
		}
		if(isset($arrFilters['respondent_ids'])){
			$arrData['respondent_id']		= $this->input->post('respondent_ids');
			if($arrData['respondent_id'][0] == "All Respondents")
				array_shift($arrData['respondent_id']);
				
		}
		if(isset($arrFilters['user_ids'])){
			$arrData['user_ids']		= $this->input->post('user_ids');
			if($arrData['user_ids'][0] == "All Users")
				array_shift($arrData['user_ids']);
				
		}
		if(isset($arrFilters['territory_ids'])){
			$arrData['territory_ids']		= $this->input->post('territory_ids');
			if($arrData['territory_ids'][0] == "All Territories")
				array_shift($arrData['territory_ids']);
		}
		if(isset($arrFilters['region_ids'])){
			$arrData['region_ids']		= $this->input->post('region_ids');
			if($arrData['region_ids'][0] == "All Regions")
				array_shift($arrData['region_ids']);
		}
		if(isset($arrFilters['district_ids'])){
			$arrData['district_ids']		= $this->input->post('district_ids');
			if($arrData['district_ids'][0] == "All Districts")
				array_shift($arrData['district_ids']);
		}
		//pr($arrData['user_ids']);

	//if($arrFilters['active_tab'] == 'influencersGeoMapTab' || $arrFilters['active_tab']=='influencersNetworkMapTab'){
		//if(empty($arrData['user_ids']) && empty($arrData['type']) && empty($arrData['state']) && empty($arrData['city']) && empty($arrData['respondent_id']) && empty($arrData['territory_ids']) && empty($arrData['region_ids']) && empty($arrData['district_ids']) && empty($arrData['name'])){
		if(empty($arrData['user_ids']) && empty($arrData['type']) && empty($arrData['state']) && empty($arrData['city']) && empty($arrData['respondent_id']) && empty($arrData['name'])){
				$userId = $this->session->userdata('user_id');
				//$userId=44;
				$name = $this->session->userdata('user_full_name');
				//$stateId=$this->session->userdata('state_id');
				$stateId = $this->session->userdata('state_id');
				$stateName = $this->session->userdata('state');
				$count = $this->survey->chkCountOfNombers($arrFilters['survey_id'],$userId,$stateId,true);
				if($count==0){
					/*if($stateId!=''){
						$count = $this->survey->chkCountOfNombers($arrFilters['survey_id'],$userId,$stateId,false);
					//echo $this->db->last_query();
					}else{
						$count=0;
					}
					if($count==0){
						//$stateName =$this->survey->getTopState($arrFilters['survey_id']);
						//echo $this->db->last_query();
						//if($stateName!=''){
							//$arrData['state'][]=$stateName;
						//}
						$arrData['type']=2;
					}else{
						$arrData['state'][]=$stateName;
					}*/
					$arrData['user_ids'][]=$name;
				}else{
					$arrData['user_ids'][]=$name;
					//$arrData['state_ids'][]=$stateName;
				}
				//echo $useChk;
			//	pr($arrData);
			//}
		}
		//pr($arrData['user_ids']);
		$array['lat'] = array();
		$arry['lang'] = array();
		$arrResults = $this->survey->getSurveyNomineesToRespondentConnnecionsForGeo($arrData['survey_id'],$arrData);
	//	echo $this->db->last_query();
		//$startTime=microtime(true);
		//$arrResults = $this->survey->getSurveyNomineesToRespondentConnnecionsForGeo($arrData['survey_id'],$arrData);
		//$timeTaken=microtime(true)-$startTime;
		//echo "Total time taken by query : ".$timeTaken."<br />";	
		//echo  $this->db->last_query()."<br />";
		$i=1;
		//$startTime=microtime(true);
		$val =mt_rand(1, 10);
		$selectedState=array();
		
		
		 $mobile = mobile_device_detect();
		// pr($mobile);
		 if($mobile[1]=='Apple iPad'){
		 //	$arrResults = array_slice($arrResults,0,100);
		 }
	//	pr($arrResults);
		foreach($arrResults as $row){
			$key = in_array($row['nom_name'],$array['names'] );
				if(($row['nomineLat']!='')){
				if(in_array($row['nomineLat'],$array['lat']) && !($key)){
					$val =mt_rand(1, 10);
					$random_num_lat = .00065 * mt_rand(1, 10);
					$random_num_lng = .00065 * mt_rand(1, 10);
					$row['nomineLat'] = $row['nomineLat']+('0.00'.mt_rand(1, 10));
					$array['lat'][] = $row['nomineLat'];
					$array['names'][$row['nom_name']] = $row['nom_name'];
					$array['names1'][$row['nom_name']]['lat'][] =$row['nomineLat'];
					$array['names1'][$row['nom_name']]['lat'][] =$row['nom_name'];
				}else{
					//$row['nomineLat'] = $array['names'][$row['nom_name']]['lat'];
					$array['lat'][] = $row['nomineLat'];
					$array['names'][$row['nom_name']] = $row['nom_name'];
				}
			}
			if($i==1){
				if($arrData['state']!=''){
					
					foreach($arrData['state'] as $state){
						if($row['state']==$state){
							$selectedState['selectedLat'] = $row['nomineLat'];
							$selectedState['selectedLang'] = $row['nominelang'];
							$i++;
						}
					}
				}
			}
			
			$arrLangAndLat[]=$row;
		}
	//	pr($array['names1']);
		foreach($arrLangAndLat as $row1){
			foreach($array['names1'] as $lat){
				if($lat['lat'][1] == $row1['nom_name']){
					$row1['nomineLat']  = $lat['lat'][0];
				}
			}
			
			$arrDetails[] = $row1;
		}
		
		//pr($arr);
		//pr($arrDetails);
		$arrData1['kols'] = $arrDetails;
		$arrData1['selectedState'] = $selectedState;
		//$arrData1['filters'] = $arrData;
		//$timeTaken=microtime(true)-$startTime;
		//echo "Total time taken to prepare the data : ".$timeTaken."<br />";
		ob_start('ob_gzhandler');
		echo json_encode($arrData1);
	}
	
	function view_geo_map(){
			$this->load->model('survey');
			$data['arrCompletedSurveys']	= $this->survey->getCompletedSurveys();
			$data['arrTypes']				= $this->arrSurveyTypes;
			$data['contentPage']			= 'surveys/view_geo_map';
			$this->load->view('layouts/client_view', $data);
		}
	
	function get_info(){
		$arr =array();
		$type = $this->input->post('type');
		$id = $this->input->post('id');
		/*$kols2 = $this->input->post('kols');
		$kols =  json_decode($kols2);
		//pr($kols);
		/*$name = $this->input->post('name');
		foreach($kols as $key=>$row){
			$row1=(array)$row;
			
			if($row1['resp_name'] == $name){
				$arrDetails1 =array();
				$lat = $row1['nomineLat']; 
				$lang = $row1['nominelang']; 
				$arrDetails1['lat']=$lat;
				$arrDetails1['long']=$lang;
				$arrDetails1['respLat']=$row1['resoLat']; ;
				$arrDetails1['respLong']=$row1['resoLang']; ;
				
				$arr[]=$arrDetails1;
			}
			
		}*/
		

		$arResult = $this->survey->getSurveyKolInfo($id,$type);
		if($type=='respondent'){
			$adress = array($arResult['respondent_city'],$arResult['respondent_state'],$arResult['respondent_postal'],$arResult['respondent_country']);
		}else{
			$adress = array($arResult['city'],$arResult['state'],$arResult['postal'],$arResult['country']);
		}
		//pr($adress);
		foreach($adress as $key=>$value){
			if(trim($value=='')){
				unset($adress[$key]);
			}
		}
		$arResult['address'] = implode(', ',$adress);
	
		//pr($data['rowData']['address']);
		//$arResult['respondents']= $arr;
		ob_start('ob_gzhandler');
		echo json_encode($arResult);
	}
	
	/*
	 * generate seed data for particular survey
	 * @author Laxman K
	 * @since Otsuka
	 * @created 18-06-2013
	 */
	//function seed_data($surveyId=0,$noOfUsers=10,$noOfRespondents=20,$noOfInfluencers=40){
	function seed_data(){
		$surveyId		= $this->input->post('survey_id');
		$noOfUsers		= $this->input->post('no_of_users');
		$noOfRespondents	= $this->input->post('no_of_respondents');
		$noOfInfluencers	= $this->input->post('no_of_influencers');
		$countryIds	= $this->input->post('country_id');
		$cityIds	= $this->input->post('city_id');
		$stateIds	= $this->input->post('state_id');
		if(!$noOfUsers>0){
			$noOfUsers=10;
		}
		if(!$noOfRespondents>0){
			$noOfRespondents=20;
		}
		if(!$noOfInfluencers>0){
			$noOfInfluencers=30;
		}
		if($surveyId>0){
			$i			= 0; 
			$textData	= '';
			$separator	= '';
			$createdOn	= date("Y-m-d H:i:s");
			$userId		= $this->session->userdata('user_id');
			$arrTypes		= $this->arrSurveyTypes;
			$arrSurveyData	= $this->survey->getActiveSurveyQuestions($surveyId);
			$arrSurveys		= $arrSurveyData['arrQuestionData'];
			$arrUsers		= $this->survey->getUsersForSeedData($noOfUsers);
			$arrRespondents	= $this->survey->getKolsForSeedData($noOfRespondents);
			$arrInfluencers	= $this->survey->getKolsForSeedData($noOfInfluencers,$countryIds,$stateIds,$cityIds);
			$preparedStatements	= "insert into survey_answers(question_id,country,state,city,postal,nominee_id,nominee_org_id,respondent_id,respondent_org_id,respondent_country,respondent_state,respondent_city,respondent_postal,created_by,created_on,survey_id,is_submitted,respondent_city_id,nominee_city_id) values ";
			foreach($arrSurveys as $categoryName => $arrSurveys){
			 foreach($arrSurveys as $key => $arrQuestionRow){
				$i++;
				$textData	.= '<tr class="tableSubHeader">
						<th class="alignTop borderBottom">'.$i.')</th>
						<th class="borderBottom" colspan="6">'.$arrQuestionRow['question'].'( Tags: '.$arrTypes[$arrQuestionRow['type_id']].', '.$categoryName.', '.$arrQuestionRow['role'].' )</th>
					</tr>
					<tr>
						<th></th>
						<th class="alignCenter">Created By</th>
						<th class="alignCenter">Respondent</th>
						<th class="alignCenter">Influencer</th>
						<th class="alignCenter">Organization</th>
						<th class="alignCenter">City</th>
						<th class="alignCenter">State</th>
						<th class="alignCenter">Country</th>
						<th class="alignCenter">Postal Code</th>
					</tr>';
				foreach($arrUsers as $userIndex=>$arrUserRow){
					$userId	= $arrUserRow['id'];
				 	foreach($arrRespondents as $key=>$arrRow){
				 		$arrValidateData['created_by']	= $userId;
				 		$arrValidateData['survey_id']	= $surveyId;
				 		$arrValidateData['respondent_name']	= $arrRow['name'];
				 		$arrStatus	= $this->survey->isRespondentAlreadySurveyed($arrValidateData);
				 		if($arrStatus['status']=="new"){
							$rand_keys = array_rand($arrInfluencers, 5);
							$arrKolData['name']		= $arrRow['name'];
							$arrKolData['kol_id']	= $arrRow['id'];
							$respondentId		= $this->survey->saveSurveyKolName($arrKolData);
							$respondentOrgId	= $this->survey->saveSurveyOrgname($arrRow['orgname']);
							foreach($rand_keys as $index=>$influencersIndex){
								if($arrRow['name']==$arrInfluencers[$influencersIndex]['name']){
									$influencersIndex++;
								}
								$textData	.= '<tr>
									<td></td>
									<td>'.$arrUserRow['username'].'</td>
									<td>'.$arrRow['name'].'</td>
									<td>'.$arrInfluencers[$influencersIndex]['name'].'</td>
									<td>'.$arrInfluencers[$influencersIndex]['orgname'].'</td>
									<td>'.$arrInfluencers[$influencersIndex]['city'].'</td>
									<td>'.$arrInfluencers[$influencersIndex]['state'].'</td>
									<td>'.$arrInfluencers[$influencersIndex]['country'].'</td>
									<td>'.$arrInfluencers[$influencersIndex]['postal'].'</td>
								</tr>';
								$arrNomineeData['name']		= $arrInfluencers[$influencersIndex]['name'];
								$arrNomineeData['kol_id']	= $arrInfluencers[$influencersIndex]['id'];
								$nomineeId		= $this->survey->saveSurveyKolName($arrNomineeData);
								$nomineeOrgId	= $this->survey->saveSurveyOrgname($arrInfluencers[$influencersIndex]['orgname']);
								$preparedStatements	.= $separator.'("'.$arrQuestionRow['id'].'","'.$arrInfluencers[$influencersIndex]['country'].'","'.$arrInfluencers[$influencersIndex]['state'].'","'.$arrInfluencers[$influencersIndex]['city'].'","'.$arrInfluencers[$influencersIndex]['postal'].'","'.$nomineeId.'","'.$nomineeOrgId.'","'.$respondentId.'","'.$respondentOrgId.'","'.$arrRow['country'].'","'.$arrRow['state'].'","'.$arrRow['city'].'","'.$arrRow['postal'].'","'.$userId.'","'.$createdOn.'","'.$surveyId.'","1","'.$arrRow['city_id'].'","'.$arrInfluencers[$influencersIndex]['city_id'].'")';
								$separator		= ',';
							}
				 		}
				 	}
				 }
				}
			}
			$this->db->query($preparedStatements);
			$arrData['textData']	= $textData;
			$arrData['contentPage']	= 'surveys/seed_data';
			$this->load->view('layouts/client_view', $arrData);
		}
	}
	
	/*
	 * Options to generate seed data for particular survey
	 * @author Laxman K
	 * @since Otsuka
	 * @created 12-09-2013
	 */
	function seed_data_options(){
		$arrData['arrCompletedSurveys']	= $this->survey->getActiveSurveys();
		$arrData['arrCountry']			= $this->Country_helper->listCountries();
		$arrData['contentPage']			= 'surveys/seed_data_options';
		$this->load->view('layouts/client_view', $arrData);
	}
	
	function survey_profile_form(){
		$arrData	= array();
		$arrProfileData	= array();
		$arrProfileData['kolname']	= $this->input->post('first_name');
		pr($_POST);
		$arrData['arrSurveys']		= $this->survey->getActiveSurveys();
		$arrData['arrRespondent']	= $arrProfileData;
		$arrData['contentPage']	= 'surveys/kol_survey_form';
		$this->load->view('layouts/client_view', $arrData);
	}
	function report(){
		$clientId = $this->session->userdata('client_id');
		$userId	=$this->session->userdata('user_id');
		$email	= $this->session->userdata('email');
		$showReports =true;
		if($showReports){
			$arrSelections	= array();
			$filterData['arrTypes']		= $this->arrSurveyTypes;
			$filterData['arrSurveys']	= $this->survey->getCompletedSurveys();
			
			//echo $this->db->last_query();
			$surveyId					= $filterData['arrSurveys'][0]['id'];
			//$filterData['arrFiltersData']	= $this->survey->getSurveyFilterDetails($surveyId);
		//	$filterData['arrFiltersData']['influencers']	= $this->survey->getSurveySelectedFilterDetails($surveyId,$arrSelections,'influencer');
			
			//$filterData['arrFiltersData']['countries']	= $this->survey->getSurveySelectedFilterDetails($surveyId,$arrSelections,'country');
			/////$filterData['arrFiltersData']['states']	= $this->survey->getSurveySelectedFilterDetails($surveyId,$arrSelections,'state');
			//$filterData['arrFiltersData']['cities']	= $this->survey->getSurveySelectedFilterDetails($surveyId,$arrSelections,'city');
			//$filterData['arrFiltersData']['postalcodes']	= $this->survey->getSurveySelectedFilterDetails($surveyId,$arrSelections,'postalcode');
			//$filterData['arrFiltersData']['respondents']	= $this->survey->getSurveySelectedFilterDetails($surveyId,$arrSelections,'respondent');
			//$filterData['arrFiltersData']['users']	= $this->survey->getSurveySelectedFilterDetails($surveyId,$arrSelections,'user');
			$details['resultsData']		= $arrResultsData;
			$details['filterData']		= $filterData;
			$details['resultsPage']		= 'surveys/report_result';
			$details['filterPage']		= 'surveys/report_filter_li_style';
			$data['data']				= $details;
		
		}
		$data['showReports'] = $showReports;
		$data['contentPage'] 		= 'surveys/reports';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited surveys report Page",
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
				'kols_or_org_id' => '',
				'transaction_name' => "Viewed surveys report Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/client_view',$data);
	//	}else{
	//		redirect(base_url());
	//	}
	}
	function load_filters(){
		//pr($_POST);
		$filterData['activeTab'] = $this->input->post('active_tab');
		$arrSelections					= $this->formatFilterSelections($_POST);
		//pr($arrSelections);
		$filterData['arrSelections']	= $this->getFiltersValuesById($arrSelections);
		$filterData['arrTypes']			= $this->arrSurveyTypes;
		$filterData['arrSurveys']		= $this->survey->getCompletedSurveys();
		$filterData['arrFiltersData']['users']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'user');
		//$filterData['arrFiltersData']	= $this->survey->getSurveyFilterDetails($arrSelections['survey_id'],$arrSelections);
		$filterData['arrFiltersData']['influencers']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'influencer');
		//pr($this->db->last_query());exit;
		//$filterData['arrFiltersData']['countries']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'country');
		$filterData['arrFiltersData']['states']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'state');
		$filterData['arrFiltersData']['cities']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'city');
		$filterData['arrFiltersData']['postalcodes']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'postalcode');
		$filterData['arrFiltersData']['respondents']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'respondent');
		//pr($filterData['arrFiltersData']['states']);
		//exit;
		/* 
		//pr($filterData['arrFiltersData']['states']);
		$filterData['arrFiltersData']['cities']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'city');
		//echo $this->db->last_query();
		$filterData['arrFiltersData']['postalcodes']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'postalcode');
		$filterData['arrFiltersData']['respondents']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'respondent');
		$filterData['arrFiltersData']['users']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'user');
		$filterData['arrFiltersData']['territory']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'territory');
		$filterData['arrFiltersData']['region']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'region');
		//echo $this->db->last_query();
	//	pr($filterData['arrFiltersData']['region']);
		$filterData['arrFiltersData']['district']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'district'); */
		$filters	= $this->load->view('surveys/report_filter_li_style',$filterData,false);
		//ob_start('ob_gzhandler');
		//json_encode($filters);
		echo $filters;
		//$this->load->view('surveys/report_filter_li_style',$filterData);
	}
	
	function load_influencer_filters(){
		$filterData['activeTab'] = $this->input->post('active_tab');
		$arrSelections					= $this->formatFilterSelectionsInfluencer($_POST);
		$filterData['arrSelections']	= $this->getFiltersValuesById($arrSelections);
		$filterData['arrTypes']			= $this->arrSurveyTypes;
		$filterData['arrSurveys']		= $this->survey->getCompletedSurveys();
		//$filterData['arrFiltersData']	= $this->survey->getSurveyFilterDetails($arrSelections['survey_id'],$arrSelections);
		//$filterData['arrFiltersData']['influencers']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'influencer');
		$filterData['arrFiltersData']['countries']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'country');
		$filterData['arrFiltersData']['states']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'state');
		//pr($filterData['arrFiltersData']['states']);
		$filterData['arrFiltersData']['cities']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'city');
		//echo $this->db->last_query();
		$filterData['arrFiltersData']['postalcodes']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'postalcode');
		//$filterData['arrFiltersData']['respondents']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'respondent');
		$filterData['arrFiltersData']['users']	= $this->survey->getSurveySelectedFilterDetails($arrSelections['survey_id'],$arrSelections,'user');
		$filters	= $this->load->view('surveys/report_filter_li_style_influencer',$filterData,false);
		//ob_start('ob_gzhandler');
		//json_encode($filters);
		echo $filters;
		//$this->load->view('surveys/report_filter_li_style',$filterData);
	}
	function load_report_result(){
		$arrSelections	= array();
		$arrSelections	= $this->formatFilterSelections($_POST);
		$arrResult		= $this->survey->load_query_result($arrSelections);
		//echo $this->db->last_query();
		unset($arrSelections['survey_id']);
		$arrReturnData	= array('data'=>$arrResult,'query'=>$arrSelections);
		ob_start('ob_gzhandler');
		echo json_encode($arrReturnData);
	}
	function getFiltersValuesById($arrFilters){
		foreach($arrFilters as $key=>$value){
			switch($key){
				case 'nominee':
					if(is_array($arrFilters[$key]['name'])){
						$arrFilters[$key]['name']	= $this->survey->getNamesById($value['name']);
					}
				break;
				case 'respondents':
					if(is_array($arrFilters[$key]['respondent']))
					$arrFilters[$key]['respondent']	= $this->survey->getNamesById($value['respondent']);
				break;
			}
		}
		return $arrFilters;
	}
	function formatFilterSelections($arrFilters){
		//pr($arrFilters);
		if($arrFilters['influencer_ids'][0]=="All Influencers"){
			array_shift($arrFilters['influencer_ids']);
		}
		if($arrFilters['country_ids'][0]=="All Countries"){
			//unset($arrFilters['country_ids'][0]);
			array_shift($arrFilters['country_ids']);
		}
		if($arrFilters['state_ids'][0]=="All States"){
			//unset($arrFilters['state_ids'][0]);
			array_shift($arrFilters['state_ids']);
		}
		if($arrFilters['city_ids'][0]=="All Cities"){
			//unset($arrFilters['city_ids'][0]);
			array_shift($arrFilters['city_ids']);
		}
		
		if($arrFilters['postalcode_ids'][0]=="All Postalcodes"){
			array_shift($arrFilters['postalcode_ids']);
		}
		if($arrFilters['respondent_ids'][0]=="All Respondents"){
			array_shift($arrFilters['respondent_ids']);
		}
		if($arrFilters['user_ids'][0]=="All Users"){
			array_shift($arrFilters['user_ids']);
		}
		if($arrFilters['territory_ids'][0]=="All Territories"){
			array_shift($arrFilters['territory_ids']);
		}
		if($arrFilters['region_ids'][0]=="All Regions"){
			array_shift($arrFilters['region_ids']);
		}
		if($arrFilters['district_ids'][0]=="All Districts"){
			array_shift($arrFilters['district_ids']);
		}
		//pr($this->session->userdata);
		//if($arrFilters['active_tab'] == 'influencersGeoMapTab' || $arrFilters['active_tab']=='influencersNetworkMapTab'){
			if(empty($arrFilters['user_ids']) && empty($arrFilters['influencer_type']) && empty($arrFilters['influencer_type']) && empty($arrFilters['state_ids']) && empty($arrFilters['city_ids']) && empty($arrFilters['respondent_ids']) && empty($arrFilters['influencer_ids'])){
				
				$userId = $this->session->userdata('user_id');
				//$userId=44;
				$stateId = $this->session->userdata('state_id');
				//$stateId=$this->session->userdata('state_id');
				$name =$this->session->userdata('user_full_name');
				$stateName = $this->session->userdata('state');
				$count = $this->survey->chkCountOfNombers($arrFilters['survey_id'],$userId,$stateId,true);
				if($count==0){
					if($stateId!=''){
					$count = $this->survey->chkCountOfNombers($arrFilters['survey_id'],$userId,$stateId,false);
					//echo $this->db->last_query();
					}else{
						$count=0;
					}
					//echo $this->db->last_query();
					if($count==0){
//						$arrFilters['influencer_type']=2;
						//$stateName =$this->survey->getTopState($arrFilters['survey_id']);
					//	echo $this->db->last_query();
						//if($stateName!=''){
							//$arrFilters['state_ids'][]=$stateName;
						//}
					}else{
						$arrFilters['state_ids'][]=$stateName;
					}
				}else{
					$arrFilters['user_ids'][]=$name;
					//$arrFilters['state_ids'][]=$stateName;
				}
				//echo $useChk;
				
			}
		//}
		
	
		//pr($arrFilters);
		$arrData['survey_id']			= $arrFilters['survey_id'];
		$arrData['nominee']['type']		= ($arrFilters['influencer_type']==0)?"":$arrFilters['influencer_type'];
		$arrData['nominee']['name']		= (sizeof($arrFilters['influencer_name'])<1)?"":$arrFilters['influencer_name'];
		$selectedInfluencerId		= (sizeof($arrFilters['influencer_ids'])>0)?$arrFilters['influencer_ids'][0] :"";
		if($selectedInfluencerId>0){
			$arrData['nominee']['id'][$selectedInfluencerId]	= $selectedInfluencerId;
		}
		//$arrData['nominee']['id']		= (sizeof($arrFilters['influencer_ids'])<1)?"":$arrFilters['influencer_ids'][0];
		$arrData['nominee']['city']		= (sizeof($arrFilters['city_ids'])<1)?"":$arrFilters['city_ids'];
		$arrData['nominee']['country']	= (sizeof($arrFilters['country_ids'])<1)?"":$arrFilters['country_ids'];
		$arrData['nominee']['state']	= (sizeof($arrFilters['state_ids'])<1)?"":$arrFilters['state_ids'];
		$arrData['nominee']['postal']	= (sizeof($arrFilters['postalcode_ids'])<1)?"":$arrFilters['postalcode_ids'];
		$arrData['respondents']['respondent']	= (sizeof($arrFilters['respondent_ids'])<1)?"":$arrFilters['respondent_ids'];
		$arrData['users']['user']	= (sizeof($arrFilters['user_ids'])<1)?"":$arrFilters['user_ids'];
		$arrData['territories']['territory']	= (sizeof($arrFilters['territory_ids'])<1)?"":$arrFilters['territory_ids'];
		$arrData['regions']['region']	= (sizeof($arrFilters['region_ids'])<1)?"":$arrFilters['region_ids'];
		$arrData['districts']['district']	= (sizeof($arrFilters['district_ids'])<1)?"":$arrFilters['district_ids'];
		//pr($arrData);
		return $arrData;
	}
	
function formatFilterSelectionsInfluencer($arrFilters){
		//pr($arrFilters);
		if($arrFilters['influencer_ids'][0]=="All Influencers"){
			array_shift($arrFilters['influencer_ids']);
		}
		if($arrFilters['country_ids'][0]=="All Countries"){
			//unset($arrFilters['country_ids'][0]);
			array_shift($arrFilters['country_ids']);
		}
		if($arrFilters['state_ids'][0]=="All States"){
			//unset($arrFilters['state_ids'][0]);
			array_shift($arrFilters['state_ids']);
		}
		if($arrFilters['city_ids'][0]=="All Cities"){
			//unset($arrFilters['city_ids'][0]);
			array_shift($arrFilters['city_ids']);
		}
		
		if($arrFilters['postalcode_ids'][0]=="All Postalcodes"){
			array_shift($arrFilters['postalcode_ids']);
		}
		if($arrFilters['respondent_ids'][0]=="All Respondents"){
			array_shift($arrFilters['respondent_ids']);
		}
		if($arrFilters['user_ids'][0]=="All Users"){
			array_shift($arrFilters['user_ids']);
		}
	
		//pr($arrFilters);
		$arrData['survey_id']			= $arrFilters['survey_id'];
		$arrData['nominee']['type']		= ($arrFilters['influencer_type']==0)?"":$arrFilters['influencer_type'];
		$arrData['nominee']['name']		= (sizeof($arrFilters['influencer_ids'])<1)?"":$arrFilters['influencer_ids'];
		$arrData['nominee']['city']		= (sizeof($arrFilters['city_ids'])<1)?"":$arrFilters['city_ids'];
		$arrData['nominee']['country']	= (sizeof($arrFilters['country_ids'])<1)?"":$arrFilters['country_ids'];
		$arrData['nominee']['state']	= (sizeof($arrFilters['state_ids'])<1)?"":$arrFilters['state_ids'];
		$arrData['nominee']['postal']	= (sizeof($arrFilters['postalcode_ids'])<1)?"":$arrFilters['postalcode_ids'];
		$arrData['respondents']['respondent']	= (sizeof($arrFilters['respondent_ids'])<1)?"":$arrFilters['respondent_ids'];
		$arrData['users']['user']	= (sizeof($arrFilters['user_ids'])<1)?"":$arrFilters['user_ids'];
		//pr($arrData);
		return $arrData;
	}

	function get_suggestions_for_autocomplete_refineby($type,$surveyId,$keyword){
		if($surveyId == 'All')
			$surveyId = '';
		$keyword		= utf8_urldecode($this->input->post($keyword));
		$arrSuggestions	= array();
		$arrAutocompleteData 	= $this->survey->getSuggestionsForAutocompleteRefineBy($type,$surveyId,$keyword);
		//pr($this->db->last_query());exit;
		//pr($arrAutocompleteData);exit;
		if((sizeof($arrAutocompleteData))<1){
			$arrSuggestions[]	= '<div style="padding-left:5px;">No results found for '.$keyword.'</div><div><label name="No results found for '.$keyword.'" class="suggestion" style="display:block"></label><label class="suggestionDetails"></label><span style="display:none" class="id1"></span></div>';
		}else{
			foreach($arrAutocompleteData as $key=>$row){
				if($type=='territory'){
					$name=$row['name'].'('.$row['territory_id'].')';
					$arrSuggestions[]='<div class="dataSet"><label name="'.$name.'" class="suggestion" style="display:block">'.$name.'</label><label>'.$row[1].'</label><span style="display:none" class="uid">'.$key.'</span></div>';
				}else{
					$arrSuggestions[]='<div class="dataSet"><label name="'.$row['name'].'" class="suggestion" style="display:block">'.$row['name'].'</label><label>'.$row[1].'</label><span style="display:none" class="uid">'.$key.'</span></div>';
				}
			}
		}
		$arrData['query']		= $keyword;
		$arrData['suggestions']	= $arrSuggestions;
		echo json_encode($arrData);
	}
	
	function update_state_name(){
		ini_set("max_execution_time",7200);
		$this->db->select('id,respondent_state,respondent_country');
		$this->db->where("(CHAR_LENGTH(respondent_state)=2)");
		$arrStatesResultSet = $this->db->get('survey_answers');
		foreach($arrStatesResultSet->result_array() as $row){
			$arrStates[] = $row;
		}
		foreach($arrStates as $key=>$value){
			$this->db->select('region');
			$this->db->join('countries','countries.CountryId=regions.CountryID','left');
			$this->db->where('code',$value['respondent_state']);
			$this->db->where('country',$value['respondent_country']);
			$arrSate = $this->db->get('regions');
			//pr($arrSate->num_rows());
			//echo $arrSate->num_rows();
			if($arrSate->num_rows()!=0){
				$array=array();
				$state = $arrSate->result_array();
				$array['respondent_state']= $state[0]['region'];
				$array['id'] = $value['id'];
				$this->db->where('id',$value['id']);
				$this->db->update('survey_answers',$array);
				//echo $this->db->last_query();
			}
		}
	}
	
	function update_nominee_state_name(){
		ini_set("max_execution_time",7200);
		$this->db->select('id,state,country');
		$this->db->where("(CHAR_LENGTH(state)=2)");
		
		$arrStatesResultSet = $this->db->get('survey_answers');
			//echo $this->db->last_query();
		foreach($arrStatesResultSet->result_array() as $row){
			$arrStates[] = $row;
		}
		foreach($arrStates as $key=>$value){
			$this->db->select('region');
			$this->db->join('countries','countries.CountryId=regions.CountryID','left');
			$this->db->where('code',$value['state']);
			$this->db->where('country',$value['country']);
			$arrSate = $this->db->get('regions');
		
			//pr($arrSate->num_rows());
			//echo $arrSate->num_rows();
			if($arrSate->num_rows()!=0){
				$array=array();
				$state = $arrSate->result_array();
				$array['state']= $state[0]['region'];
				$array['id'] = $value['id'];
				$this->db->where('id',$value['id']);
				$this->db->update('survey_answers',$array);
				//echo $this->db->last_query();
			}
		}
	}
	
	function update_city_id(){
		$this->db->select('id,nominee_city_id,city,state');
		$this->db->where("(nominee_city_id=0 and city!='' and state!='')");
		$arrSate = $this->db->get('survey_answers');
		//echo $this->db->last_query();
		foreach($arrSate->result_array() as $row){
			$arrData[]=$row;
		}
		
		foreach($arrData as $city){
			$city['nominee_city_id'] = $this->survey->getCityIdByNameAndState($city['city'],$city['state']);
			//pr($city);
			$this->db->where('id',$city['id']);
			$this->db->update('survey_answers',$city);
			echo $this->db->last_query();
		}
		//pr($arrData);
	} 
	
	function update_respondent_city_id(){
		$this->db->select('id,respondent_city_id,respondent_city,respondent_state');
		$this->db->where("(respondent_city_id=0 and respondent_city!='' and respondent_state!='')");
		$arrSate = $this->db->get('survey_answers');
		//echo $this->db->last_query();
		foreach($arrSate->result_array() as $row){
			$arrData[]=$row;
		}
		
		foreach($arrData as $city){
			$city['respondent_city_id'] = $this->survey->getCityIdByNameAndState($city['respondent_city'],$city['respondent_state']);
			//pr($city);
			$this->db->where('id',$city['id']);
			$this->db->update('survey_answers',$city);
			echo $this->db->last_query();
		}
		//pr($arrData);
	}
	/*
	 * Prepares the survey influence data using the given submitted parameters as a filters
	 * @author Ramesh B
	 * @since Otsuka
	 * @created 16-05-2012
	 */
	function get_survey_influence_data_old(){
		ini_set("max_execution_time",86400);
		//Get all the filters submited as a post data
		$arrData	= array();
		$arrData['survey_id']	= $this->input->post('survey_id');
		$arrData['name']		= $this->input->post('nominee_Name');
		$arrData['type']		= $this->input->post('nominee_type');
		$arrData['specialty']	= $this->input->post('nominee_specialty');
		$arrData['city']		= $this->input->post('nominee_city');
		$arrData['state']		= $this->input->post('nominee_state');
		$arrData['country']		= $this->input->post('nominee_country');
		$arrData['postal']		= $this->input->post('nominee_postal');
		
		$arrData['respondent_id']		= $this->input->post('respondent_id');
		$arrData['respondent_state']	= $this->input->post('respondent_state');
		$arrData['respondent_city']		= $this->input->post('respondent_city');
		$arrData['respondent_postal']	= $this->input->post('respondent_postal');
		
		//Get the array result of connections by passing the filter parameters
		$startTime=microtime(true);
		$arrResults = $this->survey->getSurveyNomineesToRespondentConnnecions($arrData['survey_id'],$arrData);
		$timeTaken=microtime(true)-$startTime;
		//echo "Total time taken by query : ".$timeTaken."<br />";	
		//echo  $this->db->last_query()."<br />";
		
		//Prepare an array of connections with respect to each unique nomineeId as a key
		//$startTime=microtime(true);
		$arrConnectonData =array();
		//Array to hold unique pairs, used for checking the bi-directonal/2 way influence
		$arrPairs = array();
		foreach($arrResults as $row){
			$arrConnectonData[$row['nominee_id']][] = $row;
			$arrPairs[] = $row['nominee_id'].$row['respondent_id'];
		}
		
		//Prepare the data as per the map requirement
		$timeTaken1=microtime(true)-$startTime;
		//echo "Total time taken for first array preparation : ".$timeTaken1."<br />";
		$startTime=microtime(true);
		$arrData = array();
		$arrRespondents = array();
		foreach($arrConnectonData as $nomineeId => $arrConnections){
			$nomKolId = $arrConnections[0]['nom_kol_id'];
			//Create Nominee node details
			$nodeDetails= array();
			$nodeDetails['name'] = $arrConnections[0]['nom_name'];
			//if the nomines is not profiled, show that in different color
			if($nomKolId != 0 && $arrConnections[0]['nom_status'] == COMPLETED){
				$nodeDetails['id'] = "kol-".$nomKolId;
				$nodeDetails['data']['$color'] = '#7DA8EB';
			}else{
				$nodeDetails['id'] = "req-".$nomineeId;
				$nodeDetails['data']['$color'] = '#E36C6A';
			}
			
			//Prepare Nominee connections details
			$arrAdjecencies = array();
			foreach($arrConnections as $connection){
				$respKolId = $connection['resp_kol_id'];
				$respondentId = $connection['respondent_id'];;
				$adjecencyDetails = array();
				//if the respondent is not profiled
				if($respKolId != 0  && $connection['resp_status'] == COMPLETED){
					$adjecencyDetails['nodeTo'] = "kol-".$respKolId;
					//$adjecencyDetails['data']['$direction'] = array("kol-".$respKolId,$nodeDetails['id']);
					$adjecencyDetails['data']['$direction'] = array($nodeDetails['id'],"kol-".$respKolId);
				}
				else{
					$adjecencyDetails['nodeTo'] = "req-".$respondentId;
					//$adjecencyDetails['data']['$direction'] = array("req-".$respondentId,$nodeDetails['id']);
					$adjecencyDetails['data']['$direction'] = array($nodeDetails['id'],"req-".$respondentId);
				}
				//check if the influencer is infleunced repsondent in the survey, i.e identify bi-directonal/2 way influence
				/*if($this->checkIsByDirectional($nomineeId,$arrConnectonData[$respondentId]))
					$adjecencyDetails['data']['$type'] = 'double_arrow';
				else{
					$adjecencyDetails['data']['$type'] = 'arrow';
				}*/
				if(in_array($respondentId.$nomineeId,$arrPairs))
					$adjecencyDetails['data']['$type'] = 'double_arrow';
				else{
					$adjecencyDetails['data']['$type'] = 'arrow';
				}
				
				//$adjecencyDetails['data']['$color'] = '#4F81BD';
				$adjecencyDetails['data']['$dim'] = 8;
				$adjecencyDetails['data']['$lineWidth'] = 0.6;
				$adjecencyDetails['data']['conn'] = $connection['num_noms'];
				$arrAdjecencies[] = $adjecencyDetails;
				//collect respondent details
				$arrRespondents[$connection['respondent_id']] = $connection;
			}
			$nodeDetails['adjacencies'] = $arrAdjecencies;
			$nodeDetails['data']['$dim'] = 3;
			$arrData[] = $nodeDetails;
		}
		//add remaining respondents as nodes, these are the respondents who don't have any nominations
		foreach($arrRespondents as $id => $connection){
			//proceed only if it is not an nominee, i.e node details are not added
			if (!array_key_exists($id, $arrConnectonData)) {
				$respKolId = $connection['resp_kol_id'];
				$respondentId = $connection['respondent_id'];;
			    $nodeDetails= array();
				$nodeDetails['name'] = $connection['resp_name'];
				//if the nominess is not profiled, show that in different color
				if($respKolId != 0 && $connection['resp_status'] == COMPLETED){
					$nodeDetails['id'] = "kol-".$respKolId;
					$nodeDetails['data']['$color'] = '#7DA8EB';
				}
				else{
					$nodeDetails['id'] = "req-".$respondentId;
					$nodeDetails['data']['$color'] = '#E36C6A';
				}
				$nodeDetails['data']['$dim'] = 3;
				$arrData[] = $nodeDetails;
			}
		}
		
		$timeTaken=microtime(true)-$startTime;
		//echo "Total time taken to Prepare the data: ".$timeTaken."<br />";
		
		ob_start('ob_gzhandler');
		echo json_encode($arrData);
	}
	
	function get_geo_influence_data_old(){

		ini_set("max_execution_time",86400);

		$arrData	= array();

		

		$arrData['survey_id']	= $this->input->post('survey_id');

		$arrData['name']		= $this->input->post('nominee_Name');

		$arrData['type']		= $this->input->post('nominee_type');

		$arrData['specialty']	= $this->input->post('nominee_specialty');

		$arrData['city']		= $this->input->post('nominee_city');

		$arrData['state']		= $this->input->post('nominee_state');

		$arrData['country']		= $this->input->post('nominee_country');

		$arrData['postal']		= $this->input->post('nominee_postal');

		

		$arrData['respondent_id']		= $this->input->post('respondent_id');

		$arrData['respondent_state']	= $this->input->post('respondent_state');

		$arrData['respondent_city']		= $this->input->post('respondent_city');

		$arrData['respondent_postal']	= $this->input->post('respondent_postal');

		

		$array['lat'] = array();

		$arry['lang'] = array();

		$arrResults = $this->survey->getSurveyNomineesToRespondentConnnecionsForGeo($arrData['survey_id'],$arrData);

	//	echo $this->db->last_query();

		//$startTime=microtime(true);

		//$arrResults = $this->survey->getSurveyNomineesToRespondentConnnecionsForGeo($arrData['survey_id'],$arrData);

		//$timeTaken=microtime(true)-$startTime;

		//echo "Total time taken by query : ".$timeTaken."<br />";	

		//echo  $this->db->last_query()."<br />";

		$i=1;

		//$startTime=microtime(true);

		$val =mt_rand(1, 10);

		$selectedState=array();

		foreach($arrResults as $row){

			$key = in_array($row['nom_name'],$array['names'] );

			if(in_array($row['nomineLat'],$array['lat']) && !($key)){

				$val =mt_rand(1, 10);

				$random_num_lat = .00065 * mt_rand(1, 10);

				$random_num_lng = .00065 * mt_rand(1, 10);

				$row['nomineLat'] = $row['nomineLat']+('0.00'.mt_rand(1, 10));

				$array['lat'][] = $row['nomineLat'];

				$array['names'][$row['nom_name']] = $row['nom_name'];

				$array['names1'][$row['nom_name']]['lat'][] =$row['nomineLat'];

				$array['names1'][$row['nom_name']]['lat'][] =$row['nom_name'];

			}else{

				//$row['nomineLat'] = $array['names'][$row['nom_name']]['lat'];

				$array['lat'][] = $row['nomineLat'];

				$array['names'][$row['nom_name']] = $row['nom_name'];

			}

			

			if($i==1){

				if($arrData['state']!=''){

					

					foreach($arrData['state'] as $state){

						if($row['state']==$state){

							$selectedState['selectedLat'] = $row['nomineLat'];

							$selectedState['selectedLang'] = $row['nominelang'];

							$i++;

						}

					}

				}

			}

			

			$arrLangAndLat[]=$row;

		}

	//	pr($array['names1']);

		foreach($arrLangAndLat as $row1){

			foreach($array['names1'] as $lat){

				if($lat['lat'][1] == $row1['nom_name']){

					$row1['nomineLat']  = $lat['lat'][0];

				}

			}

			

			$arrDetails[] = $row1;

		}

		

		//pr($arr);

		//pr($arrDetails);

		$arrData1['kols'] = $arrDetails;

		$arrData1['selectedState'] = $selectedState;

		//$arrData1['filters'] = $arrData;

		//$timeTaken=microtime(true)-$startTime;

		//echo "Total time taken to prepare the data : ".$timeTaken."<br />";

		

		echo json_encode($arrData1);

	}
	
	function merge(){
		//$this->db->limit(10);
		$arrAnswres = $this->db->get('survey_answers_for_merge');
		
		foreach($arrAnswres->result_array() as $row){
			$arrData[]=$row;
		}
	//	echo count($arrData);
		foreach($arrData as $data){
			$answers = array();
			$icontactsNominee = array();
			$icontactsResondents = array();
			$answers['survey_id'] = $data['survey_id'];
			$answers['question_id'] = $data['question_id'];
			$answers['created_by'] = $data['created_by'];
			$answers['created_on'] = $data['created_on'];
			$answers['modified_by'] = $data['modified_by'];
			$answers['modified_on'] = $data['modified_on'];
			$answers['is_submitted'] = $data['is_submitted'];
		//	pr($data);
			$icontactsNominee['full_name'] = $data['nominee_name'];
			$icontactsNominee['country_id'] = $this->country_helper->getConcountryId($data['country']);
			if($data['state']!=''){
				$stateId= $this->kol->getStateIdByCountry($data['state'],$icontactsNominee['country_id']);
				$icontactsNominee['state_id'] 		= $stateId;
			}
			//pr($icontactsNominee);
			$icontactsNominee['city_id'] = $data['nominee_city_id'];
			$icontactsNominee['org_id'] = $this->survey->chk_org_name($data['nominee_org_name']);
			$answers['nominee_id'] = $this->survey->chk_name($icontactsNominee);
			
			
			
			//Respondent
			$icontactsResondents['full_name'] = $data['resp_name'];
			$icontactsResondents['country_id'] = $this->country_helper->getConcountryId($data['respondent_country']);
			if($data['respondent_state']!=''){
				$stateId= $this->kol->getStateIdByCountry($data['respondent_state'],$icontactsResondents['country_id']);
				$icontactsResondents['state_id'] 		= $stateId;
			}
			//pr($icontactsResondents);
			$icontactsResondents['city_id'] = $data['respondent_city_id'];
			$icontactsResondents['org_id'] = $this->survey->chk_org_name($data['resp_org_name']);
			//echo $this->db->last_query();
			$answers['respondent_id'] = $this->survey->chk_name($icontactsResondents);
			if($this->db->insert('survey_answers',$answers)){
				
			}else{
				echo $this->db->last_query()."<br />";
			}
			
			//$arr1[]=$answers;
			//
			
			
			//echo count($answers);
			
		}
		//pr($arr1);
	}
	
	function get(){
		ini_set("max_execution_time",7200);
		$this->db->limit(10000);
		$arrResultSet = $this->db->get('kols');
	
		//echo $arrResultSet->num_rows();
		foreach($arrResultSet->result_array() as $row){
			$arr[]=$row;
		}
		
		foreach($arr as $data){
			unset($data['salutation']);
			if($this->db->insert('icontacts',$data)){
				
			}else{
				echo $this->db->last_query();
			}
			
		}
		
	}
	
	function spilt(){
		$this->db->select('full_name,id');
		//$this->db->limit(1);
		$arrResult = $this->db->get('icontacts');
		foreach($arrResult->result_array() as $row){
			$data=array();
			$arrName= explode(' ',$row['full_name']);
			
			//pr($arrName);
			if(count($arrName)==1){
				
				$data['first_name'] = $arrName[0];
				$data['middle_name'] = '';
				$data['last_name'] ='';
			}
			if(count($arrName)==2){
				
				$data['first_name'] = $arrName[0];
				$data['last_name'] = $arrName[1];
				$data['middle_name'] = '';
			}
			
			if(count($arrName)==3){
				$data['first_name'] = $arrName[0];
				$data['middle_name'] = $arrName[1];
				$data['last_name'] = $arrName[2];
			}
			
			if(count($arrName)==4){
				$data['first_name'] = $arrName[0];
				$data['middle_name'] = $arrName[1];
				$data['last_name'] = $arrName[2]." ".$arrName[3];
			}
			if(count($arrName)>4){
				$data['first_name'] = $arrName[0];
				$data['middle_name'] = $arrName[1];
				unset($arrName[0]);
				unset($arrName[1]);
				
					$data['last_name'] = implode(' ',$arrName);
			}
			$data['id'] = $row['id'];
			pr($data);
			$this->db->where('id',$data['id']);
			$this->db->update('icontacts',$data);
			
		}
	}
	
	function get_Influencers_respondents($id){
		
		//$arrData['nominees'] = $this->survey->getNomineesAndRespondentName($id,'nominees');
	//	$arrData['respondents'] = $this->survey->getNomineesAndRespondentName($id,'resp');
		$arrSurveys	= array();
		$arrData	= array();
		$page		= (int)$this->input->post('page'); // get the requested page 
		$limit		= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$arrSurveysResults=$this->survey->getNomineesAndRespondentName($id,'nominees');
		
		//echo $this->db->last_query();	
		$count				= sizeof($arrSurveysResults);
		if( $count >0 ){
			$total_pages	= ceil($count/$limit);
		}else{
			$total_pages	= 0;
		}
		$arrData['records']	= $count;
		$arrData['total']	= $total_pages;
		$arrData['page']	= $page;
		$arrData['rows']	= $arrSurveysResults;
		//}
		ob_start('ob_gzhandler');
		echo json_encode($arrData);
		//pr($arrData);
	}
	
	function get_Influencers_by_id($id,$type){
		$arrSurveys	= array();
		$arrData	= array();
		$arrData['survey_id']	= $this->input->post('survey');
		$arrData['participant']	= $this->input->post('participant');
		$arrSelections			= $this->formatFilterSelectionsInfluencer($_POST);
		//pr($arrSelections);
		//$arrData['nominees'] = $this->survey->getNomineesAndRespondentName($id,'nominees');
	//	$arrData['respondents'] = $this->survey->getNomineesAndRespondentName($id,'resp');
		
		$page		= (int)$this->input->post('page'); // get the requested page 
		$limit		= (int)$this->input->post('rows'); // get how many rows we want to have into the grid   
		if($type=='nominees'){  	
				$arrSurveysResults=$this->survey->getNomineesAndRespondentName($id,'nominees',$arrSelections,$arrData);
		}else{
				$arrSurveysResults=$this->survey->getNomineesAndRespondentName($id,'resp',$arrSelections,$arrData);
		}
		
		$count				= sizeof($arrSurveysResults);
		if( $count >0 ){
			$total_pages	= ceil($count/$limit);
		}else{
			$total_pages	= 0;
		}
		$arrData1['records']	= $count;
		$arrData1['total']	= $total_pages;
		$arrData1['page']	= $page;
		$arrData1['rows']	= $arrSurveysResults;
		//}
		ob_start('ob_gzhandler');
		echo json_encode($arrSurveysResults);
		//pr($arrData);
	}
	
	function get_kol_names_for_autocomplete($kolName){
		$where = array();
		$where["country_name"] 	= trim($this->input->post("country_name"));
		$where["state_name"]	= trim($this->input->post("state_name"));
		$where["city_name"] 	= trim($this->input->post("city_name"));
		$where["postal_code"] 	= trim($this->input->post("postal_code"));
//		if(strlen($where["state_name"]) == 2){
//			$where["state_name"] = $this->country_helper->getStateNameByStateCode($where["state_name"]);
//		}
		$start = trim($this->input->post("offset"));
		if($start == '')
			$start = 0;
		$kolName		= trim(utf8_urldecode($this->input->post($kolName)));
		$kol = $kolName;
		$kolName = str_replace(","," ",$kolName);
		$kolName = preg_replace('!\s+!', ' ', $kolName);
		$where["name"] = $kolName; 
		
		$arrKolNames1	= array();
		$flag			= 1;
		
		$arrKolNames	= $this->survey->searchIcontactNames($where,$count=false,$start,$limit=50,$sord=null,$sidx=null,$isForMobile=false,$isAutoComplete=true);
//		$arrKolNames	= $this->survey->getIcontactAutocomplete($kolName,$where,$offset);
		foreach($arrKolNames['kols'] as $key=>$row){
//			pr($row);
			$arrKolNames1[]	= "<div class='autocompleteHeading'>Contacts</div><div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><span style='display:none' class='addressId'>$key</span><span style='display:none' class='id1'>".$key."</span></div>";
			/* if($flag && $start==0){
				//$arrKolNames1[]	= "<div class='autocompleteHeading'>Contacts</div><div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><label class='orgName'>$row[1]</label><span style='display:none' class='id1'>$key</span></div>";
				// removed org name
				if($row[3] != "")
					$arrKolNames1[]	= "<div class='autocompleteHeading'>Contacts</div><div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><span style='display:none' class='addressId'>$key</span><span style='display:none' class='id1'>".$row['kol_id']."</span><span style='color: red'>Do Not Call</span></div>";
				else
					$arrKolNames1[]	= "<div class='autocompleteHeading'>Contacts</div><div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><span style='display:none' class='addressId'>$key</span><span style='display:none' class='id1'>".$row['kol_id']."</span></div>";
				$flag	= 0;
			}else if($start!=''){
				//$arrKolNames1[]	= "<div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><label class='orgName'>$row[1]</label><span style='display:none' class='id1'>$key</span></div>";
				if($row[3] != "")
					$arrKolNames1[]	= "<div class='' title=' ".$row[0]." '><div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><span style='display:none' class='addressId'>$key</span><span style='display:none' class='id1'>".$row['kol_id']."</span><span style='color: red'>Do Not Call</span></div></div>";
				else
					$arrKolNames1[]	= "<div class='' title=' ".$row[0]." '><div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><span style='display:none' class='addressId'>$key</span><span style='display:none' class='id1'>".$row['kol_id']."</span></div></div>";
			}else{
				//$arrKolNames1[]	= "<div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><label class='orgName'>$row[1]</label><span style='display:none' class='id1'>$key</span></div>";
				if($row[3] != "")
					$arrKolNames1[]	= "<div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><span style='display:none' class='addressId'>$key</span><span style='display:none' class='id1'>".$row['kol_id']."</span><span style='color: red'>Do Not Call</span></div>";
				else
					$arrKolNames1[]	= "<div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><span style='display:none' class='addressId'>$key</span><span style='display:none' class='id1'>".$row['kol_id']."</span></div>";
			} */
		}
		$flag			= 1;
		$stopRquesting  = false;
		if((sizeof($arrKolNames['kols'])<1)){
			$arrKolNames1[]		= "<div style='padding-left:5px;'>No results found for ".$kol."</div><div><label name='No results found for ".$kol."' class='kolName' style='display:block'></label><label class='orgName'></label><span style='display:none' class='id1'></span></div>";
			$stopRquesting = true;
		}
		$arr['query']		= $kol;
		$arr['suggestions']	= $arrKolNames1;
		$arr['isStillRequest'] = $stopRquesting;
		echo json_encode($arr);
	}
	
	function load_search_names($kolId){
		ini_set('memory_limit','-1');
		$page		= (int)$_REQUEST['page']; // get the requested page 
		$limit 		= (int)$_REQUEST['rows']; // get how many rows we want
		$sidx 		= $_REQUEST['sidx']; // get index row - i.e. user click to sort
		$sord 		= $_REQUEST['sord']; // get the direction
		$filterData = $_REQUEST['filters'];
//		echo $page." - ".$limit." - ".$sidx." - ".$sord;
//		exit;
		$arrFilter=array();
		$arrFilter=json_decode(stripslashes($filterData));
		$field='field';
		$op='op';
		$data='data';
		$groupOp='groupOp';
		$searchGroupOperator=$this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
		$searchString=$this->common_helpers->search_nested_arrays($arrFilter, $data);
		$searchOper=$this->common_helpers->search_nested_arrays($arrFilter, $op);
		$searchField=$this->common_helpers->search_nested_arrays($arrFilter, $field);
		$whereResultArray=array();
		foreach($searchField as $key=> $val){
			$whereResultArray[$val]=$searchString[$key];		
		}
		if($filterData == ''){
			$whereResultArray["name"]			= $this->input->post("name");
			$whereResultArray["country_name"]	= $this->input->post("country");
			$whereResultArray["state_name"]		= $this->input->post("state");
			$whereResultArray["city_name"]		= $this->input->post("city");
			$whereResultArray["postal_code"]	= $this->input->post("postal");
		}
		
		if($sidx == 'name'){
			$sidx = 'full_name';
		}
		if($kolId != ''){
			$kolId = explode("-",$kolId);
			$whereResultArray["kol_id"] = $kolId[0]; 
		}
		
		$count	= $this->survey->searchIcontactNames($whereResultArray,true,'','','','');
		
//		echo $count;
//		exit;
		if( $count >0 ) {
			$total_pages = ceil($count/$limit); 
		} else { 
			$total_pages = 0; 
		} 
		if ($page > $total_pages) $page=$total_pages;
		$start = $limit*$page - $limit; // do not put $limit*($page - 1)
		if ($start < 0) $start = 0;
		
		$arrResult	= $this->survey->searchIcontactNames($whereResultArray,false,$start,$limit,$sord,$sidx);
		//pr($this->db->last_query());exit;
		$data = array();
		$data['records']= $count;
		$data['total']  = $total_pages;
		$data['page']	= $page;
		$data['rows']	= $arrResult;
//		pr($data);
		ob_start('ob_gzhandler');
		echo json_encode($data);
	}
	
	
	function add_staging_icontacts(){
		$data['arrCountry']=$this->Country_helper->listCountries();
		$this->load->view('surveys/add_staging_icontacts',$data);
	}
	
	function save_staging_icontacts($surveyId,$surQueId){
		$arrData = array();
		$arrData['survey_id'] 		= $surveyId;
		$arrData['survey_question_id'] 		= $surQueId;
		$arrData['first_name'] 		= $this->input->post('first_name');
		$arrData['middle_name'] 	= $this->input->post('middle_name');
		$arrData['last_name'] 		= $this->input->post('last_name');
		$arrData['country'] 		= $this->input->post('country');
		$arrData['state'] 			= $this->input->post('state');
		$arrData['city'] 			= $this->input->post('city');
		$arrData['postal_code'] 	= $this->input->post('postal_code');
		$arrData['npi'] 			= $this->input->post('npi');
		$arrData['mdm_id'] 			= $this->input->post('mdm_id');
		$arrData['organization'] 	= $this->input->post('organization');	
		$arrData['specialty'] 		= $this->input->post('specialty');
		if($this->input->post('respondent_id') != ''){
			$arr = explode("-",$this->input->post('respondent_id'));
			if(count($arr)>1){
				$arrData['survey_respondent_id'] =	(int)$arr[0];
				$arrData['survey_respondent_address_id'] = (int)$arr[1];
			}else{
				$arrData['staging_respondent_id'] = (int)$this->input->post('respondent_id');
			}
		}
		$arrInsertedData = $this->survey->saveStagingContact($arrData);
		$data = array();
		if($arrInsertedData['id'] > 0){
			$data['status'] = true;
			$data['id'] = $arrInsertedData['id'];
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}
	
	function delete_staging_icontacts_by_id($id){
		$data['status'] = $this->survey->deleteStagingIcontactsById($id);
		echo json_encode($data);
	}
	
	function sales_report(){
		$data['showReports'] = true;
		$data['arrSurveys']	= $this->survey->getCompletedSurveys();
		$data['contentPage']= 'surveys/sales_report';
		$this->load->view('layouts/client_view',$data);
	}
	function sales_report_grid($surveyId){
		ini_set('memory_limit',"-1");
		ini_set("max_execution_time",0);
		$arrResult	= $this->survey->salesReport($surveyId);
		//echo $this->db->last_query();
		$count				= sizeof($arrResult);
		if( $count >0 ){
			$total_pages	= ceil($count/$limit);
		}else{
			$total_pages	= 0;
		}
		$arrData['records']	= $count;
		$arrData['total']	= $total_pages;
		$arrData['page']	= 0;
		$arrData['rows']	= $arrResult;
		ob_start('ob_gzhandler');
		echo json_encode($arrData);
	}
	function export_salesreport_to_excel($surveyId){
		ini_set('memory_limit',"-1");
		ini_set("max_execution_time",0);
		$this->load->plugin('phpxls/writer');
		$startTime	= microtime(true);
		$arrExcelData	= array();
		$arrExcelData['Sales Report'][0]	= array('Question','Region','District','Territory','Territory Id','User Name','Total Respondents','Local','National','Zero Influencer Count','Influencers','Staging Local','Staging National','Zero Influencer Count','Staging Influencers','Total Influencers','Call Plan','Call Plan in %','Title','Email','Manager');
		$arrResult		= $this->survey->salesReport($surveyId);
		$aartdata	= $arrResult['territory'];
		usort($aartdata,array('surveys','usort_callback_salesreport'));
		$arrResult['territory']	= $aartdata;
		$i	= 1;
		foreach($arrResult as $row){
			$arrExcelData['Sales Report'][$i][]	= strip_tags($row['survey_name']);
			$arrExcelData['Sales Report'][$i][]	= $row['region'];
			$arrExcelData['Sales Report'][$i][]	= $row['district'];
			$arrExcelData['Sales Report'][$i][]	= $row['territory_name'];
			$arrExcelData['Sales Report'][$i][]	= $row['territory'];
			$arrExcelData['Sales Report'][$i][]	= $row['user_name'];
			$arrExcelData['Sales Report'][$i][]	= $row['respondents_count'];
			$arrExcelData['Sales Report'][$i][]	= $row['prod_local'];
			$arrExcelData['Sales Report'][$i][]	= $row['prod_national'];
			$arrExcelData['Sales Report'][$i][]	= $row['prod_zero_influencers'];
			$arrExcelData['Sales Report'][$i][]	= $row['prod_responses'];
			$arrExcelData['Sales Report'][$i][]	= $row['staging_local'];
			$arrExcelData['Sales Report'][$i][]	= $row['staging_national'];
			$arrExcelData['Sales Report'][$i][]	= $row['staging_zero_influencers'];
			$arrExcelData['Sales Report'][$i][]	= $row['staging_responses'];
			$arrExcelData['Sales Report'][$i][]	= $row['total'];
			$arrExcelData['Sales Report'][$i][]	= $row['call_plan'];
			$arrExcelData['Sales Report'][$i][]	= $row['call_plan_percentage'];
			$arrExcelData['Sales Report'][$i][]	= $row['title'];
			$arrExcelData['Sales Report'][$i][]	= $row['email'];
			$arrExcelData['Sales Report'][$i][]	= $row['manager_name'];
			$i++;
		}
		$arrExcelData['Sales Summary Report'][0]	= array('Survey Completion Metrics','','','','','','Top 5 Territory Completion Metrics','','','','','','Bottom 5 Territory Completion Metrics','','','');
		$arrExcelData['Sales Summary Report'][1]	= array('Name','Respondent Count','Call Plan Count','% Completion','','','Name','Respondent Count','Call Plan Count','% Completion','','','Name','Respondent Count','Call Plan Count','% Completion');
		$arrExcelData['Sales Summary Report'][8]	= array();
		$arrExcelData['Sales Summary Report'][9]	= array();
		$arrExcelData['Sales Summary Report'][10]	= array('REGION COMPLETION METRICS','','','','','','DISTRICT COMPLETION METRICS','','','','','','TERRITORY COMPLETION METRICS','','','');
		$arrExcelData['Sales Summary Report'][11]	= array('Name','Respondent Count','Call Plan Count','% Completion','','','Name','Respondent Count','Call Plan Count','% Completion','','','Name','Respondent Count','Call Plan Count','% Completion');
		$arrResult		= $this->survey->salesSummaryReport($surveyId);
		$totalTerritoryRecords	= sizeof($arrResult['territory']);
		$rowNumber	= 12;
		$columnNumber	= 0;
		$totalRespodents	= 0;
		$totalCallPlans	= 0;
		foreach($arrResult['region'] as $row){
			$arrExcelData['Sales Summary Report'][$rowNumber][$columnNumber]	= $row['name'];
			$arrExcelData['Sales Summary Report'][$rowNumber][]	= $row['respondent_count'];
			$arrExcelData['Sales Summary Report'][$rowNumber][]	= $row['call_plan'];
			$arrExcelData['Sales Summary Report'][$rowNumber][]	= $row['completed'];
			$totalRespodents	+= $row['respondent_count'];
			$totalCallPlans	+= $row['call_plan'];
			$rowNumber++;
		}
		$arrExcelData['Sales Summary Report'][2][0]	= 'Grand Total';
		$arrExcelData['Sales Summary Report'][2][1]	= $totalRespodents;
		$arrExcelData['Sales Summary Report'][2][2]	= $totalCallPlans;
		$arrExcelData['Sales Summary Report'][2][3]	= round($totalRespodents/$totalCallPlans*100,2);
		$rowNumber	= 12;
		$columnNumber	= 6;
		foreach($arrResult['district'] as $row){
			$arrExcelData['Sales Summary Report'][$rowNumber][$columnNumber]	= $row['name'];
			$arrExcelData['Sales Summary Report'][$rowNumber][]	= $row['respondent_count'];
			$arrExcelData['Sales Summary Report'][$rowNumber][]	= $row['call_plan'];
			$arrExcelData['Sales Summary Report'][$rowNumber][]	= $row['completed'];
			$rowNumber++;
		}
		$rowNumber	= 2;
		$columnNumber	= 6;
		for($i=($totalTerritoryRecords-1);$i>=($totalTerritoryRecords-5);$i--){
			$row	= $arrResult['territory'][$i];
			$arrExcelData['Sales Summary Report'][$rowNumber][$columnNumber]	= $row['name'];
			$arrExcelData['Sales Summary Report'][$rowNumber][]	= $row['respondent_count'];
			$arrExcelData['Sales Summary Report'][$rowNumber][]	= $row['call_plan'];
			$arrExcelData['Sales Summary Report'][$rowNumber][]	= $row['completed'];
			$rowNumber++;
		}
		$rowNumber	= 2;
		$columnNumber	= 12;
		for($i=0;$i<5;$i++){
			$row	= $arrResult['territory'][$i];
			$arrExcelData['Sales Summary Report'][$rowNumber][$columnNumber]	= $row['name'];
			$arrExcelData['Sales Summary Report'][$rowNumber][]	= $row['respondent_count'];
			$arrExcelData['Sales Summary Report'][$rowNumber][]	= $row['call_plan'];
			$arrExcelData['Sales Summary Report'][$rowNumber][]	= $row['completed'];
			$rowNumber++;
		}
		$rowNumber	= 12;
		$columnNumber	= 12;
		for($i=0;$i<=$totalTerritoryRecords;$i++){
			$row	= $arrResult['territory'][$i];
			$arrExcelData['Sales Summary Report'][$rowNumber][$columnNumber]	= $row['name'];
			$arrExcelData['Sales Summary Report'][$rowNumber][]	= $row['respondent_count'];
			$arrExcelData['Sales Summary Report'][$rowNumber][]	= $row['call_plan'];
			$arrExcelData['Sales Summary Report'][$rowNumber][]	= $row['completed'];
			$rowNumber++;
		}
		
		//for downloading the file
		$workbook	= new Spreadsheet_Excel_Writer();
		// To allow more than 255 charecters.
		$workbook->setVersion(8);
		$format_und	=& $workbook->addFormat();
		$format_und->setBottom(2);//thick
		$format_und->setRight(1);
		$format_und->setBold();
		$format_und->setHAlign('centre');
		$format_und->setVAlign('vcentre');
		$format_und->setColor('black');
		$format_und->setFontFamily('Arial');
		$format_und->setSize(11);
		$format_reg	=& $workbook->addFormat();
		$format_reg->setBorder(1);
		$format_reg->setHAlign('left');
		$format_reg->setVAlign('vcentre');
		$format_reg->setColor('black');
		$format_reg->setFontFamily('Arial');
		$format_reg->setSize(10);
		
		foreach($arrExcelData as $wbname=>$rows){
			$rowcount 									= count($rows);
			$colcount 									= count($rows[0]);
			$worksheet 									=& $workbook->addWorksheet($wbname);
			$worksheet->setColumn(0,0, 30);//setColumn(startcol,endcol,float)
			$worksheet->setColumn(1,18, 30);
			for( $j=0; $j<$rowcount; $j++ ){
				for($i=0; $i<$colcount;$i++){
					$fmt	=& $format_reg;
					if($wbname=="Sales Summary Report" && ($j==0 or $j==1 or $j==10 or $j==11)){
						if($j==0 or $j==10){
							$worksheet->setMerge($j, 0, $j, 2);
							$worksheet->setMerge($j, 6, $j, 8);
							$worksheet->setMerge($j, 12, $j, 14);
						}
						$fmt	=& $format_und;
					}else if ($j==0){
						$fmt	=& $format_und;
					}
					if (isset($rows[$j][$i])){
						$value	= utf8_decode($rows[$j][$i]);
						$worksheet->write($j, $i, $value, $fmt);
					}
				}
			}
		}
		$fileName	= 'iMAP sales report - '.date("Y-m-d").'.xls';
		$workbook->send($fileName);
		$workbook->close();
	}
	
	function similar_names(){
		$returnData	= array();
		$arrParams	= array();
		$arr = array();
		foreach ($_POST as $key=>$val){
			$arr[$key] = trim($val);
		}
		$arrParams	= array_filter($arr);
		$returnData	= $this->survey->suggestSimilarNames($arrParams);
		$arrReturnData['count']	= sizeof($returnData);
		$arrReturnData['data']	= $returnData;
		ob_start('ob_gzhandler');
		echo json_encode($arrReturnData);
	}
		
	function get_kol_names_for_autocomplete_refine_by($kolName){
		$where = array();
		$where["country_name"] 	= trim($this->input->post("country_name"));
		$where["state_name"]	= trim($this->input->post("state_name"));
		$where["city_name"] 	= trim($this->input->post("city_name"));
		$where["postal_code"] 	= trim($this->input->post("postal_code"));
//		if(strlen($where["state_name"]) == 2){
//			$where["state_name"] = $this->country_helper->getStateNameByStateCode($where["state_name"]);
//		}
		$start = trim($this->input->post("offset"));
		if($start == '')
			$start = 0;
		$kolName		= trim(utf8_urldecode($this->input->post($kolName)));
		$where["name"] = $kolName; 
		$kol = $kolName;
		$arrKolNames1	= array();
		$flag			= 1;
		
		$arrKolNames	= $this->survey->searchIcontactNames($where,$count=false,$start,$limit=5000,$sord=null,$sidx=null,$isForMobile=false,$isAutoComplete=true,$type='nom');
//		$arrKolNames	= $this->survey->getIcontactAutocomplete($kolName,$where,$offset);
		
		//pr($this->db->last_query());exit;
		foreach($arrKolNames['kols'] as $key=>$row){
//			pr($row);
			$arrKolNames1[]	= "<div class='autocompleteHeading'>Contacts</div><div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><span style='display:none' class='addressId'>$key</span><span style='display:none' class='id1'>".$key."</span></div>";
			/* if($flag && $start==0){
				//$arrKolNames1[]	= "<div class='autocompleteHeading'>Contacts</div><div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><label class='orgName'>$row[1]</label><span style='display:none' class='id1'>$key</span></div>";
				// removed org name
				$arrKolNames1[]	= "<div class='autocompleteHeading'>Contacts</div><div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><span style='display:none' class='addressId'>$key</span><span style='display:none' class='id1'>".$key."</span></div>";
				$flag	= 0;
			}else if($start!=''){
				//$arrKolNames1[]	= "<div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><label class='orgName'>$row[1]</label><span style='display:none' class='id1'>$key</span></div>";
				$arrKolNames1[]	= "<div class='' title=' ".$row[0]." '><div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><span style='display:none' class='addressId'>$key</span><span style='display:none' class='id1'>".$row['kol_id']."</span></div></div>";
			}else{
				//$arrKolNames1[]	= "<div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><label class='orgName'>$row[1]</label><span style='display:none' class='id1'>$key</span></div>";
				$arrKolNames1[]	= "<div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><span style='display:none' class='addressId'>$key</span><span style='display:none' class='id1'>".$row['kol_id']."</span></div>";
			} */
		}
		$flag			= 1;
		$stopRquesting  = false;
		if((sizeof($arrKolNames['kols'])<1)){
			$arrKolNames1[]		= "<div style='padding-left:5px;'>No results found for ".$kol."</div><div><label name='No results found for ".$kol."' class='kolName' style='display:block'></label><label class='orgName'></label><span style='display:none' class='id1'></span></div>";
			$stopRquesting = true;
		}
		$arr['query']		= $kol;
		$arr['suggestions']	= $arrKolNames1;
		$arr['isStillRequest'] = $stopRquesting;
		echo json_encode($arr);
	}
	
	
	function get_kol_names_for_autocomplete_refine_resp($kolName){
		$where = array();
		$where["country_name"] 	= trim($this->input->post("country_name"));
		$where["state_name"]	= trim($this->input->post("state_name"));
		$where["city_name"] 	= trim($this->input->post("city_name"));
		$where["postal_code"] 	= trim($this->input->post("postal_code"));
//		if(strlen($where["state_name"]) == 2){
//			$where["state_name"] = $this->country_helper->getStateNameByStateCode($where["state_name"]);
//		}
		$start = trim($this->input->post("offset"));
		if($start == '')
			$start = 0;
		$kolName		= trim(utf8_urldecode($this->input->post($kolName)));
		$where["name"] = $kolName; 
		$kol = $kolName;
		$arrKolNames1	= array();
		$flag			= 1;
		
		$arrKolNames	= $this->survey->searchIcontactNames($where,$count=false,$start,$limit=5000,$sord=null,$sidx=null,$isForMobile=false,$isAutoComplete=true,$type='resp');
//		$arrKolNames	= $this->survey->getIcontactAutocomplete($kolName,$where,$offset);
		foreach($arrKolNames['kols'] as $key=>$row){
//			pr($row);
			if($flag && $start==0){
				//$arrKolNames1[]	= "<div class='autocompleteHeading'>Contacts</div><div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><label class='orgName'>$row[1]</label><span style='display:none' class='id1'>$key</span></div>";
				// removed org name
				$arrKolNames1[]	= "<div class='autocompleteHeading'>Contacts</div><div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><span style='display:none' class='addressId'>$key</span><span style='display:none' class='id1'>".$row['kol_id']."</span></div>";
				$flag	= 0;
			}else if($start!=''){
				//$arrKolNames1[]	= "<div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><label class='orgName'>$row[1]</label><span style='display:none' class='id1'>$key</span></div>";
				$arrKolNames1[]	= "<div class='' title=' ".$row[0]." '><div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><span style='display:none' class='addressId'>$key</span><span style='display:none' class='id1'>".$row['kol_id']."</span></div></div>";
			}else{
				//$arrKolNames1[]	= "<div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><label class='orgName'>$row[1]</label><span style='display:none' class='id1'>$key</span></div>";
				$arrKolNames1[]	= "<div class='dataSet'><label name='".$row[0]."' class='kolName' style='display:block'>$row[0]</label><label class='address' >$row[2]</label><span style='display:none' class='addressId'>$key</span><span style='display:none' class='id1'>".$row['kol_id']."</span></div>";
			}
		}
		$flag			= 1;
		$stopRquesting  = false;
		if((sizeof($arrKolNames['kols'])<1)){
			$arrKolNames1[]		= "<div style='padding-left:5px;'>No results found for ".$kol."</div><div><label name='No results found for ".$kol."' class='kolName' style='display:block'></label><label class='orgName'></label><span style='display:none' class='id1'></span></div>";
			$stopRquesting = true;
		}
		$arr['query']		= $kol;
		$arr['suggestions']	= $arrKolNames1;
		$arr['isStillRequest'] = $stopRquesting;
		echo json_encode($arr);
	}
		
	function get_nominations_by_respondents_id($respId){
		$arrData	= array();
		$arrData['survey_id']	= $this->input->post('survey_id');
		$arrData['participant']	= 'respondents';//$this->input->post('participant');
		$arrSelections			= $this->formatFilterSelections($_POST);
		//$arrResult['data']	= $this->survey->loadSummeryDetails($arrData,$arrSelections,$respId);
		$arrResult['data']	= $this->survey->getNominationsByRespondentsId($arrData,$arrSelections,$respId);
		ob_start('ob_gzhandler');
		echo json_encode($arrResult);
	}
	
	function get_respondents_by_user_id($userId){
		$arrData	= array();
		$arrData['survey_id']	= $this->input->post('survey_id');
		$arrData['participant']	= 'respondents';//$this->input->post('participant');
		$arrSelections			= $this->formatFilterSelections($_POST);
		//$arrResult['data']	= $this->survey->loadSummeryDetails($arrData,$arrSelections,'',$userId);
		$arrResult['data']	= $this->survey->getRespondentsByUserId($arrData,$arrSelections,$userId);
		ob_start('ob_gzhandler');
		echo json_encode($arrResult);
	}
	
	function hcp_report(){
		$data['showReports'] = true;
		$data['arrSurveys']	= $this->survey->getCompletedSurveys();
		$data['contentPage']= 'surveys/hcp_report';
		$this->load->view('layouts/client_view',$data);
	}
	
	function hcp_report_grid($surveyId){
		ini_set('memory_limit',"-1");
		ini_set("max_execution_time",0);
		$arrResult	= $this->survey->hcpCompletionReport($surveyId);
		//echo $this->db->last_query();
		$count				= sizeof($arrResult);
		if( $count >0 ){
			$total_pages	= ceil($count/$limit);
		}else{
			$total_pages	= 0;
		}
		$arrData['records']	= $count;
		$arrData['total']	= $total_pages;
		$arrData['page']	= 0;
		$arrData['rows']	= $arrResult;
		ob_start('ob_gzhandler');
		echo json_encode($arrData);
	} 
	function export_hcpreport_to_excel($surveyId,$format='xls',$download=1){
		ini_set('memory_limit',"-1");
		ini_set("max_execution_time",0);
		$surveyName	= '';
		$startTime	= microtime(true);
		$arrExcelData	= array();
		$arrResult		= $this->survey->hcpCompletionReport($surveyId);
		$sheetData[0]	= array('Source','Survey','Manager','User Name','Territory Id','Territory','District','Region','Type','Respondent Name','Respondent Organization','Respondent Specialty','Respondent State','Respondent City','Respondent MDM ID','Influencer Type','Influencer Name','Influencer Organization','Influencer Specialty','Influencer State','Influencer City','Influencer MDM ID','Zero Influencer','Created on');
		$i	= 1;
		foreach($arrResult as $row){
			$surveyName	= strip_tags($row['survey_name']);
			$sheetData[$i][]	= (isset($row['source'])?$row['source']:'');
			$sheetData[$i][]	= $surveyName;
			$sheetData[$i][]	= (isset($row['manager_name'])?$row['manager_name']:'');
			$sheetData[$i][]	= (isset($row['user_name'])?$row['user_name']:'');
			$sheetData[$i][]	= (isset($row['territory_id'])?$row['territory_id']:'');
			$sheetData[$i][]	= (isset($row['territory_name'])?$row['territory_name']:'');
			$sheetData[$i][]	= (isset($row['district'])?$row['district']:'');
			$sheetData[$i][]	= (isset($row['region'])?$row['region']:'');
			$sheetData[$i][]	= (isset($row['type'])?$row['type']:'');
			$sheetData[$i][]	= (isset($row['resp_name'])?$row['resp_name']:'');
			$sheetData[$i][]	= (isset($row['resp_org'])?$row['resp_org']:'');
			$sheetData[$i][]	= (isset($row['resp_specialty'])?$row['resp_specialty']:'');
			$sheetData[$i][]	= (isset($row['resp_state'])?$row['resp_state']:'');
			$sheetData[$i][]	= (isset($row['resp_city'])?$row['resp_city']:'');
			$sheetData[$i][]	= (isset($row['resp_mdm_id'])?$row['resp_mdm_id']:'');
			$sheetData[$i][]	= (isset($row['influencer_type'])?$row['influencer_type']:'');
			$sheetData[$i][]	= (isset($row['influencer_name'])?$row['influencer_name']:'');
			$sheetData[$i][]	= (isset($row['influencer_org'])?$row['influencer_org']:'');
			$sheetData[$i][]	= (isset($row['influencer_specialty'])?$row['influencer_specialty']:'');
			$sheetData[$i][]	= (isset($row['influencer_state'])?$row['influencer_state']:'');
			$sheetData[$i][]	= (isset($row['influencer_city'])?$row['influencer_city']:'');
			$sheetData[$i][]	= (isset($row['nom_mdm_id'])?$row['nom_mdm_id']:'');
			$sheetData[$i][]	= (isset($row['zero_influencers'])?$row['zero_influencers']:'');
			$sheetData[$i][]	= (isset($row['created_on'])?$row['created_on']:'');
			$i++;
		}
		$fileName	= 'iMAP '.$surveyName.' HCP Completion Report - '.date("Y-m-d");
		$pathToSaveFile	= $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/survey_reports/";
		switch($format){
			case 'xls':
				$arrExcelData['Report']	= $sheetData;
				$this->load->plugin('phpxls/writer');
				//for downloading the file
				if($download>0){
					$workbook	= new Spreadsheet_Excel_Writer();
					$workbook->send($fileName);
				}else{
					$workbook	= new Spreadsheet_Excel_Writer($pathToSaveFile.$fileName.".xls");
				}
				// To allow more than 255 charecters.
				$workbook->setVersion(8);
				$format_und	=& $workbook->addFormat();
				$format_und->setBottom(2);//thick
				$format_und->setRight(1);
				$format_und->setBold();
				$format_und->setHAlign('centre');
				$format_und->setVAlign('vcentre');
				$format_und->setColor('black');
				$format_und->setFontFamily('Arial');
				$format_und->setSize(11);
				$format_reg	=& $workbook->addFormat();
				$format_reg->setBorder(1);
				$format_reg->setHAlign('left');
				$format_reg->setVAlign('vcentre');
				$format_reg->setColor('black');
				$format_reg->setFontFamily('Arial');
				$format_reg->setSize(10);
				
				foreach($arrExcelData as $wbname=>$rows){
					$rowcount 									= count($rows);
					$colcount 									= count($rows[0]);
					$worksheet 									=& $workbook->addWorksheet($wbname);
					$worksheet->setColumn(0,0, 30);//setColumn(startcol,endcol,float)
					$worksheet->setColumn(1,18, 30);
					for( $j=0; $j<$rowcount; $j++ ){
						for($i=0; $i<$colcount;$i++){
							$fmt	=& $format_reg;
							if ($j==0)
							$fmt	=& $format_und;
							if (isset($rows[$j][$i])){
								$value	= utf8_decode($rows[$j][$i]);
								$worksheet->write($j, $i, $value, $fmt);
							}
						}
					}
				}
				$workbook->close();
			break;
			case 'csv':
				$this->load->helper('csv');
				echo array_to_csv($sheetData, $download, $fileName.".csv",$pathToSaveFile);
			break;
		}
	}
	
	function export_hcpreport_to_excel_new($surveyId){
		//error_reporting(E_ALL);
		$startTime = microtime(true);
		ini_set('memory_limit',"-1");
		ini_set("max_execution_time",0);
		$this->load->plugin('php_excel/classes/phpexcel.php');
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		$surveyName	= '';
		//New Worksheet
		$objWorksheet = $objPHPExcel->getActiveSheet();
		//Add header
		$objWorksheet->setCellValue('A1', 'Source')
						->setCellValue('B1', 'Survey')
						->setCellValue('C1', 'Manager Name')
						->setCellValue('D1', 'User Name')
						->setCellValue('E1', 'Territory Id')
						->setCellValue('F1', 'Territory')
						->setCellValue('H1', 'District')
						->setCellValue('G1', 'Region')
						->setCellValue('I1', 'Type')
						->setCellValue('J1', 'Respondent Name')
						->setCellValue('K1', 'Respondent Organization')
						->setCellValue('L1', 'Respondent Specialty')
						->setCellValue('M1', 'Respondent State')
						->setCellValue('N1', 'Respondent City')
						->setCellValue('O1', 'Respondent MDM ID')
						->setCellValue('P1', 'Influencer Type')
						->setCellValue('Q1', 'Influencer Name')
						->setCellValue('R1', 'Influencer Organization')
						->setCellValue('S1', 'Influencer Specialty')
						->setCellValue('T1', 'Influencer State')
						->setCellValue('U1', 'Influencer City')
						->setCellValue('V1', 'Influencer MDM ID')
						->setCellValue('W1', 'Zero Influencer')
						->setCellValue('X1', 'Created On');
						
		$arrResult		= $this->survey->hcpCompletionReport($surveyId);
		$i	=	2;
		foreach($arrResult as $row){
			$surveyName	= strip_tags($row['survey_name']);
			$objWorksheet->setCellValue('A'.$i, (isset($row['source'])?$row['source']:''))
						->setCellValue('B'.$i, $surveyName)
						->setCellValue('C'.$i, (isset($row['manager_name'])?$row['manager_name']:''))
						->setCellValue('D'.$i, (isset($row['user_name'])?$row['user_name']:''))
						->setCellValue('E'.$i, (isset($row['territory_id'])?$row['territory_id']:''))
						->setCellValue('F'.$i, (isset($row['territory_name'])?$row['territory_name']:''))
						->setCellValue('H'.$i, (isset($row['district'])?$row['district']:''))
						->setCellValue('G'.$i, (isset($row['region'])?$row['region']:''))
						->setCellValue('I'.$i, (isset($row['type'])?$row['type']:''))
						->setCellValue('J'.$i, (isset($row['resp_name'])?$row['resp_name']:''))
						->setCellValue('K'.$i, (isset($row['resp_org'])?$row['resp_org']:''))
						->setCellValue('L'.$i, (isset($row['resp_specialty'])?$row['resp_specialty']:''))
						->setCellValue('M'.$i, (isset($row['resp_state'])?$row['resp_state']:''))
						->setCellValue('N'.$i, (isset($row['resp_city'])?$row['resp_city']:''))
						->setCellValue('O'.$i, (isset($row['resp_mdm_id'])?$row['resp_mdm_id']:''))
						->setCellValue('P'.$i, (isset($row['influencer_type'])?$row['influencer_type']:''))
						->setCellValue('Q'.$i, (isset($row['influencer_name'])?$row['influencer_name']:''))
						->setCellValue('R'.$i, (isset($row['influencer_org'])?$row['influencer_org']:''))
						->setCellValue('S'.$i, (isset($row['influencer_specialty'])?$row['influencer_specialty']:''))
						->setCellValue('T'.$i, (isset($row['influencer_state'])?$row['influencer_state']:''))
						->setCellValue('U'.$i, (isset($row['influencer_city'])?$row['influencer_city']:''))
						->setCellValue('V'.$i, (isset($row['nom_mdm_id'])?$row['nom_mdm_id']:''))
						->setCellValue('W'.$i, (isset($row['zero_influencers'])?$row['zero_influencers']:''))
						->setCellValue('X'.$i, (isset($row['created_on'])?$row['created_on']:''));
			$i++;
		}
		$fileName	= 'iMAP '.$surveyName.' HCP Completion Report - '.date("Y-m-d");
		$objWorksheet->setTitle($surveyName);
		$styleArray = array(
			'borders' => array(
				'bottom' => array(
					'style' => PHPExcel_Style_Border::BORDER_THICK,
					'color' => array('argb' => '0000000'),
				),
			),
		);
		
		$arrStyles =  array(
                  'font'    => array(
                      'bold'      => true,
                      'italic'    => false
                  ),
                  'borders' => array(
                      'bottom'     => array(
                          'style' => PHPExcel_Style_Border::BORDER_THICK,
                          'color' => array(
                              'rgb' => '000000'
                          )
                      ),
                      'quotePrefix'    => true
                  )
              );
			foreach(range('A','W') as $columnID) {
			    $objPHPExcel->getSheet(0)->getColumnDimension($columnID)->setWidth(30);
			}
        	$objPHPExcel->getSheet(0)->getStyle('A1:W1')->applyFromArray($arrStyles); 
		
		$objPHPExcel->setActiveSheetIndex(0);
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

		// Redirect output to a client’s web browser (Excel2007)
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment;filename="'.$fileName.'.xlsx"');
		header('Cache-Control: max-age=0');
		// If you're serving to IE 9, then the following may be needed
		header('Cache-Control: max-age=1');

		// If you're serving to IE over SSL, then the following may be needed
		header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
		header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
		header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
		header ('Pragma: public'); // HTTP/1.0

		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save('php://output');
		exit;
	}
	
	function sales_summary_report($surveyId){
		$arrData	= $this->survey->salesSummaryReport($surveyId);
		//echo $this->db->last_query();
		ob_start('ob_gzhandler');
		echo json_encode($arrData);
	}
	
	function delete_survey_influencer_by_id($id){
		$arrRow = $this->survey->getSurveyAnserById($id);
		$arrRow['id'];
	    $questionId = $arrRow['question_id'];
	    $createdBy = $arrRow['created_by'];
	    $influenceId = $arrRow['nominee_id'];
	    $respondentId = $arrRow['respondent_id'];
	    $surveyId = $arrRow['survey_id'];
	    $influenceAddressId = $arrRow['nom_address_id'];
	    $respondentAddressId = $arrRow['resp_address_id'];
		$data = $this->survey->markInfluencerAsDelete($surveyId,$questionId,$respondentId,$respondentAddressId,$influenceId,$influenceAddressId,$createdBy);
		if($data)
			$data['status'] = true;
		else
			$data['status'] = false;
		echo json_encode($data);	
	}
	
	function excel_export(){
		ini_set('max_execution_time', 0);
		ini_set('memory_limit', '-1');
		$this->load->plugin('phpxls/writer');
		$type = $this->input->post("type");
		$arrIds = explode(",",$this->input->post("exportIds"));
		$rowName = $this->input->post("rowName");
		$arrExcelData	= array();
		switch($type){
			case'1':
				$arrResult = $this->survey->excelEsportQuery($arrIds,$type);
				$sheetData[0]	= array('Type','Name','City','State','Postal Code');
				$i	= 1;
				foreach($arrResult as $row){
					$sheetData[$i][]	= $row['type'];
					$sheetData[$i][]	= $row['full_name'];
					$sheetData[$i][]	= $row['city_name'];
					$sheetData[$i][]	= $row['state_name'];
					$sheetData[$i][]	= $row['postal_code'];
					$i++;
				}
				$arrExcelData['Nomination Details']	= $sheetData;
				$fileName	= "Respondent ".$rowName."'s Nomination details ".date("Y-m-d").".xls";
				
				break;
			case'2':
				$arrResult = $this->survey->excelEsportQuery($arrIds,$type);
				$sheetData[0]	= array('Name','City','State','Postal Code');
				$i	= 1;
				foreach($arrResult as $row){
					$sheetData[$i][]	= $row['full_name'];
					$sheetData[$i][]	= $row['city_name'];
					$sheetData[$i][]	= $row['state_name'];
					$sheetData[$i][]	= $row['postal_code'];
					$i++;
				}
				$arrExcelData['Response Details']	= $sheetData;
				$fileName	= "User ".$rowName."'s Responser details ".date("Y-m-d").".xls";
				break;
			case'3':
				$arrResult = $this->survey->excelEsportQuery($arrIds,$type);
				$sheetData[0]	= array('Type','Name','City','State','Postal Code');
				$i	= 1;
				foreach($arrResult as $row){
					$sheetData[$i][]	= $row['type'];
					$sheetData[$i][]	= $row['full_name'];
					$sheetData[$i][]	= $row['city_name'];
					$sheetData[$i][]	= $row['state_name'];
					$sheetData[$i][]	= $row['postal_code'];
					$i++;
				}
				$arrExcelData['Influencee Details']	= $sheetData;
				$fileName	= "Nominee ".$rowName."'s Responser details ".date("Y-m-d").".xls";
				break;
				
		}
		$excelFilters = $this->input->post('filters');
		$filters = array();
		if($excelFilters != '')
		$arrFilters = explode(",",$excelFilters);
		$filterHeaders[0] = 'Filter Name';
		$filterHeaders[1] = 'Filter Value';
		$filters[]	= $filterHeaders;
		foreach ($arrFilters as $filter){
			if($filter != '' && $filter != 'Search'){
				$filterRow = array();
				$filterRowElements = explode(":",$filter);
				$filterName = trim($filterRowElements[0]);
				$filterRow[0] = '';
				$filterNameElements = explode("_",$filterName);
				foreach ($filterNameElements as $value){
					$filterRow[0] .= ucfirst($value)." ";
				}
				$filterRow[1] = trim($filterRowElements[1]);
				$filters[]	= $filterRow;
			}
		}
		$arrExcelData['Filters'] = $filters;
//		pr($arrResult);
//		exit;
		//for downloading the file
		$workbook	= new Spreadsheet_Excel_Writer();
		// To allow more than 255 charecters.
		$workbook->setVersion(8);
		$format_und	=& $workbook->addFormat();
		$format_und->setBottom(2);//thick
		$format_und->setRight(1);
		$format_und->setBold();
		$format_und->setHAlign('centre');
		$format_und->setVAlign('vcentre');
		$format_und->setColor('black');
		$format_und->setFontFamily('Arial');
		$format_und->setSize(11);
		$format_reg	=& $workbook->addFormat();
		$format_reg->setBorder(1);
		$format_reg->setHAlign('left');
		$format_reg->setVAlign('vcentre');
		$format_reg->setColor('black');
		$format_reg->setFontFamily('Arial');
		$format_reg->setSize(10);
		
		foreach($arrExcelData as $wbname=>$rows){
			$rowcount 									= count($rows);
			$colcount 									= count($rows[0]);
			$worksheet 									=& $workbook->addWorksheet($wbname);
			$worksheet->setColumn(0,0, 30);//setColumn(startcol,endcol,float)
			$worksheet->setColumn(1,18, 30);
			for( $j=0; $j<$rowcount; $j++ ){
				for($i=0; $i<$colcount;$i++){
					$fmt	=& $format_reg;
					if ($j==0)
					$fmt	=& $format_und;
					if (isset($rows[$j][$i])){
						$value	= utf8_decode($rows[$j][$i]);
						$worksheet->write($j, $i, $value, $fmt);
					}
				}
			}
		}
		$workbook->send($fileName);
		$workbook->close();
	}
	function move_staging_to_production($createdBy=0){
		$data['arrData']	= $this->survey->moveStagingToProduction($createdBy);
		//echo 'No. of records: '.sizeof($arrData);
		$data['contentPage']= 'surveys/staging_to_production';
		$this->load->view('layouts/client_view',$data);
	}
	
	function add_credit_for_desktop($surveyId,$respondentId,$respondentAddressId){
//		echo $surveyId." - ".$respondentId." - ".$respondentAddressId;
		$createdOn	= date("Y-m-d H:i:s");
		$createdBy	= $this->session->userdata('user_id');
		$arrTerritoryData		= $this->survey->getUserTerritory($createdBy);
		$territoryId	= $arrTerritoryData['id'];
		$territory	= $arrTerritoryData['territory'];
		$arrInsertSurveyDetails	 = array();
		$arrInsertSurveyDetails['survey_id']	= $surveyId;
		$arrInsertSurveyDetails['created_by']	= $createdBy;
		$arrInsertSurveyDetails['territory_id']= $territoryId;
		$arrInsertSurveyDetails['territory']	= $territory;
		$arrInsertSurveyDetails['created_on']	= $createdOn;
		$arrInsertSurveyDetails['is_submitted']	= 1;
		$arrInsertSurveyDetails['respondent_id']	= $respondentId;
		$arrInsertSurveyDetails['resp_address_id']	= $respondentAddressId;
		$ret = $this->survey->creditUserForRespondent($surveyId,$respondentId,$respondentAddressId,$arrInsertSurveyDetails);
		$data = array();
		if($ret){
			$data['status'] = true;
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}
	
function get_survey_influence_data_desktop(){
		ini_set("max_execution_time",86400);
		//Get all the filters submited as a post data
		$arrData	= array();
		$arrData['survey_id']	= $this->input->post('survey_id');
		
		//$arrData['survey_id']=18;
		
		/*$arrData['specialty']	= $this->input->post('nominee_specialty');
		$arrData['respondent_state']	= $this->input->post('respondent_state');
		$arrData['respondent_city']		= $this->input->post('respondent_city');
		$arrData['respondent_postal']	= $this->input->post('respondent_postal');*/
		
		$arrFilters = $_POST;
		if($arrData['survey_id']=='undefined'){
			$details['arrSurveys']	= $this->survey->getCompletedSurveys();
			$arrData['survey_id']	= $details['arrSurveys'][0]['id'];
			$arrFilters['survey_id'] = $arrData['survey_id'];
		}
		$arrData['type']		= $this->input->post('influencer_type');
		if(isset($arrFilters['influencer_ids'])){
			$arrData['name']		= $this->input->post('influencer_ids');
			if($arrData['name'][0] == "All Influencers")
				array_shift($arrData['name']);
		}
		if(isset($arrFilters['country_ids'])){
			$arrData['country']		= $this->input->post('country_ids');
			if($arrData['country'][0] == "All Countries")
				array_shift($arrData['country']);
				
		}
		if(isset($arrFilters['state_ids'])){
			$arrData['state']		= $this->input->post('state_ids');
			if($arrData['state'][0] == "All States")
				array_shift($arrData['state']);
				
		}
		if(isset($arrFilters['city_ids'])){
			$arrData['city']		= $this->input->post('city_ids');
			if($arrData['city'][0] == "All Cities")
				array_shift($arrData['city']);
				
		}
		
		if(isset($arrFilters['postalcode_ids'])){
			$arrData['postal']		= $this->input->post('postalcode_ids');
			if($arrData['postal'][0] == "All Postalcodes")
				array_shift($arrData['postal']);
				
		}
		if(isset($arrFilters['respondent_ids'])){
			$arrData['respondent_id']		= $this->input->post('respondent_ids');
			if($arrData['respondent_id'][0] == "All Respondents")
				array_shift($arrData['respondent_id']);
				
		}
		if(isset($arrFilters['user_ids'])){
			$arrData['user_ids']		= $this->input->post('user_ids');
			if($arrData['user_ids'][0] == "All Users")
				array_shift($arrData['user_ids']);
		}
		if(isset($arrFilters['territory_ids'])){
			$arrData['territory_ids']		= $this->input->post('territory_ids');
			if($arrData['territory_ids'][0] == "All Territories")
				array_shift($arrData['territory_ids']);
		}
		if(isset($arrFilters['region_ids'])){
			$arrData['region_ids']		= $this->input->post('region_ids');
			if($arrData['region_ids'][0] == "All Regions")
				array_shift($arrData['region_ids']);
		}
		if(isset($arrFilters['district_ids'])){
			$arrData['district_ids']		= $this->input->post('district_ids');
			if($arrData['district_ids'][0] == "All Districts")
				array_shift($arrData['district_ids']);
		}
		
		//if(empty($arrData['user_ids']) && empty($arrData['type']) && empty($arrData['state']) && empty($arrData['city']) && empty($arrData['respondent_id']) && empty($arrData['name']) && empty($arrData['territory_ids']) && empty($arrData['region_ids']) && empty($arrData['district_ids'])){
		if(empty($arrData['user_ids']) && empty($arrData['type']) && empty($arrData['state']) && empty($arrData['city']) && empty($arrData['respondent_id']) && empty($arrData['name'])){
		
			$userId = $this->session->userdata('user_id');
					//$userId=44;
			$stateId = $this->session->userdata('state_id');
			//$stateId=$this->session->userdata('state_id');
			//$stateId =$this->session->userdata('user_id');
			$stateName = $this->session->userdata('state');
			$name = $this->session->userdata('user_full_name');
			$count = $this->survey->chkCountOfNombers($arrFilters['survey_id'],$userId,$stateId,true);
			if($count==0){
					if($stateId!=''){
						$count = $this->survey->chkCountOfNombers($arrFilters['survey_id'],$userId,$stateId,false);
					//echo $this->db->last_query();
					}else{
						$count=0;
					}
					if($count==0){
						//$stateName =$this->survey->getTopState($arrFilters['survey_id']);
						//echo $this->db->last_query();
						//if($stateName!=''){
							//$arrData['state'][]=$stateName;
						//}
						$arrData['type']=2;
					}else{
						$arrData['state'][]=$stateName;
					}
				}else{
					$arrData['user_ids'][]=$name;
					//$arrData['state_ids'][]=$stateName;
				}		
		}
		//Get the array result of connections by passing the filter parameters
		$startTime=microtime(true);
		$arrResults = $this->survey->getSurveyNomineesToRespondentConnnecions($arrData['survey_id'],$arrData);
		//echo $this->db->last_query();
		//pr($arrResults);
		
		$links = array();
		$arrNames = array();
		foreach($arrResults as $row){
			$arrLinks = array();
			if( $row['nom_kol_id']!=''){
			$arrLinks['source'] = $row['nomkolid'];
			$arrLinks['target'] = $row['respkolid'];
			$arrLinks['type'] = 'licensing';
			$links[]=$arrLinks;
			}
			//$arrNames[]
		}
		
		foreach($arrResults as $row){
			if( $row['nomkolid']!=''){
			$arrNames[$row['nomkolid']]['name'] = $row['nom_name'];
			$arrNames[$row['nomkolid']]['city'] = $row['city'];
			$arrNames[$row['nomkolid']]['state'] = $row['nstate_name'];
			$arrNames[$row['nomkolid']]['postal'] = $row['nom_postal'];
			$arrNames[$row['nomkolid']]['mid'] = $row['nmid'];
			$arrNames[$row['nomkolid']]['country'] = $row['ncountry_name'];
			$arrNames[$row['nomkolid']]['kolid'] = $row['nomkolid'];
			$arrNames[$row['nomkolid']]['status'] = $row['nom_status'];
			//$arrNames[$row['nom_kol_id']]['city'] = $row['city_name'];
			$arrNames[$row['respkolid']]['city'] = $row['respondent_city'];
			$arrNames[$row['respkolid']]['state'] = $row['rstate_name'];
			$arrNames[$row['respkolid']]['postal'] = $row['resp_postal'];
			$arrNames[$row['respkolid']] ['name']= $row['resp_name'];
			$arrNames[$row['respkolid']]['mid'] = $row['rmid'];
			$arrNames[$row['respkolid']]['country'] = $row['rcountry_name'];
			$arrNames[$row['respkolid']] ['kolid']= $row['respkolid'];
			$arrNames[$row['respkolid']]['status'] = $row['resp_status'];
		
			}
			
		}
	
		foreach($arrResults as $row){
			$topAuthors[$row['nom_kol_id']][]=$row;
		}
		foreach($topAuthors  as $key=>$value){
			$topAuthors1[(string)($key)] = count($value);
		}
		arsort($topAuthors1);
		//pr($topAuthors1);
		$topAuthors3=array_flip($topAuthors1);
		//pr($topAuthors3);
		$topAuthors4 = array_slice($topAuthors3,0,10);
	//pr($topAuthors2);
		//pr($topAuthors4);
		foreach($topAuthors4 as $row){
			$topAuthors5[]=(string)$row;
		}
		
		//	pr($topAuthors5);
		$arr['topauthors'] =$topAuthors5;
	//	pr($topAuthors1);
		$arr['links'] = $links;
		$arr['names'] = $arrNames;
		
	//	pr($arr);
		ob_start('ob_gzhandler');
		echo json_encode($arr);
		
		
		
		//echo json_encode($arrData);
	}
	
function get_geo_influence_data_desktop(){
		ini_set("max_execution_time",86400);
		//Get all the filters submited as a post data
		$arrData	= array();
		$arrData['survey_id']	= $this->input->post('survey_id');
		
		
		/*$arrData['specialty']	= $this->input->post('nominee_specialty');
		$arrData['respondent_state']	= $this->input->post('respondent_state');
		$arrData['respondent_city']		= $this->input->post('respondent_city');
		$arrData['respondent_postal']	= $this->input->post('respondent_postal');*/
		
		$arrFilters = $_POST;
		if($arrData['survey_id']=='undefined'){
			$details['arrSurveys']	= $this->survey->getCompletedSurveys();
			$arrData['survey_id']					= $details['arrSurveys'][0]['id'];
			$arrFilters['survey_id'] = $arrData['survey_id'];
		}
		$arrData['type']		= $this->input->post('influencer_type');
		if(isset($arrFilters['influencer_ids'])){
			$arrData['name']		= $this->input->post('influencer_ids');
			if($arrData['name'][0] == "All Influencers")
				array_shift($arrData['name']);
		}
		if(isset($arrFilters['country_ids'])){
			$arrData['country']		= $this->input->post('country_ids');
			if($arrData['country'][0] == "All Countries")
				array_shift($arrData['country']);
				
		}
		if(isset($arrFilters['state_ids'])){
			$arrData['state']		= $this->input->post('state_ids');
			if($arrData['state'][0] == "All States")
				array_shift($arrData['state']);
				
		}
		if(isset($arrFilters['city_ids'])){
			$arrData['city']		= $this->input->post('city_ids');
			if($arrData['city'][0] == "All Cities")
				array_shift($arrData['city']);
				
		}
		
		if(isset($arrFilters['postalcode_ids'])){
			$arrData['postal']		= $this->input->post('postalcode_ids');
			if($arrData['postal'][0] == "All Postalcodes")
				array_shift($arrData['postal']);
				
		}
		if(isset($arrFilters['respondent_ids'])){
			$arrData['respondent_id']		= $this->input->post('respondent_ids');
			if($arrData['respondent_id'][0] == "All Respondents")
				array_shift($arrData['respondent_id']);
				
		}
		if(isset($arrFilters['user_ids'])){
			$arrData['user_ids']		= $this->input->post('user_ids');
			if($arrData['user_ids'][0] == "All Users")
				array_shift($arrData['user_ids']);
				
		}
		if(isset($arrFilters['territory_ids'])){
			$arrData['territory_ids']		= $this->input->post('territory_ids');
			if($arrData['territory_ids'][0] == "All Territories")
				array_shift($arrData['territory_ids']);
		}
		if(isset($arrFilters['region_ids'])){
			$arrData['region_ids']		= $this->input->post('region_ids');
			if($arrData['region_ids'][0] == "All Regions")
				array_shift($arrData['region_ids']);
		}
		if(isset($arrFilters['district_ids'])){
			$arrData['district_ids']		= $this->input->post('district_ids');
			if($arrData['district_ids'][0] == "All Districts")
				array_shift($arrData['district_ids']);
		}
		//pr($arrData['user_ids']);

	//if($arrFilters['active_tab'] == 'influencersGeoMapTab' || $arrFilters['active_tab']=='influencersNetworkMapTab'){
		//if(empty($arrData['user_ids']) && empty($arrData['type']) && empty($arrData['state']) && empty($arrData['city']) && empty($arrData['respondent_id']) && empty($arrData['territory_ids']) && empty($arrData['region_ids']) && empty($arrData['district_ids']) && empty($arrData['name'])){
		if(empty($arrData['user_ids']) && empty($arrData['type']) && empty($arrData['state']) && empty($arrData['city']) && empty($arrData['respondent_id']) && empty($arrData['name'])){
				$userId = $this->session->userdata('user_id');
				//$userId=44;
				$name = $this->session->userdata('user_full_name');
				//$stateId=$this->session->userdata('state_id');
				$stateId = $this->session->userdata('state_id');
				$stateName = $this->session->userdata('state');
				$count = $this->survey->chkCountOfNombers($arrFilters['survey_id'],$userId,$stateId,true);
				if($count==0){
					if($stateId!=''){
						$count = $this->survey->chkCountOfNombers($arrFilters['survey_id'],$userId,$stateId,false);
					//echo $this->db->last_query();
					}else{
						$count=0;
					}
					if($count==0){
						//$stateName =$this->survey->getTopState($arrFilters['survey_id']);
						//echo $this->db->last_query();
						//if($stateName!=''){
							//$arrData['state'][]=$stateName;
						//}
						$arrData['type']=0;
					}else{
						$arrData['state'][]=$stateName;
					}
				}else{
					$arrData['user_ids'][]=$name;
					//$arrData['state_ids'][]=$stateName;
				}
				//echo $useChk;
			//	pr($arrData);
			//}
		}
		//pr($arrData['user_ids']);
		$array['lat'] = array();
		$arry['lang'] = array();
		$arrResults = $this->survey->getSurveyNomineesToRespondentConnnecionsForGeo($arrData['survey_id'],$arrData);
		//pr($arrResults);exit;
		//echo $this->db->last_query();
		///exit;
		//$startTime=microtime(true);
		//$arrResults = $this->survey->getSurveyNomineesToRespondentConnnecionsForGeo($arrData['survey_id'],$arrData);
		//$timeTaken=microtime(true)-$startTime;
		//echo "Total time taken by query : ".$timeTaken."<br />";	
		//echo  $this->db->last_query()."<br />";
		$i=1;
		//$startTime=microtime(true);
		$val =mt_rand(1, 10);
		$selectedState=array();
		
		
		 $mobile = mobile_device_detect();
		// pr($mobile);
		 if($mobile[1]=='Apple iPad'){
		 //	$arrResults = array_slice($arrResults,0,100);
		 }
	//	pr($arrResults);
		foreach($arrResults as $row){
			$key = in_array($row['nom_name'],$array['names'] );
				if(($row['nomineLat']!='')){
				if(in_array($row['nomineLat'],$array['lat']) && !($key)){
					$val =mt_rand(1, 10);
					$random_num_lat = .00065 * mt_rand(1, 10);
					$random_num_lng = .00065 * mt_rand(1, 10);
					$row['nomineLat'] = $row['nomineLat']+('0.00'.mt_rand(1, 10));
					$array['lat'][] = $row['nomineLat'];
					$array['names'][$row['nom_name']] = $row['nom_name'];
					$array['names1'][$row['nom_name']]['lat'][] =$row['nomineLat'];
					$array['names1'][$row['nom_name']]['lat'][] =$row['nom_name'];
				}else{
					//$row['nomineLat'] = $array['names'][$row['nom_name']]['lat'];
					$array['lat'][] = $row['nomineLat'];
					$array['names'][$row['nom_name']] = $row['nom_name'];
				}
			}
			if($i==1){
				if($arrData['state']!=''){
					
					foreach($arrData['state'] as $state){
						if($row['state']==$state){
							$selectedState['selectedLat'] = $row['nomineLat'];
							$selectedState['selectedLang'] = $row['nominelang'];
							$i++;
						}
					}
				}
			}
			
			$arrLangAndLat[]=$row;
		}
	//	pr($array['names1']);
		foreach($arrLangAndLat as $row1){
			foreach($array['names1'] as $lat){
				if($lat['lat'][1] == $row1['nom_name']){
					$row1['nomineLat']  = $lat['lat'][0];
				}
			}
			
			$arrDetails[] = $row1;
		}
		
		//pr($arr);
		//pr($arrDetails);
		$arrData1['kols'] = $arrDetails;
		$arrData1['selectedState'] = $selectedState;
		//$arrData1['filters'] = $arrData;
		//$timeTaken=microtime(true)-$startTime;
		//echo "Total time taken to prepare the data : ".$timeTaken."<br />";
		ob_start('ob_gzhandler');
		echo json_encode($arrData1);
	}
	
	function list_active_surveys_within_kols($kolId){
		$this->session->set_userdata("is_from_kol",1);
		$arrData	= array();
		$arrData['withinProfile']	= true;
		$arrData['arrSurveys']	= $this->survey->getActiveSurveys();
		$arrData['showReports'] = true;
		$this->load->view('surveys/active_surveys', $arrData);
	}
	
	function check_kol_already_survey($surveyId,$kolId){
		$arrKol = $this->kol->editKol($kolId);
		$arrIcont = $this->survey->getIcontactByNpiNumOrByName($arrKol);
//		echo $this->db->last_query();
//		exit;
		if($arrIcont){
			$this->isRespondentAlreadySurveyed($surveyId,$arrIcont['kol_id'],$arrIcont['id']);
		}else{
			$data['status'] = false;
			echo json_encode($data); 
		}
	}

	function get_kol_data_for_survey(){
		 $kolId	= $this->input->post('kol_id');
		 echo json_encode($this->survey->getKolDetailsForSurvey($kolId));
	}
	
	function search_kol_names(){
		$arrData['name']		= trim($this->input->post('name'));
		$arrData['orgname']		= trim($this->input->post('orgname'));
		$arrData['country']		= trim($this->input->post('country'));
		$arrData['state']		= trim($this->input->post('state'));
		$arrData['city']		= trim($this->input->post('city'));
		$arrData['postal']		= trim($this->input->post('postal'));
		$arrData['isRespondentOrInfluencer']		= $isRespondentOrInfluencer;
		$arrData['queryData']	= $arrData;
		$this->load->view('surveys/searched_name_results',$arrData);
	}
	function add_new_respodent($appendId){
		$data['arrCountry']=$this->Country_helper->listCountries();
		$data['appendId'] = $appendId;
		$this->load->view('surveys/add_new_respodent',$data);
	}
	
	function get_all_specialty_for_autocomplete($spaciltyName) {
		$spaciltyName = utf8_urldecode($this->input->post($spaciltyName));
		$this->load->model('Specialty');
		$arrSpecialty = $this->Specialty->getAllSpecialtyForAutocomplete($spaciltyName);
		$arrSuggestSpecialties = array();
		if (sizeof($arrSpecialty) == 0) {
			$arrSuggestSpecialties[0] = 'No results found for ' . $spaciltyName;
		} else {
			$flag = 1;
			foreach ($arrSpecialty as $id => $name) {
				if ($flag) {
					$arrSuggestSpecialties[] = '<div class="autocompleteHeading">Specialties</div><div class="dataSet"><label name="' . $id . '" class="specialties" style="display:block">' . $name . "</label></div>";
					$flag = 0;
				} else {
					$arrSuggestSpecialties[] = '<div class="dataSet"><label name="' . $id . '" class="specialties" style="display:block">' . $name . "</label></div>";
				}
			}
		}
		$arrReturnData['query'] = $spaciltyName;
		$arrReturnData['suggestions'] = $arrSuggestSpecialties;
		echo json_encode($arrReturnData);
	}
	
	function load_all_kols(){
		$page		= (int)$_REQUEST['page']; // get the requested page
		$limit 		= (int)$_REQUEST['rows']; // get how many rows we want
		$sidx 		= $_REQUEST['sidx']; // get index row - i.e. user click to sort
		$sord 		= $_REQUEST['sord']; // get the direction
		
		$arrResult1 = $this->survey->getKolDetailsForSurvey($kolId);
		
		$arrResult2 = $this->survey->getKolDetailsFromMasterTable($kolId);
		
		$arrResult = array_merge($arrResult1,$arrResult2); 
		
		$count = sizeof($arrResult);
		if( $count >0 ) {
			$total_pages = ceil($count/$limit);
		}else {
			$total_pages = 0;
		}
		if ($page > $total_pages) $page=$total_pages;
		$start = $limit*$page - $limit; // do not put $limit*($page - 1)
		if ($start < 0) $start = 0;
		
		$data = array();
		$data['records']= $count;
		$data['total']  = $total_pages;
		$data['page']	= $page;
		$data['rows']	= $arrResult;
		
		echo json_encode($data);
	}
	
	function save_missing_contact(){
		$respodentData['first_name'] = trim($this->input->post('first_name'));
		$respodentData['middle_name'] = trim($this->input->post('middle_name'));
		$respodentData['last_name'] = trim($this->input->post('last_name'));
		$respodentData['country'] = trim($this->input->post('country'));
		$respodentData['state'] = trim($this->input->post('state'));
		$respodentData['city'] = trim($this->input->post('city'));
		$respodentData['postal_code'] = trim($this->input->post('postal_code'));
		$respodentData['organization'] = trim($this->input->post('organization'));
		$respodentData['speciality'] = trim($this->input->post('speciality'));
		
		$arrResult = $this->survey->saveMissingContact($respodentData);
		echo json_encode($arrResult);
	}
	
	function save_survey_response(){
		$user_id	= $this->session->userdata('user_id');
		$survey_id	= $this->input->post('survey_id');
		$preparedStatements	= '';
		$separator		= '';
		$created_on		= date("Y-m-d H:i:s");
		$preparedStatements	= "insert into survey_answers(question_id, nominee_id, respondent_id, created_by, created_on, survey_id) values ";
		//Prepare respondent details to store in database table kol_names_for_survey and get id
		$arrRespData = array();
		$arrRespData['first_name']	= $this->input->post('respondent_first_name');
		$arrRespData['middle_name']	= $this->input->post('respondent_middle_name');
		$arrRespData['last_name']	= $this->input->post('respondent_last_name');
		$arrRespData['country']	= $this->input->post('respondent_country');
		$arrRespData['state']	= $this->input->post('respondent_state');
		$arrRespData['city']	= $this->input->post('respondent_city');
		$arrRespData['postal_code']	= $this->input->post('respondent_postal_code');
		$arrRespData['speciality']	= $this->input->post('respondent_speciality');
		$arrRespData['organization']	= $this->input->post('respondent_organization');
		$arrRespData['source_table']	= 'kols';
		$arrRespData['source_table_id']	= $this->input->post('respondent_id');
		
		
		$arrResResult = $this->survey->saveKolsToMasterTable($arrRespData);
		
		$respondent_id	= $arrResResult['id'];
		
		//Prepare influancer details to store in database table kol_names_for_survey and get id
		
		$survey_question_ids = $this->input->post('survey_question_id');
		$size = sizeof($survey_question_ids);
		for($i=0;$i<$size;$i++){
			 $question_id	= $survey_question_ids[$i];
			 $arrInfDataPrepare['first_name']	= $this->input->post('influencer_first_name_'.$survey_question_ids[$i]);
			 $arrInfDataPrepare['middle_name']	= $this->input->post('influencer_middle_name_'.$survey_question_ids[$i]);
			 $arrInfDataPrepare['last_name']	= $this->input->post('influencer_last_name_'.$survey_question_ids[$i]);
			 $arrInfDataPrepare['country']	= $this->input->post('influencer_country_'.$survey_question_ids[$i]);
			 $arrInfDataPrepare['state']	= $this->input->post('influencer_state_'.$survey_question_ids[$i]);
			 $arrInfDataPrepare['city']	= $this->input->post('influencer_city_'.$survey_question_ids[$i]);
			 $arrInfDataPrepare['postal_code']	= $this->input->post('influencer_postal_code_'.$survey_question_ids[$i]);
			 $arrInfDataPrepare['speciality']	= $this->input->post('influencer_speciality_'.$survey_question_ids[$i]);
			 $arrInfDataPrepare['organization']	= $this->input->post('influencer_organization_'.$survey_question_ids[$i]);
			 $arrInfDataPrepare['source_table']	= NULL;
			 $arrInfDataPrepare['source_table_id']	= $this->input->post('influencer_kolid_'.$survey_question_ids[$i]);
			 $count = sizeof($arrInfDataPrepare['first_name']);
			 
			 if($count>0){
			 for($j=0;$j<$count;$j++){
			 	$arrInfDataStore = array();
			 	$arrInfDataStore['first_name']	= $arrInfDataPrepare['first_name'][$j];
			 	$arrInfDataStore['middle_name']	= $arrInfDataPrepare['middle_name'][$j];
			 	$arrInfDataStore['last_name']	= $arrInfDataPrepare['last_name'][$j];
			 	$arrInfDataStore['country']	= $arrInfDataPrepare['country'][$j];
			 	$arrInfDataStore['state']	= $arrInfDataPrepare['state'][$j];
			 	$arrInfDataStore['city']	= $arrInfDataPrepare['city'][$j];
			 	$arrInfDataStore['postal_code']	= $arrInfDataPrepare['postal_code'][$j];
			 	$arrInfDataStore['speciality']	= $arrInfDataPrepare['speciality'][$j];
			 	$arrInfDataStore['organization']	= $arrInfDataPrepare['organization'][$j];
			 	$arrInfDataStore['source_table']	= 'kols';
			 	$arrInfDataStore['source_table_id']	= $arrInfDataPrepare['source_table_id'][$j];
			 	//pr($arrInfDataStore);
			 	$arrInfResult = $this->survey->saveKolsToMasterTable($arrInfDataStore);
			 				$nominee_id	= $arrInfResult['id'];
			 				$preparedStatements	.= $separator.'("'.$question_id.'","'.$nominee_id.'","'.$respondent_id.'","'.$user_id.'","'.$created_on.'","'.$survey_id.'")';
			 				$separator		= ',';
			 }
			}
			
		}
		//echo $preparedStatements;
		$result = $this->survey->insertSurveyAnswers($preparedStatements);
		
		/* 
		$survey_question_ids = $this->input->post('survey_question_id');
		$size = sizeof($survey_question_ids);
		for($i=0;$i<=$size;$i++){
			echo $survey_question_ids[$i];
		}
		pr($arrResult); */
		if($result){
			$data['status'] = 'success';
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add survey answers',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => '',
					'transaction_id' =>  $survey_id,
					'transaction_table_id' => SURVEY_ANSWERS,
					'transaction_name' => 'Add survey answers',
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
		}else{
			$data['status'] = 'fail';
			//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add survey answers',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => '',
					'transaction_id' =>  $survey_id,
					'transaction_table_id' => SURVEY_ANSWERS,
					'transaction_name' => 'Add survey answers',
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
			
		}
		echo json_encode($data);
	}
	
	function save_update_survey_response(){
		$user_id	= $this->session->userdata('user_id');
		$survey_id	= $this->input->post('survey_id');
		$respondent_id = $this->input->post('respondent_survey_ans_id');
		$preparedStatements	= '';
		$separator		= '';
		$created_on		= date("Y-m-d H:i:s");
		$preparedStatements	= "insert into survey_answers(question_id, nominee_id, respondent_id, created_by, created_on, survey_id) values ";
		
		$survey_question_ids = $this->input->post('survey_question_id');
		$size = sizeof($survey_question_ids);
		for($i=0;$i<$size;$i++){
			$question_id	= $survey_question_ids[$i];
			$arrInfDataPrepare['first_name']	= $this->input->post('influencer_first_name_'.$survey_question_ids[$i]);
			$arrInfDataPrepare['middle_name']	= $this->input->post('influencer_middle_name_'.$survey_question_ids[$i]);
			$arrInfDataPrepare['last_name']	= $this->input->post('influencer_last_name_'.$survey_question_ids[$i]);
			$arrInfDataPrepare['country']	= $this->input->post('influencer_country_'.$survey_question_ids[$i]);
			$arrInfDataPrepare['state']	= $this->input->post('influencer_state_'.$survey_question_ids[$i]);
			$arrInfDataPrepare['city']	= $this->input->post('influencer_city_'.$survey_question_ids[$i]);
			$arrInfDataPrepare['postal_code']	= $this->input->post('influencer_postal_code_'.$survey_question_ids[$i]);
			$arrInfDataPrepare['speciality']	= $this->input->post('influencer_speciality_'.$survey_question_ids[$i]);
			$arrInfDataPrepare['organization']	= $this->input->post('influencer_organization_'.$survey_question_ids[$i]);
			$arrInfDataPrepare['source_table']	= NULL;
			$arrInfDataPrepare['source_table_id']	= $this->input->post('influencer_kolid_'.$survey_question_ids[$i]);
			$count = sizeof($arrInfDataPrepare['first_name']);
			if($count>0 && ($arrInfDataPrepare['first_name']!='')){
				for($j=0;$j<$count;$j++){
					$arrInfDataStore = array();
					$arrInfDataStore['first_name']	= $arrInfDataPrepare['first_name'][$j];
					$arrInfDataStore['middle_name']	= $arrInfDataPrepare['middle_name'][$j];
					$arrInfDataStore['last_name']	= $arrInfDataPrepare['last_name'][$j];
					$arrInfDataStore['country']	= $arrInfDataPrepare['country'][$j];
					$arrInfDataStore['state']	= $arrInfDataPrepare['state'][$j];
					$arrInfDataStore['city']	= $arrInfDataPrepare['city'][$j];
					$arrInfDataStore['postal_code']	= $arrInfDataPrepare['postal_code'][$j];
					$arrInfDataStore['speciality']	= $arrInfDataPrepare['speciality'][$j];
					$arrInfDataStore['organization']	= $arrInfDataPrepare['organization'][$j];
					$arrInfDataStore['source_table']	= 'kols';
					$arrInfDataStore['source_table_id']	= $arrInfDataPrepare['source_table_id'][$j];
						
					$arrInfResult = $this->survey->saveKolsToMasterTable($arrInfDataStore);
					$nominee_id	= $arrInfResult['id'];
					$preparedStatements	.= $separator.'("'.$question_id.'","'.$nominee_id.'","'.$respondent_id.'","'.$user_id.'","'.$created_on.'","'.$survey_id.'")';
					$separator		= ',';
				}
			}
				
		}
		$result = $this->survey->insertSurveyAnswers($preparedStatements);
		if($result){
			$data['status'] = 'success';
			//Add Log activity
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Update survey answers',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => '',
					'transaction_id' =>  $survey_id,
					'transaction_table_id' => SURVEY_ANSWERS,
					'transaction_name' => 'Update survey answers',
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
		}else{
			$data['status'] = 'fail';
			//Add Log activity
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Update survey answers',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => '',
					'transaction_id' =>  $survey_id,
					'transaction_table_id' => SURVEY_ANSWERS,
					'transaction_name' => 'Update survey answers',
					'parent_object_id' =>  ''
			);
			$this->config->set_item('log_details', $arrLogDetails);
		}
		echo json_encode($data);
	}
	function delete_influencer(){
		$survey_answer_id = $this->input->post('todelele');
		$created_by = $this->input->post('user_id');
		$result = $this->survey->deleteInfluencer($survey_answer_id, $created_by);
		$arrData['status']	= $result;
		echo json_encode($arrData);
	}
	
	function store_latitude_longitude_for_survey_kols(){
		$result = $this->survey->storeLatitudeLongitudeForSurveyKols();
	}
	
}
?>