<?php  $currentController = $this->uri->segment(1);
?>
<style type="text/css">
	/*    Enable Verticle separator between content and side menu list  By Laxman   */
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
/*	#medContainer{
		width: 800px;
		margin-top: -75px;
		margin-top: 0px;
		float: right;
	}*/
	select.chosenSelect{
		width:200px;
	}
	td .chzn-container-multi .chzn-choices{
		height: 60px !important;
	}
	.alignRight{
		padding-right:0px;
                    width: 350px;
	}
	.alignCenter{
		text-align: center;
	}
	table caption{
		background:url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat-x scroll -2px -236px transparent;
	}
	/*table {
    	border: 1px solid #DDDDDD;
    }*/
	.alighRight{
		text-align: right;
	}
        tr.border_bottom td,tr.border_bottom th {
  border-top:1px solid;
  border-color:#D4D4D4;
}
</style>

<button value="Back To Medical Insight" onclick="window.history.back();">Back To Medical Insight</button>
<div id="medContainer">
		<table style="margin-top:5px;">
			<caption style="font-weight: bold;">Medical Insight</caption>
                        <tr>
				<th class="alignRight">Medical Insight ID:</th>
				<td><?php echo $arrData['generic_id'];?></td>
				
			</tr>
			<tr>
				<th class="alignRight">Therapeutic Area:</th>
				<td><?php echo $arrData['specialty'];?></td>
				<td>&nbsp;</td>
                                <?php if (!empty($arrData['agent'])) { ?>
				<th class="alignRight">Investigational Agent:</th>
				<td><?php echo $arrData['agent'];?></td>
                                  <?php } ?>
			</tr>
			<tr>
				<th class="alignRight">Product and Investigational Agent Category:</th>
				<td><?php echo $arrData['product'];?></td>
				<td>&nbsp;</td>
				<th class="alignRight">Source Type:</th>
				<td><?php echo $arrData['source_type'];?></td>
			</tr>
                         <?php 
                           if ((!empty($arrData['congress_sources'])) || (!empty($arrData['congress_name']))) {
                            ?>
                        <tr>
				<th class="alignRight">Congress Source:</th>
				<td><?php echo $arrData['congress_sources'];?></td>
				<td>&nbsp;</td>
                                <th class="alignRight">Congress Name:</th>
				<td><?php echo $arrData['congress_name'];?></td>
			</tr>
                        <?php } ?>
                        <tr>   <?php if (!empty($arrData['sphere_of_influence'])) { ?>
				<th class="alignRight">Sphere of Influence:</th>
				<td><?php echo $arrData['sphere_of_influence'];?></td>
                                 <?php } else { ?>
                                <th class="alignRight">&nbsp;</th>
				<td>&nbsp;</td>
                                 <?php } ?>
                                <?php if($currentController=='kols') { ?>
                                <td>&nbsp;</td>
                                <th class="alignRight"><?php echo lang("HCP");?> Name:</th>
                                <td><?php if (($arrKolDetail['salutation'] != '') || ($arrKolDetail["first_name"] != '') || ($arrKolDetail["middle_name"] != "") || ($arrKolDetail["last_name"] != ''))
                                    //echo $arrKolDetail["salutation"] . " " . $arrKolDetail["first_name"] . " " . $arrKolDetail["middle_name"] . " " . $arrKolDetail["last_name"];
                                    echo $this->common_helpers->get_name_format($arrKolDetail['first_name'],$arrKolDetail['middle_name'],$arrKolDetail['last_name']);
                                ?>
                                </td>
                     <?php } else if ($currentController == 'coachings') { ?>
                        <td>&nbsp;</td>
        <?php if (!empty($arrData['kol_id'])) 
//  if (($arrKolDetail['salutation'] != '') || ($kolname["first_name"] != '') || ($kolname["middle_name"] != "") || ($kolname["last_name"] != ''))
      { ?>
                            <th class="alignRight"><?php echo lang("HCP");?> Name:</th>
                            <td><?php echo $arrData['kol_id'];
            //echo $arrKolDetail["salutation"] . " " . $kolname["first_name"] . " " . $kolname["middle_name"] . " " . $kolname["last_name"];
//             echo $this->common_helpers->get_name_format($kolname['first_name'],$kolname['middle_name'],$kolname['last_name']);
        }
        ?>
                        </td>
                            <?php } ?>
			</tr>
                       
		</table>
		<table style="margin-top:5px;">
			<caption style="font-weight: bold;">Key Insight Topics</caption>
			<tr>
				<td>
						<?php  $arrTopics	= explode(', ',$arrData['topics']);
								foreach($arrTopics as $key=>$value){
                                                                      if(!empty($value))
									echo $value.' ';
								}
						?>
				</td>
			</tr>
		</table>
		<table style="margin-top:5px;">
			<caption style="font-weight: bold;">Medical Insight Details</caption>
                
                        <tr class="border_bottom">
                                <th class="alighRight" style="width: 170px;vertical-align: top;">
                                    
    <label style="font-weight: bold;">Medical Insight Summary:</label>
	</th>
				<td>
					<?php echo $arrData['summary'];?>

				</td>
                        </tr>
                          <?php if (!empty($arrData['relevance'])) {?>
            <tr class="border_bottom">            
                    <th class="alighRight" style="width: 170px;vertical-align: top;"><label style="font-weight: bold;"> Describe Relevance to OPDC:</label>
                        </th>
					<td><?php echo $arrData['relevance'];?></td>
               </tr> 
               
                <?php } ?>
                <?php if (!empty($arrData['actions_to_consider'])) {?>
			<tr class="border_bottom">            
                   <th class="alighRight" style="width: 170px;vertical-align: top;">
			 	<label style="font-weight: bold;">Actions to Consider:</label>
				</th>
				<td>	<?php echo $arrData['actions_to_consider'];?>
                </td>
                </tr>
                 <?php } ?>
                <?php if (!empty($arrData['other'])) {
//                         if($arrData['other']!="") {?>
               <tr class="border_bottom">            
                   <th class="alighRight" style="width: 170px;vertical-align: top;">
			 		<label style="font-weight: bold;">Other:</label>
				</th>
				<td>	
                              <?php echo $arrData['other'];?>
                </td>
                </tr>
                <?php } ?>
   </table>
</div><br/><br/>

<table><tr>
        <td><strong>Recorded By: </strong><?php echo $arrData['created_user']?></td>
        </tr>
        <tr>
        <td><strong>Recorded On: </strong><?php echo $arrData['created_on']?></td>
    </tr></table>
