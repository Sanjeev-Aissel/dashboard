<?php
/**
 * This is Model file of 'Organization'
 *
 * @package application.models
 * @author Ambarish
 * @since
 * @created on 17-01-11
 */

class Organization extends Model{
	
	//Constructor
	function Organization(){
		parent::Model();
	}
	/**
	 * Returns all KeyPeople Types from 'key_people_types' Table
	 * 
	 * @return unknown_type
	 */
	function getAllKeyPeopleRoles(){
		$arrKeyPeopleRoles	= array();
		
		$arrKeyPeopleRolesResult = $this->db->get('key_people_roles');
		foreach($arrKeyPeopleRolesResult->result_array() as $arrKeyPeopleRole){
			$arrKeyPeopleRoles[$arrKeyPeopleRole['id']]	= $arrKeyPeopleRole['role'];
		}
		return $arrKeyPeopleRoles;
	}
	
	/*
	* Returns the Id of the  RoleName
	*/
	function getKeyPeopleRoleIdByName($roleName=''){
		
		$roleId='';
		if($roleName !=''){
			$this->db->select('id');
			$this->db->where('role',$roleName);
			$arrRoleId = $this->db->get('key_people_roles');
			foreach($arrRoleId->result_array() as $row){
				$roleId = $row['id'];
			}
		}
		return $roleId;
	}
	
	
	/*
	* Returns the RoleName of the  Id
	*/
	function getKeyPeopleRoleNameById($roleId=''){
		
		$roleName='';
		if($roleId !=''){
			$this->db->select('role');
			$this->db->where('id',$roleId);
			$arrRoleName = $this->db->get('key_people_roles');
			foreach($arrRoleName->result_array() as $row){
				$roleName = $row['role'];
			}
		}
		return $roleName;
	}
	
	
	/**
	 * Returns all Organization Types from 'organization_types' Table
	 * 
	 * @return unknown_type
	 */
	function getAllOrganizationTypes(){
		$arrOrganizationTypes	= array();
		
		$arrOrganizationTypesResult = $this->db->get('organization_types');
		foreach($arrOrganizationTypesResult->result_array() as $arrOrganizationType){
			$arrOrganizationTypes[$arrOrganizationType['id']]	= $arrOrganizationType['type'];
		}
		return $arrOrganizationTypes;
	}	
	
	 /**
	 * Saves the Contact Details Data to DB 
	 * 
	 * @return true/false
	 */
	function saveContact($contactDetails){
		if($this->db->insert('org_additional_contacts',$contactDetails)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	
//   	/**
//	 * List all Contacts Data 
//	 * 
//	 * @return true/false
//	 */
//	function listContacts($orgId = null){
//		$arrContactDetails=array();
//		if($orgId != null){
//			$this->db->where('org_id', $orgId);
//		}
//				
//		if($arrContactDetailsResult = $this->db->get('org_additional_contacts')){
//			foreach ($arrContactDetailsResult->result_array() as $arrContact){
//				$arrContactDetails[]=$arrContact;
//			}
//			return $arrContactDetails;
//		}else{
//			return false;
//		}
//	}
	
   	/**
	 * List all Contacts Data 
	 * 
	 * @return true/false
	 */
	function listContacts($orgId = null){
		if($orgId != null){
			$this->db->where('org_id', $orgId);
		
				
			if($arrContactDetails = $this->db->get('org_additional_contacts')){
				return $arrContactDetails;
			}
		}else{
			return false;
		}
	}
	
  /**
	 * Edit the Contact Details 
	 * 
	 * @return true/false
	 */
	function editContactById($id){
		$this->db->where('id',$id);
		if($arrContactDetails = $this->db->get('org_additional_contacts')){
			return $arrContactDetails;
		}else{
			return false;
		}
	}
	
    /**
	 * Updates the Contact Detail Data 
	 * 
	 * @return true/false
	 */
	function updateContact($contactDetails){
		$this->db->where('id',$contactDetails['id']);
		if($this->db->update('org_additional_contacts',$contactDetails)){
			return true;
		}else{
			return false;
		}
	}
	
   	/**
	 * Delete the Contact Detail By Id
	 * 
	 */	
 	function deleteContactById($id){
 		
		$this->db->where('id',$id);
		if($query=$this->db->delete('org_additional_contacts')){
			return true;
		}else
			return false;
	}
	
//   	/**
//	 * List all KeyPeoples Data 
//	 * 
//	 * @return true/false
//	 */
//	function listKeyPeoples($orgId = null){
//		$arrKeyPeopleDetails=array();
//		if($orgId != null){
//			$this->db->where('org_id', $orgId);
//		}
//				
//		if($arrKeyPeopleDetailsResult = $this->db->get('key_peoples')){
//			foreach ($arrKeyPeopleDetailsResult->result_array() as $arrKeyPeople){
//				$arrKeyPeopleDetails[] = $arrKeyPeople;
//			}
//			return $arrKeyPeopleDetails;
//		}else{
//			return false;
//		}
//	}
	
  	/**
	 * Saves the Organization Detail to DB 
	 * 
	 * @return Last Insert Id/false
	 */
	function saveOrganization($organizationDetails){
		$orgName = '';
		$orgName = $organizationDetails['name'];
		$this->db->where('name',$orgName);
		if(isset($organizationDetails['cin_num'])){
			$this->db->where('cin_num',$organizationDetails['cin_num']);
		}
		if($arrOrganization = $this->db->get('organizations')){
			if($arrOrganization->num_rows!=0){
				$result=$arrOrganization->row();
				if($result!=null)
					$id=$result->id;
				$organizationDetails['id']	= $id; 
				$this->updateImportedOrganization($organizationDetails);
					return $id;
			}else{			    
				if($this->db->insert('organizations',$organizationDetails)){				    
					return $this->db->insert_id();
				}else{
					return false;
				}				
			}	
		}
	}
	
	
	
	/**
	 *  List all Organization details
	 * @param 
	 * @return array - $arrOrganizationDetail - Returns
	 */
	function listOrganizationDetails(){
		$arrOrganizationDetail	=	array();
		//For getting the Created by Name
		$this->db->select(array('organizations.*','client_users.user_name as user_full_name','countries.country','organization_types.type'));
		$this->db->join('client_users', 'client_users.id = organizations.created_by', 'left');
		$this->db->join('organization_types', 'organization_types.id = organizations.type_id', 'left');
		$this->db->join('countries','countries.countryId = organizations.country_id', 'left');
		$this->db->order_by('organizations.name','asc');
		$arrOrganizationDetailResult	=	$this->db->get('organizations');
		
		foreach ($arrOrganizationDetailResult->result_array() as $organizationDetail){
			$organizationDetail['created_by']=$organizationDetail['user_full_name'];
			$arrOrganizationDetail[] = $organizationDetail;
		}
     	return $arrOrganizationDetail;
	}
	
	
	function listOrganizationGridDetails($limit=null,$startFrom=null,$doCount=null,$sidx = '',$sord = '',$where = ''){
	if(!$doCount){
			$this->db->select(array('organizations.*','client_users.user_name as user_full_name','countries.country','organization_types.type'));
		}
		$this->db->join('client_users', 'client_users.id = organizations.created_by', 'left');
		$this->db->join('organization_types', 'organization_types.id = organizations.type_id', 'left');
		$this->db->join('countries','countries.countryId = organizations.country_id', 'left');
			
		//Add the where conditions for any jqgrid filters
		if(isset($where['name'])){
			$this->db->where("(organizations.name LIKE '%".$where['name']."%')");
		}
		if(isset($where['founded'])){
			$this->db->like('organizations.founded',$where['founded']);
		}
		if(isset($where['type'])){
			$this->db->like('organization_types.type',$where['type']);
		}
		if(isset($where['is_pubmed_processed'])){
			if(preg_match("/[yes]{1,}/i",$where['is_pubmed_processed']))
				$where['is_pubmed_processed'] = 1;
			elseif(preg_match("/[no]{1,}/i",$where['is_pubmed_processed']))
				$where['is_pubmed_processed'] = 0;
			elseif(preg_match("/[recrawl]{1,}/i",$where['is_pubmed_processed']))
				$where['is_pubmed_processed'] = 2;
			$this->db->like('organizations.is_pubmed_processed',$where['is_pubmed_processed']);
		}
		if(isset($where['is_clinical_trial_processed'])){
			if(preg_match("/[yes]{1,}/i",$where['is_clinical_trial_processed']))
				$where['is_clinical_trial_processed'] = 1;
			elseif(preg_match("/[no]{1,}/i",$where['is_clinical_trial_processed']))
				$where['is_clinical_trial_processed'] = 0;
			$this->db->like('organizations.is_clinical_trial_processed',$where['is_clinical_trial_processed']);
		}
		if(isset($where['profile_type'])){
			if(preg_match("/[basic]{1,}/i",$where['profile_type']))
				$where['profile_type'] = 1;
			elseif(preg_match("/[full]{1,}/i",$where['profile_type']))
				$where['profile_type'] = 2;
			$this->db->like('organizations.profile_type',$where['profile_type']);
		}
		if(isset($where['created_by'])){
			$this->db->like('client_users.user_name',$where['created_by']);
		}
		if(isset($where['status'])){
			$this->db->like('organizations.status',$where['status']);
		}
	
//		$this->db->where("(client_users.client_id=".INTERNAL_CLIENT_ID." or kols.status='".COMPLETED."')");
	
		if($doCount){
			$this->db->distinct();
			$count=$this->db->count_all_results('organizations');
			return $count;
		} else {
			if($sidx!='' && $sord!=''){
				switch($sidx){
					case 'name' : $this->db->order_by("organizations.name",$sord);
					   				break;
					case 'status' :$this->db->order_by("organizations.status",$sord);
					   				break;
					case 'type_id' :$this->db->order_by("organization_types.type",$sord);
					   				break;
					case 'is_pubmed_processed' :$this->db->order_by("organizations.is_pubmed_processed",$sord);
					   				break;
					case 'is_clinical_trial_processed' :$this->db->order_by("organizations.is_clinical_trial_processed",$sord);
					   				break;	
					case 'profile_type' :$this->db->order_by("organizations.profile_type",$sord);
					   				break;	
					case 'created_by' :$this->db->order_by("client_users.user_name",$sord);
					   				break;
					case 'status' :$this->db->order_by("organizations.status",$sord);
					   				break;
				}
				//$this->db->order_by($sidx,$sord);
			}
			$this->db->order_by('name','asc');
		
			$arrOrgDetail	=	$this->db->get('organizations',$limit,$startFrom);
			return $arrOrgDetail;
		}
	}
	
	/**
	 * Edit Organization details
	 * @param $id
	 * @return array - $arrOrganizationDetail 
	 */  
	function editOrganization($id){
		$arrOrganizationDetail	= array();
		$this->db->where('id',$id);
		if($arrOrganizationDetailResult	=	$this->db->get('organizations')){
		// If the results are not available
		if($arrOrganizationDetailResult->num_rows() == 0){
			return false;
		}
		    		
		foreach($arrOrganizationDetailResult->result_array() as $arrOrganization){
			if($arrOrganization['postal_code']=='0'){
				$arrOrganization['postal_code']='';
			}
			$arrOrganizationDetail	= $arrOrganization;
		}
//                pr($arrOrganizationDetail);
		return $arrOrganizationDetail;
		}else{
			return false;
		}
	}	
	
  	/**
	 * Updates the Event Data 
	 * 
	 * @return true/false
	 */
	function updateOrganization($organizationDetails, $affPartnershipDetails = 0){
		$this->db->where('id',$organizationDetails['id']);
		if($this->db->update('organizations',$organizationDetails)){
			//return true;
			if($affPartnershipDetails != 0){
				
				$this->db->insert('affiliates_partnerships',$affPartnershipDetails);
				return true;
			}else{
				return true;
			}
		}else
			return false;
	}

  	/**
	 * Saves the  Key people Detail to DB 
	 * 
	 * @return Last Insert Id/false
	 */
	function saveKeyPeople($keyPeopleDetails){
		if($this->db->insert('key_peoples',$keyPeopleDetails)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}	
	
   	/**
	 * Updates the Key people Detail Data 
	 * 
	 * @return true/false
	 */
	function updateKeyPeople($keyPeopleDetails){
		$result=array();
		$this->db->where('id',$keyPeopleDetails['id']);
		if($this->db->update('key_peoples',$keyPeopleDetails)){
			return true;
		}else{
			return false;
		}
	}
	
 	/**
	 * Delete the Key people Data 
	 * 
	 */	
 	function deleteKeyPeople($id){
		$this->db->where('id',$id);
		if($query=$this->db->delete('key_peoples')){
			return true;
		}else
			return false;
	}
	
   	/**
	 * List all Key People Details Data 
	 * 
	 * @return true/false
	 */
	function listKeyPeoples($organizationId = null){
		$arrKeyPeopleDetails = array();
		//Get the Events of KolId
		if($organizationId != null){
			$this->db->where('org_id', $organizationId);
		
			$this->db->select(array('key_peoples.*','key_people_roles.role','client_users.client_id','CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name'));
			$this->db->join('key_people_roles','key_people_roles.id = key_peoples.role_id', 'left');
			$this->db->join('organizations','organizations.id = key_peoples.org_id', 'left');
			$this->db->join('client_users','client_users.id = key_peoples.created_by', 'left');
			//For Salutation loading
			$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
			if($arrKeyPeopleDetailsResult = $this->db->get('key_peoples')){
				foreach($arrKeyPeopleDetailsResult->result_array() as $arrKeyPeople){
						$arrKeyPeople['eAllowed'] = $this->common_helpers->isActionAllowed('org_details','edit',$arrKeyPeople);
						$arrKeyPeople['role_id'] = $arrKeyPeople['role'];
						if($arrKeyPeople['salutation'] !='0'){
							$arrKeyPeople['salutation'] = $arrSalutations[$arrKeyPeople['salutation']];
						}
						$arrKeyPeopleDetails[] = $arrKeyPeople;
				}
				return $arrKeyPeopleDetails;
			}
		}else{
			return false;
		}
	}
	
	/**
	 * List all  MAtched Events Data 
	 * 
	 * @return $arrEventsDetails/false
	 */
	function getMatchOrganiations($arrFilterOrgs,$limit,$startFrom,$doCount,$doGroupBy=false,$groupByCategory=null){
		$arrOrganizations	=	array();
		//$this->db->limit(10);
//$this->db->get('organizations');
//echo $this->db->last_query();
//exit;
		//$this->db->distinct();
		$this->db->select('organizations.name,organizations.parent_id,organizations.id,countries.country,organizations.country_id, organizations.type_id as org_type_id, organization_types.type,organizations.company_logo,organizations.headquarters,organizations.phone,organizations.founded,regions.region as state,cities.City as city,organizations.state_id,organizations.city_id,organizations.profile_type,organizations.website,organizations.created_by,organizations.status, countries.GlobalRegion');
		
		$this->db->join('countries','countries.countryId = organizations.country_id', 'left');
		$this->db->join('regions','regions.regionID = organizations.state_id', 'left');
                $this->db->join('cities','cities.cityId = organizations.city_id', 'left');
		$this->db->join('organization_types','organization_types.id = organizations.type_id','left');
		//$this->db->join('key_peoples','key_peoples.org_id = organizations.id','left');
		
		//$where="(name LIKE '%".$orgName."%' OR key_peoples.first_name LIKE '%".$orgName."%' OR key_peoples.middle_name LIKE '%".$orgName."%' OR key_peoples.last_name LIKE '%".$orgName."%')";
		//in order to allow charecter ' in the search
		if($arrFilterOrgs['keyword'] != ''){
			$where='(name LIKE "%'.$arrFilterOrgs['keyword'].'%" OR key_peoples.first_name LIKE "%'.$arrFilterOrgs['keyword'].'%" OR key_peoples.middle_name LIKE "%'.$arrFilterOrgs['keyword'].'%" OR key_peoples.last_name LIKE "%'.$arrFilterOrgs['keyword'].'%")';
			$this->db->where($where);
		}
		if(isset($arrFilterOrgs['org_types']) && $arrFilterOrgs['org_types']!="" &&  sizeof($arrFilterOrgs['org_types'])>0){
			$this->db->where_in('organizations.type_id',$arrFilterOrgs['org_types']);
		}
	 	if ($arrFilterOrgs['region'] != null && isset($arrFilterOrgs['region']) && sizeof($arrFilterOrgs['region']) > 0) {
            $this->db->where_in('countries.GlobalRegion', $arrFilterOrgs['region']);
//                      
        }
		if(isset($arrFilterOrgs['country']) && $arrFilterOrgs['country']!="" &&  sizeof($arrFilterOrgs['country'])>0){
			$this->db->where_in('organizations.country_id',$arrFilterOrgs['country']);
		}
		if(isset($arrFilterOrgs['state']) && $arrFilterOrgs['state']!="" &&  sizeof($arrFilterOrgs['state'])>0){
			$this->db->where_in('organizations.state_id',$arrFilterOrgs['state']);
		}
		if(isset($arrFilterOrgs['city']) && $arrFilterOrgs['city']!="" &&  sizeof($arrFilterOrgs['city'])>0){
			$this->db->where_in('organizations.city_id',$arrFilterOrgs['city']);
		}
		if(isset($arrFilterOrgs['profile_type']) && $arrFilterOrgs['profile_type']!="" &&  sizeof($arrFilterOrgs['profile_type'])>0){
			$this->db->where_in('organizations.profile_type',$arrFilterOrgs['profile_type']);
		}
		
		if(isset($arrFilterOrgs['resOrgType'])){
			if($arrFilterOrgs['resOrgType']=="PARENT"){
				$this->db->where('organizations.parent_id',0);
			}
			if($arrFilterOrgs['resOrgType']=="CHILD"){
				$this->db->where('organizations.parent_id >',0,false);
				/* $this->db->where('organizations.parent_id !=',0,false);
				$this->db->or_where('organizations.parent_id is null','',false); */
			}
			if($arrFilterOrgs['resOrgType']=="OTHER"){
				 $this->db->or_where('organizations.parent_id is null','',false); 
			}
			//if($arrFilterOrgs['resOrgType']=="ALL" || $arrFilterOrgs['resOrgType']=="BOTH"){
			//	$this->db->where('organizations.parent_id >=',0,false);
			//}
		}
		//$this->db->like('name',$orgName);
		//$this->db->or_like('key_peoples.first_name',$orgName);
		//$this->db->or_like('key_peoples.middle_name',$orgName);
		//$this->db->or_like('key_peoples.last_name',$orgName);
		if($doCount){
// 			$this->db->where('organizations.status',COMPLETED);
			//$this->db->where('organizations.status_otsuka',"ACTV");
			if(isset($arrFilterOrgs['viewType']) && sizeof($arrFilterOrgs['viewType'])>0){
				$this->db->where_in('organizations.id',$arrFilterOrgs['viewType']);
			}
			$arrOrgDetailsResult	=	$this->db->get('organizations');
			foreach($arrOrgDetailsResult->result_array() as $row){
				$arrOrganizations[]=$row;
			}	
			return sizeof($arrOrganizations);
		}
		else{
			if($doGroupBy){
				if($groupByCategory=='region'){
					$this->db->select('COUNT(DISTINCT organizations.id) as count');
					$this->db->group_by('GlobalRegion');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='country'){
					$this->db->select('COUNT(DISTINCT organizations.id) as count');
					$this->db->group_by('country_id');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='state'){
					$this->db->select('COUNT(DISTINCT organizations.id) as count');
					$this->db->group_by('state_id');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='city'){
					$this->db->select('COUNT(DISTINCT organizations.id) as count');
					$this->db->group_by('city_id');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='type'){
						$this->db->select('COUNT(DISTINCT organizations.id) as count');
						$this->db->group_by('organization_types.id');
						//$this->db->where('specialties.specialty IS NOT NULL');
				}				
				$this->db->order_by('count','desc');
			}
			else 
			$this->db->limit($limit, $startFrom);
			//$this->db->where('organizations.status',COMPLETED);
			//$this->db->where('organizations.status_otsuka',"ACTV");
			if(isset($arrFilterOrgs['viewType']) && sizeof($arrFilterOrgs['viewType'])>0){
				$this->db->where_in('organizations.id',$arrFilterOrgs['viewType']);
			}
			$this->db->order_by('organizations.name','asc');
			$arrOrgDetailsResult	=	$this->db->get('organizations');
//echo $this->db->last_query();
//exit;
			foreach($arrOrgDetailsResult->result_array() as $row){
				$arrOrganizations[]=$row;
			}
			return $arrOrganizations;
		}
	}	
	
	/**
	 *	Filter  MAtched Events Data 
	 * 
	 * @return $arrEventsDetails/false
	 */
	function getFilterMatchOrganizations($orgName,$arrFilterOrganizations,$limit,$startFrom,$doCount,$doGroupBy=false,$groupByCategory=null,$arrQueryOptions=array()){
		$arrEvents	=	array();
		$arrOrganizations	=	array();
		//$this->db->distinct();
		$this->db->select('organizations.name,organizations.id,organizations.parent_id,countries.country,organization_types.type,organizations.company_logo,organizations.headquarters,organizations.phone,organizations.founded,regions.region as state,cities.City as city,organizations.state_id,organizations.city_id,organizations.status,organizations.profile_type,organizations.website,organizations.created_by, countries.GlobalRegion');
		
		$this->db->join('countries','countries.countryId = organizations.country_id', 'left');
		$this->db->join('regions','regions.regionID = organizations.state_id', 'left');
		$this->db->join('organization_types','organization_types.id = organizations.type_id','left');
                $this->db->join('cities','cities.cityId = organizations.city_id', 'left');
		//$this->db->join('key_peoples','key_peoples.org_id = organizations.id','left');
		
		//$where="(name LIKE '%".$orgName."%' OR key_peoples.first_name LIKE '%".$orgName."%' OR key_peoples.middle_name LIKE '%".$orgName."%' OR key_peoples.last_name LIKE '%".$orgName."%')";
		//in order to allow charecter ' in the search
		//$where='(name LIKE "%'.$orgName.'%" OR key_peoples.first_name LIKE "%'.$orgName.'%" OR key_peoples.middle_name LIKE "%'.$orgName.'%" OR key_peoples.last_name LIKE "%'.$orgName.'%")';
$where='(name LIKE "%'.$orgName.'%")';
		$this->db->where($where);
		
		if(isset($arrFilterOrganizations['orgIds']) && $arrFilterOrganizations['orgIds']!="" &&  sizeof($arrFilterOrganizations['orgIds'])>0){
			$this->db->where_in('organizations.id', $arrFilterOrganizations['orgIds']);
		}
		
		if(isset($arrFilterOrganizations['type']) && $arrFilterOrganizations['type']!="" &&  sizeof($arrFilterOrganizations['type'])>0  && !($doGroupBy==true && $groupByCategory=="type")){
			$this->db->where_in('organization_types.id', $arrFilterOrganizations['type']);
		}
		if (isset($arrFilterOrganizations['global_region']) && $arrFilterOrganizations['global_region']!="" && sizeof($arrFilterOrganizations['global_region'])>0 && !($doGroupBy==true && $groupByCategory=="region")) {
			$this->db->where_in('countries.GlobalRegion', $arrFilterOrganizations['global_region']);
		}
		if(isset($arrFilterOrganizations['country']) && $arrFilterOrganizations['country']!="" && sizeof($arrFilterOrganizations['country'])>0 && !($doGroupBy==true && $groupByCategory=="country")){
			$this->db->where_in('countries.countryId', $arrFilterOrganizations['country']);
		}
		if(isset($arrFilterOrganizations['state']) && $arrFilterOrganizations['state']!="" && sizeof($arrFilterOrganizations['state'])>0 && !($doGroupBy==true && $groupByCategory=="state")){
			$this->db->where_in('regions.regionID', $arrFilterOrganizations['state']);
		}
		if(isset($arrFilterOrganizations['city']) && $arrFilterOrganizations['city']!="" && sizeof($arrFilterOrganizations['city'])>0 && !($doGroupBy==true && $groupByCategory=="city")){
			$this->db->where_in('cities.CityId', $arrFilterOrganizations['city']);
		}
		
		/* where condition for org profile type */
		if(isset($arrFilterOrganizations['profileType']) && $arrFilterOrganizations['profileType']!="" && $arrFilterOrganizations['profileType']!=0){
			$this->db->where('organizations.profile_type', $arrFilterOrganizations['profileType']);
		}
		/* ends where condition for org profile type */
		if(isset($arrFilterOrganizations['resOrgType'])){
			if(is_array($arrFilterOrganizations['resOrgType'])){
				if(in_array("PARENT", $arrFilterOrganizations['resOrgType'])){
					$query = "(organizations.parent_id = 0";
					$addedFlag = true;
				}
				if(in_array("CHILD", $arrFilterOrganizations['resOrgType'])){
					if($addedFlag == true)
						$query .= " OR organizations.parent_id > 0";
					else{
						$query = "(organizations.parent_id > 0";
						$addedFlag = true;
					}	
				}
				if(in_array("OTHER", $arrFilterOrganizations['resOrgType'])){
					if($addedFlag == true)
							$query .= " OR organizations.parent_id is null";
						else{
							$query = "(organizations.parent_id is null";
						}	
						
				}
				if($query!=""){
					$query .= ")";
					$this->db->where($query);
				}
			}
			
			if($arrFilterOrganizations['resOrgType']=="PARENT"){
				$this->db->where('organizations.parent_id',0);
			}
			if($arrFilterOrganizations['resOrgType']=="CHILD"){
				$this->db->where('organizations.parent_id >',0,false);
				/* $this->db->where('organizations.parent_id !=',0,false);
				$this->db->or_where('organizations.parent_id is null','',false); */
			}
			if($arrFilterOrganizations['resOrgType']=="OTHER"){
				 $this->db->where('organizations.parent_id is null','',false);
			}
			//if($arrFilterOrganizations['resOrgType']=="ALL" || $arrFilterOrganizations['resOrgType']=="BOTH"){
			//	$this->db->where('organizations.parent_id >=',0,false);
			//}
		}
		//$this->db->where('organizations.status',COMPLETED);
		//$this->db->where('organizations.status_otsuka',"ACTV");
		if($doCount){
			if(isset($arrFilterOrganizations['viewType']) && sizeof($arrFilterOrganizations['viewType'])>0){
				$this->db->where_in('organizations.id', $arrFilterOrganizations['viewType']);
			}
			$arrOrgDetailsResult	=	$this->db->get('organizations');
			foreach($arrOrgDetailsResult->result_array() as $row){
				$arrOrganizations[]=$row;
			}	
			return sizeof($arrOrganizations);
		}
		else{
			if($doGroupBy){		
				if($groupByCategory=='region'){
					$this->db->select('COUNT(DISTINCT organizations.id) as count');
					$this->db->group_by('GlobalRegion');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='country'){
					$this->db->select('organizations.country_id, COUNT(DISTINCT organizations.id) as count');
					$this->db->group_by('country_id');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='state'){
					$this->db->select('COUNT(DISTINCT organizations.id) as count');
					$this->db->group_by('state_id');
				}
				if($groupByCategory=='city'){
					$this->db->select('COUNT(DISTINCT organizations.id) as count');
					$this->db->group_by('city_id');
				}
				if($groupByCategory=='type'){
					$this->db->select('organizations.type_id as org_type_id, COUNT(DISTINCT organizations.id) as count');
					$this->db->group_by('organization_types.id');
					//$this->db->where('specialties.specialty IS NOT NULL');
				}				
				$this->db->order_by('count','desc');
			}
			else{
				if($limit !=0 )
				$this->db->limit($limit, $startFrom);
			}
			if(sizeof($arrQueryOptions)>0){
				switch($arrQueryOptions['sort_by']){
					case 'name': $this->db->order_by('organizations.name',$arrQueryOptions['sort_order']);
								break;
					case 'type':$this->db->order_by('organization_types.type',$arrQueryOptions['sort_order']);
							break;
					case 'country':$this->db->order_by('countries.country',$arrQueryOptions['sort_order']);
							break;
					case 'state':$this->db->order_by('regions.region',$arrQueryOptions['sort_order']);
							break;
					case 'city':$this->db->order_by('cities.City',$arrQueryOptions['sort_order']);
							break;
				}
			}else{
				$this->db->order_by('organizations.name','asc');
			}
			if(isset($arrFilterOrganizations['viewType']) && sizeof($arrFilterOrganizations['viewType'])>0){
				$this->db->where_in('organizations.id', $arrFilterOrganizations['viewType']);
			}
			$arrOrgDetailsResult	=	$this->db->get('organizations');
// 			echo $this->db->last_query();
			foreach($arrOrgDetailsResult->result_array() as $row){
				$arrOrganizations[]=$row;
			}	
			return $arrOrganizations;
		}
	}	

	/* 
	 * Getting "org data" for "Org micro view"
	 * 
	 */
	function getOrgMicroData($orgId){
		$arrOrganizations=array();
		$this->db->select('organizations.*,organization_types.type,countries.country,regions.region');
		$this->db->join('organization_types','organization_types.id = organizations.type_id','left');
		$this->db->join('countries','countries.countryId=organizations.country_id','left');
		$this->db->join('regions','regions.regionId=organizations.state_id','left');
		$this->db->where('organizations.id',$orgId);
		$arrOrgDetailsResult	=	$this->db->get('organizations');
		foreach($arrOrgDetailsResult->result_array() as $row){
				$arrOrganizations[]=$row;
		}	
		return $arrOrganizations;
	}
	
	/**
	 * Counts the number of key people associated for one organization
	 * 
	 * @param unknown_type $orgId
	 * @return unknown_type
	 */
	function kyePeopleCount($orgId){
		$kyePeopleCount = '';
		$this->db->where('org_id',$orgId);
		if($kyePeopleCount=$this->db->count_all_results('key_peoples'))
			return $kyePeopleCount;
		else
			return false;
	}
	
	/**
	 * Counts the number of Additional contact people associated for one organization
	 * 
	 * @param unknown_type $orgId
	 * @return unknown_type
	 */	
	function getOrgContactPplCount($orgId){
		$peopleCount = '';
		$this->db->where('org_id',$orgId);
		if($peopleCount=$this->db->count_all_results('org_additional_contacts'))
			return $peopleCount;
		else
			return false;
	}
	
	/**
	 * Counts the number of Kol associated people for one organization
	 * 
	 * @param $orgId
	 * @return unknown_type
	 */
	function getOrgAssociatedPplCount($orgId){
		$associatedPpl='';
		$this->db->where('org_id',$orgId);
		if($associatedPpl=$this->db->count_all_results('kols'))
			return $associatedPpl;
		else
			return false;
	}
	
	function listOrgAssociatedPpl($orgId){
	    $client_id = $this->session->userdata('client_id');
		$arrKols = array();
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$this->db->select(array('kols.*','kols.profile_type as kol_profile_type','organizations.name','organizations.id as org_id','organizations.created_by as created_by_org','organizations.cin_num','specialties.specialty','countries.Country as country','titles.title as title_name'));
		$this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
		$this->db->join('titles', 'kols.title = titles.id', 'left');
		$this->db->join('specialties', 'specialties.id = kols.specialty', 'left');
		$this->db->join('countries', 'CountryId = kols.country_id', 'left');
		if($client_id !== INTERNAL_CLIENT_ID){
		    $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
		    $this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$this->db->where('org_id',$orgId);
		//$this->db->where('kols.status',COMPLETED);
		$arrKolsDetailsResult	=	$this->db->get('kols');
		foreach($arrKolsDetailsResult->result_array() as $row){
		    if (IS_IPAD_REQUEST)
		        $row['kol_name'] = '<a  href=\''.base_url().IPAD_URL_SEGMENT.'/kols/view/'. $row['id'].'\'>'.$arrSalutations[$row['salutation']].' '.$row['first_name'].' '.$row['middle_name'].' '.$row['last_name'].'</a>';
		    else
		        $row['kol_name'] = '<a target="_new" href=\''.base_url().'kols/view/'. $row['id'].'\'>'.$arrSalutations[$row['salutation']].' '.$row['first_name'].' '.$row['middle_name'].' '.$row['last_name'].'</a>';
				$row['phone'] = $row['primary_phone'];;
				$row['email'] = $row['primary_email'];
				$row['primary_phone'] = '<a href="callto:'.$row['primary_phone'].'" class="linkClickToCall">'.$row['primary_phone'].'</a>';
				$row['primary_email'] = '<a href="mailto:'.$row['primary_email'].'" id="emailHolder">'.$row['primary_email'].'</a>';
				$arrKols[]=$row;
		}	
		return $arrKols;
	}
	
	/**
	 * Returns the no of Organizations in the application
	 * @return unknown_type
	 */
	function countOrganizations(){
		$count = '';
		$this->db->where('status',COMPLETED);
		if($count=$this->db->count_all_results('organizations')){
			return $count;
		}else{
			return false;
		} 
	}
	
	/**
	 * Update the organization record matching the 'cin_num'
	 * @author 	Ramesh B
	 * @since	2.4
	 * @return 
	 * @created 30-05-2011
	 */
	function updateImportedOrganization($organizationDetails){
		if(isset($organizationDetails['id'])){
			$this->db->where('id',$organizationDetails['id']);
			unset($organizationDetails['id']);
		}else{
			$this->db->where('cin_num',$organizationDetails['cin_num']);
		}
		if($this->db->update('organizations',$organizationDetails)){
			//echo $this->db->last_query();
			return true;
		}else
			return false;
	}

/**
	 * Retruns the OrganizationId matching the 'cin_num'
	 * @author 	Ramesh B
	 * @since	2.4
	 * @return 
	 * @created 30-05-2011
	 */
	function getOrgIdBySinNumber($sinNumber){
		$id=0;
		$this->db->where('cin_num',$sinNumber);
		$this->db->select('id');
		$result=$this->db->get('organizations');
		$data=$result->row();
		if($data!=null)
			$id=$data->id;
		return $id;
	}
	
	/**
	 * Retruns the OrganizationId matching given name
	 * @author 	Ramesh B
	 * @since	2.4
	 * @return 
	 * @created 30-05-2011
	 */
	function getOrgIdByOrgName($orgName,$arrReturnDataInArray	= false){
		$id=0;
		//$this->db->where('name',$orgName);
		$this->db->like('name',$orgName);
		$this->db->select('id');
	//	$this->db->where('status',COMPLETED);
		$result=$this->db->get('organizations');
		if($arrReturnDataInArray){
			$arrOrgIds = array();
			foreach($result->result_array() as $arrRow){
				$arrOrgIds[] = $arrRow['id'];
			}
			return $arrOrgIds;
		}else{
			$data=$result->row();
			if($data!=null)
				$id=$data->id;
			return $id;
		}
	}
	
	/**
	 * Delete Organization details of the passed Organization id 
	 * @author 	Ambarish N
	 * @since	2.6
	 * @created July-20-2011
	 * 
	 * @param integer $id
	 * @return
	 */
	function deleteOrganization($id){
		$this->db->where('id',$id);
		$this->db->delete('organizations');
	}
	
	/**
	 * Delete Additional Contact details of the Organization id passed
	 * @author 	Ambarish N
	 * @since	2.6
	 * @created July-20-2011
	 * 
	 * @param integer $orgId
	 * @return
	 */
	function deleteAdditionalContactByOrgId($orgId){
		$this->db->where('org_id',$orgId);
		$this->db->delete('org_additional_contacts');
	}
	
	/**
	 * Delete KeyPeople details of the KOL id passed
	 * @author 	Ambarish N
	 * @since	2.6
	 * @created July-20-2011
	 * 
	 * @param integer $orgId
	 * @return
	 */
	function deleteKeyPeopleByOrgId($orgId){
		$arr =array($orgId);
		
		$this->db->where_in('org_id',$arr);
		$this->db->delete('key_peoples');
	}
	
	/**
	 * Retruns the Organization Name for a given Id
	 * @author 	Ramesh B
	 * @since	2.6
	 * @return 
	 * @created 25-07-2011
	 */
	function getOrgNameByOrgId($orgId){
		$orgName=0;
		$this->db->where('id',$orgId);
		$this->db->select('name');
		$result=$this->db->get('organizations');
		$data=$result->row();
		if($data!=null)
			$orgName=$data->name;
		return $orgName;
	}
	
	function getOrgDataByOrgId($orgId) {
		$orgData = array();
		$this->db->where('id',$orgId);
		$this->db->select('name,country_id,state_id,city_id');
		$result=$this->db->get('organizations');
		if($result->num_rows() > 0){
			foreach ($result->result_array() as $row){
				$orgData = $row;
			}
		}
//		echo $this->db->last_query();
//		pr($orgData);
		return $orgData;
	}
	
	/**
	 * Retruns the Organization Name's matching given string
	 * @author 	Ramesh B
	 * @since	2.6
	 * @return Array
	 * @created 25-07-2011
	 */
	function getMatchingOrgNames($orgName){
		$this->db->select('name');
		$this->db->like('name', $orgName);
		$this->db->where('status',COMPLETED);
		$arrResultSet = $this->db->get('organizations');
		
		$arrOrgNames = array();
		foreach($arrResultSet->result_array() as $arrRow){
			$arrOrgNames[] = $arrRow['name'];
		}
		
		return $arrOrgNames;
	}
	
	/**
	 * Retruns the Organization Types matching given string
	 * @author 	Ramesh B
	 * @since	2.6
	 * @return Array
	 * @created 25-07-2011
	 */
	function getMatchingOrgTypes($orgType){
		$this->db->distinct();
		$this->db->select('organization_types.id,organization_types.type');
		$this->db->join('organization_types','organizations.type_id=organization_types.id','left');
		$this->db->like('organization_types.type', $orgType);
		$arrResultSet = $this->db->get_where('organizations');
		$arrOrgTypes = array();
		foreach($arrResultSet->result_array() as $arrRow){
			$arrOrgTypes[$arrRow['id']] = $arrRow['type'];
		}
		return $arrOrgTypes;
	}
	function getOrgTypeByName($orgType){
	    $this->db->distinct();
	    $this->db->select('organization_types.id,organization_types.type');	    
	    $this->db->where('organization_types.type', $orgType);
	    $arrResultSet = $this->db->get_where('organization_types');
	    return $arrResultSet->row_array();
	}
	
	/**
	 * Retruns the Organization Details 
	 * @author 	Vinayak
	 * @since	3.1
	 * @return Array
	 * @created 5-09-2011
	 */
	function getOrgDetails($id){
		$arrOrgDetails=array();
		$this->db->select('organizations.cin_num,organizations.name,organization_types.type,organizations.company_logo,organizations.website,organizations.headquarters,organizations.background,organizations.mission_vision,organizations.founded,organizations.npi_num,organizations.url,organizations.key_products,organizations.mergers,organizations.clients,organizations.profile_type');
		$this->db->join('organization_types','organizations.type_id=organization_types.id','left');
		$this->db->join('countries','countries.countryId=organizations.country_id','left');
		$this->db->join('regions','regions.regionId=organizations.state_id','left');
		$this->db->join('cities','cities.cityId=organizations.city_id','left');
		$this->db->where('organizations.id',$id);
		$arrResult = $this->db->get('organizations');
		//echo $this->db->last_query();
		foreach($arrResult->result_array() as $row){
			
			$arrOrgDetails[]=$row;
		}
		return $arrOrgDetails;
	}
	
	/**
	 * Retruns the adress of Organization Details 
	 * @author 	Vinayak
	 * @since	3.1
	 * @param  $orgId
	 * @return Array
	 * @created 5-09-2011
	 */
	function getAdreessOfOrg($orgId){
		$arrAdditionalContacts=array();
		$this->db->select('organizations.cin_num,organizations.name,organizations.address,cities.city,organizations.postal_code,regions.region,countries.country,organizations.phone,organizations.fax,organizations.key_reginal_offices');
//		$this->db->join('org_additional_contacts','org_additional_contacts.org_id=organizations.id','left');
		$this->db->join('countries','countries.countryId=organizations.country_id','left');
		$this->db->join('regions','regions.regionId=organizations.state_id','left');
		$this->db->join('cities','cities.cityId=organizations.city_id','left');
		$this->db->where('organizations.id',$orgId);
		$arrResult = $this->db->get('organizations');
		//echo $this->db->last_query();
		foreach($arrResult->result_array() as $row){
			$arrAdditionalContacts[]=$row ;
		}
		return $arrAdditionalContacts;
	}
	
	/**
	 * Retruns thesocial media details of Organization  
	 * @author 	Vinayak
	 * @since	3.1
	 * @param  $orgId
	 * @return Array
	 * @created 5-09-2011
	 */
	function getSocialMediaDetailsOfOrg($orgId){
		$arrOrgsResult = array();
		$this->db->select('organizations.cin_num,organizations.name,organizations.blog,organizations.youtube,organizations.linkedin,organizations.facebook,organizations.twitter');
		$this->db->where('id',$orgId);
		$arrOrgs = $this->db->get('organizations');
		
		foreach($arrOrgs->result_array() as $row){
			$arrOrgsResult[]=$row;
		}
		return $arrOrgsResult;
	}
	
	/**
	 * Retruns the Key people details of Organization  
	 * @author 	Vinayak
	 * @since	3.1
	 * @param  $orgId
	 * @return Array
	 * @created 5-09-2011
	 */
	function getKeyPeopleDetailsOfOrg($orgId){
		$arrKeypeoples = array();
		$this->db->select('organizations.cin_num,organizations.name,key_people_roles.role,key_peoples.salutation,key_peoples.first_name,key_peoples.middle_name,key_peoples.last_name,key_peoples.department,key_peoples.title,key_peoples.email,key_peoples.url,key_peoples.id');
		$this->db->join('organizations','organizations.id=key_peoples.org_id','left');
		$this->db->join('key_people_roles','key_people_roles.id=key_peoples.role_id','left');
		$this->db->where('key_peoples.org_id',$orgId);
		$arrResult = $this->db->get('key_peoples');
		$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		foreach($arrResult->result_array() as $row){
			if($row['salutation']!=0)
				$row['salutation']=$arrSalutations[$row['salutation']];
			$arrKeypeoples[]=$row;
		}
		return $arrKeypeoples;
	}
	
	/**
	 * Retruns the additional contact details of Organization  
	 * @author 	Vinayak
	 * @since	3.1
	 * @param  $orgId
	 * @return Array
	 * @created 5-09-2011
	 */
	function getaddtionalContcat($id){
		$arrContcts = array();
		$this->db->select('phone,related_to');
		$this->db->where('org_id',$id);
		$arr=$this->db->get('org_additional_contacts');
		foreach($arr->result_array() as $row){
			$arrContcts[]=$row['related_to'].':'.$row['phone'];
			
		}
		return $arrContcts;
		
	}
	
	function updateOrgStatus($arrOrgIdsAndStatus){
		$arr = array();
		$arr['status']=$arrOrgIdsAndStatus['status'];
		$this->db->where_in('id',$arrOrgIdsAndStatus['orgIds']);
		if($this->db->update('organizations',$arr)){
			
			return true;
		}else{
			
			return false;
		}
	}
	
	function saveOrganizationWithNoDuplicateCheck($arrOrg){
		if($this->db->insert('organizations',$arrOrg)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	function checkSimilarOrganizations($name){
		$arrResults = array();
		$this->db->select('organizations.id,organizations.name,organizations.status,cities.City as city,regions.Region as state');
		$this->db->join('cities','organizations.city_id = cities.CityId','left');
		$this->db->join('regions','organizations.state_id = regions.RegionID','left');
		$this->db->where('name',$name);
		$this->db->where('profile_type',2);
		$results = $this->db->get('organizations');
		//echo $this->db->last_query();
		if(is_object($results) && $results->num_rows() > 0)
			$arrResults = $results->result_array();
		return $arrResults;
	}
	
	/**
	 * fetch sub organizations 
	 * @author 	Ramesh B
	 * @since	Otsuka 1.0.11
	 * @created 28 Mar 2013
	 * @return array of sub orgs details
	 */
	function listSubOrgs($organizationId = null, $arrFilterOrganizations = null){
		$arrSubOrgsDetails = array();
		//Get the Events of KolId
		if($organizationId != null){
			$this->db->select('organizations.id, organizations.name');
			$this->db->where('affiliates_partnerships.org_id', $organizationId);
			$this->db->join('organizations','organizations.id=affiliates_partnerships.sub_org_id','left');
			$this->db->join('countries','countries.countryId = organizations.country_id', 'left');
			$this->db->join('regions','regions.regionID = organizations.state_id', 'left');
			$this->db->join('organization_types','organization_types.id = organizations.type_id','left');
			$this->db->join('client_users','client_users.id = organizations.created_by', 'left');
			if(isset($arrFilterOrganizations['orgIds']) && $arrFilterOrganizations['orgIds']!="" &&  sizeof($arrFilterOrganizations['orgIds'])>0){
				$this->db->where_in('organizations.id', $arrFilterOrganizations['orgIds']);
			}
			
			if(isset($arrFilterOrganizations['type']) && $arrFilterOrganizations['type']!="" &&  sizeof($arrFilterOrganizations['type'])>0){
				$this->db->where_in('organization_types.type', $arrFilterOrganizations['type']);
			}
			
			if(isset($arrFilterOrganizations['country']) && $arrFilterOrganizations['country']!="" && sizeof($arrFilterOrganizations['country'])>0 ){
				$this->db->where_in('countries.country', $arrFilterOrganizations['country']);
			}
			if(isset($arrFilterOrganizations['state']) && $arrFilterOrganizations['state']!="" && sizeof($arrFilterOrganizations['state'])>0 ){
				$this->db->where_in('organizations.state_id', $arrFilterOrganizations['state']);
			}
			
			if($arrSubOrgsDetailsResult = $this->db->get('affiliates_partnerships')){
				foreach($arrSubOrgsDetailsResult->result_array() as $arrSubOrgs){
						$arrSubOrgsDetails[] = $arrSubOrgs;
				}
				return $arrSubOrgsDetails;
			}
		}else{
			return false;
		}
	}
	
	/**
	 * Retrives all the parent organizations ids and names
	 * @author 	Ramesh B
	 * @since	Otsuka 1.0.11
	 * @created 28 Mar 2013
	 */
	function getAllParentOrganizationsIdAndName($arrFilterOrganizations = null){
		//Updated logic
		$this->db->distinct();
		$this->db->select("organizations.id, organizations.name");
		$this->db->join('countries','countries.countryId = organizations.country_id', 'left');
		//$this->db->join('regions','regions.regionID = organizations.state_id', 'left');
		$this->db->join('organization_types','organization_types.id = organizations.type_id','left');
		
		$this->db->where("organizations.id NOT IN (select distinct sub_org_id from affiliates_partnerships)");		
		
		if(isset($arrFilterOrganizations['orgIds']) && $arrFilterOrganizations['orgIds']!="" &&  sizeof($arrFilterOrganizations['orgIds'])>0){
			$this->db->where_in('organizations.id', $arrFilterOrganizations['orgIds']);
		}
		
		if(isset($arrFilterOrganizations['type']) && $arrFilterOrganizations['type']!="" &&  sizeof($arrFilterOrganizations['type'])>0){
			$this->db->where_in('organization_types.type', $arrFilterOrganizations['type']);
		}
		
		if(isset($arrFilterOrganizations['country']) && $arrFilterOrganizations['country']!="" && sizeof($arrFilterOrganizations['country'])>0 ){
			$this->db->where_in('countries.country', $arrFilterOrganizations['country']);
		}
		if(isset($arrFilterOrganizations['state']) && $arrFilterOrganizations['state']!="" && sizeof($arrFilterOrganizations['state'])>0 ){
			$this->db->where_in('organizations.state_id', $arrFilterOrganizations['state']);
		}
		$this->db->where('organizations.status',COMPLETED);
		
		$arr=$this->db->get('organizations');
		//echo $this->db->last_query();
		foreach($arr->result_array() as $row){
			$arrOrgs[$row['id']]=$row['name'];
		}
		return $arrOrgs;
	}
	
	/**
	 * Retrives all the members of the given organization id
	 * @author 	Ramesh B
	 * @since	Otsuka 1.0.11
	 * @created 28 Mar 2013
	 * @param $orgId
	 */
	function getOrgMembersByOrgId($orgId){
		$arrOrgMembers=array();
		$this->db->select('kols.id,kols.salutation,kols.first_name,kols.middle_name,kols.last_name,kols.suffix');
		$this->db->where('kols.org_id',$orgId);
		$results=$this->db->get('kols');
		foreach($results->result_array() as $row){
			$arrOrgMembers[$row['id']]=$row;
		}
		//echo $this->db->last_query();
		return $arrOrgMembers;
	}
	
	
	function getAllSuborganizationIds($orgIds){
		$subOrgIDs = array();
		foreach($orgIds as $orgId){
			$subOrgIDs[] = $orgId;
			$arrSubOrganizations=$this->listSubOrgs($orgId);
			foreach($arrSubOrganizations as $org){
				$subOrgIDs[] = $org['id'];
				if($org['id'] == $orgId)
					continue;
				$arrIds = $this->getSuborganizationIds($org['id']);
				if(sizeof($arrIds) > 0)
					$subOrgIDs = array_merge($subOrgIDs, $arrIds);
			}
		}
		return $subOrgIDs;
	}
	
	function getSuborganizationIds($orgId){
		$subOrgIDs = array();
		$arrSubOrganizations=$this->listSubOrgs($orgId);
		foreach($arrSubOrganizations as $org){
			$subOrgIDs[] = $org['id'];
			if($org['id'] == $orgId)
				continue;
			//$arrIds = $this->getSuborganizationIds($org['id']);
			if(sizeof($arrIds) > 0)
				$subOrgIDs = array_merge($subOrgIDs, $arrIds);
		}
		return $subOrgIDs;
	}
	
	/**
	 * Retruns orgId if name is present else save and return last insert id
	 * @author 	Vinayak
	 * @since	1.6
	 * @param  $orgName
	 * @return orgId
	 * @created 20-3-2013
	 */
	function getOrgId($orgdetails){
		$this->db->select('id');
		$this->db->where('name',$orgdetails['name']);
		$arrResultSet = $this->db->get('organizations');
		//echo $this->db->last_query();
		if($arrResultSet->num_rows()!=0){
			$orgdetails['id']	= $arrResultSet->row()->id;
			$this->updateOrganization($orgdetails);
			return $arrResultSet->row()->id;
		}else{
			
			$this->db->insert('organizations',$orgdetails);
			$updateCinNum['cin_num'] = $this->db->insert_id();
			$updateCinNum['id'] = $this->db->insert_id();
			$this->updateOrganization($updateCinNum);
			return $updateCinNum['id'];
		}
	}
	
	/**
	 * Save AffiliatesPartnerships
	 * @author 	Vinayak
	 * @since	1.6
	 * @param  $subOrgDataDetails
	 * @return 
	 * @created 20-3-2013
	 */
	function saveAffiliatesPartnerships($subOrgDataDetails){
		
		if($this->db->insert('affiliates_partnerships',$subOrgDataDetails)){
			return true;
		}else{
			$this->db->where('org_id',$subOrgDataDetails['org_id']);
			$this->db->where('sub_org_id',$subOrgDataDetails['sub_org_id']);
			$this->db->where('address',$subOrgDataDetails['address']);
		
			if($this->db->update('affiliates_partnerships',$subOrgDataDetails)){
				return true;
			}else{
				return false;
			}
		}
		
	}
	
	function orgStatsFacats($factDetails){
		if($this->db->insert('org_stats_facts',$factDetails)){
			return true;
		}else{
			$this->db->where('org_id',$factDetails['org_id']);
			if($this->db->update('org_stats_facts',$factDetails)){
				return true;
			}else{
				return false;
			}
		}
	}
	
	/**
	 * Save OrgMedicalService
	 * @author 	Vinayak
	 * @since	1.6
	 * @param  $subOrgDataDetails
	 * @return 
	 * @created 20-3-2013
	 */
	function saveOrgMedicalService($name){
		$this->db->where('name',$name);
		$arrResultSet = $this->db->get('medical_services');
		
		if($arrResultSet->num_rows()!=0){
			return $arrResultSet->row()->id;
		}else{
			$medicalService = array();
			$medicalService['name']=$name;
			$this->db->insert('medical_services',$medicalService);
			return $this->db->insert_id();
		}
	}
	
	function saveOrgMediacalAssociation($details){
		$this->db->insert('org_medical_services',$details);
	}
	
	function saveOrgOtherLocationDetails($orgLocationDetails){
		$this->db->insert('org_other_locations',$orgLocationDetails);
	}
	
	function saveAffType($type){
		
		$this->db->where('type',$type);
		$arrResultSet = $this->db->get('affiliates_partners_type');
		
		if($arrResultSet->num_rows()!=0){
			return $arrResultSet->row()->id;
		}else{
			$types = array();
			$types['type']=$type;
			$this->db->insert('affiliates_partners_type',$types);
			return $this->db->insert_id();
		}
	}
	
	function getOrgMediaclServiceDetail($orgId){
		$arrMedialServices = array(); 
		$this->db->select('medical_services.name as medical_service, org_medical_services.*,organizations.cin_num,organizations.name');
		$this->db->join('medical_services','medical_services.id=org_medical_services.medical_service_id','left');
		$this->db->join('organizations','organizations.id=org_medical_services.org_id','left');
		$this->db->where('org_medical_services.org_id',$orgId);
		$arrResultSet = $this->db->get('org_medical_services');
		foreach($arrResultSet->result_array() as $row){

			$arrMedialServices[] = $row;
		}
		return $arrMedialServices;
	}
	
	function getOrgOtherLocations($orgId){
		$arrOrgOtherLocations = array(); 
		$this->db->select('organizations.cin_num,organizations.name,org_other_locations.id,org_other_locations.address,
						  cities.city,org_other_locations.postal_code,regions.region,
						  countries.country,org_other_locations.phone,org_other_locations.url');
		$this->db->join('organizations','organizations.id=org_other_locations.org_id','left');
		$this->db->join('countries','org_other_locations.country_id=countries.countryId','left');
		$this->db->join('regions','regions.regionId=org_other_locations.state_id','left');
		$this->db->join('cities','cities.cityId = org_other_locations.city_id','left');
		$this->db->where('org_other_locations.org_id',$orgId);
		$arrResultSet = $this->db->get('org_other_locations');
		foreach($arrResultSet->result_array() as $row){
			$arrOrgOtherLocations[] = $row;
		}
		return $arrOrgOtherLocations;
	}
	
	function getOrgStatsFacts($orgId){
		$arrStatFacts = array(); 
		$this->db->select('org_stats_facts.*, organizations.cin_num, organizations.name');
		$this->db->join('organizations','organizations.id=org_stats_facts.org_id','left');
		$this->db->where('org_stats_facts.org_id',$orgId);
		$arrResultSet = $this->db->get('org_stats_facts');
		foreach($arrResultSet->result_array() as $row){
			$arrStatFacts[] = $row;
		}
		return $arrStatFacts;
	}
	
	function getSubOrg($orgId){
		$arrSuOrgs = array(); 
		$this->db->select('client_users.client_id,o.created_by,organizations.cin_num,organizations.name as name, o.name as sub_org,affiliates_partnerships.id,affiliates_partnerships.data_type_indicator,affiliates_partnerships.org_id,affiliates_partnerships.sub_org_id,o.created_by,o.postal_code,o.address,countries.country,cities.city,regions.region,o.status,affiliates_partnerships.phone,affiliates_partnerships.npi_num,affiliates_partnerships.url,CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name',false);
		$this->db->join('organizations','organizations.id=affiliates_partnerships.org_id','left');
		$this->db->join('organizations as o','o.id = affiliates_partnerships.sub_org_id','left');
		$this->db->join('countries','o.country_id=countries.countryId','left');
		$this->db->join('regions','regions.regionId=o.state_id','left');
		$this->db->join('cities','cities.cityId = o.city_id','left');
		$this->db->join('client_users','client_users.id = o.created_by','left');
		$this->db->where('affiliates_partnerships.org_id',$orgId);
		
		$arrResultSet = $this->db->get('affiliates_partnerships');

		foreach($arrResultSet->result_array() as $row){
			$row['id'] = $row['sub_org_id'];
			$row['eAllowed'] = $this->common_helpers->isActionAllowed('org_details','edit',$row);
			$arrSuOrgs[] = $row;
		} 
		
		$this->db->select('client_users.client_id,o.created_by,organizations.cin_num,organizations.name as name, o.name as sub_org,affiliates_partnerships.id,affiliates_partnerships.data_type_indicator,affiliates_partnerships.org_id,affiliates_partnerships.sub_org_id,o.created_by,o.postal_code,o.address,countries.country,cities.city,regions.region,o.status,affiliates_partnerships.phone,affiliates_partnerships.npi_num,affiliates_partnerships.url,CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name',false);
		$this->db->join('organizations','organizations.id=affiliates_partnerships.sub_org_id','left');
		$this->db->join('organizations as o','o.id = affiliates_partnerships.org_id','left');
		$this->db->join('countries','o.country_id=countries.countryId','left');
		$this->db->join('regions','regions.regionId=o.state_id','left');
		$this->db->join('cities','cities.cityId = o.city_id','left');
		$this->db->join('client_users','client_users.id = o.created_by','left');
		$this->db->where('affiliates_partnerships.sub_org_id',$orgId);
		$arrResultSet1 = $this->db->get('affiliates_partnerships');
		foreach($arrResultSet1->result_array() as $row1){
			$row1['id'] = $row1['org_id'];
			$row1['eAllowed'] = $this->common_helpers->isActionAllowed('org_details','edit',$row1);
			$arrSuOrgs[] = $row1;
		}
		return $arrSuOrgs;
		
	}
	

	function convertDateToMM_DD_YYYY($inputDate, $delimiter='/'){

		$ddDate	=	substr($inputDate,8,2);
		$mmDate	=	substr($inputDate,5,2);
		$yyDate	=	substr($inputDate,0,4);
		return	($mmDate.$delimiter.$ddDate.$delimiter.$yyDate);
	}
	
	function getStatsAndFacts($orgId){
		$arrStatsFacts = array();
		$this->db->where('org_id',$orgId);
		$arrResultSet = $this->db->get('org_stats_facts');
		foreach($arrResultSet->result_array() as $row){
			$arrStatsFacts[]=$row;
		}
		return $arrStatsFacts;
	}
	
	function getMedicalServiceDetails($orgId){
		$arrMedicalServices = array();
		$this->db->select('org_medical_services.id,medical_services.name');
		$this->db->join('medical_services','medical_services.id=org_medical_services.medical_service_id','left');
		$this->db->where('org_medical_services.org_id',$orgId);
		$arrResultSet = $this->db->get('org_medical_services');
		foreach($arrResultSet->result_array() as $row){
			$arrMedicalServices[]=$row;
		}
		return $arrMedicalServices;
	}
	
	function getKeyPeopleDetail($kolId){
		$arrKolDetail = array();
		$this->db->select('key_peoples.id,first_name,middle_name,last_name,salutation,key_peoples.email,organizations.name as org_name,title,department,key_peoples.org_id');
		$this->db->join('organizations','organizations.id=key_peoples.org_id','left');
		$this->db->where('key_peoples.id',$kolId);
		$arrResultSet = $this->db->get('key_peoples');
		foreach($arrResultSet->result_array() as $row){
			$arrKolDetail = $row;
		}
		return  $arrKolDetail;
	}
	function getAuthorDetail($kolId){
		$arrKolDetail = array();
		$this->db->select('pubmed_authors.id,last_name,fore_name,initials as middle_name');
		$this->db->where('pubmed_authors.id',$kolId);
		$arrResultSet = $this->db->get('pubmed_authors');
		foreach($arrResultSet->result_array() as $row){
			$arrKolDetail = $row;
		}
		return  $arrKolDetail;
	}
	
	function getInvestigatorDetail($id){
		$arrDetail = array();
		$this->db->select('cts_investigators.id,cts_investigators.last_name,affiliation');
		$this->db->where('cts_investigators.id',$id);
		$arrResultSet = $this->db->get('cts_investigators');
		foreach($arrResultSet->result_array() as $row){
			$arrDetail = $row;
		}
		return  $arrDetail;
	}
	
	function getFistAuthors($orgId){
		$arrDetails = array();
		$this->db->select('pubmed_authors.*,count(pubmed_authors.id) as num_pubs,org_publications.pub_id,publications.affiliation');
		$this->db->join('pubmed_authors','publications_authors.alias_id=pubmed_authors.id','left');
		$this->db->join('org_publications','org_publications.pub_id=publications_authors.pub_id','left');
		$this->db->join('publications','publications_authors.pub_id=publications.id','left');
		$this->db->where('publications_authors.position',1);
		$this->db->where('org_publications.org_id',$orgId);
		$this->db->where('org_publications.is_verified',1);
		$this->db->group_by('last_name,fore_name,initials');
		$arrResultSet = $this->db->get('publications_authors');
		//echo $this->db->last_query();
		foreach($arrResultSet->result_array() as $row){
			$arrDetails[] = $row;
		}
	//	pr($arrDetails);
		return $arrDetails;
	}
	
	function getKeyInvestigators($orgId){
		$arrDetails = array();
		$this->db->select('cts_investigators.id,cts_investigators.last_name,count(org_clinical_trials.cts_id) as trial_count,cts_investigators.affiliation');
		$this->db->join('ct_investigators','ct_investigators.alias_id=cts_investigators.id','left');
		$this->db->join('org_clinical_trials','org_clinical_trials.cts_id=ct_investigators.cts_id','left');
		
		$this->db->where('org_clinical_trials.org_id',$orgId);
		$this->db->where('is_verified',1);
		$this->db->where('cts_investigators.last_name !=','');
		$this->db->where('org_clinical_trials.org_id IS NOT NULL');
		
		$this->db->group_by('cts_investigators.last_name');
		$arrResultSet = $this->db->get('cts_investigators');
		foreach($arrResultSet->result_array() as $row){
			$arrDetails[] = $row;
		}
		return $arrDetails;
	}
	
	function getKeyPeopleById($id){
		$rowData = array();
		$this->db->select("key_peoples.org_id,key_peoples.salutation,key_peoples.salutation,key_peoples.first_name,key_peoples.middle_name,key_peoples.last_name,key_peoples.title,key_peoples.email,organizations.name");
		$this->db->where("key_peoples.id",$id);
		$this->db->join('organizations','key_peoples.org_id = organizations.id','left');
		$results = $this->db->get("key_peoples");
		if(is_object($results) && $results->num_rows() > 0)
			$rowData = $results->row_array();
			
		return $rowData;
	}
	
	function getFirstAuthorById($id){
		$rowData = array();
		$this->db->where("id",$id);
		$results = $this->db->get("pubmed_authors");
		if(is_object($results) && $results->num_rows() > 0)
			$rowData = $results->row_array();
			
		return $rowData;
	}
	
	function getKeyInvestigatorById($id){
		$rowData = array();
		$this->db->where("id",$id);
		$results = $this->db->get("cts_investigators");
		if(is_object($results) && $results->num_rows() > 0)
			$rowData = $results->row_array();
			
		return $rowData;
	}
	
	function getFirstAuthorAffiliationData($orgId, $authorId){
		$arrCoAuthsIds = array($authorId);
		$matchingAuths=$this->getMatchingCoAuthorIds($arrCoAuthsIds,$orgId);
		
		$affiliation = "";
		$affWithEmail = '';
		$this->db->select('publications.affiliation,pubmed_authors.*');
		$this->db->join('publications_authors', 'pubmed_authors.id = publications_authors.author_id','left');
		$this->db->join('publications', 'publications_authors.pub_id = publications.id','left');
		$this->db->join('org_publications', 'publications.id = org_publications.pub_id','left');
		$this->db->where_in('pubmed_authors.id',$matchingAuths);
		$this->db->where('publications_authors.position',1);
		$this->db->where('publications.affiliation !=','NA');
		$results	=	$this->db->get('pubmed_authors');
		foreach($results->result_array() as $row){
			$affiliation=$row;
			$pos = strpos($row['affiliation'], "@");
			if ($pos === false) {
			    
			} else {
			    $affiliation = $row;
			}
		}
		
		if($affWithEmail != '')
			return $affWithEmail;
		else
			return $affiliation;
	}
	
	function getMatchingCoAuthorIds($arrCoAuthIds,$orgId){
		//Get the name details of all the co authoer id in the '$arrCoAuthIds', and get the all the co-authors having the same name details for given given orgId
		$arrCoAuthos=array();
		$coAuthIds=implode(",",$arrCoAuthIds);
		
		$this->db->select('pubmed_authors.id');
		$this->db->join('publications_authors','pubmed_authors.id=publications_authors.author_id','left');
		$this->db->join('publications','publications_authors.pub_id=publications.id','left');
		$this->db->join('org_publications','publications.id=org_publications.pub_id','left');
		$this->db->where('org_publications.org_id',$orgId);
		$this->db->where('org_publications.is_deleted',0);
		$this->db->where('org_publications.is_verified',1);
		$where="(pubmed_authors.last_name,pubmed_authors.fore_name,pubmed_authors.initials) IN (SELECT last_name,fore_name,initials FROM pubmed_authors WHERE id IN ($coAuthIds))";
		$this->db->where($where);
		$this->db->order_by('pubmed_authors.last_name,pubmed_authors.fore_name');
		
		$arrCOAuth = $this->db->get('pubmed_authors');
		foreach($arrCOAuth->result_array() as $row){
			   	$arrCoAuthos[]=$row['id'];
		}	
		//echo $this->db->last_query();
		return $arrCoAuthos;
	}
	
	function deleteMedicalService($orgId){
		$this->db->where('org_id',$orgId);
		$this->db->delete('org_medical_services');
	}
	
	function getOrgDetailForPdf($orgId){
		$arrDetail =array();
		$this->db->select('organization_types.type,organization_types.id as type_id,o.name,o.address,o.phone,o.fax,o.headquarters,o.website,o.facebook,o.youtube,o.twitter,o.linkedin,o.company_logo,o.npi_num,
							org_stats_facts .*,o.founded,countries.country,regions.region,cities.city,o.background,o.mission_vision,o.key_products, o.mergers, o.clients,o.key_reginal_offices,group_concat(" ",medical_services.name) as medical_service',false);
		$this->db->join('organization_types','o.type_id=organization_types.id','left');
		$this->db->join('countries','o.country_id=countries.countryId','left');
		$this->db->join('regions','o.state_id=regions.regionId','left');
		$this->db->join('cities','o.city_id=cities.cityId','left');
		$this->db->join('org_medical_services','org_medical_services.org_id=o.id','left');
		$this->db->join('medical_services','medical_services.id=org_medical_services.medical_service_id','left');
		$this->db->join('org_stats_facts','org_stats_facts.org_id = o.id','left');
		$this->db->where('o.id',$orgId);
		$arrResultSet = $this->db->get('organizations as o');
		
		//echo $this->db->last_query();
		foreach($arrResultSet->result_array() as $row){
			$arrDetail = $row;
		}
		return $arrDetail;
	}
	
	function saveAffiliatesPartnershipsManaul($subOrgDataDetails){
	    $dataType = 'User Added';
	    $client_id =$this->session->userdata('client_id');
	    if($client_id == INTERNAL_CLIENT_ID){
	        $dataType = 'Aissel Analyst';
	    }
	    $subOrgDataDetails['data_type_indicator'] = $dataType;
		if($this->db->insert('affiliates_partnerships',$subOrgDataDetails)){
			return $this->db->insert_id();
		}else{
			return false;
		}
		
	}
	
	function getKeyPeopleData($id){
		$this->db->where('id',$id);
		$arresultset = $this->db->get('key_peoples');
		$arrKeyPeoples = $arresultset->result_array();
		return $arrKeyPeoples[0];
	}
	
	function getOrgsMatchingGivenIds($arrIds){
		$arrOrganizations	=	array();
		$this->db->select('organizations.name,organizations.id,countries.country,organization_types.type,regions.region as state,organizations.status,cities.city as city');
		$this->db->join('countries','countries.countryId = organizations.country_id', 'left');
		$this->db->join('regions','regions.regionID = organizations.state_id', 'left');
		$this->db->join('cities','cities.cityId = organizations.city_id', 'left');
		$this->db->join('organization_types','organization_types.id = organizations.type_id','left');
		$this->db->where_in('organizations.id',$arrIds);
		$this->db->order_by('organizations.name','asc');
		$arrOrgDetailsResult	=	$this->db->get('organizations');
		foreach($arrOrgDetailsResult->result_array() as $row){
			$arrOrganizations[]=$row;
		}
		return $arrOrganizations;
	}
	
 function saveNote($arrDetails) {
    	//pr($arrDetails);exit;
        if ($this->db->insert('org_notes', $arrDetails)) {
        	//pr($this->db->last_query());
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    function getNotes($kolId) {
        $rows = array();
        $this->db->select('org_notes.*,client_users.first_name,client_users.last_name,modified.first_name as modified_by_first_name, modified.last_name as modified_by_last_name');
        $this->db->where('org_id', $kolId);
        $this->db->join('client_users', 'org_notes.created_by = client_users.id', 'left');
        $this->db->join('client_users as modified', 'org_notes.modified_by = modified.id', 'left');
        $this->db->order_by('created_on', 'desc');
        $res = $this->db->get('org_notes');
        //pr($this->db->last_query());exit;
        if ($res->num_rows() > 0)
            $rows = $res->result_array();

        return $rows;
    }

    function deleteNote($noteId) {
        $get = $this->db->get_where("org_notes",array("id"=>$noteId))->row();
        $filename = $get->document;
        $this->db->where('id', $noteId);
        if ($this->db->delete("org_notes")) {
            if($filename!='')
                unlink($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/kol_note_documents/".$filename);
            return true;
        } else {
            return false;
        }
    }
    function deleteNoteAttachment($noteId){
        $get = $this->db->get_where("org_notes",array("id"=>$noteId))->row();
        $filename = $get->document;
        if($filename!=''){
            unlink($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/kol_note_documents/".$filename); 
            $this->db->update("org_notes",array("document"=>'',"document_name"=>'',"orginal_doc_name"=>''),array("id"=>$noteId));
            return true;
        } else {
            return false;
        }
    }
    function updateNote($arrData) {
    	//pr($arrData);exit;
        $this->db->where('id', $arrData['id']);
        //pr($this->db->last_query())exit;
        if ($this->db->update("org_notes", $arrData)) {
            return true;
        } else {
            return false;
        }
    }

    function getNotesById($noteId) {
        $this->db->select("org_notes.id,org_notes.org_id,org_notes.note,org_notes.created_by,org_notes.client_id,org_notes.created_on,org_notes.document,org_notes.document_name,org_notes.modified_by,org_notes.modified_by,org_notes.modified_on,CONCAT(client_users.first_name,' ',client_users.last_name) as name", false);
        $this->db->where('org_notes.id', $noteId);
        $this->db->join("client_users", "client_users.id = org_notes.created_by", "left");
        $result = $this->db->get("org_notes");
        $arr = array();
        foreach ($result->result_array() as $row) {
            $arr[] = $row;
        }
        return $arr;
    }
	
	function saveOrgPayerFacts($data){
		if($this->db->insert('org_payer_facts',$data)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	function deleteOrgPayerFacts($id){
		$this->db->where('org_id',$id);
		$this->db->delete('org_payer_facts');
	}
	
	function saveOrgFormularies($data){
		if($this->db->insert('org_formularies',$data)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	function deleteOrgFormulary($id){
		$this->db->where('org_id',$id);
		$this->db->delete('org_formularies');
	}
	
	function saveDeaseManagement($data){
		if($this->db->insert('org_disease_managements',$data)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	function deleteDiseaseManagement($id){
		$this->db->where('org_id',$id);
		$this->db->delete('org_disease_managements');
	}
	function saveOrgEnrollement($data){
		if($this->db->insert('org_enrollments',$data)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	function deleteOrgEnrollement($id){
		$this->db->where('org_id',$id);
		$this->db->delete('org_enrollments');
	}
	
	function getClaimsaAndProcess(){
		$arr = array();
		$arrRsultSet = $this->db->get('org_claims_process');
		foreach($arrRsultSet->result_array() as $row){
			$arr[$row['claim']] = $row;
			
		}
	
		return $arr;
	}
	
	function saveClaimData($arrData){
		$this->db->insert('org_claims_process_mapped_data',$arrData);
	}
	
	function getFormularyDropDownValues(){
		$arr = array();
		$arrRsultSet = $this->db->get('org_formulary_dropdown_values');
		foreach($arrRsultSet->result_array() as $row){
			$arr[$row['drug_pa']] = $row;
			
		}
	
		return $arr;
	}
	
	function saveFormularyDropdownData($arrData){
		$this->db->insert('org_formluary_mapped_data',$arrData);
	}
	
	function getDiseaseDropDownValues(){
		$arr = array();
		$arrRsultSet = $this->db->get('org_disease_drop_down_values');
		foreach($arrRsultSet->result_array() as $row){
			$arr[$row['value']] = $row;
			
		}
	
		return $arr;
	}
	
	function getDiseaseDropDownValuesForParticulars($typeId) {
		$arr = array();
		$this->db->where('type',$typeId);
		$arrRsultSet = $this->db->get('org_disease_drop_down_values');
		foreach($arrRsultSet->result_array() as $row){
			$arr[$row['value']] = $row;
			
		}
	
		return $arr;
	}
	
	function saveDiseaseDropdownData($arrData){
		$this->db->insert('org_disease_mapped_data',$arrData);
	}
	
	function getOrgPayerStatsFacts($orgId){
		$arrFacts = array();
		$this->db->select("*,org_claims_process_mapped_data.cliam_process_id,
						GROUP_CONCAT(case org_claims_process_mapped_data.type_id when 1 then org_claims_process.claim else null end SEPARATOR ',')
						as claims, GROUP_CONCAT(case org_claims_process_mapped_data.type_id when 2 then org_claims_process.claim else null end SEPARATOR ',') 
							AS processing" 	
						,false);
		$this->db->join('org_claims_process_mapped_data','org_claims_process_mapped_data.fact_id=org_payer_facts.id','left');
		$this->db->join('org_claims_process','org_claims_process_mapped_data.cliam_process_id=org_claims_process.id','left');
		$this->db->where('org_id',$orgId);
		$arrRsultSet = $this->db->get('org_payer_facts');
		//echo $this->db->last_query();
		foreach($arrRsultSet->result_array() as $row){
			$arrFacts[] = $row;
		}
		return $arrFacts;
	}
	
	function getOrgPayerEnrollements($orgId){
		$arrEnrollements = array();
		$this->db->where('org_id',$orgId);
		$arrRsultSet = $this->db->get('org_enrollments');
		//echo $this->db->last_query();
		foreach($arrRsultSet->result_array() as $row){
			$arrEnrollements[] = $row;
		}
		return $arrEnrollements;
	}
	
	function getOrgPayerFormularies($orgId){
		$arrFormularies = array();
		$this->db->where('org_id',$orgId);
		$arrRsultSet = $this->db->get('org_formularies');
		foreach($arrRsultSet->result_array() as $row){
			$arrFormularies[] = $row;
		}
		return $arrFormularies;
	}
	
	function getFormularyDrugValues($id,$type){
		$this->db->select(" group_concat(case org_formluary_mapped_data.type when $type then org_formulary_dropdown_values.drug_pa else null end SEPARATOR ',' ) as drug_tier",false);
		$this->db->join('org_formulary_dropdown_values','org_formluary_mapped_data.drug_pa_id=org_formulary_dropdown_values.id','left');
		$this->db->where('form_id',$id);
		$arrRsultSet = $this->db->get('org_formluary_mapped_data');
			
		return $arrRsultSet->row()->drug_tier;
	}
	
	function getOrgPayerDiseaseManagements($orgId){
		$arrManagements = array();
		$this->db->where('org_id',$orgId);
		$arrRsultSet = $this->db->get('org_disease_managements');
		//echo $this->db->last_query();
		foreach($arrRsultSet->result_array() as $row){
			$arrManagements[] = $row;
		}
		return $arrManagements;
	}
	
	function getPayerDiseaseDropDownValues($id,$type){
		$this->db->select("group_concat(case org_disease_mapped_data.type when $type then org_disease_drop_down_values.value else null end separator ',') as value",false);
		$this->db->join('org_disease_drop_down_values','org_disease_drop_down_values.id=org_disease_mapped_data.value_id','left');
		$this->db->where('disease_id',$id);
		$arrRsultSet = $this->db->get('org_disease_mapped_data');
			
		return $arrRsultSet->row()->value;
	}
	
	function getCollabarationCategories(){
		$arr = array();
		$arrRsultSet = $this->db->get('org_payer_collabaration_categories');
		foreach($arrRsultSet->result_array() as $row){
			$arr[$row['category']] = $row;
			
		}
	
		return $arr;
	}
	
	function getCollabarationRatings(){
		$arr = array();
		$arrRsultSet = $this->db->get('org_collabaration_categories_ratings');
		foreach($arrRsultSet->result_array() as $row){
			$arr[$row['rating']] = $row;
			
		}
	
		return $arr;
	}
	
	function saveCollabarationRatings($ratings){
		$this->db->insert('org_payer_collabaration_mapped_data',$ratings);
	}
	
	function deleteCollabarationRatings($orgId){
		$this->db->where('org_id',$orgId);
		$this->db->delete('org_payer_collabaration_mapped_data');
	}
	
	function getOrgCollabarationCategories(){
		$arrCategories = array();
		$arrResultSet = $this->db->get('org_payer_collabaration_categories');
		foreach($arrResultSet->result_array() as $row){
			$arrCategories[$row['id']] = $row['category'];
		}
		return $arrCategories;
	}
	
	function getOrgCollabarationRatings($orgId){
		$arrCategories = array();
		$this->db->select('category_id,group_concat(" ",rating) as ratings');
		$this->db->join('org_payer_collabaration_mapped_data','org_payer_collabaration_mapped_data.category_id=org_payer_collabaration_categories.id');
		$this->db->join('org_collabaration_categories_ratings','org_collabaration_categories_ratings.id=org_payer_collabaration_mapped_data.rating_id');
		$this->db->where('org_id',$orgId);
		$this->db->group_by('org_payer_collabaration_categories.category');
		$arrResultSet = $this->db->get('org_payer_collabaration_categories');
		foreach($arrResultSet->result_array() as $row){
			$arrCategories[$row['category_id']] =trim($row['ratings']);
		}
		return $arrCategories;
	}
	
	
	function getAllOrgPayersFact($orgId){
		$this->db->select("org_payer_facts.id,org_payer_facts.org_id,org_payer_facts.no_of_hospitals,org_payer_facts.no_of_physicians,org_payer_facts.no_of_affiliated,org_payer_facts.benefit_management,org_payer_facts.specialty_pharmacy,org_payer_facts.ncqa_status,org_payer_facts.start_rating,org_payer_facts.physicians_employed,
							group_concat( case org_claims_process_mapped_data.type_id when 1 then org_claims_process.claim else null end separator ',') as cliam_and_emr,
							group_concat( case org_claims_process_mapped_data.type_id when 2 then org_claims_process.claim else null end separator ',') as data_processing",false);
		$this->db->where("org_payer_facts.org_id",$orgId);
		$this->db->join("org_claims_process_mapped_data","org_claims_process_mapped_data.fact_id = org_payer_facts.id","left");
		$this->db->join("org_claims_process","org_claims_process_mapped_data.cliam_process_id = org_claims_process.id","left");
		$this->db->group_by("org_claims_process_mapped_data.fact_id");
		$arrResultSet = $this->db->get("org_payer_facts");
		foreach($arrResultSet->result_array() as $row){
			$arrOrgPayerFact[] = $row;
		}
		return $arrOrgPayerFact;
	}
	
	function getAllOrgEnroll($orgId){
		$arrOrgEnroll = array();
		$this->db->where('org_id',$orgId);
		$arrResultSet = $this->db->get('org_enrollments');
		foreach($arrResultSet->result_array() as $row){
			$arrOrgEnroll[] = $row;
		}
		return $arrOrgEnroll;
	}
	
	function getAllOrgEnrollData($orgId,$year){
			$arrOrgEnroll = array();
			$this->db->select('id,type,created_by,client_id');
			$this->db->where('org_id',$orgId);
			$arrResult = $this->db->get('org_enrollments');
			foreach($arrResult->result_array() as $row){
				$arrOrgEnrollments[$row['id']] = $row;
			}
				
			foreach ($arrOrgEnrollments as $k=>$v){
				$this->db->where('enroll_id',$v['id']);
				$this->db->where_in('year',$year);
				$arrResultSet = $this->db->get('org_enrollment_years');
				foreach($arrResultSet->result_array() as $row){
					$arrOrgEnrollments[$k][$row['year']] = $row['value'];
					
				}
			}
			return $arrOrgEnrollments;
		}
		
		function getYearData($id){
				$this->db->where('enroll_id',$id);
				$arrResultSet = $this->db->get('org_enrollment_years');
				foreach($arrResultSet->result_array() as $row){
					$arrOrgEnrollments[$row['year']] = $row['value'];
					
				}
			return $arrOrgEnrollments;
		}
	
	function getAllFormulariesData($formulariesArrData) {
		$arrFormularies = array();
		foreach($formulariesArrData as $data){
			$this->db->where("form_id",$data['id']);
			$this->db->select("org_formularies.id,org_formularies.org_id,org_formularies.created_by,org_formularies.client_id,org_formularies.drug_name,org_formluary_mapped_data.drug_pa_id,org_formluary_mapped_data.type,
								group_concat( case org_formluary_mapped_data.type when 1 then org_formulary_dropdown_values.drug_pa else null end separator ',') as drugTier,
								group_concat( case org_formluary_mapped_data.type when 2 then org_formulary_dropdown_values.drug_pa else null end separator ',') as drugCriteria",false);
			$this->db->join("org_formluary_mapped_data","org_formluary_mapped_data.form_id=org_formularies.id","left");
			$this->db->join("org_formulary_dropdown_values","org_formluary_mapped_data.drug_pa_id=org_formulary_dropdown_values.id","left");
		$arrResultSet = $this->db->get("org_formularies");	
			foreach($arrResultSet->result_array() as $row){
				$arrFormularies[] = $row;
			}
		}
		return $arrFormularies;
	}
	
	function getAllOrgDiseaseManagementIds($orgId) {
		$arrOrgDmIds = array();
		$this->db->where('org_id',$orgId);
		$arrResultSet = $this->db->get('org_disease_managements');
		foreach($arrResultSet->result_array() as $row){
			$arrOrgDmIds[] = $row;
		}
		return $arrOrgDmIds;
	}
	function getAllOrgDiseaseManagementData($dmIds) {
		$arrDms = array();
		foreach($dmIds as $data){
			$this->db->where("org_disease_managements.id",$data['id']);
			$this->db->select("org_disease_managements.id,org_disease_managements.created_by,org_disease_managements.client_id,org_disease_managements.disease_name,
								group_concat( case org_disease_mapped_data.type when 1 then org_disease_drop_down_values.value else null end separator ',') as dmPlatform,
								group_concat( case org_disease_mapped_data.type when 2 then org_disease_drop_down_values.value else null end separator ',') as identification,
								group_concat( case org_disease_mapped_data.type when 3 then org_disease_drop_down_values.value else null end separator ',') as intervention,
								group_concat( case org_disease_mapped_data.type when 4 then org_disease_drop_down_values.value else null end separator ',') as measurement",false);
			$this->db->join("org_disease_mapped_data","org_disease_mapped_data.disease_id = org_disease_managements.id","left");
			$this->db->join("org_disease_drop_down_values","org_disease_mapped_data.value_id = org_disease_drop_down_values.id","left");
			$arrResultSet = $this->db->get("org_disease_managements");
			foreach($arrResultSet->result_array() as $row){
				$arrDms[] = $row;
			}
		}
		return $arrDms;
	}
	
	function addEnrollmentDetail($arrEnrollData){
		if($this->db->insert('org_enrollments',$arrEnrollData)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	function addEnrollmentDetails($data,$arrEnroll,$arrEnrollVal) {
		$orgEnroll['org_id']		=	$data['org_id'];
		$orgEnroll['type']			=	$data['type'];
		$orgEnroll['created_by']	=	$data['created_by'];
		$orgEnroll['created_on']	=	$data['created_on'];
		$orgEnroll['client_id']		=	$data['client_id'];
		if($this->db->insert('org_enrollments',$orgEnroll)){
			$lastId =  $this->db->insert_id();
			foreach ($arrEnroll as $key=>$row){
				$arr['enroll_id'] = $lastId;
				$arr['year'] = $arrEnroll[$key];
				$arr['value'] = $arrEnrollVal[$key];
				$this->db->insert('org_enrollment_years',$arr);
			}
			return $lastId;
		}else{
			return false;
		}
	}
	
	function updateEnrollmentDetail($arrEnrollData) {
		$this->db->where('id',$arrEnrollData['id']);
		if($this->db->update('org_enrollments',$arrEnrollData)){
			return true;
		}else{
			return false;
		}
		
	}
	
	function updateEnrollmentDetails($data,$arrEnroll,$arrEnrollVal) {
//		$orgEnroll['org_id']		=	$data['org_id'];
		$orgEnroll['type']			=	$data['type'];
		$orgEnroll['modified_by']	=	$data['modified_by'];
		$orgEnroll['modified_on']	=	$data['modified_on'];
		$orgEnroll['client_id']		=	$data['client_id'];
		$this->db->where('id',$data['id']);
		if($this->db->update('org_enrollments',$orgEnroll)){
			$this->db->where('enroll_id',$data['id']);
			if($this->db->delete('org_enrollment_years')){
				foreach ($arrEnroll as $key=>$row){
						$arr['enroll_id'] = $data['id'];
						$arr['year'] = $arrEnroll[$key];
						$arr['value'] = $arrEnrollVal[$key];
						$this->db->insert('org_enrollment_years',$arr);
					}
					return true;
				}else{
					return false;
				}	
			
			}	
		}
	
	function deleteOrgEnrollById($enrollId) {
		$this->db->where('enroll_id',$enrollId);
		if($this->db->delete('org_enrollment_years')){
			$this->db->where('id',$enrollId);
			$this->db->delete('org_enrollments');
			return true;
		}else{
			return false;
		}
	}
	
	function getEnrollmentById($orgId,$id) {
		$arrEnrollData = array();
		$this->db->where('id',$id);
		$this->db->where('org_id',$orgId);
		$query = $this->db->get('org_enrollments');
		foreach ($query->result_array() as $row){
			$arrEnrollData = $row;
		}
		return $arrEnrollData;
	}
	
	function getEnrollmentsById($orgId,$id,$year) {
			$arrEnrollData = array();
			$this->db->select("org_enrollments.id,org_enrollments.created_by,org_enrollments.org_id,org_enrollments.type,org_enrollment_years.id as enroll_data_id,org_enrollment_years.year,org_enrollment_years.value,
								group_concat( org_enrollment_years.year  ) as year,
								group_concat( org_enrollment_years.value  ) as value,
								group_concat( org_enrollment_years.id  ) as enroll_data_id",false);
			$this->db->where("org_enrollments.id",$id);
			$this->db->join("org_enrollment_years","org_enrollments.id = org_enrollment_years.enroll_id","left");
			$this->db->where_in("org_enrollment_years.year",$year);
			$query = $this->db->get("org_enrollments");
			foreach ($query->result_array() as $row){
				$arrEnrollData = array('id'=>$row['id'],
										'type'=>$row['type'],
										'year'=>explode(',',$row['year']),
										'value'=>explode(',',$row['value'])
				);
			}
			return $arrEnrollData;
		}

	
	function getAllFormularyDropdown() {
		$arrFormularyDropdown = array();
		$query = $this->db->get('org_formulary_dropdown_values');
		foreach ($query->result_array() as $row){
			$arrFormularyDropdown[] = $row;
		}
		return $arrFormularyDropdown;
	}
	
	function addFormularyDetail($arrFormularyDetail) {
		$arrFormData['org_id'] 		= $arrFormularyDetail['org_id'];
		$arrFormData['drug_name'] 	= $arrFormularyDetail['drug_name'];
		$arrFormData['created_by']	= $arrFormularyDetail['created_by'];
		$arrFormData['created_on'] 	= $arrFormularyDetail['created_on'];
		$arrFormData['client_id'] 	= $arrFormularyDetail['client_id'];  
		if($this->db->insert('org_formularies',$arrFormData)){
			$fromId = $this->db->insert_id();
			if(isset($arrFormularyDetail['drug_pa']) && !empty($arrFormularyDetail['drug_pa'])){
				foreach ($arrFormularyDetail['drug_pa'] as $key=>$value){
					$arrDrugPa['type'] 			= 1;
					$arrDrugPa['drug_pa_id'] 	= $value;
					$arrDrugPa['form_id'] 		= $fromId;
					$this->db->insert('org_formluary_mapped_data',$arrDrugPa);
				}
			}
			if(isset($arrFormularyDetail['pa_criteria']) && !empty($arrFormularyDetail['pa_criteria'])){
				foreach ($arrFormularyDetail['pa_criteria'] as $key=>$value){
					$arrDrug['type'] 		= 2;
					$arrDrug['drug_pa_id'] 	= $value;
					$arrDrug['form_id'] 	= $fromId;
					$this->db->insert('org_formluary_mapped_data',$arrDrug);
				}
			}
			return $fromId;
		}else{
			return false;
		}
	}
	
	function getFormularyById($formId) {
		$arrFormularyData = array();
		$this->db->where('id',$formId);
		$query = $this->db->get('org_formularies');
		foreach ($query->result_array() as $row){
			$arrFormularyData = $row;
		}
		return $arrFormularyData;	
	}
	
	function getFormularyMappedById($orgId,$formId) {
		$arrFormularyMappedData = array();
		$this->db->where('form_id',$formId);
		$query = $this->db->get('org_formluary_mapped_data');
		foreach ($query->result_array() as $row){
			$arrFormularyMappedData[$row['drug_pa_id']] = $row;
		}
		return $arrFormularyMappedData;
	}
	
	function updateFormularyDetail($arrFormularyDetail) {
		$arrFormData['id'] 			= $arrFormularyDetail['id'];
		$arrFormData['drug_name'] 	= $arrFormularyDetail['drug_name'];
		$arrFormData['modified_by']	= $arrFormularyDetail['modified_by'];
		$arrFormData['modified_on']	= $arrFormularyDetail['modified_on'];
		$arrFormData['client_id'] 	= $arrFormularyDetail['client_id'];
		$this->db->where('id',$arrFormData['id']);  
		if($this->db->update('org_formularies',$arrFormData)){
			$this->db->where('form_id',$arrFormData['id']);
			if($this->db->delete('org_formluary_mapped_data')){
				if(isset($arrFormularyDetail['drug_pa']) && !empty($arrFormularyDetail['drug_pa'])){
					foreach ($arrFormularyDetail['drug_pa'] as $key=>$value){
						$arrDrugPa['type'] = 1;
						$arrDrugPa['drug_pa_id'] = $value;
						$arrDrugPa['form_id'] = $arrFormData['id']; 
						$this->db->insert('org_formluary_mapped_data',$arrDrugPa);
					}
				}
				
				if(isset($arrFormularyDetail['pa_criteria']) && !empty($arrFormularyDetail['pa_criteria'])){
					foreach ($arrFormularyDetail['pa_criteria'] as $key=>$value){
						$arrDrug['type'] = 2;
						$arrDrug['drug_pa_id'] = $value;
						$arrDrug['form_id'] = $arrFormData['id']; 
						$this->db->insert('org_formluary_mapped_data',$arrDrug);
					}
				}
			}
			return true;
		}else{
			return false;
		}
	}
	
	function deleteOrgFormularyById($formId) {
		$this->db->where('id',$formId);
			if($this->db->delete('org_formularies')){
				$this->db->where('form_id',$formId);
				$this->db->delete('org_formluary_mapped_data');
				return true;
			}else{
				return false;
			}
	}
	
	function getAllDiseaseDropdown() {
		$arrDiseaseDropdown = array();
		$query = $this->db->get('org_disease_drop_down_values');
		foreach ($query->result_array() as $row){
			$arrDiseaseDropdown[] = $row;
		}
		return $arrDiseaseDropdown;
	}
	
	function addDiseaseManagementDetail($arrDiseaseMngmt) {
		$arrDmMngmts['org_id']			=	$arrDiseaseMngmt['org_id'];
		$arrDmMngmts['disease_name']	=	$arrDiseaseMngmt['disease_name'];
		$arrDmMngmts['created_by']		= 	$arrDiseaseMngmt['created_by'];
		$arrDmMngmts['created_on'] 		= 	$arrDiseaseMngmt['created_on'];
		$arrDmMngmts['client_id'] 		= 	$arrDiseaseMngmt['client_id'];
			if($this->db->insert('org_disease_managements',$arrDmMngmts)){
				$dmId = $this->db->insert_id();
				
				if(isset($arrDiseaseMngmt['dm_platform']) && !empty($arrDiseaseMngmt['dm_platform'])){
					foreach ($arrDiseaseMngmt['dm_platform'] as $key=>$value){
						$dmPlatform['disease_id'] 	= $dmId;
						$dmPlatform['value_id'] 	= $value;
						$dmPlatform['type'] 		= DISEASE_MANAGEMENT_PLATFORMS;
						$this->db->insert('org_disease_mapped_data',$dmPlatform);
					}
				}
				
				if(isset($arrDiseaseMngmt['identification']) && !empty($arrDiseaseMngmt['identification'])){
					foreach ($arrDiseaseMngmt['identification'] as $key=>$value){
						$identification['disease_id'] 	= $dmId;
						$identification['value_id'] 	= $value;
						$identification['type'] 		= IDENTIFICATION;
						$this->db->insert('org_disease_mapped_data',$identification);
					}
				}
				
				if(isset($arrDiseaseMngmt['intervention']) && !empty($arrDiseaseMngmt['intervention'])){
					foreach ($arrDiseaseMngmt['intervention'] as $key=>$value){
						$intervention['disease_id'] 	= $dmId;
						$intervention['value_id'] 	= $value;
						$intervention['type'] 		= INTERVENTION;
						$this->db->insert('org_disease_mapped_data',$intervention);
					}
				}
					
				if(isset($arrDiseaseMngmt['measurement']) && !empty($arrDiseaseMngmt['measurement'])){
					foreach ($arrDiseaseMngmt['measurement'] as $key=>$value){
						$measurement['disease_id'] 	= $dmId;
						$measurement['value_id'] 	= $value;
						$measurement['type'] 		= MEASUREMENT;
						$this->db->insert('org_disease_mapped_data',$measurement);
					}
				}
				
				return $dmId;
			}else{
				return false;
			}	
	}
	
	function getDiseaseManagementById($dmId) {
		$this->db->where('id',$dmId);
		$query = $this->db->get('org_disease_managements');
		foreach ($query->result_array() as $row){
			$arrDmData = $row;
		}
		return $arrDmData;
	}
	
	function getDiseaseManagementMappedById($orgId,$dmId) {
		$this->db->where('disease_id',$dmId);
		$query = $this->db->get('org_disease_mapped_data');
		if ($query->num_rows() > 0){
			foreach ($query->result_array() as $row){
				$arrDmMappedData[] = $row;
			}
			return $arrDmMappedData;
		}else{
			return false;
		}
	}
	
	function updateDiseaseManagementDetail($arrDiseaseMngmt) {
		$arrDmMngmts['org_id']			=	$arrDiseaseMngmt['org_id'];
		$arrDmMngmts['disease_name']	=	$arrDiseaseMngmt['disease_name'];
		$arrDmMngmts['modified_by']		=	$arrDiseaseMngmt['modified_by'];
		$arrDmMngmts['modified_on']		=	$arrDiseaseMngmt['modified_on'];
		$arrDmMngmts['client_id'] 		=	$arrDiseaseMngmt['client_id'];
		$this->db->where('id',$arrDiseaseMngmt['id']);
			if($this->db->update('org_disease_managements',$arrDmMngmts)){
				$dmId = $arrDiseaseMngmt['id'];
				$this->db->where('disease_id',$arrDiseaseMngmt['id']);
				if($this->db->delete('org_disease_mapped_data')){
					if(isset($arrDiseaseMngmt['dm_platform']) && !empty($arrDiseaseMngmt['dm_platform'])){
						foreach ($arrDiseaseMngmt['dm_platform'] as $key=>$value){
							$dmPlatform['disease_id'] 	= $dmId;
							$dmPlatform['value_id'] 	= $value;
							$dmPlatform['type'] 		= DISEASE_MANAGEMENT_PLATFORMS;
							$this->db->insert('org_disease_mapped_data',$dmPlatform);
						}
					}
					
					if(isset($arrDiseaseMngmt['identification']) && !empty($arrDiseaseMngmt['identification'])){
						foreach ($arrDiseaseMngmt['identification'] as $key=>$value){
							$identification['disease_id'] 	= $dmId;
							$identification['value_id'] 	= $value;
							$identification['type'] 		= IDENTIFICATION;
							$this->db->insert('org_disease_mapped_data',$identification);
						}
					}
					
					if(isset($arrDiseaseMngmt['intervention']) && !empty($arrDiseaseMngmt['intervention'])){
						foreach ($arrDiseaseMngmt['intervention'] as $key=>$value){
							$intervention['disease_id'] 	= $dmId;
							$intervention['value_id'] 	= $value;
							$intervention['type'] 		= INTERVENTION;
							$this->db->insert('org_disease_mapped_data',$intervention);
						}
					}
						
					if(isset($arrDiseaseMngmt['measurement']) && !empty($arrDiseaseMngmt['measurement'])){
						foreach ($arrDiseaseMngmt['measurement'] as $key=>$value){
							$measurement['disease_id'] 	= $dmId;
							$measurement['value_id'] 	= $value;
							$measurement['type'] 		= MEASUREMENT;
							$this->db->insert('org_disease_mapped_data',$measurement);
						}
					}
				}
				return $dmId;
			}else{
				return false;
			}
	}
	
	function deleteOrgDiseaseManagementById($dmId) {
		$this->db->where('id',$dmId);
			if($this->db->delete('org_disease_managements')){
				$this->db->where('disease_id',$dmId);
				$this->db->delete('org_formluary_mapped_data');
				return true;
			}else{
				return false;
			}
	}
	
	function getAllCollaborationCategories(){
		$query = $this->db->get('org_payer_collabaration_categories');
		foreach ($query->result_array() as $row){
			$arrCollabCat[$row['id']] = $row;
		}
		return $arrCollabCat;
		
	}
	
	function getCollaborationCategories(){
		$query = $this->db->get('org_payer_collabaration_categories');
		foreach ($query->result_array() as $row){
			$arrCollabCat[] = $row;
		}
		return $arrCollabCat;
		
	}
	
	function getAllCollabarationRatings() {
		$query = $this->db->get('org_collabaration_categories_ratings');
		foreach ($query->result_array() as $row){
			$arrCollabRatings[] = $row;
		}
		return $arrCollabRatings;
	}
	
	function getAllOrgCollabarationRatings($orgId){
		$arrCategories = array();
		$this->db->select('category_id,group_concat(rating separator ",") as ratings');
		$this->db->join('org_payer_collabaration_mapped_data','org_payer_collabaration_mapped_data.category_id=org_payer_collabaration_categories.id');
		$this->db->join('org_collabaration_categories_ratings','org_collabaration_categories_ratings.id=org_payer_collabaration_mapped_data.rating_id');
		$this->db->where('org_id',$orgId);
		$this->db->group_by('org_payer_collabaration_categories.category');
		$arrResultSet = $this->db->get('org_payer_collabaration_categories');
		foreach($arrResultSet->result_array() as $row){
			$arrCategories[$row['category_id']] = $row;
		}
		return $arrCategories;
	}
	
	function addCollaborationRatingsData($arrData,$data) {
		
		$this->db->where('org_id',$data['org_id']);
		$this->db->delete('org_payer_collabaration_mapped_data');
		foreach ($arrData as $key=>$row){
			if(!empty($row)){
				foreach($row as $key1=>$row1){
					$arrRatings =array();
					$arrRatings['org_id'] 		= $data['org_id'];
					$arrRatings['category_id'] 	= $key;
					$arrRatings['rating_id'] 	= $row1;
					$arrRatings['client_id']	= $data['client_id'];
					$arrRatings['created_by'] 	= $data['created_by'];
					$arrRatings['created_on'] 	= $data['created_on'];				
					$this->db->insert('org_payer_collabaration_mapped_data',$arrRatings);
				}
			}
		}
		return true;
	}
	
	function getAllCollaborationMappedData($orgId) {
		$arrRatings = array();
		$this->db->where('org_id',$orgId);
		$query = $this->db->get('org_payer_collabaration_mapped_data');
		foreach ($query->result_array() as $row){
			$arrRatings[$row['rating_id']] = $row;
		}
		return $arrRatings;
	}
	
	function deleteFacts($orgId){
		$this->db->where('org_id',$orgId);
		$this->db->delete('org_payer_facts');
	}
	
	function saveEnrollements($arr){
		$this->db->insert('org_enrollment_years',$arr);
	}
	
	function getOrgDetailsForRecentAvtivity($orgId){
		$arrNames = array();
		$this->db->where('id',$orgId);
		$this->db->select('id,name,status');
		$result=$this->db->get('organizations');
		foreach($result->result_array() as $row){
			$arrNames=$row;
		}
		return $arrNames;
	}
	
	function getOrgType($orgId){
		$arr = array();
		$this->db->select('type_id');
		$this->db->where('id',$orgId);
		$arrResultSet = $this->db->get('organizations');
		foreach($arrResultSet->result_array() as $row){
			$arr = $row;
		}
		return $arr;
	}
	function getMaxEnrollYear($orgIds) {
		$this->db->select("GROUP_CONCAT(DISTINCT(org_enrollments.org_id) SEPARATOR ',') AS ids, MAX(org_enrollment_years.year) AS maxyear",false);
		$this->db->join("org_enrollment_years","org_enrollments.id = org_enrollment_years.enroll_id","left");
		$this->db->where_in("org_enrollments.org_id",$orgIds);
		$result = $this->db->get("org_enrollments");
		foreach ($result->result_array() as $row){
			$arr = $row;
		}
		return $arr;
	}
	function getOrgTypeById($arrTypeId){
		$arrTypes = array();
		$this->db->where_in('id',$arrTypeId);
		$arrResultSet = $this->db->get('organization_types');
		foreach($arrResultSet->result_array() as $row){
			$arrTypes[$row['id']] = $row['type'];
		}
		return $arrTypes;
	}
	function getOrgsById($arrId){
		$arrOrgs = array();
		$this->db->select('id as org_id,name');
		$this->db->where_in('id',$arrId);
		$arrResultSet = $this->db->get('organizations');
		foreach($arrResultSet->result_array() as $row){
			$arrOrgs[$row['org_id']] = $row['name'];
		}
		return $arrOrgs;
	}
	
	function getAllCustomFilterByUser($userId) {
		$this->db->where('created_by',$userId);
		$this->db->where('filter_type',2);
		$this->db->order_by('applied_on','desc');
		$this->db->order_by('name','asc');
		$result = $this->db->get('custom_filters');
		foreach ($result->result_array() as $row){
			$arrData[] = $row;
		}
		return $arrData;
	}
	
	function saveCustomFilters($arrData) {
		if($this->db->insert('custom_filters',$arrData)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	function getFilterById($arrData) {
		$this->db->where('id',$arrData['id']);
		if($this->db->update('custom_filters',$arrData)){
			$this->db->where('id',$arrData['id']);
			$result = $this->db->get('custom_filters');
			if ($result->num_rows() > 0)
				{
				   foreach ($result->result() as $row)
				   {
				      $arrData = $row->filter_value;
				   }
				}
			return $arrData;
		}else{
			return false;
		}
	}
	
	function updateCustomFilters($arrData) {
		$this->db->where('id',$arrData['id']);
		$result = $this->db->update('custom_filters',$arrData);
		if($result)
			return true;
		else
			return false;
	}
	
	function deleteSavedFilter($filterId) {
		$this->db->where('id',$filterId);
		$result = $this->db->delete('custom_filters');
		if($result)
			return true;
		else
			return false;
	}
	
	function updateSavedFilter($arrData) {
		$this->db->where('id',$arrData['id']);
		$result = $this->db->update('custom_filters',$arrData);
		if($result)
			return true;
		else
			return false;
	}
	
	function getOrgNameById($orgId) {
		$this->db->select("name");
		$this->db->where("id",$orgId);
		$query = $this->db->get("organizations");
		foreach ($query->result_array() as $row){
			$orgName = $row['name'];
		}
		return $orgName;
	}
	
	function getAllEventsByOrgName($orgName) {
		$this->db->select("COUNT(DISTINCT kol_id) AS num_kol,event_id,events.name AS events_name,kol_events.event_type,
							conf_event_types.event_type AS event_type_name,start,end,address,city_id,state_id,country_id");
		$this->db->join("conf_event_types","kol_events.event_type = conf_event_types.id","left");
		$this->db->join("events","events.id = kol_events.event_id","left");
		$this->db->where("organizer",$orgName);
		$this->db->group_by("event_id");
		$this->db->order_by("num_kol","desc");
		$query = $this->db->get("kol_events");
//		echo $this->db->last_query();
		foreach ($query->result_array() as $row){
			$arrData[] = $row;
		}
		return $arrData;
	}
	
	function getAllKolIdsByEventId($eventId,$eventName) {
		$this->db->select("DISTINCT(kol_id)");
		$this->db->where("event_id",$eventId);
		$this->db->where("organizer",$eventName);
		$query = $this->db->get("kol_events");
		foreach ($query->result_array() as $row){
			$kolIds[] = $row;
		}
		return $kolIds;
	}
	
	function getKolDetailsByIds($kolId){
		$arrKolDetails =array();
		$this->db->where_in('kols.id',$kolId);
		$this->db->select('kols.id,kols.salutation,kols.first_name,kols.middle_name,kols.last_name,kols.specialty,specialties.specialty as specialty_name,kols.city_id,kols.state_id,kols.country_id,countries.Country,regions.Region,cities.City,kols.primary_phone,kols.primary_email');
		$this->db->join('specialties', 'specialties.id = kols.specialty', 'left');
		$this->db->join('countries', 'CountryId = kols.country_id', 'left');
		$this->db->join('regions','RegionId = kols.state_id','left');
		$this->db->join('cities','cityId = kols.city_id','left');
		$arrKolDetailsResult	=	$this->db->get('kols');
//		echo $this->db->last_query();
		foreach($arrKolDetailsResult->result_array() as $row){
			$arrKolDetails[] = $row;
		}
		return $arrKolDetails;
	}
	
	function getFilterByRecentApplied() {
	$userId = $this->session->userdata('user_id');
	$this->db->select("id,name,filter_value");
		$this->db->where('filter_type',2);
		$this->db->where('created_by',$userId);
		$this->db->where('applied_on !=','0000-00-00 00:00:00');
		$this->db->order_by('applied_on',"desc");
		$this->db->limit(1);
		$result = $this->db->get('custom_filters');
//		echo $this->db->last_query();
		if ($result->num_rows() > 0){
		   foreach ($result->result_array() as $row){
		      $data = $row;
		   }
//		   pr($data);
		   	$arrPostData	= array();
			$arrFilterValue	= json_decode($data['filter_value']);
			$postData	= explode('&',$arrFilterValue->postData);
			foreach($postData as $key=>$row){
				$arrValues	= array();
				$arrRow	= explode('=',$row);
				$arrValues	= explode(',',$arrRow[1]);
				foreach($arrValues as $index=>$value){
					if($value != '')
					$arrPostData[$arrRow[0]][$value]	= $value;
				}
			}
//			pr($arrPostData);
			$arrFilterFields	= array();
			foreach($arrPostData as $key=>$value){
				switch($key){
					case 'states':
							$arrFilterFields['state']	=$value;
						break;
					case 'cities':
							$arrFilterFields['city']	=$value;
						break;
					case 'countries':
							$arrFilterFields['country']	= $value;
						break;
					case 'org_types':
							$arrFilterFields['org_types']	= $value;
						break;
					case 'profile_type':
								$arrFilterFields['profile_type'] = $value;
						break;
				}
			}
//			pr($arrFilterFields);
			$data['filter_value'] = $arrPostData;
			$data['arrFilterFields'] = $arrFilterFields;
			return $data;
		}else{
			return false;
		}
	}
	
	function resetAppliedFilter($userId) {
		$arrData['applied_on'] = '';
		$this->db->where("created_by",$userId);
		$this->db->where("filter_type",2);
		if($this->db->update("custom_filters",$arrData))
			return true;
		else
			return false; 
	}
	
	function OrgMediacalServicesByBulk($arrData){
		
		foreach($arrData as $row){
			$row['url'] = mysql_real_escape_string($row['url']);
			$bulkStatment.="('".$row['org_id']."','".$row['medical_service_id']."','".$row['url']."')".",";
			
		}
		$stament=  substr($bulkStatment,0,-1);
		$this->db->query('insert into org_medical_services(`org_id`,`medical_service_id`,`url`) values'.$stament.'');
	//	echo $this->db->last_query();
	}
	

	function saveAffiliatesPartnershipsBulk($arrData){
		
		foreach($arrData as $row){
			$row['address'] = mysql_real_escape_string($row['address']);
			
			$row['url'] = mysql_real_escape_string($row['url']);
			$bulkStatment.="('".$row['address']."','".$row['url']."','".$row['postal_code']."','".$row['state_id']."',
			'".$row['country_id']."','".$row['phone']."','".$row['npi_num']."','".$row['org_id']."',
			'".$row['sub_org_id']."','".$row['city_id']."')".",";
			
		}
		$stament=  substr($bulkStatment,0,-1);
		$this->db->query('insert into affiliates_partnerships(`address`,`url`,`postal_code`,`state_id`,`country_id`,`phone`,`npi_num`,`org_id`,`sub_org_id`,`city_id`) values'.$stament.'');
		//echo $this->db->last_query();
	}
	
	function saveKeyPeopleBulk($arrData){
		$bulkStatment	= '';
		/*
		foreach($arrData as $row){

		  //  pr($row);
		//	$row['first_name'] = mysqli_real_escape_string($row['first_name']);
		//	$row['middle_name'] = mysqli_real_escape_string($row['middle_name']);
		//	$row['last_name'] = mysqli_real_escape_string($row['last_name']);
		//	$row['department'] = mysqli_real_escape_string($row['department']);
		//	$row['title'] = mysqli_real_escape_string($row['title']);
		//	$row['email'] = mysqli_real_escape_string($row['email']);
		//	$row['url'] = mysqli_real_escape_string($row['url']);

			$bulkStatment.="('".$row['role_id']."','".$row['salutation']."','".$row['first_name']."','".$row['middle_name']."','".$row['last_name']."',
			'".$row['department']."','".$row['title']."','".$row['email']."','".$row['url']."',
			'".$row['created_by']."','".$row['created_on']."','".$row['org_id']."')".",";
			
		}
		$stament=  substr($bulkStatment,0,-1);
		$this->db->query('insert into key_peoples(role_id,salutation,first_name,middle_name,last_name,department,title,email,url,created_by,created_on,org_id) values'.$stament.'');
		echo $this->db->last_query();
		*/
		foreach($arrData as $row){
			$this->db->insert('key_peoples',$row);
		}
	}
	
	function getCountOfMedical($orgId){
		
		$this->db->where('org_id',$orgId);
		$result = $this->db->count_all_results('org_medical_services');
		return $result;
		
	}
	
	function getCountOfAffiliates($orgId){
		
		$this->db->where('org_id',$orgId);
		$result = $this->db->count_all_results('affiliates_partnerships');
		return $result;
		
	}
	
	function getCountOfKeyPeople($orgId){
		
		$this->db->where('org_id',$orgId);
		$result = $this->db->count_all_results('key_peoples');
		return $result;
		
	}
	
	function getCountOfPmids($orgId){
		
		$this->db->where('org_id',$orgId);
		$result = $this->db->count_all_results('org_pmids');
		return $result;
		
	}
	
	function getCountOfCtids($orgId){
		
		$this->db->where('org_id',$orgId);
		$result = $this->db->count_all_results('org_ctids');
		return $result;
		
	}
	
	
	function getCountOfEnrollments($orgId){
		
		$this->db->where('org_id',$orgId);
		$result = $this->db->count_all_results('org_enrollments');
		return $result;
		
	}
	
	function getCountOfFormularies($orgId){
		
		$this->db->where('org_id',$orgId);
		$result = $this->db->count_all_results('org_formularies');
		return $result;
		
	}
	
	function getCountOfDisease($orgId){
		
		$this->db->where('org_id',$orgId);
		$result = $this->db->count_all_results('org_disease_managements');
		return $result;
		
	}
	
	function getOrgBasicInfoById($id){
		$this->db->where('id',$id);
		$result = $this->db->get('organizations');
		foreach ($result->result_array() as $row){
			$arrData = $row;
		}
		return $arrData;
	}
	
	function getAllMedicalService(){
		$arrData = array();
		$result = $this->db->get("medical_services");
		foreach ($result->result_array() as $row){
			$arrData[$row['id']] = $row;
 		}
 		return $arrData;
	}

	function getMedicalServiceDetailsById($orgId){
		$arrMedicalServices = array();
		$this->db->select('org_medical_services.id,medical_services.name,org_medical_services.medical_service_id');
		$this->db->join('medical_services','medical_services.id=org_medical_services.medical_service_id','left');
		$this->db->where('org_medical_services.org_id',$orgId);
		$arrResultSet = $this->db->get('org_medical_services');
		foreach($arrResultSet->result_array() as $row){
			$arrMedicalServices[$row['medical_service_id']]=$row;
		}
		return $arrMedicalServices;
	}
	
	function saveMedicalService($data){
//		pr($data);
		foreach ($data as $row){
			$this->db->insert('org_medical_services',$row);
//			echo $this->db->last_query();
		}
	}
	
	function getFactsById($orgId){
		$arrData = array();
		$this->db->where("org_id",$orgId);
		$result = $this->db->get("org_stats_facts");
		foreach ($result->result_array() as $row){
			$arrData = $row;
 		}
 		return $arrData;
	}
	
	function updateOrgFacts($arrData){
		$this->db->where("id",$arrData['id']);
		if($this->db->update("org_stats_facts",$arrData))
			return true;
		else
			return false;
	}
	
	function getPayerFactsById($orgId){
		$this->db->select("org_payer_facts.id,org_payer_facts.org_id,org_payer_facts.no_of_hospitals,org_payer_facts.no_of_physicians,org_payer_facts.no_of_affiliated,org_payer_facts.benefit_management,org_payer_facts.specialty_pharmacy,org_payer_facts.ncqa_status,org_payer_facts.start_rating,org_payer_facts.physicians_employed,
							group_concat( case org_claims_process_mapped_data.type_id when 1 then org_claims_process.id else null end separator ',') as cliam_and_emr,
							group_concat( case org_claims_process_mapped_data.type_id when 2 then org_claims_process.id else null end separator ',') as data_processing",false);
		$this->db->where("org_payer_facts.org_id",$orgId);
		$this->db->join("org_claims_process_mapped_data","org_claims_process_mapped_data.fact_id = org_payer_facts.id","left");
		$this->db->join("org_claims_process","org_claims_process_mapped_data.cliam_process_id = org_claims_process.id","left");
		$this->db->group_by("org_claims_process_mapped_data.fact_id");
		$arrResultSet = $this->db->get("org_payer_facts");
//		echo $this->db->last_query();
		foreach($arrResultSet->result_array() as $row){
			$arrOrgPayerFact = $row;
		}
		return $arrOrgPayerFact;
 		
	}
	
	function updatePayerFacts($arrData){
		$this->db->where("id",$arrData['id']);
		if($this->db->update("org_payer_facts",$arrData))
			return true;
		else
			return false;
	}
	
	function update_org_claims_process_mapped_data($arrData,$rowId){
		$this->db->where('fact_id',$rowId);
		if($this->db->delete('org_claims_process_mapped_data')){
			foreach ($arrData as $arrRowData){
				$this->db->insert('org_claims_process_mapped_data',$arrRowData);				
			}
		}
		return true;
	}
	
	function savePayerFacts($arrData){
		if($this->db->insert('org_payer_facts',$arrData)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	function saveOrgFacts($arrData){
		if($this->db->insert("org_stats_facts",$arrData))
			return true;
		else
			return false;
	}
	
	function save_org_claims_process_mapped_data($arrData){
		foreach ($arrData as $arrRowData){
			$this->db->insert('org_claims_process_mapped_data',$arrRowData);				
		}
		return true;
	}
	
	function deleteSubOrg($orgId){
		$this->db->where('sub_org_id',$orgId);
		if($this->db->delete('affiliates_partnerships')){
			return true;
		}else{
			return false;
		}
	}
	
	function getOrgSocialMediaById($orgId){
		$this->db->select("id,blog,facebook,twitter,youtube,linkedin");
		$this->db->where('id',$orgId);
		$result = $this->db->get('organizations');
		$this->db->last_query();
		foreach ($result->result_array() as $row){
			$arrData = $row;
		}
		return $arrData;
	}
	
	function updateOrgSocialMedia($arrData){
		$this->db->where("id",$arrData['id']);
		if($this->db->update("organizations",$arrData))
			return true;
		else
			return false;
	}
	
	function getMyOrgsView($userId){
		$this->db->select('org_id');
		$this->db->where('user_id',$userId);
		$this->db->join('organizations','user_orgs.org_id = organizations.id','left');
		//$this->db->where('organizations.status',COMPLETED);
		$result = $this->db->get('user_orgs');
		foreach ($result->result_array() as $row){
			$arr[$row['org_id']] = $row['org_id'];  
		}
		return $arr;
	}
        
        /**
	 * Saving a new organization based on type
	 * @author 	Shruti Purushan
	 * @Created on: 16-10-2015
	 * @return
	 */
        function saveOrg($arrData,$data){
		$arrData['created_by']	= $this->session->userdata('user_id');
		$arrData['created_on']	= date("Y-m-d H:i:s");
		if($this->db->insert('organizations',$arrData)){
			$lastId=$this->db->insert_id();
			$this->db->where("id",$lastId);
			$this->db->set("cin_num",$lastId);
			$this->db->update('organizations');
                        $orgLastId=$lastId;
                        $data['contact'] = $lastId;
                        $this->db->insert('contact_restrictions',$data);
                        return $orgLastId;
                      
		}   else{
			return false;
		}
                
	}
        
         /**
	 * Fetching all specialty for  organization 
	 * @author 	Shruti Purushan
	 * @Created on: 19-10-2015
	 * @return
	 */
        function getSpecialtyNames(){
            $arrReturnData = array();
            $this->db->select('id,specialty');


            $this->db->order_by('id', 'desc');
            $arrResultSet = $this->db->get('specialties');
            //        echo $this->db->last_query();
            foreach ($arrResultSet->result_array() as $row) {
                $arrReturnData[] = $row;
            }
            return $arrReturnData;

        }
        
         /**
	 * Editing a new organization based on type
	 * @author 	Shruti Purushan
	 * @Created on: 16-10-2015
	 * @return
	 */

        function editOrg($id=''){
		$arrReturnData 				= array();
		$this->db->select('organizations.* ');
		if(!empty($id)){
			$this->db->where('organizations.id',$id);
		}
		$this->db->order_by('organizations.id','desc');
		$arrOrgResultSet		= $this->db->get('organizations');
		//echo $this->db->last_query();
		foreach($arrOrgResultSet->result_array() as $row){
//			$row['agent']		= $this->Client_User->getUserNameById($row['agent']);
//			$row['created_user']= $row['ufname'].' '.$row['ulname'];
			$arrReturnData[]	= $row;
		}
		return $arrReturnData;
	}
        
         /**
	 * Editing Contact Restrictions of organization based on type
	 * @author 	Shruti Purushan
	 * @Created on: 21-10-2015
	 * @return
	 */

        function getContactRestrictions($id=''){
		$arrReturnData 				= array();
		$this->db->select('contact_restrictions.* ');
		if(!empty($id)){
			$this->db->where('contact_restrictions.contact',$id);
		}
		$this->db->order_by('contact_restrictions.contact','desc');
		$arrContactRestrictionsResultSet		= $this->db->get('contact_restrictions');
		//echo $this->db->last_query();
		foreach($arrContactRestrictionsResultSet->result_array() as $row){
//			$row['agent']		= $this->Client_User->getUserNameById($row['agent']);
//			$row['created_user']= $row['ufname'].' '.$row['ulname'];
			$arrReturnData[]	= $row;
		}
		return $arrReturnData;
	}
         /**
	 * Updating a new organization based on type
	 * @author 	Shruti Purushan
	 * @Created on: 16-10-2015
	 * @return
	 */
        function updateOrg($arrData,$data){
                
		$arrData['created_by']	= $this->session->userdata('user_id');
		$arrData['created_on']	= date("Y-m-d H:i:s");
                $this->db->where('id',$arrData['id']);
		if($this->db->update('organizations',$arrData)){
                $this->db->where('contact',$data['contact']);
                $this->db->delete('contact_restrictions');
		$this->db->insert('contact_restrictions',$data);
                        return true;
		}else{
			return false;
		}
	}
        
        function updateOrgAsPrimary($arrOrgDetails){
           
                    $id	=	$arrOrgDetails['id'];
                    $this->db->where('id',$id);
                    $this->db->update('organizations',$arrOrgDetails);
                    return true;
                
        }
        /**
	 * Updating a Contact Restrictions of organization based on id
	 * @author 	Shruti Purushan
	 * @Created on: 21-10-2015
	 * @return
	 */
        function updateContactRestrictions($data,$lastId){
                $this->db->where('contact',$lastId);
                $this->db->delete('contact_restrictions');
		$this->db->update('contact_restrictions',$data);
                        
	}
        
        /*
        * To get List of Institution Names By passing  Name for autocomltete 
        * @author Shruti Purushan
        * @created on 16-10-2015
        */
        function getAllInstitutionNamesForAutocomplete($Name){
                $arrKols =array();
                $this->db->select("name");
                if(count(explode(' ',$Name))>2){
                $this->db->like("concat_ws(' ',name)",$Name);
                }else{
                        $this->db->like("concat_ws(' ',name)",$Name);
                }
                $this->db->where('organizations.org_type','institution');
                $arrKolsResult=$this->db->get('organizations');
                $arrCompletedKols	= array();
                $arrMyCustomers		= array();
                foreach($arrKolsResult->result_array() as $row){

                $arrMyCustomers[$row['institution_type']][]	= $row['name'];
                        }
                $arrKols['kols']		= $arrMyCustomers;
                return $arrKols;

        }
        function saveLocation($arrLocation) {
            if(isset($arrLocation['id'])) {
                $id = $arrLocation['id'];
                unset($arrLocation['id']);
                if($arrLocation["is_primary"] == "1") {
                    $primary_flag = array('is_primary' => 0);
                    $this->db->where('org_id',$arrLocation['org_id']);
                    $this->db->update('org_locations',$primary_flag);
                }
                
                $this->db->where('id',$id);
                if($this->db->update('org_locations',$arrLocation)){
                    return true;
                }else{
                    return false;
                }
            } else {
                
                if($arrLocation["is_primary"] == "1") {
                    $primary_flag = array('is_primary' => 0);
                    $this->db->where('org_id',$arrLocation['org_id']);
                    $this->db->update('org_locations',$primary_flag);
                }
                
                if($this->db->insert('org_locations',$arrLocation)){
                            return $this->db->insert_id();
                }else{
                            return false;
                }
            }
        }
        
        
        function listLocationDetails($orgId) {
             $this->db->select('org_locations.id,'
                     .'CONCAT(COALESCE(org_locations.address1,""),", ",COALESCE(org_locations.address2,"")," ",COALESCE(org_locations.address3,"")) as address, '
                     . 'org_locations.main as org_name, cities.City as city, regions.Region as state,org_locations.postal_code,org_locations.is_primary,org_locations.address_type,org_locations.created_by', false);
             $this->db->where('org_id',$orgId);
            //$this->db->join('countries','kol_locations.country_id = countries.CountryID','left');
            $this->db->join('regions','org_locations.state_id = regions.RegionID','left');
//            $this->db->join('organizations','kol_locations.org_institution_id = organizations.id','left');
            $this->db->join('cities','org_locations.city_id = cities.CityId','left');
            $res = $this->db->get('org_locations');
            return $res->result_array();
//            $this->db->select('org_locations.id, concat(org_locations.address1, " ", org_locations.address2, " ",  org_locations.address3) as address, countries.Country as country, regions.Region as state, cities.City as city', false);
//            $this->db->where('org_id',$orgId);
//            $this->db->join('countries','org_locations.country_id = countries.CountryID','left');
//            $this->db->join('regions','org_locations.state_id = regions.RegionID','left');
//            $this->db->join('cities','org_locations.city_id = cities.CityId','left');
//            $res = $this->db->get('org_locations');
//            return $res->result_array();
            
            
            
        }
         function getLocationById($id) {
            $this->db->select('org_locations.*');
            $this->db->where('id',$id);
            $res = $this->db->get('org_locations');
            return $res->result_array();
        }
        
        function deleteLocation($id) {
            $this->db->where('id',$id);
            $this->db->delete('org_locations');
        }
        
        /*
        * To get organization details from org_locations
        * @author Shruti Purushan
        * @created on 23-10-2015
        */
        function getLocationByOrganizationId($id){
            $this->db->select('org_locations.*');
            $this->db->where('org_locations.org_id',$id);
            $this->db->where('org_locations.is_primary',1);
            $res = $this->db->get('org_locations');
            return $res->result_array();
        }
          
        /*
        * To update the organization details from org_locations
        * @author Shruti Purushan
        * @created on 23-10-2015
        */
        function updateOrgLocation($arrLocation){
           if(isset($arrLocation['org_id'])){
                if($arrLocation["is_primary"] == "1") {
                    $primary_flag = array('is_primary' => 0);
                    $this->db->where('org_id',$arrLocation['org_id']);
                    $this->db->update('org_locations',$primary_flag);
                }
                
                $this->db->where('id',$arrLocation['id']);
                if($this->db->update('org_locations',$arrLocation)){
                    return true;
                }else{
                    return false;
                }
            
            }
        }
        
        
	function getOrgNames($arrIds=""){
		$arrKolDetail=array();
		$this->db->select('id,name,status');
		if($arrIds != "" && is_array($arrIds))
			$this->db->where_in('id',$arrIds);
		$this->db->order_by('name');
		$arrKolDetailResult	=	$this->db->get('organizations');
		foreach($arrKolDetailResult->result_array() as $row){
			$arrKolDetail[]=$row;
		}
		return $arrKolDetail;
	}
        function getOrgFullDetails($id){
		$arrKolDetail=array();
		$this->db->select('organizations.*');
                $this->db->where('organizations.id',$id);
		$this->db->order_by('name');
		$arrKolDetailResult	=	$this->db->get('organizations');
		foreach($arrKolDetailResult->result_array() as $row){
			$arrKolDetail[]=$row;
		}
		return $arrKolDetail;
	}
        
         /**
	 * Fetching all mco type  for  organization 
	 * @author 	Shruti Purushan
	 * @Created on: 19-10-2015
	 * @return
	 */
        function getMcoTypeNames(){
            $arrReturnData = array();
            $this->db->select('id,name');
            $this->db->order_by('id', 'ASC');
            $arrResultSet = $this->db->get('org_mco_type');
            //        echo $this->db->last_query();
            foreach ($arrResultSet->result_array() as $row) {
                $arrReturnData[] = $row;
            }
            return $arrReturnData;

        }
         /**
	 * Fetching all address type  for  organization 
	 * @author 	Shruti Purushan
	 * @Created on: 4-11-2015
	 * @return
	 */
        function getAddressTypeNames(){
            $arrAddressTypeNames	= array();
            $this->db->select('id,name');
            $this->db->where('is_active',1);
            $this->db->order_by('id', 'ASC');
            $result	= $this->db->get('org_address_type');
            foreach($result->result_array() as $row){
                    $arrAddressTypeNames[] = $row;
            }
            return $arrAddressTypeNames;
        }
        /**
	 * Fetching all validation_status for  organization 
	 * @author 	Shruti Purushan
	 * @Created on:  4-11-2015
	 * @return
	 */
        function getValidationStatusNames(){
            $arrValidationStatus	= array();
            $this->db->select('id,name');
            $this->db->where('is_active',1);
            $this->db->order_by('id', 'ASC');
            $result	= $this->db->get('validation_status');
            foreach($result->result_array() as $row){
                    $arrValidationStatus[] = $row;
            }
            return $arrValidationStatus;
        }
        
        
        /**
	 *  GET org details of the Specified Id
	 * @param
	 * @return array - $arrKolDetail - Returns
	 */
	function getOrgDetailsById($orgId){
		$arrKolDetails =array();
		//$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$this->db->where('id',$orgId);
		$this->db->select(array('organizations.*','countries.Country','regions.Region','cities.City'));
		$this->db->join('countries', 'CountryId = country_id', 'left');
		$this->db->join('regions','RegionId = state_id','left');
		$this->db->join('cities','cityId = city_id','left');

		$arrKolDetailsResult	=	$this->db->get('organizations');
		foreach($arrKolDetailsResult->result_array() as $row){
			$arrKolDetails[] = $row;
		}
              //  echo $this->db->last_query();
		return $arrKolDetails;
	}

	
        
        function getAllLocationsByOrgId($orgId){
        	$this->db->select('org_locations.*');
            $this->db->where('org_locations.org_id',$orgId);
            $result = $this->db->get('org_locations');
            $arr = array();
            foreach ($result->result_array() as $row){
              
            	if($row['main'] != '')   
                    $arr[$row['id']] = $row['main'];
            }
            return $arr;
            
        }
        
         function getPhones($id, $type) {
            $this->db->select(' org_locations.main,phone_numbers.*,phone_type.name as phn_type');
			if($type == 'location'){
            	$this->db->where('location_id',$id);
            }
          	if($type == 'organization'){
            	$this->db->where('contact',$id);
            	$this->db->where('contact_type =','organization');
          	}
            $this->db->join('org_locations','org_locations.id = phone_numbers.location_id','left');
            $this->db->join("phone_type","phone_type.id = phone_numbers.type","left");
            $res = $this->db->get('phone_numbers');
            return $res->result_array();
        }
        
         function getStaffs($id, $type) {
            $this->db->select('org_locations.main as loc_name,staffs.*,staff_title.name as staff_title');
            if($type == 'location'){
            	$this->db->where('location_id',$id);
            }
          	if($type == 'organization'){
            	$this->db->where('contact',$id);
            	$this->db->where('contact_type =','organization');
          	}
          	$this->db->join("staff_title", "staff_title.id = staffs.title", "left");
 			$this->db->join('org_locations','org_locations.id = staffs.location_id','left');
            $res = $this->db->get('staffs');
            return $res->result_array();
        }
        
	function getExcludedKolsOrgs($arrIds){
            $this->db->select(array('organizations.id', 'organizations.name', '0 as kol_org_count'), false);
            $this->db->order_by("name", "asc"); 
            $this->db->join('kols','organizations.id=kols.org_id');
            if(count($arrIds) !=0)
                $this->db->where_not_in('organizations.id', $arrIds);
            $this->db->where('kols.status',COMPLETED);
            $this->db->group_by('organizations.id');
            $client_id = $this->session->userdata('client_id');
            if($client_id !== INTERNAL_CLIENT_ID){
            	$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
            	$this->db->where('kols_client_visibility.client_id', $client_id);
            }
            $query = $this->db->get('organizations');
            //pr($this->db->last_query());exit;
            return $query->result_array();
        }
        
        function updateOrgTypeForOrganization($arrData) {
        	$this->db->where('id',$arrData['id']);
        	$result = $this->db->update('organizations',$arrData);
        	if($result)
        		return true;
        		else
        			return false;
        }
        function checkOrgAissenedToUser($kolId){
            if($client_id == INTERNAL_CLIENT_ID){
                return true;
            }else{
                $userId = $this->session->userdata('user_id');
                $get = $this->db->get_where('user_orgs',array("user_id"=>$userId,"org_id"=>$kolId));
                if($get->num_rows()>0){
        
                    return true;
                }
                return false;
            }
        }
        function saveOrgAssignClient($arrAssignData) {
        	if ($this->db->insert('user_orgs', $arrAssignData)) {
        		return $this->db->insert_id();
        	} else {
        		return false;
        	}
        }
 
        /*
	 	* @Author : Kishan Ravindra (00001111)
	 	* @Params : columnName, columnValue, searchType (WHERE / LIKE / FIND_IN_SET)
	 	* @Action : Returns the data matching the search criteria. ( SearchType on columnName = columnValue )
	 	*/
        function getOrgs($colName=null, $colValue=null, $searchType = null) {
        	if($colName != null && $colValue != null && $searchType != null){
        		switch(strtoupper($searchType)){
        			Case "WHERE":
        				$this->db->where($colName, $colValue);
        				break;
        			Case "LIKE": 
        				$this->db->like($colName, $colValue);
        				break;
        			Case "FIND_IN_SET":
        				$this->db->where('id IS NOT NULL',' AND find_in_set('.$colValue.','.$colName.')',false);
        				break;
        		}
        	}
        	$this->db->order_by('name');
        	$query = $this->db->get('organizations');
        	return $query->result_array();
        }
        function associateParentOrganisation($arrChildOrgId, $parentOrgId){
        	$data = array(
        			"parent_id"=>$parentOrgId
        	);
        	$this->db->where_in("id", $arrChildOrgId);
        	if($this->db->update("organizations", $data)){
        		return true;
        	}else{
        		return false;
        	}
        }
        function updateParentForOrg($arrOrgIds){
        	$data = array(
        			"parent_id"=>0
        	);
        	$this->db->where_in("id", $arrOrgIds);
        	if($this->db->update("organizations", $data)){
        		return true;
        	}else{
        		return false;
        	}
        }
}