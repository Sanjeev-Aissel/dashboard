<?php
/**
 * Hook to detect the the user agent and the browser of the request and redirect the request 
 * to  appropriate controller
 * @author Ramesh B
 * @since
 * @package application.controllers	
 * @created on 12-10-2011
 */



if (!defined('BASEPATH')) exit('No direct script access allowed');



class Mobile_agent_detect_custom_redirect

{

	var $CI;
    var $lang;
    
    // No Comments 
    function mobile_agent_detect_custom_redirect(){
    	$this->CI =& get_instance();
    	$this->CI->load->helper('url');
    	require_once($_SERVER['DOCUMENT_ROOT']."/".$this->CI->config->item('app_folder_path')."application/libraries/mobile_device_detect.php");
    	require_once($_SERVER['DOCUMENT_ROOT']."/".$this->CI->config->item('app_folder_path')."application/libraries/Browscap.php");
    }
    
    // No Comments 
	function check(){
		//Get the Mobile Platform details from the library 'mobile_device_detect'
		$mobile = mobile_device_detect();
		//pr($mobile);	
		
		//Get the Browser Details from the php native funtion 'get_browser'  using 'browsecap.ini'
		//$browser=get_browser(null, true);

		//Get the Browser Details from 'Browscap.php' file
		// Creates a new Browscap object (loads or creates the cache)
		$bc = new Browscap($_SERVER['DOCUMENT_ROOT']."/".$this->CI->config->item('app_folder_path')."system/cache");				
		// Gets information about the current browser's user agent
		$browser = $bc->getBrowser();
		
		
		$currentController=$this->CI->uri->segment(1);
		$currentMethod=$this->CI->uri->segment(2);
		if( ($currentController== 'login' || $currentController == '') && $currentMethod=='' ){
			//echo 'Platform : '.$mobile[1].',   Browser : '.$browser['browser'];
			if(isset($mobile[1]))
				redirect(base_url().MOBILE_URL_SEGMENT."/login");
				
		}	
	}

}

?>