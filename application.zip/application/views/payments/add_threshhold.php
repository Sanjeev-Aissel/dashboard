<?php
/**
 * File to 'add' Threshhold details
 *
 * @author: Ambarish
 * @Created on: 04-03-11
 */
?>
<style type="text/css">
	table{
		width: 80%;
		margin-left: 10%;
	}
	input[type="text"], select{
		margin-top: 0px;
		width:220px;
		padding: 0;
	}
	label.error{
		float: right;
		width: 130px;
	}
	.tableCaption{
		margin-bottom: 10px;
		background-color: #fff;
		border-bottom: 1px solid;
		font-weight: bold;
	}
</style>
<script type="text/javascript" language="javascript">
	function getThreshhold(){
		var kolId=$("#threshholdKOL").val();
		method		= '<?php echo base_url();?>payments/get_threshhold/'+kolId; 
		//$('.threshholdMsgBox').html("");
		
		$.post(method,function(returnData){
			if(returnData.threshholdLimit){
				$("#threshholdRate").val(returnData.threshholdLimit.threshhold_rate);
				$("#threshholdId").val(returnData.threshholdLimit.id);
				formAction="<?php echo base_url()?>payments/update_threshhold";
				$('#threshholdForm').attr('action', formAction);
			}
			else{
				$("#threshholdRate").val("");
				$("#threshholdId").val("");
				formAction="<?php echo base_url()?>payments/save_threshhold";
				$('#threshholdForm').attr('action', formAction);
				//$('.threshholdMsgBox').html("Enter Threshhold value");
			}
			
		},"json");
	}

	function saveThreshhold(){
		if(!$("#threshholdForm").validate().form()){
			return false;
		}
		id = $("#threshholdId").val();
		if(id == ''){
			formAction = '<?php echo base_url();?>payments/save_threshhold';
		}else{
			formAction = '<?php echo base_url();?>payments/update_threshhold';
		}	

		$('div.threshholdMsgBox').removeClass('success');
		$('div.threshholdMsgBox').addClass('notice');
		$('div.threshholdMsgBox').show();
		$('div.threshholdMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
		
		$.ajax({
			type: "post",
			dataType: "json",
			data: $("#threshholdForm").serialize(),
			url: formAction,
			success: function(returnData){
				if(returnData.saved == true){
					$("#threshholdId").val("");
					$("#threshholdKOL").val("");
					$("#threshholdRate").val("");
				}
			},
			complete: function(){
				$('div.threshholdMsgBox').fadeOut(1300);
				$(".threshholdMsgBox").hide();
				$('.formError').hide();
			}
			
		});
	};

	$(document).ready(function (){
		$("#threshholdForm").validate({
			debug:true,
			onkeyup:true
		});
		
		$('#threshholdRate').rules("add", {
			 required: true,
			 messages: {
			   required: "Enter Threshhold value"
			 }
		});
	});

//	// Validates for advanced search form for atleast one field to be enterd before trigger advanced search
//	function validateThreshholdForm(){
//		$('.threshholdMsgBox').html("");
//		var noOfBlanks=0;
//			if(document.threshholdForm.elements[2].value=="")
//				noOfBlanks++;
//			jAlert(noOfBlanks);
//		if(noOfBlanks == 0)
//			$('#threshholdForm').submit();
//		else{
//			$('.threshholdMsgBox').html("Enter Both fields");
//		}
//	}
</script>
<br />
<form action="<?php echo base_url()?>payments/<?php if($arrThreshhold['id']=='') echo 'save_threshhold'; else if($arrThreshhold['id']!='') echo 'update_threshhold';?>"  enctype="multipart/form-data" method="post" id="threshholdForm" name="threshholdForm" class="validateForm"> 
	<div class="msgBoxContainer"><div class="threshholdMsgBox"></div></div>
	<!-- Table for Threshhold -->
	<table class="analystForm" id="threshholdTbl">
	<caption class="tableCaption">Add new threshold rate</caption>
		<tr>
			<td>
				<p>
					<input type="hidden" name="id" id="threshholdId" value="<?php echo $arrThreshhold['id'];?>"></input>
					<label for="threshholdKOL">KOL:</label>
					<select name="kol_id" id="threshholdKOL" onchange="getThreshhold()">
						<option value="0">--- Select ---</option>
						<?php 
							foreach($arrKol as $key => $value){
							if($key == $arrThreshhold['kol_id'])
								echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
							else
								echo '<option value="'.$key.'">'.$value.'</option>';
							}
						?>
					</select>
				</p>
			</td>
		</tr>
		<tr>
			<td>
				<p>
					<label for="threshholdRate">Threshold Rate*:</label>
					<input type="text" name="threshhold_rate" value="<?php echo $arrThreshhold['threshhold_rate'];?>" id="threshholdRate" class="required"></input>
				</p>
			</td>
		</tr>
		<tr>
			<td colspan="2">	
				<div class="formButtons">
					<input type="button" value="Save" name="submit" id="savePayment" onclick="saveThreshhold();">
				</div>
			</td>
		</tr>
	</table>		
	<!-- End of Payment table -->
</form>