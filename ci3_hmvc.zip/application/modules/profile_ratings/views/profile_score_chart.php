<style>
.no_bottom_margin {
    margin-bottom: 0px;
}
</style>
<label>Profile Score: <?php echo round($arrAllParameter['Profile score']);?>%</label>
<table class="table">
	<tr>
 		<td width="35%" class="textAlignRight">Professional Experience</td>
 		<td width="50%">
 			<div class="progress no_bottom_margin">
  				<div class="progress-bar" role="progressbar" title="<?php echo $arrAllParameter['Professional Experience']['professionalScore']?>" style="width:<?php echo $arrAllParameter['Professional Experience']['professionalScore']?>;" aria-valuenow="50%" aria-valuemin="0" aria-valuemax="100">
  				</div>
			</div>
		</td>
		<td width="15%"><?php echo $arrAllParameter['Professional Experience']['professionalScore']." (".$arrAllParameter['Professional Experience']['totalProfessionalCount'].")"?></td>
	</tr>
	<tr>
 		<td width="35%" class="textAlignRight">Research</td>
 		<td width="50%">
 			<div class="progress no_bottom_margin">
  				<div class="progress-bar" role="progressbar" title="<?php echo $arrAllParameter['Research']['authPosScore']?>" style="width:<?php echo $arrAllParameter['Research']['authPosScore']?>;" aria-valuenow="50%" aria-valuemin="0" aria-valuemax="100">
  				</div>
			</div>
		</td>
		<td width="15%"><?php echo $arrAllParameter['Research']['authPosScore']." (".$arrAllParameter['Research']['authPosCount'].")"?></td>
	</tr>
	<tr>
 		<td width="35%" class="textAlignRight">Events Presence</td>
 		<td width="50%">
 			<div class="progress no_bottom_margin">
  				<div class="progress-bar" role="progressbar" title="<?php echo $arrAllParameter['Events Presence']['eventScore']?>" style="width:<?php echo $arrAllParameter['Events Presence']['eventScore']?>;" aria-valuenow="50%" aria-valuemin="0" aria-valuemax="100">
  				</div>
			</div>
		</td>
		<td width="15%"><?php echo $arrAllParameter['Events Presence']['eventScore']." (".$arrAllParameter['Events Presence']['totalEvents'].")"?></td>
	</tr>
</table>