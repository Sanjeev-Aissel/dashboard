<?php
/**
 * this is html file to hold the kol filter fields in linked-in style
 * 
 * @author Ramesh B
 * @since	2.1
 * @created: 15-01-11
 * @package application.views.search
 */
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter1(-1);}";
$autoSearchOptions2 = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
?>
<?php
$method= $this->uri->segment(2);
//echo $method;
	// prepare array of JS files to insert into queue
	//$queued_js_scripts = array('search/kol_filters_li_style');
	//echo $this->config->item('js_files_to_load').'here';
	// add the JS files into queue i.e Append to the existing queue
	//$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<style type="text/css">
	#searchFiltersElements ul{
		padding-left: 1px;
		margin-right: 0px;
		padding-left: 5px;
	}
	#searchFiltersElements ul li{
		font-size: 12px;
		list-style: none;
		color:#000000;
		font-style: normal;
		font-family: inherit;
	}
	
	#searchLeftBar li.category{
	/*	border-top:1px dotted #999999; */
	/*	margin-top:0.7em;*/
		overflow:visible;
		/*padding-top:0.8em;*/
		padding-top:0px;
		position:relative;
	/*	margin-right: 10px;*/
		clear: both;
	}
        .navLinkMyKols {
    width: 26px !important; 
        }
        .region{
                background: url('../images/ipad/region_active.svg');
    background-size: 22px auto;
    height: 22px;
    width: 22px;
        }
	#searchLeftBar li#categotyKols{
		border-top:0px dotted #999999;
		margin-top:0;
		padding-top:0;
		padding-top:0.7em;
	}
/*	
	#searchLeftBar label.facet-toggle {
		background:transparent url(../images/sprite_facetsearch_v7.png) no-repeat scroll 0 -61px;
		cursor:pointer;
		display:block;
		font-size:85%;
		height:11px;
		position:absolute;
		right:0;
		text-indent:-99999px;
		top:11px;
		width:11px;
	}
	
	#searchLeftBar label.facet-toggle:hover {
		background-position: 0px -76px;
	}
	
	#searchLeftBar label.collapsed{
		background-position:-20px -61px;
	}
*/	
	#searchFiltersElements ul li.allIndicator{
		font-weight: bold;
	}
	
	#searchFiltersElements ul li.allIndicator label{
		padding-left:4px;
		font-weight: bold;
	}
	
	#searchFiltersElements  input[type="checkbox"] {
		margin-left: -18px;
	}
	#categoriesContainer ul li label{
		margin-left: -6px;
		font-family:inherit;
		font-size:11px;
		font-style:normal;
		font-weight: normal;
	}
	#resetBttnContainer{
		text-align: right;
		vertical-align: middle;
		font-style: normal;
		color: #000099;
	}
	.kolSpecialty{
		margin-top: 4px;
	}
	.chzn-container-multi .chzn-choices{
		padding-left: 0px !important;
	}
	.chzn-container{
		font-size: 12px;
	}
	.chzn-container-single .chzn-single{
		border-radius: 2px;
		height: 18px;
		padding: 0 0 0 5px;		
	}
	.chzn-container-single .chzn-single span{
		margin-top: -3px !important
	}
	.chzn-container .chzn-results{
		padding-left: 0px !important;
		margin: 0px;
	}
	#profileType_chzn .chzn-single span{
		margin-top: 0px;
	}
	#savedFilterValue_chzn .chzn-drop .chzn-search input{
		border-radius: 2px;
	}
	.highlighted{
		background: #5A86B8 !important;
		color: white;
	}
	.chzn-container-single .chzn-search input{
		padding: 2px 20px 2px 4px;
	}
	.chzn-search li input[type="text"]{
		border-radius: 2px !important;
	}
	div.actionIcon{
		float: right;
	}
</style>
<script type="text/javascript">
	var options, a;
	// Autocomplet Options for the 'org type' field
		var orgTypeAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>organizations/get_org_types',
				<?php echo $autoSearchOptions;?>,
				onSelect : function(event, ui) {
					var selText = $(event).children('.orgTypes').html();
					var selId = $(event).children('.orgTypes').attr('name');
					selText=selText.replace(/\&amp;/g,'&');
					$('#orgType').val(selText);
					$('#orgTypeId').val(selId);
					if(event.length>20){
						if(event.substring(0,21)=="No results found for "){
							return false;
						}else{
							doSearchFilter1(-1);
						}
					}else{
						doSearchFilter1(-1);
					}
				}
			};
                        
                        var topicCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_topics',
				<?php echo $autoSearchOptions;?>,
				onSelect : function(event, ui) {
					var selText = $(event).children('.topicTypes').html();
					var selId = $(event).children('.topicTypes').attr('name');
					selText=selText.replace(/\&amp;/g,'&');
					$('#topicType').val(selText);
					$('#topicTypeId').val(selId);
					if(event.length>20){
						if(event.substring(0,21)=="No results found for "){
							return false;
						}else{
							doSearchFilter1(-1);
						}
					}else{
						doSearchFilter1(-1);
					}
				}
			};
                        var regionTypeAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_region',
				<?php echo $autoSearchOptions;?>,
				onSelect : function(event, ui) {
					var selText = $(event).children('.regionTypes').html();
					var selId = $(event).children('.regionTypes').attr('name');
					selText=selText.replace(/\&amp;/g,'&');
					$('#regionType').val(selText);
//                                        alert(selId);
					$('#regionTypeId').val(selId);
					if(event.length>20){
						if(event.substring(0,21)=="No results found for "){
							return false;
						}else{
							doSearchFilter1(-1);
						}
					}else{
						doSearchFilter1(-1);
					}
				}
			};
                        	var kolTitlesAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_kol_titles',
				<?php echo $autoSearchOptions;?>,
				onSelect : function(event, ui) {
					var selText = $(event).children('.kolTypes').html();
					var selId = $(event).children('.kolTypes').attr('name');
					selText=selText.replace(/\&amp;/g,'&');
					$('#kolType').val(selText);
					$('#kolTypeId').val(selId);
					if(event.length>20){
						if(event.substring(0,21)=="No results found for "){
							return false;
						}else{
							doSearchFilter1(-1);
						}
					}else{
						doSearchFilter1(-1);
					}
				}
			};
	// Autocomplet Options for the 'role' field 
		var SpecialtyNameAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>kols/get_specialty_names',
			<?php echo $autoSearchOptions;?>,
			onSelect : function(event, ui) {
				var selText = $(event).children('.specialties').html();
				var selId = $(event).children('.specialties').attr('name');
				selText=selText.replace(/\&amp;/g,'&');
				$('#specialty').val(selText);
				$('#specialtyId').val(selId);
				if(event.length>20){
					if(event.substring(0,21)=="No results found for "){
						return false;
					}else{
						doSearchFilter1(-1);
					}
				}else{
					doSearchFilter1(-1);
				}
			}
		};	
	
	// Autocomplet Options for the 'role' field 
		var educationNameAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>kols/get_institute_names',
			<?php echo $autoSearchOptions;?>,
			onSelect : function(event, ui) {
				var selText = $(event).children('.educations').html();
				var selId = $(event).children('.educations').attr('name');
				selText=selText.replace(/\&amp;/g,'&');
				$('#education').val(selText);
				$('#educationId').val(selId);
				if(event.length>20){
					if(event.substring(0,21)=="No results found for "){
						return false;
					}else{
						doSearchFilter1(-1);
					}
				}else{
					doSearchFilter1(-1);
				}
			}
		};	
	
		// Autocomplet Options for the 'Organizer' field 
	var organizationNameAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>kols/get_organization_names',
			<?php echo $autoSearchOptions;?>,
			onSelect : function(event, ui) {
				var selText = $(event).children('.organizations').html();
				var selId = $(event).children('.organizations').attr('name');
				selText=selText.replace(/\&amp;/g,'&');
				$('#organization').val(selText);
				$('#organizationId').val(selId);
				if(event.length>20){
					if(event.substring(0,21)=="No results found for "){
						return false;
					}else{
						doSearchFilter1(-1);
					}
				}else{
					doSearchFilter1(-1);
				}
			}
		};	
	
	// Autocomplet Options for the 'country' field
	var countryNameAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>country_helpers/get_country_names',
			<?php echo $autoSearchOptions;?>,
			onSelect : function(event, ui) {
				var selText = $(event).children('.countries').html();
				var selId = $(event).children('.countries').attr('name');
				selText=selText.replace(/\&amp;/g,'&');
				$('#country').val(selText);
				$('#countryId').val(selId);
				if(event.length>20){
					if(event.substring(0,21)=="No results found for "){
						return false;
					}else{
						doSearchFilter1(-1);
					}
				}else{
					doSearchFilter1(-1);
				}
			}
		};	
	
	// Autocomplet Options for the 'state' field
	var stateNameAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>country_helpers/get_state_names',
			<?php echo $autoSearchOptions;?>,
			onSelect : function(event, ui) {
				var stateId = $(event).children('.autocompleteStateId').html();
				var selText = $(event).children('.stateName').attr('name');
				selText=selText.replace(/\&amp;/g,'&');
				$('#state').val(selText);
				$('#stateIdForAutocomplete').val(stateId);
				if(selText.length>20){
					if(selText.substring(0,21)=="No results found for "){
						return false;
					}else{
						doSearchFilter1(-1);
					}
				}else{
					doSearchFilter1(-1);
				}
			}
		};
	// Autocomplet Options for the 'city' field
	var cityNameAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>country_helpers/get_city_names',
			<?php echo $autoSearchOptions;?>,
			onSelect : function(event, ui) {
				var stateId = $(event).children('.autocompleteCityId').html();
				var selText = $(event).children('.cityName').attr('name');
				selText=selText.replace(/\&amp;/g,'&');
				$('#city').val(selText);
				$('#cityIdForAutocomplete').val(stateId);
				if(selText.length>20){
					if(selText.substring(0,21)=="No results found for "){
						return false;
					}else{
						doSearchFilter1(-1);
					}
				}else{
					doSearchFilter1(-1);
				}
			}
		};
	
	// Autocomplet Options for the 'country' field
	var eventNameNameAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>kols/get_search_eventLookup_names',
			<?php echo $autoSearchOptions;?>,
			onSelect : function(event, ui) {
				var selText = $(event).children('.events').html();
				var selId = $(event).children('.events').attr('name');
				selText=selText.replace(/\&amp;/g,'&');
				$('#eventName').val(selText);
				$('#eventNameId').val(selId);
				if(event.length>20){
					if(event.substring(0,21)=="No results found for "){
						return false;
					}else{
						doSearchFilter1(-1);
					}
				}else{
					doSearchFilter1(-1);
				}
			}
		};

	// Autocomplet Options for the 'country' field
	var listNameAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>my_list_kols/get_list_names_with_category',
			<?php echo $autoSearchOptions;?>,
			onSelect : function(event, ui) {
				var selText = $(event).children('.lists').html();
				var selId = $(event).children('.lists').attr('name');
				selText=selText.replace(/\&amp;/g,'&');
				$('#listName').val(selText);
				$('#listNameId').val(selId);
				if(event.length>20){
					if(event.substring(0,21)=="No results found for "){
						return false;
					}else{
						doSearchFilter1(-1);
					}
				}else{
					doSearchFilter1(-1);
				}
			}
		};		
	
	var kolNameAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete',
			<?php echo $autoSearchOptions;?>,
			onSelect : function(event, ui) {
				var kolId = $(event).children('.id1').html();
				//var selText = $(event).children('.kolName').html();
				var selText = $(event).children('.kolName').attr('name');
				selText=selText.replace(/\&amp;/g,'&');				
					//resetFilters();				
				$('#kolName').val(selText);
				$('#kolIdForAutocomplete').val(kolId);
				if(selText.length>20){
					if(selText.substring(0,21)=="No results found for "){
						return false;
					}else{
						doSearchFilter1(-1);
					}
				}else{
					doSearchFilter1(-1);
				}
			}
		};

	var  b;
	
	var kolNameAutoCompleteOptions1 = {
			<?php 
			if(KOL_CONSENT){?>
			serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete/0/1',
			<?php }else{ ?>
			serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete',
			<?php }?>
			<?php echo $autoSearchOptions2;?>,
			onSelect : function(event, ui) {
				var kolId = $(event).children('.id1').html();
				//var selText = $(event).children('.kolName').html();
				var selText = $(event).children('.kolName').attr('name');
				selText=selText.replace(/\&amp;/g,'&');
				
				$('#influenceKolName').val(selText);
				$('#kolIdForAutocomplete').val(kolId);
				if(selText.length>20){
					if(selText.substring(0,21)=="No results found for "){
						return false;
					}else{
						loadKolInfluenceData(kolId);
					}
				}else{
					loadKolInfluenceData(kolId);
				}
			}
		};
	$(document).ready(function(){
		$("#savedFilterValue").chosen().change(function(){
			activeCustmFilters();
		});
               
//                doSearchFilter1(-1,this);
              
		$("#profileType").chosen({disable_search_threshold: 10}).change(function() {
//			if($("#savedFilterValue").val()){
//				activeCustmFilters();
//				return true;
//				}
				doSearchFilter1(-1,this);
			});
		$("#viewType").chosen({disable_search_threshold: 10}).change(function() {
			if($("#savedFilterValue").val()){
				activeCustmFilters();
				return true;
				}
			doSearchFilter1(-1,this);
		});
		//$("#savedFilterValue").chosen();
		initializeCustomToolTips();
	});
</script>
<?php 
	if($this->uri->segments[1]=="maps"){
		$selectedSpecialties= array();
		$selectedCountries	= array();
		$selectedStates		= array();
		//$selectedLists		= array();
		//Prepare array of filter fields, ehich will be used for querying
		$arrFilterFields=$this->session->userdata('arrMapFilterFields');
		if(isset($arrFilterFields['specialty'])){
			//$selectedSpecialties	=	$arrFilterFields['specialty'];
			$CI =& get_instance();
			$CI->load->model("Specialty");
			$selectedSpecialties	= $CI->Specialty->getSpecialtiesById($arrFilterFields['specialty']);
		}
		if(isset($arrFilterFields['country'])){
			//$selectedCountries		=	$arrFilterFields['country'];
			$selectedCountries		= $this->Country_helper->getCountryNameById($arrFilterFields['country']);
		}
		if(isset($arrFilterFields['state'])){
			$selectedStates			= $this->Country_helper->getStateNameById($arrFilterFields['state']);
		}
                
//		if(isset($arrFilterFields['list_id'])){
//			$selectedLists			= $arrFilterFields['list_id'];
//		}
		if(isset($arrFilterFields['profile_type'])){
			$profileType = $arrFilterFields['profile_type'];
		}
//		if(isset($arrFilterFields['viewType'])){
//			$profileType = $arrFilterFields['profile_type'];
//		}
		if(isset($arrFilterFields['savedFilterId'])){
			$savedFilterId = $arrFilterFields['savedFilterId'];
		}
//		pr($arrFilterFields);
	}
	if(isset($searchType)){
		if($searchType=='simple') 
			$formAction	= 'filter_search_kols'; 
		else 
			$formAction	= 'filter_adv_search_kols';
	}else{
		$formAction	= 'filter_search_kols';
	}
?>
<div id="searchFiltersElements">
	<form action="<?php echo base_url()?>kols/<?php echo $formAction;?>" name="searchFilterForm" method="post" id="searchFilterForm">
			<input type="hidden" name="search_type" id="searchType" value="<?php if(isset($searchType)) echo $searchType; ?>" class='advSearch'/>
			<input type="hidden" name="filterCategory" id="filterCategory" value="people" class='advSearch'/>
		<?php if(isset($keyword) && $keyword!=null ) {?>
			<input type="hidden" name="keyword" id="keyword" value="<?php if($keyword !=null && isset($keyword)) echo $keyword; else echo ""; ?>" class='advSearch'/>
		<?php }?>
		<?php if(isset($arrAdvSearchFields['keywords']) && $arrAdvSearchFields['keywords']!=''){?>
			<input type="hidden" name="keywords" id="keywords" value="<?php echo $arrAdvSearchFields['keywords']; ?>" class='advSearch'/>
		<?php }?>
		<?php if(isset($arrAdvSearchFields['first_name']) && $arrAdvSearchFields['first_name']!=''){?>
			<input type="hidden" name="first_name" id="firstName" value="<?php echo $arrAdvSearchFields['first_name']; ?>" class='advSearch'/>
		<?php }?>
		<?php if(isset($arrAdvSearchFields['middle_name']) && $arrAdvSearchFields['middle_name']!=''){?>
			<input type="hidden" name="middle_name" id="middleName" value="<?php echo $arrAdvSearchFields['middle_name']; ?>" class='advSearch'/>
		<?php }?>
		<?php if(isset($arrAdvSearchFields['last_name']) && $arrAdvSearchFields['last_name']!=''){?>
			<input type="hidden" name="last_name" id="lastName" value="<?php echo $arrAdvSearchFields['last_name']; ?>" class='advSearch'/>
		<?php }?>
		<?php if(isset($arrAdvSearchFields['pkeywords']) && $arrAdvSearchFields['pkeywords']!=''){?>
			<input type="hidden" name="pkeywords" id="p_keywords" value="<?php echo $arrAdvSearchFields['pkeywords']; ?>" class='advSearch'/>
		<?php } if(isset($arrAdvSearchFields['pauthpos']) && $arrAdvSearchFields['pauthpos']!=''){?>
			<input type="hidden" name="pauthpos" id="p_authpos" value="<?php echo $arrAdvSearchFields['pauthpos']; ?>" class='advSearch'/>
		<?php } if(isset($arrAdvSearchFields['pqtype']) && $arrAdvSearchFields['pqtype']!=''){?>
			<input type="hidden" name="pqtype" id="pq_type" value="<?php echo $arrAdvSearchFields['pqtype']; ?>" class='advSearch'/>
		<?php }?>
		<?php if(isset($arrAdvSearchFields['etopic']) && $arrAdvSearchFields['etopic']!=''){?>
			<input type="hidden" name="etopic" id="e_topic" value="<?php echo $arrAdvSearchFields['etopic']; ?>" class='advSearch'/>
		<?php }?>
		<?php if(isset($arrAdvSearchFields['erole']) && $arrAdvSearchFields['erole']!=''){?>
			<input type="hidden" name="erole" id="e_role" value="<?php echo $arrAdvSearchFields['erole']; ?>" class='advSearch'/>
		<?php }?>
		<?php if(isset($arrAdvSearchFields['eqtype']) && $arrAdvSearchFields['eqtype']!=''){?>
			<input type="hidden" name="eqtype" id="eq_type" value="<?php echo $arrAdvSearchFields['eqtype']; ?>" class='advSearch'/>
		<?php }?>
		<?php if(isset($arrAdvSearchFields['tkeywords']) && $arrAdvSearchFields['tkeywords']!=''){?>
			<input type="hidden" name="tkeywords" id="t_keywords" value="<?php echo $arrAdvSearchFields['tkeywords']; ?>" class='advSearch'/>
		<?php }?>
		<?php if(isset($arrAdvSearchFields['trole']) && $arrAdvSearchFields['trole']!=''){?>
			<input type="hidden" name="trole" id="t_role" value="<?php echo $arrAdvSearchFields['trole']; ?>" class='advSearch'/>
		<?php }?>
		<?php if(isset($arrAdvSearchFields['tqtype']) && $arrAdvSearchFields['tqtype']!=''){?>
			<input type="hidden" name="tqtype" id="tq_type" value="<?php echo $arrAdvSearchFields['tqtype']; ?>" class='advSearch'/>
		<?php }?>
                        <?php if(isset($arrAdvSearchFields['memebers']) && $arrAdvSearchFields['memebers']!=''){?>
			<input type="hidden" name="members" id="member_hidden" value="<?php echo $arrAdvSearchFields['memebers']; ?>" class='advSearch'/>
		<?php }?>
		
		<!--<div id="resetBttnContainer"><label id="resetBttn" onclick="resetFilters();">&nbsp</label>Reset</div>
		-->
		<ul id="categoriesContainer">
			<li class="">
				<div>
					<div class="assigned sprite_iconSet" id="assignedIcon"></div>
					<label class="categoryName" style="float:left;border-bottom:0px; margin-right: 27px;">Assigned</label>
					<div style="">
						<select name="view_type" id="viewType" class="chosenSelect" style="width:150px;">
							<option value="1" <?php if($viewType == MY_RECORDS)echo 'selected="selected"';?>>My Contacts</option>
							<option value="2" <?php if($viewType == ALL_RECORDS)echo 'selected="selected"';?>>All Contacts</option>
						</select>
					</div>
				</div>
			</li>
			<li id="customFilters" class="">
				<div>
					<div class="filterDropdownActive sprite_iconSet" id="filterDropdownIcon"></div>
					<label class="categoryName" style="float:left;border-bottom:0px; margin-right: 5px;">Saved Filters </label>
					<div style="">
						<select id="savedFilterValue" data-placeholder="Choose saved filters..." style="width:150px;" class="chosen-select">
							<option></option>
							<?php foreach($customFilters as $customFilter){ ?>
				 				<option value='<?php echo $customFilter['id'];?>' <?php if($savedFilterId == $customFilter['id']){ echo 'selected="selected"';}?> ><?php echo $customFilter['name'];?></option>
							<?php }?>
						</select>
						<div class="actionIcon editIcon tooltip-demo tooltop-left" onclick="getSavedFilters(); return false;">
							<a title="Settings" href="#" class="tooltipLink" rel="tooltip"></a>
						</div>
					</div>
				</div>
			</li>
			<li class="">
				<div>
					<div class="typeDropDownActive sprite_iconSet" id="typeDropDownIcon"></div>
					<label class="categoryName" style="float:left;border-bottom:0px; margin-right: 9px;">Profile Type </label>
					<div style="">
						<select name="select_type" id="profileType" class="chosenSelect" style="width:150px;">
							<option value="">All Profiles</option>
							<option value="Full Profile" <?php if($profileType == "Full Profile") echo "selected='selected'";?>>Full Profiles</option>
							<!-- <option value="Basic Plus" <?php if($profileType == "Basic Plus") echo "selected='selected'";?>>Basic+ Profiles</option> -->
							<option value="Basic" <?php if($profileType == "Basic") echo "selected='selected'";?>>Basic Profiles</option>
							<!-- <option value="Market Access" <?php if($profileType == "Market Access") echo "selected='selected'";?>>Market Access Profile</option>-->
							<option value="User Added" <?php if($profileType == "User Added") echo "selected='selected'";?>>User Added</option>
							<option value="Legacy" <?php if($profileType == "Legacy") echo "selected='selected'";?>>Legacy</option>
						</select>
					</div>
				</div>
			</li>
			<li id="categoryKolInfluence" class="category" style="display: none;">
<!--				<div class="kolName sprite_iconSet"></div><label class="categoryName">KOL Name</label>-->
				<div class="filterSearchIcon"></div><input type="text" name="influence_kol_name" id="influenceKolName" value="Enter KTL Name" class="autocompleteInputBox" onfocus="removeSuggession();" onblur="addSuggession();"/>
			</li>
			<li id="categotyKols" class="category">
				<!-- <div class="kolName sprite_iconSet"></div><label class="categoryName">KOL Name</label> -->
				<table class="clear">
				<?php 
					if(isset($selectedKol) && $selectedKol!=null){
						foreach($selectedKol as $kol){?>
							<tr class="kol<?php echo str_replace(' ','',$kol);?>">
								<td class="textAlignRight">
									<input type="checkbox" name="kols[]" class="kolElement hideCheckbox" id="kol<?php echo str_replace(' ','',$kol);?>" checked="checked" value="<?php echo $kol?>" onclick="doSearchFilter1(-1,this)" />&nbsp;<?php echo $kol;?>
								</td>
								<td class="histoGram"><div class="filterBar">
										<div class="progress" title="1(<?php echo round((1/1)*100);?>%)">
											<div class="bar" style="width: <?php if(isset($kol)) echo round((1/1)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
								<td>1</td>
							</tr>
				<?php } }?>
				</table>
				<div class="filterSearchIcon"></div><input type="text" name="kol_name" class="autocompleteInputBox kolElement" id="kolName" value="Enter KTL Name" title=""/><input type="hidden" id="kolIdForAutocomplete" value='' name="kol_id"></input>
			</li>
			 <?php if($method=="list_kols_client_view_filters" || $method=="reload_filters" || $method=="reload_influence_filters_optimized") { ?>
                        <li id="categotyRegions" class="category">
				<div class="region sprite_iconSet"></div><label class="categoryName">Global Region</label>
				<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<tr class="allRegionTypes">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_region_types" id="allRegionTypes" value="regionType" <?php if(isset($selectedRegionTypes) && $selectedRegionTypes!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Regions </td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allRegionCount."(".round(($allRegionCount/$allRegionCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allRegionCount)) echo round(($allRegionCount/$allRegionCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allRegionCount)) echo $allRegionCount; else echo 0;?></td>
					</tr>
					<?php $i=0;
					 	foreach($arrRegionCount as $regionCountDetails){ ?>
					 	<?php if($regionCountDetails['region_type_id']>0 && $regionCountDetails['GlobalRegion']!=''){?>
						 	<tr class="regionType<?php echo $regionCountDetails['region_type_id'];?>">
						 		<td class="textAlignRight">
						 			<input type="checkbox" name="regionType_ids[]" class="regionTypeElement hideCheckbox" id="regionType<?php echo $regionCountDetails['region_type_id'];?>" value="<?php echo $regionCountDetails['GlobalRegion'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedRegionTypes[$regionCountDetails['GlobalRegion']])){
											unset($selectedRegionTypes[$regionCountDetails['GlobalRegion']]);
											echo 'checked="checked"';
										}
									?>
									/><?php echo $regionCountDetails['GlobalRegion'];?>
						 		</td>
						 		<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $regionCountDetails['count']."(".round(($regionCountDetails['count']/$allRegionCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allRegionCount)) echo round(($regionCountDetails['count']/$allRegionCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
								<td><?php if(isset($regionCountDetails['count'])) echo $regionCountDetails['count']; else echo 0;?></td>
							</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php if(isset($selectedRegionTypes) && $selectedRegionTypes!=null){foreach($selectedRegionTypes as $typeId=>$regionName){?>
						<tr class="orgType<?php echo $typeId;?>">
					 		<td class="textAlignRight">
								<input type="checkbox" name="regionType_ids[]" class="regionTypeElement hideCheckbox" id="regionType<?php echo $typeId;?>" value="<?php echo $typeId;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $regionName;?>
							</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrRegionCount[$regionName]['count']."(".round(($arrRegionCount[$regionName]['count']/$allRegionCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allRegionCount)) echo round(($arrRegionCount[$regionName]['count']/$allRegionCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($typeId, $arrRegionCount)) echo $arrRegionCount[$typeId]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					</table>
						<div class="filterSearchIcon"></div><input type="text" name="region_type" class="autocompleteInputBox" id="regionType" value="Enter Global Region" title="" /><input type="hidden" name="region_type_id" id="regionTypeId" value="" />
				</div>
                          </li> <?php } ?>
			<li id="categoryCountry" class="category">
				<div class="refineByCountryImage sprite_iconSet"></div><label class="categoryName">Country</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
				<table class="clear">
					<!-- CheckBox representing All for this Category -->
					<tr class="allCountries">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_countries" id="allCountries"  onclick="doSearchFilter1(-1,this)" value="country" <?php if(isset($selectedCountries) && $selectedCountries!=null) echo ''; else echo "checked='checked'"?> />All Countries</td>
						<td class="histoGram">
							<div class="filterBar">
								<div class="progress" title="<?php echo $allCountryCount."(".round(($allCountryCount/$allCountryCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allCountryCount)) echo round(($allCountryCount/$allCountryCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allCountryCount)) echo $allCountryCount; else echo 0;?></td>
					</tr>
					<!-- Sart of Displaying checkbox for each value in thi category (currently limited to 4)
							and also make chekbox checked if it is already selected in the previous filtering	-->
					<?php $i=0;
					 	foreach($arrKolsByCountryCount as $countryCountDetails){ ?>
					 	<?php if($countryCountDetails['country']!=''){?>
					 	<tr class="country<?php echo $countryCountDetails['country_id'];?>">
					 		<td class="textAlignRight">
					 			<input type="checkbox" name="country_ids[]" class="countryElement hideCheckbox" id="country<?php echo $countryCountDetails['country_id'];?>" value="<?php echo $countryCountDetails['country_id'];?>" onclick="doSearchFilter1(-1,this)" 
								<?php
									if(isset($selectedCountries[$countryCountDetails['country_id']])){
										unset($selectedCountries[$countryCountDetails['country_id']]);
										echo 'checked="checked"';
									}
								?> 
								/><?php echo $countryCountDetails['country'];?>
					 		</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $countryCountDetails['count']."(".round(($countryCountDetails['count']/$allCountryCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allCountryCount)) echo round(($countryCountDetails['count']/$allCountryCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
					 		<td><?php echo $countryCountDetails['count'];?></td>
					 	</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php //for each remaining selected values add checkbox and make them checked
					 if(isset($selectedCountries) && $selectedCountries!=null){foreach($selectedCountries as $key=>$countryName){?>
						<tr class="country<?php echo str_replace(' ','',str_replace('&','and',$countryName));?>">
							<td class="textAlignRight">
								<input type="checkbox" name="country_ids[]" class="countryElement hideCheckbox" id="country<?php echo str_replace(' ','',str_replace('&','and',$countryName));?>" value="<?php echo $key;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $countryName;?>
							</td>
							<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrKolsByCountryCount[$key]['count']."(".round(($arrKolsByCountryCount[$key]['count']/$allCountryCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allCountryCount)) echo round(($arrKolsByCountryCount[$key]['count']/$allCountryCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($key, $arrKolsByCountryCount)) echo $arrKolsByCountryCount[$key]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					<!-- Input box to enter the category value that are no in the above list of checkbox's -->
					</table>
					<div class="filterSearchIcon"></div><input type="text" name="country" class="autocompleteInputBox" id="country" value="Enter Country" title=""/><input type="hidden" name="country_id" id="countryId" value="" />
				</div>
			</li>
                        <?php if($method=="list_kols_client_view_filters" || $method=="reload_filters") { ?>
                        <li id="categotyKolTitle" class="category">
				<div class="navLinkMyKols sprite_iconSet activeIcon "></div><label class="categoryName">Position</label>
				<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
                                   
					<tr class="allKolTypes">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_kol_types" id="allKolTypes" value="kolType" <?php if(isset($selectedKolTypes) && $selectedKolTypes!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Positions</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allkolTypeCount."(".round(($allkolTypeCount/$allkolTypeCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allkolTypeCount)) echo round(($allkolTypeCount/$allkolTypeCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allkolTypeCount)) echo $allkolTypeCount; else echo 0;?></td>
                                                 
					</tr>
					<?php $i=0;
					//pr($arrKolByTypeCount);
					 	foreach($arrKolByTypeCount as $kolTypeCountDetails){?>
					 	<?php if($kolTypeCountDetails['kol_type_id']!='' && $kolTypeCountDetails['title']!='' && $kolTypeCountDetails['kol_type_id']>0){  ?>					 	
						 	<tr class="kolType<?php echo $kolTypeCountDetails['kol_type_id'];?>">
                                                         
						 		<td class="textAlignRight">
						 			<input type="checkbox" name="kolType_ids[]" class="kolTypeElement hideCheckbox" id="kolType<?php echo $kolTypeCountDetails['title'];?>" value="<?php echo $kolTypeCountDetails['title'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedKolTypes[$kolTypeCountDetails['title']])){
                                                                                   
											unset($selectedKolTypes[$kolTypeCountDetails['title']]);
											echo 'checked="checked"';
										}
									?>
									/><?php								
										echo $kolTypeCountDetails['title'];									
									?>
						 		</td>
						 		<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $kolTypeCountDetails['count']."(".round(($kolTypeCountDetails['count']/$allkolTypeCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allkolTypeCount)) echo round(($kolTypeCountDetails['count']/$allkolTypeCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
								<td><?php if(isset($kolTypeCountDetails['count'])) echo $kolTypeCountDetails['count']; else echo 0;?></td>
							</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php if(isset($selectedKolTypes) && $selectedKolTypes!=null){
                                           
                                            foreach($selectedKolTypes as $typeId=>$kolTypeName){?>
						<tr class="kolType<?php echo $typeId;?>">
                                                   
					 		<td class="textAlignRight">
								<input type="checkbox" name="kolType_ids[]" class="kolTypeElement hideCheckbox" id="kolType<?php echo $typeId;?>" value="<?php echo $typeId;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $kolTypeName;?>
							</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrKolByTypeCount[$kolTypeName]['count']."(".round(($arrKolByTypeCount[$kolTypeName]['count']/$allkolTypeCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allkolTypeCount)) echo round(($arrKolByTypeCount[$kolTypeName]['count']/$allkolTypeCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($typeId, $arrKolByTypeCount)) echo $arrKolByTypeCount[$typeId]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					</table>
						<div class="filterSearchIcon"></div><input type="text" name="kol_type" class="autocompleteInputBox" id="kolType" value="Enter Position" title="" /><input type="hidden" name="kol_type_id" id="kolTypeId" value="" />
				</div>
			</li> <?php } ?>
			<?php if(KOL_CONSENT && ($method=="list_kols_client_view_filters" || $method=="reload_filters")) { ?>
             <li id="categotyOptInOut" class="category">
				<div class="sprite_iconSet"></div><label class="categoryName">Opt-in/Opt-out</label>
				<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<tr class="allOptInOut">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_opt_in_out" id="allOptInOut" value="opt_inout" <?php if(isset($selectedOptInOut) && $selectedOptInOut!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allOptInOutCount."(".round(($allOptInOutCount/$allOptInOutCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allOptInOutCount)) echo round(($allOptInOutCount/$allOptInOutCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allOptInOutCount)) echo $allOptInOutCount; else echo 0;?></td>
					</tr>
					<?php $i=0;
					foreach($arrOptInOutCount as $optInCountDetails){ ?>
					 	<?php if($optInCountDetails['opt_in_out_id']>0 && $optInCountDetails['opt_name']!=''){?>
						 	<tr class="optType<?php echo $optInCountDetails['opt_in_out_id'];?>">
						 		<td class="textAlignRight">
						 			<input type="checkbox" name="optInOut_ids[]" class="optInOutElement hideCheckbox" id="optInOut<?php echo $optInCountDetails['opt_in_out_id'];?>" value="<?php echo $optInCountDetails['opt_in_out_id'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
									if(isset($selectedOptInOut[$optInCountDetails['opt_in_out_id']])){
									    unset($selectedOptInOut[$optInCountDetails['opt_in_out_id']]);
											echo 'checked="checked"';
										}
									?>
									/><?php echo $optInCountDetails['opt_name'];?>
						 		</td>
						 		<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $optInCountDetails['count']."(".round(($optInCountDetails['count']/$allOptInOutCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allOptInOutCount)) echo round(($optInCountDetails['count']/$allOptInOutCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
								<td><?php if(isset($optInCountDetails['count'])) echo $optInCountDetails['count']; else echo 0;?></td>
							</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php if(isset($selectedOptInOut) && $selectedOptInOut!=null){
					    foreach($selectedOptInOut as $typeId=>$optName){?>
						<tr class="optType<?php echo $typeId;?>">
					 		<td class="textAlignRight">
								<input type="checkbox" name="optInOut_ids[]" class="optInOutElement hideCheckbox" id="optInOut<?php echo $typeId;?>" value="<?php echo $typeId;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $optName;?>
							</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrOptInOutCount[$typeId]['count']."(".round(($arrOptInOutCount[$typeId]['count']/$allOptInOutCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allOptInOutCount)) echo round(($arrOptInOutCount[$typeId]['count']/$allOptInOutCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($typeId, $arrOptInOutCount)) echo $arrOptInOutCount[$typeId]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					</table>
						<!--  <div class="filterSearchIcon"></div><input type="text" name="region_type" class="autocompleteInputBox" id="regionType" value="Enter Global Region" title="" /><input type="hidden" name="region_type_id" id="regionTypeId" value="" />-->
				</div>
            </li> <?php } ?>
			<li id="categotySpecialty" class="category">
				<div class="refineBySecialtyImage sprite_iconSet"></div><label class="categoryName">Specialty</label>
				<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
				<div>
				<table class="clear">
					<tr class="allSpecialties">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_specialties" id="allSpecialties" value="specialty" <?php if(isset($selectedSpecialties) && $selectedSpecialties!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Specialties</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allSpecialtyCount."(".round(($allSpecialtyCount/$allSpecialtyCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allSpecialtyCount)) echo round(($allSpecialtyCount/$allSpecialtyCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allSpecialtyCount)) echo $allSpecialtyCount; else echo 0;?></td>
					</tr>

					<?php $i=0;//pr($selectedSpecialties);pr($arrKolsBySpecialtyCount);
					 	foreach($arrKolsBySpecialtyCount as $specialtyCountDetails){ ?>
					 	<?php if($specialtyCountDetails['specialty']!='' && $specialtyCountDetails['specialty']!= 0){?>

					 		<tr class="specialty<?php echo $specialtyCountDetails['specialty'];?>">
					 			<td class="textAlignRight">
					 				<input type="checkbox" name="specialty_ids[]" class="specialtyElement hideCheckbox" id="specialty<?php echo $specialtyCountDetails['specialty'];?>" value="<?php echo $specialtyCountDetails['specialty'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedSpecialties[$specialtyCountDetails['specialty']])){
											unset($selectedSpecialties[$specialtyCountDetails['specialty']]);
											echo 'checked="checked"';
										}
									?> 
									/><?php echo $specialtyCountDetails['specs'];?>
					 			</td>
					 			<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $specialtyCountDetails['count']."(".round(($specialtyCountDetails['count']/$allSpecialtyCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allSpecialtyCount)) echo round(($specialtyCountDetails['count']/$allSpecialtyCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
					 			<td><?php echo $specialtyCountDetails['count'];?></td>
					 		</tr>

					<?php $i++; if($i>3) break; }}?>
					
					<?php if(isset($selectedSpecialties) && $selectedSpecialties!=null){foreach($selectedSpecialties as $id=>$specialtyName){?>
						<tr class="specialty<?php echo $id;?>">
							<td class="textAlignRight">
								<input type="checkbox" name="specialty_ids[]" class="specialtyElement hideCheckbox" id="specialty<?php echo $id;?>" value="<?php echo $id;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $specialtyName;?>
							</td>
							<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrKolsBySpecialtyCount[$id]['count']."(".round(($arrKolsBySpecialtyCount[$id]['count']/$allSpecialtyCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allSpecialtyCount)) echo round(($arrKolsBySpecialtyCount[$id]['count']/$allSpecialtyCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($id, $arrKolsBySpecialtyCount)) echo $arrKolsBySpecialtyCount[$id]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					</table>
					<div class="filterSearchIcon"></div>
					<input type="text" name="specialty" class="autocompleteInputBox" id="specialty" value="Enter Specialty" title=""/><input type="hidden" name="specialty_id" id="specialtyId" value="" />
				</div>
			</li>
                         
                         <?php  if($method=="adv_search" || $method=="reload_adv_filters") {?>
                        <li id="categotyTopic" class="category">
				<div class="refinedByLinkEvents sprite_iconSet"></div><label class="categoryName">Topic</label>
				<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<tr class="allTopicTypes">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_topic_types" id="allTopicTypes" value="topicType" <?php if(isset($selectedTopicTypes) && $selectedTopicTypes!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Topics </td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allTopicCount."(".round(($allTopicCount/$allTopicCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allTopicCount)) echo round(($allTopicCount/$allTopicCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allTopicCount)) echo $allTopicCount; else echo 0;?></td>
					</tr>
					<?php $i=0;
					 	foreach($arrTopicCount as $topicCountDetails){ ?>
					 	<?php if($topicCountDetails['topic_type_id']>0){?>
						 	<tr class="regionType<?php echo $topicCountDetails['topic_type_id'];?>">
						 		<td class="textAlignRight">
						 			<input type="checkbox" name="topicType_ids[]" class="topicTypeElement hideCheckbox" id="topicType<?php echo $topicCountDetails['topic_type_id'];?>" value="<?php echo $topicCountDetails['name'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedTopicTypes[$topicCountDetails['name']])){
											unset($selectedTopicTypes[$topicCountDetails['name']]);
											echo 'checked="checked"';
										}
									?>
									/><?php echo $topicCountDetails['name'];?>
						 		</td>
						 		<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $topicCountDetails['count']."(".round(($topicCountDetails['count']/$allTopicCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allTopicCount)) echo round(($topicCountDetails['count']/$allTopicCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
								<td><?php if(isset($topicCountDetails['count'])) echo $topicCountDetails['count']; else echo 0;?></td>
							</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php if(isset($selectedTopicTypes) && $selectedTopicTypes!=null){foreach($selectedTopicTypes as $typeId=>$topicName){?>
						<tr class="topicType<?php echo $typeId;?>">
					 		<td class="textAlignRight">
								<input type="checkbox" name="topicType_ids[]" class="topicTypeElement hideCheckbox" id="topicType<?php echo $typeId;?>" value="<?php echo $typeId;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $topicName;?>
							</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrTopicCount[$topicName]['count']."(".round(($arrTopicCount[$topicName]['count']/$allTopicCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allTopicCount)) echo round(($arrTopicCount[$topicName]['count']/$allTopicCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($typeId, $arrTopicCount)) echo $arrTopicCount[$typeId]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					</table>
						<div class="filterSearchIcon"></div><input type="text" name="topic_type" class="autocompleteInputBox" id="topicType" value="Enter Topic Name" title="" /><input type="hidden" name="topic_type_id" id="topicTypeId" value="" />
				</div>
                        </li> <?php } ?>
                          <?php if($method=="list_kols_client_view_filters" || $method=="reload_filters") { ?>
                        <li id="categotyOrgType" class="category"> <?php  ?>
				<div class="navLinkOrganizations sprite_iconSet"></div><label class="categoryName">Org Type</label>
				<label class="facet-toggle expanded" onclick="toggleCategory(true,this);"></label>
				<div>
				<table>
					<tr class="allOrgTypes">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_org_types" id="allOrgTypes" value="orgType" <?php if(isset($selectedOrgTypes) && $selectedOrgTypes!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Org Types</td>
						<td class="histoGram"><div class="filterBar">
								<div class="progress" title="<?php echo $allOrgTypeCount."(".round(($allOrgTypeCount/$allOrgTypeCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allOrgTypeCount)) echo round(($allOrgTypeCount/$allOrgTypeCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allOrgTypeCount)) echo $allOrgTypeCount; else echo 0;?></td>
					</tr>
					<?php $i=0;
					 	foreach($arrOrgByTypeCount as $orgTypeCountDetails){ ?>
					 	<?php if($orgTypeCountDetails['org_type_id']>0){ ?>
						 	<tr class="orgType<?php echo $orgTypeCountDetails['org_type_id'];?>">
						 		<td class="textAlignRight">
						 			<input type="checkbox" name="orgType_ids[]" class="orgTypeElement hideCheckbox" id="orgType<?php echo $orgTypeCountDetails['org_type_id'];?>" value="<?php echo $orgTypeCountDetails['org_type_id'];?>" onclick="doSearchFilter1(-1,this)" 
									<?php
										if(isset($selectedOrgTypes[$orgTypeCountDetails['org_type_id']])){
											unset($selectedOrgTypes[$orgTypeCountDetails['org_type_id']]);
											echo 'checked="checked"';
										}
									?>
									/><?php echo $orgTypeCountDetails['type'];?>
						 		</td>
						 		<td class="histoGram">
						 			<div class="filterBar">
										<div class="progress" title="<?php echo $orgTypeCountDetails['count']."(".round(($orgTypeCountDetails['count']/$allOrgTypeCount)*100)."%)";?>">
											<div class="bar" style="width: <?php if(isset($allOrgTypeCount)) echo round(($orgTypeCountDetails['count']/$allOrgTypeCount)*100); else echo 0;?>%;"></div>
										</div>
									</div>
								</td>
								<td><?php if(isset($orgTypeCountDetails['count'])) echo $orgTypeCountDetails['count']; else echo 0;?></td>
							</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php if(isset($selectedOrgTypes) && $selectedOrgTypes!=null){foreach($selectedOrgTypes as $typeId=>$orgTypeName){?>
						<tr class="orgType<?php echo $typeId;?>">
					 		<td class="textAlignRight">
								<input type="checkbox" name="orgType_ids[]" class="orgTypeElement hideCheckbox" id="orgType<?php echo $typeId;?>" value="<?php echo $typeId;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $orgTypeName;?>
							</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrOrgByTypeCount[$orgTypeName]['count']."(".round(($arrOrgByTypeCount[$orgTypeName]['count']/$allCountryCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allCountryCount)) echo round(($arrOrgByTypeCount[$orgTypeName]['count']/$allCountryCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($typeId, $arrOrgByTypeCount)) echo $arrOrgByTypeCount[$typeId]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					</table>
						<div class="filterSearchIcon"></div><input type="text" name="org_type" class="autocompleteInputBox" id="orgType" value="Enter Org Type" title="" /><input type="hidden" name="org_type_id" id="orgTypeId" value="" />
				</div>
                          </li><?php } ?>
			<li id="categoryState" class="category">
				<div class="refineByRegionImage sprite_iconSet"></div><label class="categoryName">State</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
				<table class="clear">
					<!-- CheckBox representing All for this Category -->
					<tr class="allStates">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_states" id="allStates"  onclick="doSearchFilter1(-1,this)" value="state" <?php if(isset($selectedStates) && $selectedStates!=null) echo ''; else echo "checked='checked'"?> />All States</td>
						<td class="histoGram">
							<div class="filterBar">
								<div class="progress" title="<?php echo $allStateCount."(".round(($allStateCount/$allStateCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allStateCount)) echo round(($allStateCount/$allStateCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allStateCount)) echo $allStateCount; else echo 0;?></td>
					</tr>
					<!-- Sart of Displaying checkbox for each value in thi category (currently limited to 4)
							and also make chekbox checked if it is already selected in the previous filtering	-->
					<?php $i=0;
					 	foreach($arrKolsByStateCount as $key=>$arrStateCountDetails){ ?>
					 	<?php if($arrStateCountDetails['state_id']>0){?>
					 	<tr class="state<?php echo $arrStateCountDetails['state_id'];?>">
					 		<td class="textAlignRight">
					 			<input type="checkbox" name="state_ids[]" class="stateElement hideCheckbox" id="state<?php echo $arrStateCountDetails['state_id'];?>" value="<?php echo $arrStateCountDetails['state_id'];?>" onclick="doSearchFilter1(-1,this)" 
								<?php
									if(isset($selectedStates[$arrStateCountDetails['state_id']])){
										unset($selectedStates[$arrStateCountDetails['state_id']]);
										echo 'checked="checked"';
									}
								?> 
								/><?php echo $arrStateCountDetails['state'];?>
					 		</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrStateCountDetails['count']."(".round(($arrStateCountDetails['count']/$allStateCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allStateCount)) echo round(($arrStateCountDetails['count']/$allStateCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
					 		<td><?php echo $arrStateCountDetails['count'];?></td>
					 	</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php //for each remaining selected values add checkbox and make them checked
					 if(isset($selectedStates) && $selectedStates!=null){foreach($selectedStates as $key=>$stateName){?>
						<tr class="state<?php echo str_replace(' ','',str_replace('&','and',$stateName));?>">
							<td class="textAlignRight">
								<input type="checkbox" name="state_ids[]" class="stateElement hideCheckbox" id="state<?php echo str_replace(' ','',str_replace('&','and',$stateName));?>" value="<?php echo $key;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $stateName;//$key;?>
							</td>
							<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrKolsByStateCount[$key]['count']."(".round(($arrKolsByStateCount[$key]['count']/$allStateCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allStateCount)) echo round(($arrKolsByStateCount[$key]['count']/$allStateCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($key, $arrKolsByStateCount)) echo $arrKolsByStateCount[$key]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					<!-- Input box to enter the category value that are no in the above list of checkbox's -->
					</table>
					<div class="filterSearchIcon"></div><input type="text" name="state" class="autocompleteInputBox" id="state" value="Enter State" title=""/><input type="hidden" id="stateIdForAutocomplete" value='' name="state_id">
				</div>
			</li>
			
			<?php if($this->uri->segments[1]!="maps"){?>
			
<!--			<li id="categoryCity" class="category">
				<div class="refineByRegionImage sprite_iconSet"></div><label class="categoryName">City</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
				<table class="clear">
					 CheckBox representing All for this Category 
					<tr class="allCities">
						<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_cities" id="allCities"  onclick="doSearchFilter1(-1,this)" value="City" <?php if(isset($selectedCities) && $selectedCities!=null) echo ''; else echo "checked='checked'"?> />All Cities</td>
						<td class="histoGram">
							<div class="filterBar">
								<div class="progress" title="<?php echo $allCityCount."(".round(($allCityCount/$allCityCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allCityCount)) echo round(($allCityCount/$allCityCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
						</td>
						<td><?php if(isset($allCityCount)) echo $allCityCount; else echo 0;?></td>
					</tr>
					 Sart of Displaying checkbox for each value in thi category (currently limited to 4)
							and also make chekbox checked if it is already selected in the previous filtering	
					<?php $i=0;
					 	foreach($arrKolsByCityCount as $key=>$arrCityCountDetails){ ?>
					 	<?php if($arrCityCountDetails['city_id']>0){?>
					 	<tr class="city<?php echo $arrCityCountDetails['city_id'];?>">
					 		<td class="textAlignRight">
					 			<input type="checkbox" name="city_ids[]" class="cityElement hideCheckbox" id="city<?php echo $arrCityCountDetails['city_id'];?>" value="<?php echo $arrCityCountDetails['city_id'];?>" onclick="doSearchFilter1(-1,this)" 
								<?php
									if(isset($selectedCities[$arrCityCountDetails['city_id']])){
										unset($selectedCities[$arrCityCountDetails['city_id']]);
										echo 'checked="checked"';
									}
								?> 
								/>&nbsp;<?php echo $arrCityCountDetails['city'];?>
					 		</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrCityCountDetails['count']."(".round(($arrCityCountDetails['count']/$allCityCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allCityCount)) echo round(($arrCityCountDetails['count']/$allCityCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
					 		<td><?php echo $arrCityCountDetails['count'];?></td>
					 	</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php //for each remaining selected values add checkbox and make them checked
					 if(isset($selectedCities) && $selectedCities!=null){foreach($selectedCities as $key=>$cityName){?>
						<tr class="city<?php echo str_replace(' ','',str_replace('&','and',$cityName));?>">
							<td class="textAlignRight">
								<input type="checkbox" name="city_ids[]" class="cityElement hideCheckbox" id="city<?php echo str_replace(' ','',str_replace('&','and',$cityName));?>" value="<?php echo $key;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $cityName;//$key;?>
							</td>
							<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrKolsByCityCount[$key]['count']."(".round(($arrKolsByCityCount[$key]['count']/$allCityCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allCityCount)) echo round(($arrKolsByCityCount[$key]['count']/$allCityCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($key, $arrKolsByCityCount)) echo $arrKolsByCityCount[$key]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					 Input box to enter the category value that are no in the above list of checkbox's 
					</table>
					<div class="filterSearchIcon"></div><input type="text" name="city" class="autocompleteInputBox" id="city" value="Enter City" title=""/><input type="hidden" id="cityIdForAutocomplete" value='' name="city_id">
				</div>
			</li>-->
			
			<?php }?>			
			
			<li id="categotyList" class="category">
				<div class="refinedByCreateListIcon sprite_iconSet"></div><label class="categoryName">List</label>
				<label class="facet-toggle expanded"  onclick="toggleCategory(true,this);"></label>
				<div>
				<table class="clear">
					<tr class="allLists">
				 		<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_events" id="allLists" value="list" <?php if(isset($selectedLists) && $selectedLists!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Lists</td>
				 		<td class="histoGram">
				 			<div class="filterBar">
								<div class="progress" title="<?php echo $allListCount."(".round(($allListCount/$allListCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allListCount)) echo round(($allListCount/$allListCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
				 		</td>
				 		<td><?php if(isset($allListCount)) echo $allListCount; else echo 0;?></td>
				 	</tr>
					<?php $i=0;
					 	foreach($arrKolsByListCount as $listCountDetails){ ?>
					 	<?php if($listCountDetails['list_name']!=''){?>
					 	<tr class="list<?php echo $listCountDetails['list_name_id'];?>">
					 		<td class="textAlignRight">
					 			<input type="checkbox" name="list_ids[]" class="listElement hideCheckbox" id="list<?php echo $listCountDetails['list_name_id'];?>" value="<?php echo $listCountDetails['list_name_id'];?>" onclick="doSearchFilter1(-1,this)"
					 				<?php 
					 				if(isset($selectedLists[$listCountDetails['list_name_id']])){
										unset($selectedLists[$listCountDetails['list_name_id']]);
										echo 'checked="checked"';
									}
									?> 
								/><?php echo $listCountDetails['list_name'];?>
					 		</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $listCountDetails['count']."(".round(($listCountDetails['count']/$allListCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allListCount)) echo round(($listCountDetails['count']/$allListCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
					 		</td>
					 		<td><?php echo $listCountDetails['count'];?></td>
					 	</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php if(isset($selectedLists) && $selectedLists!=null){foreach($selectedLists as $key=>$listName){?>
						<tr class="list<?php echo str_replace(' ','',str_replace('&','and',$listName));?>">
					 		<td class="textAlignRight">
					 			<input type="checkbox" name="list_ids[]" class="listElement hideCheckbox" id="list<?php echo str_replace(' ','',str_replace('&','and',$listName));?>" value="<?php echo $key;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $listName;?>
					 		</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrKolsByListCount[$key]['count']."(".round(($arrKolsByListCount[$key]['count']/$allListCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allListCount)) echo round(($arrKolsByListCount[$key]['count']/$allListCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($key, $arrKolsByListCount)) echo $arrKolsByListCount[$key]['count']; else echo 0;?></td>
					 	</tr>
					<?php }}?>
					</table>
					<div class="filterSearchIcon"></div><input type="text" name="list_name" class="autocompleteInputBox" id="listName" value="Enter List" title=""/><input type="hidden" name="list_name_id" id="listNameId" value="" />
				</div>
			</li>
			<?php
				if((!isset($mapSection)) || $mapSection!='geoMap'){?>
			<li id="categotyOrganization" class="category">
				<div class="navLinkOrganizations sprite_iconSet"></div><label class="categoryName">Organization</label>
				<label class="facet-toggle collapsed"  onclick="toggleCategory(true,this);"></label>
				<div style="display:none;">
				<table class="clear">
					<tr class="allOrgs">
				 		<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_orgs" id="allOrgs" value="organization" <?php if(isset($selectedOrgs) && $selectedOrgs!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Organizations</td>
				 		<td class="histoGram">
				 			<div class="filterBar">
								<div class="progress" title="<?php echo $allOrgCount."(".round(($allOrgCount/$allOrgCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allOrgCount)) echo round(($allOrgCount/$allOrgCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
				 		</td>
				 		<td><?php if(isset($allOrgCount)) echo $allOrgCount; else echo 0;?></td>
				 	</tr>
					<?php $i=0;
					 	foreach($arrKolsByOrgCount as $orgCountDetails){ ?>
					 	<?php
					 		if($orgCountDetails['name']!=''){?>
					 	<tr class="org<?php echo $orgCountDetails['org_id'];?>">
					 		<td class="textAlignRight">
					 			<input type="checkbox" name="org_ids[]" class="orgElement hideCheckbox" id="org<?php echo $orgCountDetails['org_id'];?>" value="<?php echo $orgCountDetails['org_id'];?>" onclick="doSearchFilter1(-1,this)" 
								<?php if(isset($selectedOrgs) && sizeof($selectedOrgs)>0 && $selectedOrgs!=null){
										if((in_array($orgCountDetails['name'], $selectedOrgs))||(in_array($orgCountDetails['org_id'], $selectedOrgs))) {
											if(isset($selectedOrgs[$orgCountDetails['org_id']])){
												unset($selectedOrgs[$orgCountDetails['org_id']]);
											}
											?>
											checked="checked"
									<?php 
										$key = array_search($orgCountDetails['name'], $selectedOrgs);
										if(array_key_exists($key, $selectedOrgs))
											unset($selectedOrgs[$key]);
										//$selectedOrgs=array_values($selectedOrgs);
							 			}
							 		}?>
								/><?php echo $orgCountDetails['name'];?>
					 		</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $orgCountDetails['count']."(".round(($orgCountDetails['count']/$allOrgCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allOrgCount)) echo round(($orgCountDetails['count']/$allOrgCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
					 		</td>
					 		<td><?php echo $orgCountDetails['count'];?></td>
					 	</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php if(isset($selectedOrgs) && $selectedOrgs!=null){foreach($selectedOrgs as $orgId => $orgName){?>
						<tr class="org<?php echo $orgId;?>">
					 		<td class="textAlignRight">
								<input type="checkbox" name="org_ids[]" class="orgElement hideCheckbox" id="org<?php echo $orgId;?>" value="<?php echo $orgId;?>" onclick="doSearchFilter1(-1,this)" checked="checked" />&nbsp; <?php echo $orgName;?>
							</td>
							<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrKolsByOrgCount[$orgId]['count']."(".round(($arrKolsByOrgCount[$orgId]['count']/$allOrgCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allOrgCount)) echo round(($arrKolsByOrgCount[$orgId]['count']/$allOrgCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($orgId, $arrKolsByOrgCount)) echo $arrKolsByOrgCount[$orgId]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					</table>
					<div class="filterSearchIcon"></div><input type="text" name="organization" class="autocompleteInputBox" id="organization" value="Enter Organization" title=""/><input type="hidden" name="organization_id" id="organizationId" value="" />
					</div>
			</li>
			<!--organization type starts here-->
                             
                        
                        
                        
                        <!-- global regions begins here -->
                        
                       
			<li id="categotyEducation" class="category">
				<div class="educationIcon sprite_iconSet"></div><label class="categoryName">Education</label>
				<label class="facet-toggle collapsed" onclick="toggleCategory(true,this);"></label>
				<div style="display:none;">
				<table class="clear">
					<tr class="allEdus">
				 		<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_edus" id="allEdus" value="education" <?php if(isset($selectedEdus) && $selectedEdus!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Educations</td>
				 		<td class="histoGram">
				 			<div class="filterBar">
								<div class="progress" title="<?php echo $allEduCount."(".round(($allEduCount/$allEduCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allEduCount)) echo round(($allEduCount/$allEduCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
				 		</td>
				 		<td><?php if(isset($allEduCount)) echo $allEduCount; else echo 0;?></td>
				 	</tr>
					<?php $i=0;//pr($selectedEdus);pr($arrKolsByEduCount);
					 	foreach($arrKolsByEduCount as $eduCountDetails){ ?>
					 	<?php if($eduCountDetails['institute_id']!=''){?>
					 	<tr class="edu<?php echo $eduCountDetails['institute_id'];?>">
					 		<td class="textAlignRight">
					 			<input type="checkbox" name="edu_ids[]" class="eduElement hideCheckbox" id="edu<?php echo $eduCountDetails['institute_id'];?>" value="<?php echo $eduCountDetails['institute_id'];?>" onclick="doSearchFilter1(-1,this)" 
								<?php if(isset($selectedEdus) && sizeof($selectedEdus)>0 && $selectedEdus!=null){if(in_array($eduCountDetails['institute_name'], $selectedEdus)) {?>
									checked="checked"
								<?php $key = array_search($eduCountDetails['institute_name'], $selectedEdus);if(array_key_exists($key, $selectedEdus))unset($selectedEdus[$key]);$selectedEdus=array_values($selectedEdus);}}?>
								/><?php echo $eduCountDetails['institute_name'];?>
					 		</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $eduCountDetails['count']."(".round(($eduCountDetails['count']/$allEduCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allEduCount)) echo round(($eduCountDetails['count']/$allEduCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
					 		</td>
					 		<td><?php echo $eduCountDetails['count'];?></td>
					 	</tr>
					<?php $i++; if($i>3) break; }}?>
					<?php if(isset($selectedEdus) && $selectedEdus!=null){foreach($selectedEdus as $key=>$eduName){?>
						<tr class="edu<?php echo str_replace(' ','',str_replace('&','and',$eduName));?>">
					 		<td class="textAlignRight">
								<input type="checkbox" name="edu_ids[]" class="eduElement hideCheckbox" id="edu<?php echo str_replace(' ','',str_replace('&','and',$eduName));?>" value="<?php echo $eduName;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $eduName;?>
							</td>
							<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrKolsByEduCount[$key]['count']."(".round(($arrKolsByEduCount[$key]['count']/$allEduCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allEduCount)) echo round(($arrKolsByEduCount[$key]['count']/$allEduCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
							</td>
							<td><?php if (array_key_exists($key, $arrKolsByEduCount)) echo $arrKolsByEduCount[$key]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
					</table>
					<div class="filterSearchIcon"></div><input type="text" name="education" class="autocompleteInputBox" id="education" value="Enter Education" title=""/><input type="hidden" name="education_id" id="educationId" value="" />
				</div>
			</li>
			
			<li id="categotyEvent" class="category">
				<div class="refinedByLinkEvents sprite_iconSet"></div><label class="categoryName">Event</label>
				<label class="facet-toggle collapsed"  onclick="toggleCategory(true,this);"></label>
				<div style="display:none;">
				 <table class="clear">
					<tr class="allEvents">
				 		<td class="textAlignRight"><input class="hideCheckbox" type="checkbox" name="all_events" id="allEvents" value="event" <?php if(isset($selectedEvents) && $selectedEvents!=null) echo ''; else echo "checked='checked'"?> onclick="doSearchFilter1(-1,this)"/>All Events</td>
				 		<td class="histoGram">
				 			<div class="filterBar">
								<div class="progress" title="<?php echo $allEventCount."(".round(($allEventCount/$allEventCount)*100)."%)";?>">
									<div class="bar" style="width: <?php if(isset($allEventCount)) echo round(($allEventCount/$allEventCount)*100); else echo 0;?>%;"></div>
								</div>
							</div>
				 		</td>
				 		<td><?php if(isset($allEventCount)) echo $allEventCount; else echo 0;?></td>
				 	</tr>
				 	<?php $i=0;//pr($selectedEdus);pr($arrKolsByEduCount);
					 	foreach($arrKolsByEventCount as $eventCountDetails){ ?>
					 	<?php if($eventCountDetails['event_id']!=''){?>
					 	<!-- <tr class="event<?php echo $eventCountDetails['event_id'];?>">
					 		<td class="textAlignRight">
					 			<input type="checkbox" name="event_ids[]" class="eventElement hideCheckbox" id="event<?php echo $eventCountDetails['event_id'];?>" value="<?php echo $eventCountDetails['event_id'];?>" onclick="doSearchFilter1(-1,this)" 
								<?php if(isset($selectedEvents) && sizeof($selectedEvents)>0 && $selectedEvents!=null){if(in_array($eventCountDetails['event_name'], $selectedEvents)) {?>
									checked="checked"
								<?php $key = array_search($eventCountDetails['event_name'], $selectedEvents);if(array_key_exists($key, $selectedEvents))unset($selectedEvents[$key]);$selectedEvents=array_values($selectedEvents);}}?>
								/><?php echo $eventCountDetails['event_name'];?>
					 		</td>
					 		<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $eventCountDetails['count']."(".round(($eventCountDetails['count']/$allEventCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allEventCount)) echo round(($eventCountDetails['count']/$allEventCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
					 		</td>
					 		<td><?php echo $eventCountDetails['count'];?></td>
					 	</tr> -->
					<?php $i++; if($i>3) break; }}?>
				 	
					<?php if(isset($selectedEvents) && $selectedEvents!=null){foreach($selectedEvents as $id=>$eventName){?>
						<tr class="event<?php echo $id;?>">
					 		<td class="textAlignRight">
								<input type="checkbox" name="event_ids[]" class="eventElement hideCheckbox" id="event<?php echo $id;?>" value="<?php echo $id;?>" onclick="doSearchFilter1(-1,this)" checked="checked"/>&nbsp;<?php echo $eventName;?>
							</td>
							<td class="histoGram">
					 			<div class="filterBar">
									<div class="progress" title="<?php echo $arrKolsByEventCount[$id]['count']."(".round(($arrKolsByEventCount[$id]['count']/$allEventCount)*100)."%)";?>">
										<div class="bar" style="width: <?php if(isset($allEventCount)) echo round(($arrKolsByEventCount[$id]['count']/$allEventCount)*100); else echo 0;?>%;"></div>
									</div>
								</div>
					 		</td>
					 		<td><?php if (array_key_exists($id, $arrKolsByEventCount)) echo $arrKolsByEventCount[$id]['count']; else echo 0;?></td>
						</tr>
					<?php }}?>
				  </table>
				  <div class="filterSearchIcon"></div><input type="text" name="event_name" class="autocompleteInputBox" id="eventName" value="Enter Event" title=""/><input type="hidden" name="event_name_id" id="eventNameId" value="" />
				</div>
			</li>		
		<?php 	}?>
		</ul>
	</form>
</div>
<script type="text/javascript">
$(document).ready(function(){
    var method='<?php echo $method; ?>';
    
    if(method=="adv_search")
      $("#allTopicTypes").trigger('click');
	//$('#categoriesContainer input').parent().parent().css('background-color','#ffffff');
	$('#categoriesContainer input:checked').each(function (index){
		$(this).parent().parent().css('background-color','#D3DFED');
	});
        
	$('#searchFiltersElements ul li table tr').click(function (){
		var input = $(this).children('td:first').children('input');
		if($(input).attr('checked')=="checked"){
			$(this).css('background-color','#ffffff');
			$(input).removeAttr('checked');
			doSearchFilter1(-1,$('#'+$(this).attr('class')));
		}else{
			$(this).css('background-color','#D3DFED');
			$(input).attr('checked','checked');
			doSearchFilter1(-1,$('#'+$(this).attr('class')));
		}
	});

	// Trigger the Autocompleter for 'education' field of  Event'
	a = $('#specialty').autocomplete(SpecialtyNameAutoCompleteOptions);

	// Trigger the Autocompleter for 'education' field of  Event'
	a = $('#education').autocomplete(educationNameAutoCompleteOptions);

	// Trigger the Autocompleter for 'organizer' field of  Event'
	a = $('#organization').autocomplete(organizationNameAutoCompleteOptions);

	// Trigger the Autocompleter for 'country' field of  Event'
	a = $('#country').autocomplete(countryNameAutoCompleteOptions);

	// Trigger the Autocompleter for 'state' field of  Event'
	a = $('#state').autocomplete(stateNameAutoCompleteOptions);

	// Trigger the Autocompleter for 'state' field of  Event'
	a = $('#city').autocomplete(cityNameAutoCompleteOptions);

	// Trigger the Autocompleter for 'country' field of  Event'
	a = $('#eventName').autocomplete(eventNameNameAutoCompleteOptions);

	// Trigger the Autocompleter for 'list' field of  Event'
	a = $('#listName').autocomplete(listNameAutoCompleteOptions);

	a= $('#kolName').autocomplete(kolNameAutoCompleteOptions);
        
        a = $('#orgType').autocomplete(orgTypeAutoCompleteOptions);
        a = $('#kolType').autocomplete(kolTitlesAutoCompleteOptions);
         a = $('#regionType').autocomplete(regionTypeAutoCompleteOptions);
           a = $('#topicType').autocomplete(topicCompleteOptions);
	$('.autocomplete').click(function(){
		//doSearchFilter1(-1);
	});

	// Trigger the Autocompleter for 'KOl Name' field
	b= $('#influenceKolName').autocomplete(kolNameAutoCompleteOptions1);

	$('#country').focus(function(){
		$('#country').val(' ');
		
	});
	             $('#regionType').focus(function(){
    $('#regionType').val(' ');
    });
            $('#regionType').blur(function(){
    $('#regionType').val('Enter Global Region ');
    });
                 $('#topicType').focus(function(){
    $('#topicType').val(' ');
    });
            $('#topicType').blur(function(){
    $('#topicType').val('Enter Topic Name ');
    });    
    $('#kolType').focus(function(){
    	$('#kolType').val(' ');
    });
            $('#kolType').blur(function(){
    $('#kolType').val('Enter Positions ');
    });    
	$('#country').blur(function(){
		$('#country').val('Enter Country ');
		
	});
        
        $('#orgType').focus(function(){
		$('#orgType').val(' ');
		
	});
	       
	$('#orgType').blur(function(){
		$('#orgType').val('Enter Type ');
		
	});
	$('#state').focus(function(){
		$('#state').val(' ');
		
	});
	       
	$('#state').blur(function(){
		$('#state').val('Enter State ');
		
	});

	$('#city').focus(function(){
		$('#city').val(' ');
		
	});
	       
	$('#city').blur(function(){
		$('#city').val('Enter City ');
		
	});
	
	$('#specialty').focus(function(){
		$('#specialty').val(' ');
		
	});
	       
	$('#specialty').blur(function(){
		$('#specialty').val('Enter Specialty');
		
	});

	$('#listName').focus(function(){
		$('#listName').val(' ');
		
	});
	       
	$('#listName').blur(function(){
		$('#listName').val('Enter List');
		
	});

	$('#education').focus(function(){
		$('#education').val(' ');
		
	});
	       
	$('#education').blur(function(){
		$('#education').val('Enter Education');
	});

	$('#organization').focus(function(){
		$('#organization').val(' ');
		
	});
	       
	$('#organization').blur(function(){
		$('#organization').val('Enter Organization');
	});

	$('#eventName').focus(function(){
		$('#eventName').val(' ');
		
	});
	       
	$('#eventName').blur(function(){
		$('#eventName').val('Enter Event');
	});

	$('#kolName').focus(function(){
		$('#kolName').val(' ');
		
	});
	       
	$('#kolName').blur(function(){
		$('#kolName').val('Enter KTL Name');
	});


       if($('#country').val()=='Enter Country' || $('#state').val()=='Enter State' || $('#city').val()=='Enter City' || $('#specialty').val()=='Enter Specialty' || $('#listName').val()=='Enter List' || $('#organization').val()=='Enter Organization' || $('#eventName').val()=='Enter Event' || $('#education').val()=='Enter Education' || $('#kolName').val()=='Enter HCP Name'){
			$('.autocompleteInputBox').css({color:'grey'});
       }
});



// Hide or Show the Category checkbox's 
function toggleCategory(toggleFlag,thisEle){
	var parentId=$(thisEle).parent().attr("id");
	if($(thisEle).hasClass('expanded')){
		$(thisEle).removeClass('expanded');
		$(thisEle).addClass('collapsed');
		$(thisEle).next().hide();
	}
	else {
		$(thisEle).removeClass('collapsed');
		$(thisEle).addClass('expanded');
		$(thisEle).next().show();
	}
}
</script>