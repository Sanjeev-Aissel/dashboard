<?php
/**
 * This is Model file of 'Role'
 *
 * @package application.models
 * @author Ambarish
 * @since
 * @created on  9-12-10
 */
class Role extends Model{

	//Constructor
	function Role(){
		parent::Model();
	
	}
	
	/*
	 * To Get all Roles from role table
	 *  
	 * @author Vinayak
 	 * @since  3.5.1
 	 * @created  22-12-11
	 * 
	 */
	function getRoles(){
		$arrRoles =array();
		$this->db->order_by('role','asc');
		$arrRolesResult = $this->db->get('user_roles');
		foreach($arrRolesResult->result_array() as $row){
			$arrRoles[]=$row;
		}
		return $arrRoles;
	}
	
	/*
	 * To Get user role and AllowedType for particualr Method
	 *  
	 * @author Vinayak
 	 * @since  3.5.1
 	 * @created  22-12-11
 	 * @param  $id;
	 * @return $arrRoleReult
	 */
	function getUserRoleAndAllowedType($id){
		$arrRoleReult=array();
		$arrResult = $this->db->query('select access_permissions.*,user_roles.role
										from user_roles
										left join access_permissions on user_roles.id=access_permissions.role_id
										where access_permissions.access_object_id='.$id.'
										order by role asc
												');
		foreach($arrResult->result_array() as $row){
			$arrRoleReult[]=$row;
		}
		return $arrRoleReult;
	}
	
	
	/*
	 * To Get all roles
	 *  
	 * @author Vinayak
 	 * @since  3.5.1
 	 * @created  22-12-11
	 * @return $arrRoleReult
	 */
	function listRoles(){
		$arrRoles = array();
		$arrResultSet = $this->db->get('user_roles');
		foreach($arrResultSet->result_array() as $row){
			$arrRoles[]=$row;
		}
		return $arrRoles;
	}
	
	/*
	 * To Save all Role details
	 *  
	 * @author Vinayak
 	 * @since  3.5.1
 	 * @created  22-12-11
	 * @return Last insert id
	 */
	function saveRole($arrRoles){
	
			if($this->db->insert('user_roles',$arrRoles)){
				return $this->db->insert_id();
			}else{
				return false;
			}
			
	}
	
	/*
	 * To get role detail for particular Role id
	 *  
	 * @author Vinayak
 	 * @since  3.5.1
 	 * @created  22-12-11
	 * @return $arrRole
	 */
	function getRoleById($roleId){
		$arrRole=array();
		$this->db->where('id',$roleId);
		$arrResultset = $this->db->get('user_roles');
		foreach($arrResultset->result_array() as $row){
			$arrRole=$row;
		}
		return $arrRole;
	}
	
	/*
	 * To Update all Role details
	 *  
	 * @author Vinayak
 	 * @since  3.5.1
 	 * @created  22-12-11
	 * @return true/false
	 */
	function updateRole($arrRoles){
		$this->db->where('id',$arrRoles['id']);
		if($this->db->update('user_roles',$arrRoles)){
			return true;
		}else{
			return false;
		}
		
	}
	
	/*
	 * To Delete Role details
	 *  
	 * @author Vinayak
 	 * @since  3.5.1
 	 * @created  22-12-11
	 * @return true/false
	 */
	function deleteRole($roleId){
		$this->db->where('id',$roleId);
		if($this->db->delete('user_roles')){
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
					'description' => 'Delete Role',
					'status' => STATUS_SUCCESS,
					'transaction_id' =>  $roleId,
					'transaction_table_id' => USER_ROLES,
					'transaction_name' => "Delete Role",
					'parent_object_id' =>  $roleId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return true;
		}else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
					'description' => 'Delete Role',
					'status' => STATUS_FAIL,
					'transaction_id' =>  $roleId,
					'transaction_table_id' => USER_ROLES,
					'transaction_name' => "Delete Role",
					'parent_object_id' =>  $roleId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return false;
		}
		
	}
}