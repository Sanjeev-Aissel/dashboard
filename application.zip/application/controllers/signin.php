<?php
/**
 * Handles the login page request from the users not using the SSO
 * @author Ramesh B
 * @since
 * @package application.controllers	
 * @created on 02 Feb 2013
 */
class Signin extends Controller {
	
	function Signin()
	{
		parent::Controller();	
		$this->load->model('login_model');
		$this->load->library('SimpleLoginSecure');
		//$this->output->cache(60);
	}
	
	/**
	 * Handles the login page request from the users not using the SSO
	 */
	function index(){
		// Checking the UNDER_MAINTENANCE value.if it 0 redirect it to login page
		if(UNDER_MAINTENANCE == 0){
			
			// If the user has already logged in
			if($this->session->userdata('logged_in')) {
	    		redirect('/kols/list_kols_client_view');
			}
			else{
				//Cache the login page for next 720 minutes i.e 1 day
				//$this->output->cache(720);
				$this->load->view('login/login');
			}
		}
	}
}