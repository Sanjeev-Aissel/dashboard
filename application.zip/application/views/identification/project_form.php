
<style>
#contents{
	text-align:left;
	font-size:110%;
	padding-left:150px;
}

#contents label{
	float:left;
	width:150px;
	text-align:right;
	padding-right:6px;
	padding-top:2px;
}
h2 {
    font-size: 1.5em;
    font-weight: bold;
}
#client_chzn{
width:409px !important;
}
.chzn-container-multi .chzn-choices .search-field input{
	width:180px !important;
}
h2{
	color:#2E6E9E;
	font-size:170%;
	margin-bottom:10px;
	margin-top:15px;
}
.analystForm div.formButtons, div.formButtons{
	margin-bottom:20px;
}
button{
top:0px;
}
textarea {
    width: 395px;
    padding: 5px;
}
#popup_message{
    text-align:left;
}
</style>
<link href="<?php echo base_url(); ?>css/chosen.css" media="screen" rel="stylesheet" />
<script type="text/javascript">
var projectId = '';
var idsOfSelectedRows = [];
var arrKolIds = [];
$(document).ready(function(){
	<?php if(isset($rowData)){?>
			projectId = <?php echo $rowData['id'];?>;
			<?php foreach($selectedKols as $row){ ?>
			arrKolIds.push("<?php echo $row['kol_id'];?>");
			<?php } ?>
			idsOfSelectedRows = arrKolIds;
// 			alert(arrKolIds);
	<?php } ?>
	getKolsNotAssociatedWithProject();
	if(projectId >0){
		getKolsAssociatedWithProject();
	}
	
	
	$('#cancel_project').click(function(){
		window.location.href = '<?php echo base_url();?>identifications/list_projects';
	});
});
$(function () {
	$('#client').chosen({
        placeholder_text: "Click to Select Clients",
        allow_single_deselect: true
    });
});
function getKolsAssociatedWithProject(){
	$("#gridProjectKolsContainer").html("");
	$("#gridProjectKolsContainer").html('<table id="JQBlistProjectKolsDetails"></table><div id="listProjectKolsDetailsPage"></div>');
	var ele=document.getElementById('gridProjectKolsContainer');
	var base_url = '<?php echo base_url() ?>';
	var gridWidth=$('#gridProjectKolsContainer').width();
	jQuery("#JQBlistProjectKolsDetails").jqGrid({
		url: base_url + 'identifications/get_kols_by_project/'+projectId+'/true',
		datatype: "json",
		colNames:['Id','Name','Specialty','Gender','Organizations', 'Pubmed ?','Trials ?','Created By','Pin','Status','Action'],
	   	colModel:[
			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},
			{name:'kol_name',index:'kol_name',search:true,
	   			formatter: function (cellvalue, options, rowObject) {
//	   				jAlert(rowObject.is_imported);
	   				if(rowObject.is_imported == parseInt(1)){
		   				 return "<a href='"+base_url+"/kols/view/"+rowObject.id+"' target='_NEW' class='link' title='" + $.jgrid.stripHtml(cellvalue) + "'>" +
				         $.jgrid.htmlEncode(cellvalue) + "</a> <span class='highlightImported'> (xls)<span>";
		   			}
				        return "<a href='"+base_url+"/kols/view/"+rowObject.id+"' target='_NEW' class='link' title='" + $.jgrid.stripHtml(cellvalue) + "'>" +
			            $.jgrid.htmlEncode(cellvalue) + "</a>";
	    	},firstsortorder:'asc'},
	   		{name:'specialty',index:'specialty',width:90, search:true},
	   		{name:'gender',index:'gender',search:true,width:50, resizable:false},
	   		{name:'organization',index:'organization',search:true},
	   		{name:'pubmed_processed',index:'pubmed_processed',width:50, editable: false, edittype:"select", editoptions:{value:"0:No;1:Yes;2:Re Crawl"}},
			{name:'trial_processed',index:'trial_processed',width:50,search:true, align:'center',resizable:false},
			{name:'created_by',index:'created_by',width:80,search:true},
			{name:'pin',index:'pin', width:100, search:true},
			{name:'status',index:'status',width:60,search:true},
			{name:'action',index:'action',width:45, align:'center',search:false, resizable:false, hidden:true}
			
	   	],
	   	rowNum:10,
	   	rownumbers: true,
	   	autowidth: true, 
	   	loadonce:true,
	   	multiselect: true,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",		   
	   	pager: '#listProjectKolsDetailsPage',
	   	toppager:false,
	   	mtype: "POST",
	   	sortname: 'kol_name',
	    viewrecords: true,
	    sortorder: "asc",
	    jsonReader: { repeatitems : false, id: "0" },
	    toolbar: "top",
	    caption:"Associated KOL's Profile List",
   		rowList:paginationValues,
	    gridComplete: function(){	
	    },
	    loadComplete: function () {
	        var $this = $(this), i, count;
	        for (i = 0, count = idsOfSelectedRows.length; i < count; i++) {
	            $this.jqGrid('setSelection', idsOfSelectedRows[i], false);
	        }
	    }
	});

	jQuery("#JQBlistProjectKolsDetails").jqGrid('navGrid','#listProjectKolsDetailsPage',{edit:false,add:false,del:false,search:false,refresh:false});

	//Toolbar search bar below the Table Headers
	jQuery("#JQBlistProjectKolsDetails").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
	
	//Toggle Toolbar Search 
	jQuery("#JQBlistProjectKolsDetails").jqGrid('navButtonAdd',"#listProjectKolsDetailsPage",{
		caption:"Search",title:"Toggle Search",
		onClickButton:function(){ 			
			if(jQuery(".ui-search-toolbar").css("display")=="none") {
				jQuery(".ui-search-toolbar").css("display","");
			} else {
				jQuery(".ui-search-toolbar").css("display","none");
			}							
		} 
	}); 
	jQuery("#JQBlistProjectKolsDetails").jqGrid('setGridWidth',gridWidth); 
}
function getKolsNotAssociatedWithProject(){
	$("#gridNotProjectKolsContainer").html("");
	$("#gridNotProjectKolsContainer").html('<table id="JQBlistNotProjectKolsDetails"></table><div id="listNotProjectKolsDetailsPage"></div>');
	var ele=document.getElementById('gridNotProjectKolsContainer');
	var base_url = '<?php echo base_url() ?>';
	var gridWidth=$('#gridNotProjectKolsContainer').width();
	jQuery("#JQBlistNotProjectKolsDetails").jqGrid({
		url: base_url + 'identifications/get_kols_by_project/'+projectId,
		datatype: "json",
		colNames:['Id','Name','Specialty','Gender','Organizations', 'Pubmed ?','Trials ?','Created By','Pin','Status','Action'],
	   	colModel:[
			{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},
			{name:'kol_name',index:'kol_name',search:true,
	   			formatter: function (cellvalue, options, rowObject) {
//	   				jAlert(rowObject.is_imported);
	   				if(rowObject.is_imported == parseInt(1)){
		   				 return "<a href='"+base_url+"/kols/view/"+rowObject.id+"' target='_NEW' class='link' title='" + $.jgrid.stripHtml(cellvalue) + "'>" +
				         $.jgrid.htmlEncode(cellvalue) + "</a> <span class='highlightImported'> (xls)<span>";
		   			}
				        return "<a href='"+base_url+"/kols/view/"+rowObject.id+"' target='_NEW' class='link' title='" + $.jgrid.stripHtml(cellvalue) + "'>" +
			            $.jgrid.htmlEncode(cellvalue) + "</a>";
	    	},firstsortorder:'asc'},
	   		{name:'specialty',index:'specialty',width:90, search:true},
	   		{name:'gender',index:'gender',search:true,width:50, resizable:false},
	   		{name:'organization',index:'organization',search:true},
	   		{name:'pubmed_processed',index:'pubmed_processed',width:50, editable: false, edittype:"select", editoptions:{value:"0:No;1:Yes;2:Re Crawl"}},
			{name:'trial_processed',index:'trial_processed',width:50,search:true, align:'center',resizable:false},
			{name:'created_by',index:'created_by',width:80,search:true},
			{name:'pin',index:'pin', width:100, search:true},
			{name:'status',index:'status',width:60,search:true},
			{name:'action',index:'action',width:45, align:'center',search:false, resizable:false, hidden:true}
			
	   	],
	   	rowNum:10,
	   	rownumbers: true,
	   	autowidth: true, 
	   	loadonce:true,
	   	multiselect: true,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",		   
	   	pager: '#listNotProjectKolsDetailsPage',
	   	toppager:false,
	   	mtype: "POST",
	   	sortname: 'kol_name',
	    viewrecords: true,
	    sortorder: "asc",
	    jsonReader: { repeatitems : false, id: "0" },
	    toolbar: "top",
	    caption:"Non-Assocciated KOL's Profile List",
   		rowList:paginationValues,
	    gridComplete: function(){	
	    }
	});

	jQuery("#JQBlistNotProjectKolsDetails").jqGrid('navGrid','#listNotProjectKolsDetailsPage',{edit:false,add:false,del:false,search:false,refresh:false});

	//Toolbar search bar below the Table Headers
	jQuery("#JQBlistNotProjectKolsDetails").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
	
	//Toggle Toolbar Search 
	jQuery("#JQBlistNotProjectKolsDetails").jqGrid('navButtonAdd',"#listNotProjectKolsDetailsPage",{
		caption:"Search",title:"Toggle Search",
		onClickButton:function(){ 			
			if(jQuery(".ui-search-toolbar").css("display")=="none") {
				jQuery(".ui-search-toolbar").css("display","");
			} else {
				jQuery(".ui-search-toolbar").css("display","none");
			}							
		} 
	}); 
	jQuery("#JQBlistNotProjectKolsDetails").jqGrid('setGridWidth',gridWidth); 
}
function save_project(){
	var data ={};
	data['name'] = $("#name").val();
	data['description'] = $("#description").val();
	data['year_range'] = $('#year_range').val();
	var selectedValues = [];    
    $("#client :selected").each(function(){
        selectedValues.push($(this).val()); 
    });
    data['client'] = selectedValues;
    data['kol_ids']	= $('#JQBlistNotProjectKolsDetails').getGridParam('selarrrow');
    <?php if(isset($rowData)){?>
    	data['id'] = $("#projId").val();
    	data['assocciatedkolId']	= $('#JQBlistProjectKolsDetails').getGridParam('selarrrow');		
    	if(document.getElementById('overwrite_association').checked) {
    		data['overwrite_association'] = 1;
    	} else {
    		data['overwrite_association'] = 0;
    	}
//     	data['overwrite_association'] = $('#overwrite_association').val();
    <?php }else{ ?>
//     if(data['kol_ids']==''){
// 		jAlert("Please select at least one KOL");
// 		return false;
// 	}
	
	<?php }?>
// 	console.log(data);return false;
	$.ajax({
		url:'<?php echo base_url()?>identifications/save_project',
		data:data,
		type:'post',
		dataType:'json',
		success:function(res){
			//alert(res.toSource());	
			if(res.status==true){
				jAlert('Saved Details '+res.data, '', function(result) {
            		window.location	= "<?php echo base_url().'identifications/edit_project/';?>"+res.project_id;
                });
			}else{		
				//$(".errorName").html(res.msgName);
			}
		}
	});
	
}

</script>

	<?php if(isset($rowData)){?>
		<input type="hidden" name="id" value="<?php echo $rowData['id'];?>" id='projId'>
	<?php }?>
	<?php if(isset($rowData)){ echo '<h2>Edit '.$rowData['name'].' </h2>';} else { echo '<h2>Add Project</h2>';}?>
	
				<p><span style="float:left"><label for="name">Project Name<span class="required">*</span> :</label>
			
				<input name="name" id="name" value="<?php if(isset($rowData)) echo $rowData['name'];?>" style="width: 121px;"></span>
				
				<span style="float:left"><label for="year_range">Year Range<span class="required">*</span> :</label>
			
				<input name="year_range" id="year_range" value="<?php if(isset($rowData)) echo $rowData['year_range'];?>" style="width: 121px;"></span></p><br/>
			
				<p><label for="description">Description :</label>
			
				<textarea name="description" id="description" rows="4"><?php if(isset($rowData)) echo $rowData['description'];?></textarea></p>
				<!-- 
				<p><label for="kol_ids">Kol Ids :</label>
			
				<textarea name="kol_ids" id="kol_ids" rows="4"><?php if(isset($rowData)) echo $rowData['kol_ids'];?></textarea></p> -->
			
				<p><label for="kol_ids">Client :</label>
			<select class="chosenMultipleSelect" name="client[]" id="client" multiple="multiple" >
						<?php 
							foreach ($arrClientList as $arrList){
						?>
						<option value="<?php echo $arrList['id'];?>" 
						<?php if (isset($selectedClients)) {
								if (in_array($arrList['id'], $selectedClients)){
									 echo 'selected';
								}
							}             
                         ?>><?php echo $arrList['name']; ?></option>
						<?php 
							}
						?>
				</select></p>
		<p><label for="overwrite_association">Overwrite Association :</label>
			
			<input type="checkbox" name="overwrite_association" id="overwrite_association"></p>
		<?php if(isset($rowData)){?>	
		<div class="gridWrapper" id="gridProjectKolsContainer">
			<table id="JQBlistProjectKolsDetails"></table>
			<div id="listProjectKolsDetailsPage"></div>
		</div>
		<?php }?>
		<div class="gridWrapper" id="gridNotProjectKolsContainer">
			<table id="JQBlistNotProjectKolsDetails"></table>
			<div id="listNotProjectKolsDetailsPage"></div>
		</div>
		<br>
				
		<div class="formButtons">	
			<!-- <input type="submit" value="Save" /> -->
			<button type="button" id="save" onclick='save_project();'>Save</button>
 			<button type="button" id="cancel_project" >Cancel</button>
 		</div>
		 	

