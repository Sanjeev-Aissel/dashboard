<?php
/**
 * View -Password Cinfirmamtion page
 * @author Vinayaj
 * @since 0tsuka_1.0.7
 * @package application.view.login	
 * @created on 20-12-2012
 */
?>

<style type="text/css">
	.message{
		margin: 7% 4% auto;	
	}
	b{
	
	} 
 
	.header{
	border-bottom: 1px solid #D7D9DA;
    color: #0070BD;
    font-family: trebuchet ms;
    font-size: 28px;
    margin: 1px 4% auto;
    padding: 18px 5px 5px 0;
    width: 495px;
	}
</style>
<div class="header">
	Password should not be same as your previous <?php echo RESTRICT_NO_OF_PASSWORDS_TO_REUSE;?> passwords
</div>
<div class="message">
	Your password has not been changed. <a href="<?php echo base_url()?>login/reset_password/<?php echo $user_id.'/'.$pass_key;?>" >Click Here</a> to try again
</div>