<?php
class Country_helper extends CI_Model{
	/*
	 * function to list all the available countries
	 */
	function listCountries(){
		$client_id = $this->session->userdata('client_id');
		$arrCountry=array();
		$group_names = explode(',', $this->session->userdata('group_names'));
		$this->db->order_by('Country');
        if(INTERNAL_CLIENT_ID != $client_id){
            if($this->session->userdata('user_role_id') == ROLE_USER || $this->session->userdata('user_role_id') == ROLE_MANAGER){
    		  $this->db->where_in('GlobalRegion',$group_names);
            }
        }
		$result=$this->db->get('countries');
		$country=array();
			foreach ($result->result() as $row)
				{					
					$country['country_id']=$row->CountryId;
					$country['country_name']=$row->Country;
					$arrCountry[$country['country_name']]=$country;
				}
		return $arrCountry;		
	}
	/*
	 * function to list all the available states
	 */
	function listStates(){
		$arrStates=array();
		$this->db->order_by('name');
		$result=$this->db->get('states');
		$state=array();
		// looping trought each row to get 'state_id->state_name' pair
		foreach ($result->result() as $row)
		{
			$state['state_id']=$row->id;
			$state['state_name']=$row->name;
			$arrStates[$state['state_name']]=$state;
		}
		// end of looping trought all rows
	
		return $arrStates;
	}
	
	function listStatesAssociated(){
		$arrStates=array();
		$this->db->order_by('name');
		$result=$this->db->get('states');
		$state=array();
		// looping trought each row to get 'state_id->state_name' pair
		foreach ($result->result() as $row)
		{
			$state['state_id']=$row->id;
			$state['state_name']=$row->name;
			$index = $row->country_id.'_'.str_replace(" ", "_", $row->name);
			$arrStates[$index]=$state;
		}
		// end of looping trought all rows
	
		return $arrStates;
	}
	/*
	 * function to list all the available cities
	 */
	function listCities(){
		$arrCity=array();
		$this->db->select('city,cityId');
		$result=$this->db->get('cities');
		$city=array();
		// Looping trought each row to get 'state_id->state_name' pair
		foreach ($result->result() as $row)
		{
			$city['city_id']	=	$row->cityId;
			$city['city_name']	=	$row->city;
			$arrCity[$city['city_name']]=	$city;
		}
		// End of looping trought all rows
	
		return $arrCity;
	}
	
	function listCitiesAssociated(){
		$arrCity=array();
		$this->db->select('city,cityId,CountryID,RegionID');
		$result=$this->db->get('cities');
		$city=array();
		// Looping trought each row to get 'state_id->state_name' pair
		foreach ($result->result() as $row)
		{
			$city['city_id']	=	$row->cityId;
			$city['city_name']	=	$row->city;
			$index = $row->CountryID.'_'.$row->RegionID.'_'.str_replace(" ", "_", $row->city);
			$arrCity[$index]=	$city;
		}
		// End of looping trought all rows
	
		return $arrCity;
	}
	/*
	 * function to get states belongs to county 
	 * takes 'country_id' as parameter
	 */
	function getStatesByCountryId($countryId){
		$arrState=array();
		$this->db->where('country_id', $countryId); 
		$this->db->order_by('name');
		$result=$this->db->get('states');
		$state=array();
			foreach ($result->result() as $row)
				{										
					$state['state_id']=$row->id;	
					$state['state_name']=$row->name;
					$arrState[]=$state;				    
				}
		return $arrState;	
	}
	/*
	 * function to get cities belongs to state
	 * takes 'state_id' as parameter
	 */
	 function getCitiesByStateId($stateId,$cityName='',$forAutocomplete=false,$limit=50,$offset=0){
		$arrCity=array();
		$this->db->select('cities.city,cities.cityId,states.name as state,cities.Latitude,cities.Longitude');
			$this->db->where('cities.RegionID', $stateId);
		if(!empty($cityName)){
			$this->db->like('cities.city', $cityName);
		}
		$this->db->join('states','states.id=cities.RegionID','inner');
		$this->db->order_by('City');
		if($stateId == 0 || !isset($stateId))
			$this->db->limit($limit,$offset);
		$result=$this->db->get('cities');
		$city=array();
		foreach ($result->result_array() as $row)
		{
			$city['city_id']	=	$row['cityId'];	
			$city['city_name']	=	$row['city'];
			if($forAutocomplete){
				$arrCity[$row['cityId']][]=$row['city'];
				$arrCity[$row['cityId']][]=$row['state'];
				$arrCity[$row['cityId']][]=$row['Latitude'];
				$arrCity[$row['cityId']][]=$row['Longitude'];
			}else{
				$arrCity[]	=	$city;
			}	    
		}
		return $arrCity;		
	}
	function getCountryNameById($arrCountryIds){
		$arrCountries =	array();
		$this->db->where_in('CountryId',$arrCountryIds);
		$result = $this->db->get('countries');
		foreach($result->result_array() as $row){
			$arrCountries[$row['CountryId']] = $row['Country'];
		}
		return $arrCountries;
	}
	function getStateNameById($arrIds){
		$arrState =	array();
		$this->db->where_in('id',$arrIds);
		$result = $this->db->get('states');
		foreach($result->result_array() as $row){
			$arrState[$row['id']] = $row['name'];
		}
		return $arrState;
	}
	function getCountryById($id){
		$arrCountry = array();
		$this->db->where('CountryID',$id);
		$result = $this->db->get('countries');
		foreach($result->result_array() as $row){
			if($result->num_rows!=0){
				$arrCountry = $row['Country'];
			}else{
				return false;
			}
		}
		return $arrCountry;
	}
	function getStateById($id){
		$arrState =	array();
		$this->db->where('id',$id);
		$result = $this->db->get('states');
		foreach($result->result_array() as $row){
			$arrState = $row['name'];
		}
		return $arrState;
	}	
	function getCityeById($id){
		$arrCity =array();
		$this->db->select('city');
		$this->db->where('CityID',$id);
		$result = $this->db->get('cities');
		foreach($result->result_array() as $row){
			$arrCity = $row['city'];
		}
		return $arrCity;
	}
	function getCityNameById($arrIds){
		$arrCity =	array();
		$this->db->where_in('CityId',$arrIds);
		$result = $this->db->get('cities');
		foreach($result->result_array() as $row){
			$arrCity[$row['CityId']] = $row['City'];
		}
		return $arrCity;
	
	}
	function checkStateIfExistElseAdd($state,$country){
		$this->db->select('id');
		$this->db->where('name',$state);
		$this->db->where('country_id',$country);
		$this->db->limit(1);
		$query = $this->db->get('states');
		$result = $query->result_array();
		 
		if($result['0']['id'] == ""){
			$data = array(
					'country_id' => $country,
					'name' => $state
			);
			$this->db->insert('states', $data);
			return $this->db->insert_id();
		}else{
			return $result['0']['id'];
		}
	}
	function checkCityIfExistElseAdd($city,$stateId,$country){
		$this->db->select('CityId');
		$this->db->where('city',$city);
		$this->db->where('RegionID',$stateId);
		$this->db->where('CountryID',$country);
		$this->db->limit(1);
		$query = $this->db->get('cities');
		$result = $query->result_array();
		 
		if($result['0']['CityId'] == ""){
			$data = array(
					'CountryID' => $country,
					'RegionID' => $stateId,
					'City'	=>	$city
			);
			$this->db->insert('cities', $data);
			return $this->db->insert_id();
		}else{
			return $result['0']['CityId'];
		}
	}
}
