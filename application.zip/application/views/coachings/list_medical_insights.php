<?php
// prepare array of JS files to insert into queue
$queued_js_scripts = array('i18n/grid.locale-en',
    'jquery.jqGrid.min',
    'jquery/jquery-ui-1.8.16.datepicket',
    'chosen.jquery'
);
// add the JS files into queue i.e Append to the existing queue
$this->config->set_item('js_files_to_load', array_merge($this->config->item('js_files_to_load'), $queued_js_scripts));
$currentController = $this->uri->segment(1);
$kolId = (int) $this->uri->segment(3);
$client_id = (int) $this->session->userdata('client_id');

if (!empty($kolId)) {
    $kol_id = $kolId;
} else {
    $kol_id = 0;
}
?>
<!-- JQGrid Plugins -->
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url() ?>css/themes/ui.jqgrid.css" />
<link href="<?php echo base_url(); ?>css/chosen.css" media="screen" rel="stylesheet" />
<style type="text/css">
    /*    Enable Verticle separator between content and side menu list  By Laxman   */
    #contentWrapper.span-23 {
        background-image: url("<?php echo base_url(); ?>images/verticlesep_terNav.jpg");
        background-position: 135px 50%;
        background-repeat: repeat-y;
    }
    /*	#coachingsList{
                    width: 800px;
                    margin-top: -75px;
                    margin-top: 0px;
                    float: right;
            }*/
    .buttonsWarpper{
        float: right;
        width: 266px;
    }
    .gridWrapper {
        width: 100%;
    }
    th.ui-th-column div {
        height: auto !important;
        overflow: hidden !important;
        padding: 2px;
        white-space: normal !important;
    }
    .ui-th-ltr, .ui-jqgrid .ui-jqgrid-htable th.ui-th-ltr{
        vertical-align: top;
    }
    p#submitButton{
           text-align: center;
           padding-left: 136px;
       }
       #medicalInsightFilterForm p {
       float: left;
       width: 260px;
       margin: 0;
   }
   .exportOptionsContainer ul.addMedical {
        margin-top: -50px !important;

   }
   #coachingsList{
   margin-top: -35px;
   }
</style>
<script type="text/javascript">
    var kolId =<?php echo $kol_id; ?>;
    var currentController = "<?php echo $currentController; ?>";
    var username = "<?php echo lang("track.Username"); ?>";
    var specialty = "<?php echo lang("track.Specialty"); ?>";
    var action = "<?php echo lang("Overview.Action"); ?>";
    var allUser=0;
    var todayDate = "<?php echo date("m/d/Y");?>";
    var monthFirstDate = "<?php echo date("m/01/Y");?>";
    var postData = {};
    jqgridIds = new Array('listCoachingsResultSet');
    
    $(document).ready(function () {
        $('#start_date').datepicker({
            dateFormat: 'mm/dd/yy'
        });
        $('#start_date').val(monthFirstDate);
        $('#end_date').datepicker({
            dateFormat: 'mm/dd/yy'
        });
        $('#end_date').val(todayDate);
        generateMedicalInsightReport();
    });
    function addMedicalInsight() {
        if (currentController == "kols")
            window.location = base_url + 'kols/view/' + kolId + '/medical_insight/';
        else
            window.location = base_url + 'coachings/medical_insight/';
    }
    function editCoaching(id) {
        // window.location=base_url+'coachings/edit_coaching/'+id;
    }
    function viewMedicalInsight(id) {
        if (currentController == "kols")
            window.location = base_url + 'kols/view/' + kolId + '/view_medical_insight/' + id + '/';
        else
            window.location = base_url + 'coachings/view_medical_insight/' + id + '/';
    }
    function deleteMedicalInsight(id) {
        var formAction = base_url + 'coachings/delete_medical_insight/' + id;
        jQuery("#listCoachingsResultSet").jqGrid('delGridRow', id, {reloadAfterSubmit: false, url: formAction});
        //$("#delmodlistInteractionsResultSet").addClass("gridConfirmFormCenterAlign");
        $("#delmodlistCoachingsResultSet").center();
    }
    function editMedicalInsight(id) {
        if (currentController == "kols")
            window.location = base_url + 'kols/view/' + kolId + '/edit_medical_insight/' + id;
        else
            window.location = base_url + 'coachings/edit_medical_insight/' + id;
    }
    function listRecordsPerPage(maxRecords, increament) {
        var rowList = new Array();
        for (i = increament; i <= maxRecords; i += increament) {
            rowList.push(i);
        }
        return rowList;
    }

    /** 
     * Show/Hide the Search Tool Bar in the JQGrid
     */
    function toggleSearchToolbar() {
        if (jQuery(".ui-search-toolbar").css("display") == "none") {
            jQuery(".ui-search-toolbar").css("display", "");
        } else {
            jQuery(".ui-search-toolbar").css("display", "none");
        }
    }
    
     function generateMedicalInsightReport(){
    var data={};
     var   sd = $("#start_date").val();
           if(sd!=''){        
                   var sdSplits = sd.split("/");            
                   data['from'] = sdSplits[2]+"-"+sdSplits[0]+"-"+sdSplits[1];        
           }        
           var ed = $("#end_date").val();        
           if(ed!=''){            
                   var edSplits = ed.split("/");            
                   data['to'] = edSplits[2]+"-"+edSplits[0]+"-"+edSplits[1];        
           }
           data['manager_id']=$("#managers").val();
            postData = data;
            list_coaching_grid(allUser);
            var fromDate = new Date( $("#start_date").val());
            var toDate = new Date($("#end_date").val());
            if(sd != '' && ed != ''){
                if (toDate < fromDate){
                    jAlert(" 'End Date' Should be greater than 'Start Date' ");
                    return false;
                }
            }
   }
    function list_coaching_grid(allUserFlag) {  
        var showAll=0;
        if(allUserFlag==1)
            showAll=1;
        else{
            showAll=0;
        } 
        $("#allUserFlag").val(showAll);
        var ele = document.getElementById('coachingsList');
        var gridWidth = ele.clientWidth;
        $('#coachingsList').html('');
        $('#coachingsList').html('<div class="gridWrapper"><div id="listCoachingsPage"></div><table id="listCoachingsResultSet"></table><div>');
        jQuery("#listCoachingsResultSet").jqGrid({
            url: '<?php echo base_url(); ?>coachings/list_medical_insight_grid/<?php echo $kol_id; ?>/'+showAll+'/',
            datatype: "json",
            colNames: ['', '','Id', 'Therapeutic Area', 'Product', 'Source Type', '', 'Topics',  'Medical Insight Summary', '', '', 'KTL Name', 'Recorded By','Recorded On', '', '', action],
            colModel: [
                {name: 'id', index: 'id', width: 0, hidden: true, search: false, resizable: false},
                {name: 'micro', width: 40, search: false, align: 'center'},
                {name: 'generic_id', index: 'generic_id', width: 100, search: true},
                {name: 'specialty', index: 'specialty', width: 100, search: true},
                {name: 'product', index: 'product', width: 80, search: true},
                {name: 'source_type', index: 'source_type', width: 100, search: true},
                {name: 'agent', index: 'agent', width: 80, search: true, resizable: false,hidden: true,},
                {name: 'topics', index: 'topics', width: 100, search: true, resizable: false},
                {name: 'summary', index: 'summary', width: 100, search: true, resizable: false},
                {name: 'relevance', index: 'relevance', width: 100, search: true, resizable: false, hidden: true,},
                {name: 'actions_to_consider', index: 'actions_to_consider', width: 100, search: true, resizable: false, hidden: true,},
                {name: 'kol_id', index: 'kol_id', width: 100, search: true, resizable: false},
                {name: 'created_user', index: 'created_user', width: 90, search: true, resizable: false},
                {name: 'created_on', index: 'created_on', width: 90, search: true, resizable: false},
                {name: 'eAllowed', index: 'eAllowed', width: 0, hidden: true},
                {name: 'dAllowed', index: 'dAllowed', width: 0, hidden: true},
                {name: 'act', width: 50, hidden: false, align: 'center', search: false}
            ],
            postData: postData,
            rowNum: 10,
            multiselect: false,
            rownumbers: true,
            autowidth: false,
            width: gridWidth,
            loadonce: false,
            ignoreCase: true,
            hiddengrid: false,
            height: "auto",
            pager: '#listCoachingsPage',
            mtype: "POST",
            sortname: 'name',
            viewrecords: true,
            sortorder: "desc",
            shrinkToFit: true,
            jsonReader: {repeatitems: false, id: "0"},
            caption: 'Medical Insight',
            gridComplete: function () {
                //Get array of id'f from jqgrid			   
                var arrIds = jQuery("#listCoachingsResultSet").jqGrid('getDataIDs');
                // Loop trough each row(id) and prepare a microview, edit and delete links and update the perticular row
                var roleId = '<?php echo $this->session->userdata('user_role_id') ?>';
                var role = '<?php echo ROLE_MANAGER ?>';
                for (var i = 0; i < arrIds.length; i++) {
                    var id = arrIds[i];
                    var rowData = jQuery('#listCoachingsResultSet').jqGrid('getRowData', id);
//                                        alert(JSON.stringify(rowData.dAllowed));
                    //Edit and Delete labels 
                    var actionLink = '';
                    if ((rowData.eAllowed == 'true')) {
//					    	editDeleteLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editMedicalInsight('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\">&nbsp;</a></div><div class='actionIcon deleteIcon' onclick=\"deleteMedicalInsight('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></div>";
//					    	jQuery("#listCoachingsResultSet").jqGrid('setRowData',arrIds[i],{act:editDeleteLink});
                        actionLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editMedicalInsight('" + id + "'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\">&nbsp;</a></div>";


                    }
                    if ((rowData.dAllowed == 'true')) {
//					    	editDeleteLink = "<div class='actionIconsContainer tooltip-demo tooltop-left'><div class='actionIcon editIcon' onclick=\"editMedicalInsight('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Edit\">&nbsp;</a></div><div class='actionIcon deleteIcon' onclick=\"deleteMedicalInsight('"+id+"'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></div>";
//					    	jQuery("#listCoachingsResultSet").jqGrid('setRowData',arrIds[i],{act:editDeleteLink});
                        actionLink += "<div class='actionIcon deleteIcon' onclick=\"deleteMedicalInsight('" + id + "'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></div>";
                    }
                    jQuery("#listCoachingsResultSet").jqGrid('setRowData', arrIds[i], {act: actionLink});
                    //Microview label	

                    microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewMedicalInsight('" + id + "'); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"View Medical Insight\">&nbsp;</a></div></label>";
                    jQuery("#listCoachingsResultSet").jqGrid('setRowData', arrIds[i], {micro: microviewLink});
                }
                jQuery("#listCoachingsResultSet").jqGrid('navGrid', 'hideCol', "id");
                //Initialize the tooltips
                initializeCustomToolTips();
                var postParams = $('#listCoachingsResultSet').getGridParam("postData");
                //alert(postParams.toSource());
                postParams = JSON.stringify(postData);
                $("#filters").val(postParams);

            },
            rowList: paginationValues

        });
        jQuery("#listCoachingsResultSet").jqGrid('navGrid', '#listCoachingsPage', {edit: false, add: false, del: false, search: false, refresh: false});
        //Toolbar search bar below the Table Headers
        jQuery("#listCoachingsResultSet").jqGrid('filterToolbar', {stringResult: true, searchOnEnter: false, defaultSearch: "cn"});
        //Toggle Toolbar Search 
        jQuery("#listCoachingsResultSet").jqGrid('navButtonAdd', "#listCoachingsPage", {caption: "Search", buttonicon: "ui-icon-search", title: "Toggle Search",
            onClickButton: toggleSearchToolbar
        });
          if (currentController != "kols"){
        var buttonsText = "<div style='float:right;  margin-right: 21px;' class='title-bar-actions'>";
            buttonsText += '<input type="button" id="allUserRecord" value="All User Records" onclick="allUserRecords();" class="toggle-button" style="margin-top:-3px;">';
            buttonsText += "</div>";
             $("#coachingsList .ui-jqgrid-titlebar").append(buttonsText);
         }
        jQuery("#listCoachingsResultSet").jqGrid('navButtonAdd', "#listCoachingsPage", {caption: toggleJqgridColumnsCaption, title: toggleJqgridColumnsCaption,
            onClickButton: toggleGridColumns
        });
    }

  
    
    function allUserRecords(){
        $('#allUserRecord').val() == "All User Records" ? allUserRecordLoad() : myRecords();
        }
    function allUserRecordLoad() {
        $("select").find('option').removeAttr("selected");
        allUser=1;
        list_coaching_grid(allUser);
        $('#allUserRecord').val("My Records");

}

function myRecords() {
        allUser=0;
        list_coaching_grid(allUser);
        $('#allUserRecord').val("All User Records");

}
    function export_excel() {




        var excelFilters = '';

var postParams = $('#listCoachingsResultSet').getGridParam("postData");




        $(".gridWrapper .ui-jqgrid tr.ui-search-toolbar th input").each(function () {

          if($(this).val() != ''){

            var filterName = $(this).attr('name');
             if(filterName=="generic_id")
                filterName="Id";
            if(filterName=="specialty")
                filterName="Therapeutic Area";
            if(filterName=="product")
                filterName="Product";
            if(filterName=="source_type")
                filterName="Source Type";
              if(filterName=="agent")
                filterName="Agent";
              if(filterName=="topics")
                filterName="Topics";
              if(filterName=="sphere_of_influence")
                filterName="Sphere of Influence";
              if(filterName=="congress_sources")
                filterName="Congress Source";
              if(filterName=="congress_name")
                filterName="Congress Name";
              if(filterName=="summary")
                filterName="Summarize Medical Insight";
              if(filterName=="relevance")
                filterName="Describe Relevance to OPDC";
              if(filterName=="actions_to_consider")
                filterName="Actions to Consider";
            if(filterName=="kol_id")
                filterName="<?php echo lang("HCP"); ?> Name";
                if(filterName=="created_user")
                filterName="Recorded By";
             if(filterName=="created_on")
                filterName="Recorded On";

            var filterValue = $(this).val();

            excelFilters += filterName+" : "+filterValue+",";

    }
//                                        alert(excelFilters);

        });

        //$("#excel-filters").val(excelFilters);

        var selectedOPtion = $(".ui-pg-selbox").val();

        $(".ui-pg-selbox option:last").attr('selected', 'selected');

        $('.ui-pg-selbox').trigger('change');

        if ($("#listCoachingsResultSet").html() != null)
            var arrIds = jQuery("#listCoachingsResultSet").jqGrid('getDataIDs');

        else
            var arrIds = jQuery("#listPaymentsResultSet").jqGrid('getDataIDs');
//                            alert(arrIds);

//            if($('#orgIntaerctionContainer').css('display')!='block'){
//
//            
//
//                $('#ids').val(arrIds);
//
//            }







        $('#ids').val(arrIds);
        $("#excel-filters").val(excelFilters);
        $("#gridFilter").val(JSON.stringify(postParams));
        //    return false;

        $('#export').submit();

        $(".ui-pg-selbox option[value=" + selectedOPtion + "]").attr('selected', 'selected');

        $('.ui-pg-selbox').trigger('change');

    }
</script>
<form action="" name="medicalInsightFilterForm" id="medicalInsightFilterForm">

			<table class="table">

				<tr>

                                    <td style="width:100px;">

						<p>

						<label for=monthlyreport>Start Date:</label>

							<input type="text" name="start_date" id="start_date" >

						</p>

					</td>

					<td style="width:100px;">

						<p>

							

							<label for=monthlyreport>End Date:</label>

							<input type="text" name="end_date" id="end_date" />

						</p>

					</td>
                                        <?php if($this->session->userdata('user_role_id')!=ROLE_USER) {?>
                                        <td style="width:100px;">

						<p>

							

						<label for=monthlyreport>Manager Name:</label>
                                                <select name="manager_name" id="managers">
	            				<option value="">Select</option>
		            			<?php 
					                foreach($arrManager as $key=>$arrRow){
		            		        $selected    = '';?>
		                    		<option value="<?php echo $arrRow['id']?>"><?php echo $arrRow['first_name']?>&nbsp;<?php echo $arrRow['last_name']?></option>;
		                		<?php }?>
				        	</select>
							

						</p>

					</td>   <?php } ?>
                                        <td>
                                           <p id="">

				<input type="button" value="Apply Filters" onclick="generateMedicalInsightReport();"/>
<!--				<input type="reset" value="Reset Filters" />-->

			</p> 
                                        </td>
				</tr>

				
			

			</table>

			

			

		</form>
<div id="container">
<?php if ($this->common_helpers->isActionAllowed('medical insight', 'add')) { ?>
        <div class="exportOptionsContainer">
            <ul class="pageRightOptions addMedical">
                <li>
                    <a href="#" class="NewBlueButton NewAddIcon" onclick="addMedicalInsight();">Add Medical Insight</a>						
                </li>
                <li>
                    <div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="export_excel();" style="float:right;  position: relative;">
                        <a href="#" rel="tooltip" data-original-title="Export Medical Insight Detail into Excel format">&nbsp;</a>
                    </div>					
                </li>
            </ul>
        </div>
<?php } ?>
    <div id="coachingsList" class="clear"></div>
    <form action="<?php echo base_url() ?>coachings/export_medical_insight_details_new/" method='post' id="export">
        <input type="hidden" id="ids" name="medical_ids" value=""></input>
        <input type="hidden" value="" name="filters" id="excel-filters"></input>
        <input type="hidden" value="<?php echo $kol_id; ?>" name="kolId" id="kolId"></input>
        <input type="hidden" name="grid_filter" id="gridFilter" />
        <input type="hidden" value="" name="allUserFlag" id="allUserFlag"></input>
    </form>
</div>