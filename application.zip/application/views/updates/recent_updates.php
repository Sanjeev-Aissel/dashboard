<?php
/**
*View file to display recent updates
*@author Ramesh B
*@since 4.2
*@package application.controllers	
*@created on 05-07-2012
*/
?>

<?php 
	/** @Author Ramesh B
     ** @since  24 Aug 2012
     ** The following code is used to disable caching in IE
	 **/
	$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
	$this->output->set_header("Pragma: no-cache"); 
?>
<label id="update-label">Recent Activity </label>
<div id='updates-list'>
<div style="margin-bottom: 10px; margin-top: -30px; border-bottom: 1px dotted; padding-bottom: 5px;">
	
	 <div id="activities-filters">
		<?php if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN){?>
		<label for="start_date">Start Date:</label>
		<input id="start_date"  type="text" value="" name="start_date" size='10' />
		<label for="end_date">End Date:</label>
		<input id="end_date"  type="text" value="" name="end_date" size='10' />
		<label id="users-list-label">User</label>	
		<select id="usersname" name="usersname" style="width: 120px">
			<option value="0">All</option>
			<?php foreach($clientUsers as $key => $value){?>
				<option value="<?php echo $value['id'];?>"> <?php echo $value['first_name']." ". $value['last_name'];?></option>
			<?php }?>
		</select>
		<?php }?>
		<label id="category-list-label">Category</label>
		<select id="category-list" name="category" style="width: 120px">
			<option value="0">All</option>
			<?php foreach($arrModules as $key => $value){?>
				<?php if($key != 'coaching'){?>
					<option value="<?php echo $key;?>"> <?php echo $value;?></option>
				<?php }?>
			<?php }?>
		</select>
                <input type="text" id="influenceKolNameOutside" name="influence_kol_name_outside" placeholder="Enter KTL Name" class="autocompleteInputBox  enter-kol-name" >
		<input type="hidden" id="influenceKolNameOutsideKolId" name="influence_kol_id_outside" value="">
		
<!--		<select name="view_type" id="viewType" style="width:150px;">
			<option value="1" selected="selected">My Contacts</option>
			<option value="2">All Contacts</option>
		</select>
				-->
		<input type="button" value="Submit" id="submit" />
		<!-- button type="button" id="submit">Submit</button-->
	</div>	
</div>
		
 <?php if($this->uri->segment(2) == 'show_updates_analyst'){?>
	<div style="margin-bottom: 12px; border-bottom: 1px solid rgb(218, 218, 218);">
		<input type="checkbox" id="select-all"/>
		<label for="select-all">Select All</label>
		<a href='#' class='publish-toggle-llink-all pl' style="margin-left: 15px;" onclick="publishUnpublishSelected(1);">Publish</a>
		<a href='#' class='publish-toggle-llink-all upl' style="margin-left: 15px;" onclick="publishUnpublishSelected(0);">UnPublish</a>
		<a href='#' class='delete-link-all' style="margin-left: 15px;" onclick="deleteSelected();" title="delete"></a>
	</div>
<?php }?>	

<?php
	$this->load->view('updates/update_element');		
?>

<!-- Container for the 'Publication Micro Profile' modal box -->
	<div id="dailog1">	
		<div id="pubMicroProfile" class="microProfileDialogBox">
			<div class="profileContent"></div>
		</div>
	</div>
<!--End of  Container for the 'Publication Micro Profile' modal box -->

<!-- Container for the 'Kol Micro Profile'  box -->
	<div id="contentHolder" class="callOutTest microView" style="display: none;">
		<div>
			<a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeKolProfile();" class="ui-icon ui-icon-closethick">close</span></a>
			<!--<img class="ui-icon ui-icon-closethick" alt="" src="" onclick="closeKolProfile();" />
		--></div>
		<div class="profileContent"></div>
	</div>
	<div id="arraouHolder" class="callOutTest" style="display: none;"><div class="arrowMarkIcon"></div></div>
	
<!-- Container for the 'Clinical Trial Micro Profile' modal box -->
	<div id="dailog2">	
		<div id="trialMicroProfile" class="microProfileDialogBox">
			<div class="profileContent"></div>
		</div>
	</div>
<!--End of  Container for the 'Clinical Trial Micro Profile' modal box -->

<!-- Container for the 'Affiliation Micro Profile' modal box -->
	<div id="dailog3">	
		<div id="affMicroProfile" class="microProfileDialogBox">
			<div class="profileContent"></div>
		</div>
	</div>
<!--End of  Container for the 'Affiliation Micro Profile' modal box -->

<!-- Container for the 'Event Micro Profile' modal box -->
	<div id="dailog3">	
		<div id="eventMicroProfile" class="microProfileDialogBox">
			<div class="profileContent"></div>
		</div>
	</div>
<!--End of  Container for the 'Event Micro Profile' modal box -->

	<!-- Container for the 'Interaction Micro Profile' modal box -->
	<div id="dailog4">	
		<div id="interactionMicroProfile" class="microProfileDialogBox">
			<div class="profileContent"></div>
		</div>
	</div>
	<!--End of  Container for the 'Interaction Micro Profile' modal box -->
	
	<!-- Container for the 'Interaction Micro Profile' modal box -->
	<div id="dailog5">	
		<div id="paymentMicroProfile" class="microProfileDialogBox">
			<div class="profileContent"></div>
		</div>
	</div>
	<!--End of  Container for the 'Interaction Micro Profile' modal box -->

</div>
<div id="lastPostsLoader">
	<img src="../images/ajax-loader-round.gif" />
</div>	
<style type="text/css">
.update-row{
    border-bottom: 1px dotted;
    font-size: 12px;
    margin-bottom: 4px;
    min-height: 38px;
}

.update-small-content{
	margin-left: 94px;
	 <?php if($this->uri->segment(2) == 'show_updates_analyst'){?>
		margin-left: 108px;
	<?php }?>
	padding-bottom: 4px;
	overflow: hidden;
}
.update-row span.human-time{
	color: green;
    float: right;
    font-size: 11px;
}

#all-updates-link{
	float: right;
}

div#load-more{
	display: block;
	text-align: center;
}
.category-box{
	width: 80px;
	float: left;
	-moz-border-radius: 5px 5px 5px 5px;
	background: none repeat scroll 0 0 #20DAFF;
	color: #fff;
	text-align: right;
	padding-right: 5px;
}
span.microViewIcon {
  /* background: url("http://localhost/iprofile_crm/images/kolm-sprite-image.png") repeat scroll -241px 28px transparent; */
  cursor: pointer;
  display: inline;
  /* float: left; */
  height: 20px;
  margin-right: 6px;
  position: absolute;
  width: 22px;
  margin: 3px;
}

.microViewIcon.Male {
  /* background-position: 32px 237px !important; */
  /*background: url("../images/male_kol_profile.svg") no-repeat scroll 0 -2px / 17px auto;*/
  background: rgba(0, 0, 0, 0) url("../images/microview_inactive.png") no-repeat scroll 0 -1px / 17px auto;
}
.category-overview{
	background: none repeat scroll 0 0 #2B8B94;
}
.category-status{
	background: none repeat scroll 0 0 #2B8B94;
}
.category-education{
	background: none repeat scroll 0 0 #5E1D6B;
}
.category-affiliation{
	background: none repeat scroll 0 0 #FFFA70;
	color: #000;
}
.category-event{
	background: none repeat scroll 0 0 #20DAFF;
}
.category-publication{
	background: none repeat scroll 0 0 #A8BEDB;
}
.category-trial{
	background: none repeat scroll 0 0 #DEE7FA;
}
.category-interaction{
	background: none repeat scroll 0 0 #A21D38;
}
.category-payment{
	background: none repeat scroll 0 0 #631b00;
}
.update-full-content{
	display: none;
	min-height: 50px;
	background-color: #EEEEEE;
	overflow: hidden;
}
span.expand-image{
    background-image: url("../images/exp.gif");
    background-repeat: no-repeat;
    cursor: pointer;
    height: 16px;
    margin-left: 10px;
    margin-top: 5px;
    position: absolute;
    width: 16px;
}
span.collapse{
	background-image: url("../images/collapse.gif");
}

.update-row-detailed .text-line{
	float: left;
}
.update-row-detailed div.microViewIcon{
	float: left;
	margin-left: 10px;
}
.update-row-detailed{
	float: left;
	width: 100%;
	background-color: #EEEEEE;
}

span.microViewIcon {
    background: url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat scroll -241px 28px transparent;
    <?php if($this->uri->segment(2) == 'show_updates_analyst'){?>
		 background: url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat scroll -262px 235px transparent;
	<?php }?>
    cursor: pointer;
    display: inline;
    float: left;
    height: 16px;
    margin-right: 10px;
    position: absolute;
    width: 22px;
}

#update-label{
	font-size: 18px;
    position: relative;
    top: -32px;
}
#category-list{
	margin-bottom: 0px;
}

div#lastPostsLoader{
	text-align: center;
	background-color: #eeeeee;
	display: none;
}
.update-full-content div.loader-indicater{
	text-align: center;
	background-color: #eeeeee;
}
.created-by{
	color: #000000;
    float: left;
    font-size: 12px;
    font-style: italic;
    width: 100%;
}
#category-list-label{
    margin-right: 6px;
    margin-top: 7px;
}
#activities-filters{
	/*margin-left: 30px;*/
	display: inline;
	<?php if($this->session->userdata('user_role_id') == ROLE_USER )
		echo "margin-left: 540px;";
	?>
}
.profileContent{
     height: 400px !important;
        overflow-y:scroll !important;
}
div#contentHolder{
	z-index: 2 !important;
      
       
        width:600px !important;
}
div#arraouHolder{
	z-index: 3 !important;;
}
.analyst-links{
	display: inline-block;
    float: right;
    margin-right: 70px;
    margin-top: -33px;
}
.analyst-links a{
	margin-right: 9px;
}
.publish-toggle-llink, .publish-toggle-llink-all{
	height: 19px;
    padding-top: 3px;
    text-decoration: none;
}
.upl, .upl:VISITED{
	color:blue;
	background-color: #8DB817;
    border-radius: 5px 5px 5px 5px;
    color: white;
    display: inline-block;
    text-align: center;
    width: 72px;
}
.pl, .pl:VISITED{
	background-color: #3B98C4;
    border-radius: 5px 5px 5px 5px;
    color: white;
    display: inline-block;
    text-align: center;
    width: 52px;
}
.publish-toggle-llink:HOVER, .publish-toggle-llink-all:HOVER{
	color:black;
}
.delete-link, .delete-link-all{
	background: url("../images/kolm-sprite-image.png") repeat scroll -181px 834px transparent;
    display: inline-block;
    height: 18px;
    margin-top: 2px;
    vertical-align: middle;
    width: 18px;
}
.activities-select{
	float:left;
}
.checkbox-place-holder{
	display: inline-block;
    float: left;
    height: 20px;
    width: 20px;
}
 .category-keypeople{
 background: none repeat scroll 0 0 #6C6C6C !important;
 }
 .category-formulary{
	background: none repeat scroll 0 0 #7CBCBC; 
 }
 
 .category-disiease{
	background:none repeat scroll 0 0 #20C0FF;
 }
 
 .orgRecent{
	position: absolute !important; 
 }
<?php $mobile = mobile_device_detect(); 
if(isset($mobile[1])){
echo "#activities-filters{";
echo "margin-left: 25px;";
echo "display: inline;";
echo "font-size: 11px;";
if($this->session->userdata('user_role_id') == ROLE_USER)
	echo "margin-left: 525px;";
echo "}";		
}?>			



</style>
<script src="<?php echo base_url();?>js/jquery/jquery-ui-1.8.16.datepicket.js" type="text/javascript"></script>
<script type="text/javascript">
// Browser back button reset, it will reset the value before page gets unloaded
// Don't use this when you are submitting the form, it will unset and send the vlaue
$(window).bind('beforeunload', function() 
        { 
           $("#category-list").val(0);
           $("#username").val(0);
           $("#start_date").val("");
           $("#end_date").val("");
        } 
    );

var kolName = "";
var kolNameOutsideAutoCompleteOptions = {
		serviceUrl: base_url+'kols/get_kol_names_for_all_autocomplete',
		width: 278, 
		delimiter: /(,|;)\s*/, 
		deferRequestBy: 200, 
		noCache: true, minChars: 3,
		onSelect : function(event, ui) {
			var kolId = $(event).children('.id1').html();
			var selText = $(event).children('.kolName').attr('name');
			selText=selText.replace(/\&amp;/g,'&');
			kolName = selText;
			$('#influenceKolNameOutside').val(selText);
			$('#influenceKolNameOutsideKolId').val(kolId);
			//$('#kolIdForAutocomplete').val(kolId);
			if(selText.length>20){
				if(selText.substring(0,21)=="No results found for "){
					return false;
				}else{
					//loadKolInfluenceData(kolId);
				}
			}else{
				//loadKolInfluenceData(kolId);
			}
		}
	};
var  b;

$(document).ready(function(){
	// Trigger the Autocompleter for 'KOl Name' field
	b= $('#influenceKolNameOutside').autocomplete(kolNameOutsideAutoCompleteOptions);

	$('#influenceKolNameOutside').focus(function(){
		if($(this).val() == "Enter KTL Name")
			$('#influenceKolNameOutside').val('');
		$(this).addClass("enter-kol-name");
	});
	       
	$('#influenceKolNameOutside').blur(function(){
		if($(this).val() == ''){
			$('#influenceKolNameOutside').val('Enter KTL Name');
			$(this).removeClass("enter-kol-name");
			$('#influenceKolNameOutsideKolId').val('');
		}
		else{
			if($('#influenceKolNameOutside').val() != kolName)
				$('#influenceKolNameOutsideKolId').val('');
		}
		
		if($(this).val() == "Enter KTL Name"){
			$(this).addClass("enter-kol-name");
		}
	});

	
	
	
	$('#start_date').datepicker({
		dateFormat: 'mm/dd/yy'
	});

	$('#end_date').datepicker({
		dateFormat: 'mm/dd/yy'
	});
	
	$(window).scroll(function(){
        if  ($(window).scrollTop() == $(document).height() - $(window).height() || $(window).scrollTop() == $(document).height() - $(window).height()-1){
        	lastAddedLiveFunc();
        }
	}); 

	////Expand or collapse the updates content and load the content if not loaded
	$("span.expand-image").live("click",function(){
		$(this).parent().next().toggle();
		//Expand or collapse the updates content
		if($(this).hasClass('collapse')){
			$(this).children('.tooltipLink').attr("data-original-title","Expand to view the updated data");
			$(this).removeClass('collapse');
		}else{
			$(this).addClass('collapse');
			$(this).children('.tooltipLink').attr("data-original-title","Collapse");
		}

		//load the content if not loaded
		if($(this).parent().next().hasClass('loaded')){
			//Do nothing
		}else{
			//Send a request to load the content
			var data = {};
			data['utype'] = $(this).parent().attr('utype');
			data['pid'] = $(this).parent().attr('pid');
			data['cday'] = $(this).parent().attr('cday');
			data['cby'] = $(this).parent().attr('cby');
			var fullContentObj = $(this).parent().next();
			$(fullContentObj).html("<div class='loader-indicater'><img src='../images/ajax-loader-round.gif'></div>");
			$.ajax({
			 	type: 'POST',
		  	  	data: data,
			  	url: base_url+'updates/get_detailed_updates',
			  	dataType: 'text',
		      	success: function(returnData) {
					$(fullContentObj).html(returnData);
		  		},
		  		complete:function(){
		  			$(fullContentObj).addClass('loaded');
			  	}	
			});
			
		}
		return false;
	});

	//Delete activity ajax function
	$(".delete-link").live("click",function(){
		if(jConfirm("Are you sure you want to delete selected activities.?")){
			var data = {};
			data['utype'] = $(this).parent().prev().prev().attr('utype');
			data['pid'] = $(this).parent().prev().prev().attr('pid');
			data['cday'] = $(this).parent().prev().prev().attr('cday');
			data['cby'] = $(this).parent().prev().prev().attr('cby');
			var fullContentObj = $(this).parent().parent();
			$(fullContentObj).block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
			$.ajax({
			 	type: 'POST',
		  	  	data: data,
			  	url: base_url+'updates/delete_activities',
			  	dataType: 'text',
		      	success: function(returnData) {
					if(returnData == 1)
						$(fullContentObj).remove();
	
					$(fullContentObj).unblock();
		  		}
			});
		}
		return false;
	});


	//Update activity publish status
	$(".publish-toggle-llink").live("click",function(){
		//Send a request to load the content
		var data = {};
		data['utype'] = $(this).parent().prev().prev().attr('utype');
		data['pid'] = $(this).parent().prev().prev().attr('pid');
		data['cday'] = $(this).parent().prev().prev().attr('cday');
		data['cby'] = $(this).parent().prev().prev().attr('cby');
		var changeStatus = 0;
		if($(this).html() == "Publish")
			changeStatus = 1;
		else
			changeStatus = 0;

		data['publish_status'] = changeStatus;
		var fullContentObj = $(this).parent().parent();
		var thisObj = this;
		$(fullContentObj).block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		$.ajax({
		 	type: 'POST',
	  	  	data: data,
		  	url: base_url+'updates/update_activity_status',
		  	dataType: 'text',
	      	success: function(returnData) {
				if(returnData == 1){
					if(changeStatus == 1){
						$(thisObj).html("UnPublish");
						$(thisObj).removeClass('pl').addClass('upl');
					}
					else{
						$(thisObj).html("Publish");
						$(thisObj).removeClass('upl').addClass('pl');
					}
				}else{
					
				}
				$(fullContentObj).unblock();
	  		}
		});
		return false;
	});

	
	$("#select-all").live("click",function(){
		if($(this).attr('checked') == 'checked'){
			$.each($(".activities-select input[name='activities[]']"), function() {
				$(this).attr("checked","checked");
			});
		}else{
			$.each($(".activities-select input[name='activities[]']"), function() {
				$(this).removeAttr("checked");
			});
		}
	});


	// Settings for the Dialog Box
	var pubMicroProfileDialogOpts = {
			title: "Publication Snapshot",
			modal: true,
			autoOpen: false,
			width: 800,
			dialogClass: "microView",
			open: function() {
				//display correct dialog content
			}
	};
	
	$("#pubMicroProfile").dialog(pubMicroProfileDialogOpts);	

	// Settings for the Dialog Box
	var trialMicroProfileDialogOpts = {
			title: "Clinical Trial Snapshot",
			modal: true,
			autoOpen: false,
			width: 800,
			dialogClass: "microView",
			open: function() {
				//display correct dialog content
			}
	};
	
	$("#trialMicroProfile").dialog(trialMicroProfileDialogOpts);

	// Settings for the Dialog Box
	var affMicroProfileDialogOpts = {
			title: "Affiliation Snapshot",
			modal: true,
			autoOpen: false,
			width: 800,
			dialogClass: "microView",
			open: function() {
				//display correct dialog content
			}
	};
	
	$("#affMicroProfile").dialog(affMicroProfileDialogOpts);

	// Settings for the Dialog Box
	var eventMicroProfileDialogOpts = {
			title: "Event Snapshot",
			modal: true,
			autoOpen: false,
			width: 800,
			dialogClass: "microView",
			open: function() {
				//display correct dialog content
			}
	};
	
	$("#eventMicroProfile").dialog(eventMicroProfileDialogOpts);

	// Settings for the Dialog Box
	var interactionMicroviewDialogOpts = {
			title: "",
			modal: true,
			autoOpen: false,
			width: 800,
			dialogClass: "microView",
			position: ['center', 130],
			open: function() {
				//display correct dialog content
			}
	};
	
	$("#interactionMicroProfile").dialog(interactionMicroviewDialogOpts);

	// Settings for the Dialog Box
	var paymentMicroviewDialogOpts = {
			title: "",
			modal: true,
			autoOpen: false,
			width: 800,
			dialogClass: "microView",
			position: ['center', 130],
			open: function() {
				//display correct dialog content
			}
	};
	
	$("#paymentMicroProfile").dialog(interactionMicroviewDialogOpts);

	//Called on category selection change
	$('#submit').click(function(){
		var categoryId 	= $('#category-list').val();
    	var userId		= $('#usersname').val();
    	var startDate	= $('#start_date').val();
    	var endDate		= $('#end_date').val();
    	var viewType	= $('#viewType').val();	
    	var kolId		= $('#influenceKolNameOutsideKolId').val();
    	var data={};
		data['start_from']	=	0;
		data['category_id'] = categoryId;
		data['user_id']		= userId;
		data['start_date']	= startDate;
		data['end_date']	= endDate;
		data['view_type']	= viewType;
		data['kol_id']		= kolId; 
		
		<?php if($this->uri->segment(2) == 'show_updates_analyst'){?>
			data['is_analyst_app']	= true;
		<?php }?>

		$('#updates-list').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		
		$.ajax({
		 	type: 'POST',
	  	  	data: data,
		  	url: base_url+'updates/show_updates',
		  	dataType: 'text',
	      	success: function(returnData) {
	      		$('.update-row').remove();
				if (returnData != "") {
					$("#updates-list").append(returnData);
				}
				$('#updates-list').unblock().removeAttr('style');
	  		}	
		});
	});

    /*$('#submit').click(function(){
    	var categoryId 	= $('#category-list').val();
    	var userId		= $('#usersname').val();
    	var startDate	= $('#start_date').val();
    	var endDate		= $('#end_date').val();	
    	var data={};
		data['start_from']	=	0;
		data['category_id'] = categoryId;
		data['user_id']		= userId;
		data['start_date']	= startDate;
		data['end_date']	= endDate;
        
		$.ajax({
			url:base_url+'updates/show_updates',
			dataType:'json',
			data:data,
			type:'post',
			success:function(returnData){
				if(returnData.status=='success'){
					closeModelBox();
				}else{
					$('#msgbox').css('display','block');
					$('#msgbox').text(returnData.status);
					$('#msgbox').fadeOut(1000);
				}
			}
		});	
    });*/
});

function deleteSelected(){
	if(jConfirm("Are you sure you want to delete selected activities.?")){
		var selectedActivities = new Array();
		$.each($(".activities-select input[name='activities[]']:checked"), function() {
			selectedActivities.push($(this).val());
		});
	
		var data = {};
		data['selected_activities'] = selectedActivities;
		$("#updates-list").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		$.ajax({
		 	type: 'POST',
	  	  	data: data,
		  	url: base_url+'updates/delete_selected_activities',
		  	dataType: 'text',
	      	success: function(returnData) {
				$.each($(".activities-select input[name='activities[]']:checked"), function() {
					$(this).parent().parent().remove();
				});
				$('#updates-list').unblock().removeAttr('style');
	  		}
		});
	}
	return false;
}

function publishUnpublishSelected(changeStatus){
	var selectedActivities = new Array();
	$.each($(".activities-select input[name='activities[]']:checked"), function() {
		selectedActivities.push($(this).val());
	});

	var data = {};
	data['publish_status'] = changeStatus;
	data['selected_activities'] = selectedActivities;
	$("#updates-list").block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
	$.ajax({
	 	type: 'POST',
  	  	data: data,
	  	url: base_url+'updates/update_selected_activities',
	  	dataType: 'text',
      	success: function(returnData) {
			$.each($(".activities-select input[name='activities[]']:checked"), function() {
				if(changeStatus == 1){
					$(this).parent().parent().find('.publish-toggle-llink').html("UnPublish");
					$(this).parent().parent().find('.publish-toggle-llink').removeClass('pl').addClass('upl');
				}
				else{
					$(this).parent().parent().find('.publish-toggle-llink').html("Publish");
					$(this).parent().parent().find('.publish-toggle-llink').removeClass('upl').addClass('pl');
				}
				$(this).removeAttr('checked');
			});
			$('#updates-list').unblock().removeAttr('style');
  		}
	});
	return false;
}

function viewPubMicroProfile(pubId){
	$("#pubMicroProfile .profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#pubMicroProfile").dialog("open");
	$("#pubMicroProfile .profileContent").load(base_url+'pubmeds/view_micro_pub/'+pubId);
	return false;
}

/**
* Opens the Modal Box with the Micro Profile content of KOL
* @param: kolId
*/
function viewKolMicroProfile(kolId, rowId,thisEle){
	//var elmt=document.getElementById("micro-"+rowId+"");	
	var pos = getElementAbsolutePos(thisEle);
	//jAlert(pos.x);
	var offset = $(thisEle).offset();
	var height = $(thisEle).height();
	var xPos=pos.x+31;
	var yPos=offset.top + height - 60;//pos.y-45;
	
	//$("#callOutTest").css({'position': 'absolute','top':yPos,'left':xPos});
	//$("#callOutTest").show();
	
	$("#arraouHolder").css({'position': 'absolute','top':yPos-10,'left':xPos-11});
	$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos});
	
	//$("#arraouHolder").css({'position': 'absolute','top':yPos-15,'left':xPos+50});
	//$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos+30});
	$("#arraouHolder").show();
	$("#contentHolder").show();

	$("#contentHolder .profileContent").html("");
	//$("#contentHolder").html("<div class='microViewLoading'>Loading...</div>");
	$('#contentHolder .profileContent').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});		


	$("#contentHolder .profileContent").load(base_url+'kols/view_kol_micro/'+kolId,{},
			function(){	$('#contentHolder .profileContent').unblock(); }
		);
	
	return false;
}
function viewKolMicroProfileKolLocation(kolId, rowId,thisEle){
	//var elmt=document.getElementById("micro-"+rowId+"");	
	var pos = getElementAbsolutePos(thisEle);
	//jAlert(pos.x);
	var offset = $(thisEle).offset();
	var height = $(thisEle).height();
	var xPos=pos.x+31;
	var yPos=offset.top + height - 60;//pos.y-45;
	
	//$("#callOutTest").css({'position': 'absolute','top':yPos,'left':xPos});
	//$("#callOutTest").show();
	
	$("#arraouHolder").css({'position': 'absolute','top':yPos-10,'left':xPos-11});
	$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos});
	
	//$("#arraouHolder").css({'position': 'absolute','top':yPos-15,'left':xPos+50});
	//$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos+30});
	$("#arraouHolder").show();
	$("#contentHolder").show();

	$("#contentHolder .profileContent").html("");
	//$("#contentHolder").html("<div class='microViewLoading'>Loading...</div>");
	$('#contentHolder .profileContent').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});		


	$("#contentHolder .profileContent").load(base_url+'kols/view_location/'+kolId,{},
			function(){	$('#contentHolder .profileContent').unblock(); }
		);
	
	return false;
}

function viewKolMicroProfileSpeaker(kolId, rowId,thisEle){
	//var elmt=document.getElementById("micro-"+rowId+"");	
       
	var pos = getElementAbsolutePos(thisEle);
	//jAlert(pos.x);
	var offset = $(thisEle).offset();
	var height = $(thisEle).height();
	var xPos=pos.x+31;
	var yPos=offset.top + height - 60;//pos.y-45;
	
	//$("#callOutTest").css({'position': 'absolute','top':yPos,'left':xPos});
	//$("#callOutTest").show();
	
	$("#arraouHolder").css({'position': 'absolute','top':yPos-10,'left':xPos-11});
	$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos});
	
	//$("#arraouHolder").css({'position': 'absolute','top':yPos-15,'left':xPos+50});
	//$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos+30});
	$("#arraouHolder").show();
	$("#contentHolder").show();

	$("#contentHolder .profileContent").html("");
	//$("#contentHolder").html("<div class='microViewLoading'>Loading...</div>");
	$('#contentHolder .profileContent').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});		


	$("#contentHolder .profileContent").load(base_url+'speaker_evaluations/view_micro_detail/'+kolId,{},
			function(){	$('#contentHolder .profileContent').unblock(); $(".formContainer").children()[0].remove();}
		);
	
	return false;
}
function viewKolMicroProfileKolLocation(kolId, rowId,thisEle){
	//var elmt=document.getElementById("micro-"+rowId+"");	
	var pos = getElementAbsolutePos(thisEle);
	//jAlert(pos.x);
	var offset = $(thisEle).offset();
	var height = $(thisEle).height();
	var xPos=pos.x+31;
	var yPos=offset.top + height - 60;//pos.y-45;
	
	//$("#callOutTest").css({'position': 'absolute','top':yPos,'left':xPos});
	//$("#callOutTest").show();
	
	$("#arraouHolder").css({'position': 'absolute','top':yPos-10,'left':xPos-11});
	$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos});
	
	//$("#arraouHolder").css({'position': 'absolute','top':yPos-15,'left':xPos+50});
	//$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos+30});
	$("#arraouHolder").show();
	$("#contentHolder").show();

	$("#contentHolder .profileContent").html("");
	//$("#contentHolder").html("<div class='microViewLoading'>Loading...</div>");
	$('#contentHolder .profileContent').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});		


	$("#contentHolder .profileContent").load(base_url+'kols/view_location/'+kolId,{},
			function(){	$('#contentHolder .profileContent').unblock(); }
		);
	
	return false;
}
function viewOrgMicroProfileLocation(kolId, rowId,thisEle){
	//var elmt=document.getElementById("micro-"+rowId+"");	
	var pos = getElementAbsolutePos(thisEle);
	//jAlert(pos.x);
	var offset = $(thisEle).offset();
	var height = $(thisEle).height();
	var xPos=pos.x+31;
	var yPos=offset.top + height - 60;//pos.y-45;
	
	//$("#callOutTest").css({'position': 'absolute','top':yPos,'left':xPos});
	//$("#callOutTest").show();
	
	$("#arraouHolder").css({'position': 'absolute','top':yPos-10,'left':xPos-11});
	$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos});
	
	//$("#arraouHolder").css({'position': 'absolute','top':yPos-15,'left':xPos+50});
	//$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos+30});
	$("#arraouHolder").show();
	$("#contentHolder").show();

	$(".profileContent").html("");
	//$("#contentHolder").html("<div class='microViewLoading'>Loading...</div>");
	$('#contentHolder .profileContent').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});		


	$("#contentHolder .profileContent").load(base_url+'organizations/view_location/'+kolId,{},
			function(){	$('#contentHolder .profileContent').unblock(); }
		);
	
	return false;
}

/**
* Opens the Modal Box with the Micro Profile content of KOL
* @param: kolId
*/
function viewInteractionMicroProfile(interactionId){
	$("#interactionMicroProfile .profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#interactionMicroProfile").dialog("open");
	$("#interactionMicroProfile .profileContent").load(base_url+'interactions/view_micro_interaction/'+interactionId);
	return false;
}

/**
* Opens the Modal Box with the Micro Profile content of KOL
* @param: kolId
*/
function viewPaymentMicroProfile(paymentId){
	$("#paymentMicroProfile .profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#paymentMicroProfile").dialog("open");
	$("#paymentMicroProfile .profileContent").load(base_url+'payments/view_micro_payment/'+paymentId);
	return false;
}

function closeKolProfile(){
	$("#arraouHolder").hide();
	$("#contentHolder  .profileContent").html("");
	$("#contentHolder").hide();
}

/**
* Opens the Modal Box with the Micro Profile content of KOL
* @param: kolId
*/
function viewClinicalTrialMicroProfile(id){
	$("#trialMicroProfile .profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#trialMicroProfile").dialog("open");
	$("#trialMicroProfile .profileContent").load(base_url+'clinical_trials/view_micro_trial/'+id);
	return false;
}

/**
* Opens the Modal Box with the Micro snapshot content of Affiliation
* @param: affiliationId
*/
function viewAffMicroProfile(id){
	$("#affMicroProfile .profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#affMicroProfile").dialog("open");
	$("#affMicroProfile .profileContent").load(base_url+'kols/view_micro_affiliation/'+id);
	return false;
}	

/**
* Opens the Modal Box with the Micro snapshot content of Event
* @param: eventId
*/
function viewEventMicroProfile(id){
	$("#eventMicroProfile .profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#eventMicroProfile").dialog("open");
	$("#eventMicroProfile .profileContent").load(base_url+'kols/view_micro_event/'+id);
	return false;
}	

var isRequestSent = false;
function lastAddedLiveFunc(){
	if(!isRequestSent){
		isRequestSent = true;
		var categoryId 	= $('#category-list').val();
		var userId		= $('#usersname').val();
		var startDate	= $('#start_date').val();
		var endDate		= $('#end_date').val();
		var viewType	= $('#viewType').val();
		var kolId		= $('#influenceKolNameOutsideKolId').val();
			
		var data={};
		data['start_from']=$(".update-row:last").attr("id");
		data['category_id'] = categoryId;
		data['user_id']		= userId;
		data['start_date']	= startDate;
		data['end_date']	= endDate;
		data['view_type']	= viewType;
		data['kol_id']		= kolId; 
		<?php if($this->uri->segment(2) == 'show_updates_analyst'){?>
			data['is_analyst_app']	= true;
		<?php }?>
		
		if(data['start_from'] != null){
			$('div#lastPostsLoader').show();
			$.ajax({
			 	type: 'POST',
		  	  	data: data,
			  	url: base_url+'updates/show_updates',
			  	dataType: 'text',
		      	success: function(returnData) {
					if (returnData != "") {
						$("#updates-list").append(returnData);
					}
					$('div#lastPostsLoader').hide();
					isRequestSent = false;
		  		}	
			});
		}
	}
}

</script>