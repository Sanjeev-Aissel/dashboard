<?php
/**

 * This is HTML page which lists all the Interactions of the perticular client

 * 

 * @author Ramesh B

 * @Created on: 01-03-11

 * @since  1.5	

 */
?>




<?php
// prepare array of JS files to insert into queue

$queued_js_scripts = array('speakers/list_speakers',
    'i18n/grid.locale-en',
    'jquery.jqGrid.min',
    'jquery/jquery.validate1.9.min',
    'jquery/jquery-ui-1.8.16.slider',
    'jquery/jquery-ui-1.8.16.datepicket',
    'jquery-ui-timepicker-addon 0.9.3',
    'CalendarControl',
    'chosen.jquery'
);

// add the JS files into queue i.e Append to the existing queue

$prevjs = $this->config->item('js_files_to_load');

if ($prevjs == null)
    $prevjs = array();

$this->config->set_item('js_files_to_load', array_merge($prevjs, $queued_js_scripts));

$currentController = $this->uri->segment(1);
?>

<!-- JQGrid Plugins -->

<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url() ?>css/themes/ui.jqgrid.css" />

<!-- Month Year Selection Calendar plugin -->

<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url() ?>css/StyleCalender.css" />
<link href="<?php echo base_url(); ?>css/chosen.css" media="screen" rel="stylesheet" />

<script type="text/javascript">
var filter;
var tabReportClick=0;

	var isReportsPage = <?php if(isset($isReportPage)) echo "true"; else echo "false";  ?>;
	
    var interactionsTitle = "<?php echo lang("Track.Interactions"); ?>";

    var date = "<?php echo lang("Overview.Date"); ?>";

    var action = "<?php echo lang("Overview.Action"); ?>";

    var type = "<?php echo lang("Overview.Type"); ?>";

    var recordedBy = "<?php echo lang("track.RecordedBy"); ?>";

    var channel = "<?php echo lang("Overview.Channel"); ?>";

    var product = "<?php echo lang("Overview.Product"); ?>";

    var paymentsTitle = "<?php echo lang("Overview.Payments"); ?>";

    var requestedBy = "<?php echo lang("Overview.requestedBy"); ?>";

    var paidBy = "<?php echo lang("Overview.paidBy"); ?>";

    var amount = "<?php echo lang("Overview.amount"); ?>";
    var kolId = "<?php echo $kolId ?>";
    var isIpadRequest="<?php echo IS_IPAD_REQUEST ?>";
    jqgridIds = new Array('listInteractionsResultSet');

    function addSpeaker() {
        $('#interactionsContainer').hide();
        $("#addInteractionContainer").show();
        $('#firstPageContainer').show();
        $('#secondPage').hide();
        //if($("#addInteractionContainer").html()==''){
        $("#editInteractionContainer").html('');
        $("#addInteractionContainer").block({message: ' ', overlayCSS: {backgroundColor: '#F7F7F7', cursor: 'default'}, css: {backgroundImage: 'url(../images/ajax-loader-round.gif)', backgroundPosition: 'center', backgroundRepeat: 'no-repeat', backgroundColor: 'transparent', border: '0px', height: '30%', cursor: 'default'}});
        $("#addInteractionContainer").load(base_url + 'speaker_evaluations/add_evaluation/' + kolId);
        //}
        //$('#interactionsContainer').hide();
        //$('#addInteractionContainer').load('<?php echo base_url() ?>speaker_evaluations/add_evaluation');
    }

    
    $(document).ready(function () {
        tabReportClick = 0;

        // list_medical_insight_grid();


//            list_medical_insight_grid();

        $('.tabsWrapper ul.tabsContainer li').click(function () {
            var currentTab = $(this).attr('name');
            $('.tabsWrapper ul.tabsContainer li').removeClass('current');
            $('.tabsWrapper .tabsContent div.tabContent').hide();
            $(this).addClass('current');
            $('.tabsWrapper .tabsContent div.' + currentTab).show();
        });

        $("#list").click(function () {
            
            tabReportClick = 0;
            currentChartId = "report";
            $("#gridContainer").css("display", "block");
            $("#profileScoreReport").css("display", "none");

listInteractions(filter);


        });
        $("#chart").click(function () {
            tabReportClick = 1;
            currentChartId = "chart";
            $("#gridContainer").css("display", "none");
            $("#profileScoreReport").css("display", "block");
                listSpeakerDataReport(filter);

        });


    });
    
    function filterCurrentReport(data) {
        filter=data;
        listInteractions(data);
        listSpeakerDataReport(filter);
        if(tabReportClick==0){
             $("#gridContainer").css("display", "block");
            $("#profileScoreReport").css("display", "none");
        }
        else{
             $("#gridContainer").css("display", "none");
            $("#profileScoreReport").css("display", "block");
        }
    }
    
     function export_excel_speaker(){



			

			var excelFilters = '';



			

		

				$(".gridWrapper .ui-jqgrid tr.ui-search-toolbar th input").each(function(){

					if($(this).val() != ''){

						var filterName = $(this).attr('name');
                                                if(filterName=="username")
                                                    filterName="MSL/MML Name";
                                                if(filterName=="specialty")
                                                    filterName="Therapeutic Area";
                                                if(filterName=="status")
                                                    filterName="Engagement Status";
                                                if(filterName=="kol_id")
                                                    filterName="HCP Name(s)";
                                                
						var filterValue = $(this).val();

						excelFilters += filterName+" : "+filterValue+",";

					}
//                                        alert(excelFilters);

				});

				//$("#excel-filters").val(excelFilters);

				var selectedOPtion = $(".ui-pg-selbox").val();

				$(".ui-pg-selbox option:last").attr('selected','selected');

		    	$('.ui-pg-selbox').trigger('change');

		    	

		    		var arrIds = $("#listInteractionsResultSet").jqGrid("getCol", "row_id");
               

//		    if($('#orgIntaerctionContainer').css('display')!='block'){
//
//	    	
//
//	    		$('#ids').val(arrIds);
//
//	    	}



	    	
             
//	    	$("#refineFilters").val(filters);

                
                $('#ids').val(arrIds);
	    	$("#excel-filters").val(excelFilters);

	    //	return false;
//
	    <?php if (!IS_IPAD_REQUEST) { ?>
                $('#exportSpeaker').submit();
            <?php } else { ?>
                var data= $("#exportSpeaker").serialize();
                sendMail(data);
            <?php } ?>   

	    	$(".ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');

	    	$('.ui-pg-selbox').trigger('change');

		}
                function sendMail(data){
                    alert("Excel has been mailed successfully.");
                    $.ajax({

                    url: "<?php echo base_url()?>speaker_evaluations/send_email_for_export",
                            dataType: "json",
                            data: data,
                            type: "POST",
                            success: function (responseText) {
                           
                            },
                            complete: function () {
                           
                            }
                    });               
    }

</script>

<style type="text/css">

    /*    Enable Verticle separator between content and side menu list  By Laxman   */

    #contentWrapper.span-23 {

        background-image: url("<?php echo base_url(); ?>images/verticlesep_terNav.jpg");

        background-position: 135px 50%;

        background-repeat: repeat-y;

    }

    .ui-tabs-vertical .ui-tabs-nav {

        margin-left: 0px;

    }

    .listResultSet a{

        text-decoration:none;

        text-align:left;

        float:left;

    }

    tr.selectedRow {

        background-color: #D8DFEA !important;

    }

    .addLink {

        width:auto;

        float: right;

    }

    .addLink label{

        margin-top: -20px;

    }

    .toggleBtnWrapper{

        width: auto;

        margin-top: 1px;

    }

    #interactionsTernaryNav{

        width: 124px;

    }

    /*		#interactionsContainer, #addEditInteractionWrapper{
    
                            width: 805px;
    
                            margin-top: -75px;
    
                            margin-top: 0px;
    
                            float: right;
    
                    }*/

    #timeLineSliderContainer{

        margin-bottom: 0px;

    }

    #timeLineSliderContainer p {

        margin-top: 0px;

    }

    #timeLineSliderContainer p input[type="text"]{

        margin: 1px 0px 0px 0px;

    }

    div#contentHolder{

        width: auto !important;

        min-width: 260px;

        max-width: 600px;

    }


    .buttonsWarpper{

        float: right;

        width: 266px;

    }

    #addInteractionContainer,#editInteractionContainer, #viewInteractionContainer{

        display:none;

        min-height: 400px;

        min-width: 400px

    }
    ul.tabsContainer{
    padding-left: 3.333em !important;
}
    
        .exportOptionsContainer {
    height: 0px !important;
    overflow: visible;
}
.title-bar-actions{
    margin-top: -6px !important;
}
     
     <?php if(!isset($isReportPage)){?>
     	.tabsContent{
     		border-width:0px !important;
     	}       
     <?php }?>
<?php if(IS_IPAD_REQUEST == 1){ ?>
         form label {
            font-weight: normal !important;
            text-align: left  !important;
        }
		.tabsContainer li{
			font-size: 12px;
		}
        #load_listMslActivityResultSet{
            display:none !important;
        }
         .tabsWrapper ul.tabsContainer{
		list-style: none;
		border-bottom: 1px solid #D0CCC9;
	    line-height: 21px;
	    margin: 0px;
	}
	.tabsWrapper ul.tabsContainer li{
		display: inline;
		background-color: #ECECEC;
		border:1px solid #D0CCC9;
		border-bottom-color: #ececec;
		padding: 2px 5px;
	}
	.tabsWrapper ul.tabsContainer li.current{
		border-bottom: 2px solid #fff;
		background-color: #fff;
	}
	.tabsWrapper ul.tabsContainer li.current a{
		color:#333333;
	}
	.tabsWrapper ul.tabsContainer li a{
		text-decoration: none;
		padding: 0 5px;
		font-weight: bold;
		color: #333333;
	}
	.tabsWrapper div.tabsContent{
		border: 1px solid #D0CCC9;
		padding:5px;
		border-top: 0px;
	}
	.tabsWrapper .tabsContent div.tabContent{
		display: none;
	}
        #timeLineSliderContainer{
            display:none;
        }
        <?php } ?>
</style>



<!--[if IE]>

<style type="text/css">

        .toggleBtnWrapper{

                margin-top: 3px;

        }

</style>

<![endif]-->

<div id="searchFiltersContainer">
    <div id="searchFiltersElements">
	<div id="container">
    <div id="addContaier"></div>
    <div id="addEditInteractionWrapper">

        <div id="addInteractionContainer"></div>

        <div id="editInteractionContainer"></div>

        <div id="viewInteractionContainer"></div>

    </div>
    <div id="interactionsContainer">
        <div id="timeLineSliderContainer" class="timeLineSliderContainer ui-widget-content">
            <div class="exportOptionsContainer">
                <ul class="pageRightOptions">
					<?php if ($currentController == 'kols') { ?>
                        <li>
                            <a href="#" class="NewBlueButton NewAddIcon" onclick="addSpeaker();">Add Speaker Evaluation</a>
                        </li> 
        			<?php } ?>

                </ul>

            </div>

        </div>
<!--        <form action="<?php echo base_url() ?>interactions/export_interaction_details" method='post' id="export">

            <input type="hidden" name="interaction_ids" value="" id='ids'></input>

            <input type="hidden" name="filters" id="excel-filters" />

        </form>-->

        <div id="interactionsList" class="clear">
            <?php if(IS_IPAD_REQUEST == 1){ ?>
	<div style="margin-bottom: 10px;">
		<a class="btn btn-default" href="<?php echo base_url().IPAD_URL_SEGMENT;?>/reports/list_all_ireports" >Back</a>
	</div>
<?php }?>
            <div class="tabsWrapper" id="test">
                <ul class="tabsContainer">
                <?php if(isset($isReportPage)){?>
                    <li class="current" name="tab0"><a id="list" href="#">List</a></li>
                    <li name="tab1"><a id="chart" href="#">Report</a></li>
				<?php }?>
                </ul>
                <div class="tabsContent">
                    <div class="tab0 tabContent" style="display:block;">
                        <div class="gridWrapper" id="gridContainer">

                            <div id="listInteractionsPage">
                            <?php if(isset($isReportPage)){?>
                            	Select Filters for report
                            	<?php }?>
                            	</div>

                            <table id="listInteractionsResultSet"></table>


                        </div>
                    </div>
                    <div class="tab1 tabContent" style="display:block;">
                        <div id="profileScoreReport"></div>
                    </div>
                </div>
            </div>
            <!-- Container for the 'Interaction Micro Profile' modal box -->
            <div id="dailog1">	
                <div id="interactionMicroProfile" class="microProfileDialogBox">
                    <div class="profileContent"></div>
                </div>
            </div>
            <!--End of  Container for the 'Interaction Micro Profile' modal box -->
            <!-- Container for the 'Interaction Add' modal box -->
            <div id="dailog2">	
                <div id="interactionAddContainer" class="microProfileDialogBox">
                    <div class="profileContent" id="interactionAddProfileContent"></div>
                </div>
            </div>
            <!--End of  Container for the 'Interaction Addd' modal box -->
            <!-- Container for the 'Interaction Micro Edit' modal box -->
            <div id="dailog3">	
                <div id="interactionEditContainer" class="microProfileDialogBox">
                    <div class="profileContent" id="interactinEditProfileContent"></div>
                </div>
            </div>
            <!--End of  Container for the 'Interaction Edit' modal box -->
        </div>
        <div id="interactionsReports">
        </div>
        <!-- Container for the 'Micro Profile'  box -->
        <div id="contentHolder" class="callOutTest microView" style="display: none;">
            <div>
                <a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeKolProfile();" class="ui-icon ui-icon-closethick">close</span></a>
                                <!--<img class="ui-icon ui-icon-closethick" alt="" src="" onclick="closeKolProfile();" />
                --></div>
            <div class="profileContent"></div>
        </div>
        <div id="arraouHolder" class="callOutTest" style="display: none;"><div class="arrowMarkIcon"></div></div>
    </div>
	</div>
</div>
</div>

<form action="<?php echo base_url()?>speaker_evaluations/export_speaker_report/" method='post' id="exportSpeaker">
        <input type="hidden" id="ids" name="coaching" value=""></input>
        <input type="hidden" name="filters" id="excel-filters" />
        <input type="hidden" name="filter" id="refineFilters" />
    </form>