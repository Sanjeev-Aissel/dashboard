<?php
/**
 * 
 * @author Laxman K
 * @since 6.0.4
 * @created on 06-12-2013
 * 
 */

	// Get the URI segment.
	$currentController	= $this->uri->segment(1);
	$currentMethod		= $this->uri->segment(2);
	$param				= $this->uri->segment(3);
	$subSection			= $this->uri->segment(4);
	if($currentController=='reports'){
		$subSection			= $param;
	}
	$subSection			= (empty($subSection)?'default':$subSection);
	$rightSideBar		= '';
	$arrSideBarVisibility	= array(
									'kols'				=> array(	'client_index'=> 0,
																	'view_social_media'=>0,
																	'view'=>0,
																	//'view'=> array('default'=>0,'bio'=>0,'interaction_report'=>0,'payments'=>0),
																	'view_kol_interactions'=>0,
																	'view_affiliations'=>0,
																	'view_events'=>0,
																	'view_publications'=>0,
																	'view_clinical_trials'=>0,
																	'survey_form'=>0,
                                                                    'add_ol' => 0,
                                                                    'edit_ol' => 0,
																	'add' => 0
																),
									'opt_in_out' => array( 'edit_kol'=>0),
									'organizations'		=> array(	'view'=> array('default'=>0,'about'=>0,'social_media'=>0),
																	'view_keypeople'=>0,
																	'view_publications'=>array('default'=>0,'search'=>0,'by_time'=>0),
																	'view_events'=>0,
																	'view_clinical_trials'=>0,
																	'view_network_map'=>0,
																	'view_sub_organizations'=>0,
																	'view_interactions' => 0,
                                                                                                                                        'add_org'=>0
																),
									'requested_kols'	=> array('show_client_requested_kols'=>0,'show_non_profiled_kols'=>0),
									'client_user_log_activities'	=> array('show_client_log_activities'=>0),
									'requested_orgs'	=> array('show_client_requested_orgs'=>0),
									'interactions'		=> array(	'list_interactions'=>0,
																	'view_numeric_report'=>0,
																	'add_interaction'=>0,
                                                                                                                                        'add_mirf'=>0,
                                                                                                                                        'list_mirf'=>0,
                                                                                                                                        'view_mirf'=>0,
                                                                                                                                         'view_mirf_base'=>0,
                                                                                                                                        'view_micro_interaction'=>0,
                                                                                                                                        'edit_mirf'=>0,
																																		'view_drilldown_list'=>0,
																																		'save_interaction'		=> 0,
																),
									'plannings'			=> array('show_plans'=>0,'view_plan'=>0,'add_plans'=>0),
									'payments'			=> array('list_payments'=>0, 'add_payment'=>0),
									'monthly_reports'	=> array('list_monthly_events'=>0),
									'contracts'			=> array('show_contracts'=>0),
									'coachings'			=> array(	'list_coachings'=>0,
																	'add_coaching'=>0,
																	'edit_coaching'=>0,
																	'view'=>0,
                                                                            
																	'medical_insight'=>0,
																	'compliance'=>0,
																	'list_medical_insights'=>0,
																	'view_medical_insight'=>0,
                                                                                                                                        'edit_medical_insight'=>0,
																	'list_compliance'=>0,
																	'view_compliance'=>0,
                                                                            'edit_compliance'               => 0
																),
									'customer_engagements'	=> array(	'add'	=> 0,
																		'list_engagements'	=> 0
																),
									'maps'				=> array('view_network_map'=>0,
																'view_geo_map'=>0,
																'view_influence_map_org'=>1
																),
									'my_list_kols'		=> array(	'list_categories_and_names'=>0,
																	'list_categories'=>0
																),
									'surveys'			=> array(	'list_active_surveys'=>0,
																	'list_surveys'=>0,
																	'view_reports'=>0,
																	'view_network_map'=>0,
																	'view_geo_map'=>0,
																	'add_survey'=>0,
																	'edit_survey'=>0,
																	'view'=>0,
																	'survey_form'=>0,
																	'edit_survey_data'=>0,
																	'sales_report'=>0,
																	'hcp_report'=>0
																),
									'reports'		=> array(	'view_reports'=> array('activity'=>1,'rating'=>0,'events'=>1,'affiliations'=>1,'publications'=>1,'segmentation'=>1, 'view_interaction_reports'=>1,'view_coaching_reports'=>1,'view_coaching_quarterly_reports'=>1, 'user_analytics'=>0, 'ktl_analytics'=>0, 'summary'=>0)),
									'user_settings' => array(0),
									'updates'		=> array('show_updates'=>0),
            'identifications'		=> array('priority_settings'=>0),
									'speaker_evaluations'		=> array('list_surveys'=>0),
									'notifications'		=> array('notifications_home'=>0),
										 'media_intel_extractions' => array('media_feature' => 0,
                                                                                                            'get_kol_id' => 0)						
								);
	if(isset($arrSideBarVisibility[$currentController][$currentMethod])){
		if(is_array($arrSideBarVisibility[$currentController][$currentMethod])){
			if($arrSideBarVisibility[$currentController][$currentMethod][$subSection]){
				$hideSideBar	= 0;
			}else{
				$hideSideBar	= 1;
			}
		}else{
			if($arrSideBarVisibility[$currentController][$currentMethod]){
				$hideSideBar	= 0;
			}else{
				$hideSideBar	= 1;
			}
		}
	}
	if(!$hideSideBar){
		if(isset($filterPage)){
			$rightSideBar	= 'refinedbyfilters';
		}else if(isset($additionalContent)){
			$rightSideBar	= 'additionalContent';
		}else if(isset($rightSideContentPage)){
			$rightSideBar	= 'rightSideContentPage';
		}
	}
?>
<style type="text/css">
	#rightSideBarWrapper{
		display:<?php echo ($hideSideBar)?'none':'';?>;
	}
	#rightSideBarEnableDisable{
		display:<?php echo ($hideSideBar)?'none':'';?>;
	}
	#rightSideBar{
		<?php echo ($hideSideBar)?'padding:0px':'';?>;
	}
	#rightSideBarSlider{
		display: none;
	}
</style>
<div id="rightSideBarWrapper">
	<div id="rightSideBarContainer">
		<?php switch($rightSideBar){
			case 'refinedbyfilters':
		?>
		<div id="refinedByWrapper" class="rightRefinedByFilter">
			<div id="refinedByContainer">
				<div id="rightSideBarSlider" class="tooltip-demo tooltop-left collapseRightSideBar"><a href="#" class="tooltipLink" rel='tooltip' title="Show Refine By">&nbsp;</a></div>
				<div id="searchLeftBar" style="display: block;">
					<h3>
						<div class="funnelIcon sprite_iconSet"></div>Refine By
						<div id="resetBttnContainer"><label class="tooltip-demo tooltop-left" id="resetBttn" onclick="resetFilters();"><a href="#" class="tooltipLink" rel='tooltip' title="Reset Filters">&nbsp;</a></label>Reset</div>
					</h3>
					<div id="searchFiltersContainer">
						<?php echo $this->load->view($filterPage,$filterData);?>
					</div>
				</div>
			</div>
		</div>
		<?php 
				break;
			case 'additionalContent':
				echo $additionalContent;
		 	break;
		 	case 'rightSideContentPage':
				echo $this->load->view($rightSideContentPage,$rightSideContentPageData);
		 	break;
			default:?>
			<div id="refinedByWrapper" class="rightRefinedByFilter">
			<div id="refinedByContainer">
				<div id="rightSideBarSlider" class="tooltip-demo tooltop-left collapseRightSideBar"><a href="#" class="tooltipLink" rel='tooltip' title="Show Refine By">&nbsp;</a></div>
				<div id="searchLeftBar" style="display: block;">
					<h3>
						<div class="funnelIcon sprite_iconSet"></div>Refine By
						<div id="resetBttnContainer"><label class="tooltip-demo tooltop-left" id="resetBttn" onclick="resetFilters();"><a href="#" class="tooltipLink" rel='tooltip' title="Reset Filters">&nbsp;</a></label>Reset</div>
					</h3>
					<div id="searchFiltersContainer">
						
					
				<?php 
						// If the 'Reports' is the action
						if(($currentController == 'reports')  && (
																$currentMethod == 'view_reports' 
																|| $currentMethod == 'view_interaction_reports' 
																|| $currentMethod == "msl_activity_report" 
																|| $currentMethod == 'user_access_report'  
																|| $currentMethod == 'view_interaction_reports' 
																|| $currentMethod == 'view_coaching_reports' 
                                                                                                                                || $currentMethod == 'customer_seen_report'
                                                                                                                                || $currentMethod == 'institution_seen_report'
                                                                                                                                || $currentMethod == 'view_coaching_quarterly_reports' 
																|| $currentMethod == 'list_uoq' 
																|| $currentMethod == 'list_speaker_evaluations')
						): ?>
					<?php echo $this->load->view("reports/crm_report_filters"); ?>
					<?php endif;?>
			</div>
				</div>
			</div>
		</div>
			<?php	break;
		}?>
		
	</div>
</div>
<script>
var agent ='';
<?php 
	 $mobile = mobile_device_detect();
	 if(isset($mobile[1])){?>
	  	agent ='<?php echo $mobile[1]?>';

	  	
	 <?php }?>
	function resizeJqGridWidth(width)
	{
		if(isiPad===true){
			width	= jqgridWidthForiPad;
		}
		if (jqgridIds instanceof Array) {
			$.each(jqgridIds, function( index, value ) {
				$('#'+value).setGridWidth(width,true);
			});
		}
		saveColumnSettings();
	}
	function toggleRightSideBar(){
		$('#rightSideBarWrapper').toggle();
		if(jqgridIds[0] == 'reports' || jqgridIds[0] == 'kolsProfileScore'){
			
			if($('#rightSideBarEnableDisable').html()==='Show Sidebar'){
				resizeReportsGridWidth();
				$('#rightSideBarEnableDisable').html('Hide Sidebar');
			}else{
				resizeReportsGridWidth();
				$('#rightSideBarEnableDisable').html('Show Sidebar');
			}
		}else{
			$("#tabs1 .current").triggerHandler("click");
			if($('#rightSideBarEnableDisable').html()==='Show Sidebar'){
				$('.frozen-div #kolsByRankingResultSet_name').width(200);
				$('.frozen-div #kolsByRankingResultSet_rank').width(60);
				$('.frozen-div #kolsByRankingResultSet_score').width(100);
				resizeJqGridWidth(jqgridMinWidth);
				$('#rightSideBarEnableDisable').html('Hide Sidebar');
				
				if(agent=='Apple iPad'){
					$('#surveyMap').css('width','800px');
				}else{
					$('#surveyMap').css('width','805px');
				}
				
				
			}else{
				$('.frozen-div #kolsByRankingResultSet_name').width(297);
				$('.frozen-div #kolsByRankingResultSet_rank').width(92);
				$('.frozen-div #kolsByRankingResultSet_score').width(121);
				$('#rightSideBarEnableDisable').html('Show Sidebar');
				if(agent=='Apple iPad'){
					$('#surveyMap').css('width','780px');
				}else{
					$('#surveyMap').css('width','1175px');
				}
				resizeJqGridWidth(jqgridMaxWidth);
				
			}
		}
	}

	function resizeReportsGridWidth(){
		if (jqgridIds instanceof Array) {
			if(jqgridIds[0] == 'reports' || jqgridIds[0] == 'kolsProfileScore'){
				if($('#rightSideBarEnableDisable').html()==='Show Sidebar'){
					if(jqgridIds[0] == 'kolsProfileScore'){
						jqgridMinWidth = jqgridMinWidth-40;
					}
					$.each(jqgridIds, function( index, value ) {
						jQuery("#"+value).setGridWidth(jqgridMinWidth);
					});
				}else{
					$.each(jqgridIds, function( index, value ) {
						jQuery("#"+value).setGridWidth('1150');
					});
				}
			}
		}
	}
</script>
