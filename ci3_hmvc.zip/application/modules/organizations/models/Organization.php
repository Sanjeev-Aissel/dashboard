<?php
class Organization extends CI_Model {
	
	function getMyOrgsView($userId){
		$this->db->select('org_id');
		$this->db->where('user_id',$userId);
		$this->db->join('organizations','user_orgs.org_id = organizations.id','left');
		//$this->db->where('organizations.status',COMPLETED);
		$result = $this->db->get('user_orgs');
		foreach ($result->result_array() as $row){
			$arr[$row['org_id']] = $row['org_id'];
		}
		return $arr;
	}
	
	function getAllCustomFilterByUser($userId) {
		$this->db->where('created_by',$userId);
		$this->db->where('filter_type',2);
		$this->db->order_by('applied_on','desc');
		$this->db->order_by('name','asc');
		$result = $this->db->get('custom_filters');
		foreach ($result->result_array() as $row){
			$arrData[] = $row;
		}
		return $arrData;
	}
	function getOrgNames($arrIds=""){
		$arrKolDetail=array();
		$this->db->select('id,name,status');
		if($arrIds != "" && is_array($arrIds))
			$this->db->where_in('id',$arrIds);
		$this->db->order_by('name');
		$arrKolDetailResult	=	$this->db->get('organizations');
		foreach($arrKolDetailResult->result_array() as $row){
			$arrKolDetail[]=$row;
		}
		return $arrKolDetail;
	}
	/**
	 * List all  MAtched Events Data
	 *
	 * @return $arrEventsDetails/false
	 */
function getMatchOrganiations($arrFilterOrgs,$limit,$startFrom,$doCount,$doGroupBy=false,$groupByCategory=null){
		$arrOrganizations	=	array();
		//$this->db->limit(10);
//$this->db->get('organizations');
//echo $this->db->last_query();
//exit;
		//$this->db->distinct();
		$this->db->select('organizations.name,organizations.parent_id,organizations.id,countries.country,organizations.country_id, organizations.type_id as org_type_id, organization_types.type,organizations.company_logo,organizations.headquarters,organizations.phone,organizations.founded,states.name as state,cities.City as city,organizations.state_id,organizations.city_id,organizations.profile_type,organizations.website,organizations.created_by,organizations.status, countries.GlobalRegion');
		$this->db->join('countries','countries.countryId = organizations.country_id', 'left');
		$this->db->join('states','states.id = organizations.state_id', 'left');
        $this->db->join('cities','cities.cityId = organizations.city_id', 'left');
		$this->db->join('organization_types','organization_types.id = organizations.type_id','left');
		//$this->db->join('key_peoples','key_peoples.org_id = organizations.id','left');
		
		//$where="(name LIKE '%".$orgName."%' OR key_peoples.first_name LIKE '%".$orgName."%' OR key_peoples.middle_name LIKE '%".$orgName."%' OR key_peoples.last_name LIKE '%".$orgName."%')";
		//in order to allow charecter ' in the search
		if($arrFilterOrgs['keyword'] != ''){
			$where='(organizations.name LIKE "%'.$arrFilterOrgs['keyword'].'%" OR key_peoples.first_name LIKE "%'.$arrFilterOrgs['keyword'].'%" OR key_peoples.middle_name LIKE "%'.$arrFilterOrgs['keyword'].'%" OR key_peoples.last_name LIKE "%'.$arrFilterOrgs['keyword'].'%")';
			$this->db->where($where);
		}
		if(isset($arrFilterOrgs['org_types']) && $arrFilterOrgs['org_types']!="" &&  sizeof($arrFilterOrgs['org_types'])>0){
			$this->db->where_in('organizations.type_id',$arrFilterOrgs['org_types']);
		}
	 	if ($arrFilterOrgs['region'] != null && isset($arrFilterOrgs['region']) && sizeof($arrFilterOrgs['region']) > 0) {
            $this->db->where_in('countries.GlobalRegion', $arrFilterOrgs['region']);
//                      
        }
		if(isset($arrFilterOrgs['country']) && $arrFilterOrgs['country']!="" &&  sizeof($arrFilterOrgs['country'])>0){
			$this->db->where_in('organizations.country_id',$arrFilterOrgs['country']);
		}
		if(isset($arrFilterOrgs['state']) && $arrFilterOrgs['state']!="" &&  sizeof($arrFilterOrgs['state'])>0){
			$this->db->where_in('organizations.state_id',$arrFilterOrgs['state']);
		}
		if(isset($arrFilterOrgs['city']) && $arrFilterOrgs['city']!="" &&  sizeof($arrFilterOrgs['city'])>0){
			$this->db->where_in('organizations.city_id',$arrFilterOrgs['city']);
		}
		if(isset($arrFilterOrgs['profile_type']) && $arrFilterOrgs['profile_type']!="" &&  sizeof($arrFilterOrgs['profile_type'])>0){
			$this->db->where_in('organizations.profile_type',$arrFilterOrgs['profile_type']);
		}
		
		if(isset($arrFilterOrgs['resOrgType'])){
			if($arrFilterOrgs['resOrgType']=="PARENT"){
				$this->db->where('organizations.parent_id',0);
			}
			if($arrFilterOrgs['resOrgType']=="CHILD"){
				$this->db->where('organizations.parent_id >',0,false);
				/* $this->db->where('organizations.parent_id !=',0,false);
				$this->db->or_where('organizations.parent_id is null','',false); */
			}
			if($arrFilterOrgs['resOrgType']=="OTHER"){
				 $this->db->or_where('organizations.parent_id is null','',false); 
			}
			//if($arrFilterOrgs['resOrgType']=="ALL" || $arrFilterOrgs['resOrgType']=="BOTH"){
			//	$this->db->where('organizations.parent_id >=',0,false);
			//}
		}
		//$this->db->like('name',$orgName);
		//$this->db->or_like('key_peoples.first_name',$orgName);
		//$this->db->or_like('key_peoples.middle_name',$orgName);
		//$this->db->or_like('key_peoples.last_name',$orgName);
		if($doCount){
// 			$this->db->where('organizations.status',COMPLETED);
			//$this->db->where('organizations.status_otsuka',"ACTV");
			if(isset($arrFilterOrgs['viewType']) && sizeof($arrFilterOrgs['viewType'])>0){
				$this->db->where_in('organizations.id',$arrFilterOrgs['viewType']);
			}
			$arrOrgDetailsResult	=	$this->db->get('organizations');
			foreach($arrOrgDetailsResult->result_array() as $row){
				$arrOrganizations[]=$row;
			}	
			return sizeof($arrOrganizations);
		}
		else{
			if($doGroupBy){
				if($groupByCategory=='region'){
					$this->db->select('COUNT(DISTINCT organizations.id) as count');
					$this->db->group_by('GlobalRegion');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='country'){
					$this->db->select('COUNT(DISTINCT organizations.id) as count');
					$this->db->group_by('country_id');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='state'){
					$this->db->select('COUNT(DISTINCT organizations.id) as count');
					$this->db->group_by('state_id');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='city'){
					$this->db->select('COUNT(DISTINCT organizations.id) as count');
					$this->db->group_by('city_id');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='type'){
						$this->db->select('COUNT(DISTINCT organizations.id) as count');
						$this->db->group_by('organization_types.id');
						//$this->db->where('specialties.specialty IS NOT NULL');
				}				
				$this->db->order_by('count','desc');
			}
			else 
			$this->db->limit($limit, $startFrom);
			//$this->db->where('organizations.status',COMPLETED);
			//$this->db->where('organizations.status_otsuka',"ACTV");
			if(isset($arrFilterOrgs['viewType']) && sizeof($arrFilterOrgs['viewType'])>0){
				$this->db->where_in('organizations.id',$arrFilterOrgs['viewType']);
			}
			$this->db->order_by('organizations.name','asc');
			$arrOrgDetailsResult	=	$this->db->get('organizations');
			foreach($arrOrgDetailsResult->result_array() as $row){
				$arrOrganizations[]=$row;
			}
			return $arrOrganizations;
		}
	}
	function getFilterMatchOrganizations($orgName,$arrFilterOrganizations,$limit,$startFrom,$doCount,$doGroupBy=false,$groupByCategory=null,$arrQueryOptions=array()){
		$arrEvents	=	array();
		$arrOrganizations	=	array();
		//$this->db->distinct();
		$this->db->select('organizations.name,organizations.id,organizations.parent_id,countries.country,organization_types.type,organizations.company_logo,organizations.headquarters,organizations.phone,organizations.founded,states.name as state,cities.City as city,organizations.state_id,organizations.city_id,organizations.status,organizations.profile_type,organizations.website,organizations.created_by, countries.GlobalRegion');
	
		$this->db->join('countries','countries.countryId = organizations.country_id', 'left');
		$this->db->join('states','states.id = organizations.state_id', 'left');
		$this->db->join('organization_types','organization_types.id = organizations.type_id','left');
		$this->db->join('cities','cities.cityId = organizations.city_id', 'left');
		//$this->db->join('key_peoples','key_peoples.org_id = organizations.id','left');
	
		//$where="(name LIKE '%".$orgName."%' OR key_peoples.first_name LIKE '%".$orgName."%' OR key_peoples.middle_name LIKE '%".$orgName."%' OR key_peoples.last_name LIKE '%".$orgName."%')";
		//in order to allow charecter ' in the search
		//$where='(name LIKE "%'.$orgName.'%" OR key_peoples.first_name LIKE "%'.$orgName.'%" OR key_peoples.middle_name LIKE "%'.$orgName.'%" OR key_peoples.last_name LIKE "%'.$orgName.'%")';
		$where='(organizations.name LIKE "%'.$orgName.'%")';
		$this->db->where($where);
	
		if(isset($arrFilterOrganizations['orgIds']) && $arrFilterOrganizations['orgIds']!="" &&  sizeof($arrFilterOrganizations['orgIds'])>0){
			$this->db->where_in('organizations.id', $arrFilterOrganizations['orgIds']);
		}
	
		if(isset($arrFilterOrganizations['type']) && $arrFilterOrganizations['type']!="" &&  sizeof($arrFilterOrganizations['type'])>0  && !($doGroupBy==true && $groupByCategory=="type")){
			$this->db->where_in('organization_types.id', $arrFilterOrganizations['type']);
		}
		if (isset($arrFilterOrganizations['global_region']) && $arrFilterOrganizations['global_region']!="" && sizeof($arrFilterOrganizations['global_region'])>0 && !($doGroupBy==true && $groupByCategory=="region")) {
			$this->db->where_in('countries.GlobalRegion', $arrFilterOrganizations['global_region']);
		}
		if(isset($arrFilterOrganizations['country']) && $arrFilterOrganizations['country']!="" && sizeof($arrFilterOrganizations['country'])>0 && !($doGroupBy==true && $groupByCategory=="country")){
			$this->db->where_in('countries.countryId', $arrFilterOrganizations['country']);
		}
		if(isset($arrFilterOrganizations['state']) && $arrFilterOrganizations['state']!="" && sizeof($arrFilterOrganizations['state'])>0 && !($doGroupBy==true && $groupByCategory=="state")){
			$this->db->where_in('states.id', $arrFilterOrganizations['state']);
		}
		if(isset($arrFilterOrganizations['city']) && $arrFilterOrganizations['city']!="" && sizeof($arrFilterOrganizations['city'])>0 && !($doGroupBy==true && $groupByCategory=="city")){
			$this->db->where_in('cities.CityId', $arrFilterOrganizations['city']);
		}
	
		/* where condition for org profile type */
		if(isset($arrFilterOrganizations['profileType']) && $arrFilterOrganizations['profileType']!="" && $arrFilterOrganizations['profileType']!=0){
			$this->db->where('organizations.profile_type', $arrFilterOrganizations['profileType']);
		}
		/* ends where condition for org profile type */
		if(isset($arrFilterOrganizations['resOrgType'])){
			if(is_array($arrFilterOrganizations['resOrgType'])){
				if(in_array("PARENT", $arrFilterOrganizations['resOrgType'])){
					$query = "(organizations.parent_id = 0";
					$addedFlag = true;
				}
				if(in_array("CHILD", $arrFilterOrganizations['resOrgType'])){
					if($addedFlag == true)
						$query .= " OR organizations.parent_id > 0";
						else{
							$query = "(organizations.parent_id > 0";
							$addedFlag = true;
						}
				}
				if(in_array("OTHER", $arrFilterOrganizations['resOrgType'])){
					if($addedFlag == true)
						$query .= " OR organizations.parent_id is null";
						else{
							$query = "(organizations.parent_id is null";
						}
	
				}
				if($query!=""){
					$query .= ")";
					$this->db->where($query);
				}
			}
				
			if($arrFilterOrganizations['resOrgType']=="PARENT"){
				$this->db->where('organizations.parent_id',0);
			}
			if($arrFilterOrganizations['resOrgType']=="CHILD"){
				$this->db->where('organizations.parent_id >',0,false);
				/* $this->db->where('organizations.parent_id !=',0,false);
					$this->db->or_where('organizations.parent_id is null','',false); */
			}
			if($arrFilterOrganizations['resOrgType']=="OTHER"){
				$this->db->where('organizations.parent_id is null','',false);
			}
			//if($arrFilterOrganizations['resOrgType']=="ALL" || $arrFilterOrganizations['resOrgType']=="BOTH"){
			//	$this->db->where('organizations.parent_id >=',0,false);
			//}
		}
		//$this->db->where('organizations.status',COMPLETED);
		//$this->db->where('organizations.status_otsuka',"ACTV");
		if($doCount){
			if(isset($arrFilterOrganizations['viewType']) && sizeof($arrFilterOrganizations['viewType'])>0){
				$this->db->where_in('organizations.id', $arrFilterOrganizations['viewType']);
			}
			$arrOrgDetailsResult	=	$this->db->get('organizations');
			foreach($arrOrgDetailsResult->result_array() as $row){
				$arrOrganizations[]=$row;
			}
			return sizeof($arrOrganizations);
		}
		else{
			if($doGroupBy){
				if($groupByCategory=='region'){
					$this->db->select('COUNT(DISTINCT organizations.id) as count');
					$this->db->group_by('GlobalRegion');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='country'){
					$this->db->select('organizations.country_id, COUNT(DISTINCT organizations.id) as count');
					$this->db->group_by('country_id');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='state'){
					$this->db->select('COUNT(DISTINCT organizations.id) as count');
					$this->db->group_by('state_id');
				}
				if($groupByCategory=='city'){
					$this->db->select('COUNT(DISTINCT organizations.id) as count');
					$this->db->group_by('city_id');
				}
				if($groupByCategory=='type'){
					$this->db->select('organizations.type_id as org_type_id, COUNT(DISTINCT organizations.id) as count');
					$this->db->group_by('organization_types.id');
					//$this->db->where('specialties.specialty IS NOT NULL');
				}
				$this->db->order_by('count','desc');
			}
			else{
				if($limit !=0 )
					$this->db->limit($limit, $startFrom);
			}
			if(sizeof($arrQueryOptions)>0){
				switch($arrQueryOptions['sort_by']){
					case 'name': $this->db->order_by('organizations.name',$arrQueryOptions['sort_order']);
					break;
					case 'type':$this->db->order_by('organization_types.type',$arrQueryOptions['sort_order']);
					break;
					case 'country':$this->db->order_by('countries.country',$arrQueryOptions['sort_order']);
					break;
					case 'state':$this->db->order_by('states.name',$arrQueryOptions['sort_order']);
					break;
					case 'city':$this->db->order_by('cities.City',$arrQueryOptions['sort_order']);
					break;
				}
			}else{
				$this->db->order_by('organizations.name','asc');
			}
			if(isset($arrFilterOrganizations['viewType']) && sizeof($arrFilterOrganizations['viewType'])>0){
				$this->db->where_in('organizations.id', $arrFilterOrganizations['viewType']);
			}
			$arrOrgDetailsResult	=	$this->db->get('organizations');
			// 			echo $this->db->last_query();
			foreach($arrOrgDetailsResult->result_array() as $row){
				$arrOrganizations[]=$row;
			}
			return $arrOrganizations;
		}
	}
	function getOrgTypeById($arrTypeId){
		$arrTypes = array();
		$this->db->where_in('id',$arrTypeId);
		$arrResultSet = $this->db->get('organization_types');
		foreach($arrResultSet->result_array() as $row){
			$arrTypes[$row['id']] = $row['type'];
		}
		return $arrTypes;
	}
	
	function getMatchingOrgTypes($orgType){
		$this->db->distinct();
		$this->db->select('organization_types.id,organization_types.type');
		$this->db->join('organization_types','organizations.type_id=organization_types.id','left');
		$this->db->like('organization_types.type', $orgType);
		$arrResultSet = $this->db->get_where('organizations');
		$arrOrgTypes = array();
		foreach($arrResultSet->result_array() as $arrRow){
			$arrOrgTypes[$arrRow['id']] = $arrRow['type'];
		}
		return $arrOrgTypes;
	}
	
	function saveCustomFilters($arrData) {
		if($this->db->insert('custom_filters',$arrData)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	function getMcoTypeNames(){
		$arrReturnData = array();
		$this->db->select('id,name');
		$this->db->order_by('id', 'ASC');
		$arrResultSet = $this->db->get('org_mco_type');
		//        echo $this->db->last_query();
		foreach ($arrResultSet->result_array() as $row) {
			$arrReturnData[] = $row;
		}
		return $arrReturnData;
	
	}
	
	function getAddressTypeNames(){
		$arrAddressTypeNames	= array();
		$this->db->select('id,name');
		$this->db->where('is_active',1);
		$this->db->order_by('id', 'ASC');
		$result	= $this->db->get('org_address_type');
		foreach($result->result_array() as $row){
			$arrAddressTypeNames[] = $row;
		}
		return $arrAddressTypeNames;
	}
	
	function getValidationStatusNames(){
		$arrValidationStatus	= array();
		$this->db->select('id,name');
		$this->db->where('is_active',1);
		$this->db->order_by('id', 'ASC');
		$result	= $this->db->get('validation_status');
		foreach($result->result_array() as $row){
			$arrValidationStatus[] = $row;
		}
		return $arrValidationStatus;
	}
	
	function getOrgTypeByName($orgType){
		$this->db->distinct();
		$this->db->select('organization_types.id,organization_types.type');
		$this->db->where('organization_types.type', $orgType);
		$arrResultSet = $this->db->get_where('organization_types');
		return $arrResultSet->row_array();
	}
	function saveOrg($arrData,$data){
		$arrData['created_by']	= $this->session->userdata('user_id');
		$arrData['created_on']	= date("Y-m-d H:i:s");
		if($this->db->insert('organizations',$arrData)){
			$lastId=$this->db->insert_id();
			$this->db->where("id",$lastId);
			$this->db->set("cin_num",$lastId);
			$this->db->update('organizations');
			$orgLastId=$lastId;
			$data['contact'] = $lastId;
			$this->db->insert('contact_restrictions',$data);
			return $orgLastId;
	
		}   else{
			return false;
		}
	
	}
	function saveLocation($arrLocation) {
		if(isset($arrLocation['id'])) {
			$id = $arrLocation['id'];
			unset($arrLocation['id']);
			if($arrLocation["is_primary"] == "1") {
				$primary_flag = array('is_primary' => 0);
				$this->db->where('org_id',$arrLocation['org_id']);
				$this->db->update('org_locations',$primary_flag);
			}
	
			$this->db->where('id',$id);
			if($this->db->update('org_locations',$arrLocation)){
				return true;
			}else{
				return false;
			}
		} else {
	
			if($arrLocation["is_primary"] == "1") {
				$primary_flag = array('is_primary' => 0);
				$this->db->where('org_id',$arrLocation['org_id']);
				$this->db->update('org_locations',$primary_flag);
			}
	
			if($this->db->insert('org_locations',$arrLocation)){
				return $this->db->insert_id();
			}else{
				return false;
			}
		}
	}
	
	function saveOrgAssignClient($arrAssignData) {
		if ($this->db->insert('user_orgs', $arrAssignData)) {
			return $this->db->insert_id();
		} else {
			return false;
		}
	}
	
	function getLocationByOrganizationId($id){
		$this->db->select('org_locations.*');
		$this->db->where('org_locations.org_id',$id);
		$this->db->where('org_locations.is_primary',1);
		$res = $this->db->get('org_locations');
		return $res->result_array();
	}
	
	function editOrg($id=''){
		$arrReturnData 				= array();
		$this->db->select('organizations.* ');
		if(!empty($id)){
			$this->db->where('organizations.id',$id);
		}
		$this->db->order_by('organizations.id','desc');
		$arrOrgResultSet		= $this->db->get('organizations');
		//echo $this->db->last_query();
		foreach($arrOrgResultSet->result_array() as $row){
			//			$row['agent']		= $this->Client_User->getUserNameById($row['agent']);
			//			$row['created_user']= $row['ufname'].' '.$row['ulname'];
			$arrReturnData[]	= $row;
		}
		return $arrReturnData;
	}
	function checkOrgAissenedToUser($kolId){
		if($client_id == INTERNAL_CLIENT_ID){
			return true;
		}else{
			$userId = $this->session->userdata('user_id');
			$get = $this->db->get_where('user_orgs',array("user_id"=>$userId,"org_id"=>$kolId));
			if($get->num_rows()>0){
	
				return true;
			}
			return false;
		}
	}
	function getContactRestrictions($id=''){
		$arrReturnData 				= array();
		$this->db->select('contact_restrictions.* ');
		if(!empty($id)){
			$this->db->where('contact_restrictions.contact',$id);
		}
		$this->db->order_by('contact_restrictions.contact','desc');
		$arrContactRestrictionsResultSet		= $this->db->get('contact_restrictions');
		//echo $this->db->last_query();
		foreach($arrContactRestrictionsResultSet->result_array() as $row){
			//			$row['agent']		= $this->Client_User->getUserNameById($row['agent']);
			//			$row['created_user']= $row['ufname'].' '.$row['ulname'];
			$arrReturnData[]	= $row;
		}
		return $arrReturnData;
	}
	
	function updateOrg($arrData,$data){
	
		$arrData['created_by']	= $this->session->userdata('user_id');
		$arrData['created_on']	= date("Y-m-d H:i:s");
		$this->db->where('id',$arrData['id']);
		if($this->db->update('organizations',$arrData)){
			$this->db->where('contact',$data['contact']);
			$this->db->delete('contact_restrictions');
			$this->db->insert('contact_restrictions',$data);
			return true;
		}else{
			return false;
		}
	}
	function editOrganization($id){
		$arrOrganizationDetail	= array();
		$this->db->where('id',$id);
		if($arrOrganizationDetailResult	=	$this->db->get('organizations')){
			// If the results are not available
			if($arrOrganizationDetailResult->num_rows() == 0){
				return false;
			}
	
			foreach($arrOrganizationDetailResult->result_array() as $arrOrganization){
				if($arrOrganization['postal_code']=='0'){
					$arrOrganization['postal_code']='';
				}
				$arrOrganizationDetail	= $arrOrganization;
			}
			//                pr($arrOrganizationDetail);
			return $arrOrganizationDetail;
		}else{
			return false;
		}
	}
	function getAllKeyPeopleRoles(){
		$arrKeyPeopleRoles	= array();
	
		$arrKeyPeopleRolesResult = $this->db->get('key_people_roles');
		foreach($arrKeyPeopleRolesResult->result_array() as $arrKeyPeopleRole){
			$arrKeyPeopleRoles[$arrKeyPeopleRole['id']]	= $arrKeyPeopleRole['role'];
		}
		return $arrKeyPeopleRoles;
	}
	function getAllOrganizationTypes(){
		$arrOrganizationTypes	= array();
	
		$arrOrganizationTypesResult = $this->db->get('organization_types');
		foreach($arrOrganizationTypesResult->result_array() as $arrOrganizationType){
			$arrOrganizationTypes[$arrOrganizationType['id']]	= $arrOrganizationType['type'];
		}
		return $arrOrganizationTypes;
	}
	function listContacts($orgId = null){
		if($orgId != null){
			$this->db->where('org_id', $orgId);
	
	
			if($arrContactDetails = $this->db->get('org_additional_contacts')){
				return $arrContactDetails;
			}
		}else{
			return false;
		}
	}
	function getMedicalServiceDetails($orgId){
		$arrMedicalServices = array();
		$this->db->select('org_medical_services.id,medical_services.name');
		$this->db->join('medical_services','medical_services.id=org_medical_services.medical_service_id','left');
		$this->db->where('org_medical_services.org_id',$orgId);
		$arrResultSet = $this->db->get('org_medical_services');
		foreach($arrResultSet->result_array() as $row){
			$arrMedicalServices[]=$row;
		}
		return $arrMedicalServices;
	}
	function getStatsAndFacts($orgId){
		$arrStatsFacts = array();
		$this->db->where('org_id',$orgId);
		$arrResultSet = $this->db->get('org_stats_facts');
		foreach($arrResultSet->result_array() as $row){
			$arrStatsFacts[]=$row;
		}
		return $arrStatsFacts;
	}
	function getNotes($kolId) {
		$rows = array();
		$this->db->select('org_notes.*,client_users.first_name,client_users.last_name,modified.first_name as modified_by_first_name, modified.last_name as modified_by_last_name');
		$this->db->where('org_id', $kolId);
		$this->db->join('client_users', 'org_notes.created_by = client_users.id', 'left');
		$this->db->join('client_users as modified', 'org_notes.modified_by = modified.id', 'left');
		$this->db->order_by('created_on', 'desc');
		$res = $this->db->get('org_notes');
		//pr($this->db->last_query());exit;
		if ($res->num_rows() > 0)
			$rows = $res->result_array();
	
			return $rows;
	}
	function getSubOrg($orgId){
		$arrSuOrgs = array();
		$this->db->select('client_users.client_id,o.created_by,organizations.cin_num,organizations.name as name, o.name as sub_org,affiliates_partnerships.id,affiliates_partnerships.data_type_indicator,affiliates_partnerships.org_id,affiliates_partnerships.sub_org_id,o.created_by,o.postal_code,o.address,countries.country,cities.city,states.name as region,o.status,affiliates_partnerships.phone,affiliates_partnerships.npi_num,affiliates_partnerships.url,CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name',false);
		$this->db->join('organizations','organizations.id=affiliates_partnerships.org_id','left');
		$this->db->join('organizations as o','o.id = affiliates_partnerships.sub_org_id','left');
		$this->db->join('countries','o.country_id=countries.countryId','left');
		$this->db->join('states','states.id=o.state_id','left');
		$this->db->join('cities','cities.cityId = o.city_id','left');
		$this->db->join('client_users','client_users.id = o.created_by','left');
		$this->db->where('affiliates_partnerships.org_id',$orgId);
	
		$arrResultSet = $this->db->get('affiliates_partnerships');
		foreach($arrResultSet->result_array() as $row){
			$row['id'] = $row['sub_org_id'];
			$row['eAllowed'] = true;//$this->common_helpers->isActionAllowed('org_details','edit',$row);
			$arrSuOrgs[] = $row;
		}
	
		$this->db->select('client_users.client_id,o.created_by,organizations.cin_num,organizations.name as name, o.name as sub_org,affiliates_partnerships.id,affiliates_partnerships.data_type_indicator,affiliates_partnerships.org_id,affiliates_partnerships.sub_org_id,o.created_by,o.postal_code,o.address,countries.country,cities.city,states.name as region,o.status,affiliates_partnerships.phone,affiliates_partnerships.npi_num,affiliates_partnerships.url,CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name',false);
		$this->db->join('organizations','organizations.id=affiliates_partnerships.sub_org_id','left');
		$this->db->join('organizations as o','o.id = affiliates_partnerships.org_id','left');
		$this->db->join('countries','o.country_id=countries.countryId','left');
		$this->db->join('states','states.id=o.state_id','left');
		$this->db->join('cities','cities.cityId = o.city_id','left');
		$this->db->join('client_users','client_users.id = o.created_by','left');
		$this->db->where('affiliates_partnerships.sub_org_id',$orgId);
		$arrResultSet1 = $this->db->get('affiliates_partnerships');
		foreach($arrResultSet1->result_array() as $row1){
			$row1['id'] = $row1['org_id'];
			$row1['eAllowed'] = true;//$this->common_helpers->isActionAllowed('org_details','edit',$row1);
			$arrSuOrgs[] = $row1;
		}
		return $arrSuOrgs;
	
	}
	
	function saveNote($arrDetails) {
		//pr($arrDetails);exit;
		if ($this->db->insert('org_notes', $arrDetails)) {
			//pr($this->db->last_query());
			return $this->db->insert_id();
		} else {
			return false;
		}
	}
	function getKeyPeopleRoleNameById($roleId=''){
	
		$roleName='';
		if($roleId !=''){
			$this->db->select('role');
			$this->db->where('id',$roleId);
			$arrRoleName = $this->db->get('key_people_roles');
			foreach($arrRoleName->result_array() as $row){
				$roleName = $row['role'];
			}
		}
		return $roleName;
	}
	function saveKeyPeople($keyPeopleDetails){
		if($this->db->insert('key_peoples',$keyPeopleDetails)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	function listKeyPeoples($organizationId = null){
		$arrKeyPeopleDetails = array();
		//Get the Events of KolId
		if($organizationId != null){
			$this->db->where('org_id', $organizationId);
	
			$this->db->select(array('key_peoples.*','key_people_roles.role','client_users.client_id','CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name'));
			$this->db->join('key_people_roles','key_people_roles.id = key_peoples.role_id', 'left');
			$this->db->join('organizations','organizations.id = key_peoples.org_id', 'left');
			$this->db->join('client_users','client_users.id = key_peoples.created_by', 'left');
			//For Salutation loading
			$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
			if($arrKeyPeopleDetailsResult = $this->db->get('key_peoples')){
				foreach($arrKeyPeopleDetailsResult->result_array() as $arrKeyPeople){
					$arrKeyPeople['eAllowed'] = true;//$this->common_helper->isActionAllowed('org_details','edit',$arrKeyPeople);
					$arrKeyPeople['role_id'] = $arrKeyPeople['role'];
					if($arrKeyPeople['salutation'] !='0'){
						$arrKeyPeople['salutation'] = $arrSalutations[$arrKeyPeople['salutation']];
					}
					$arrKeyPeopleDetails[] = $arrKeyPeople;
				}
				return $arrKeyPeopleDetails;
			}
		}else{
			return false;
		}
	}
	
	function listOrgAssociatedPpl($orgId){
		$client_id = $this->session->userdata('client_id');
		$arrKols = array();
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$this->db->select(array('kols.*','kols.profile_type as kol_profile_type','organizations.name','organizations.id as org_id','organizations.created_by as created_by_org','organizations.cin_num','specialties.specialty','countries.Country as country','titles.title as title_name'));
		$this->db->join('organizations', 'organizations.id = kols.org_id', 'left');
		$this->db->join('titles', 'kols.title = titles.id', 'left');
		$this->db->join('specialties', 'specialties.id = kols.specialty', 'left');
		$this->db->join('countries', 'CountryId = kols.country_id', 'left');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$this->db->where('org_id',$orgId);
		//$this->db->where('kols.status',COMPLETED);
		$arrKolsDetailsResult	=	$this->db->get('kols');
		foreach($arrKolsDetailsResult->result_array() as $row){
			if (IS_IPAD_REQUEST)
				$row['kol_name'] = '<a  href=\''.base_url().IPAD_URL_SEGMENT.'/kols/kols/view/'. $row['id'].'\'>'.$arrSalutations[$row['salutation']].' '.$row['first_name'].' '.$row['middle_name'].' '.$row['last_name'].'</a>';
				else
					$row['kol_name'] = '<a target="_new" href=\''.base_url().'kols/kols/view/'. $row['id'].'\'>'.$arrSalutations[$row['salutation']].' '.$row['first_name'].' '.$row['middle_name'].' '.$row['last_name'].'</a>';
					$row['phone'] = $row['primary_phone'];;
					$row['email'] = $row['primary_email'];
					$row['primary_phone'] = '<a href="callto:'.$row['primary_phone'].'" class="linkClickToCall">'.$row['primary_phone'].'</a>';
					$row['primary_email'] = '<a href="mailto:'.$row['primary_email'].'" id="emailHolder">'.$row['primary_email'].'</a>';
					$arrKols[]=$row;
		}
		return $arrKols;
	}
	
	function getKeyPeopleData($id){
		$this->db->where('id',$id);
		$arresultset = $this->db->get('key_peoples');
		$arrKeyPeoples = $arresultset->result_array();
		return $arrKeyPeoples[0];
	}
	
	function updateKeyPeople($keyPeopleDetails){
		$result=array();
		$this->db->where('id',$keyPeopleDetails['id']);
		if($this->db->update('key_peoples',$keyPeopleDetails)){
			return true;
		}else{
			return false;
		}
	}
	
	function deleteKeyPeople($id){
		$this->db->where('id',$id);
		if($query=$this->db->delete('key_peoples')){
			return true;
		}else
			return false;
	}
	
	function saveOrganization($organizationDetails){
		$orgName = '';
		$orgName = $organizationDetails['name'];
		$this->db->where('name',$orgName);
		if(isset($organizationDetails['cin_num'])){
			$this->db->where('cin_num',$organizationDetails['cin_num']);
		}
		if($arrOrganization = $this->db->get('organizations')){
			if($arrOrganization->num_rows!=0){
				$result=$arrOrganization->row();
				if($result!=null)
					$id=$result->id;
					$organizationDetails['id']	= $id;
					$this->updateImportedOrganization($organizationDetails);
					return $id;
			}else{
				if($this->db->insert('organizations',$organizationDetails)){
					return $this->db->insert_id();
				}else{
					return false;
				}
			}
		}
	}
	

	function saveAffiliatesPartnershipsManaul($subOrgDataDetails){
		$dataType = 'User Added';
		$client_id =$this->session->userdata('client_id');
		if($client_id == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		$subOrgDataDetails['data_type_indicator'] = $dataType;
		if($this->db->insert('affiliates_partnerships',$subOrgDataDetails)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	
	}
	
	function updateOrganization($organizationDetails, $affPartnershipDetails = 0){
		$this->db->where('id',$organizationDetails['id']);
		if($this->db->update('organizations',$organizationDetails)){
			//return true;
			if($affPartnershipDetails != 0){
	
				$this->db->insert('affiliates_partnerships',$affPartnershipDetails);
				return true;
			}else{
				return true;
			}
		}else
			return false;
	}
	
	function deleteSubOrg($orgId){
		$this->db->where('sub_org_id',$orgId);
		if($this->db->delete('affiliates_partnerships')){
			return true;
		}else{
			return false;
		}
	}
	function getOrgsById($arrId){
		$arrOrgs = array();
		$this->db->select('id as org_id,name');
		$this->db->where_in('id',$arrId);
		$arrResultSet = $this->db->get('organizations');
		foreach($arrResultSet->result_array() as $row){
			$arrOrgs[$row['org_id']] = $row['name'];
		}
		return $arrOrgs;
	}
	function getOrgNameByOrgId($orgId){
		$orgName=0;
		$this->db->where('id',$orgId);
		$this->db->select('name');
		$result=$this->db->get('organizations');
		$data=$result->row();
		if($data!=null)
			$orgName=$data->name;
		return $orgName;
	}
	function updateOrgTypeForOrganization($arrData) {
		$this->db->where('id',$arrData['id']);
		$result = $this->db->update('organizations',$arrData);
		if($result)
			return true;
		else
			return false;
	}
}