<?php
$autoSearchOptions = "width: 255, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
$queued_js_scripts = array('js/jquery.autocomplete',
		'jquery_validator/dist/jquery.validate',
		'alerts/jquery.alerts'
);
$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>alerts/jquery.alerts.css" media="screen" />
<div class="panel panel-default">
	<div class="panel-heading align_center"><?php if($arrEventData['id']>0)echo 'Update Event Details';else echo 'Add Event';?></div>
	<div class="panel-body">
		<div class="col-md-10 col-md-offset-2 eventMsgBox alert alert-success" role="alert"></div>
		<form action="<?php if($arrEventData){echo 'update_event';}else{echo 'save_event';}?>"   method="post" id="conferenceForm" name="conferenceForm" class="validateForm">
			<input type="hidden" name="kol_id" id="kolId" value="<?php echo $kolId?>"/>
			<input type="hidden" name="type" value="conference">
			<input type="hidden" name="id" id="confId" value="<?php if($arrEventData['id']){echo $arrEventData['id'];}?>"/>
			<input type="hidden" name="event_id" id="confEventId" value="<?php if($arrEventData['id']){echo $arrEventData['id'];}?>"/>
			<div class="form-group row">
				<label class="col-sm-2 align_right">Event Name:<span class="required">*</span></label>
				<div class="col-sm-10">
					  <input type="text" name="event_name" value="<?php if($arrEventData['event_name']){echo $arrEventData['event_name'];}?>" id="confEventName" class="autocompleteInputBox required form-control"/>
		    	</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 align_right">Sponsor Type:</label>
				<div class="col-sm-4">
					  <select class="form-control" name="sponsor_type" id="sponcerType">
				   			<option value="">--- Select ---</option>
							<?php 
								foreach($arrEventSponsorTypes as $key => $value){
									if($arrEventData['sponsor_type'] == $key){
										echo '<option value="'.$key.'" selected>'.$value.'</option>';
									}else{
										echo '<option value="'.$key.'">'.$value.'</option>';
									}
								}
							?>
    				</select>
		    	</div>
		    	<label class="col-sm-2 align_right">Session Sponsor:</label>
				<div class="col-sm-4">
					  <input type="text"  class="form-control" name="session_sponsor" value="<?php if($arrEventData['session_sponsor']){echo $arrEventData['session_sponsor'];}?>" id="sessionSponsor"/>
			    </div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 align_right">Session Name:</label>
				<div class="col-sm-2">
	 				<input type="text"  class="form-control" name="session_name" value="<?php if($arrEventData['session_name']){echo $arrEventData['session_name'];}?>" id="confSessionName"/>
		    	</div>
		    	<label class="col-sm-2 align_right">Organizer:</label>
				<div class="col-sm-2">
					  <input type="text"  class="form-control" name="organizer" value="<?php if($arrEventData['organizer']){echo $arrEventData['organizer'];}?>" id="confOrganizer"/>
		    	</div>
		    	<label class="col-sm-2 align_right">Organizer Type:</label>
				<div class="col-sm-2">
					<select name="organizer_type"  class="form-control">
						<option value="">--- Select ---</option>
							<?php foreach($arrEventOrganizerTypes as $key => $value){
									if($arrEventData['organizer_type'] == $key){
										echo '<option value="'.$key.'" selected>'.$value.'</option>';
									}else{
										echo '<option value="'.$key.'">'.$value.'</option>';
									}
								}?>
			    	</select>
		    	</div>
			</div>
			<div class="form-group row">
					<label class="col-sm-2 align_right">Event Type:<span class="required">*</span></label>
					<div class="col-sm-2">
						<select name="event_type" id="confEventType" class="form-control required">
				   			<option value="">--- Select ---</option>
							<?php 
								foreach($arrConfEventTypes as $key => $value){
									if($arrEventData['event_type'] == $key){
										echo '<option value="'.$key.'" selected>'.$value.'</option>';
									}else{
										echo '<option value="'.$key.'">'.$value.'</option>';
									}
								}
							?>
				    	</select>
			    	</div>
			    	<label class="col-sm-2 align_right">Session Type:<span class="required">*</span></label>
					<div class="col-sm-2">
						<select name="session_type" id="confSessionType" class="form-control required">
				   			<option value="">--- Select ---</option>
							<?php 
								foreach($arrConfSessionTypes as $key => $value){
									if($arrEventData['session_type'] == $key){
										echo '<option value="'.$key.'" selected>'.$value.'</option>';
									}else{
										echo '<option value="'.$key.'">'.$value.'</option>';
									}
								}
							?>
				    	</select>	
			    	</div>
			    	<label class="col-sm-2 align_right">Role:<span class="required">*</span></label>
					<div class="col-sm-2">
						 <select name="role" id="confRole" class="form-control required">
				   			<option value="">--- Select ---</option>
							<?php 
								foreach($arrRoles as $key => $value){
									if($arrEventData['role'] == $value){
										echo '<option value="'.$value.'" selected>'.$value.'</option>';
									}else{
										echo '<option value="'.$value.'">'.$value.'</option>';
									}
								}
							?>
				    	</select>
			    	</div>
				</div>
				<div class="form-group row">
					<label class="col-sm-2 align_right">Topic:</label>
					<div class="col-sm-2">
	 					<select name="topic" id="confTopic" class="form-control">
				     		<option value=0>--- Select ---</option>
							<?php 
							foreach($arrTopics as $key => $value){
								if($arrEventData['topic'] == $key){
									echo '<option value="'.$key.'" selected>'.$value['name'].'</option>';
								}else{
									echo '<option value="'.$key.'">'.$value['name'].'</option>';
								}
								
							}
						?>
					</select>
					<a id="allTopicBtn" href="#" onclick="showAllTopics();">all</a>
			    	</div>
			    	<label class="col-sm-2 align_right">Start:</label>
					<div class="col-sm-2">
						<input type="text" class="form-control" name="start" value="<?php if($arrEventData['start']){echo sql_date_to_app_date($arrEventData['start']);}?>" id="confStart" size="10" maxlength="10" onkeyup="dateFormat(event,this)" onblur="validateDateFormat(event,this)" onmouseout="isValidDate(this.value,true,end.value,'conf')"/>
			    		<p id="confStartContainer"></p>
			    	</div>
			    	<label class="col-sm-2 align_right">End:</label>
					<div class="col-sm-2">
						<input type="text"  class="form-control" name="end" value="<?php if($arrEventData['end']){echo sql_date_to_app_date($arrEventData['end']);}?>" id="confEnd" size="10" maxlength="10" onkeyup="dateFormat(event,this)" onblur="validateDateFormat(event,this)" onmouseout="isValidDate(this.value,false,start.value,'conf')"/>
				    	<p id="confEndContainer"></p>
				    </div>
				</div>
				<div class="form-group row">
					<label class="col-sm-2 align_right">Location:</label>
					<div class="col-sm-2">
		 				<input type="text" class="form-control" name="location" value="<?php if($arrEventData['location']){echo $arrEventData['location'];}?>" id="confLocation"/>
			    	</div>
			    	<label class="col-sm-2 align_right">Address:</label>
					<div class="col-sm-2">
						<input type="text" class="form-control" name="address" value="<?php if($arrEventData['address']){echo $arrEventData['address'];}?>" id="confAddress"/>
			    	</div>
			    	<label class="col-sm-2 align_right">Postal Code:</label>
					<div class="col-sm-2">
						<input type="text" class="form-control" name="postal_code" value="<?php if($arrEventData['postal_code']){echo $arrEventData['postal_code'];}?>" id="confPostalCode"/>
			    	</div>
				</div>
				<div class="form-group row">
					<label class="col-sm-2 align_right">Country:</label>
					<div class="col-sm-2">
	 						<select name="country_id" id="countryId1" onchange="getStatesByCountryId(1);" class="form-control">
								<option value="">-- Select --</option>
								<?php foreach( $arrCountry as $country ){ ?>
								<?php if($arrEventData['country_id']){ ?>
									<option value="<?php echo $country['country_id'];?>" <?php if($country['country_id']==$arrEventData['country_id']){?> selected="selected" <?php }?>>
								<?php echo $country['country_name'];?>
									</option>
								<?php }else{?>
									<option value="<?php echo $country['country_id'];?>" >
								<?php echo $country['country_name'];?>
									</option>
								<?php } }?>
							</select>
			    	</div>
			    	<label class="col-sm-2 align_right">State:</label>
					<div class="col-sm-2">
						<input type="hidden" value="<?php echo $arrEventData['state_id']; ?>" id="stateIdHidden" name="stateIdHidden"/>
						<select name="state_id" class="form-control" id="stateId1" onchange="getCitiesByStateId(1);">		
							<option>Select State</option>
						</select>
			    	</div>
			    	<label class="col-sm-2 align_right">City:</label>
					<div class="col-sm-2">
						<input type="hidden" value="<?php echo $arrEventData['city_id']; ?>" id="cityIdHidden" name="cityIdHidden"/>
						<select class="form-control" name="city_id" id="cityId1">
							<option >Select City</option>		
						</select>
			    	</div>
			</div>
			<div class="form-group row">
				<label class="col-sm-2 align_right">URL:</label>
				<div class="col-sm-10">
					<input type="text"  class="form-control" name="url1" value="<?php if($arrEventData['url1']){echo $arrEventData['url1'];}?>" id="confUrl1"/>
		    	</div>
			</div>
			<div class="form-group row" style="text-align: center;">
	   			<a type="button" onclick="saveEventDetails();" class="btn btn-primary">Save</a>
	            <a type="button" onclick="goBack();return false;" class="btn btn-primary">Cancel</a>
			</div>
		</form>
	</div>
</div>
<div id="eventTopics" class="microProfileDialogBox">
	<div class="profileContent"></div>
</div>
<script>
var otherTopicId=0;
var modalBoxLayout = {
		title: "",
		modal: true,
		width:400,
		position:['center',100],
		resizable: true
	};
	$(document).ready(function(){
		$('div.eventMsgBox').hide();
		// Trigger the Autocompleter for 'Event Name' field of type 'Conference Event'
    	a = $('#confEventName').autocomplete(confEventNameAutoCompleteOptions);	
    	$('#confEventName').attr("autocomplete",'on');
		$("#conferenceForm").validate({
			debug:true,
			onkeyup:true,
			rules: validationRules,
			messages: validationMessages
		});
		$('#confStart').datepicker({
			dateFormat: 'mm/dd/yy'
		});
		$('#confEnd').datepicker({
			dateFormat: 'mm/dd/yy'
		});
		getStatesByCountryId(1);
	});
	var confEventNameAutoCompleteOptions={
			serviceUrl: '<?php echo base_url();?>events/events/get_eventLookup_names/conference',
			<?php echo $autoSearchOptions;?>,
			onSelect : function(event, ui) {
				var selText = $(event).children('.educations').text();
				var selId = $(event).children('.educations').attr('name');
				selText=selText.replace(/\&amp;/g,'&');
				$('#confEventName').val(selText);
				$('#confEventId').val(selId);
				if(event.length>20){
					//$('#orgIdForAutocomplete').val(kolId);
					if(event.substring(0,21)=="No results found for "){
						return false;
					}
				}
			}		
	};
	var validationRules	=  {
			event_name: {
				required:true
			},
			start_date: {
				fullYear: true
			},
			end_date: {
				fullYear: true
			},
			eduUrl1: {
				url: true
			},
			eduUrl2: {
				url: true
			},
			event_type: {
				required:true
			},
			session_type: {
				required:true
			}
		};
		var validationMessages = {
			event_name: {
				required: "Required."
			},
			start_date: "Only full year is allowed. Ex: 2010",
			end_date: "Only full year is allowed. Ex: 2010",
			url: "Please enter a valid URL address",
			event_type: {
				required:"Required."
			},
			session_type: {
				required:"Required."
			}
		};
		function addSelectedTopicToList(value,text){
			//remove the other specialty topics from the conference topics select box
			if(otherTopicId!=0)
				removeTopic(otherTopicId);
			var topics = document.getElementById('confTopic');
			var newTopic = document.createElement('option');
			newTopic.text = text;
			newTopic.value = value;
			 var prev = topics.options[topics.selectedIndex];
			 topics.add(newTopic, prev);
			 topics.value=value;
			 //set this as a other specialty topic
			 otherTopicId=value;
		}
		function isValidDate(date,isStartDate,otherDate,eventType){
			$("#"+eventType+"StartContainer .error").remove();
			$("#"+eventType+"EndContainer .error").remove();
			var month=date.substring(0,2);
			var day=date.substring(3,5);
			var year=date.substring(6);
			var isDateValid=true;
			
			if(month>12)
				isDateValid=false;
			if(day>31)
				isDateValid=false;
			if(year.length<4)
				isDateValid=false;
			if(date!='' && !isDateValid){
				var errorFiled="<label  class=\"error\">Invalid Date<\/label>";
				if(isStartDate)
					$("#"+eventType+"StartContainer").append(errorFiled);
				else
					$("#"+eventType+"EndContainer").append(errorFiled);
				return false;
			}
			else{
				if(!(date=='' || otherDate=='')){
					var date1=new Date(month+" "+ day+","+ year);
					var date2=new Date(otherDate.substring(0,2)+" "+ otherDate.substring(3,5)+","+ otherDate.substring(6));
					if(isStartDate){
						var difference = date2 - date1;
						if(difference<0){
							var errorFiled="<label  class=\"error\">Should be Less than End Year<\/label>";
							$("#"+eventType+"StartContainer").append(errorFiled);
							return false;
						}
					}
					else{
						var difference = date1 - date2;
						if(difference<0){
							var errorFiled="<label  class=\"error\">Should be Greater than Start Year<\/label>";
							$("#"+eventType+"EndContainer").append(errorFiled);
							return false;
						}
					}
				}
				return true;
			}
		}

		
		function validateDateFormat(e,src) {
			if (!e) var e = window.event
			if (e.keyCode) code = e.keyCode;
			else if (e.which) code = e.which;
		 	if(src.value == null || src.value == "") {
		 		return true;
		 	}
			if(!src.value.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
				jAlert("Please enter the date in mm/dd/yyyy format!");
				src.focus();
			}
		}
		
		function dateFormat(e,src) {		
			if (!e) var e = window.event
			if (e.keyCode) code = e.keyCode;
			else if (e.which) code = e.which;
			
			if(code != 37 && code != 38 && code != 39 && code != 40) { 
				if(!src.value.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
					src.value=src.value.replace(/[^0-9\/]/g,'');  
					if(code!=8 && code!=46) // not backspace or delete
					{	
						src.value=src.value.replace(/[^0-9]/g,'');
						if (src.value.length == 2) {
					        src.value += "/";
					    }
						if (src.value.length > 2) {
							if(src.value.indexOf('/') != 2) {
								src.value = src.value.substring(0,2) + "/" + src.value.substring(2,src.value.length);
							}
						}
						if (src.value.length == 5) {
					        src.value += "/";
					    }
						if (src.value.length > 5) {
							if(src.value.lastIndexOf('/') != 5) {
								src.value = src.value.substring(0,5) + "/" + src.value.substring(5,src.value.length);
							}
						}
						if(src.value.length >= 10)
						{
							return false;
						}
					}  
				}
			}
			return true;
		}
		function getStatesByCountryId(idName){
			var countryId=$('#countryId' + idName).val();
			var params = "country_id="+countryId;	
			$("#stateId" + idName).html("<option>select state</option>");
			$("#cityId" + idName).html("<option>select city</option>");
			var states = document.getElementById('stateId' + idName);
			$.ajax({
				url: "<?php echo base_url()?>helpers/country_helpers/get_states_by_countryid/",
				dataType: "json",
				data: params,
				type: "POST",
				success: function(responseText){
					var selectedIndex	= '';					
					$.each(responseText, function(key, value) {				
						 selectedIndex	= '';
						if($('#stateIdHidden').val()>0 && $('#stateIdHidden').val()===value.state_id){
							selectedIndex	= ' selected="selected"';
						} 
						 $('#stateId' + idName).append('<option value="'+value.state_id+'"'+selectedIndex+'>'+value.state_name+'</option>');
					});
					getCitiesByStateId(idName);
				}		
			});		
		}
		function getCitiesByStateId(idName){
			var stateId=$('#stateId' + idName).val();
			$("#cityId" + idName).html("<option>select city</option>");	
			var cities = document.getElementById('cityId' + idName);
			var params = "state_id="+stateId;	
			$.ajax({
				url: "<?php echo base_url()?>helpers/country_helpers/get_cities_by_stateid/",
				dataType: "json",
				data: params,
				type: "POST",
				success: function(responseText){
					var selectedIndex	= '';							
					$.each(responseText, function(key, value) {	
	    				selectedIndex	= '';
	    				if($('#cityIdHidden').val()>0 && $('#cityIdHidden').val()===value.city_id){
	    					selectedIndex	= ' selected="selected"';
	    				} 
	    				 $('#cityId' + idName).append('<option value="'+value.city_id+'"'+selectedIndex+'>'+value.city_name+'</option>');	 		
					});		
				}		
			});		
		}
		function saveEventDetails(){		
			var address = $("#confAddress").val();
			var postalCode = $("#confPostalCode").val();
			var country = $("#countryId1 option:selected").text();
			var state = $("#stateId1 option:selected").text();
			var city = $("#cityId1 option:selected").text();
			var dataString = 'address='+address+'&country='+country+'&state='+state+'&city='+city+'&postalCode='+postalCode;
			$.ajax({
				type: "POST",
				url: "<?php echo base_url()?>events/events/get_lat_long_dynamically",
				data: dataString,
				cache: false,
				success: function(jsonResult){
					var result = $.parseJSON(jsonResult);
					if(result){
						$("#latitude").val(result.lat);
						$("#longitude").val(result.lon);
					}else{
						//alert("Latitude and Longitude not found for given address");
						$("#latitude").val('0');
						$("#longitude").val('0');
					}
				},
				complete: function (jsonResult) {
					saveConferenceDetail();
			    }
			});
		}	
		function saveConferenceDetail(){
// 			// Disable the SAVE Button
// 			disableButton("saveConference");
			$("#conferenceForm").validate().resetForm();
			if(!$("#conferenceForm").validate().form()){
				$('html, body').animate({
		            scrollTop: $(".error").first().offset().top-100
		        });
				//enableButton("saveConference");
				return false;
			}
			//dont save if dates provided are wrong
			var startDate=$('#confStart').val();
			var endDate=$('#confEnd').val();
			if(startDate!='' || endDate!=''){
				if(!isValidDate(startDate,true,endDate,'conf')){
					//enableButton("saveConference");
					return false;
				}
				if(!isValidDate(endDate,false,startDate,'conf')){
					enableButton("saveConference");
					return false;
				}
			}
			// Check if the Event Name is present in Master table or not
			eventName	=	$("#confEventName").val(); 
			// URL to get the Event Lookup ID, if Name is present
			urlAction = base_url+'events/events/get_event_id_else_save/'+eventName;
			// Variable to hold the eventLookup Id
			eventLookupId	= '';
			$.post(urlAction,'',
					function(returnData){
						if(returnData){
							eventLookupId	= returnData;
							$("#confEventNameNotFound").hide();
//							location.reload();
							saveConferenceDetails(eventLookupId);
						}else{
							//enableButton("saveConference");
							$("#confEventNameNotFound").show();
							// Set the user entered name in the 'Add New Event Lookup' form
							$("#eventLookupName").val(eventName);
							return false;
						}
					},"json");
		}	
		function saveConferenceDetails(eventLookupId){
			$("#confEventId").val(eventLookupId);
			$('div.eventMsgBox').removeClass('alert-success');
			$('div.eventMsgBox').addClass('alert-warning');
			$('div.eventMsgBox').show();
			$('div.eventMsgBox').html('Saving the data... <img src="<?php echo base_url()?>assets/images/ajax_loader_black.gif" />');
			formAction = '<?php echo base_url();?>events/events/save_event1';
			$.post(formAction,$("#conferenceForm").serialize(),
				 function(returnData){		
				$('html, body').animate({
		            scrollTop: $("div.eventMsgBox").first().offset().top-100
		        });
	     		$('div.eventMsgBox').html(returnData.msg);
     			if(returnData.saved == true){
					$('div.eventMsgBox').removeClass('alert-warning');
					$('div.eventMsgBox').addClass('alert-success');
		     	}else{
		     		enableButton("saveConference");
					$('div.eventMsgBox').removeClass('alert-success');
					$('div.eventMsgBox').addClass('alert-danger');
			    }
    			$('div.eventMsgBox').fadeOut(10000);
				},"json");
		}		
		//Opens the tab based topics in a model box
		function showAllTopics(){
			$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
			$("#eventTopics").dialog(modalBoxLayout);
			$(".profileContent").load('<?php echo base_url().'events/events/view_all_topics/'?>');
			return false;
		}	
	</script>