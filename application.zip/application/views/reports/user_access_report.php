<?php 

	$queued_js_scripts = array('i18n/grid.locale-en','jquery.jqGrid.min');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
	<style type="text/css">
		
		.title-bar-actions{
			float:right;
			margin-right: 19px;
		}
		.title-bar-actions .sprite_iconSet{
			float:right;
			margin-left: 0;
		}
		.title-bar-actions .blueButton{
			background: none no-repeat scroll left center #BBBBBB;
		    border-color: #8A8A8A !important;
		    margin-left: 5px;
		}
		.reasonContent{
			height: 79px !important;
			width:350px;
		}
		.reasonContent .profileContent{
			height: 60px !important;
    		min-height: 40px !important;
		}
		.title-bar-actions .approve-button, .title-bar-actions .reject-button{
			padding-bottom: 2px;
		}
		.title-bar-actions .approve-button{
			background-image: url("../images/approve.png");
			background-size: 22px auto;
    		padding-left: 23px;
		}
		.title-bar-actions .reject-button{
			background-image: url("../images/reject.png");
			background-size: 16px auto;
    		padding-left: 24px;
		}
		#cb_myPendingApprovalsResultSet{
			margin-left: 6px;
		}
		.rowFailed {
			color: red !important;
		}
                <?php if(IS_IPAD_REQUEST == 1){ ?>
		.tabsContainer li{
			font-size: 12px;
		}
        #load_listMslActivityResultSet{
            display:none !important;
        }
         .tabsWrapper ul.tabsContainer{
		list-style: none;
		border-bottom: 1px solid #D0CCC9;
	    line-height: 21px;
	    margin: 0px;
	}
	.tabsWrapper ul.tabsContainer li{
		display: inline;
		background-color: #ECECEC;
		border:1px solid #D0CCC9;
		border-bottom-color: #ececec;
		padding: 2px 5px;
	}
	.tabsWrapper ul.tabsContainer li.current{
		border-bottom: 2px solid #fff;
		background-color: #fff;
	}
	.tabsWrapper ul.tabsContainer li.current a{
		color:#333333;
	}
	.tabsWrapper ul.tabsContainer li a{
		text-decoration: none;
		padding: 0 5px;
		font-weight: bold;
		color: #333333;
	}
	.tabsWrapper div.tabsContent{
		border: 1px solid #D0CCC9;
		padding:5px;
		border-top: 0px;
	}
	.tabsWrapper .tabsContent div.tabContent{
		display: none;
	}
        <?php } ?>
	</style>
<script type="text/javascript">
                var lastRequestXHR;
                function cancelLastRequest(){
                        lastRequestXHR.abort();
                        $("#applyFilter").val("Apply Filters");
                        $("#applyFilter").attr("onclick","reloaReport();");
                }
		function filterCurrentReport(data){
			allProfileRequests(data);
		}

		function allProfileRequests(data){
			var ele=document.getElementById('allProfileRequestsGridContainer');
			var gridWidth=ele.clientWidth;
			jqgridMinWidth = gridWidth;
			$("#allProfileRequestsGridContainer").html("");
			// Append the required div and table
			$("#allProfileRequestsGridContainer").html('<table id="allProfileRequestsResultSet"></table><div id="allProfileRequestsPager"></div>');
			jQuery("#allProfileRequestsResultSet").jqGrid({
			   	url:'<?php echo base_url()?>login/list_all_user_analytics_details/',
				datatype: "json",
			 	colNames:['Id','MSL Name','Team Name','Title','Login Time','OS','Browser'],
			   	colModel:[
							{name:'id',index:'id', hidden:true},
							
							{name:'user_name',index:'user_name', search:true},
							{name:'group_name',index:'group_name', search:true},
							{name:'title',index:'title',width:100, resizable:false,title: false},
                                                        
							{name:'created_on',index:'created_on',width:110, search:true},
                                                        {name:'os',index:'os',width:100, resizable:false,title: false},
                                                        {name:'browser',index:'browser',width:100, resizable:false,title: false}
			   	],
			   	postData:data,
			   	rowNum:10,
			   	rownumbers: true,
				//rownumWidth: 60,
				multiselect: false,
			   	autowidth: true, 
			   	loadonce:false,
			   	ignoreCase:true,
			   	hiddengrid:false,
			   	height: "auto",	
			   	width:"100%",
			   	resizable:true,
			   	shrinkToFit: true,
			   	pager: '#allProfileRequestsPager',
			   	mtype: "POST",
			   	sortname: 'institute_id',
			    viewrecords: true,
			    sortorder: "desc",
			    jsonReader: { repeatitems : false, id: "0" }, 
			    caption:"User Access Report",
			    rowList:paginationValues,
                            loadBeforeSend: function (xhr) { 
                                lastRequestXHR = xhr; 
                            },
			    afterInsertRow: function(id, data)
		        {
		            if(parseInt(data.is_login_failed) == 1) {
		                $('tr#'+id).find('td').addClass('rowFailed');
		            }
		        },
			   	gridComplete: function(){
                                    $("#applyFilter").val("Apply Filters");
	    	$("#applyFilter").attr("onclick","reloaReport();");
		        	var postParams = $('#allProfileRequestsResultSet').getGridParam("postData");
		        	//alert(postParams.toSource());
		        	postParams = JSON.stringify(postParams);
		        	$("#filters").val(postParams);
		    	},
		    	onSelectAll: function(aRowids,status) {
		    	
			          
		        }
			});
			//jQuery("#JQBlistAllResultSet").jqGrid('navGrid','#listAllPager',{edit:false,add:false,del:false,search:false,refresh:false});
			jQuery("#allProfileRequestsResultSet").jqGrid('navGrid','#allProfileRequestsPager',{edit:false,add:false,del:false,search:false,refresh:false});
			//Toolbar search bar below the Table Headers
			jQuery("#allProfileRequestsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn",beforeSearch: function(){
				$(".ui-search-toolbar input[type='text']").each(function(){
					if($(this).val() == 'Search')
						$(this).val("");
			    });
			},afterSearch:function(){
				/*$(".ui-search-toolbar input[type='text']").each(function(){
					if($(this).val() == '')
						$(this).val("Search");
			    });*/
			}});

			//Add action button in the title bar
                          <?php if (!IS_IPAD_REQUEST) { ?>
    			var buttonsText = "<div class='title-bar-actions'>";
    				buttonsText += "<div class='excelExportIcon sprite_iconSet' onclick='export_excel()' >	<a rel='tooltip' href='#' title='Export'>&nbsp;</a>	</div>";
    				buttonsText += "</div>";
                            <?php } else { ?>
                        var buttonsText = "<div style='float:right;  margin-right: 21px;' class='title-bar-actions'>";
                            buttonsText += '<input type="button" value="Export excel as email" onclick="export_excel();" class="toggle-button" style="margin-top:-3px;">';
                            buttonsText += "</div>";
                            <?php } ?>
			$("#allProfileRequestsGridContainer .ui-jqgrid-titlebar").append(buttonsText); 	
			jqgridIds	= new Array('allProfileRequestsResultSet');	
		}

		$(document).ready(function(){
			//allProfileRequests();
		});



		function findPos(obj) {
			 var obj2 = obj;
			 var curtop = 0;
			 var curleft = 0;
			 if (document.getElementById || document.all) {
			  do  {
			   curleft += obj.offsetLeft-obj.scrollLeft;
			   curtop += obj.offsetTop-obj.scrollTop;
			   obj = obj.offsetParent;
			   obj2 = obj2.parentNode;
			   while (obj2!=obj) {
			    curleft -= obj2.scrollLeft;
			    curtop -= obj2.scrollTop;
			    obj2 = obj2.parentNode;
			   }
			  } while (obj.offsetParent)
			 } else if (document.layers) {
			  curtop += obj.y;
			  curleft += obj.x;
			 }
			 return [curtop, curleft];
			}   // en
			
		function export_excel(){
				var excelFilters = '';
				$("#allProfileRequestsGridContainer .ui-jqgrid tr.ui-search-toolbar th input").each(function(){
					if($(this).val() != ''){
						var filterName = $(this).attr('name');
						var filterValue = $(this).val();
						excelFilters += filterName+" : "+filterValue+",";
					}
				});
				//$("#filters").val(excelFilters);
				var selectedOPtion = $(".ui-pg-selbox").val();
				$(".ui-pg-selbox option:last").attr('selected','selected');
		    	$('.ui-pg-selbox').trigger('change');
		    	var arrIds = jQuery("#allProfileRequestsResultSet").jqGrid('getDataIDs'); 
		    	$('#exportIds').val(arrIds);
			//	return false;
                        <?php if (!IS_IPAD_REQUEST) { ?>
                        $('#exportClientRequestDetail').submit();
                        <?php } else { ?>
                          var data= $("#exportClientRequestDetail").serialize();
                               sendMail(data);
                        <?php } ?>
		    	$(".ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');
		    	$('.ui-pg-selbox').trigger('change');
			}
            function sendMail(data){
        alert("Excel has been mailed successfully.");
      $.ajax({
         
                    url: "<?php echo base_url()?>reports/send_email_for_export_reports/User_Access",
                            dataType: "json",
                            data: data,
                            type: "POST",
                            success: function (responseText) {
                           
                            },
                            complete: function () {
                           
                            }
                    });               
    }

		
	</script>


	<form action="<?php echo base_url()?>login/export_analytic_detail/client" method="post" id="exportClientRequestDetail">
		<input type="hidden" value="" name="exportIds" id="exportIds"></input>
		<input type="hidden" value="" name="filters" id="filters"></input>
		<input type="hidden" value="" name="type" id="type">
	</form>
        <?php if(IS_IPAD_REQUEST == 1){ ?>
	<div style="margin-bottom: 10px;">
		<a class="btn btn-default" href="<?php echo base_url().IPAD_URL_SEGMENT;?>/reports/list_all_ireports" >Back</a>
	</div>
<?php }?>
	<div class="tabsWrapper" id="test">
		<ul class="tabsContainer">
			<li class="current" name="tab0"><a id="list" href="#">Report</a></li>
			<!--<li name="tab1"><a id="chart" href="#">chart</a></li>-->
		</ul>
		<div class="tabsContent">
			<div class="tab0 tabContent" style="display:block;">
				<div>
					<div class="gridWrapper" id="allProfileRequestsGridContainer">
						<table id="allProfileRequestsResultSet">Select Filters for report</table>
						<div id="allProfileRequestsPager"></div>
					</div>		
				</div>
			</div>
		</div>
	</div>
	

