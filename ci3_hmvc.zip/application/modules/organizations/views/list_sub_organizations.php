
<link rel="stylesheet" href="http://localhost/hmvc/assets/jqgrid/css/jquery-ui-1.8.4.custom.css" />
<link rel="stylesheet" href="http://localhost/hmvc/assets/jqgrid/css/ui.jqgrid.css" />
<link rel="stylesheet" href="http://localhost/hmvc/assets/jqgrid/css/ui.multiselect.css" />
<link rel="stylesheet" href="http://localhost/hmvc/assets/jqgrid/css/jqgrid.css" />

<script type="text/javascript" src="http://localhost/hmvc/assets/jqgrid/jquery.js"></script>
<script type="text/javascript" src="http://localhost/hmvc/assets/jqgrid/jquery-ui-1.8.4.custom.min.js"></script>
<script type="text/javascript" src="http://localhost/hmvc/assets/jqgrid/i18n/grid.locale-en.js"></script>
<script type="text/javascript" src="http://localhost/hmvc/assets/jqgrid/jquery.jqGrid.min_3.8.js"></script>
<script type="text/javascript">
var base_url = "<?php echo base_url(); ?>";
var orgId = '<?php echo $arrOrganization['id'];?>';
$(document).ready(function(){
	subOrgListView();
});
function subOrgListView(){
	$('#subOrgGridContainer').html('');
 	$('#subOrgGridContainer').html('<table id="subOrgResultSet"></table><div id="subOrgPage"></div>');
	var ele=document.getElementById('subOrgGridContainer');
	var gridWidth=ele.clientWidth;
//	gridWidth-=-5;

	jQuery("#subOrgResultSet").jqGrid({
	
	   	url:base_url+'organizations/list_sub_org_details/'+orgId,
		datatype: "json",
		colNames:['Id','Institute Name','Address','City','Postal Code','State' ,'Country','','Action','','','','created_by_full_name','data_type_indicator'],
	   	colModel:[
			{name:'id',index:'id', hidden:true},
			{name:'sub_org',index:'sub_org',
				
				 formatter: function (cellvalue, options, rowObject) {
				//if(rowObject.status=='Completed'){
				var orgId= rowObject.id;
		        return "<a href='"+base_url+"/organizations/view/"+orgId+"' target='New' class='link' title='" + $.jgrid.stripHtml(cellvalue) + "'>" +
		            $.jgrid.htmlEncode(cellvalue) + "</a>";
				//}else{
					//return $.jgrid.htmlEncode(cellvalue);
				//}
						
	    	},firstsortorder:'asc'
			},
			{name:'address',index:'address',width:205},
	   		{name:'city',index:'city',width:100},
	   		{name:'postal_code',index:'postal_code',width:100},
	   		{name:'region',index:'region',width:100},
	   		{name:'country',index:'country',width:100},
	   		{name:'status',index:'status' ,hidden:true},
	   		{name:'act',index:'act' ,width:70,search:false},
	   		{name:'created_by',index:'created_by' ,hidden:true},
	   		{name:'eAllowed',index:'eAllowed' ,hidden:true},
	   		{name:'client_id',index:'client_id' ,hidden:true},
	   		{name:'created_by_full_name',index:'created_by_full_name',hidden:true},
	   		{name:'data_type_indicator',index:'data_type_indicator', hidden:true}

	   	],
	   	rowNum:10,
	   	rownumbers: true,
	   	autowidth: false, 
	   	loadonce:true,
	   	multiselect: false,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",		   
	   	pager: '#subOrgPage',
	   	mtype: "POST",
	   	sortname: 'name',
	    viewrecords: true,
	    sortorder: "desc",
	    gridComplete: function(){						     
	
		    var ids = jQuery("#subOrgResultSet").jqGrid('getDataIDs'); 
	    	for(var i=0;i < ids.length;i++){ 
	    			var be='';
			    	var cl = ids[i];	
			    	var isAnalyst = jQuery("#subOrgResultSet").jqGrid('getCell',cl,'client_id');
                    var createdByName = jQuery("#subOrgResultSet").jqGrid('getCell',cl,'created_by_full_name'); 
			    	var ret = jQuery("#subOrgResultSet").jqGrid('getRowData', cl);
			    	val = ret.is_manual;
			    	if(isAnalyst != 1 && isAnalyst != '' && isAnalyst != 'null'){                    
						be = "<div class='actionIcon iconCreatedByUser tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Added by: "+createdByName+"' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'></a></div>";
	                 }else{
	                 //	jQuery("#JQBlistAllResultSet").jqGrid('setRowData',ids[i],{created_by_full_name:'Aissel Analyst'});
	                 	var dataTypeIndicator = jQuery("#subOrgResultSet").jqGrid('getCell',cl,'data_type_indicator');
	                 	be += data_type_indicator(dataTypeIndicator);		    		
	                 }
			    	if(ret.eAllowed=='true'){
				    	be += "<div class='actionIcon editIcon tooltip-demo tooltop-left'><a href='"+base_url+"organizations/add_sub_org/"+ret.id+"/1' class='tooltipLink' rel='tooltip' title='Edit'>Edit</a></div>";
				    	be += "&nbsp;";
				    	be += "<div class='actionIcon deleteIcon tooltip-demo tooltop-left' onclick=\"deleteSubOrg('"+ret.id+"'); return false;\"><a href='#' class='tooltipLink' rel='tooltip' title='Delete'>Delete</a></div>";				    	
			    	}
			    	jQuery("#subOrgResultSet").jqGrid('setRowData',ids[i],{act:be});
				    	microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewClinicalTrialMicroProfile('"+ret.id+"');return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Clinical Trial Snapshot\">&nbsp;</a></div></label>";
				    	jQuery("#statsResultSet").jqGrid('setRowData',ids[i],{micro:microviewLink}); 
			    	} 
		    
		    	jQuery("#subOrgResultSet").jqGrid('navGrid','hideCol',"id");
			    
		    	//Initialize the tooltips
		    	
	    	}, 
	    jsonReader: { repeatitems : false, id: "0" }, 
	    caption:"AFFILIATES & PARTNERS",
		//rowList:paginationValues
		
	});
	jQuery("#subOrgResultSet").jqGrid('navGrid','#subOrgPage',{edit:false,add:false,del:false,search:false,refresh:false});

	//Toolbar search bar below the Table Headers
	jQuery("#subOrgResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
	
	//Toggle Toolbar Search 
	jQuery("#subOrgResultSet").jqGrid('navButtonAdd',"#subOrgPage",{
		caption:"Search",title:"Toggle Search",
		onClickButton:function(){ 			
			if(jQuery(".ui-search-toolbar").css("display")=="none") {
				jQuery(".ui-search-toolbar").css("display","");
			} else {
				jQuery(".ui-search-toolbar").css("display","none");
			}							
		} 
	}); 
	jQuery("#subOrgResultSet").jqGrid('setGridWidth',gridWidth);
}

/*
* To open the modal box to add new Org
* @author vianyak
* @since 
* @created on 8-7-2011
*/
function editSubOrg(orgId){
	$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$('#addSubOrg').dialog("open");
	$('#subOrgContainer').load(base_url+'organizations/edit_sub_org/'+orgId);
	return false;

}

function deleteSubOrg(orgId){
			$.ajax({
				url: base_url+'organizations/delete_sub_org/'+orgId,
				type: "post",
				dataType:"json",
				success: function(returnData){
					if(returnData.status){
						subOrgListView();
					}
			}	
			});
}
</script>
<style>
table.ui-pg-table {
    font-size: 1.7em;
}
.object-name {
    display: inline-block;
}
.panel{
border-radius:0px !important;
}
.panel-group .panel+.panel {
    margin-top: 0px !important;
}
.panel-title {
    font-size: 13px !important;
    font-weight: bold;
}
.title{
	font-size: 14px;
	margin-top: 20px;
    font-weight: bold;
    border-bottom:1px dashed #ccc;
}
.box-background{
	background: #f4f4f4;

}
.top-buttons{
    position: absolute;
    top: 0;
    right: 0;
    margin-top: 5px;
    font-size: 12px;
}
.glyphicon { margin-right:10px; }
.panel-body { padding:0px; }
.panel-body table tr td { padding-left: 15px }
.panel-body .table {margin-bottom: 0px; }
.org-box{margin-bottom:10px;padding :10px; min-height: 190px;}
.border-box{ border:1px solid #ccc;} 
.subnotes{margin-top:10px;}
input[type=file] {
    display: inline !important;
}
.organization-container-head{
	/* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#ffffff+0,f4f4f4+47,c9c9c9+100 */
background: #ffffff; /* Old browsers */
background: -moz-linear-gradient(top,  #f0f0f0 0%, #f4f4f4 47%, #c9c9c9 100%); /* FF3.6-15 */
background: -webkit-linear-gradient(top,  #f0f0f0 0%,#f4f4f4 47%,#c9c9c9 100%); /* Chrome10-25,Safari5.1-6 */
background: linear-gradient(to bottom,  #f0f0f0 0%,#f4f4f4 47%,#c9c9c9 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#f0f0f0', endColorstr='#c9c9c9',GradientType=0 ); /* IE6-9 */
	
}
p.profileName {
    margin-bottom: 0px;
    font-weight: bold;
    text-align: center;
}
#organizationShortDetails {
    text-align: center;
    width: 100%;
    background: #ffffff;
    padding: 10px 0;
    color: #000000;
    font-weight: bold;
    border-top: 1px solid #ccc;
}
.top-header{
	padding:5px 0;
}
.margin-zero{
	margin-top:0 !important;
}
/*key people css */
.tab-pane{
	border-left:1px solid #ccc;
	border-right:1px solid #ccc;
	border-bottom:1px solid #ccc;
	padding: 10px;
	height: 100%;
}
.content{
	min-height: 600px;
}
</style>
<script>
function saveFiltersLayout(){
	$(".modal-body").load('http://localhost/hmvc/organizations/add_client_keypeople/'+orgId);
}
</script>
<div class="row top-header">
	<?php $this->load->view('organizations/organization_header_bar'); ?>
</div>
<div class="row">
		<div class="secondary-menu col-md-2" style="padding-right: 0px;padding-left: 0px;">
			<?php $this->load->view('organizations/organization_left_side_bar'); ?>
		</div>
		<div class="content col-md-10" style="border-left: 1px solid #ccc;">
				<ul class="nav nav-tabs">
				  <li class="active"><a data-toggle="tab" href="#key-people">AFFILIATES & PARTNERS</a></li>
				</ul>
				
				<div class="tab-content">
				  <div id="key-people" class="tab-pane fade in active">
				    <div class="col-md-12">
				    	<a href="<?php echo base_url();?>organizations/add_sub_org/<?php echo $arrOrganization['id'];?>" class="btn custom-btn btn-primary pull-right">Add AFFILIATES</a>
				    </div>
				    <div class="row">
					<div class="col-md-12">
						<p class="title"></p>
							<div class="gridWrapper clear" id="subOrgGridContainer">
							<table id="subOrgResultSet"></table>
							<div id="subOrgPage"></div>
							</div>
					</div>
				</div>
				  </div>
				</div>
		</div>
</div>