<?php


?>

	<!-- Load the Custom CSS file -->
	<!--[if IE 7]>
		<link type="text/css" href="<?php echo base_url()?>css/default_ie_only.css" rel="stylesheet" />
	<![endif]-->
	
	
	<script type="text/javascript">

//function waitForMsg(){
//$.ajax({
//		type: "POST",
//		url: '<?php echo base_url();?>media_intel_extractions/ajaxTest',
//		async: true,
//                
//                data:{id:2},
//		cache: false,
//		
//		success: function(data){
//		
//		setTimeout("waitForMsg()",1000);
//		},
//		error: function(XMLHttpRequest,textStatus,errorThrown) {
//		
//		setTimeout("waitForMsg()",15000);
//		}
//	  });
//	}
		function list_kols_grid(){
			var lastsel2;
			$('#gridKolsListing').html('');
		    $('#gridKolsListing').html('<div class="gridWrapper"><div id="gridKolsListingPagintaion"></div><table id="gridKolsListingResultSet"></table><div>');
		    grid = $("#gridKolsListingResultSet"),
            getUniqueNames = function(columnName) {
                var texts = grid.jqGrid('getCol',columnName), uniqueTexts = [],
                    textsLength = texts.length, text, textsMap = {}, i;
             //   jAlert(texts.toSource());
                for (i=0;i<textsLength;i++) {
                    text = texts[i];
                    if (text !== undefined && textsMap[text] === undefined) {
                        // to test whether the texts is unique we place it in the map.
                        textsMap[text] = true;
                        uniqueTexts.push(text);
                    }
                }
                return uniqueTexts;
            },
            buildSearchSelect = function(uniqueNames) {
                var values=":All";
                $.each (uniqueNames, function() {
                    values += ";" + this + ":" + this;
                });
                return values;
            },
           
            grid.jqGrid({
				url:'<?php echo base_url();?>media_intel_extractions/list_logs',
				datatype: "json",
				colNames:['Id','Controller','Created On','type','status', 'URL','Description','Client ID'],
			   	colModel:[
					{name:'id',index:'id', hidden:true, search:false, resizable:false,resizable:false},
					{name:'controller',index:'controller',search:true,width:110},
			   		{name:'created_on',index:'created_on',width:110, search:true},
			   		{name:'type',index:'type',search:true,width:110, resizable:false},
			   		{name:'status',index:'status',search:true},
			   		{name:'url',index:'url',width:90, editable: false, edittype:"select", editoptions:{value:"0:No;1:Yes;2:Re Crawl"}},
                                        {name:'description',index:'description',width:90, editable: false, edittype:"select", editoptions:{value:"0:No;1:Yes;2:Re Crawl"}},
				
					  {name:'client_id',index:'client_id',width:90, editable: false, edittype:"select", editoptions:{value:"0:No;1:Yes;2:Re Crawl"}},
			   	],
			   	onSelectRow: function(id){
				   //alert(id);	
                if(id && id!==lastsel2){
                  grid.restoreRow(lastsel2);
                  grid.editRow(id,true);
                  lastsel2=id;
                }
               },
               onCellSelect: function(id){
	   				var option=$("option[value='0']", $('#'+id+'_pubmed_processed'));
	   				option.attr("disabled","disabled");
               },
               
             
			   	rowNum:10,
			   	multiselect: false,
			   	rownumbers: true,
			   	autowidth: true, 
			   	loadonce:true,
			   	ignoreCase:true,
			   	hiddengrid:false,
			   	height: "auto",		 
			   	pager: '#gridKolsListingPagintaion',
			   	mtype: "POST",
			   	sortname: 'name',
			    viewrecords: true,
			    sortorder: "desc",
			    shrinkToFit:true,
			    jsonReader: { repeatitems : false, id: "0" }, 
			    caption:"Media Log",
			    gridComplete: function(){	
			    },
				rowList:paginationValues
			});
//           
			grid.jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
			//Toggle Toolbar Search 
			//grid.jqGrid('navButtonAdd',"#gridKolsListingPagintaion",{caption:"Search",buttonicon:"ui-icon-search",title:"Toggle Search"});
		}
	
		$(document).ready(function(){
			// Settings for the Dialog Box
			var modalBoxAddOpts = {
					title: "",
					modal: true,
					autoOpen: false,
					width: 600,
					dialogClass: "microView",
					position: ['center', 160],
					open: function() {
						//display correct dialog content
					}
			};
			$("#exportKolsContainer").dialog(modalBoxAddOpts);
		
			list_kols_grid();
			
		});
		
                function ignore(id)
                {
                    $.ajax({
                                url:'<?php echo base_url()?>media_intel_extractions/ignore_source/',
                                type:'post',
                                dataType:"TEXT",
                                async:false,
                                data:{id:id},
                                success:function(returnMsg){
                                      alert("Source Disabled for users");
                                                list_kols_grid();
                                        }
                        });
                }       
                
                function restore(id)
                {
                    $.ajax({
                                url:'<?php echo base_url()?>media_intel_extractions/restore_source/',
                                type:'post',
                                dataType:"TEXT",
                                async:false,
                                data:{id:id},
                                 
                                success:function(returnMsg){
                                    alert("Source Enabled for users");
                                                list_kols_grid();
                                        }
                        });
                }  
		function deleteSelectedKols(kolIds){
			jConfirm("Are you sure you want to delete selected KOL's?","Please confirm",function(r){
					if(r){
						$.ajax({
							url:'<?php echo base_url()?>media_intel_extractions/delete_source/'+kolIds,
							type:'post',
							dataType:"json",
							success:function(returnMsg){
									list_kols_grid();
								}
						});
						}else{
								return false;
							}
				});
		}
	</script>
	
	<style type="text/css">
		#listKols a{
			letter-spacing: 0px;
		}
		.ui-widget-content a {
			color:#000099;
		}
/*		.icon {
			 padding-top: 6px;
		}
*/
		.buttons {
			float: none;
		}
		tr.selectedRow {
		    background-color: #D8DFEA !important;
		}
		#contents{
			padding:10px 50px;
		}
		
		#contents table{
			font-size:125%;
			border-collapse:collapse;
		/*	border:1px solid #ccc; */
		}
		
		#contents table, td, th{
		/*	border:1px solid #ccc; */
		}
		
		h1{
			color:#2E6E9E;
			font-size:170%;
			margin-bottom:10px;
			margin-top:15px;
			text-align:left;
		}
		
		#linkHeaders{
			float:left;
			text-align:right;
		}
		a.addLink{
			text-decoration:none;
		}
		
		div#listKolsTbl{
			padding:0;
			width:100%;		
		}
		div.extraOptions div.rightSideOptions{
			text-align: right;
		}
		div.extraOptions div.leftSideOptions{
			float:left;
			text-align: left;
			width: 50%;
			margin-top: 5px;
		}
		input[type="checkbox"]{
			position: static;
		}
		.additionalLinks a{
			display:block;
			width:220px;
			float: left;
		}
		
		select.pubmed-status{
			width: 65px;
			float: left;
		}
		
		button.pubmed-status-chnage-btn{
			background-color: green;
		    border: 0 none;
		    border-radius: 5px 5px 5px 5px;
		    cursor: pointer;
		    display: block;
		    float: right;
		    height: 13px;
		    margin-right: 0;
		    margin-top: 5px;
		    width: 14px;
		}
		.processing{
			background-image: url("../images/anim_loading_16x16.gif");
			background-color: #ffffff !important;
		}
		.setting-dorpdowns{
			display: inline-block;
   			margin-right: 14px;
		}
		
		.setting-dorpdowns button{
		    margin-left: 5px;
		    margin-top: 1px;
		    top: 0;
		}
		
	</style>
	

	
		<div class="msgBoxContainer"><div class="kolMsgBox"></div></div>
		<div class="extraOptions">
		 	<!-- <div class="leftSideOptions">
				<?php 
					if($clientUser['client_id']==1 && $clientUser['user_role_id']==2){ ?>
						<input type="button" value="Delete" name="submit" class="buttons" onclick="deleteKols();"></input>
				<?php } ?>		
				<input type="button" name="bb" class="buttons" onclick="showKolExportBox();" value="Excel Export"></input>
			</div>
		-->
			<div class="rightSideOptions">
				<!--<a class="addLink" href="<?php echo base_url();?>media_intel_extractions/add_source"><img src="<?php echo base_url();?>images/bullet_add.png" border="0" style="height: 30px;vertical-align: middle;" />Add New Source</a>-->
			</div>
		</div>
		<div id="gridKolsListing">
			<div class="gridWrapper">
				<div id="gridKolsListingPagintaion"></div>
				<table id="gridKolsListingResultSet"></table>
			</div>
		</div>
		<div class="extraOptions">
			<div class="leftSideOptions">
				
			</div>
			<div class="rightSideOptions">
				<!--<a class="addLink" href="<?php echo base_url();?>media_intel_extractions/add_source"><img src="<?php echo base_url();?>images/bullet_add.png" border="0" style="height: 30px;vertical-align: middle;" />Add New Source</a>-->
				
			</div>
		</div>
		
		<!-- 
		<div id="listKols">
			<div id="listKolsTbl">
				<table class="listResultSet">
					<thead>
						<tr class="headerBg">
							<th><input type='checkbox' name='checkall' onclick='checkedAll(this);' /></th>
							<th>Name</th>
							<th>Specialty</th>
							<th>Gender</th>
							<th>Organizations</th>
							<th>Pubmed Processed ?</th>
							<th>Clinical Trial Processed ?</th>
							<th>Created By</th>
							<th>Action</th>
							
						</tr>
					</thead>
				
				</table>
				<div class="extraOptions">
					<div class="leftSideOptions">
						<?php 
							if($clientUser['client_id']==1 && $clientUser['user_role_id']==2){ ?>
								<input type="button" value="Delete" name="submit" class="buttons" onclick="deleteKols();"></input>
						<?php } ?>		
						<input type="button" name="bb" class="buttons" onclick="showKolExportBox();" value="Excel Export"></input>
					</div>
					<div class="rightSideOptions">
						<a class="addLink" href="<?php echo base_url();?>kols/add_kol"><img src="<?php echo base_url();?>images/bullet_add.png" border="0" style="height: 30px;vertical-align: middle;" />Add New Profile</a>
						<input type="button" name="bb" class="buttons" onClick="showKolImportBox()" value="Excel Import"></input>
					</div>
				</div>
				<?php 
				
					if($clientUser['client_id']==1 && $clientUser['user_role_id']==2){ ?>
						<blockquote style="margin:0px;font-style: normal;float: left;">
							<a href="<?php echo base_url();?>clinical_trials/process_clinical_trials">Process Clinical Trials</a><br />
							<a href="<?php echo base_url();?>pubmeds/process_pubmeds"> Process Publications</a>
						</blockquote>
							
				<?php } ?>
				
			</div>
		</div>
 		-->
	<!-- Container for the 'Kol's Export' modal box -->
	<div id="exportKolsDialog" style="display:none">	
		<div id="exportKolsContainer" class="microProfileDialogBox">
			<div class="profileContent" id="exportKolsProfileContent"></div>
		</div>
	</div>
	<!--End of  Container for the 'Kol's Export' modal box -->	
<div id="online-status"></div>




