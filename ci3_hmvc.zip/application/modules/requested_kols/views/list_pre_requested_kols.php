<style>
	caption {
	    padding: 8px 8px;
	    text-align: left;
	    border-color: #2E6E9E;
	    color: #FFF;
	    background-color: #2E6E9E;
	    margin-top: 20px;
	    font-size: 15px;
	}
	.table>caption+thead>tr>th{
		font-size:13px;
	}
	.table>tbody>tr>th, .table>tbody>tr>td{
		font-size:12px !important;
		padding:5px !important;
	}
	button.btn.btn-primary {
	    vertical-align: top;
	}
	.checkbox, .radio{
		margin-top:0px  !important;
		margin-bottom:0px  !important;
	}
	.checkbox input[type=checkbox]{
		margin-left:0px  !important;
	}
</style>
	
	<script type="text/javascript">


	$(document).ready(function(){
		
		var addNewKol = {
				title: "Add KOL",
				modal: true,
				autoOpen: false,
				width: 400,
				draggable:false,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};
		$("#newKolProfile").dialog(addNewKol);
	
	});
	
	function addNewKolProfile(){
		var Kol = new Array();
		$.each($('input[name="exportId[]"]:checked'),function(){
			Kol.push($(this).val());
		});
		if(Kol==''){
			jAlert("Select At least 1 KOL");
			return false;
		}

		if((Kol.length)>1){
			jAlert("Select only 1 KOL");
			return false;
		}
		
		
		$(".newProfileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#newKolProfile").dialog("open");
		$(".newProfileContent").load('<?php echo base_url()?>requested_kols/add_client_pre_kol/'+Kol[0]);
		return false;	
	}

</script>
<div class="container-fluid" style="margin-top:20px;">
<?php $userRoleId = $this->session->userdata('user_role_id');?>
	<div class="col-md-12">
		<button onclick="addNewKolProfile()" class="btn btn-primary" style="">Request Profile</button>				
	</div>
	<div class="col-md-12">
		<div class="msgBox"></div>
	</div>
	<div id="listKols" class="col-md-12">
		<div id="listKolsTbl" class="table-responsive">
		  <table class="listResultSet table ">
			  <caption>List of Requested KOL's profiles</caption>
			  <thead>
			    <tr>
			      	<th>ID</th>
					<th>Select</th>
					<th>Name</th>
					<th>Specialty</th>
					<th>Gender</th>
					<th>Organizations</th>
					<th>Created By</th>
					<th>Status</th>
			    </tr>
			  </thead>
			  <tbody>
    			<?php 
					$slNo	= 1;
					foreach($arrKol as $kol){
						echo '<tr id=KOL_'.$kol['kol_id'].'>';
						echo '<td>' .$slNo. '</td>';
							echo "<td class='export'>
									<input type='checkbox' name='exportId[]' value='$kol[kol_id]'>
								</td>";
						if($kol['salutation']<='4'&& $kol['salutation']!='0'){
							$name	= $arrSalutations[$kol['salutation']] . ' ';
						}else{
							$name='';
						}
						$name	.= $kol['first_name'] . ' ';
						$name	.= $kol['middle_name'] . ' ';
						$name	.= $kol['last_name'];
						
						echo '<td><a href="'.base_url().'kols/edit_kol/'.$kol['kol_id'].'">' .$name. '</a></td>';
						if($kol['specialty']!='0'){
							echo '<td>' .$kol['specialty']. '</td>';
						}else{
							echo '<td> &nbsp; </td>';
						}
						echo '<td>' .$kol['gender']. '</td>';
						echo '<td>' .$kol['name']. '</td>';
						
						echo '<td>' .$kol['user_full_name']. '</td>';
			
					
						echo '<td>' .$kol['status']. '</td>';
						echo '</tr>';
						
						$slNo++;
					}
				
				?>
			  </tbody>
			</table>
	</div>
	</div>
</div>
			<!-- Container for the 'Kol's Export' modal box -->
			<div id="newKolProfile" class="microProfileDialogBox">
					<div class="newProfileContent profileContent"></div>
				</div>
			<!--End of  Container for the 'Kol's Export' modal box -->	

					





