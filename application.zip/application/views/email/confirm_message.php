Hi <?php echo $userDetail['first_name']." ".$userDetail['last_name']?>,
The password on your <?php echo PRODUCT_VERSION;?> Application account has been successfully changed. If you feel this is an error, please contact us at support@aissel.com.

Thanks, 
<?php echo PRODUCT_VERSION;?> Support

