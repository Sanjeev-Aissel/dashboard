<?php


/**
 * This is HTML page to show Interation micro view profile
 * 
 * @author Ramesh B
 * @Created on: 04-03-11
 * @since  1.5	
 */
$previousUrl=$_SERVER['HTTP_REFERER'];
$link_array = explode('/',$previousUrl);
$page = end($link_array);
?>
<script src="<?php echo base_url(); ?>js/jquery.autocomplete.js"></script>
<style>
    .microView h3 {
        background: none repeat scroll 0 0 #EEEEEE;
        line-height: 25px;
        text-align: center;
    }
    #interactionMicroProfileContent .alignRight{
        padding-right: 1px;
    }
    table.tabularGrid caption{
        /*background:url("<?php echo base_url(); ?>images/kolm-sprite-image.png") repeat-x scroll -2px -236px transparent;*/
        background: #ececec none repeat scroll 0 0;
    	box-shadow: 0 0 4px #d1d1d1 inset;
    	color: #333333;
    	padding-left: 5px;
    }
    table.tabularGrid td:FIRST-CHILD{
        padding-left: 5px;
    }
    table.interactionDetails td:nth-child(1){
        width: 150px !important;
    }
    table.interactionDetails td:nth-child(2){
        width: 300px !important;
    }
    table.interactionDetails td:nth-child(3){
        width: 150px !important;
    }
    #interactionMicroProfileContent table.highlightHeadings tr th{
        background-color: #eee;
    }
    h5.heading{
        background: none repeat scroll 0 0 #D8E5F4;
        color: #2D53AF;
        margin-bottom: 2px;
        padding: 5px;
    }

    #historyContainer > div > div{
        border-bottom: 1px solid #bbbbbb;
    }
    #historyContainer ul{
        list-style: none;
    }
</style>
<script type="text/javascript">
    $(document).ready(function () {
        $('table.tabularGrid caption div.collapseSlider').click(function () {
            if ($(this).attr('class') != "collapseSlider") {
                $(this).parent().parent().find('tr').hide();
                $(this).find('a').attr('data-original-title', 'Expand');
            } else {
                $(this).parent().parent().find('tr').show();
                $(this).find('a').attr('data-original-title', 'Collapse');
            }
            $(this).toggleClass('expandSlider');
        });

     // Binding the function for slidechange event 
    	$(document).on("click",".downloadIcon",function(){
    		var url = $(this).attr('href');
    		if(url=="#"){
    			jAlert("You do not have permission to download this file");
    		}
    	})
    });


    function showIntarctionTable() {
        //window.location=base_url+'interactions/list_interactions';
        $('#interactionsContainer').show();
        $('#viewInteractionContainer').html("");
        $("#viewInteractionContainer").hide();
    }
</script>
<?php
$date = '';
$timing = '';
$this->load->model('common_helpers');
if ($interactionDetails['date'] != "0000-00-00") {
    $date = explode('/', $this->common_helpers->convertDateToMM_DD_YYYY($interactionDetails['date']));
    //$date = 'on '.date("M d, Y", mktime(0, 0, 0, $date[0], $date[1], $date[2])).' ';
    $date = date("M d, Y", mktime(0, 0, 0, $date[0], $date[1], $date[2])) . ' ';
}
$phpdate = strtotime($interactionDetails['fromtime']);
$mysqldate = date("g:i A", $phpdate);
if ($interactionDetails['fromtime'] != '00:00:00') {
    $timing = 'at ' . $mysqldate;
}
?>

<div id="interactionMicroProfileContent">
    <?php if($page!="list_uoq" && !isset($fromPlan)) { ?>
    <div><?php if(isset($backLink) && $backLink > 0) echo '<a class="blueButton" href="'.base_url().'interactions/view_numeric_report">Back to Interactions</a>'; else echo '<button onclick="location.reload();">Back to Interactions</button>';?></div><?php } ?>
    <div class="microViewThumbnail"></div>
    <?php // pr($interactionDetails); ?>
    <table class="highlightHeadings tabularGrid interactionDetails">
        <?php //pr($internal_users); ?>
        <caption>Interaction Details
            <div id="collapseExpandButton" class="expandSlider collapseSlider">
                <a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
            </div>
        </caption>
        <tr>
            <td>
            	<table>
            		<tr>
            			<td class="alignRight"><strong>Interaction ID:&nbsp; </strong></td>
            			<td><?php echo $interactionDetails['generic_id']?></td>
            		</tr>
            		<tr>
            			<td class="alignRight"><strong>Interaction Date:&nbsp; </strong></td>
            			<td><?php echo sql_date_to_app_date($interactionDetails['date']); ?></td>
            		</tr>
            		
            		
            		<tr>
            			<td class="alignRight"><strong>Interaction Type:&nbsp;</strong></td>
            			<td><?php echo $interactionDetails['mode_name']; ?></td>
            		</tr>
                        <tr>
            			<td class="alignRight"><strong>Plan Name:&nbsp;</strong></td>
            			<td><?php
                                     foreach ($plans as $key => $value) {
							$selected	= '';
							if($key == $plan_id){
								echo $value;
							}
                                    } ?></td>
            		</tr>
            	</table>
            </td>
            <td>
            	<table>
            		
            		<tr>
            			<td class="alignRight"><strong>Number of Attendees:&nbsp;</strong></td>
            			<td><?php echo $interactionDetails['total_attendies']; ?></td>
            		</tr>
            		<tr>
            			<td class="alignRight"><strong>Interaction Category:&nbsp;</strong></td>
            			<td><?php if ($interactionDetails['group_name'] != "") echo $interactionDetails['group_name']; ?></td>
            		</tr>
            		<tr>
            			<td class="alignRight"><strong>Interaction Location:&nbsp;</strong></td>
            			<td><?php echo $interactionDetails['location_category_name']; ?></td>
            		</tr>
            		<tr>
            			<td class="alignRight"><strong>&nbsp;</strong></td>
            			<td>&nbsp;</td>
            		</tr>
                      
                      
                        
            	</table>
            </td>
        </tr>
    </table>

    <table class="highlightHeadings tabularGrid">
        <caption>Discussion Topics
            <div id="collapseExpandButton" class="expandSlider collapseSlider">
                <a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
            </div>
        </caption>
        <tr>
            <th width="20px">&nbsp;</th>	
            <th><?php echo lang("Overview.Product");?></th>
            <th>Discussion Type</th>
            <th>Topic</th>
<!--            <th>Sub Topic</th>-->
        </tr>
        <?php
        foreach ($interactionDetails['aboutTopics']['objective_names'] as $key => $value) {
            ?>
            <tr>
                <td>
                    <?php if ($key == 0) { ?>
                        <span class="is_primary" style="margin-bottom: 6px; margin-left: 6px;">&nbsp;</span>
                    <?php } else { ?>
                        &nbsp;
                    <?php } ?>
                </td>
                <td><?php echo $interactionDetails['aboutTopics']['product_names'][$key]; ?></td>
                <td><?php echo $value; ?></td>
                <td><?php echo $interactionDetails['aboutTopics']['topic_names'][$key]; ?></td>
                <!--<td><?php echo $interactionDetails['aboutTopics']['sub_topic_names'][$key]; ?></td>-->
            </tr>
            <?php
        }
        ?>
          <table class="highlightHeadings tabularGrid">
        <caption>Attendees
            <div id="collapseExpandButton" class="expandSlider collapseSlider">
                <a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
            </div>
        </caption>
        <tr>
        	<th width="20px">&nbsp;</th>
        	<?php
                if ($interactionDetails['is_org_interaction']) { ?>
            <th>KTL / Key People Name</th>
            <th>Specialty</th>
            <th>Title</th>
            <?php }else{?>
            <th>KTL Name</th>
            <th>Specialty</th>
            <th>Title</th>
            <th>&nbsp;</th>
            <th>&nbsp;</th>
            <!--<th>Note</th>-->
            <?php }?>
        </tr>
        <?php
        foreach ($interactionDetails['attendees']['kol_names'] as $key => $value) {
            ?>
            <tr>
            	<td width="20px">&nbsp;</td>
                <td><?php echo $value; ?></td>
                <?php
                if ($interactionDetails['is_org_interaction']) { ?>
                <td><?php echo $interactionDetails['attendees']['specialties'][$key]; ?></td>
                <td><?php echo $interactionDetails['attendees']['title'][$key]; ?></td>
                <?php }else{?>
                <td><?php echo $interactionDetails['attendees']['specialties'][$key]; ?></td>
                <td><?php echo $interactionDetails['attendees']['title'][$key]; ?></td>
                <td><?php //echo $interactionDetails['attendees']['interaction_status'][$key]; ?></td>
                <td><?php //echo $interactionDetails['attendees']['last_interaction'][$key]; ?>&nbsp;</td>
                <td style="display:none;"><?php
                    if ($interactionDetails['attendees']['note'][$key] == "0");
                    else
                        echo $interactionDetails['attendees']['note'][$key];
                    ?></td>
                <?php }?>
            </tr>
            <?php
        }
        ?>
    </table>   
            
            <table class="highlightHeadings tabularGrid">
                <caption>Locations
                    <div id="collapseExpandButton" class="expandSlider collapseSlider">
                        <a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
                    </div>
                </caption>
                <tr>
                    <th width="20px">&nbsp;</th>	
                    <th>Location</th>
                    <th>Address</th>
                    <th>Country</th>
                    <th>City</th>
                    <th>State</th>
                </tr>
                <tr>
                    <td width="20px">&nbsp;</td>	
                    <td><?php echo $interactionDetails['location']; ?></td>
                    <td><?php echo $interactionDetails['address'].' '.$interactionDetails['address2']; ?></td>
                    <td><?php if ($interactionDetails['country'] != "") echo $interactionDetails['country']; ?></td>
                    <td><?php if ($interactionDetails['city'] != "") echo $interactionDetails['city']; ?></td>
                    <td><?php if ($interactionDetails['state'] != "") echo $interactionDetails['state']; ?></td>
                </tr>
            </table>
            
   <?php if(!$interactionDetails['is_org_interaction']){?>
    <?php if ($interactionDetails['group_name'] != 'One-on-One') { ?>
        <table class="highlightHeadings tabularGrid">
            <caption>Non-Profiled Attendees
                <div id="collapseExpandButton" class="expandSlider collapseSlider">
                    <a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
                </div>
            </caption>
            <tr>
                    <th width="40px">&nbsp;</th>
                <th>Name</th>
                <th>Specialty</th>
                <th>Comments</th>
            </tr>
            <?php
            foreach ($interactionDetails['other_attendees'] as $key => $row) {
                ?>
                <tr>
                    <td width="40px">&nbsp;</td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['specialty']; ?></td>
                    <td><?php  echo $row['comments']; ?></td>
                </tr>
                <?php
            }
            ?>
        </table>
    <?php } }?>




    <!--<fieldset>
            <legend>Location</legend>
            <table class="highlightHeadings">
                    <tr>
                            <th>Location</th>
                            <th>Address</th>
                            <th>City</th>
                            <th>State</th>
                    </tr>
                    <tr>
    <?php
    echo '<td>' . $interactionDetails['location'] . '</td>';
    echo '<td>' . $interactionDetails['address'] . '</td>';
    echo '<td>' . $interactionDetails['state'] . '</td>';
    echo '<td>' . $interactionDetails['city'] . '</td>';
    ?>
                    </tr>
            </table>
    </fieldset>
    -->

    <table class="tabularGrid">
        <caption>Notes
            <div id="collapseExpandButton" class="expandSlider collapseSlider">
                <a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
            </div>
        </caption>
        <tr>
            <td>
                <?php
                if (empty($interactionDetails['notes'])) {
                    echo '<tr><td>Notes not added</td></tr>';
                } else {
                    echo $interactionDetails['notes'];
                }
                ?>
            </td>
        </tr>
    </table>
    
    <table class="tabularGrid">
        <caption>Documents
            <div id="collapseExpandButton" class="expandSlider collapseSlider">
                <a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
            </div>
        </caption>
        <?php
            if (empty($docs)) {
                    echo '<tr><td>Documents not added</td></tr>';
            } else {
         ?>
         <tr>
			<th width="3%">&nbsp;</th>	
			<th width='30%'>Name</th>
			<th width='30%'>Description</th>
			<th width='30%'>Download</th>
        </tr>
        <?php 
	        foreach ($docs as $doc){
	            $find_doc_extn = explode(".",$doc['doc_path']);
	            if($doc['download'] == 'yes'){
	                $path = "<a class='downloadIcon' href='".base_url()."/interactions/download_interaction_document/".$doc['doc_path']."'>".$doc['name'].'.'.$find_doc_extn[1]."</a>";
	            }else{
	                $path = "<a class='downloadIcon' href='#'>".$doc['name'].'.'.$find_doc_extn[1]."</a>";
	            }
	        	echo "
 					<tr>
			        	<td width='3%'>&nbsp;</td>	
						<td width='30%'>".$doc['name']."</td>
						<td width='30%'>".$doc['description']."</td>
						<td width='30%'>".$path."</td>
			        </tr>
 				";
	        }
        ?>
         <?php 
           	}
        ?>
        
    </table>  
</div>
<!-- <td><a href='".base_url()."documents/kol_interactions_documents/".$doc['doc_path']."'>".$doc['doc_path']."</a></td> -->
<div id="historyContainer" style="display: none;">
<?php if (count($arrHistories) > 0) { ?>
        <h4 style="font-weight: bold;">Interaction History</h4>
        <hr>
        <div>
    <?php foreach ($arrHistories as $history) { ?>
                <div>
                    <ul>
                        <li>
                            <label>Modified By :</label><?php echo $history['created_by']; ?>
                        </li>
                        <li>
                            <label>Modified On :</label><?php echo sql_date_to_app_date($history['created_on']); ?>
                        </li>
                        <li>
                            <label>Changes :</label>
                            <ul>
                                    <?php foreach ($history['changes'] as $change) { ?>
                                    <li>
                                    <?php echo $change; ?>
                                    </li>
        <?php } ?>
                            </ul>
                        </li>
                    </ul>
                </div>
        <?php } ?>
        </div>
<?php } ?>
</div>

<table><tr>
        <th width="100"><?php echo CREATED_BY;?>:</th><td><?php echo $interactionDetails['created_by_name']?></td>
        <th width="100"><?php echo CREATED_ON;?>:</th><td><?php echo sql_date_to_app_date($interactionDetails['created_on']);?></td>
    </tr></table>
</table>       
	
