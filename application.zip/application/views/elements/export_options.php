<?php
/**
 * 
 * @author Laxman K
 * @since 6.0.1
 * @created on 08/11/20132
 * 
 */
?>
<style>
	#exportOptionsContainer {
		
	}
	#newOrgDropdown{
		background: #ffffff none repeat scroll 0 0;
	    border: 1px solid #aaaaaa;
	    left: -71px;
	    padding: 0;
	    position: absolute;
	    top: 21px;
	    width: 180px;
	    z-index: 10001;
	    
	    
	    background: #ffffff -moz-linear-gradient(center top , rgba(255, 255, 255, 0.05) 0%, rgba(255, 255, 255, 0.05) 20%, rgba(0, 0, 0, 0.05) 100%) repeat scroll 0 0;
	    border-radius: 2px;
	    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
	}
	#newOrgDropdown li{
		list-style: none;
		float: none;
		border-bottom: 1px inset #aaaaaa;
		padding: 0px;
	}
	#newOrgDropdown li a{
		color: #333333;
	    display: block;
	    font-size: 12px;
	    font-weight: bold;
	    padding-left: 2px;
	    text-decoration: none;	    
	}
	#newOrgDropdown li a:hover{
		background-color: #eeeeee;
	}
	 a.blueButton{
	 	color: #ffffff !important;
	 }
	 a.addInteractionButton{
	 	color: #ffffff !important;
	 }
	 a.addInteractionButton.activeIcon{
	 	color: #2b9af3 !important;
	 }
</style>
<script>
    function toggleListingView() {
        $('.tooltip.in').hide();
        if (viewType == 'list') {
            viewType = 'tabular';
            $('#toggleViewIcon').removeClass('listView');
        } else {
            viewType = 'list';
            $('#toggleViewIcon').addClass('listView');
        }
        doSearchFilter(0);
    }

    function showNewOrgDropdown(e){
		$("#newOrgDropdown").show();
		e.stopPropagation();
    }
    function hideNewOrgDropdown(){
    	$("#newOrgDropdown").hide();
    }
	
    $(document).ready(function(){
    	$("html").mouseover(function(e){
//    		hideNewOrgDropdown();
		});
		
    	$("html").click(function(e){
    		hideNewOrgDropdown();
		});		
		$("#newOrgDropdown ul").mouseover(function(e){
			e.stopPropagation();
		});
		$("#newOrgDropdown ul li").mouseover(function(e){
			e.stopPropagation();
		});
	});	

    function addNewOrgProfile(id,thisEle){
		/*closeOrgProfile();
		$(".addNewOrgProfileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#addNewOrg").dialog("open");
		$("#addNewOrg").dialog('option','width',400);
		$("#addNewOrg").dialog('option','position',['center', 80]);
		$(".addNewOrgProfileContent").load(base_url+'organizations/add_client_org_request/'+id);
		return false;*/
		jConfirm(orgRequestConfirmMessage,"Confirm message",function(r){
			if(r){
		    	if(userRoleId == ROLE_MANAGER || userRoleId == ROLE_ADMIN)
					jAlert("The Organization Profile request(s) will be sent for processing. You will not be able to undo this request. You will get a notification once the requests are processed");
				else
					jAlert("Your Organization Profile request has been submitted to your manager for approval. We will notify you when your request is approved");
				var data = {};
				data['org_id'] = id;
				data['profile_type'] = "Full Profile";		
				$.ajax({
					url:base_url+'requested_orgs/save_org_request',
					type:'post',
					dataType:'json',
					data:data,
					success:function(returnData){
						if(returnData.hidden){
							$(thisEle).remove();
						}
					}
				});
			}else{
				return false;
			}
		});
	}

   
</script>
<div class="exportOptionsContainer tooltip-demo tooltop-right" style="padding-bottom: 3px;">
    <ul>
        <?php
        $requestKolId = 'requestKolId'.$arrKol['id'];
        switch ($currentController) {
            case 'kols': if ($currentMethod == 'list_kols_client_view') {
                    ?>
                    <li>
                        <div id="toggleView" >
                            <div id="toggleViewIcon" <?php if(isset($listView)){ if($listView>1){ echo "class='listView'";} }?>><a rel='tooltip' title="Change View" href="#" onclick="toggleListingView();
                                                return false;">&nbsp;</a></div>
                        </div>
                    </li>
                    <?php /*if($this->common_helpers->isActionAllowed('profile_request','add',$kolDetails)){ ?>
                    <li>
                        <span id="kolRequestForHint" style="display: block;height: 18px;width: 1px;float: left;"></span>
                        <div class="kolRequestIcon sprite_iconSet"><a rel='tooltip' title="New Contact Profile Request" href="<?php echo base_url() ?>requested_kols/show_client_requested_kols" >&nbsp;</a></div>
                    </li>
                   <?php } */?>
                    <!--<li>
                        <div class="myCustomersIcon sprite_iconSet tooltip-demo tooltop-right"><a  rel='tooltip' title="Colpal Contacts" href="<?php echo base_url() ?>requested_kols/show_non_profiled_kols" >&nbsp;</a></div>
                    </li>
                    --><li>
                        <div class="createListIcon sprite_iconSet" onclick="displayModelBox();"><a  rel='tooltip' title="Create List" href="#">&nbsp;</a></div>
                    </li>
                     <?php if($this->session->userdata('user_role_id') != ROLE_READONLY_USER){ ?>
                    <li>
                        <div class="alignToUsersIcon sprite_iconSet" onclick="alignUsers();"><a  rel='tooltip' title="Assign Profiles" href="#">&nbsp;</a></div>
                    </li>
                    <?php } ?>
                    <li>
                        <div class="excelExportIcon sprite_iconSet" onclick="showKolExportBox();"><a  rel='tooltip' title="Export profiles into Excel format" href="#">&nbsp;</a></div>
                    </li>
                    <li>
                        <div class="pdfExportIcon sprite_iconSet" onclick="exportPdfProfile();" style="margin-left: 2px;">
                            <form action="<?php echo base_url() ?>kols/export_pdf" id="kolPdfExport" method="post">
                                <a  rel='tooltip' title="Export profile into PDF format" href="#">&nbsp;</a>
                            </form>
                        </div>
                    </li>
                    <li>
                        <div id="emailIcon" class="emailId sprite_iconSet" onclick="showEmailModalBoxInOvearllPage()">
                            <a rel="tooltip" title="Email Profile" href="#">&nbsp;</a>
                        </div>
                    </li><!--
                    <li>
                        <label id="countKolMsg"></label>
                    </li>
                    --><?php
                } else if (($currentMethod != 'search_kols') &&
                        ($currentMethod != 'view_kol_adv_search') &&
                        ($currentMethod != 'adv_search_kols') &&
                        ($currentMethod != 'adv_search') &&
                        ($currentMethod != 'search_events') &&
                        ($currentMethod != 'view_event_adv_search') &&
                        ($currentMethod != 'adv_search_events') &&
                        ($currentMethod != 'client_index') &&
                        ($currentMethod != 'list_kols_client_view') &&
                    ($currentMethod != 'add_ol')  && ($currentMethod != 'edit_ol') && ($currentMethod != 'add') && ($subContentPage!='add_opt_in_form') &&
                        ($currentMethod != 'import_kol_profiles')) {
                    /* if($currentMethod=="view" && ($subContentPage=="bio" || $subContentPage=="")){
                      if($arrKol['status'] == PRENEW){?>
                      <li><input type="button" id='kolRequestButton' onclick="addNewKolProfile(<?php echo $arrKol['id'];?>)" value="Request Profile" /></li>
                      <?php }
                      } */
                    ?>
                    <li><div class="createListIcon sprite_iconSet" <?php if((isset($arrKol) && $arrKol['imported_as']==1)){?>onclick="is_id_profile();return false;" <?php }else{?>onclick="showListModalBox();" <?php }?>>
                            <a  rel='tooltip' title="Create List" href="#">&nbsp;</a>
                        </div></li>
                    <li><div class="excelExportIcon sprite_iconSet" onClick="showSingleKolExportBox(<?php echo (isset($arrKol['id']) ? $arrKol['id'] : 0); ?>)">
                            <a  href="#"  rel="tooltip" title="Export profiles into Excel format">&nbsp;</a>
                        </div></li>
                    <li><div class="pdfExportIcon sprite_iconSet">
                            <a rel="tooltip" title="Export profile into PDF format" href="<?php echo base_url() . 'kols/export_pdf/' . (isset($arrKol['id']) ? $arrKol['id'] : 0); ?>" target="_new">&nbsp;</a>
                        </div></li>
                    <li><div id="emailIcon" class="emailId sprite_iconSet" onclick="showEmailModalBox(<?php echo (isset($arrKol['id']) ? $arrKol['id'] : 0); ?>)">
                            <a  rel="tooltip" title="Email Profile" href="#">&nbsp;</a>
                        </div></li>
                   <?php if($currentMethod=='view' && ($this->uri->segment(4)=='edit' || $this->uri->segment(4)=='details')) { }else {?>
                       <?php $data['kol_id'] = $arrKol['id']; if($this->common_helpers->isActionAllowed('kol_details','add',$data)){ ?> 
                       <li>
                            <div class="assignedUsers">
                                <label style="float: left;">Assigned to:</label>
                                <div style="float: right;">
                                    <?php
                                    if (count($assignedUsers) > 2) {
                                        $arrChunk = array_chunk($assignedUsers, 2);
                                        echo '<p class="tooltip-demo tooltop-bottom" style="float:left;margin:0px;">&nbsp;' . implode($arrChunk[0], ', ');
                                        echo '<a style="text-decoration:none;" href="#" rel="tooltip" title="' . implode($assignedUsers, '<br />') . '"> more...</a>';
                                        echo '</p>';
                                    } else {
                                        echo '<p style="float:left;margin:0px;">&nbsp;' . implode($assignedUsers, ', ') . '</p>';
                                    }
                                    //if(count($assignedUsers)<=2){
                                    ?>
                                    <div class="actionIcon editIcon tooltip-demo tooltop-bottom" style="float: right; margin-left: 4px; margin-top: 2px;">
                                        <a class="tooltipLink" 
                                        <?php if((isset($arrKol) && $arrKol['imported_as']==1)){?>onclick="is_id_profile();return false;" <?php }else{?>onclick="editUsers(<?php echo $arrKol['id'] ?>, 'Edit');"<?php }?> href="#" rel="tooltip" data-original-title="Edit">&nbsp;</a>
                                    </div>
                                    <?php
                                    //}
                                    if (count($assignedUsers) > 2) {
                                        ?>
                                        <!-- a onclick="editUsers(<?php echo $arrKol['id'] ?>,'all');" id="showLink">&nbsp;Show All</a-->
                                    <?php } ?>
                                </div>
                            </div>
                        </li>
                        <?php } ?>
                    <?php } ?>
                <?php } else if ($currentMethod == 'adv_search') {
                    ?>
                    <li>
                        <div class="createListIcon sprite_iconSet" onclick="displayModelBox();"><a  rel='tooltip' title="Create List" href="#">&nbsp;</a></div>
                    </li>
                    <li>
                        <div class="excelExportIcon sprite_iconSet" onclick="showKolExportBox();"><a  rel='tooltip' title="Export profiles into Excel format" href="#">&nbsp;</a></div>
                    </li>
                    <li>
                        <div class="pdfExportIcon sprite_iconSet" onclick="exportPdfProfile();">
                            <form action="<?php echo base_url() ?>kols/export_pdf" id="kolPdfExport" method="post">
                                <a  rel='tooltip' title="Export profile into PDF format" href="#">&nbsp;</a>
                            </form>
                        </div>
                    </li>
                    <li>
                        <div id="emailIcon" class="emailId sprite_iconSet" onclick="showEmailModalBoxInOvearllPage()">
                            <a  rel="tooltip" title="Email Profile" href="#">&nbsp;</a>
                        </div>
                    </li>
                    <li>
                        <label id="countAdvKolMsg"></label>
                    </li>
                    <?php
                }
                break;
            case 'organizations': if ($currentMethod == 'list_organizations_client_view') {
                    ?>
                    <li>
                        <div id="toggleView" class="tooltip-demo tooltop-right">
                            <div id="toggleViewIcon"><a rel='tooltip' title="Change View" href="#" onclick="toggleListingView();
                                                return false;">&nbsp;</a></div>
                        </div>
                    </li>
                    <?php /*?><li>
                        <div class="orgRequestIcon sprite_iconSet tooltip-demo tooltop-right">
                            <a href="<?php echo base_url(); ?>requested_orgs/show_client_requested_orgs" rel="tooltip" data-original-title="New Organization Profile Request">&nbsp;</a>
                        </div>
                    </li><?php */?>
                    <?php if($this->session->userdata('user_role_id') != ROLE_READONLY_USER){ ?>
                    <li>
                        <div class="alignToUsersIcon sprite_iconSet" onclick="alignOrgUsers();"><a rel='tooltip' title="Assign Profiles" href="#">&nbsp;</a></div>
                    </li>
                    <?php } ?>
                    <?php if($this->session->userdata('client_id') == INTERNAL_CLIENT_ID) {?>
                   <li>
                        <div id="excelExport" class="exportOptionsContainer tooltip-demo tooltop-right" onclick="orgExportExcel()">
            <!--											<form action="<?php echo base_url() ?>organizations/multiple_org_export" id="orgExport" method="post">-->
            <!--												<input type="hidden" name="org_ids" value="" id="orgIds"></input>-->
                            <div id="organizationExport" class="excelExportIcon sprite_iconSet"><a rel='tooltip'  title="Export Organizations into Excel format" href="#">&nbsp;</a></div>
                            <!--											</form>-->
                        </div>
                    </li>
                    <?php }?>
                    <?php /*?> 
                    <li>
                        <div class="pdfExportIcon sprite_iconSet tooltip-demo tooltop-right" onclick="exportOrgPdf();" style="margin-left: 2px;">
                            <a rel="tooltip" title="Export profile into PDF format"  target="_new" id="orgPdf">&nbsp;</a>
                        </div>
                    </li><php */?>
                    <li>
<!--                        <label id="countMsg"></label>-->
                    </li>
                     <?php 
            			 } else if ($currentMethod != 'list_organizations_client_view' && $currentMethod != 'add_org') {
                    ?>
                    <li><div class="tooltip-demo tooltop-right exportOptionsContainer">
                            <!-- <div id="organizationExport" class="excelExportIcon sprite_iconSet"><a  rel='tooltip' title="Export Organization into Excel format" href="<?php echo base_url() ?>organizations/single_org_export/<?php echo $arrOrganization['id'] ?>/<?php echo $arrOrganization['type_id'] ?>">&nbsp;</a></div> -->
                        </div></li>
                    <?php /*if ($arrOrganization['profile_type'] == FULL) { ?>
                        <li><div class="pdfExportIcon tooltip-demo tooltop-right sprite_iconSet">
                                <a rel="tooltip" title="Export profile into PDF format" href="<?php echo base_url() . 'organizations/export_as_pdf/' . (isset($arrOrganization['id']) ? $arrOrganization['id'] : 0) . '/' . $arrOrganization['type_id'] ?>" target="_new">&nbsp;</a>
                            </div></li>
                    <?php } */?>
                    <li>
                    <?php $data['org_id'] = $arrOrganization['id']; if($this->common_helpers->isActionAllowed('org_details','add',$data)){ ?> 
                        <div class="assignedOrgUsers">
                            <label style="float: left;">Assigned to:</label>
                            <div style="float: right;">
                                <?php
                                if (count($assignedUsers) > 2) {
                                    $arrChunk = array_chunk($assignedUsers, 2);
                                    echo '<p class="tooltip-demo tooltop-bottom" style="float:left;margin:0px;">&nbsp;' . implode($arrChunk[0], ', ');
                                    echo '<a style="text-decoration:none;" href="#" rel="tooltip" title="' . implode($assignedUsers, '<br />') . '"> more...</a>';
                                    echo '</p>';
                                } else {
                                    echo '<p style="float:left;margin:0px;">&nbsp;' . implode($assignedUsers, ', ') . '</p>';
                                }
                                ?>
                                <?php //if(count($assignedUsers)<=2){ ?>
                                <div class="actionIcon editIcon tooltip-demo tooltop-bottom" style="float: right; margin-left: 4px; margin-top: 2px;">
                                    <a class="tooltipLink" onclick="editOrgUsers(<?php echo $arrOrganization['id'] ?>, 'Edit');" href="#" rel="tooltip" data-original-title="Edit">&nbsp;</a>
                                </div>
                                <?php // }  ?>
                            </div>
                        </div>
                        <?php } ?>
                    </li>
                    <?php
                }
                break;
            case 'requested_kols': if ($currentMethod == 'show_non_profiled_kols') {
                    ?>
                    <li>
                        <a class="blueButton" rel='tooltip' title="Add Contact" href="#" onclick="showFormToAddKol()">Add</a>
                    </li>
                    <li>
                        <a class="blueButton" rel='tooltip' title="Back to My Contact profiles listing" href="<?php echo base_url(); ?>kols/list_kols_client_view">Back to contacts</a>
                    </li>
                    <?php
                }
                if ($currentMethod == 'show_client_requested_kols') {
                    ?>
                    <?php //<li><a class="blueButton" href="#" onclick="addNewKolProfile()" class="tooltipLink" rel='tooltip' title="Submit new profile request">Add</a></li> ?>
                    <!-- <li><a class="blueButton" href="#" onclick="showUpgradeBox()" class="tooltipLink" rel='tooltip' title="Upgrade existing profile">Upgrade</a></li> -->
                    <?php
                }
                break;
            case 'requested_orgs': /*if ($currentMethod == 'show_client_requested_orgs') {
                    ?>
                    <li><a class="blueButton" href="#" onclick="addNewOrgProfile()" class='tooltipLink' rel='tooltip' title='Submit new organization request'>Add</a></li>
                    <?php
                }*/
                break;
                case 'identifications': if($currentMethod=='home'){?>
                    <li><a href="<?php echo base_url();?>identifications/priority_settings" rel="tooltip" class="NewBlueButton prioritySetting"  title='Priority Settings'>Priority Settings</a></li>
						
                                                            <!--<a class="NewBlueButton prioritySetting" href="<?php echo base_url();?>identifications/priority_settings" class='tooltipLink' rel='tooltip' title='Priority Settings'><span></span></>Priority Settings</a>>-->
							
							<div id="filtersApplied" class="tooltip-demo tooltop-bottom">
								<span class="filterSections"></span>
								<div id="resetBttnContainer"><a href="#" onclick="resetFilters();">Reset Filters</a><label class="tooltip-demo tooltop-bottom" id="resetBttn" onclick="resetFilters();"><a data-original-title="Reset Filters" href="#" class="tooltipLink" rel="tooltip">&nbsp;</a></label></div>
							</div>
							<div style="color: rgb(0, 0, 153); display: inline-block; margin-top: 11px;" onclick="addFilters();" id="addFilters"><a title="Save all active filter selections" rel="tooltip" href="#"><div id="addFilters1"></div></a>&nbsp;<a href="#">Save Filters</a></div>
					<?php }
					if($currentMethod=='priority_settings'){?>
							<li style="margin-left: 136px;"><a class="blueButton" href="<?php echo base_url();?>identifications/home" class='tooltipLink' rel='tooltip' title='Back to Identification Report'><span></span></>Back to Identification Report</a></li>
							
					<?php }
				break;
        }
        ?>
    </ul>
    <ul class="pageRightOptions">
        <?php
        switch ($currentController) {
            case 'kols': if ($currentMethod == 'view' && $subContentPage != 'survey_form') {?>
            		
                    <?php /* if($this->common_helpers->isActionAllowed('profile_request','edit',$arrKol)){ ?>
                        <li>
                            <div class="tooltip-demo tooltop-bottom" style="text-align: right;">
                                <a class="blueButton" href="#" onclick="addNewKolProfile(<?php echo $arrKol['id']; ?>,this)" class="tooltipLink" rel='tooltip' title="Request Profile">Request Profile</a>
                            </div>
                        </li>
                    <?php }*/ ?>
                    <li>
                        <div class="tooltip-demo tooltop-bottom" style="text-align: right;">
                        <?php if ($subContentPage != 'interaction_report' && $subContentPage != 'list_medical_insights' && $subContentPage != 'list_speaker_evaluation') {?>
                            <!--<a class="NewBlueButton addInfluForKol" onclick="addInfluencerForKol(<?php echo $arrKol['id']; ?>);" href="#" class="tooltipLink" rel='tooltip' title="Add Influencers">Add Influencers</a>-->
                        <?php }?>                   
                        
                        <?php
                        if(KOL_CONSENT){
                            if($arrKol['opt_in_out_status'] == 4 || $arrKol['opt_in_out_status'] == 0){
                        $arrKol['kol_id']=$arrKol['id'];if($this->common_helpers->isActionAllowed('profile_request','edit',$arrKol) && $subContentPage != 'payments' && $subContentPage != 'show_contracts'){?>
						    
						<?php if($arrKol['profile_type']=='User Added' || $arrKol['profile_type']=='Legacy'){ 
						    if($arrKol['request_status']==1 || $arrKol['request_status']==2) {?>
					    	<a class="NewBlueButton requestProfileIcon <?php echo $requestKolId;?>" href="#" class="tooltipLink" rel='tooltip' title="Request" style="pointer-events:none;cursor:default;text-decoration:none;background: #bbbbbb none repeat scroll 0 0;border: 1px solid #bbbbbb;">Requested</a>
					    <?php } else {?>
							<a class="NewBlueButton requestProfileIcon <?php echo $requestKolId;?>" href="#" onclick="addNewKolProfileUAL(<?php echo $arrKol['id'];?>,this); return false;" class="tooltipLink" rel='tooltip' title="Request">Request</a>
						<?php } }else{ 
						    if($arrKol['request_status']==1 || $arrKol['request_status']==2) {?>
						    	<a class="NewBlueButton requestProfileIcon <?php echo $requestKolId;?>" href="#" class="tooltipLink" rel='tooltip' title="Request" style="pointer-events:none;cursor:default;text-decoration:none;background: #bbbbbb none repeat scroll 0 0;border: 1px solid #bbbbbb;">Requested</a>
						    <?php } else {?>
							<a class="NewBlueButton requestProfileIcon <?php echo $requestKolId;?>" href="#" onclick="addNewKolProfile(<?php echo $arrKol['id'];?>,this); return false;" class="tooltipLink" rel='tooltip' title="Request">Request</a>	
						<?php  } } }}}else {
                        $arrKol['kol_id']=$arrKol['id'];if($this->common_helpers->isActionAllowed('profile_request','edit',$arrKol) && $subContentPage != 'payments' && $subContentPage != 'show_contracts'){?>
						    
						<?php if($arrKol['profile_type']=='User Added' || $arrKol['profile_type']=='Legacy'){ 
						    if($arrKol['request_status']==1 || $arrKol['request_status']==2) {?>
						    	<a class="NewBlueButton requestProfileIcon <?php echo $requestKolId;?>" href="#" class="tooltipLink" rel='tooltip' title="Request" style="pointer-events:none;cursor:default;text-decoration:none;background: #bbbbbb none repeat scroll 0 0;border: 1px solid #bbbbbb;">Requested</a>
						    <?php } else {?>
							<a class="NewBlueButton requestProfileIcon <?php echo $requestKolId;?>" href="#" onclick="addNewKolProfileUAL(<?php echo $arrKol['id'];?>,this); return false;" class="tooltipLink" rel='tooltip' title="Request">Request</a>
						<?php } } else{ 
						    if($arrKol['request_status']==1 || $arrKol['request_status']==2) {?>
					    	<a class="NewBlueButton requestProfileIcon <?php echo $requestKolId;?>" href="#" class="tooltipLink" rel='tooltip' title="Request" style="pointer-events:none;cursor:default;text-decoration:none;background: #bbbbbb none repeat scroll 0 0;border: 1px solid #bbbbbb;">Requested</a>
					    <?php } else {?>
						<a class="NewBlueButton requestProfileIcon <?php echo $requestKolId;?>" href="#" onclick="addNewKolProfile(<?php echo $arrKol['id'];?>,this); return false;" class="tooltipLink" rel='tooltip' title="Request">Request</a>	
						<?php } } } }
                        if(KOL_CONSENT){
                            if($arrKol['opt_in_out_status'] == 4 || $arrKol['opt_in_out_status'] == 0){
                                if($this->common_helpers->isActionAllowed('interaction','add',$kolDetails,$arrKol) && $subContentPage != 'payments' && $subContentPage != 'show_contracts'){ ?>
                            <a id="addInterButton" class="NewBlueButton addInteractionButton" href="<?php echo base_url().'kols/view/'. $arrKol['unique_id'].'/interaction_report/1';?>" class="tooltipLink" rel='tooltip' title="Add Interactions">Add Interaction</a>
                        <?php }
                            }
                        }else{
                            if($this->common_helpers->isActionAllowed('interaction','add',$kolDetails,$arrKol) && $subContentPage != 'payments' && $subContentPage != 'show_contracts'){?>
                        	<a id="addInterButton" class="NewBlueButton addInteractionButton" href="<?php echo base_url().'kols/view/'. $arrKol['unique_id'].'/interaction_report/1';?>" class="tooltipLink" rel='tooltip' title="Add Interactions">Add Interaction</a>
                        <?php }
                        }?>
            <!--						<a class="blueButton" href="<?php echo base_url() . 'kols/view/' . $arrKol['id'] . '/survey_form'; ?>" class="tooltipLink" rel='tooltip' title="Add Influencers">Add Influencers</a>-->
                        </div>
                    </li>
                    <?php
                } 
                break;
            case 'find_experts': if ($currentMethod == 'profile') {
                    ?>
                    <div style="margin-top: 2px;">
                        <div style="float: right;">
                            <button id="hide" class="blue_btn">Hide Sidebar</button>
                            <button id="show" class="blue_btn">Show Sidebar</button>
                        </div>
                        <div class="action_buttons" style="float: left;">
                            <a href="#"><img src="<?php echo base_url(); ?>images/find_experts/add_contact.png" title="Add to my customer" onclick="showFormToAddKol('<?php echo $authDetails['_id']['$id']; ?>')"></img></a>
                            <?php if ($is_bookmarked) { ?>
                                <a href="#" id="bookMrk" onclick="RemoveBookmarkLink('<?php echo $authDetails['_id']['$id']; ?>');"><img src="<?php echo base_url(); ?>images/find_experts/remove_bookmark.png" title="Remove Bookmark"></img></a>
                            <?php } else { ?>
                                <a href="#" id="bookMrk" onclick="CreateBookmarkLink('<?php echo $authDetails['_id']['$id']; ?>');"><img src="<?php echo base_url(); ?>images/find_experts/add_bookmark.png" title="Bookmark profile"></img></a>
                            <?php } ?>
                           <!--  <a href="#"><img src="<?php echo base_url(); ?>images/find_experts/req_profile.png" title="Request profile" onclick="addNewKolProfile('<?php echo $authDetails['_id']['$id']; ?>')"></img></a>  -->
                        </div>
                    </div>
                    <?php
                } break;
            case 'surveys': if ($currentMethod == 'sales_report' || $currentMethod == 'hcp_report') {
                    ?>
                    <li>
                        <div class="tooltip-demo tooltop-bottom" style="text-align: right;">
                            <a class="blueButton" href="#" onclick="exportGridToExcel();" class="tooltipLink" rel='tooltip' title="Export To Excel">Export To Excel</a>
                        </div>
                    </li>
                    <?php
                }
                break;
			case 'organizations':/*if ($currentMethod == 'view') {?>
                    <?php if($this->common_helpers->isActionAllowed('org_profile_request','add',$arrOrganization)){ ?>
                        <li>
                            <div class="tooltip-demo tooltop-bottom" style="text-align: right;">
                                <a class="blueButton" href="#" onclick="addNewOrgProfile(<?php echo $arrOrganization['id']; ?>,this)" class="tooltipLink" rel='tooltip' title="Request Profile">Request Profile</a>
                            </div>
                        </li>
                    <?php 
                    }
                }*/
			    if ($currentMethod == 'view' || $currentMethod == 'view_keypeople' || $currentMethod == 'view_sub_organizations' || $currentMethod == 'view_interactions' || $currentMethod == 'view_events' || $currentMethod == 'view_publications' || $currentMethod == 'view_clinical_trials' || $currentMethod == 'view_network_map') {
			        $arrOrganization['org_id'] = $arrOrganization['id']; if($this->common_helpers->isActionAllowed('org_profile_request','',$arrOrganization) && $subContentPage != 'show_contracts') {?>
			    <li> 
    				<div class="tooltip-demo tooltop-bottom" style="text-align: right;">
    						<a class="NewBlueButton requestProfileIcon" href="#" onclick="addNewOrgProfile(<?php echo $arrOrganization['id'];?>,this); return false;" class="tooltipLink" rel='tooltip' title="Request">Request</a>
            		</div>
        		</li>
			   <?php } }                                          
               if ($currentMethod == 'view' || $currentMethod == 'view_keypeople' || $currentMethod == 'view_sub_organizations' || $currentMethod == 'view_interactions' || $currentMethod == 'view_events' || $currentMethod == 'view_publications' || $currentMethod == 'view_clinical_trials' || $currentMethod == 'view_network_map') {
                   if($this->common_helpers->isActionAllowed('org_interaction','add',array('org_id' => $arrOrganization['id'],'created_by' => $arrOrganization['created_by'])) && $subContentPage != 'show_contracts'){ ?>
						<li>
	                        <div class="tooltip-demo tooltop-bottom" style="text-align: right;">
	                        <a id="addInterButton" class="NewBlueButton addInteractionButton" href="<?php echo base_url().'organizations/view_interactions/'. $arrOrganization['id'].'/interaction/1';?>" class="tooltipLink" rel='tooltip' title="Add Interactions">Add Interaction</a>
	                        </div>
	                    </li>
					<?php }
                }
                
                if($currentMethod = 'list_organizations_client_view'){
                 	if ($data['add_org'] == 1) {
            		?> 
                    <li style="position: relative;">
            			 <a id="addPhoneButton" class="addIcon blueButton" style="text-decoration: none;float: right;"  href="<?php echo base_url().'organizations/add_org/institution';?>" rel="tooltip" data-original-title="Add Organization"><span></span>Add Organization</a>
            			 <?php /*?><ul id="newOrgDropdown" style="display: none;">
            			 	<li>
            			 		<a href="<?php echo base_url();?>organizations/add_org/institution">Institution</a>
            			 	</li>
            			 	<li>
            			 		<a href="<?php echo base_url();?>organizations/add_org/department">Department</a>
            			 	</li>
            			 	<li>
            			 		<a href="<?php echo base_url();?>organizations/add_org/managed_care_org">Managed Care Organization</a>
            			 	</li>
                                        <li>
            			 		<a href="<?php echo base_url();?>organizations/add_org/practice">Practice</a>
            			 	</li>
                                        <li>
            			 		<a href="<?php echo base_url();?>organizations/add_org/pharmacy">Pharmacy</a>
            			 	</li>
            			 </ul>  
            			 <?php */?>                  	
                    </li>
            		<?php }
                }
        			
                break;
				 
        }
        ?>

        <?php
        if ($currentMethod == 'list_kols_client_view') {
            if ($data['add_KOL'] == 1) {
            ?> 

            <li>
                <a class="NewBlueButton requestProfileIcon" rel='tooltip' title="<?php echo lang("HCP"); ?>/Contact" href="<?php echo base_url() ?>kols/add">Add <?php echo lang("HCP"); ?>/Contact</a>
            </li>
            <?php
        } }
        ?>
        <?php
       if ($currentController == 'coachings') {
           if($this->uri->segment(2)=='list_coachings'){
           ?> 
           <li>
                <div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="top: -3px !important;" onclick="export_excel();" style="float:right;  position: relative;top: -22px;">
                    <a href="#" rel="tooltip" data-original-title="Export Coachings Detail into Excel format">&nbsp;</a>    
                </div>
           </li>
           <?php if($this->common_helpers->isActionAllowed('coaching','add')){
               
               ?>
			<li><a href="#" class="NewBlueButton NewAddIcon" onclick="addCoaching();">Add New</a></li>			
			<?php }?>
           <?php
       } }
       ?>       
       <?php
       if ($currentController == 'contracts' || $subContentPage == 'show_contracts') { ?>
        <li style="color:red;"><span class="contractExpired"></span>Contract Expired</li>
        <?php 
        if($currentController=='kols' || $currentController == 'contracts'){
        $arrKol = array();
        if($kolId!=''){
            $arrKol["kol_id"]=$kolId;  
            $arrKol["contract_type"] = 'kol';
        }?>
           <?php if($this->common_helpers->isActionAllowed('contract','add',$arrKol)){
           ?>               
        <li><label class="link" onclick="addContract();" id="addButton"><div class="actionIcon addIcon" style="margin-top:0px;"></div>Add Contract</label></li>
       <?php }}
       if($currentController=='organizations'){
       if($this->common_helpers->isActionAllowed('contract','add',array('org_id' => $arrOrganization['id'],'created_by' => $arrOrganization['created_by'],'contract_type'=>'org'))){
           ?>
           <li><label class="link" onclick="addContract();" id="addButton"><div class="actionIcon addIcon" style="margin-top:0px;"></div>Add Contract</label></li>
       <?php } }?>
       <li>
       	<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="exportExcel('#listContractResultSet','contracts');">
			<a href="#" rel="tooltip" data-original-title="Export Contract Details into Excel format">&nbsp;</a>
		</div>
       </li>
       <?php }?>
        <li>
            <div style="text-align: right;">
<!--                <input id="rightSideBarEnableDisable" type="button" value="Hide Sidebar" onclick="toggleRightSideBar()" />-->
                <a id="rightSideBarEnableDisable" class="blueButton" onclick="toggleRightSideBar()" href="#">Hide Sidebar</a>
            </div>
        </li>
    </ul>
</div>
<?php if ($currentController == 'find_experts' && $currentMethod != 'profile') { ?>
    <div id="mesgBoxContainer">
        <div class="loaderMessage">
            <div class="loaderContent">
                <div class="loaderImage">
                    <div class="ldrImg"></div>
                </div>
                <div class="loaderText"></div>
            </div>
        </div>
    </div>
<?php }
?>


<!--<div id="myCustomer" class="microProfileDialogBox">
    <div class="myCustomerContent profileContent"></div>
</div>-->