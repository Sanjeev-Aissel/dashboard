<style>
.notifications{
	background: url("<?php echo base_url();?>assets/modules/notifications/images/notification_inactive.svg") no-repeat scroll -1px 0px transparent;
}
#notiticationsSection{
	background: url("<?php echo base_url();?>assets/modules/notifications/images/notification.png") no-repeat;
	bottom: -28px;
    left: -33px;
    position: absolute;
}
#icon-notification{
    background-repeat: no-repeat;
    background-size: 84% auto;
    color: #ffffff !important;
    cursor: pointer;
    display: inline-block;
    height: 40px;
    margin-top: -8px;
    vertical-align: middle;
    width: 34px;
}
#notificationCount{
	background: #ff0000 none repeat scroll 0 0;
    border: 3px solid #ffffff;
    border-radius: 12px;
    color: #ffffff;
    left: 13px;
    min-height: 14px;
    min-width: 14px;
    padding: 0 2px 1px;
    position: absolute;
    text-align: center;
    top: -11px;
    vertical-align: middle;
    cursor: pointer;
}
.notification{
width :85%;
}
</style>
<script type="text/javascript">
var modalBoxLayout = {
		title: "",
		modal: true,
		width:400,
		position:['center',100],
		resizable: true
	};
function listNotifications() {	
	$(".modalContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#modalContainer").dialog(modalBoxLayout);
	$('#ui-dialog-title-modalContainer').html('Notifications');
	$(".modalContent").load(base_url+'notifications/notifications/list_user_notifications');
	return false;
    }    
function closeNotification() {
        $("#modalContainer").dialog("close");
    }
function markNoteSeen(note_id, user_id, tr_id,thisEle) {
    $.ajax({
        url: '<?php echo base_url() ?>notifications/notifications/mark_notification_seen/' + note_id + '/' + user_id,
        type: 'post',
        dataType: 'json',
        success: function (returnData) {
            if(returnData.status){
                $(thisEle).remove();
                var notificationCount = $("#notificationCount").html();
                notificationCount = notificationCount.replace("(",'');
                notificationCount = notificationCount.replace(")",'');
                notificationCount = parseInt(notificationCount);
                notificationCount = notificationCount-1;
                if(notificationCount == 0){
                	$("#notificationCount").html("");
                }else{
					$("#notificationCount").html(notificationCount);
                }
            }
        }
    });
}   
</script>
<div class="pull-right ">
<?php
if($this->common_helper->check_module("notifications")){        	
        $ciInst = & get_instance();
        $ciInst->load->model('notifications/Notification');
        $notifications = $ciInst->Notification->getUserNotifications($ciInst->session->userdata('user_id'), "notSeen");
        ?>
	<!-- Trigger the modal with a button -->
	<div id="notiticationsSection" class="icon-notification" style="<?php if(count($notifications) == 0) echo "display:none;";?>" data-toggle="modal" data-target="#myModal">
		<span id="icon-notification" class="actionIcon addIcon"> <span
			id='notificationCount'><?php echo count($notifications);?></span>
		</span>
	</div>
	<?php }?>
	<span class="glyphicon glyphicon-user"></span>&nbsp;
	<?php echo $this->session->userdata('user_full_name');?>&nbsp;
	<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-cog"></span></a>
		<ul class="dropdown-menu">
            <li><a href="#">Action</a></li>
            <li><a href="#">Another action</a></li>
            <li><a href="#">Something else here</a></li>
            <li role="separator" class="divider"></li>
            <?php if($is_analyst_page){?>
            <li><a href="<?php echo base_url();?>logins/logins/kols">Application</a></li>
            <?php }else{
            	if($this->session->userdata('client_id')== INTERNAL_CLIENT_ID){?>
			            <li><a href="<?php echo base_url();?>configurations/configurations/client_modules">Analyst Application</a></li>
			            <?php }
            		}?>
            <li role="separator" class="divider"></li>
            <li><a href="<?php echo base_url();?>logins/logins/logout">Logout</a></li>
          </ul>
</div>
<!-- Modal to show notifications -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content for notifications-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Notifications for you</h4>
      </div>
      <div class="modal-body">
	     <table id="listNotifications">    	
	        <?php
	        $i = 0;
	        foreach ($notifications as $note) {
	            ?>
	            <tr id="note_<?php echo $i; ?>">
	    		<td class="notification"><?php echo $note['note']; ?></td>
	                <?php if($note['has_seen'] == 0){?>
	                	<td>
	    			<a style="float: right;" href="#"
	    			onclick="markNoteSeen(<?php echo $note['id'] . ", " . $note['user_id'] . ", " . $i++; ?>,this); return false;">Mark
	    				as Read</a>
	    		</td>
	                <?php }?>
	            </tr>
	    	<tr>
	    		<th colspan="3">Posted By : <?php echo $note['name']; ?></th>
	    	</tr>
	        <?php } ?>
	    </table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
