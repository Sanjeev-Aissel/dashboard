<?php
/**
 * Controller for handling the calendar operations
 * 
 * @author Ramesh B
 * @since
 * @package application.controllers	
 * @created on 12-05-2011
 */
class Calendars extends Controller {
	
	function Calendars(){
		parent::Controller();
		$this->load->model('calendar');
		$this->load->model('common_helpers');
	}
	
	function view_calendar(){
		$data['contentPage'] 	=	'calendar/view_calendar';
		$this->load->view('layouts/client_view',$data);
	}
	
	/**
	 * Prepares the Add/Edit form for a calender event
	 * @author 	Ramesh B
	 * @since	
	 * @return 
	 * @created 14-05-2011
	 */
	function edit_calendar_event($id=null){
		$data=array();
		if($id!=null){
			$row=$this->calendar->getEvent($id);
			$data['event']=$row;
		}
		
		$this->load->view('calendar/edit_calendar_event',$data);
	}
	/**
	 * Controller method for calling the apropriate methed based on the parameter
	 * @author 	Ramesh B
	 * @since	
	 * @return JSON
	 * @created 14-05-2011
	 */
	function datafeed($methodName,$id=null){
		$arrDetails=explode("=",$methodName);
		$method=$arrDetails[1];
		//echo $method;
		switch ($method) {
		    case "add":
		        $returnData = $this->add_calendar($_POST["CalendarStartTime"], $_POST["CalendarEndTime"], $_POST["CalendarTitle"], $_POST["IsAllDayEvent"]);
		        break;
		    case "list":
		        $returnData = $this->list_calendar($_POST["showdate"], $_POST["viewtype"]);
		        //$returnData	=$this->list_events();
		        break;
		    case "update":
		        $returnData = $this->update_calendar($_POST["calendarId"], $_POST["CalendarStartTime"], $_POST["CalendarEndTime"]);
		        break; 
		    case "remove":
		        $returnData = $this->remove_calendar( $_POST["calendarId"]);
		        break;
		    case "adddetails":
		        $starTime = $_POST["stpartdate"] . " " . $_POST["stparttime"];
		        $endTime = $_POST["etpartdate"] . " " . $_POST["etparttime"];
		        //echo $starTime." ".$endTime;
		       
		        if(isset($id)){
		            $returnData = $this->update_detailed_calendar($id, $starTime, $endTime, 
		                $_POST["Subject"], isset($_POST["IsAllDayEvent"])?1:0, $_POST["Description"], 
		                $_POST["Location"], $_POST["colorvalue"], $_POST["timezone"]);
		        }else{
		            $returnData = $this->add_detailed_calendar($starTime, $endTime,                    
		                $_POST["Subject"], isset($_POST["IsAllDayEvent"])?1:0, $_POST["Description"], 
		                $_POST["Location"], $_POST["colorvalue"], $_POST["timezone"]);
		        }        
		        
		        break; 
		
		
		}
		//$returnData=array();
		echo json_encode($returnData); 
	}
	
	/**
	 * Saves the calendar event with less details
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 14-05-2011
	 */
	function add_calendar($startTime, $endTime, $subject, $isAllDayEvent){
	  $returnData = array();
	  $userId		=$this->session->userdata('user_id');
	  $clientId		=$this->session->userdata('client_id');
	  $arrEventDetails=array();
	  $arrEventDetails['subject']		=$subject;
	  $arrEventDetails['starttime']		=$this->common_helpers->php_to_my_sql_time($this->common_helpers->js_to_php_time($startTime));
	  $arrEventDetails['endtime']		=$this->common_helpers->php_to_my_sql_time($this->common_helpers->js_to_php_time($endTime));
	  $arrEventDetails['isalldayevent']	=$isAllDayEvent;
	  //$arrEventDetails['description']	=$description;
	  //$arrEventDetails['location']		=$location;
	  //$arrEventDetails['color']			=$color;
	  $arrEventDetails['client_id']		=$clientId;
	  $arrEventDetails['created_by']	=$userId;
	  $arrEventDetails['created_on']	=date("Y-m-d H:i:s");
	  $arrEventDetails['event_type']	=EVENT_TYPE_GENERAL;
	  
	  $id=$this->calendar->addEvent($arrEventDetails);
	  if($id==0){
	  	 $returnData['IsSuccess'] = false;
	      $returnData['Msg'] = "Error";
	  }else{
	  	 $returnData['IsSuccess'] = true;
	      $returnData['Msg'] = 'add success';
	      $returnData['Data'] = $id;
	  }
	  return $returnData;
	}
	
	/**
	 * Saves the calendar event with all details
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 14-05-2011
	 */
	function add_detailed_calendar($startTime, $endTime, $subject, $isAllDayEvent, $description, $location, $color, $timezone){
	  $returnData = array();
	  $userId		=$this->session->userdata('user_id');
	  $clientId		=$this->session->userdata('client_id');
	  $arrEventDetails=array();
	  $arrEventDetails['subject']		=$subject;
	  $arrEventDetails['starttime']		=$this->common_helpers->php_to_my_sql_time($this->common_helpers->js_to_php_time($startTime));
	  $arrEventDetails['endtime']		=$this->common_helpers->php_to_my_sql_time($this->common_helpers->js_to_php_time($endTime));
	  $arrEventDetails['isalldayevent']	=$isAllDayEvent;
	  $arrEventDetails['description']	=$description;
	  $arrEventDetails['location']		=$location;
	  $arrEventDetails['color']			=$color;
	  $arrEventDetails['client_id']		=$clientId;
	  $arrEventDetails['created_by']	=$userId;
	  $arrEventDetails['created_on']	=date("Y-m-d H:i:s");
	  
	  $id=$this->calendar->addEvent($arrEventDetails);
	  if($id==0){
	  	 $returnData['IsSuccess'] = false;
	      $returnData['Msg'] = "Error";
	  }else{
	  	 $returnData['IsSuccess'] = true;
	      $returnData['Msg'] = 'add success';
	      $returnData['Data'] = $id;
	  }
	  return $returnData;
	}
	
	/**
	 * Retries all the Calendar events with in the given range of time for given ClientID/UserID
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 14-05-2011
	 */
	function list_calendar_by_range($startDate, $endDate){
	  $returnData = array();
	  $clientId		=$this->session->userdata('client_id');
	  $userId=0;		
	  if($this->session->userdata('user_role_id')==ROLE_USER)
		$userId		=$this->session->userdata('user_id');
	  $returnData['events'] = array();
	  $returnData["issort"] =true;
	  $returnData["start"] = $this->common_helpers->php_to_js_time($startDate);
	  $returnData["end"] = $this->common_helpers->php_to_js_time($endDate);
	  $returnData['error'] = null;
	  
	  $startTime=$this->common_helpers->php_to_my_sql_time($startDate);
	  $endTime=$this->common_helpers->php_to_my_sql_time($endDate);
	  $arrEvents=$this->calendar->getAllEvents($startTime,$endTime,$clientId,$userId);
	  foreach($arrEvents as $row){
	  	 $returnData['events'][] = array(
	        $row->Id,
	        $row->Subject,
	        $this->common_helpers->php_to_js_time($this->common_helpers->my_sql_to_php_time($row->StartTime)),
	        $this->common_helpers->php_to_js_time($this->common_helpers->my_sql_to_php_time($row->EndTime)),
	        $row->IsAllDayEvent,
	        0, //more than one day event
	        //$row->InstanceType,
	        0,//Recurring event,
	        $row->Color,
	        1,//editable
	        $row->Location, 
	        $row->event_type,
	        ''//$attends
	      );
	  }
	  return $returnData;
	}
	
	/**
	 * Retrives all the Calendar events with in the given range of time 
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 14-05-2011
	 */
	function list_calendar($day, $type){
	  $phpTime = $this->common_helpers->js_to_php_time($day);
	  //echo $phpTime . "+" . $type;
	  switch($type){
	    case "month":
	      $startTime = mktime(0, 0, 0, date("m", $phpTime), 1, date("Y", $phpTime));
	      $endTime = mktime(0, 0, -1, date("m", $phpTime)+1, 1, date("Y", $phpTime));
	      break;
	    case "week":
	      //suppose first day of a week is monday 
	      $monday  =  date("d", $phpTime) - date('N', $phpTime) + 1;
	      //echo date('N', $phpTime);
	      $startTime = mktime(0,0,0,date("m", $phpTime), $monday, date("Y", $phpTime));
	      $endTime = mktime(0,0,-1,date("m", $phpTime), $monday+7, date("Y", $phpTime));
	      break;
	    case "day":
	      $startTime = mktime(0, 0, 0, date("m", $phpTime), date("d", $phpTime), date("Y", $phpTime));
	      $endTime = mktime(0, 0, -1, date("m", $phpTime), date("d", $phpTime)+1, date("Y", $phpTime));
	      break;
	  }
	  //echo $startTime . "--" . $endTime;
	  return $this->list_calendar_by_range($startTime, $endTime);
	}
	
	/**
	 * Updates the given calendar event
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 14-05-2011
	 */
	function update_calendar($id, $startTime, $endTime){
	 $returnData = array();
	   $userId		=$this->session->userdata('user_id');
	  $clientId		=$this->session->userdata('client_id');
	  $arrEventDetails=array();
	  $arrEventDetails['id']			=$id;
	  $arrEventDetails['starttime']		=$this->common_helpers->php_to_my_sql_time($this->common_helpers->js_to_php_time($startTime));
	  $arrEventDetails['endtime']		=$this->common_helpers->php_to_my_sql_time($this->common_helpers->js_to_php_time($endTime));
	  $arrEventDetails['client_id']		=$clientId;
	  $arrEventDetails['created_by']	=$userId;
	  $arrEventDetails['created_on']	=date("Y-m-d H:i:s");
	  
	  $udated=$this->calendar->updateEvent($arrEventDetails);
	  if(!$udated){
	  		$returnData['IsSuccess'] = false;
	      $returnData['Msg'] = "Error";
	  }else {
	  	 $returnData['IsSuccess'] = true;
	      $returnData['Msg'] = 'Updated successfully';
	  }
	  return $returnData;
	}
	
	/**
	 * Updates the Calendar event matching the givent calendar event Id with the given details
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 14-05-2011
	 */
	function update_detailed_calendar($id, $startTime, $endTime, $subject, $isAllDayEvent, $description, $location, $color, $timezone){
	  $returnData = array();
	   $userId		=$this->session->userdata('user_id');
	  $clientId		=$this->session->userdata('client_id');
	  $arrEventDetails=array();
	  $arrEventDetails['id']			=$id;
	  $arrEventDetails['subject']		=$subject;
	  $arrEventDetails['starttime']		=$this->common_helpers->php_to_my_sql_time($this->common_helpers->js_to_php_time($startTime));
	  $arrEventDetails['endtime']		=$this->common_helpers->php_to_my_sql_time($this->common_helpers->js_to_php_time($endTime));
	  $arrEventDetails['isalldayevent']	=$isAllDayEvent;
	  $arrEventDetails['description']	=$description;
	  $arrEventDetails['location']		=$location;
	  $arrEventDetails['color']			=$color;
	  $arrEventDetails['client_id']		=$clientId;
	  $arrEventDetails['created_by']	=$userId;
	  $arrEventDetails['created_on']	=date("Y-m-d H:i:s");
	  
	  $udated=$this->calendar->updateEvent($arrEventDetails);
	  if(!$udated){
	  		$returnData['IsSuccess'] = false;
	      $returnData['Msg'] = "Error";
	  }else {
	  	 $returnData['IsSuccess'] = true;
	      $returnData['Msg'] = 'Updated successfully';
	  }
	  return $returnData;
	}
	
	/**
	 * Deletes the Calendar event matching the givent calendar event Id
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 16-02-11
	 */
	function remove_calendar($id){
	  $returnData = array();
	  $deleted=$this->calendar->deleteEvent($id);
	 if(!$deleted){
	  		$returnData['IsSuccess'] = false;
	      $returnData['Msg'] = "Error";
	  }else {
	  	 $returnData['IsSuccess'] = true;
	      $returnData['Msg'] = 'Updated successfully';
	  }
	  return $returnData;
	}
}