<link  href="<?php echo base_url().MODULES_ASSETS;?>configurations/css/configurations.css" rel="stylesheet">
<?php echo $html_form;?>
<div id="msgBox">
</div>
<script>
$(document).ready(function() {
		$("#saveKolStateLicenseForm").validate({
			rules: {
				state_license_number: "required",
				country_id: "required",
				state_id: "required"
			},
			messages: {
				state_license_number: {
					required: "This field is required.",
				},
				country_id: {
					required: "This field is required.",
				},
				state_id: {
					required: "This field is required.",
				}
			}
		});		
});
</script>