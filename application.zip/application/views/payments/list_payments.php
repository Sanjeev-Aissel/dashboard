<?php
/**
 * File to 'List' Payment details
 *
 * @author: Ambarish
 * @Created on: 28-02-11
 */
?>
<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array('payments/list_payments',
							'i18n/grid.locale-en',
							'jquery.jqGrid.min',
							'jquery/jquery.validate1.9.min',
							'jquery/jquery-ui-1.8.16.slider',
							'jquery/jquery-ui-1.8.16.datepicket',
							'chosen.jquery',
							'CalendarControl'
							);
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<?php 
if(!isset($kolId)){
$kolId	= $this->uri->segment(4);
}
$payment_id	= $this->uri->segment(5);
?>
<script type="text/javascript">
	var baseUrl = '<?php echo base_url(); ?>';
	var subContentPage	= '<?php echo $subContentPage;?>';
	var date = "<?php echo lang("Overview.Date");?>";
	var action = "<?php echo lang("Overview.Action");?>";
	var paymentsTitle = "<?php echo lang("Overview.Payments");?>";
	var requestedBy = "<?php echo lang("Overview.requestedBy");?>";
	var paidBy = "<?php echo lang("Overview.paidBy");?>";
	var amount = "<?php echo lang("Overview.amount");?>";
	jqgridIds	= new Array('listPaymentsResultSet');
	var completd = '<?php echo COMPLETED ;?>';
	var prenew = '<?php echo PRENEW;?>';
	var approved= '<?php echo APPROVED;?>';
	var New1 = '<?php echo New1;?>';
	var kolId = "<?php echo $kolId;?>";
	var paymentId = "<?php echo $payment_id;?>";
</script>
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
<!-- Month Year Selection Calendar plugin -->
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/StyleCalender.css" />
	<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet" />
<style type="text/css">
	/*    Enable Verticle separator between content and side menu list  By Laxman   */
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
	.ui-tabs-vertical .ui-tabs-nav {
		margin-left: 2px;
	}	
	.listResultSet a{
		text-decoration:none;
		text-align:left;
		float:left;
	}
	tr.selectedRow {
    	background-color: #D8DFEA !important;
	}
	.addLink {
		width:auto;
		float: right;
	}
	.toggleBtnWrapper{
		width: auto;
		margin-top: 1px;
	}
	#listPaymentsContainer{
	/*	width: 810px;*/
		margin-top: 0px;
		float: right;
	}
	#timeLineSliderContainer p {
		margin-top: -20px;
		margin-top: 0px;
	}
	#addThreshhold{
		border: 0px;
		margin-top: 10px;
	}
	.ui-datepicker-calendar {
    	display: none;
	}
	#timeLineSliderContainer p input[type="text"]{
		margin: 1px 0px 0px 0px;
	}
	#timeLineSliderContainer{
		margin-bottom: 0px;
	}
	.buttonsWarpper{
		float: right;
		width: 255px;
	}
	.s-ico{
		display: inline !important;
	}
	#jqgh_listPaymentsResultSet_micro .s-ico, #jqgh_listPaymentsResultSet_act .s-ico{
		display: none !important;
	}
</style>

<!--[if IE]>
<style type="text/css">
	.toggleBtnWrapper{
		margin-top: 3px;
	}
</style>
<![endif]-->
	
	<?php //if($this->session->userdata('kolId')== '-1'){?>
		
		<div id="paymentsTernaryNav" class="span-20 last">
			<!--<ul class="span-3 append-1 ternaryNav" >
				<li><a href="#listPaymentsContainer">Payments</a></li>
				<li><a href="#addThreshhold" onclick="addThreshhold();">Add Threshold</a></li>
				 <li><a href="#reportPayments">Reports</a></li> 
			</ul>
			-->
			<?php 
				switch($subContentPage){
						case 'add_threshold':
			?>
								<div id="addThreshhold">
									<div class="threshholdprofileContent"></div>	
								</div>
			<?php 
							break;
						case 'add_payment':
			?>
						<!-- Start of 'Add Payment' Form -->
							<div id="addPayment">
								<div id="addPaymentContainer">
						
								</div>
							</div>
						<!-- End of 'Add Payment' Form -->
			<?php 
							break;
						case 'edit_payment':
			?>
													<!-- Start of 'Add Payment' Form -->
														<div id="editPayment">
															<div id="editPaymentContainer">
													
															</div>
														</div>
													<!-- End of 'Add Payment' Form -->
			<?php 
							break;
						default:	
			?>
								<div id="timeLineSliderContainer" class="timeLineSliderContainer ui-widget-content">
									<div class="exportOptionsContainer">
										<ul class="pageRightOptions">
											<li>
												<label for=monthlyreport>Month From :</label>
												<input type="text" name="monthlyreport" id="monthlyreport" value="Click to select" placeholder="Click to select" onfocus="showCalendarControl(this.id);" />
												<label for=monthlyreport>To:</label>
												<input type="text" name="monthto" id="monthto" value="Click to select" placeholder="Click to select" onfocus="showCalendarControl(this.id);" />
												<input type="button" value="Apply Filter" id="filterbutton" onclick="paymentReport()" />
											</li>
											<?php if($kolId==''){ ?>
											<li><input type="button" onClick="toggleKolGrouping('listPaymentsResultSet', 'toggleKolGrouping');" value="Remove Grouping" name="toggleKolGrouping" id="toggleKolGrouping" /></li>
											<?php } ?>
											<?php 
                                                $arrKol = array();
                                                if($kolId!=''){
                                                    $arrKol["kol_id"]=$kolId;            
                                                }?>
											<?php if($this->common_helpers->isActionAllowed('payment','add',$arrKol)){ ?>
											<li><a href="<?php echo base_url(); ?>payments/list_payments/add_payment<?php echo isset($kolId)?'/'.$kolId:''; ?>" class="link NewBlueButton NewAddIcon">Add Payment</a></li>
											<?php } ?>
											<li>
												<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="export_excel();">
													<a href="#" rel="tooltip" data-original-title="Export Payment Details into Excel format">&nbsp;</a>
												</div>
											</li>
										</ul>
									</div>
								</div>
								<div id="listPaymentsContainer">
									<!--<div class="toggleBtnWrapper">
										<input type="button" onClick="toggleKolGrouping('listPaymentsResultSet', 'toggleKolGrouping');" value="Remove Grouping" name="toggleKolGrouping" id="toggleKolGrouping" />
										<div class="addLink">
											<label onclick="addPayment();"><div class="actionIcon addIcon" style="margin-top:0px;"></div>Add New Payment</label>
										</div>
									</div>
									
									--><div id="listPayments">
									<form action="<?php echo base_url()?>payments/export_payment_details" method='post' id="export">
										<input type="hidden" name="payment_ids" value="" id='ids'></input>
										<input type="hidden" name="filters"  id="excel-filters"/>
									</form>
										<div class="gridWrapper" id="gridContainer">
											<div id="listPaymentsPage"></div>
											<table id="listPaymentsResultSet"></table>
										</div>
									</div>
									
									<!-- Container for the 'Add Payments' modal box -->
									<div id="dailog2">	
										<div id="paymentAddContainer" class="microProfileDialogBox">
											<div class="profileContent" id="paymentAddProfileContent"></div>
										</div>
									</div>
									<!--End of  Container for the 'Add Payments' modal box -->
									<!-- Container for the 'Edit Payments' modal box -->
									<div id="dailog3">	
										<div id="paymentEditContainer" class="microProfileDialogBox">
											<div class="profileContent" id="paymentEditProfileContent"></div>
										</div>
									</div>
									<!--End of  Container for the 'Edit Payments' modal box -->
									
									<!-- Container for the View Payments' modal box -->
									<div id="dailog3">	
										<div id="paymentViewContainer" class="microProfileDialogBox">
											<div class="profileContent" id="paymentViewProfileContent"></div>
										</div>
									</div>
									<!--End of  Container for the View  Payments' modal box -->
								</div>
			<?php 			
						break;
				}
			?>
			
			<div id="reportPayments">
					
			</div>
		
		</div>
	<?php // }?>


