<?php
/*
 * View survey reports
 *  
 * @Author		: Laxman K
 * @since 		: KOLM v5.5 Otsuka 1.0.11
 * Created on	: 03-04-2013
 *  
 */

	// prepare array of JS files to insert into queue
	$queued_js_scripts =array(	'surveys/view_report',
								'chosen.jquery',
								'highcharts2_2_2/highcharts3.0.5',
								'highcharts2_2_2/modules/exporting3.0.5',
								'i18n/grid.locale-en',
								'jquery.jqGrid.min',
								'maps/map',
								'jquery/jquery.validate1.9.min'
							);
	// add the JS files into queue i.e Append to the existing queue
	$prevjs = $this->config->item('js_files_to_load');
	if($prevjs == null)
		$prevjs = array();
	$this->config->set_item('js_files_to_load',array_merge($prevjs,$queued_js_scripts));
?>

<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet">
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
<style type="text/css">
	#imageContenet{
	float:left;
}
	#mapsContent{
		float: left;
	}
	#addrssInfo{
		text-align: left;
		color:#000000;
		font-family:arial,helvetica,sans-serif;
		font-size:13px;
	}
	#kolImage{
		vertical-align: bottom;
	}
	
	#surveyMap{
		position:relative; 
		width:805px; 
		height:450px;
	}
	.Infobox{
		width:356px !important;	
	}
	
	
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
/*	#surveyReports{
		width: 805px;
		margin-top: -75px;
		margin-top: 0px;
		float: right;
		position: relative;
	}
*/
	select.chosenSelect, select.chosenMultipleSelect{
		width:200px;
	}
	.preQuery select.chosenSelect{
		width:150px;
	}
	.chzn-container{
		font-size: 12px;
		margin-bottom: 3px;
	}
	#chartOptions th{
		text-align: right;
	}
	#counts caption{
		font-weight: bold;
	}
	#counts th{
		width: 150px;
		text-align: left;
	}
	#subChartContainer1{
		float: left;
	}
	#subChartContainer2{
		float: right;
	}
	#subChartContainer1, #subChartContainer2{
		width: 395px;
	}
	#customQueryForm th,#customQueryForm td{
		vertical-align: top;
	}
	#customQueryForm label{
	    display: block;
	    float: left;
	    height: 25px;
	    line-height: 25px;
	    padding-right: 5px;
	    text-align: right;
	    vertical-align: middle;
	    width: 80px;
	}
	th .tableHeader{
		text-align: center;
		background-color: #eee;
		padding: 5px 0;
	}
	.preQuery label{
		display: inline-block;
	    font-weight: normal;
/*	    line-height: 30px;
	    vertical-align: super;
*/	    font-size: 14px;
	}
	#preDefinedQuery tr:nth-child(even) td{
		border-bottom: 1px solid #ddd;
	}
/*	#preDefinedQuery tr:nth-child(even){
		background-color: #eee;
	}
	#preDefinedQuery tr:nth-child(odd){
		background-color: #fff;
	}
*/
	#preDefinedQuery button{
		height: 25px;
   		vertical-align: top;
   		margin-bottom: 0px;
   		top:0px;
	}
	#preDefinedQuery div{
		vertical-align: middle;
	}
	fieldset{
		border-color: #ddd;
		padding-bottom: 0;
	}
	fieldset legend{
		color: #999;
	}
	fieldset legend span.minimize{
		background-position: -3px -85px !important;
	}
	fieldset legend span.minmaxSection{
		background: url("<?php echo base_url();?>images/kolm-sprite-image.png") no-repeat scroll -23px -85px transparent;
		display: inline-block;
	    height: 17px;
	    width: 20px;
	}
	abbr, acronym{
		border-bottom: none;
	}
	#surveyReports .kolRequestIcon{
		background-position: -181px 120px;
		margin-left: 0px;
	}
	#surveyReports .orgRequestIcon {
    	background-position: -354px 119px;
    	margin-left: 0px;
    }
	.gridWrapper .ui-jqgrid tr.jqgrow td div.microViewIcon{
		height: 19px !important;
	}
	blockquote {
		border: 1px solid #ddd;
		border-right: 0px;
		border-left: 0px;
	}
	.chzn-container .chzn-results li{
		text-align: left;
	}
	#queryContainer{
		display: none;
	}
	#chartOptions{
		border-bottom: 1px solid #999;
	}
	#chartOptions table{
		margin-bottom: 0px;
	}
	
	#indivisual-influence{
		height:450px;
		width:600px;
	}
/*	#listSurveysResultSet .jqgrow td:nth-child(4){
		cursor:pointer;
		color:#000099;
	}*/
	.orgProfileRequest, .orgProfile{
		margin-left: 0px;
	}
	
	
	.MapPushpinBase img{

	 margin-top: 31px;
	 margin-left: 8px;
	}
	
	.kolInfo{
		min-height:46px;
		margin-top:-6px;
	}
	
	.Infobox{
		height: 82px !important;
	    top: 59px !important;
	    width: 239px !important;
	}
	.infobox-stalk{
		height:30px !important;
		top: 82px !important;
	}
	
	#imageContenet{
	float:left;
	margin-right: 4px;
	margin-top:3px;
	}
	
	#addrssInfo{
		text-align: left;
		color:#000000;
		font-family:arial,helvetica,sans-serif;
		font-size:11px;
		
	}
	#tooltip-survey-select{
		/*left: 290px;
    	position: absolute;
    	top: 9px;*/
    	display: inline-block;
	    position: relative;
	    vertical-align: super;
	}
	#tooltip-report-type{
		/*position: absolute;
    	right: 77px;
    	top: 9px;*/
    	display: inline-block;
	    position: relative;
	    vertical-align: super;
	}
	#tooltip-apply-filters{
		position: absolute;
    	right: 33px;
    	top: 78px;
	}
	#tooltip-recent-query {
	    display: inline-block;
	    left: 1px;
	    position: relative;
	    top: 5px;
	}
/*	#tooltip-influence-map{
		left: 245px;
	    position: absolute;
	    top: 48px;
	}
	#tooltip-geo-map{
		left: 322px;
	    position: absolute;
	    top: 48px;
	}*/
	
	.NavBar_modeSelectorControlContainer{
		display: none;
	}
	.NavBar_compassControlContainer{
		display: none;
	}
	.NavBar_zoomControlContainer .NavBar_zoomDrop{
		display: none;
	}
	.NavBar_zoomControlContainer{
		background: none repeat scroll 0 0 #FAF7F5;
	    height: 30px;
	    left: 5px;
	    position: absolute;
	    top: 351px;
	    transform: rotate(270deg);
	    width: 52px;
	}
	.MicrosoftMap .OverlaysBR-logoAware{
		display: none;
	}
	#surveyMap{
		border: 1px solid #000080;
	   
	   
	}
	.disableNavigation{
		opacity: 0.30;
		-ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=30)"; /* IE 8 */
		filter: alpha(opacity=30); /* older IEs */
		margin: 2px 3px 2px 2px;
	}
	.NavBar_zoomControlContainer .NavBar_zoomIn{
		-webkit-transform: rotate(90deg); 
		-moz-transform: rotate(90deg); 
		-o-transform: rotate(90deg);
		-ms-transform: rotate(90deg); 
	}
	.NavBar_zoomControlContainer .NavBar_zoomOut{
		-webkit-transform: rotate(90deg); 
		-moz-transform: rotate(90deg); 
		-o-transform: rotate(90deg);
		-ms-transform: rotate(90deg);
	}
</style>
<script type="text/javascript">
	jqgridIds	= new Array('listSurveysResultSet');
<?php 
		 $mobile = mobile_device_detect();

		 if(isset($mobile[1])){
		 //pr($mobile);
		 	?>
		  var agent ='<?php echo $mobile[1]?>';
		 	
		 <?php }else{?>
		 var agent ='';
		 <?php }?>

var filterType = 'pre';
var userRoleId	= <?php echo $this->session->userdata('user_role_id');?>;
$(document).ready(function(){
	function loadOptions(){
		var surveyId	= $('#survey').val();
		var chartType	= $('#chartType').val();
		$('#customQuery').hide();
		$('#chartHeader').html('');
		$('#chartContainer').html('<div id="subChartContainer1"></div><div id="subChartContainer2"></div>');
		$('#chartFooter').html('<div class="gridWrapper" id="gridContainer"></div>');
		$('#chartFooter').show();
		$('#surveyNetworkMap').hide('slow');
		$('#surveyGeoMap').hide('slow');
		if(surveyId!=0){
			if(chartType==1){
				$('#chartFooter').hide();
				$('#chartFooter').prepend('<input type="button" onclick="backtocharts();" value="Back to charts" />');
			}
			if(chartType!=5){
				load_selected_chart(surveyId,chartType);
			}else{
				load_custom_query_options(surveyId);
			}
		}
	}
	$("#survey_chzn").live('click',function(){
		moveFromCurrentStep(4);
	});
	$("#chartType_chzn").live('click',function(){
		hideHint(5);
	});
	$("#survey").chosen().change(function() {
		loadOptions();
	});
	$("#chartType").chosen().change(function() {
		loadOptions();
	//	moveFromCurrentStep(5);
	});
	$('.chosenSelect').chosen({allow_single_deselect: true});
	$('.chosenMultipleSelect').chosen({
		allow_single_deselect: true
	});
	$("#customQueryForm").submit(function (event){
		var surveyId	= $('#survey').val();
		var data	= $("#customQueryForm").serialize();
		data		+= '&survey_id='+surveyId;
		$.ajax({
			type: "post",
			dataType:"json",
			data: data,
			url: base_url+'surveys/load_query_result',
			success: function(returnData){
				listSurveyReport(returnData,false);
				filterType = 'custom';
			},
			complete: function(){
				saveQuery(0);
			}
		});
		return false;
	});
	$('span.minmaxSection').click(function (){
		$('span.minmaxSection').parent().next().slideToggle('slow');
		$('span.minmaxSection').toggleClass('minimize');
	});

//	$("#listSurveysResultSet .jqgrow td::nth-child(4)").live('click',function(){
//		var id = $(this).parent().attr("id");
//		showIndivisualSurveyMap(id);
//	});
});
</script>
<?php 
	$helpLink = "<a class='help-link' href='".getSSOUrl($this->session->userdata('user_full_name'), $this->session->userdata('email'))."&redirect_to=/support/solutions/articles/129926-generating-custom-reports-on-top' target='_new'>View Additional Help</a>";
	$helpLinkReportType = "<a class='help-link' href='".getSSOUrl($this->session->userdata('user_full_name'), $this->session->userdata('email'))."&redirect_to=/support/solutions/articles/129925-finding-the-top-influencers-' target='_new'>View Additional Help</a>";
?>
<div id="container">
<div id="surveyReports">
	<div id="chartOptions">
		<table>
			<tr>
				<th>Survey:</th>
				<td>
					<select id="survey" name="survey" class="chosenSelect">
						<option value="0">Select Survey</option>
						<?php foreach($arrCompletedSurveys as $key=>$arrRow){
							echo '<option value="'.$arrRow['id'].'">'.$arrRow['name'].'</option>';
						}?>
					</select>
					<span id="tooltip-survey-select" class="map-info tooltop-bottom">
						<a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Select the Survey name from the drop down options to generate the report.</span>">&nbsp;</a>
					</span>
				</td>
				<th><span id="reportTypeForHint">Report Type:</span></th>
				<td>
					<select id="chartType" name="chart_type" class="chosenSelect">
						<option value="1">Summary</option>
						<option value="2">Top Influencers</option>
						<!--<option value="3">User Nominees</option>
						<option value="4">User Respondents</option>
						-->
						<option value="5">Custom Report</option>
					</select>
					<span id="tooltip-report-type" class="map-info tooltop-bottom">
						<a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>
						<strong>Summary:</strong> A summary of the over all survey – influencers, users and respondents.<br>
						<strong>Top Influencers:</strong> Chart type report of the top influencers with filters of TA & State.<br>
						<strong>Custom:</strong> Generate tabular report based on your needs.
						<?php echo $helpLinkReportType;?></span>">&nbsp;</a>
					</span>
				</td>
			</tr>
		</table>
	</div> 
		<div id="chartWrapper">
			<div id="customQuery" style="display:none;">
			<fieldset>
				<legend>
					<span class="minmaxSection minimize"></span>Recent Query
					<span id="tooltip-recent-query" class="map-info tooltop-bottom">
						<a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Recent Query is the last report you generated. Select the options for Influencer Type, TA & State to generate the report. You can view Influence Map or Geo Map once you generate a report.
						Click on the Report Builder for more options and filters.<?php echo $helpLink;?></span>">&nbsp;</a>
					</span>
				</legend>
				<div id="preDefinedQuery">
					<table>
						<tr>
							<td>
								<div class="preQuery">
								<form action="#" onsubmit="return false;">
									<div>
									<label>Top </label>
									<select id="PDQnomineeType" name="nominee_type" class="chosenSelect nominee_type" data-placeholder="Select Type">
										<option value=""></option>
										<?php 
											foreach($arrTypes as $id=>$name){
												echo '<option value="'.$id.'">'.$name.'</option>';
											}
										?>
									</select>
									<label>Influencers of  </label>
									<select id="PDQnomineeSpecialty" name="nominee_specialty" class="chosenSelect nominee_specialty" data-placeholder="Select Therapeutic Area">
										<option value=""></option>
									</select>
									<label>in the state of </label>
									<select id="PDQnomineeState" name="nominee_state[]" class="chosenSelect nominee_state" data-placeholder="Select State">
										<option value=""></option>
									</select>
									<input type="button" value="Go" onclick="predefinedquery(this);" />
									<!-- button onclick="predefinedquery(this);">Go</button-->
									</div>
								</form>
								</div>
							</td>
						</tr>
					</table>
				</div>
			</fieldset>
			<fieldset>
				<legend><span class="minmaxSection"></span>Report Builder</legend>
				<div id="customQueryWrapper" style="display:none;">
					<form id="customQueryForm" action="#" method="post">
						<table>
							<tr>
								<th><div class="tableHeader">Refine by Influencer</div></th>
								<th style="vertical-align: middle;">AND</th>
								<th><div class="tableHeader">Refine by Respondent</div></th>
							</tr>
							<tr>
								<td>
									<div>
										<label>Name:</label>
										<select id="nomineeName" name="nominee_Name" class="chosenSelect" data-placeholder="Select Influencer">
											<option value=""></option>
										</select>
									</div>
									<div>
										<label>Specialty:</label>
										<select id="nomineeSpecialty" name="nominee_specialty" class="chosenSelect nominee_specialty" data-placeholder="Select Therapeutic Area">
											<option value=""></option>
										</select>
									</div>
									<div>
										<label>Type:</label>
										<select id="nomineeType" name="nominee_type" class="chosenSelect nominee_type" data-placeholder="Select Type">
											<option value=""></option>
											<?php 
												foreach($arrTypes as $id=>$name){
													echo '<option value="'.$id.'">'.$name.'</option>';
												}
											?>
										</select>
									</div>
									<div>
										<label>Country:</label>
										<select id="nomineeCountry" name="nominee_country" class="chosenSelect" data-placeholder="Select Country">
											<option value=""></option>
										</select>
									</div>
									<div>
										<label>State:</label>
										<select id="nomineeState" multiple="multiple" name="nominee_state[]" class="chosenMultipleSelect nominee_state" data-placeholder="Select State(s)">
											<option value=""></option>
										</select>
									</div>
									<div>
										<label>City:</label>
										<select id="nomineeCity" multiple="multiple" name="nominee_city[]" class="chosenMultipleSelect" data-placeholder="Select Cities">
											<option value=""></option>
										</select>
									</div>
									<div>
										<label>Postal Code:</label>
										<select id="nomineePostal" multiple="multiple" name="nominee_postal[]" class="chosenMultipleSelect" data-placeholder="Select Postal Code(s)">
											<option value=""></option>
										</select>
									</div>
								</td>
								<td></td>
								<td>
									<div>
										<label>Name:</label>
										<select id="respondentId" name="respondent_id" class="chosenSelect" data-placeholder="Select Respondent">
											<option value=""></option>
										</select>
									</div>
									<div>
										<label>State:</label>
										<select id="respondentState" multiple="multiple" name="respondent_state[]" class="chosenMultipleSelect" data-placeholder="Select State(s)">
											<option value=""></option>
										</select>
									</div>
									<div>
										<label>City:</label>
										<select id="respondentCity" multiple="multiple" name="respondent_city[]" class="chosenMultipleSelect" data-placeholder="Select Cities">
											<option value=""></option>
										</select>
									</div>
									<div>
										<label>Postal Code:</label>
										<select id="respondentPostal" multiple="multiple" name="respondent_postal[]" class="chosenMultipleSelect" data-placeholder="Select Postal Code(s)">
											<option value=""></option>
										</select>
									</div>
								</td>
							</tr>
							<tr>
								<td colspan="3"><center><input type="button" onclick="clearSelection();" value="Clear Selections" /> &nbsp; <input type="submit" value="Create Report" /></center></td>
							</tr>
						</table>
					</form>
				</div>
			</fieldset>
		</div>
		<div id="chartHeader"></div>
		<div id="chartContainer">
			<div id="subChartContainer1"></div>
			<div id="subChartContainer2"></div>
			    <div class="gridWrapper" id="allAfiliationGridContainer">
				<div id="listSurveysPage1"></div><table id="JQBlistAllResultSet"></table>
			</div>
		</div>
		<div id="chartFooter">
			<div class="gridWrapper" id="gridContainer">
			</div>
		</div>
		<div id="surveyNetworkMap" style="display: none;">
			<div id="queryOptContainer"></div>
			<?php $this->load->view('surveys/network_map_element');?>
		</div>
		
		<div id="surveyGeoMap" style="display: none;">
		<div id="queryOptContainer1"></div>
			<div id="surveyMapsContent" class="span-20 last" >			
				<div id='surveyMap' style=""></div>
			</div>
			
		</div>
	</div>
	<!--<div id="refinedByWrapper" class="rightRefinedByFilter">
		<div id="refinedByContainer">
			<div id="rightSideBarSlider" class="tooltip-demo tooltop-left expandRightSideBar"><a href="#" class="tooltipLink" rel='tooltip' title="Show Refine By">&nbsp;</a></div>
			<div id="searchLeftBar" style="display: none;">
				<div id="resetBttnContainer"><label class="tooltip-demo tooltop-left" id="resetBttn" onclick="resetFilters();"><a href="#" class="tooltipLink" rel='tooltip' title="Reset Filters">&nbsp;</a></label>Reset</div>
				<h3><div class="funnelIcon sprite_iconSet"></div>Refine By</h3>
				<div id="searchFiltersContainer">
					<?php //echo $refinedByFilterContent;?>
				</div>
			</div>
		</div>
	</div>
	-->
</div>
<div id="dailog2">
	<!-- Container for the 'Micro Profile'  box -->
	<div id="contentHolder" class="callOutTest microView" style="display: none;">
		<div>
			<a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeKolProfile();" class="ui-icon ui-icon-closethick">close</span></a>
		</div>
		<div class="profileContent"></div>
	</div>
	<div id="arraouHolder" class="callOutTest" style="display: none;"><div class="arrowMarkIcon"></div></div>
</div>
<div id="addNewKol" class="microProfileDialogBox">
	<div class="addNewKolContent profileContent"></div>
</div>
<div id="addNewOrg" class="microProfileDialogBox">
	<div class="addNewOrgProfileContent profileContent"></div>
</div>
<div id="queryContainer">
	<table id="viewReportOptions" style="margin-bottom: 0px;">
		<tr>
			<td><input type="button" value="Back to Report Builder" onclick="backBuilder();" /><!-- button onclick="backBuilder();">Back to Report Builder</button-->
			<!--</td>
			<td><input class="queryName" type="text" name="queryname" value="autosaved query" style="margin: 0px;width: 380px;" placeholder="Enter Query Name" />&nbsp;<button>Save Query</button></td>
			<td>-->
			<input type="button" onclick="getSurveyInfluenceData();" style="margin-right: 21px;" value="Influence Map" />
			<span id="tooltip-influence-map" class="map-info tooltop-bottom helpToolTip">
				<a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Click to view Influence Map
				Each dot is an individual. Click on any name to highlight connections & click again to unselect.<br>
				<b>Respondent</b> – individuals who have nominated others; indicated by arrows pointing towards them.<br>
				<b>Influencer</b> – Individuals who have been nominated by others; indicated by arrows pointing away.<br>
				E.g. A ----------- >B  = A influences B<br><br>
				
				<b>Red dot</b> = no profile present, new name<br>
				<b>Blue dot</b> = profile present, existing KOL
				.<?php echo $helpLink;?></span>">&nbsp;</a>
			</span>
			<!--</td><td>
			-->
			<input type="button" onclick="getSurveyGeoData();" value="Geo Map" id="mapButton"/>
			<span id="tooltip-geo-map" class="map-info tooltop-bottom helpToolTip">
				<a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Click to view Geo Map
				Each dot is an individual. Click on any name to highlight connections & click again to unselect.
				<b>Respondent</b> – individuals who have nominated others; indicated by arrows pointing towards them.<br>
				<b>Influencer</b> – Individuals who have been nominated by others; indicated by arrows pointing away.<br>
				E.g. A ----------- >B  = A influences B.<?php echo $helpLink;?></span>">&nbsp;</a>
			</span>
			</td>
		</tr>
	</table>
</div>
</div>