<?php
/**
 * This is Controller file of 'Organizations'
 * 
 * @author Ambarish
 * @since
 * @package application.controllers	
 * @created on  17-01-11
 */

class Organizations extends Controller{
	
	//Constructor
	function Organizations(){
		parent::Controller();
		$this->load->model('organization');
		$this->load->model("Country_helper");
		$this->load->library("Ajax_pagination");
		$this->load->model('common_helpers');
		$this->load->model('Client_User');
		$this->load->model('pubmed_org');
		$this->load->model('pubmed');
		$this->load->model('clinical_trial');
		$this->load->model('payment');
		$this->load->model('kol');
		$this->load->model('clinical_trial_org');
		$this->load->model('align_user');
		//Check for log in
		$this->loggedUserId = $this->session->userdata('user_id');
	}
	
	/**
	 * Checks if the user has logged in or not 
	 *@access private
	 */
	private function _is_logged_in(){
		if(!$this->session->userdata('logged_in')) {
			redirect(base_url()."/login");
		}else{
			$this->loggedUserId = $this->session->userdata('user_id');
		}
	}

	/**
	 * Shows the page of Add Organizations details
	 * 
	 */
 	function add_organization(){
		//Analyst App to be accessed by only Aissel users. 
		$this->common_helpers->checkUsers();
		 		
 		$reportSection=$this->uri->segment(3);
 		// Remove any OrganizationId from Session, if set
 		$this->session->unset_userdata("organizationId");
 		
 		$organizationDetails = array(	'id' 				=>  '',
 										'name' 				=>  '',	
										'type_id'			=>  '',
 										'company_logo'		=> 	'',
										'website'			=>  '',
										'founded'			=> 	'',
										'background'		=>	'',
										'products_services'	=> 	'',
										'mission_vision' 	=> 	'',
										'headquarters'	 	=>  '',
										'address'	 		=> 	'',
				                        'phone'	 			=> 	'',
			 							'fax'	 			=> 	'',
										'country_id'	 	=> 	'',
										'state_id' 			=> 	'',
										'city_id'	 		=> 	'',
			                            'postal_code'	 	=> 	'',
			                            'blog'	 			=> 	'',
			                            'facebook'	 		=> 	'',
			                            'twitter'	 		=> 	'',
			                            'youtube'	 		=> 	'',
			                            'linkedin'	 		=> 	'',
										'created_by'		=>	'',
										'created_on'		=>	'');
 		
 		$data['arrOrganization']	= $organizationDetails;
 					
 		$arrKeyPeopleRoles = $this->organization->getAllKeyPeopleRoles();
		$data['arrKeyPeopleRoles']	= $arrKeyPeopleRoles;
		
		$arrOrganizationTypes = $this->organization->getAllOrganizationTypes();
		$data['arrOrganizationTypes']	= $arrOrganizationTypes;
		
		$data['arrCountry']=$this->Country_helper->listCountries();
		
		$arrSalutations	= array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		$data['reportSection']=$reportSection;
		$data['contentPage'] 	=	'organizations/add_organization';
		//pr($data['arrOrganizationTypes']);
		$this->load->view('layouts/analyst_view',$data);
		
	}	
	
	/**
	 * Saves the Organization Detail to DB 
	 * 
	 */
	function save_organization(){
		if(isset($_POST) && count($_POST)>0){
		
			// Getting the POST details of Organization
			$organizationDetails = array(	'name' 				=> 	ucwords(trim($this->input->post('name'))),
											'type_id'			=> 	$this->input->post('type_id'),
											'website'			=> 	$this->input->post('website'),
											'founded'			=> 	trim($this->input->post('founded')),
											'background'		=>	$this->input->post('background'),
											'products_services'	=> 	$this->input->post('products_services'),
											'mission_vision' 	=> 	$this->input->post('mission_vision'),
											'headquarters'	 	=> 	ucwords(trim($this->input->post('headquarters'))),
											'address'	 		=> 	$this->input->post('address'),
					                        'phone'	 			=> 	$this->input->post('orgphone'),
				 							'fax'	 			=> 	$this->input->post('fax'),
											'country_id'	 	=> 	$this->input->post('country_id'),
											'state_id' 			=> 	$this->input->post('state_id'),
											'city_id'	 		=> 	$this->input->post('city_id'),
				                            'postal_code'	 	=> 	$this->input->post('postal_code'),
				                            'blog'	 			=> 	$this->input->post('blog'),
				                            'facebook'	 		=> 	$this->input->post('facebook'),
				                            'twitter'	 		=> 	$this->input->post('twitter'),
				                            'youtube'	 		=> 	$this->input->post('youtube'),
				                            'linkedin'	 		=> 	$this->input->post('linkedin'),
											'created_by'		=>	$this->loggedUserId,
											'created_on'		=>	date('Y-m-d H:i:s'),
											'status'			=>New1,
											'profile_type'		=>	$this->input->post('profile_type'));
				//pr($organizationDetails);
				
			// Create an array to return the result
			$arrResult = array();
			
			if($lastInsertId = $this->organization->saveOrganization($organizationDetails)){
				$arrResult['saved']			= true;
				$arrResult['lastInsertId']	= $lastInsertId;
				$arrResult['data']			= $organizationDetails;
				$this->session->set_userdata('organizationId', $lastInsertId);
				
				//Update CIN number as organization id
				$updateData = array();
				$updateData['id'] 			=  $lastInsertId;  
	       		$updateData['cin_num'] 		=  $lastInsertId;  
	       		$this->organization->updateOrganization($updateData);
	       		$this->update->insertUpdateEntry(ORG_ADD, $lastInsertId, MODULE_ORGANIZATION, $lastInsertId);
			}else{
				$arrResult['saved']			= false;
				$arrResult['msg']			= "Sorry! Institute Name is  already present in database";
			}
			
			echo json_encode($arrResult);
		}
	}
	
	
	/*
	*    Update  'Organizations' details
	*/
	function update_organization(){
		if(isset($_POST) && count($_POST)>0){
	
		// Getting the POST details of Organization
		$organizationDetails = array(	'id' 				=> 	$this->input->post('org_id'),
										'name' 				=> 	ucwords(trim($this->input->post('name'))),
										'type_id'			=> 	$this->input->post('type_id'),
										'website'			=> 	$this->input->post('website'),
										'founded'			=> 	trim($this->input->post('founded')),
										'background'		=>	utf8_urldecode($this->input->post('background')),
										'products_services'	=> 	$this->input->post('products_services'),
										'mission_vision' 	=> 	$this->input->post('mission_vision'),
										'headquarters'	 	=> 	ucwords(trim($this->input->post('headquarters'))),
										'address'	 		=> 	$this->input->post('address'),
				                        'phone'	 			=> 	$this->input->post('orgphone'),
			 							'fax'	 			=> 	$this->input->post('fax'),
										'country_id'	 	=> 	$this->input->post('country_id'),
										'state_id' 			=> 	$this->input->post('state_id'),
										'city_id'	 		=> 	$this->input->post('city_id'),
			                            'postal_code'	 	=> 	$this->input->post('postal_code'),
			                            'blog'	 			=> 	$this->input->post('blog'),
			                            'facebook'	 		=> 	$this->input->post('facebook'),
			                            'twitter'	 		=> 	$this->input->post('twitter'),
			                            'youtube'	 		=> 	$this->input->post('youtube'),
			                            'linkedin'	 		=> 	$this->input->post('linkedin'),
										'modified_by'		=>	$this->loggedUserId,
										'modified_on'		=>	date('Y-m-d H:i:s'),
										'profile_type'		=>	$this->input->post('profile_type'));
			//pr($organizationDetails);
			
		// Create an array to return the result
		
		//echo $organizationDetails['background'];
		//exit;
		$returnValue = $this->organization->updateOrganization($organizationDetails);
			if($this->organization->updateOrganization($organizationDetails)){
				$arrResult['saved']			= true;
				$arrResult['lastInsertId']	= $organizationDetails['id'];
				$arrResult['data']			= $organizationDetails;
				$this->update->insertUpdateEntry(ORG_ABOUT_UPDATE, $organizationDetails['id'], MODULE_ORGANIZATION, $organizationDetails['id']);
			//	$this->session->set_userdata('organizationId', $lastInsertId);
			}else{
				$arrResult['saved']			= false;
			}
			
			echo json_encode($arrResult);
		
		}
	}
	
	/*
	*    Listing  'Organizations' details
	*/
	function list_organizations_old(){
		//Analyst App to be accessed by only Aissel users. 
		$this->common_helpers->checkUsers();
		$data			=	array();
		$arrOrganization	=	array();
		
		$arrOrganization = $this->organization->listOrganizationDetails();
	
   	 	$data['arrOrganization']	=	$arrOrganization;
   	 	
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
				
	//	$data['contentPage'] 	=	'organizations/list_Organizations';
	//	$this->load->view('organizations/list_Organizations',$data);
		$data['clientUser'] = $this->Client_User->getUserDetail($this->session->userdata('user_id'));
		$data['contentPage'] 	=	'organizations/list_organizations';
		$this->load->view('layouts/analyst_view',$data);
	}	
	
	function list_organizations(){
		//Analyst App to be accessed by only Aissel users.
		$this->common_helpers->checkUsers();
		$data =	array();
		$data['clientUser'] = $this->Client_User->getUserDetail($this->session->userdata('user_id'));
		$data['contentPage'] = 'organizations/list_organizations_grid';
		$this->load->view('layouts/analyst_view',$data);
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Params : none
	 * @Action : Loads parent-child association details Page
	 */
	function list_parent_org_associations(){
		// Lists Organisation Parent Child Association Grid for Aissel Users
		$this->common_helpers->checkUsers ();
		$data = array ();
		$data ['clientUser'] = $this->Client_User->getUserDetail ( $this->session->userdata ( 'user_id' ) );
		$data ['contentPage'] = 'organizations/list_parent_org_associate_grid';
		$this->load->view ('layouts/analyst_view', $data );
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Params : none
	 * @Action : Returns parent-child association details between Organizations to jQgrid
	 */
	function list_parent_org_associate_grid(){
		$this->list_organizations_grid(true);
		return;
	}
	/*
	 * @Author : Sanjeev K
	 * @Params : Organisation Id(s)
	 * @Action : Marks organisation as parent by changing parent id as zero
	 */
	function assign_org_parent(){
		$org_id = $this->input->post('org_id');
		if ($org_id != ''){
			if (!is_array($org_id)){
				$arrOrgIds = explode(",", $org_id);
			}else{
				$arrOrgIds = $org_id;
			}
		}
		$arrFiltered = array_values(array_filter($arrOrgIds));
		$result = $this->organization->updateParentForOrg($arrFiltered);
		if($result == 1){
			$statusCount = sizeof($arrFiltered);
			$data['status'] = 'success';
			$data['count'] = $statusCount;
		}else{
			$data['status'] = 'fail';
		}
		echo json_encode($data);
	}
	/*
	 * @Author : Kishan Ravindra (00001111), Sanjeev k
	 * @Params : orgId, parentOrgId
	 * @Action : Associates Parent Organization (Single and Multiple Association)
	 */
	function associate_parent(){
		$recId = $this->input->post('recId');
		$parentId = $this->input->post('parentId');
		$removeFlag = $this->input->post('remove');
		if ($recId != ''){
			if (!is_array($recId)){
					$arrRecIds = explode(",", $recId);
			}else{
					$arrRecIds = $recId;
			}
		}
		$parentHierarchy = $this->organization->getOrgs('id',$parentId,'WHERE');
		$hierarchy = $parentId == 0 ? null : $parentId;
		foreach ($parentHierarchy as $record){
			$hierarchy .= $record['hierarchy'] != null ? (",".$record['hierarchy']) : ($parentId != 0 ? ",0" : null);
		}
		
		$cyclicAssociation = 0;
		$updateFailedCount = 0;
		$updateSuccessCount = 0;
		$message = '';
		foreach($arrRecIds as $eachRecId){
		if(!empty($eachRecId)){
			if(in_array($eachRecId, explode(',', $hierarchy))){
				$cyclicAssociation++;
				}else{
					$data = array(
							'id' => $eachRecId,
							'parent_id' => $parentId,
							'hierarchy' => $hierarchy
					);
					if($removeFlag == 'set'){
						$status = $this->organization->updateOrganization($data);
						$this->organization->deleteSubOrg($eachRecId);
					}else{
						$childDetails = $this->organization->getOrgs('id',$eachRecId,'WHERE');
						
						$affPartnershipDetails['org_id'] = $parentId;
						$affPartnershipDetails['sub_org_id'] = $eachRecId;
						$affPartnershipDetails['address'] = $childDetails[0]['address'];
						$affPartnershipDetails['city_id'] = $childDetails[0]['city_id'];
						$affPartnershipDetails['state_id'] = $childDetails[0]['state_id'];
						$affPartnershipDetails['country_id'] = $childDetails[0]['country_id'];
						$affPartnershipDetails['postal_code'] = $childDetails[0]['postal_code'];
						$affPartnershipDetails['phone'] = $childDetails[0]['phone'];
						$affPartnershipDetails['url'] = $childDetails[0]['url'];
						$affPartnershipDetails['npi_num'] = $childDetails[0]['npi_num'];
						$status = $this->organization->updateOrganization($data, $affPartnershipDetails);
					}
					if($status){
						if($recId != 0){
							$checkStatus = $this->process_Child_Orgs($eachRecId, $hierarchy);
							if($checkStatus == true){
								$updateSuccessCount++;
							}
						}
					} else {
						$updateFailedCount++;
					}
				}
			}	
		}
		if($updateSuccessCount > 0){
			$value = (sizeof($arrRecIds)>1)?$updateSuccessCount." Organization(s) " :null;
			$message .= $value."Successfully Updated";
		}
		if($updateFailedCount > 0){
			if($message!=null){
				$message .= "<br/>";
			}
			$value = (sizeof($arrRecIds)>1)?$updateFailedCount." Organization(s) ":null;
			$message .= $value."Failed to Update";
		}
		if($cyclicAssociation > 0){
			if($message!=null){
				$message .= "<br/>";
			}
			$value = (sizeof($arrRecIds)>1)?$cyclicAssociation." Organization(s) ":null;
			$message .= $value."Cyclic associations cannot be updated";
		}
		echo $message;
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111), Sanjeev k
	 * @Params : parentId, parent's path
	 * @Action : Updates hierarchy paths for all children of parentId
	 */
	function process_Child_Orgs($parentId, $replacePath){
		$orgList = $this->organization->getOrgs('hierarchy',$parentId,'FIND_IN_SET');
		foreach ($orgList as $orgRecord){
			$oldPath = $orgRecord['hierarchy'];
			$arrRec = explode(',', $oldPath);
			$index = 0;
			foreach ($arrRec as $rec){
				if($rec == $parentId){
					break;
				}
				$index++;
 			}
			$newPath = implode(',', array_slice(explode(',', $oldPath), 0, ++$index));
			$newPath .= $replacePath == null ? ",0" : ",".$replacePath;
			$finalPath = implode(',', array_unique(explode(',', $newPath)));
			$data = array(
				'id' => $orgRecord['id'],
				'hierarchy' => $finalPath
			);
			$status = $this->organization->updateOrganization($data);
		}
		return true;
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Params : Org Name as SearchKey (By POST)
	 * @Action : Returns Matched Organizations(id,name) to AJAX Call
	 */
	function load_Org_autoComplete(){
		$searchKey = $this->input->post('searchKey');
		$resData = $this->organization->getOrgs('name',$searchKey,'LIKE');
		$arrOrg = array();
		$org = array();
		foreach ($resData as $row) {
			$org['id'] = $row['id'];
			$org['name'] = $row['name'];
			$arrOrg[] = $org;
		}
		echo json_encode($arrOrg);
	}
	
	function list_organizations_grid($overRideAction = false ){
		$page = $_REQUEST['page']; // get the requested page 
		$limit = $_REQUEST['rows']; // get how many rows we want
		$sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
		$sord = $_REQUEST['sord']; // get the direction
		if(!$sidx) $sidx =1;
//		echo $page." -- ".$limit." -- ".$sidx." -- ".$sord;
		$filterData=$_REQUEST['filters'];
		$arrFilter=array();
		$arrFilter=json_decode(stripslashes($filterData));
		$field='field';
		$op='op';
		$data='data';
		$groupOp='groupOp';
		$searchGroupOperator=$this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
		$searchString=$this->common_helpers->search_nested_arrays($arrFilter, $data);
		$searchOper=$this->common_helpers->search_nested_arrays($arrFilter, $op);
		$searchField=$this->common_helpers->search_nested_arrays($arrFilter, $field);
		$whereResultArray=array();
		foreach($searchField as $key=> $val){
			$whereResultArray[$val]=$searchString[$key];		
		}
		$searchGroupOperator=$searchGroupOperator[0];
		$searchResults=array();
		$count	=	$this->organization->listOrganizationGridDetails($limit,$start,true,$sidx,$sord,$whereResultArray);
//		echo $this->db->last_query();
		if( $count >0 ) {
			$total_pages = ceil($count/$limit); 
		} else { 
			$total_pages = 0; 
		} 
		if ($page > $total_pages) $page=$total_pages;
		$start = $limit*$page - $limit; // do not put $limit*($page - 1)
		if ($start < 0) $start = 0;
			
		$arrOrgDetailResult = array();
		$data 				= array();
		$arrOrgDetail		= array();
		if($arrOrgDetailResult = $this->organization->listOrganizationGridDetails($limit,$start,false,$sidx,$sord,$whereResultArray)){
//			echo $this->db->last_query();
			foreach($arrOrgDetailResult->result_array() as $row){
				$row['id']			= $row['id'];
				$row['name']		= $row['name'];
				$row['type']		= $row['type'];
				$row['founded']		= $row['founded'];
				if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN){
					if($row['is_pubmed_processed'] == 0)
					$pubStatusHtml= "No";

					if($row['is_pubmed_processed'] == 1)
					$pubStatusHtml = "Yes";

					if($row['is_pubmed_processed'] == 2)
					$pubStatusHtml = "Recrawl";
						
					$row['is_pubmed_processed']	= $pubStatusHtml;
				}else{
					$pubStatus = 'No';
					if($row['is_pubmed_processed'] == 1)
					$pubStatus = 'Yes';
					if($row['is_pubmed_processed'] == 2)
					$pubStatus = 'Recrawl';
					$row['is_pubmed_processed']	= $pubStatus;
				}
				if($row['is_clinical_trial_processed'] == 0){
					$trialStatusHtml= "No";
				}else{
					$trialStatusHtml = "Yes";
				}
				$row['is_clinical_trial_processed']	= $trialStatusHtml;
				
				if($row['profile_type'] == 1){
					$profileTypeHtml= "Basic";
				}else{
					$profileTypeHtml = "Full";
				}
				$parentOrg = $this->organization->getOrgs('id', $row['parent_id'], 'WHERE');
				foreach ($parentOrg as $org){
					$row['parent_name'] = $org['name'];
				}
				$row['profile_type']= $profileTypeHtml;
				$row['created_by']	= $row['user_full_name'];
				$row['status']	= $row['status'];
				$actions = '<div class="actionIcon editIcon"><a href="'.base_url().'organizations/edit_organization/'.$row['id'].'/about" title="Edit">&nbsp;</a></div><div class="actionIcon deleteIcon"><a onclick="deleteSelectedOrg('.$row['id'].');" href="#" title="delete">&nbsp;</a></div>';
				if($overRideAction){
					$actions = '<div class="actionIcon associateIcon"><a href="javascript:assocOrgDialog('.$row['id'].',\''.$row['name'].'\','.$row['parent_id'].',\''.$row['parent_name'].'\');" title="Associate">&nbsp;</a></div>';
				}
				$row['action']	= $actions;
				$arrOrgDetail[]	= $row;
			}
	   
			$data['records']= $count;
			$data['total']  = $total_pages;
			$data['page']	= $page;
			$data['rows']	= $arrOrgDetail;
		}
//		echo $this->db->last_query();
		ob_start('ob_gzhandler');
		echo json_encode($data);
//pr($data);
	}

	/* 
	*  Editing 'Organization' detail
	*/
	function edit_organization($organizationId = null){
		//Analyst App to be accessed by only Aissel users. 
		$this->common_helpers->checkUsers();
		
		$reportSection=$this->uri->segment(4);
		
		if(!$organizationId){
		$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
		redirect('organizations/list_organizations');
		}
  	 	$arrOrganizationDetail = array();
    	// Getting the Organization details
      	$arrOrganizationDetail = $this->organization->editOrganization($organizationId);
  	 	
      	// If there is no record in the database
      	if(!$arrOrganizationDetail){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations');
  	 	}
      	
      	// Set the Organization ID into the Session
    	$this->session->set_userdata('organizationId', $organizationId);
  		
		$data['arrCountry']		=	$this->Country_helper->listCountries();
		
		$arrStates 	= array();
		$arrCities	= array();
		
		if($arrOrganizationDetail['country_id'] != 0){
			$arrStates = $this->Country_helper->getStatesByCountryId($arrOrganizationDetail['country_id']);
		}
		if($arrOrganizationDetail['state_id'] != 0){
			$arrCities = $this->Country_helper->getCitiesByStateId($arrOrganizationDetail['state_id']);
		}
		$data['arrStates']	= $arrStates;
		$data['arrCities']	= $arrCities;
		
		 $arrKeyPeopleRoles = $this->organization->getAllKeyPeopleRoles();
		$data['arrKeyPeopleRoles']	= $arrKeyPeopleRoles;
		
		$arrOrganizationTypes = $this->organization->getAllOrganizationTypes();
		$data['arrOrganizationTypes']	= $arrOrganizationTypes;
		
		$data['arrCountry']=$this->Country_helper->listCountries();
		
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		
		$data['arrContactDetails']	= array();
		$arrContactDetails = array();
		if($arrContactDetails = $this->organization->listContacts($organizationId)){
				foreach ($arrContactDetails->result_array() as $row){
					$data['arrContactDetails'][] = $row;
				}
		}
		
		
		$data['arrOrganization']	= $arrOrganizationDetail;
		//pr($arrOrganizationDetail);
		//$data['orgContentPage'] 	=	'organizations/add_organization';
		//$this->load->view('organizations/organization_profile',$data);
		if($reportSection == 'publications')
			$data['contentPage'] 	=	'organizations/list_publications';
		else if ($reportSection == 'trials')
			$data['contentPage'] 	=	'organizations/list_clinical_trials';
		else
		$data['contentPage'] 	=	'organizations/add_organization';
		$data['reportSection']=$reportSection;
		//$data['orgId']=$organizationId;
		$this->load->view('layouts/analyst_view',$data);
	}	
	
	
	/**
	 * Saves the Key people Details to DB 
	 * 
	 */
	function save_key_people(){
		if(isset($_POST) && count($_POST)>0){
		    $dataType = 'User Added';
		    $client_id =$this->session->userdata('client_id');
		    if($client_id == INTERNAL_CLIENT_ID){
		        $dataType = 'Aissel Analyst';
		    }
			// Getting the POST details of Organization
			$keyPeopleDetails = array(		'id'				=> 	$this->input->post('id'),
											'org_id' 			=> 	$this->input->post('org_id'),
											'role_id' 			=> 	$this->input->post('role_id'),
											'salutation'		=> 	$this->input->post('salutation'),
											'first_name'		=> 	ucwords(trim($this->input->post('first_name'))),
											'middle_name'		=> 	ucwords(trim($this->input->post('middle_name'))),
											'last_name'			=>	ucwords(trim($this->input->post('last_name'))),
											'title' 			=> 	ucwords(trim($this->input->post('title'))),
											'email'	 			=> 	trim($this->input->post('email')),
											'department'	 			=> 	trim($this->input->post('department')),
											'created_by'		=>	$this->loggedUserId,
											'created_on'		=>	date('Y-m-d H:i:s'),
			                                'data_type_indicator' => $dataType
			);
		
				
			// Create an array to return the result
			
			$arrResult = array();
			$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
			
			if($lastInsertId = $this->organization->saveKeyPeople($keyPeopleDetails)){
				$arrResult['saved']				= true;
				$arrResult['lastInsertId']		= $lastInsertId;
				if($keyPeopleDetails['salutation'] !=''){
					$keyPeopleDetails['salutation']	= $arrSalutations[$keyPeopleDetails['salutation']];
				}
				$keyPeopleDetails['role_id']	= $this->organization->getKeyPeopleRoleNameById($keyPeopleDetails['role_id']);
				$keyPeopleDetails['kol_name']   = $keyPeopleDetails['first_name']." ".$keyPeopleDetails['middle_name']." ".$keyPeopleDetails['last_name'];
				$arrResult['data']				= $keyPeopleDetails;
				$this->update->insertUpdateEntry(ORG_KEY_PEOPLE_ADD, $lastInsertId, MODULE_ORG_KEY_PEOPLE, $keyPeopleDetails['org_id']);
				
			}else{
				$arrResult['saved']				= false;
			}
			echo json_encode($arrResult);
		}
	}
	
	/**
	 * Updates the Key people Details to DB 
	 * 
	 */
	function update_key_people(){
	    $dataType = 'User Added';
	    $client_id =$this->session->userdata('client_id');
	    if($client_id == INTERNAL_CLIENT_ID){
	        $dataType = 'Aissel Analyst';
	    }
		if(isset($_POST) && count($_POST)>0){
		
			// Getting the POST details of Organization
			$keyPeopleDetails = array(		'id'				=> 	$this->input->post('id'),
											'org_id' 			=> $this->input->post('org_id'),
											'role_id' 			=> 	$this->input->post('role_id'),
											'salutation'		=> 	$this->input->post('salutation'),
											'first_name'		=> 	ucwords(trim($this->input->post('first_name'))),
											'middle_name'		=> 	ucwords(trim($this->input->post('middle_name'))),
											'last_name'			=>	ucwords(trim($this->input->post('last_name'))),
											'title' 			=> 	ucwords(trim($this->input->post('title'))),
											'email'	 			=> 	trim($this->input->post('email')),
											'department'	 	=> 	trim($this->input->post('department')),
											'modified_by'		=>	$this->loggedUserId,
											'modified_on'		=>	date('Y-m-d H:i:s'),
     	                                    'data_type_indicator' => $dataType);
			
				
			// Create an array to return the result
			
			$arrResult = array();
			$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
			
			if($this->organization->updateKeyPeople($keyPeopleDetails)){
				$arrResult['saved']			= true;
				$arrResult['lastInsertId']	= $keyPeopleDetails['id'];
				if($keyPeopleDetails['salutation'] !=''){
					$keyPeopleDetails['salutation']= $arrSalutations[$keyPeopleDetails['salutation']];
				}
				$keyPeopleDetails['role_id'] = $this->organization->getKeyPeopleRoleNameById($keyPeopleDetails['role_id']);
				$keyPeopleDetails['kol_name']   = $keyPeopleDetails['first_name']." ".$keyPeopleDetails['middle_name']." ".$keyPeopleDetails['last_name'];
				$arrResult['data']			= $keyPeopleDetails;
				$this->update->insertUpdateEntry(ORG_KEY_PEOPLE_UPDATE, $keyPeopleDetails['id'], MODULE_ORG_KEY_PEOPLE, $keyPeopleDetails['org_id']);
			}else{
				$arrResult['saved']			= false;
			}
			echo json_encode($arrResult);
		}
	}
	
	/*
	*    Listing  'Key People' details
	*/
	function list_key_peoples($orgId=null){
		//$arrKols				= $this->payment->getAllKolsName1();
		$arrKols  = $this->pubmed_org->getKolNamesWithConcat();
		$page					= (int)$this->input->post('page'); // get the requested page 
		$limit					= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$data					=	array();
		$arrKeyPeople			=	array();
   	 	$data['arrKeyPeople']	=	$arrKeyPeople;
		$arrSalutations			= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		
		$arrAssociltedPeople = array();
		$arrDetails = array();
		//$data['arrSalutations']	= $arrSalutations;
		$arrKeyPeople =  $this->organization->listKeyPeoples($orgId);
			foreach($arrKeyPeople as $row){
				$row['kol_name'] = $row['salutation']." ".$this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);//$row[FIRST_ORDER]." ".$row[SECOND_ORDER]." ".$row[THIRD_ORDER];
				
				$kolId = array_search($row[FIRST_ORDER].$row[SECOND_ORDER].$row[THIRD_ORDER],$arrKols);
				if($kolId){
					$row['kol_id'] = $kolId;
					$row['is_kol'] = 'Yes';
				}else{
					$row['is_kol'] = 'No';
				}
				$row['role'] = $row['role_id'];
				$arrDetails[]    = $row;
			}
			
			$arrAssocPeople	=  $this->organization->listOrgAssociatedPpl($orgId);
			
			foreach($arrAssocPeople as $people){
				$arrDetail = array();
				$arrDetail['id'] = $people['id'];
				$arrDetail['kol_id'] = $people['id'];
				$arrDetail['kol_name'] = $arrSalutations[$people['salutation']]." ".$people[FIRST_ORDER]." ".$people[SECOND_ORDER]." ".$people[THIRD_ORDER];
				$arrDetail['title'] = $people['title_name'];
				$arrDetail['department'] = $people['division'];
				$arrDetail['role'] = 'Associated People';
				$arrDetail['is_kol'] = 'Yes';
				$arrDetail['org_id'] = $people['org_id'];
				$arrDetail['created_by'] = $people['created_by_org'];
				$arrDetail['eAllowed'] = $this->common_helpers->isActionAllowed('org_details','edit',$arrDetail);
			     $data_type = $people['kol_profile_type'];
                  if($people['kol_profile_type']=='Basic' || $people['kol_profile_type']=='Full Profile'){
                      $data_type = 'Aissel Analyst';
                  }
				
				$arrDetail['data_type_indicator'] = $data_type;
				$arrAssociltedPeople[]=$arrDetail;
			}
			$arrDetails = (is_array($arrDetails))?$arrDetails:array($arrDetails);
			$arrAssociltedPeople = (is_array($arrAssociltedPeople))?$arrAssociltedPeople:array($arrAssociltedPeople);

			$arrOfKeyandAssocPeople = array_merge($arrDetails,$arrAssociltedPeople);
			$count	=	sizeof($arrOfKeyandAssocPeople);				
			if( $count >0 ) { 
				$total_pages = ceil($count/$limit); 
			} else { 
				$total_pages = 0; 
			} 
			$data['records']	=	$count;
			$data['total']		=	$total_pages;
			$data['page']		=	$page;
			$data['rows'] 		= 	$arrOfKeyandAssocPeople;
		
		echo json_encode($data);
	}
	
	
	function list_key_peoples_analyst($orgId=null){
		$arrKols				= $this->payment->getAllKolsName1();
		$page					= (int)$this->input->post('page'); // get the requested page 
		$limit					= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$data					=	array();
		$arrKeyPeople			=	array();
   	 	$data['arrKeyPeople']	=	$arrKeyPeople;
		$arrSalutations			= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		
		$arrAssociltedPeople = array();
		$arrDetails = array();
	if($arrKeyPeople =  $this->organization->listKeyPeoples($this->session->userdata('organizationId'))){
			$count	=	sizeof($arrKeyPeople);				
			if( $count >0 ) { 
				$total_pages = ceil($count/$limit); 
			} else { 
				$total_pages = 0; 
			} 
			$data['records']	=	$count;
			$data['total']		=	$total_pages;
			$data['page']		=	$page;
			$data['rows'] 		= 	$arrKeyPeople;
		}
		echo json_encode($data);
	}
	
	
 	/**
	 * Delete the Key People Data 
	 * 
	 */	
 	function delete_key_people($id){
		if($this->organization->deleteKeyPeople($id)){
			$data['status'] = true;
		}
		else {
			$data['status'] = false;
		}
		echo json_encode($data);
	}
	
	/**
	 * Returns the Reqired ID's
	 * 
	 * @param String	$eventName
	 * @return unknown_type
	 */	
	function get_key_people_types($roleName='',$salutation=''){
		$salutationId='';
		$roleId='';
		if($salutation !=''){
			$salutation = $salutation."".'.';
			$arrSalutations = array(''			=>0,
									'Dr.'		=> 1,
									'Prof.' 	=> 2,
									'Mr.'  		=> 3,
									'Ms.' 		=> 4);
							
			$salutationId  = $arrSalutations[$salutation];
		}
		if($roleName!=''){
			$roleId = $this->organization->getKeyPeopleRoleIdByName($roleName);
		}
		$arrReturnData['salutation']	= $salutationId;
		$arrReturnData['role_id'] 	 	= $roleId;
		echo json_encode($arrReturnData);
	}
	
		
 	/**
	 * Saves the Contact Details to DB 
	 * 
	 */
	function save_contact(){
		
		if(isset($_POST) && count($_POST)>0){
		
		// Getting the POST details of Contact
		$contactDetails = array(	'related_to' 		=> 	$this->input->post('related_to'),
									'phone'				=>	$this->input->post('phone'),
									'created_by'		=> 	$this->loggedUserId,
									'created_on'		=>	date("Y-m-d H:i:s"),
									'org_id'			=>	$this->input->post('org_id'));
		
		//pr($contactDetails);
		// Create an array to return the result
		$arrResult = array();
		
		if($lastInsertId = $this->organization->saveContact($contactDetails)){
			$arrResult['saved']			= true;
			$arrResult['lastInsertId']	= $lastInsertId;
			$arrResult['data']			= $contactDetails;
			$this->update->insertUpdateEntry(ORG_CONTACT_ADD, $lastInsertId, MODULE_ORGANIZATION, $contactDetails['org_id']);
		}else{
			$arrResult['saved']			= false;
		}
		echo json_encode($arrResult);
		}
	}
	

	
   	/**
	 * Edit the Contact Detail 
	 * 
	 */
	function edit_contact($id){
		if($arrContactDetails = $this->organization->editContactById($id)){
			foreach ($arrContactDetails->result_array() as $row){	
				$data['arrContactDetails'][] = $row;
			}
		}
		$this->load->view('contacts/edit_contact',$data);
	}
	
	
	 /**
	 * Updates the Contact detail to DB 
	 * 
	 */
	function update_contact(){
		if(isset($_POST) && count($_POST)>0){
		
		// Getting the POST details of Contact
		$contactDetails = array(	'id'                =>	$this->input->post('id'),
									'related_to' 		=> 	$this->input->post('related_to'),
									'phone'				=>	$this->input->post('phone'),
									'modified_by'		=> 	$this->loggedUserId,
									'modified_on'		=>	date("Y-m-d H:i:s"));
		
		// Create an array to return the result
		$arrResult = array();
		
		if($this->organization->updateContact($contactDetails)){
			$arrResult['saved']			= true;
			$arrResult['lastInsertId']	= $contactDetails['id'];
			$arrResult['data']			= $contactDetails;
			$this->update->insertUpdateEntry(ORG_CONTACT_UPDATE, $contactDetails['id'], MODULE_ORGANIZATION, $contactDetails['org_id']);
		}else{
			$arrResult['saved']			= false;
		}
		echo json_encode($arrResult);
		}
	}
	
 	/**
	 * List the Contacts Data 
	 * 
	 */
	function list_contacts($orgId=null){
		$data				=	array();
		$arrContactsResults	=	array();
		if($arrContactDetails = $this->organization->listContacts($orgId)){
			foreach ($arrContactDetails->result_array() as $row){
				$arrContactsResults[] = $row;
			}
			$page	= (int)$this->input->post('page'); // get the requested page 
			$limit	= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
			$data	= array();
			$count	= sizeof($arrContactsResults);				
			if( $count >0 ) { 
				$total_pages	=	ceil($count/$limit); 
			} else { 
				$total_pages = 0; 
			} 
			$data['records']	=	$count;
			$data['total']		=	$total_pages;
			$data['page']		=	$page;
			$data['rows']		=	$arrContactsResults;
		}
		echo json_encode($data);
	}

  	/**
	 * Delete the Contact detail From DB
	 * 
	 */	
 	function delete_contact($id){
		if($this->organization->deleteContactById($id)){
			echo 'success';
		}else{
			echo 'failed to delete';
		}
	}
	
	/* 
	*  View method for clint apllication 
	*/
	function view($organizationId = null,$subContentPage=''){
		if(!$organizationId){
		$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations_client_view');
		}
		if(!is_numeric($organizationId)){
			$organizationId = $this->process_url_parameters($organizationId);
		}
		if(!is_numeric($organizationId)){
			redirect('organizations/list_organizations_client_view');
		}
		
		$arrOrganizationDetail = array();
		// Getting the Organization details
		$arrOrganizationDetail = $this->organization->editOrganization($organizationId);
//			pr($arrOrganizationDetail); exit;
		// If there is no record in the database
		if(!$arrOrganizationDetail){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations_client_view');
  	 	}
      	
      	// Set the Organization ID into the Session
    	$this->session->set_userdata('organizationId', $organizationId);
  		
//		$data['arrCountry']		=	$this->Country_helper->listCountries();
		
//		$arrStates 	= array();
//		$arrCities	= array();
		if($arrOrganizationDetail['country_id'] != 0){
			$arrStates = $this->Country_helper->getStatesByCountryId($arrOrganizationDetail['country_id']);
			$arrOrganizationDetail['country_name']=$this->Country_helper->getCountryById($arrOrganizationDetail['country_id']);
		}
		if($arrOrganizationDetail['state_id'] != 0){
//			$arrCities = $this->Country_helper->getCitiesByStateId($arrOrganizationDetail['state_id']);
//			$stateCode	=	$this->Country_helper->getStatecodeByStateIdorName($arrOrganizationDetail['state_id'],'id');
//			$data['stateCode']	=	$stateCode;
			$arrOrganizationDetail['state_name'] = $this->Country_helper->getStateById($arrOrganizationDetail['state_id']);
		}
		if($arrOrganizationDetail['city_id'] != 0){
			$arrOrganizationDetail['city_name']=$this->Country_helper->getCityeById($arrOrganizationDetail['city_id']);
		}
		if($arrOrganizationDetail['state_id'] != 0){
			if($arrOrganizationDetail['country_name']=='United States'){
			//$arrCities = $this->Country_helper->getCitiesByStateId($arrKolDetail['state_id']);
				$stateCode	=	$this->Country_helper->getStatecodeByStateIdorName($arrOrganizationDetail['state_id'],'id');
				$arrOrganizationDetail['state_code']	=	$stateCode;
			}
		}
//		$data['arrStates']	= $arrStates;
//		$data['arrCities']	= $arrCities;
		
		 $arrKeyPeopleRoles = $this->organization->getAllKeyPeopleRoles();
		$data['arrKeyPeopleRoles']	= $arrKeyPeopleRoles;
		
		$arrOrganizationTypes = $this->organization->getAllOrganizationTypes();
		$data['arrOrganizationTypes']	= $arrOrganizationTypes;
		
		$data['arrCountry']=$this->Country_helper->listCountries();
		
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		
		$data['arrContactDetails']	= array();
		$arrContactDetails = array();
		if($arrContactDetails = $this->organization->listContacts($organizationId)){
				foreach ($arrContactDetails->result_array() as $row){
					$data['arrContactDetails'][] = $row;
				}
		}
		
		
		
		if($arrOrganizationDetail['type_id']!=PAYOR){
			$medicalDetails	= $this->organization->getMedicalServiceDetails($organizationId);
			if(isset($medicalDetails) && !empty($medicalDetails)){
				foreach($medicalDetails as $row){
					$medicalDetail[]=$row['name'];
				}
				$medicalDetails = implode(', ',$medicalDetail);
			}
			$data['medicalDetails'] = $medicalDetails;
			
			$arrStatFacts = $this->organization->getStatsAndFacts($organizationId);
			$data['arrStatFacts'] 			= $arrStatFacts;
		}
		
		if($arrOrganizationDetail['type_id']==PAYOR){
		//Payer starts
		$data['arrFacts'] = $this->organization->getAllOrgPayersFact($organizationId);
		$year = $this->get_enrollment_years();
		$data['years'] = $year;
		$data['arrEnroll'] 				= $this->organization->getAllOrgEnrollData($organizationId,$year);
		$fromularyIds 					= $this->organization->getOrgPayerFormularies($organizationId);
		$data['arrFormularies'] 		= $this->organization->getAllFormulariesData($fromularyIds);
		$dmIds							= $this->organization->getAllOrgDiseaseManagementIds($organizationId);
		$data['arrDiseseMngmt'] 		= $this->organization->getAllOrgDiseaseManagementData($dmIds);
		$data['arrCollabCategory'] 			= $this->organization->getAllCollaborationCategories();
		$data['arrCollabRatings'] 		= $this->organization->getAllOrgCollabarationRatings($organizationId);
		foreach ($data['arrCollabCategory'] as $k=>$v){
			if(array_key_exists($k,$data['arrCollabRatings'])){
				$data['arrCollabCategory'][$k]['ratings'] = $data['arrCollabRatings'][$k]['ratings'];
			}else{
				$data['arrCollabCategory'][$k]['ratings'] = '';
			}
		}
		//Payer ends
		}
              
		$data['edit_org']	= $this->common_helpers->isActionAllowed('org','edit',$data);
		$data['arrNotes']  				= $this->organization->getNotes($organizationId);
		$data['arrOrganization']		= $arrOrganizationDetail;
                //  pr($data['arrOrganization']);
                $formData = $_POST;
		$formData = json_encode($formData);
		$arrLogDetails = array(
                'type' => LOG_VIEW,
                'description' => 'View Organization',
                'status' => 'success',
                'transaction_id' => $organizationId,
            	'transaction_table_id' => ORGANIZATIONS,
                'transaction_name' => "ViewOrganization",
            	'form_data' => $formData
                );
		$this->config->set_item('log_details', $arrLogDetails);
                log_user_activity(null,true);
		$data['contentPage'] 	= 'view_organization';
		$data['subContentPage']	=	$subContentPage;
		$data['assignedUsers'] = $this->align_user->getAssignedOrgUsers($organizationId);
		
		if($subContentPage == 'details'){
			$this->load->model('Specialty');
                $specialtyName            = $this->Specialty->getAllSpecialties();
                $mcoType            = $this->organization->getMcoTypeNames();
                $addressType            = $this->organization->getAddressTypeNames();
                $data['arrCountries']=$this->Country_helper->listCountries();
                $data['staffs'] = $this->organization->getStaffs($organizationId, 'organization');
                        $data['phones'] = $this->organization->getPhones($organizationId, 'organization');
//                       pr($organizationId); pr(    $data['staffs']); exit;
                $data['arrInstitutions']=$this->Country_helper->listCountries();
                $validationStatus            = $this->organization->getValidationStatusNames();
                $arrMcoTypeTemp = array();
			foreach ($mcoType as $key => $value) {
				$arrMcoTypeTemp[$value['id']] = ($value['name']);
			}
	                $arrAddressTypeTemp = array();
			foreach ($addressType as $key => $value) {
				$arrAddressTypeTemp[$value['id']] = ($value['name']);
			}
	                $arrValidationStatusTemp = array();
			foreach ($validationStatus as $key => $value) {
				$arrValidationStatusTemp[$value['id']] = ($value['name']);
			}
	                $data['validationStatus']=$arrValidationStatusTemp;
			$data['specialtyName']=$specialtyName;
                $data['mcoType']=$arrMcoTypeTemp;
                $data['addressType']=$arrAddressTypeTemp;
                $data['arrLocations'] = $this->organization->getAllLocationsByOrgId($organizationId);
//                pr( $data['arrLocations']); exit;
                	$arrContactData = $this->organization->getContactRestrictions($organizationId);
                 $data['arrContactData']= $arrContactData[0];
		}
		
		$data['data']['rightSideContentPage']	= 'right_sidebar/org_overview';
		$data['data']['rightSideContentPageData']	= array('orgId'=>$organizationId);
		$this->load->view('layouts/client_view',$data);
//		pr($data);
	}	
	
	/**
	 * Uploads the Organization Logo
	 */
	function upload_organization_logo(){
		$this->load->library('ColinUpload');
		$orgLogo = new ColinUpload($_FILES['organization_logo']);
		if ($orgLogo->uploaded) {
			// Save uploaded image with a random name
			
			// Generate the Random String
			$this->load->helper('String');
			$newFileName	= random_string('unique', 20);
			
			$orgLogo->file_new_name_body = $newFileName;
			$orgLogo->Process('images/organization_images/original');
			if ($orgLogo->processed) {
				
			} else {
				log_message('error', 'Error while uploading the image'. $orgLogo->error);
			}

			// Resize the image to Medium Size and save
			$orgLogo->file_new_name_body = $newFileName;
			$orgLogo->image_resize = true;
			$orgLogo->image_x = 400;
			$orgLogo->image_ratio_y = true;
			$orgLogo->Process('images/organization_images/medium');
			if ($orgLogo->processed) {
				
			} else {
				log_message('error', 'Error while Resizing the Image to Medium Size'. $orgLogo->error);
			}
			
			
			// Resize the image to Small Size and save
			$orgLogo->file_new_name_body = $newFileName;
			$orgLogo->image_resize = true;
			$orgLogo->image_x = 144;
			$orgLogo->image_ratio_y = true;
			$orgLogo->Process('images/organization_images/resized');
			if ($orgLogo->processed) {
				//echo 'Image Resized';
				$orgLogo->Clean();
				
				// Save the Image Path into the database
				$this->organization->db->where('id', $this->session->userdata('organizationId'));
				
				$data['company_logo']	= $newFileName . '.' . $orgLogo->file_src_name_ext;
				$this->organization->db->update('organizations', $data);

				// Redirect to the organization Profile
				redirect(base_url().'organizations/edit_organization/'.$this->session->userdata('organizationId').'/about');
				exit;
				
				// Output the HTML text 
				echo '<div id="output">success</div>';
				
				//then output your message (optional)
				$imageSrc	= base_url().'images/organization_images/medium/'.$data['company_logo'];
				echo '<div id="message"><img src="'.$imageSrc.'" alt="Uploaded Image"> </div>';
				
				echo '<div id="imageSrc">'.$imageSrc.'</div>';
				
			} else {
				log_message('error', 'Error while uploading the image'. $orgLogo->error);
			}
		}		
	}
	
	
	/**
	 * Crops the Uploaded Image
	 * @return unknown_type
	 */
	function crop_image(){
		$x1	= $this->input->post('x1');
		$y1	= $this->input->post('y1');
		$x2	= $this->input->post('x2');
		$y2	= $this->input->post('y2');
		$w	= $this->input->post('w');
		$h	= $this->input->post('h');
		$thumbImagePath	= $this->input->post('thumbImagePath');
		
		// Get the FileName info
		$arrFileInfo	= pathinfo($thumbImagePath);
		
		// Filename without Extension
		$fileName	= $arrFileInfo['filename'];
		$fileExtn	= $arrFileInfo['extension'];
		
		/** As of now we don't need this code **/
		$maxSmallImageWidth	= 100;
		
		// Calculate the SCaling Factor
		$scale	= $maxSmallImageWidth/$w;
		
		// Get the existing Image Dimension of the Medium Sized image
		list($imageWidth, $imageHeight, $imageType) = getimagesize($thumbImagePath);
		
		$newImageWidth	= ceil($w * $scale);
		$newImageHeight	= ceil($h * $scale);
		/** End of Unwanted Code **/
		
		$this->load->library('ColinUpload');
		
		// Create the absolute path of the local file system
		$docRoot	= $_SERVER['DOCUMENT_ROOT'];
			$absFilePath	= $docRoot.'/'.$this->config->item('app_folder_path').'images/organization_images/medium/'.$fileName.'.'.$fileExtn;
		$orgLogo = new ColinUpload($absFilePath);
		$newFileName	= $orgLogo->file_src_name_body;
		
		$orgLogo->file_new_name_body = $newFileName;

		// Resize the image to Medium Size and save
		$orgLogo->file_new_name_body = $newFileName;
		$orgLogo->image_resize = true;
		// For Colin Upload
		// My Observation - Top, Right , Bottom , Left (As seen with Crop dimension from Office Pict)
		$right 	= $imageWidth - $x1 - $w;
		$left 	= $x1;
		$top	= $y1;
		$bottom	= $imageHeight - $y1 - $h;
		//- End of Observation

		$orgLogo->image_precrop		= array($top, $right, $bottom, $left);
		$orgLogo->image_x = 100;
		$orgLogo->image_ratio_y = true;
		
		$orgLogo->Process('images/organization_images/resized');
		if ($orgLogo->processed) {
			//echo 'Image Resized';
			//$orgLogo->Clean();
			
			// Save the Image Path into the database
			$this->organization->db->where('id', $this->session->userdata('organizationId'));
			
			$data['company_logo']	= $orgLogo->file_dst_name_body . '.' . $orgLogo->file_src_name_ext;
			$this->organization->db->update('organizations', $data);
			
		} else {
			log_message('error', 'Error while uploading the image'. $orgLogo->error);
		}
		
		// Redirect to the organization Profile
		redirect(base_url().'organizations/add_organization/'.$this->session->userdata('organizationId'));
		
	}
	
	function search_organizations(){
		ini_set('memory_limit',"-1");
		ini_set("max_execution_time",0);
		//$arrFilterById = $this->organization->getFilterByRecentApplied();
		$arrFilterById = false;
		$arrFiltersOrg = array();
		$arrFiltersOrg	   = ($arrFilterById['arrFilterFields'])?$arrFilterById['arrFilterFields']:array();
//		pr($arrFiltersOrg);
		$viewType									= $this->uri->segment(3);
		$noOfRecordsPerPage							= $this->uri->segment(4);
		if($noOfRecordsPerPage=='' && $viewType=='list'){
			$noOfRecordsPerPage						= 10;
		}
		if($noOfRecordsPerPage=='' && ($viewType=='main' || $viewType=='')){
			$noOfRecordsPerPage						= 10;
		}
		$this->ajax_pagination->set_records_per_page($noOfRecordsPerPage);
		$limit=$this->ajax_pagination->per_page;
		$count=0;
		$startFrom=0;
		$arrOrganizations	= array();
		$searchType	= 'simple';
		$arrFiltersOrg['keyword']	= $this->input->post('keyword');
		if($arrFiltersOrg['keyword']==null)	
			$arrFiltersOrg['keyword']="";
		
		$viewMyOrgs = $this->organization->getMyOrgsView($this->loggedUserId);
		if(sizeof($viewMyOrgs) > 0){
			$viewTypeMyOrgs = MY_RECORDS;
			$arrFiltersOrg['viewType'] = $viewMyOrgs;
		}
		else{
			$viewTypeMyOrgs = ALL_RECORDS;
//			$arrFiltersOrg['viewType'] = array(0);
		}
//		pr($arrFilterById['filter_value']['org_id']);
		if(sizeof($arrFilterById['filter_value']['org_id'])>0 && $viewTypeMyOrgs = MY_RECORDS){
			foreach($arrFilterById['filter_value']['org_id'] as $key => $val){
				$orgId = $val;
			}
			if(in_array($orgId,$arrFiltersOrg['viewType'])){
				$arrFiltersOrg['viewType'] = $arrFilterById['filter_value']['org_id']; 
//				echo "its in";
			}else{
				$arrFiltersOrg['viewType'] = ''; 
			}
		}
//		pr($arrFiltersOrg['viewType']);
		//Getting "all Matching Events by event name"
		$arrOrganizations		= $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,false);
		$count					= $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,true);
		$arrOrgByCountryCount	= $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,false,true,'country');
		$arrOrgByStateCount		= $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,false,true,'state');
		$arrOrgByCityCount		= $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,false,true,'city');
		$arrOrgByTypeCount		= $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,false,true,'type');
		$arrOrgByRegionCount	= $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,false,true,'region');
		$arrFilterOrgs=array();
		$this->session->set_userdata('keyword',$arrFiltersOrg['keyword']);
		$this->session->set_userdata('arrFilterFields',$arrFilterOrgs);
		
		$allRegionCount=0;
		$assoArrOrgByRegionCount=array();
		foreach($arrOrgByRegionCount as $row){
			$assoArrOrgByRegionCount[$row['GlobalRegion']]=$row;
			$allRegionCount+=$row['count'];
		}
		$allCountryCount=0;
		$assoArrOrgByCountryCount=array();
		foreach($arrOrgByCountryCount as $row){
			$assoArrOrgByCountryCount[$row['country_id']]=$row;
			$allCountryCount+=$row['count'];
		}
		$allStateCount=0;
		$assoArrOrgByStateCount=array();
		foreach($arrOrgByStateCount as $row){
			$assoArrOrgByStateCount[$row['state_id']]=$row;
			$allStateCount+=$row['count'];
		}
		$allCityCount=0;
		$assoArrOrgByCityCount=array();
		foreach($arrOrgByCityCount as $row){
			$assoArrOrgByCityCount[$row['city_id']]=$row;
			$allCityCount+=$row['count'];
		}
		$allOrgTypeCount=0;
		$assoArrOrgByTypeCount=array();
		foreach($arrOrgByTypeCount as $row){
			$assoArrOrgByTypeCount[$row['org_type_id']]=$row;
			$allOrgTypeCount+=$row['count'];
		}
		
		$profileType = 	($arrFiltersOrg['profile_type'])?$arrFiltersOrg['profile_type']:0;		
//		$arrFilterOrgs['orgIds'] 	= ($arrFiltersOrg[''])?$arrFiltersOrg['']:'';
		$arrFilterOrgs['global_region'] 	= ($arrFiltersOrg['global_region'])?$arrFiltersOrg['global_region']:'';
		$arrFilterOrgs['country'] 	= ($arrFiltersOrg['country'])?$arrFiltersOrg['country']:'';
		$arrFilterOrgs['state'] 	= ($arrFiltersOrg['state'])?$arrFiltersOrg['state']:'';
		$arrFilterOrgs['city'] 		= ($arrFiltersOrg['city'])?$arrFiltersOrg['city']:'';
		$arrFilterOrgs['type'] 		= ($arrFiltersOrg['org_types'])?$arrFiltersOrg['org_types']:'';
		$arrFilterOrgs['profileType'] = ($arrFiltersOrg['profile_type'])?$arrFiltersOrg['profile_type']:array($profileType);
		$arrFilterOrgs['view_type'] = array($viewTypeMyOrgs);	
		
		$arrFiltersApplied	= array();
//			$arrFilterOrgs['profileType'] 	= array($profileType);	
			foreach($arrFilterOrgs as $section =>$arrValues){
				if((sizeof(array_filter($arrValues)))>0){
					$separator	= ' | ';
					switch($section){
						case 'orgIds': 
										$arrFiltersApplied['organizations']	= 'Organization Name';
										break;
						case 'global_region':
										//$arrFiltersApplied['global_region']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($arrSelectedCountries).'">Global Region</a>';
										$arrFiltersApplied['global_region']	= 'Global Region';
							break;
						case 'country':  
										$arrSelectedCountries			= $this->Country_helper->getCountryNameById($arrFilterOrgs['country']);
										$arrFiltersApplied['country']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($separator,$arrSelectedCountries).'">Country</a>';
										break;
						case 'state':  
										$arrSelectedStates			= $this->Country_helper->getStateNameById($arrFilterOrgs['state']);
										$arrFiltersApplied['state']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($separator,$arrSelectedStates).'">State</a>';
										break;
						case 'city':  
										$arrSelectedCities			= $this->Country_helper->getCityNameById($arrFilterOrgs['city']);
										$arrFiltersApplied['city']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($separator,$arrSelectedCities).'">City</a>';
										break;
						case 'type':  
										$arrSelectedOrgTypes		= $this->organization->getOrgTypeById($arrFilterOrgs['type']);
										$arrFiltersApplied['organization_type']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($separator,$arrSelectedOrgTypes).'">Organization Type</a>';
										break;
						case 'profileType':  
	//									$arrSelectedOrgTypes		= $this->organization->getOrgTypeById($arrOrgTypes);
										if($profileType == 2)
											$profileTypeValue = "Full Profiles";
										else
											$profileTypeValue = "Basic Profiles";
										$arrFiltersApplied['profile_type']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.$profileTypeValue.'">Profile Type</a>';
										break;
						case 'view_type':
										if($arrValues[0] == 1)
											$viewTypeString = "My Organizations";
										else
											$viewTypeString = "All Organizations";
										$arrFiltersApplied['viewType']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.$viewTypeString.'">View Type</a>';
										break;
					}
				}
			}
		
//		$orgResultsData['savedQueryFilterApplied']			= implode(', ',$arrFiltersApplied);
//		pr($assoArrOrgByCountryCount);
		//Setting all the required data and forwording in to respective page
		$filterData['allRegionCount']		=	$allRegionCount;
		$filterData['allCountryCount']		=	$allCountryCount;
		$filterData['allStateCount']		=	$allStateCount;
		$filterData['allCityCount']			=	$allCityCount;
		$filterData['allOrgTypeCount']		=	$allOrgTypeCount;
		$filterData['arrOrgByRegionCount']	=	$assoArrOrgByRegionCount;
		$filterData['arrOrgByCountryCount']	=	$assoArrOrgByCountryCount;
		$filterData['arrOrgByStateCount']	=	$assoArrOrgByStateCount;
		$filterData['arrOrgByCityCount']	=	$assoArrOrgByCityCount;
		$filterData['arrOrgByTypeCount']	=	$assoArrOrgByTypeCount;
//		$filterData['selectedOrgNames']		=   $arrOrgIdsAndNames;
		$filterData['selectedRegionTypes']	=	$arrFiltersOrg['global_region'];
		$filterData['selectedCountries']	=   $this->Country_helper->getCountryNameById(($arrFiltersOrg['country']) ? $arrFiltersOrg['country'] : 0);
		$filterData['selectedStates']		=   $this->Country_helper->getStateNameById(($arrFiltersOrg['state']) ? $arrFiltersOrg['state'] : 0);
		$filterData['selectedCities']		=   $this->Country_helper->getCityNameById(($arrFiltersOrg['city']) ? $arrFiltersOrg['city'] : 0);
		$filterData['selectedOrgTypes']		=   $this->organization->getOrgTypeById(($arrFiltersOrg['org_types']) ? $arrFiltersOrg['org_types'] : 0);
		$filterData['savedFilterId']		=   $arrFilterById['id'];
		$filterData['keyword']				=	$arrFiltersOrg['keyword'];
		$filterData['searchType']			= 	$searchType;
		$filterData['viewType']			= 	$viewTypeMyOrgs;
		$arrFiltersOrg['resOrgType'] = "ALL"; 
		$allOrgsCount = $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,true);
		$arrFiltersOrg['resOrgType'] = "PARENT";
		$parentOrgsCount = $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,true);
		$arrFiltersOrg['resOrgType'] = "CHILD";
		$childOrgsCount = $this->organization->getMatchOrganiations($arrFiltersOrg,$limit,$startFrom,true);
		$filterData['selectedOrgs']			= "ALL";
		$filterData['allOrgsCount']			= $allOrgsCount;
		$filterData['parentOrgsCount']		= $parentOrgsCount;
		$filterData['childOrgsCount']		= $childOrgsCount;
		$filterData['otherOrgsCount']		= $allOrgsCount - ($parentOrgsCount + $childOrgsCount);
		$filterData['arrFilterFields']		= 	"";
		$filterData['arrAdvSearchFields']	= 	"";
		$filterData['customFilters']		= $this->organization->getAllCustomFilterByUser($this->loggedUserId);
		$orgResultsData['orgsCount']=$count;
		//pr($arrOrganizations);
		$orgResultsData['arrOrganiations']	=	$arrOrganizations;
		$orgResultsData['searchType']		=	"simple";
		$orgResultsData['msg']=$this->common_helpers->genSearchResMsgs($startFrom,$limit,$count,$arrFiltersOrg['keyword']);
		if(sizeof($arrFiltersOrg['profile_type'])>0){
			foreach ($arrFiltersOrg['profile_type'] as $k=>$v){
				$arrFiltersOrg['profile_type'] = $v;
			}
			$details['profileType'] = $arrFiltersOrg['profile_type']; 
                      
		}
		if(isset($arrFilterById['id']) && $arrFilterById['id'] != ''){
			$details['savedFilterName']						= $arrFilterById['name'];
			$details['savedQueryFilterApplied']				= implode(', ',$arrFiltersApplied);
		}else if($viewTypeMyOrgs != ''){
			$details['savedQueryFilterApplied']				= implode(', ',$arrFiltersApplied);
		}
                $details['add_org']	= $this->common_helpers->isActionAllowed('org','add',$details);
		$details['orgResultsPage']			=	'search/my_org_results';
		$details['orgResultsData']			=	$orgResultsData;
		
		$details['arrOrganiations']			=	$arrOrganizations;
		$details['filterPage']				=	'search/org_filters_li_style';
		$details['filterData']				=	$filterData;
		$data['data']						=	$details;
		$data['contentPage'] 				=	'search/org_results';
		$this->load->view('layouts/client_view',$data);
//		echo $this->db->last_query();
//		pr($data);
	}

	/**
	 * returns the simple filter search results for Event, matching the keyword with event name
	 * @return Array 
	 */
	function filter_search_organizations(){
		ini_set('memory_limit',"-1");
		ini_set("max_execution_time",0);
//            pr($_POST);
		$page=$this->input->post('page');
		$count=0;
		$arrQueryOptions['sort_by']				= 'name';
		$arrQueryOptions['sort_order']			= 'asc';
		$viewType								= $this->uri->segment(3);
		$noOfRecordsPerPage						= $this->uri->segment(4);
		if($viewType=='list'){
			$arrQueryOptions['sort_by']			= $this->input->post('sort_by');
			$arrQueryOptions['sort_order']		= $this->input->post('sort_order');
			if($noOfRecordsPerPage==''){
				$noOfRecordsPerPage				= 10;
			}
		}
		if($noOfRecordsPerPage=='' && ($viewType=='main' || $viewType=='')){
			$noOfRecordsPerPage					= 10;
		}
		
//		$noOfRecordsPerPage	= $this->uri->segment(3);
		if(!empty($noOfRecordsPerPage))
			$this->ajax_pagination->set_records_per_page($noOfRecordsPerPage);
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
		$details=array();
		$keyword	= $this->input->post('keyword');
		$orgName	= $keyword;
		$searchType = $this->input->post('search_type');
	//	if((int)$page>-1){
			//if the request is for the next page result then get the already saved search and filter fields from session
//			$keyword=trim($this->session->userdata('keyword'));	
//			$arrFilterOrgs=$this->session->userdata('arrFilterFields');	
	//	}
	//	else{
			$acOrgName	= trim($this->input->post('org_name'));
			$global_region 	= trim($this->input->post('region_type_id'));
			$country 	= trim($this->input->post('country_id'));		
			$state	 	= trim($this->input->post('state_id'));
			$city	 	= trim($this->input->post('city_id'));
			$orgType 	= trim($this->input->post('org_type_id'));
			//$resOrgType = "ALL";
			$orgsType = trim($this->input->post('orgsType'));
			if($orgsType != ''){
				/* $arrOrgs = array(array("ALL","CHILD"),array("PARENT","BOTH"));
				$arrOrgsType = array();
				$arrOrgsType = explode(",", $orgsType);
				$resOrgType = $arrOrgs[$arrOrgsType[0]][$arrOrgsType[1]]; */
				$arrOrgsType = array();
				$arrOrgsType = explode(",", $orgsType);
				foreach($arrOrgsType as $row){
					if($row != '0'){
						$resOrgType[] = $row;
					}
				}
				if(empty($resOrgType)){
					$resOrgType[] = "ALL";
				}
			}
			if($orgType=="Enter Org Type"){
				$orgType	= '';
			}
			if($acOrgName=="Enter Org Name"){
				$acOrgName	= '';
			}
			if($global_region=="Enter Global Region"){
				$global_region	= '';
			}
			if($country=="Enter Country"){
				$country	= '';
			}
			if($acOrgName=='Enter Org Name'){
				$acOrgName	= '';
			}
			//Get all the selected checkboxs details for respective category
			$arrOrgIds	=	array();
			$arrOrgIds	=	$this->input->post('org_ids');
			if(sizeof($arrOrgIds)>0 && $arrOrgIds!=''){
				$arrOrgIds	=explode(",",$arrOrgIds);
			}
			if($acOrgName!=''){
				$arrIds			= $this->organization->getOrgIdByOrgName($acOrgName,true);
				//$arrOrgIds		= array_merge((array)$arrOrgIds, (array)$arrIds);
				$arrOrgIds		= $arrIds;
			}
			//pr($arrOrgIds);
			$arrGlobalRegions	=	$this->input->post('global_regions');
			if($arrGlobalRegions!='')
				$arrGlobalRegions	=explode(",",$arrGlobalRegions);
				//if the input field is not blank add the value in to respective category array values
				if($global_region!='')
					$arrGlobalRegions[]	=	$global_region;
						
			$arrCountries	=	$this->input->post('countries');
			if($arrCountries!='')
				$arrCountries	=explode(",",$arrCountries);
			//if the input field is not blank add the value in to respective category array values
			if($country!='')
				$arrCountries[]	=	$country;
				
			$arrStates	=	$this->input->post('states');
			if($arrStates!='')
				$arrStates	=explode(",",$arrStates);
			//if the input field is not blank add the value in to respective category array values
			if($state!='')
				$arrStates[]	=	$state;
				
			$arrCities	=	$this->input->post('cities');
			if($arrCities!='')
				$arrCities	=explode(",",$arrCities);
			//if the input field is not blank add the value in to respective category array values
			if($city!='')
				$arrCities[]	=	$city;
			
			$arrOrgTypes	=	$this->input->post('org_types');
			if($arrOrgTypes!='')
				$arrOrgTypes	=explode(",",$arrOrgTypes);
			if($orgType!=''){
				$arrOrgTypes[]	=	$orgType;
			}
			$profileType	=	$this->input->post('profile_type');
                          
			$viewTypeMyOrgs = $this->input->post('view_type');
// 			$viewTypeMyOrgs = $this->input->post('viewTypeMyOrgs');
			//echo 'profile '.$viewMyOrgs;
		if($viewTypeMyOrgs == MY_RECORDS){
			$viewMyOrgs = $this->organization->getMyOrgsView($this->loggedUserId);
			//echo $this->db->last_query();
			if(sizeof($viewMyOrgs) > 0){
				$viewTypeMyOrgs = MY_RECORDS;
				$arrFilterOrgs['viewType'] = $viewMyOrgs;
			}else{
				$arrFilterOrgs['viewType'] = array(0);
			}						
		}
		$arrFilterOrgs['view_type'] 	= array($viewTypeMyOrgs);
		$arrFilterOrgs['profileType'] 	= array($profileType);
		$arrFilterOrgs['orgIds'] 		= $arrOrgIds;
		$arrFilterOrgs['type'] 			= $arrOrgTypes;
		$arrFilterOrgs['global_region'] = $arrGlobalRegions;
		$arrFilterOrgs['country'] 		= $arrCountries;
		$arrFilterOrgs['state'] 		= $arrStates;
		$arrFilterOrgs['city'] 			= $arrCities;
		$arrFilterOrgs['profileType'] 	= $profileType;
		$arrFilterOrgs['resOrgType'] 	= $resOrgType;
//                pr($arrFilterOrgs); exit;
		//Getting "filter Search MatchingEvents"
		$arrOrganizations	= $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,false,false,null,$arrQueryOptions);
		//echo $this->db->last_query();
		$count				= $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,true);
//		echo $this->db->last_query();
//		$this->session->set_userdata('keyword',$keyword);
//		$this->session->set_userdata('arrFilterFields',$arrFilterOrgs);
//		pr($this->session->userdata('arrFilterFields'));
		$arrFiltersApplied	= array();
		
		foreach($arrFilterOrgs as $section =>$arrValues){
			if((sizeof(array_filter($arrValues)))>0){
				$separator	= ' | ';
				switch($section){
					case 'orgIds': 
									$arrFiltersApplied['organizations']	= 'Organization Name';
									break;
					case 'global_region':
					                $arrSelectedRegion = $arrGlobalRegions;
					                $arrFiltersApplied['global_region']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($separator,$arrSelectedRegion).'">Region</a>';
									break;
					case 'country':  
									$arrSelectedCountries			= $this->Country_helper->getCountryNameById($arrCountries);
									$arrFiltersApplied['country']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($separator,$arrSelectedCountries).'">Country</a>';
									break;
					case 'state':  
									$arrSelectedStates			= $this->Country_helper->getStateNameById($arrStates);
									$arrFiltersApplied['state']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($separator,$arrSelectedStates).'">State</a>';
									break;
					case 'city':  
									$arrSelectedCities			= $this->Country_helper->getCityNameById($arrCities);
									$arrFiltersApplied['city']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($separator,$arrSelectedCities).'">City</a>';
									break;
					case 'type':  
									$arrSelectedOrgTypes		= $this->organization->getOrgTypeById($arrOrgTypes);
									$arrFiltersApplied['organization_type']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.implode($separator,$arrSelectedOrgTypes).'">Organization Type</a>';
									break;
					case 'profileType':  
//									$arrSelectedOrgTypes		= $this->organization->getOrgTypeById($arrOrgTypes);
									if($profileType == 2)
										$profileTypeValue = "Full Profiles";
									else
										$profileTypeValue = "Basic Profiles";
									$arrFiltersApplied['profile_type']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.$profileTypeValue.'">Profile Type</a>';
									break;
					case 'view_type':
									if($arrValues[0] == 1)
										$viewTypeString = "My Organizations";
									else
										$viewTypeString = "All Organizations";
									$arrFiltersApplied['viewType']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.$viewTypeString.'">View Type</a>';
									break;
				}
			}
		}
// 		$orgsTypeStr = ($resOrgType == "BOTH" ? "All" : ucwords(strtolower($resOrgType)))." Organizations";
// 		$arrFiltersApplied['resOrgType']	= '<a href="#" onclick="return false;" rel="tooltip" data-original-title="'.$orgsTypeStr.'">Orgs Type</a>';
		$orgResultsData['filtersApplied']	= implode(', ',$arrFiltersApplied);
		//$filterData['arrConfSessionTypes'] 	= $arrFilterOrgs['type'] ;
		$filterData['keyword']				= $keyword;
		$filterData['searchType']			= $searchType;
		$filterData['arrFilterFields']		= $arrFilterOrgs;
		$filterData['arrAdvSearchFields']	= "";
		$orgResultsData['orgsCount']		= $count;
		$orgResultsData['arrOrganiations']	= $arrOrganizations;
		$orgResultsData['searchType']		= "simple";
		$orgResultsData['msg']=$this->common_helpers->genSearchResMsgs($startFrom,$limit,$count,$keyword);
		$orgResultsData['profileType']		= $profileType;
		$details['orgResultsPage']			= 'search/my_org_results';
		$details['orgResultsData']			=	$orgResultsData;
		$orgResultsData['arrSortBy']		= $arrQueryOptions;
		$details['arrOrganiations']			= $arrOrganizations;
		$details['filterPage']				= 'search/org_filters';
		$details['filterData']				= $filterData;
		$data['data']						= $details;
		$data['contentPage'] 				= 'search/org_results';
		$this->load->model('Event_helper');
		$arrConfSessionTypes = $this->Event_helper->getAllConferenceSessionTypes();
		$data['arrConfSessionTypes']	= $arrConfSessionTypes;  
		$this->load->view('search/my_org_results',$orgResultsData);
	}


	/* Getting organization data for "micro view"
	 * 
	 * 
	 */
	function view_micro_org($orgId){
		$count='';
		$arrOrg=array();
		$arrOrg = $this->organization->getOrgMicroData($orgId);
		$data['arrOrg']=$arrOrg;
		$data['kyePeopleCount']=$this->organization->kyePeopleCount($orgId);
		$data['associatedPplCount']=$this->organization->getOrgAssociatedPplCount($orgId);
		$data['associatedPplCount'] = $data['kyePeopleCount']+$data['associatedPplCount'];
		if($data['arrOrg'][0]['city_id']!=0){
			$data['arrOrg'][0]['city']=$this->Country_helper->getCityeById($data['arrOrg'][0]['city_id']);
		}
		if($data['arrOrg'][0]['state_id']!=0){
			$data['arrOrg'][0]['state']=$this->Country_helper->getStateById($data['arrOrg'][0]['state_id']);
			$data['arrOrg'][0]['state_code']	=	$this->Country_helper->getStatecodeByStateIdorName($data['arrOrg'][0]['state_id'],'id');
		}
		$this->load->view('organizations/view_org_micro_profile',$data);
	}
	
	/**
	 * List the Kol People Associated with the one Organization
	 * 
	 * @return unknown_type
	 */
	function list_associated_ppl(){
		$page		= (int)$this->input->post('page'); // get the requested page 
		$limit		= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$data		= array();
		$arrKols	= array();
   	 	
		if($arrKols =  $this->organization->listOrgAssociatedPpl($this->session->userdata('organizationId'))){
			$count	=	sizeof($arrKols);				
			if( $count >0 ) { 
				$total_pages = ceil($count/$limit); 
			} else { 
				$total_pages = 0; 
			} 
			$data['records']	=	$count;
			$data['total']		=	$total_pages;
			$data['page']		=	$page;
			$data['rows'] 		= 	$arrKols;
		}
		echo json_encode($data);
	}
	
	/**
	 * Show the page of List of organizations for the client view
	 * @return unknown_type
	 */
	function list_organizations_client_view(){
		ini_set('memory_limit','-1');
		$data			=	array();
		$arrOrganization	=	array();
		
		//$arrOrganization = $this->organization->listOrganizationDetails();
	
   	 	$data['arrOrganization']	=	$arrOrganization;
   	 	
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
				
		$this->search_organizations();
		//$data['contentPage'] 	=	'organizations/list_organizations_client_view';
		//$this->load->view('layouts/client_view',$data);
	}
	
	/* 
	*  Display organization Associated People
	*/
	function view_keypeople($organizationId = null,$subContentPage=''){
		if(!$organizationId){
		$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
		redirect('organizations/list_organizations');
		}
  	 	$arrOrganizationDetail = array();
    	// Getting the Organization details
      	$arrOrganizationDetail = $this->organization->editOrganization($organizationId);
  	 	
      	// If there is no record in the database
      	if(!$arrOrganizationDetail){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations');
  	 	}
      	
      	// Set the Organization ID into the Session
    	$this->session->set_userdata('organizationId', $organizationId);
  		
		$arrOrganizationTypes = $this->organization->getAllOrganizationTypes();
		//$data['arrAssocPeople']	= $this->organization->listOrgAssociatedPpl($organizationId);
		$data['arrOrganizationTypes']	= $arrOrganizationTypes;
		$data['assignedUsers'] = $this->align_user->getAssignedOrgUsers($organizationId);
		
		$data['arrOrganization']	= $arrOrganizationDetail;
		$data['contentPage'] 	= 'organizations/view_associated_people';
		$data['subContentPage']	=	$subContentPage;
		$this->load->view('layouts/client_view',$data);
	}
	
	/**
	 * Shows the organization upload page
	 * @author 	Ramesh B
	 * @since	2.4
	 * @return 
	 * @created 28-05-2011
	 */
	function view_import_page(){
		$this->load->view('organizations/view_import_page');
	}
	
	function upload_zip_file(){
	//	$path_info = pathinfo($_FILES["overview_import"]['name']);
	
		$type = $this->input->post('university');
		
		if($type=='uni'){
			$dest = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_imports/university/uploaded/".$_FILES["overview_import"]['name'];
		}else{
			$dest = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_imports/payer/uploaded/".$_FILES["overview_import"]['name'];
		}
		move_uploaded_file($_FILES["overview_import"]['tmp_name'],$dest);
		
		$name = substr($_FILES["overview_import"]['name'],0,-4);
		$this->load->library('unzip');
		if($type=='uni'){
			$this->unzip->extract($dest, $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_imports/university/uploaded/");
		}else{
			$this->unzip->extract($dest, $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_imports/payer/uploaded/");
		}
		
		
		$arrUHFiles = array();
		if($type=='uni'){
			$path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_imports/university/uploaded/";
		}else{
			$path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_imports/payer/uploaded/";
		}
		
		if ($handle = opendir($path)) {
			/* This is the correct way to loop over the directory. */
			
					$chk = substr($entry,-4);
					if($chk!='.zip'){
							if(is_dir($path.$name)){
								
								if ($handle1 = opendir($path.$name)) {
									
									while (false !== ($entry1 = readdir($handle1))) {
										
										if($entry1 !='.' && $entry1 !='..' && $entry1 !='.svn'){
										$arrUHFiles[$name][] = $entry1;
									}
								}
								
							}
							
							}
				
			}
		}
		$data['arrProfiles'] = $arrUHFiles;
		$data['contentPage']= 'organizations/list_import_files';
	 	$data['type'] = $type;
		$this->load->view('layouts/analyst_view', $data);
	//	pr($arrUHFiles);
	
	}
	
	function list_uploaded_files($type){
		$arrFiles = array();
		if($type=='uni'){
			$orgUploadedPath = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_imports/university/uploaded/";
		}else{
			$orgUploadedPath = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_imports/payer/uploaded/";
		}
		if ($handle = opendir($orgUploadedPath)) {
			/* This is the correct way to loop over the directory. */
			while (false !== ($entry = readdir($handle))) {
				
				if($entry !='.' && $entry !='..' && $entry !='.svn'){
					echo $entry;
					$chk = substr($entry,-4);
					//$arrUHFiles[] = $entry;
					
					if($chk!='.zip'){
					
						if(is_dir($orgUploadedPath.$entry)){
								
								if ($handle1 = opendir($orgUploadedPath.$entry)) {
									
									while (false !== ($entry1 = readdir($handle1))) {
										
										if($entry1 !='.' && $entry1 !='..' && $entry1 !='.svn'){
										$arrFiles[$entry][] = $entry1;
									}
								}
								
							}
							
							}
					}
				}
			}
		}
		$data['arrProfiles'] = $arrFiles;
		
		$data['contentPage']= 'organizations/list_import_files';
		$data['type'] = $type;
		$this->load->view('layouts/analyst_view', $data);
		
	}
	
	function delete_files(){
		
			//$uploadedPath  = 	$_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/kol_imports/uploaded/";
			$arrFiles = $this->input->post('files');
			$type = $this->input->post('type');
			if($type=='uni'){
				$uploadedPath  = 	$_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_imports/university/uploaded/";
			}else{
				$uploadedPath  = 	$_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_imports/payer/uploaded/";
			}
			$arrFolders = $this->input->post('folders');
	//	pr($arrFiles);
			foreach($arrFiles as $row){
				$pos = strpos($row,'&');
				$folderNAme = substr($row,0,$pos);
				$files[$folderNAme][]=substr($row,$pos+1);
			}
			foreach($files as $folder=>$fileNames){
				
				
				foreach($fileNames as $fileName){
					 unlink($uploadedPath.$folder."/".$fileName);
					
				}
			}
			
			foreach($arrFolders as $folderName){
					 rmdir($uploadedPath.$folderName);

					 
					unlink($uploadedPath.$folderName.".zip");
			}
	}
	
	/**
	 * Uploads the csv files containig the organization profiles and 
	 * parses the csv files and saves the data into respective tables
	 * @author 	Ramesh B
	 * @since	2.4
	 * @return 
	 * @created 28-05-2011
	 */
	function import_org_profiles(){
		$userId		=$this->session->userdata('user_id');
		$clientId	=$this->session->userdata('client_id');
		$arrImportStatusMsg=array();
		$target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_profiles/";
		
		// Uploading Overview file and Parssing and saving the data 
		$overviewFileName	= random_string('unique', 20);
		$overview_file_target_path = $target_path . $overviewFileName; 
		$path_info = pathinfo($_FILES["overview_import"]['name']);
		if($_FILES["overview_import"]['name']!=null){
			//Proceed only if the uploaded file if of type 'csv'
			if($path_info['extension']=='csv'){	
				if(move_uploaded_file($_FILES['overview_import']['tmp_name'], $overview_file_target_path)) {
					$row = 1;
					if (($handle = fopen($overview_file_target_path, "r")) !== FALSE) {
						$organizationTypes=$this->organization->getAllOrganizationTypes();					
						$existingOrgs=array();
					    while (($data = fgetcsv($handle, 10000, ",")) !== FALSE) {
					    if($row==1){
					    		if(trim($data[0])!="CIN NUM" || trim($data[1])!="COMPANY NAME" || trim($data[2])!="COMPANY TYPE" || trim($data[3])!="LOGO" || trim($data[4])!="WEBSITE"
					    		 || trim($data[5])!="COMPANY HEADQUARTERS" || trim($data[6])!="COMPANY BACKGROUND" || trim($data[7])!="MISSION, VISION & VALUES" || trim($data[8])!="KEY PRODUCTS & SERVICES" ){
					    		 	$arrImportStatusMsg['overview']['incorrect_format']='Uploaded File format is incorrect';
					    		 	break;
					    		 }
					    	}
					    	$organizationDetails=array();
					    	if($row>1){
						        $organizationDetails['cin_num']=trim($data[0]);
						        $organizationDetails['name']=ucwords(trim($data[1]));
						        $orgType=array_search(trim($data[2]),$organizationTypes);
						        $organizationDetails['type_id']=$orgType;
						        $organizationDetails['company_logo']=trim($data[3]);
						        $organizationDetails['website']=trim($data[4]);
						        $organizationDetails['headquarters']=trim($data[5]);
						        $organizationDetails['background']=trim($data[6]);
						        $organizationDetails['mission_vision']=trim($data[7]);
						        $organizationDetails['products_services']=trim($data[8]);
						        
						        $organizationDetails['created_by']	=$userId;
						        $organizationDetails['created_on']	=date("Y-m-d H:i:s");
						        //pr($organizationDetails);	
						        /* */
						        //Save only if the 'cin_num' is not blank
						        if($organizationDetails['cin_num']!=""){
							        $id=$this->organization->saveOrganization($organizationDetails);
							        if($id==false){
							        	//array of already existing organizations
							        	$existingOrgs[]=$organizationDetails['name'];
							        }
						        }else{
						        	//aray of organizations having no 'cin_num'
						        	$arrImportStatusMsg['overview']['no_cin_num'][]= $organizationDetails['name'];
						        }		
						       		        
					    	}
					    	$row++;
					    	$arrImportStatusMsg['overview']['success']=true;
					    }
					    $arrImportStatusMsg['overview']['existingOrgs']=$existingOrgs;
					    fclose($handle);
					}
				} else{
				   $arrImportStatusMsg['overview']['upload_error']="Error in uploading file '".$_FILES["overview_import"]['name']."'";
				}
			}
			else{
				$arrImportStatusMsg['overview']['file_type_missmatch']="file type is not 'cvs'";
			}
		}
		// Uploading Organization profiles address file and Parssing and saving the data 
		$addressFileName	= random_string('unique', 20);
		$address_file_target_path = $target_path . $addressFileName; 
		$path_info = pathinfo($_FILES["address_import"]['name']);
		//Proceed only if the uploaded file if of type 'csv'
		if($_FILES["address_import"]['name']!=null){
			if($path_info['extension']=='csv'){		
				if(move_uploaded_file($_FILES['address_import']['tmp_name'], $address_file_target_path)) {
					$row = 1;
					if (($handle = fopen($address_file_target_path, "r")) !== FALSE) {
						$arrCountries	=$this->Country_helper->listCountries();
						$arrStates		=$this->Country_helper->listStates();
						$arrCities		=$this->Country_helper->listCities();	
					    while (($data = fgetcsv($handle, 10000, ",")) !== FALSE) {
					    	//check wherether format is correct or not
					    	if($row==1){
					    		if(trim($data[0])!="CIN NUM" || trim($data[1])!="Company Name" || trim($data[2])!="ADDRESS" || trim($data[3])!="CITY" || trim($data[4])!="POSTAL CODE"
					    		 || trim($data[5])!="STATE" || trim($data[6])!="COUNTRY" || trim($data[7])!="PHONE" || trim($data[8])!="FAX" || trim($data[9])!="Additional Phone Numbers"){
					    		 	$arrImportStatusMsg['address']['incorrect_format']='Uploaded File format is incorrect';
					    		 	break;
					    		 }
					    	}
					    	$organizationDetails=array();
					    	if($row>1){
					    		$countryId=0;
					    		$stateId=0;
					    		$cityId=0;
						        $organizationDetails['cin_num']=trim($data[0]);
						        $organizationDetails['name']=trim($data[1]);
						        $organizationDetails['address']=trim($data[2]);
						        if(array_key_exists(ucwords(trim($data[3])),$arrCities))
						        	$cityId=$arrCities[ucwords(trim($data[3]))]['city_id'];
						        $organizationDetails['city_id']=$cityId;
						        $organizationDetails['postal_code']=trim($data[4]);
						        if(array_key_exists(ucwords(trim($data[5])),$arrStates))
						        	$stateId=$arrStates[ucwords(trim($data[5]))]['state_id'];
						        $organizationDetails['state_id']=$stateId;
						        if(array_key_exists(ucwords(trim($data[6])),$arrCountries))
						        	$countryId=$arrCountries[ucwords(trim($data[6]))]['country_id'];
						        $organizationDetails['country_id']=$countryId;
						        $organizationDetails['phone']=trim($data[7]);
						        $organizationDetails['fax']=trim($data[8]);
						        
						        $faxDetails=explode(" ",$organizationDetails['fax']);
						        $arrFaxValues=array();
						        $faxNumber="";
						        foreach($faxDetails as $value){
						        	if(strpos($value, "+")!=false){
						        		$faxNumber.=trim($value);
						        	}
						        	if(is_numeric($value)){
						        		$faxNumber.=trim($value);
						        	}
						        }
								$organizationDetails['created_by']	=$userId;
						        $organizationDetails['created_on']	=date("Y-m-d H:i:s");
						        
						        //Save only if the 'cin_num' is not blank
						        if($organizationDetails['cin_num']!=""){
							        $id=$this->organization->updateImportedOrganization($organizationDetails);
							        if($id==false){
							        	//array of 'cin_num' not present in database
							        	$arrImportStatusMsg['address']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
							        }
						        }else{
						        	//aray of organizations  having no 'cin_num'
						        	$arrImportStatusMsg['address']['no_cin_num'][]= $organizationDetails['name'];
						        }		
						        
						        //Parsing and saving additional contact details
						        if($organizationDetails['cin_num']!=""){
						        	$arrContactDetails=array();
							        $orgId=$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
							        $aditionalContats=trim($data[9]);
							        $arrAditionalContactDetails=explode("\n",$aditionalContats);
							        foreach($arrAditionalContactDetails as $aditionalContat){
							        	$contactDetails=array();
							        	$phNumber="";
							        	$relatedTo="";
							        	if(strpos($aditionalContat, "-")!=false){
							        		$aditionalContatDetails=explode("-",$aditionalContat);
							        		 foreach($aditionalContatDetails as $value){
									        	if(strpos($value, "+")!=false){
									        		$phNumber.=trim($value);
									        		//echo "EXt-".$phNumber."<br /> ";
									        	}else if(is_numeric($value)){
									        		$phNumber.=trim($value);
									        		//echo "Ph-".$phNumber."<br /> ";
									        	}else {
									        		$relatedTo.=trim($value);
									        		//echo $relatedTo."<br /> ";
									        	}
									        }
							        	}else if(strpos($aditionalContat, ":")!=false){
							        		$aditionalContatDetails=explode(":",$aditionalContat);
							        	 	foreach($aditionalContatDetails as $value){
									        	if(strpos($value, "+")!=false){
									        		$phNumber.=trim($value);
									        	}else if(is_numeric($value)){
									        		$phNumber.=trim($value);
									        	}else {
									        		$relatedTo.=trim($value);
									        	}
									        }
							        	}else{
							        		$aditionalContatDetails=explode(" ",$aditionalContat);
							        		//pr($aditionalContatDetails);
							        	}
							        	//echo $phNumber."<br /> ".$relatedTo." <br /><br />";
							        	$contactDetails['related_to']=$relatedTo;
							        	$contactDetails['phone']=$phNumber;
							        	$arrContactDetails[]=$contactDetails;
							        }
							        if($orgId!=0){
							        	//save additional contact details
							        	foreach($arrContactDetails as $row){
							        		$row['org_id']=$orgId;
							        		$row['created_by']	=$userId;
						        			$row['created_on']	=date("Y-m-d H:i:s");
						        			$this->organization->saveContact($row);
							        	}
							        }else{
							        	//set error details
							        }
						        }
						        /*
						        $id=$this->organization->saveOrganization($organizationDetails);
						        if($id==false){
						        	$existingOrgs[]=$organizationDetails['name'];
						        }		
						        */		        
					    	}
					    	$row++;					    	
					    	$arrImportStatusMsg['address']['success']=true;
					    }
					    fclose($handle);
					}
				} else{
				   $arrImportStatusMsg['address']['upload_error']="Error in uploading file '".$_FILES["overview_import"]['name']."'";
				}
			}
			else{
				$arrImportStatusMsg['address']['file_type_missmatch']="file type is not 'cvs'";
			}
		}
		
		// Uploading Social Media file and Parssing and saving the data 
		$socialMediaFileName	= random_string('unique', 20);
		$social_media_file_target_path = $target_path . $socialMediaFileName; 
		$path_info = pathinfo($_FILES["social_media_import"]['name']);
		if($_FILES["social_media_import"]['name']!=null){
			//Proceed only if the uploaded file if of type 'csv'
			if($path_info['extension']=='csv'){	
				if(move_uploaded_file($_FILES['social_media_import']['tmp_name'], $social_media_file_target_path)) {
					$row = 1;
					if (($handle = fopen($social_media_file_target_path, "r")) !== FALSE) {
						$organizationTypes=$this->organization->getAllOrganizationTypes();		
					    while (($data = fgetcsv($handle, 10000, ",")) !== FALSE) {
					    if($row==1){
					    		if(trim($data[0])!="CIN NUM" || trim($data[1])!="COMPANY NAME" || trim($data[2])!="BLOG" || trim($data[3])!="YOUTUBE" || trim($data[4])!="LINKEDIN"
					    		 || trim($data[5])!="FACEBOOK" || trim($data[6])!="MYSPACE" || trim($data[7])!="TWITTER" ){
					    		 	$arrImportStatusMsg['social_media']['incorrect_format']='Uploaded File format is incorrect';
					    		 	break;
					    		 }
					    	}
					    	$organizationDetails=array();
					    	if($row>1){
						        $organizationDetails['cin_num']=trim($data[0]);
						        $organizationDetails['name']=ucwords(trim($data[1]));
						        
						        $organizationDetails['blog']=trim($data[2]);
						        $organizationDetails['youtube']=trim($data[3]);
						        $organizationDetails['linkedin']=trim($data[4]);
						        $organizationDetails['facebook']=trim($data[5]);
						        //$organizationDetails['myspace']=trim($data[6]);
						        $organizationDetails['twitter']=trim($data[7]);
						        
						        $organizationDetails['created_by']	=$userId;
						        $organizationDetails['created_on']	=date("Y-m-d H:i:s");
						        //pr($organizationDetails);	
						        /* */
						        //Save only if the 'cin_num' is not blank
						        if($organizationDetails['cin_num']!=""){
							        $id=$this->organization->updateImportedOrganization($organizationDetails);
							        if($id==false){
							        	//array of 'cin_num' not present in database
							        	$arrImportStatusMsg['social_media']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
							        }
						        }else{
						        	//aray of address detains having no 'cin_num'
						        	$arrImportStatusMsg['social_media']['no_cin_num'][]= $organizationDetails['name'];
						        }		
						       		        
					    	}
					    	$row++;
					    	$arrImportStatusMsg['social_media']['success']=true;
					    }
					    fclose($handle);
					}
				} else{
				   $arrImportStatusMsg['social_media']['upload_error']="Error in uploading file '".$_FILES["overview_import"]['name']."'";
				}
			}
			else{
				$arrImportStatusMsg['social_media']['file_type_missmatch']="file type is not 'cvs'";
			}
		}
		
		// Uploading Key People file and Parssing and saving the data 
		$keyPeopleFileName	= random_string('unique', 20);
		$key_people_file_target_path = $target_path . $keyPeopleFileName; 
		$path_info = pathinfo($_FILES["key_people_import"]['name']);
		if($_FILES["key_people_import"]['name']!=null){
			//Proceed only if the uploaded file if of type 'csv'
			if($path_info['extension']=='csv'){	
				if(move_uploaded_file($_FILES['key_people_import']['tmp_name'], $key_people_file_target_path)) {
					$row = 1;
					if (($handle = fopen($key_people_file_target_path, "r")) !== FALSE) {
						$arrKeyPeopleRoles=$this->organization->getAllKeyPeopleRoles();
						//$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
						$arrSalutations	= array(''=>0,'Dr.' => 1, 'Prof.' => 2, 'Mr.' => 3, 'Ms.' =>4);			
					    while (($data = fgetcsv($handle, 10000, ",")) !== FALSE) {
					    if($row==1){
					    		if(trim($data[0])!="CIN NUM" || trim($data[1])!="Company" || trim($data[2])!="Role" || trim($data[3])!="Salutation" || trim($data[4])!="First Name"
					    		 || trim($data[5])!="Middle Name" || trim($data[6])!="Last Name" || trim($data[7])!="Title" || trim($data[8])!="Email" || trim($data[9])!="URL" ){
					    		 	$arrImportStatusMsg['key_people']['incorrect_format']='Uploaded File format is incorrect';
					    		 	break;
					    		 }
					    	}
					    	$organizationDetails=array();
					    	if($row>1){
						        $organizationDetails['cin_num']=trim($data[0]);
						        $organizationDetails['name']=ucwords(trim($data[1]));
						        
						        $roleId=array_search(trim($data[2]),$arrKeyPeopleRoles);
						        $keyPeopleDetails['role_id']=$roleId;
						        $keyPeopleDetails['salutation']=$arrSalutations[trim($data[3])];
						        $keyPeopleDetails['first_name']=trim($data[4]);
						        $keyPeopleDetails['middle_name']=trim($data[5]);
						        $keyPeopleDetails['last_name']=trim($data[6]);
						        $keyPeopleDetails['title']=trim($data[7]);
						        $keyPeopleDetails['email']=trim($data[8]);
						        //$organizationDetails['url']=trim($data[9]);
						        
						        $keyPeopleDetails['created_by']	=$userId;
						        $keyPeopleDetails['created_on']	=date("Y-m-d H:i:s");
						        //pr($organizationDetails);	
						        /* */
						        //Save only if the 'cin_num' is not blank
						        if($organizationDetails['cin_num']!=""){
						        	$orgId=$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
						        	if($orgId==0)
						        		$orgId=$this->organization->getOrgIdByOrgName($organizationDetails['name']);
						        	if($orgId!=0){						        
							        	$keyPeopleDetails['org_id']=$orgId;
								        $this->organization->saveKeyPeople($keyPeopleDetails);								        
						        	}else{
						        		$arrImportStatusMsg['key_people']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
						        	}
						        }else{
						        	//aray of address detains having no 'cin_num'
						        	$arrImportStatusMsg['key_people']['no_cin_num'][]= $organizationDetails['name'];
						        }		
						       		        
					    	}
					    	$row++;					    	
					    	$arrImportStatusMsg['key_people']['success']=true;
					    }
					    fclose($handle);
					}
				} else{
				   $arrImportStatusMsg['key_people']['upload_error']="Error in uploading file '".$_FILES["overview_import"]['name']."'";
				}
			}
			else{
				$arrImportStatusMsg['key_people']['file_type_missmatch']="file type is not 'cvs'";
			}
		}
		$data['arrImportStatusMsg']=$arrImportStatusMsg;
		$data['contentPage'] 	=	'organizations/view_import_status';
		$this->load->view('layouts/client_view',$data);
	}
	
	function reload_filters(){
		$page=$this->input->post('page');
		$count=0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
		$details=array();
		$keyword	= $this->input->post('keyword');
		$orgName	= $keyword;
		$searchType = $this->input->post('search_type');
		$viewTypeMyOrgs = $this->input->post("viewTypeMyOrgs");
	//	if((int)$page>-1){
			//if the request is for the next page result then get the already saved search and filter fields from session
	//		$keyword=trim($this->session->userdata('keyword'));	
	//		$arrFilterOrgs=$this->session->userdata('arrFilterFields');	
	//	}
	//	else{
			$acOrgName	= trim($this->input->post('org_name'));
			$global_region = trim($this->input->post('region_type_id')); 
			$country 	= trim($this->input->post('country_id'));
			$state	 	= trim($this->input->post('state_id'));
			$city	 	= trim($this->input->post('city_id'));
			$orgType 	= trim($this->input->post('org_type_id'));
			//$resOrgType = "ALL";
			$orgsType = trim($this->input->post('orgsType'));
			if($orgsType != ''){
				/* $arrOrgs = array(array("ALL","CHILD"),array("PARENT","BOTH"));
				$arrOrgsType = array();
				$arrOrgsType = explode(",", $orgsType);
				$resOrgType = $arrOrgs[$arrOrgsType[0]][$arrOrgsType[1]]; */
				$arrOrgsType = array();
				$arrOrgsType = explode(",", $orgsType);
				foreach($arrOrgsType as $row){
					if($row != '0'){
						$resOrgType[] = $row;
					}
				}
				if(empty($resOrgType)){
					$resOrgType[] = "ALL";
				}
			}
			//Get all the selected checkboxs details for respective category
			$arrOrgIds=array();
			$arrOrgIds	=	$this->input->post('org_ids');
			if($arrOrgIds!=''){
				//$arrOrgIds	=	$this->input->post('org_ids');
				$arrOrgIds	=explode(",",$arrOrgIds);
			}
			if($acOrgName!=''){
				$arrOrgIds	=	array($this->organization->getOrgIdByOrgName($acOrgName));
			}
			$arrGlobalRegions	=	$this->input->post('global_regions');
			if($arrGlobalRegions!='')
				$arrGlobalRegions	=explode(",",$arrGlobalRegions);
				//if the input field is not blank add the value in to respective category array values
				if($global_region!='')
					$arrGlobalRegions[]	=	$global_region;
						
			$arrCountries	=	$this->input->post('countries');
			if($arrCountries!='')
				$arrCountries	=explode(",",$arrCountries);
			//if the input field is not blank add the value in to respective category array values
			if($country!='')
				$arrCountries[]	=	$country;
				
			$arrStates	=	$this->input->post('states');
			if($arrStates!='')
				$arrStates	=explode(",",$arrStates);
			//if the input field is not blank add the value in to respective category array values
			if($state!='')
				$arrStates[]	=	$state;
				
			$arrCities	=	$this->input->post('cities');
			if($arrCities!='')
				$arrCities	=explode(",",$arrCities);
			//if the input field is not blank add the value in to respective category array values
			if($city!='')
				$arrCities[]	=	$city;
			
			$arrOrgTypes	=	$this->input->post('org_types');
			if($arrOrgTypes!='')
				$arrOrgTypes	=explode(",",$arrOrgTypes);
			if($orgType!=''){
				$arrOrgTypes[]	=	$orgType;
			}
			$profileType	=	$this->input->post('profile_type');

			$arrFilterOrgs['orgIds'] 	= $arrOrgIds;
			$arrFilterOrgs['global_region'] 	= $arrGlobalRegions;
			$arrFilterOrgs['country'] 	= $arrCountries;
			$arrFilterOrgs['state'] 	= $arrStates;
			$arrFilterOrgs['city'] 		= $arrCities;
			$arrFilterOrgs['type'] 		= $arrOrgTypes;
			$arrFilterOrgs['profileType'] 	= $profileType;
				
	//	}
		if($viewTypeMyOrgs == MY_RECORDS){
				$viewMyOrgs = $this->organization->getMyOrgsView($this->loggedUserId);
				if(sizeof($viewMyOrgs) > 0){
					$viewTypeMyOrgs = MY_RECORDS;
					$arrFilterOrgs['viewType'] = $viewMyOrgs;
				}else{
					$arrFilterOrgs['viewType'] = array(0);
				}				
			}
		$arrOrgByRegionCount	= $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,false,true,"region");
		$arrOrgByCountryCount	= $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,false,true,"country");
		$arrOrgByStateCount		= $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,false,true,"state");
		$arrOrgByCityCount		= $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,false,true,"city");
		$arrOrgByTypeCount		= $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,false,true,"type");
		//$this->session->set_userdata('keyword',$keyword);
		//$this->session->set_userdata('arrFilterFields',$arrFilterOrgs);

		$arrFilterOrgs['resOrgType'] = "ALL";
		$allOrgsCount = $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,true);
		$arrFilterOrgs['resOrgType'] = "PARENT";
		$parentOrgsCount = $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,true);
		$arrFilterOrgs['resOrgType'] = "CHILD";
		$childOrgsCount = $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,true);
		$arrFilterOrgs['resOrgType'] = "OTHER";
		$otherOrgsCount = $this->organization->getFilterMatchOrganizations($orgName,$arrFilterOrgs,$limit,$startFrom,true);
		/* pr($this->db->last_query());
		exit; */
		$arrOrgIdsAndNames=array();		
		if($arrOrgIds !=''){
			foreach($arrOrgIds as $id){
				$arrOrgIdsAndNames[$id]=$this->organization->getOrgNameByOrgId($id);
			}
		}
		
		$allRegionCount=0;
		$assoArrOrgByRegionCount=array();
		foreach($arrOrgByRegionCount as $row){
			$assoArrOrgByRegionCount[$row['GlobalRegion']]=$row;
			$allRegionCount+=$row['count'];
		}
		
		$allCountryCount=0;
		$assoArrOrgByCountryCount=array();
		foreach($arrOrgByCountryCount as $row){
			$assoArrOrgByCountryCount[$row['country_id']]=$row;
			$allCountryCount+=$row['count'];
		}
		
		$allStateCount=0;
		$assoArrOrgByStateCount=array();
		foreach($arrOrgByStateCount as $row){
			$assoArrOrgByStateCount[$row['state_id']]=$row;
			$allStateCount+=$row['count'];
		}
		
		$allCityCount=0;
		$assoArrOrgByCityCount=array();
		foreach($arrOrgByCityCount as $row){
			$assoArrOrgByCityCount[$row['city_id']]=$row;
			$allCityCount+=$row['count'];
		}
		
		$allOrgTypeCount=0;
		$assoArrOrgByTypeCount=array();
		foreach($arrOrgByTypeCount as $row){
			$assoArrOrgByTypeCount[$row['org_type_id']]=$row;
			$allOrgTypeCount+=$row['count'];
		}
		//$filterData['arrConfSessionTypes']= $arrFilterOrgs['type'] ;
		$filterData['allRegionCount']		= $allRegionCount;
		$filterData['allCountryCount']		= $allCountryCount;
		$filterData['allStateCount']		= $allStateCount;
		$filterData['allCityCount']			= $allCityCount;
		$filterData['allOrgTypeCount']		= $allOrgTypeCount;
		$filterData['arrOrgByRegionCount']	= $assoArrOrgByRegionCount;
		$filterData['arrOrgByCountryCount']	= $assoArrOrgByCountryCount;
		$filterData['arrOrgByStateCount']	= $assoArrOrgByStateCount;
		$filterData['arrOrgByCityCount']	= $assoArrOrgByCityCount;
		$filterData['arrOrgByTypeCount']	= $assoArrOrgByTypeCount;
		$filterData['selectedOrgNames']		= $arrOrgIdsAndNames;
		foreach($arrFilterOrgs['global_region'] as $values){
			$selectedRegionTypes[$values]=$values;
		}
		$filterData['selectedRegionTypes']	=	$selectedRegionTypes;
		$filterData['selectedCountries']	= $this->Country_helper->getCountryNameById($arrCountries);
		$filterData['selectedStates']		= $this->Country_helper->getStateNameById($arrStates);
		$filterData['selectedCities']		= $this->Country_helper->getCityNameById($arrCities);
		$filterData['selectedOrgTypes']		= $this->organization->getOrgTypeById($arrOrgTypes);
		$filterData['selectedProfileTypes']	= $profileType;
		$filterData['viewType']				= $viewTypeMyOrgs;
		$filterData['selectedOrgs']			= $resOrgType; //$resOrgType;
		$filterData['allOrgsCount']			= $allOrgsCount;
		$filterData['parentOrgsCount']		= $parentOrgsCount;
		$filterData['childOrgsCount']		= $childOrgsCount;
		$filterData['otherOrgsCount']		= $otherOrgsCount; //$allOrgsCount - ($parentOrgsCount + $childOrgsCount);
		$filterData['keyword']				= $keyword;
		$filterData['searchType']			= $searchType;
		$filterData['arrFilterFields']		= $arrFilterOrgs;
		$filterData['arrAdvSearchFields']	= "";
		$filterData['customFilters']		= $this->organization->getAllCustomFilterByUser($this->loggedUserId);
// 		pr($filterData);
		$this->load->view('search/org_filters_li_style',$filterData);
	}
	
	/**
	 * Uploads the xls file containig the organization profiles and 
	 * parses the file and  saves the data into respective tables
	 * @author 	Ramesh B
	 * @since	2.5
	 * @return 
	 * @created 28-06-2011
	 */
	function import_org_profiles_xls(){
		ini_set("max_execution_time",7200);
		// Load the plugin
		$this->load->plugin('excelReader/reader2');
		$userId		=$this->session->userdata('user_id');
		$clientId	=$this->session->userdata('client_id');
		$orgID		= 0;
		$target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_profiles/";
		$overviewFileName	= random_string('unique', 20);
		$path_info = pathinfo($_FILES["overview_import"]['name']);
		$overview_file_target_path = $target_path . $overviewFileName . "." . $path_info['extension'];  
		if($_FILES["overview_import"]['name']!=null){
			if($path_info['extension']=='xls'){
				if(move_uploaded_file($_FILES['overview_import']['tmp_name'], $overview_file_target_path)) {
				//	require_once $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."system/plugins/excelReader/reader_pi.php";
				//	$reader=new Spreadsheet_Excel_Reader();
				//	$reader->setUTFEncoder('iconv');
				//	$reader->setOutputEncoding('UTF-8');
				//	$reader->read($overview_file_target_path);
				//	$reader->setOutputEncoding('CP-1251');
					$reader				=	new Spreadsheet_Excel_Reader($overview_file_target_path, true, 'utf-8');
				//	foreach ($reader->boundsheets as $k=>$sheet){
				//		print_r($sheet);
				//	}
				//	pr($overview_file_target_path);
				//	pr($reader->sheets);
				//	exit();
					 foreach($reader->sheets as $k=>$details){
					 	if($k==0){
					 		$numColumns=0;
							//pr($details['cells']);
							$existingOrgs=array();
							$row=1;						
							$organizationTypes=$this->organization->getAllOrganizationTypes();	
							foreach($details['cells'] as $data){
							    if($row==1){
						    		if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="COMPANY TYPE" || trim($data[4])!="LOGO" || trim($data[5])!="WEBSITE"
						    		 || trim($data[6])!="COMPANY HEADQUARTERS" || trim($data[7])!="COMPANY BACKGROUND" || trim($data[8])!="MISSION, VISION & VALUES" || trim($data[9])!="KEY PRODUCTS & SERVICES" ){
						    		 	$arrImportStatusMsg['overview']['incorrect_format']='Uploaded File format is incorrect';
						    		 	break;
						    		 }
						    		 $numColumns=sizeof($data);
							    }
						    	$organizationDetails=array();
						    	if($row>1){
						    		for($i=1;$i<=$numColumns;$i++){
						    			if(!isset($data[$i]))
						    				$data[$i]="";
						    		}
							        $organizationDetails['cin_num']=trim($data[1]);
							        $organizationDetails['name']=ucwords(trim($data[2]));
							        $orgType=array_search(trim($data[3]),$organizationTypes);
							        $organizationDetails['type_id']=$orgType;
							        $organizationDetails['company_logo']=trim($data[4]);
							        $organizationDetails['website']=trim($data[5]);
							        $organizationDetails['headquarters']=trim($data[6]);
							        $organizationDetails['background']=trim($data[7]);
							        $organizationDetails['mission_vision']=trim($data[8]);
							        $organizationDetails['products_services']=trim($data[9]);
							        $organizationDetails['status']=New1;
							        $organizationDetails['created_by']	=$userId;
							        $organizationDetails['created_on']	=date("Y-m-d H:i:s");
							        //pr($organizationDetails);	
							        /* */
							        //Save only if the 'cin_num' is not blank
							        if($organizationDetails['cin_num']!=""){
								        $id=$this->organization->saveOrganization($organizationDetails);
								        if($id==false){
								        	//array of already existing organizations
								        	$existingOrgs[]=$organizationDetails['name'].' has been updated';
								        }else{
								        	$orgID	= $id;
								        }
							        }else{
							        	//aray of organizations having no 'cin_num'
							        	$arrImportStatusMsg['overview']['no_cin_num'][]= $organizationDetails['name'];
							        }		
							       		        
						    	}
						    	$row++;
						    	$arrImportStatusMsg['overview']['success']=true;
							}					
							$arrImportStatusMsg['overview']['existingOrgs']=$existingOrgs;
					 	}
					 	else if($k==1){
					 		$numColumns=0;
					 		$row=1;
					 		$arrCountries	=$this->Country_helper->listCountries();
							$arrStates		=$this->Country_helper->listStates();
							$arrCities		=$this->Country_helper->listCities();	
						    foreach ($details['cells'] as $data) {
						    	//check wherether format is correct or not
						    	if($row==1){
						    		if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="ADDRESS" || trim($data[4])!="CITY" || trim($data[5])!="POSTAL CODE"
						    		 || trim($data[6])!="STATE" || trim($data[7])!="COUNTRY" || trim($data[8])!="PHONE" || trim($data[9])!="FAX" || trim($data[10])!="ADDITIONAL PHONE NUMBERS"){
						    		 	$arrImportStatusMsg['address']['incorrect_format']='Uploaded File format is incorrect';
						    		 	break;
						    		 }
						    		 $numColumns=sizeof($data);
						    	}
						    	$organizationDetails=array();
						    	if($row>1){
						    		for($i=1;$i<=$numColumns;$i++){
						    			if(!isset($data[$i]))
						    				$data[$i]="";
						    		}
						    		$countryId=0;
						    		$stateId=0;
						    		$cityId=0;
							        $organizationDetails['cin_num']=trim($data[1]);
							        $organizationDetails['name']=trim($data[2]);
							        $organizationDetails['address']=trim($data[3]);
							        if(array_key_exists(ucwords(trim($data[4])),$arrCities))
							        	$cityId=$arrCities[ucwords(trim($data[4]))]['city_id'];
							        $organizationDetails['city_id']=$cityId;
							        $organizationDetails['postal_code']=trim($data[5]);
							        if(array_key_exists(ucwords(trim($data[6])),$arrStates))
							        	$stateId=$arrStates[ucwords(trim($data[6]))]['state_id'];
							        $organizationDetails['state_id']=$stateId;
							        if(array_key_exists(ucwords(trim($data[7])),$arrCountries))
							        	$countryId=$arrCountries[ucwords(trim($data[7]))]['country_id'];
							        $organizationDetails['country_id']=$countryId;
							        $organizationDetails['phone']=trim($data[8]);
							        $organizationDetails['fax']=trim($data[9]);
							        
							        $faxDetails=explode(" ",$organizationDetails['fax']);
							        $arrFaxValues=array();
							        $faxNumber="";
							        foreach($faxDetails as $value){
							        	if(strpos($value, "+")!=false){
							        		$faxNumber.=trim($value);
							        	}
							        	if(is_numeric($value)){
							        		$faxNumber.=trim($value);
							        	}
							        }
									$organizationDetails['created_by']	=$userId;
							        $organizationDetails['created_on']	=date("Y-m-d H:i:s");
							        
							        //Save only if the 'cin_num' is not blank
							        if($organizationDetails['cin_num']!=""){
							        	$orgID =$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
							        	if($orgID>0){
							        		$organizationDetails['id']	= $orgID;
							        	}
								        $id=$this->organization->updateImportedOrganization($organizationDetails);
								       // echo $this->db->last_query();
								        if($id==false){
								        	//array of 'cin_num' not present in database
								        	$arrImportStatusMsg['address']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
								        }
							        }else{
							        	//aray of organizations  having no 'cin_num'
							        	$arrImportStatusMsg['address']['no_cin_num'][]= $organizationDetails['name'];
							        }		
							        
							        //Parsing and saving additional contact details
							        if($organizationDetails['cin_num']!=""){
							        	$arrContactDetails=array();
								        $orgId=$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
								        $aditionalContats=trim($data[10]);
								        $arrAditionalContactDetails=explode("\n",$aditionalContats);
								        foreach($arrAditionalContactDetails as $aditionalContat){
								        	$contactDetails=array();
								        	$phNumber="";
								        	$relatedTo="";
								        	if(strpos($aditionalContat, "-")!=false){
								        		$aditionalContatDetails=explode("-",$aditionalContat);
								        		 foreach($aditionalContatDetails as $value){
										        	if(strpos($value, "+")!=false){
										        		$phNumber.=trim($value);
										        		//echo "EXt-".$phNumber."<br /> ";
										        	}else if(is_numeric($value)){
										        		$phNumber.=trim($value);
										        		//echo "Ph-".$phNumber."<br /> ";
										        	}else {
										        		$relatedTo.=trim($value);
										        		//echo $relatedTo."<br /> ";
										        	}
										        }
								        	}else if(strpos($aditionalContat, ":")!=false){
								        		$aditionalContatDetails=explode(":",$aditionalContat);
								        	 	foreach($aditionalContatDetails as $value){
										        	if(strpos($value, "+")!=false){
										        		$phNumber.=trim($value);
										        	}else if(is_numeric($value)){
										        		$phNumber.=trim($value);
										        	}else {
										        		$relatedTo.=trim($value);
										        	}
										        }
								        	}else{
								        		$aditionalContatDetails=explode(" ",$aditionalContat);
								        		//pr($aditionalContatDetails);
								        	}
								        	//echo $phNumber."<br /> ".$relatedTo." <br /><br />";
								        	$contactDetails['related_to']=$relatedTo;
								        	$contactDetails['phone']=$phNumber;
								        	$arrContactDetails[]=$contactDetails;
								        }
								        if($orgId!=0){
								        	//save additional contact details
								        	foreach($arrContactDetails as $row){
								        		$row['org_id']=$orgId;
								        		$row['created_by']	=$userId;
							        			$row['created_on']	=date("Y-m-d H:i:s");
							        			$this->organization->saveContact($row);
								        	}
								        }else{
								        	//set error details
								        }
							        }
							        /*
							        $id=$this->organization->saveOrganization($organizationDetails);
							        if($id==false){
							        	$existingOrgs[]=$organizationDetails['name'];
							        }		
							        */		        
						    	}
						    	$row++;					    	
						    	$arrImportStatusMsg['address']['success']=true;
						    }
					 	}
					 	else if($k==2){
					 		$numColumns=0;
					 		$row=1;
					 		$organizationTypes=$this->organization->getAllOrganizationTypes();		
						    foreach($details['cells'] as $data) {
						    if($row==1){
						    		if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="BLOG" || trim($data[4])!="YOUTUBE" || trim($data[5])!="LINKEDIN"
						    		 || trim($data[6])!="FACEBOOK" || trim($data[7])!="TWITTER" ){
						    		 	$arrImportStatusMsg['social_media']['incorrect_format']='Uploaded File format is incorrect';
						    		 	break;
						    		 }
						    		 $numColumns=sizeof($data);
						    	}
						    	$organizationDetails=array();
						    	if($row>1){
						    		for($i=1;$i<=$numColumns;$i++){
						    			if(!isset($data[$i]))
						    				$data[$i]="";
						    		}
							        $organizationDetails['cin_num']=trim($data[1]);
							        $organizationDetails['name']=ucwords(trim($data[2]));
							        
							        $organizationDetails['blog']=trim($data[3]);
							        $organizationDetails['youtube']=trim($data[4]);
							        $organizationDetails['linkedin']=trim($data[5]);
							        $organizationDetails['facebook']=trim($data[6]);
							        //$organizationDetails['myspace']=trim($data[7]);
							        $organizationDetails['twitter']=trim($data[7]);
							        
							        $organizationDetails['created_by']	=$userId;
							        $organizationDetails['created_on']	=date("Y-m-d H:i:s");
							    	//pr($organizationDetails);	
							        /* */
							        
							        //Save only if the 'cin_num' is not blank
							        if($organizationDetails['cin_num']!=""){
							        	$orgID	= $this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
							        	if($orgID>0){
							        		$organizationDetails['id']	= $orgID;
							        	}
								        $id=$this->organization->updateImportedOrganization($organizationDetails);
								        if($id==false){
								        	//array of 'cin_num' not present in database
								        	$arrImportStatusMsg['social_media']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
								        }
							        }else{
							        	//aray of address detains having no 'cin_num'
							        	$arrImportStatusMsg['social_media']['no_cin_num'][]= $organizationDetails['name'];
							        }		
							       		        
						    	}
						    	$row++;
						    	$arrImportStatusMsg['social_media']['success']=true;
						    }
					 	}
					 	else if($k==3){
					 		//pr($details);
					 		$numColumns=0;
					 		$row=1;
					 		$arrKeyPeopleRoles=$this->organization->getAllKeyPeopleRoles();
							//$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
							$arrSalutations	= array(''=>0,'Dr.' => 1, 'Prof.' => 2, 'Mr.' => 3, 'Ms.' =>4);			
						    foreach($details['cells'] as $data) {
						    if($row==1){
						    		if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="ROLE" || trim($data[4])!="SALUTATION" || trim($data[5])!="FIRST NAME"
						    		 || trim($data[6])!="MIDDLE NAME" || trim($data[7])!="LAST NAME" || trim($data[8])!="TITLE" || trim($data[9])!="EMAIL" ){
						    		 	$arrImportStatusMsg['key_people']['incorrect_format']='Uploaded File format is incorrect';
						    		 	break;
						    		 }
						    		 $numColumns=sizeof($data);
						    	}
						    	$organizationDetails=array();
						    	if($row>1){
						    		for($i=1;$i<=$numColumns;$i++){
						    			if(!isset($data[$i]))
						    				$data[$i]="";
						    		}
							        $organizationDetails['cin_num']=trim($data[1]);
							        $organizationDetails['name']=ucwords(trim($data[2]));
							        
							        $roleId=array_search(trim($data[3]),$arrKeyPeopleRoles);
							        $keyPeopleDetails['role_id']=$roleId;
							        $keyPeopleDetails['salutation']=$arrSalutations[trim($data[4])];
							        $keyPeopleDetails['first_name']=trim($data[5]);
							        $keyPeopleDetails['middle_name']=trim($data[6]);
							        $keyPeopleDetails['last_name']=trim($data[7]);
							        $keyPeopleDetails['title']=trim($data[8]);
							        $keyPeopleDetails['email']=trim($data[9]);
							        //$organizationDetails['url']=trim($data[10]);
							        
							        $keyPeopleDetails['created_by']	=$userId;
							        $keyPeopleDetails['created_on']	=date("Y-m-d H:i:s");
							        //pr($organizationDetails);	
							        /* */
							        //Save only if the 'cin_num' is not blank
							        if($organizationDetails['cin_num']!=""){
							        	$orgId=$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
							        	if($orgId==0)
							        		$orgId=$this->organization->getOrgIdByOrgName($organizationDetails['name']);
							        	if($orgId!=0){				        
								        	$keyPeopleDetails['org_id']=$orgId;
									        $this->organization->saveKeyPeople($keyPeopleDetails);	
									        //pr($keyPeopleDetails);
									        //echo $this->db->last_query();							        
							        	}else{
							        		$arrImportStatusMsg['key_people']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
							        	}
							        }else{
							        	//aray of address detains having no 'cin_num'
							        	$arrImportStatusMsg['key_people']['no_cin_num'][]= $organizationDetails['name'];
							        }		
							       		        
						    	}
						    	$row++;					    	
						    	$arrImportStatusMsg['key_people']['success']=true;
						    }
					 	}
					}
				}
			}
			else{
				$arrImportStatusMsg['overview']['file_type_missmatch']="file type is not 'xls'";
			}
		}
				
		//pr($arrImportStatusMsg);
		$data['arrImportStatusMsg']=$arrImportStatusMsg;
		$data['contentPage'] 	=	'organizations/view_import_status';
		$this->load->view('layouts/analyst_view',$data);
	}
	
	/**
	 * 
	 * Deletes the entire Organization Related formation. For the passed organization id
	 * @author 	Ambarish N
	 * @since	2.6
	 * @created July-20-2011
	 * 
	 * @param Array $orgsId
	 * @return boolean
	 */
	function delete_organizations($orgsId){
		$arrOrganizations = explode(',',$orgsId);
		foreach ($arrOrganizations as $orgId){
			$arrOrgDetail = array();
	    	// Getting the Organization details
	      	$arrOrgDetail = $this->organization->editOrganization($orgId);
		    //Delete organization Profile images
      		if($arrOrgDetail['company_logo'] !=''){
      			if(strpos($arrOrgDetail['company_logo'], ":")==false){
		      		unlink($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."images/organization_images/medium/".$arrOrgDetail['company_logo']);
		      		unlink($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."images/organization_images/original/".$arrOrgDetail['company_logo']);
		      		unlink($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."images/organization_images/resized/".$arrOrgDetail['company_logo']);
      			}
      		}
      		$this->organization->deleteOrganization($orgId);
			$this->organization->deleteAdditionalContactByOrgId($orgId);
			$this->organization->deleteKeyPeopleByOrgId($orgId);
		} 
		//End of Loop through Each Organization
		$msg = true;
		echo json_encode($msg);
	}
	
	/**
	 * Retruns the Organization Name's matching given string
	 * @author 	Ramesh B
	 * @since	2.6
	 * @return Array
	 * @created 25-07-2011
	 */
	function get_org_names($orgName){
		$orgName		= utf8_urldecode($this->input->post($orgName));
		$arrOrgNames = $this->organization->getMatchingOrgNames($orgName);
		if(sizeof($arrOrgNames)==0){
			$arrOrgNames[0]		= 'No results found for '.$orgName;
		}
		$arrReturnData['query'] = $orgName;
		$arrReturnData['suggestions']	= $arrOrgNames;
		echo json_encode($arrReturnData);
	}
	
	/**
	 * Retruns the Organization Types matching given string
	 * @author 	Ramesh B
	 * @since	2.6
	 * @return JSON
	 * @created 25-07-2011
	 */
	function get_org_types($orgType){
		$orgType		= utf8_urldecode($this->input->post($orgType));
		$arrOrgTypes = $this->organization->getMatchingOrgTypes($orgType);
		$arrSuggestTypes	= array();
		if(sizeof($arrOrgTypes)==0){
			$arrSuggestTypes[0]		= 'No results found for '.$orgType;
		}else{
			$flag	= 1;
			foreach($arrOrgTypes as $typeId=>$type){
				if($flag){
					$arrSuggestTypes[]='<div class="autocompleteHeading">Organization Types</div><div class="dataSet"><label name="'.$typeId.'" class="orgTypes" style="display:block">'.$type."</label></div>";
					$flag	= 0;
				}else{
					$arrSuggestTypes[]='<div class="dataSet"><label name="'.$typeId.'" class="orgTypes" style="display:block">'.$type."</label></div>";
				}
			}
		}
		$arrReturnData['query'] = $orgType;
		$arrReturnData['suggestions']	= $arrSuggestTypes;
		echo json_encode($arrReturnData);
	}
	
	/**
	 * Passing  single Organizations Id to 'org_export' function for Exporing
	 * @author 	Vinayak
	 * @since	3.1
	 * @return Array
	 * @created 25-09-2011
	 */
	function single_org_export_old($orgId,$type){
		$orgIds=array();
		$orgIds[]=$orgId;
		if($type==8){
			$this->org_payer_export($orgIds);
		}else{
			$this->org_export($orgIds);
		}
	}
	
	/**
	 * Passing  Multiple Organizations Id to 'org_export' function for Exporing
	 * @author Vinayak
	 * @since	3.1
	 * @return Array
	 * @created 25-09-2011
	 */
	function multiple_org_export_old($values,$type){
		//$values=$this->input->post('org_ids');
		//$values = 250,245,246;
		$orgIds=explode(',',$values);
	echo $values;
	exit();
		//$orgIds = array(250,245,246);
		
		if($type==8){
			$this->org_payer_export($orgIds);
		}else{
			$this->org_export($orgIds);
		}
	}
	
	/**
	 * preparing all organizations to be export
	 * @author 	Vinayak
	 * @since	1.0.11
	 * @return Array
	 * @created 4 appr 2013
	 */
	function org_export($orgIds){

		$clientId = $this->session->userdata('client_id');
	
		$this->load->plugin('phpxls/writer');
		$arrOrganizationDetailSheet[0]	= array('CIN NUM','COMPANY NAME','COMPANY TYPE','LOGO','WEBSITE','COMPANY HEADQUARTERS','COMPANY BACKGROUND','MISSION, VISION & VALUES','FOUNDED','NPI NUMBER','PROFILE TYPE');

		
		$arrOrgAddressSheet[0]			= array('CIN NUM','COMPANY NAME','ADDRESS','CITY','POSTAL CODE','STATE','COUNTRY','PHONE','FAX','ADDITIONAL PHONE NUMBERS');
		$arrSocialMediaDetailsSheet[0]	= array('CIN NUM','COMPANY NAME','BLOG','YOUTUBE','LINKEDIN','FACEBOOK','TWITTER');
		$arrkeyPeoplesSheet[0]			= array('CIN NUM','COMPANY NAME','ROLE','SALUTATION','FIRST NAME','MIDDLE NAME','LAST NAME','TITLE','EMAIL');
		$arrMedialserviceSheet[0]		= array('CIN NUM','COMPANY NAME','MEDICAL SERVICES');
		$arrSubOrgSheet[0]		= array('CIN NUM','COMPANY NAME','INSTITUTE NAME','ADDRESS','CITY','POSTAL CODE','STATE','COUNTRY','PHONE','NPI NUMBER');
		$arrStatFactSheet[0]		= array('CIN NUM','COMPANY NAME','NO. OF BEDS','INPATIENT','BIRTHS','OUTPATIENT ','EMERGENCY DEPARTMENT','NO. OF SURGERIES');

		$arrAssocitedPeopleSheet[0]		= array('CIN NUM','COMPANY NAME',"KOL NAME","SPECIALTY",'COUNTRY','PHONE','EMAIL');
		$arrkeyPeoplesSheet[0] = array('CIN NUM','COMPANY NAME','ROLE','SALUTATION','FIRST NAME','MIDDLE NAME','LAST NAME','DEPARTMENT/DIVISION/CENTER','TITLE','EMAIL');
		$arrPublicationsSheet[0] = array('CIN NUM','COMPANY NAME','Article Title','PMID','Journal Name','Date','Authors');
		
		$arrTrialSheet[0] = array('CIN NUM','COMPANY NAME','CTID','Study Type','Trial Name','Condition','Intervention','Phase','Number of enrollees','Number of trial sites','Sponsors','Status','Start Date','End Date',
		'Minimum Age','Maximum Age','Gender','Investigators','Collaborator','Purpose','Official Title','Keywords','MeSH Terms');
		
		if($clientId == INTERNAL_CLIENT_ID){
			$arrOrganizationDetailSheet[0][]='URL';
			$arrOrgAddressSheet[0][] = 'URL';
			$arrkeyPeoplesSheet[0][] = 'URL';
			$arrMedialserviceSheet[0][] = 'URL';
			$arrSubOrgSheet[0][] = 'URL';
			$arrStatFactSheet[0][] = 'URL1';
			$arrStatFactSheet[0][] = 'URL2';
		}
		//pr($arrOrganizationDetailSheet);
		//pr($arrOrgAddressSheet);
		//pr($arrkeyPeoplesSheet);
	//	pr($arrMedialserviceSheet);
	//	pr($arrSubOrgSheet);
	//	pr($arrStatFactSheet);
	//	pr($arrSubOrgSheet);
		//break;
		
			foreach($orgIds as $id){
				//Getting the Organizations Details
				$arrOrganizationDetail	= $this->organization->getOrgDetails($id);
				//Getting the Organizations Address Details	
				
				$orgAdress				= $this->organization->getAdreessOfOrg($id);
				
				//Getting the Organizations Social Media Details									
				$orgSocialMediaDetails	= $this->organization->getSocialMediaDetailsOfOrg($id);
				//Getting the Organizations KeyPeople  Details
				$orgkeyPeoples			= $this->organization->getKeyPeopleDetailsOfOrg($id);
				
				//Preparing the Array For Exporting
				$arrOrganizationDetail1	= array();
				foreach($arrOrganizationDetail as $key=>$orgValue){
					
					$arrDetail = array();
					
					$arrDetail[] = $orgValue['cin_num'];
					$arrDetail[] = $orgValue['name'];
					$arrDetail[] = $orgValue['type'];
					$arrDetail[] = $orgValue['company_logo'];
					$arrDetail[] = $orgValue['website'];
					$arrDetail[] = $orgValue['headquarters'];
					$arrDetail[] = $orgValue['background'];
					$arrDetail[] = $orgValue['mission_vision'];
					$arrDetail[] = $orgValue['founded'];
					$arrDetail[] = $orgValue['npi_num'];
				
					if($orgValue['profile_type']==BASIC){
						$arrDetail[] = 'Basic';
					}				
					
					if($orgValue['profile_type']==FULL){
						$arrDetail[] = 'Full Profile';
					}
					$arrOrganizationDetailSheet[]	= $arrDetail;
				}
				
			//pr($arrOrganizationDetailSheet);
				//Preparing the Array For Exporting
				$arrSocialMediaDetails = array();
			//pr($orgSocialMediaDetails);
				foreach($orgSocialMediaDetails as $key=>$orgDetails){
					foreach($orgDetails as $row){
						$arrSocialMediaDetails[]= $row;
					}
				}
				$arrSocialMediaDetailsSheet[]	= $arrSocialMediaDetails;
				
				if(!(empty($orgkeyPeoples))){
					//Preparing the Array For Exporting
					foreach($orgkeyPeoples as $key=>$orgDetails){
						$arrkeyPeoples =array();
						foreach($orgDetails as $row){
							$arrkeyPeoples[]=$row;
						}
						$arrkeyPeoplesSheet[]	= $arrkeyPeoples;
					}
				}
				foreach($orgAdress as $key=>$orgDetails){
					$arrOrgAddress = array();
					$arrOrgAddress[]=$orgDetails['cin_num'];
					$arrOrgAddress[]=$orgDetails['name'];
					$arrOrgAddress[]=$orgDetails['address'];
					$arrOrgAddress[]=$orgDetails['city'];
					$arrOrgAddress[]=$orgDetails['postal_code'];
					$arrOrgAddress[]=$orgDetails['region'];
					$arrOrgAddress[]=$orgDetails['country'];
					$arrOrgAddress[]=$orgDetails['phone'];
					$arrOrgAddress[]=$orgDetails['fax'];
					//$arrOrgAddress[]=$orgDetails['fax'];
					
					$arrAdditionalContacts=$this->organization->getaddtionalContcat($id);
					//pr($arrAdditionalContacts);
					$phoneDetails='';
					$phoneDetails=implode("\n",$arrAdditionalContacts);
					$arrOrgAddress[]=$phoneDetails;
					if($clientId == INTERNAL_CLIENT_ID){
						$arrOrgAddress[] = $orgDetails['url'];
					}
					$arrOrgAddressSheet[]=$arrOrgAddress;
				}
				
			//Getting the Organizations Medical service  Details
			$orgMedialService			= $this->organization->getOrgMediaclServiceDetail($id);
			foreach($orgMedialService as $key=>$mediaclDetail){
				$arrDetails =array();
				$arrDetails[]=$mediaclDetail['cin_num'];
				$arrDetails[]=$mediaclDetail['name'];
				$arrDetails[]=$mediaclDetail['medical_service'];
				if($clientId == INTERNAL_CLIENT_ID){
					$arrDetails[]=$mediaclDetail['url'];
				}
				$arrMedialserviceSheet[] =$arrDetails;
			}
					
			$arrStatsFacts =  $this->organization->getOrgStatsFacts($id);
			foreach($arrStatsFacts as $key=>$statfactDetail){
				$arrStatDetails =array();
				$arrStatDetails[] = $statfactDetail['cin_num'];
				$arrStatDetails[] = $statfactDetail['name'];
				$arrStatDetails[] = $statfactDetail['no_of_beds'];
				$arrStatDetails[] = $statfactDetail['inpatient'];
			
				$arrStatDetails[] = $statfactDetail['births'];
				$arrStatDetails[] = $statfactDetail['outpatient'];
				$arrStatDetails[] = $statfactDetail['emergency_department'];
				$arrStatDetails[] = $statfactDetail['no_of_surgeries'];
				if($clientId == INTERNAL_CLIENT_ID){
					$arrStatDetails[] = $statfactDetail['link1'];
					$arrStatDetails[] = $statfactDetail['link2'];
				}
				$arrStatFactSheet[] =$arrStatDetails;
			}
			
			$subOrgDetails			= $this->organization->getSubOrg($id);
			foreach($subOrgDetails as $key=>$orgDetail){
				$arrSubOrgDetails =array();
				$arrSubOrgDetails[] = $orgDetail['cin_num'];
				$arrSubOrgDetails[] = $orgDetail['name'];
				$arrSubOrgDetails[] = $orgDetail['sub_org'];
				$arrSubOrgDetails[] = $orgDetail['address'];
				$arrSubOrgDetails[] = $orgDetail['city'];
				$arrSubOrgDetails[] = $orgDetail['postal_code'];
				$arrSubOrgDetails[] = $orgDetail['region'];
				$arrSubOrgDetails[] = $orgDetail['country'];
				$arrSubOrgDetails[] = $orgDetail['phone'];
				$arrSubOrgDetails[] = $orgDetail['npi_num'];
				if($clientId == INTERNAL_CLIENT_ID){
					$arrSubOrgDetails[] = $orgDetail['url'];
				}
				$arrSubOrgSheet[] =$arrSubOrgDetails;
			}
			$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
			$arrAssocitedPeople = $this->organization->listOrgAssociatedPpl($id);
			//pr($arrAssocitedPeople);
			foreach($arrAssocitedPeople as $key=>$kolDetail){
				$arrKolDetails =array();
				$arrKolDetails[]=$kolDetail['cin_num'];
				$arrKolDetails[]=$kolDetail['name'];
				$arrKolDetails[]=$arrSalutations[$kolDetail['salutation']]." ".$kolDetail['first_name']." ".$kolDetail['middle_name']." ".$kolDetail['last_name'];
				$arrKolDetails[]=$kolDetail['specialty'];
				$arrKolDetails[]=$kolDetail['country'];
				$arrKolDetails[]=$kolDetail['phone'];
				$arrKolDetails[]=$kolDetail['email'];
				$arrAssocitedPeopleSheet[] =$arrKolDetails;
			}
		
			$arrPubDetails = $this->pubmed_org->listOrgPublicationDetails($id,null);
		
			foreach($arrPubDetails as $pubDetail){
				$arrPub =array();
				$arrPub[] = $pubDetail['cin_num'];
				$arrPub[] = $pubDetail['orgName'];
			
				$arrPub[] = $pubDetail['article_title'];
				$arrPub[] = $pubDetail['pmid'];
				$arrPub[] = $pubDetail['jname'];
				$arrPub[] = $this->organization->convertDateToMM_DD_YYYY($pubDetail['created_date']);
				$arrPub[]			= $this->get_pub_authors($pubDetail['id']);
				$arrPublicationsSheet[] = $arrPub;
			}
						    
			
				  
			$arrClinicalTrialsResults = $this->clinical_trial_org->listClinicalTrialsDetails($id);
			//pr($arrClinicalTrialsResults);
			foreach($arrClinicalTrialsResults as $arrClinicalTrialsResult){
				$arrClinicalTrial = array();
		      					    
				$arrClinicalTrial[]	= $arrClinicalTrialsResult['cin_num'];
				$arrClinicalTrial[]	= $arrClinicalTrialsResult['name'];
				$arrClinicalTrial[] = $arrClinicalTrialsResult['ct_id'];
				$arrClinicalTrial[]	= $arrClinicalTrialsResult['study_type'];
				$arrClinicalTrial[]	= $arrClinicalTrialsResult['trial_name'];
				$arrClinicalTrial[]	= $arrClinicalTrialsResult['condition'];
				$arrClinicalTrial[]	= $this->get_interventions($arrClinicalTrialsResult['id']);
				$arrClinicalTrial[]	= $arrClinicalTrialsResult['phase'];
				$arrClinicalTrial[]	= $arrClinicalTrialsResult['no_of_enrollees'];
				$arrClinicalTrial[]	= $arrClinicalTrialsResult['no_of_trial_sites'];
				$arrClinicalTrial[]	= $this->get_sponsers($arrClinicalTrialsResult['id']);
				$arrClinicalTrial[]	= $this->clinical_trial->getStatusNameById($arrClinicalTrialsResult['status_id']);
				$arrClinicalTrial[]	= $arrClinicalTrialsResult['start_date'];
				$arrClinicalTrial[]	= $arrClinicalTrialsResult['end_date'];
				$arrClinicalTrial[]	= $arrClinicalTrialsResult['min_age'];
				$arrClinicalTrial[]	= $arrClinicalTrialsResult['max_age'];
				$arrClinicalTrial[]	= $arrClinicalTrialsResult['gender'];
				$arrClinicalTrial[]	= $this->get_investigators($arrClinicalTrialsResult['id']);
				$arrClinicalTrial[]	= $arrClinicalTrialsResult['collaborator'];
				$arrClinicalTrial[]	= $arrClinicalTrialsResult['purpose'];
				$arrClinicalTrial[]	= $arrClinicalTrialsResult['official_title'];
				$arrKeywordsData	= '';
				$separator			= '';
				foreach($this->clinical_trial->listCTIKeyWords($arrClinicalTrialsResult['id']) as $key=>$row){
					$arrKeywordsData	.=	$separator.$row['name'];
					$separator	= ',';
				}
				$arrClinicalTrial[]		= $arrKeywordsData;
				$arrMeshtermsData	= '';
				$separator			= '';
				foreach($this->clinical_trial->listCTMeshTerms($arrClinicalTrialsResult['id']) as $key=>$row){
					$arrMeshtermsData	.=	$separator.$row['term_name'];
					$separator	= ',';
				}
				$arrClinicalTrial[]		= $arrMeshtermsData;
				$arrClinicalTrial[]			= $arrClinicalTrialsResult['link'];
				$arrTrialSheet[]				= $arrClinicalTrial;
				}
				
				}
				
			//pr($arrTrialSheet);
				
		$workbook = new Spreadsheet_Excel_Writer();
		$workbook->setVersion(8);
		$format_und =& $workbook->addFormat();
		$format_und->setBottom(2);//thick
		$format_und->setBold();
		$format_und->setColor('black');
		$format_und->setFontFamily('Calibri');
		$format_und->setAlign('center');
		$format_und->setSize(11);
			
		$format_reg =& $workbook->addFormat();
		$format_reg->setColor('black');
		$format_reg->setFontFamily('Calibri');
		$format_reg->setSize(11);
		
		$arr = array(
				      'COMPANY OVERVIEW'	=> $arrOrganizationDetailSheet,
				      'ADDRESS'     		=> $arrOrgAddressSheet,
					  'MEDICAL SERVICES' 	=> $arrMedialserviceSheet,
					  'AFFILIATES & PARTNERSHIPS'   =>$arrSubOrgSheet,
		 				'SOCIAL MEDIA'   	 	=> $arrSocialMediaDetailsSheet,
		  			  'KEY PEOPLE'   =>$arrkeyPeoplesSheet,
			 		  'ASSOCIATED PEOPLE'   =>$arrAssocitedPeopleSheet,
			 		  'FACTS'   =>$arrStatFactSheet,
					  'PUBLICATION'	=> $arrPublicationsSheet,
					  'TRIAL'	=> $arrTrialSheet
			 
		);
			
		foreach($arr as $wbname=>$rows)
			    {

			$rowcount = count($rows);
			$colcount = count($rows[0]);
				
			$worksheet =& $workbook->addWorksheet($wbname);
			//Setting the column width for 'COMPANY OVERVIEW' Sheet
			if($wbname=='COMPANY OVERVIEW'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,50.00);
				$worksheet->setColumn(2,2, 20.00);
				$worksheet->setColumn(3,4, 25.00);
				$worksheet->setColumn(5,7, 60.00);
				$worksheet->setColumn(8,9, 30.00);
				$worksheet->setColumn(10,10, 50.00);

			            }
			//Setting the column width for 'SOCIAL MEDIA' Sheet
			if($wbname=='SOCIAL MEDIA'){
				$worksheet->setColumn(1,1,50.00);
				$worksheet->setColumn(2,3, 35.00);
				$worksheet->setColumn(4,5,60.00);
				$worksheet->setColumn(5,6,50.00);
					
            }
			//Setting the column width for 'KEY PEOPLE' Sheet
			if($wbname=='ADDRESS'){

				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,50.00);
				$worksheet->setColumn(2,2, 30.00);
				$worksheet->setColumn(3,3,15.00);
				$worksheet->setColumn(4,6,20.00);
				$worksheet->setColumn(7,7,20.00);
				$worksheet->setColumn(8,8,20.00);
				$worksheet->setColumn(9,9,40.00);
			        }
			if($wbname=='MEDICAL SERVICES'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,50.00);
				$worksheet->setColumn(2,2, 50.00);
			    }

			if($wbname=='Other Locations'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,3,50.00);
				$worksheet->setColumn(4,8, 30.00);
				$worksheet->setColumn(9,9, 70.00);
					
			}
			if($wbname=='FACTS'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,40.00);
				$worksheet->setColumn(2,8, 17.00);
				$worksheet->setColumn(9,10, 60.00);
			
	}	
			if($wbname=='AFFILIATES & PARTNERSHIPS'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,40.00);
				$worksheet->setColumn(2,2, 40.00);
				$worksheet->setColumn(3,3, 50.00);
				$worksheet->setColumn(4,8, 30.00);
				$worksheet->setColumn(9,9, 70.00);
			}
	
			if($wbname=='ASSOCIATED PEOPLE'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,40.00);
				$worksheet->setColumn(2,2, 30.00);
				$worksheet->setColumn(3,6, 20.00);
							
						}
												
			if($wbname=='KEY PEOPLE'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,50.00);
				$worksheet->setColumn(2,2, 30.00);
				$worksheet->setColumn(3,3,20.00);
				$worksheet->setColumn(4,6,30.00);
				$worksheet->setColumn(7,7,70.00);
				$worksheet->setColumn(8,8,40.00);
					}
				
			if($wbname=='PUBLICATION'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,50.00);
				$worksheet->setColumn(2,2, 50.00);
				$worksheet->setColumn(3,3,15.00);
				$worksheet->setColumn(4,4,50.00);
				$worksheet->setColumn(5,5,10.00);
				$worksheet->setColumn(6,6,50.00);
					}
				
			if($wbname=='TRIAL'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,40.00);
				$worksheet->setColumn(2,2, 20.00);
				$worksheet->setColumn(3,3,20.00);
				$worksheet->setColumn(4,4,45.00);
				$worksheet->setColumn(5,5,25.00);
				$worksheet->setColumn(6,6,30.00);
				$worksheet->setColumn(7,7,15.00);
				$worksheet->setColumn(8,9,25.00);
				$worksheet->setColumn(10,10,25.00);
				$worksheet->setColumn(11,16,20.00);
				$worksheet->setColumn(17,18,30.00);
				$worksheet->setColumn(19,24,30.00);
			}
							
			for( $j=0; $j<$rowcount; $j++ )
			{
				for($i=0; $i<$colcount;$i++)
				{
					$fmt  =& $format_reg;
					if ($j==0){
						$fmt =& $format_und;
					}
					if (isset($rows[$j][$i]))
					{
						//    $data[]=$rows[$j][$i];
						/*    if($wbname=='ADDRESS'){
						 $wrapFmt=& $format_reg;
						 $wrapFmt->setTextWrap(true);
						 $worksheet->write($j, $i, $data, $wrapFmt);
							}else
							*/
						//   pr($rows[$j][$i]);
						$worksheet->writeString($j, $i, utf8_decode($rows[$j][$i]), $fmt);
					}
				}
						}
					}
		//pr($data);
		//		exit();
		//for downloading the file
		$workbook->send('organizations.xls');
		$workbook->close();
				
	}
			
	function get_pub_authors($pubId){
		$authNames 			= '';
		$arrAuthors			= $this->pubmed->listPublicationAuthors($pubId);
		foreach($arrAuthors as $author){
			$authName		= $author['last_name']." ".$author['initials'];
			if($authNames==''){
				$authNames	= $authName;
			} else{
				$authNames=$authNames.",".$authName;
			}
		}
		return $authNames;
				}
					
	/**
	 * get the sponsers data of clinical trial
	 * @author 	Vinayak
	 * @since	1.0.11
	 * @created 4 appr 2013
	 * @return $sponsersNames
	 */
	function get_sponsers($ctId){
		$sponsersNames			= '';
		$arrSponsers			= $this->clinical_trial->listCTSponsors($ctId);
		foreach($arrSponsers as $sponser){
			$sponserName		= $sponser['agency'];
			if($sponsersNames==''){
				$sponsersNames	= $sponserName;
			}else{
				$sponsersNames	= $sponsersNames.";".$sponserName;
			}
		}
		return $sponsersNames;
	}
			
	/**
	 * get the interventions data of clinical trial
	 * @author 	Vinayak
	 * @since	1.0.11
	 * @created 4 appr 2013
	 * @return $sponsersNames
	 */
	function get_interventions($ctId){
		$interventionsNames			= '';
		$arrInterventions			= $this->clinical_trial->listCTInterventions($ctId);
		foreach($arrInterventions as $intervention){
			$interventionName		= $intervention['name'];
			if($interventionsNames==''){
				$interventionsNames	= $interventionName;
			}else{
				$interventionsNames	= $interventionsNames.";".$interventionName;
			}
		}
		return $interventionsNames;
	}
			
	/**
	 * get the investigators data of clinical trial
	 * @author 	Vinayak
	 * @since	1.0.11
	 * @created 4 appr 2013
	 * @return $sponsersNames
	 */
	function get_investigators($ctId){
		$investigatorsNames			= '';
		$arrInvestigators			= $this->clinical_trial->listCTInvestigators($ctId);
		foreach($arrInvestigators as $investigator){
			$investigatorName		= $investigator['last_name'];
			if($investigatorsNames==''){
				$investigatorsNames	= $investigatorName;
			}else{
				$investigatorsNames	= $investigatorsNames.";".$investigatorName;
			}
		}
		return $investigatorsNames;
	}
		
	/**
	 * preparing the Organizations data required for Excel
	 * @author 	Vinayak
	 * @since	3.1
	 * @return JSON
	 * @created  6-9-2011
	 */
	function org_export1($orgIds){
		$this->load->plugin('phpxls/writer');
		
			
		$arrOrganizationDetail12=array();
		$arrkeyPeoplesSheet=array();
		foreach($orgIds as $id){
			//Getting the Organizations Details
			$arrOrganizationDetail = $this->organization->getOrgDetails($id);
			//Preparing the Array For Exporting
			foreach($arrOrganizationDetail as $key=>$orgValue){
				$arrOrganizationDetail1=array();
				foreach($orgValue as $arrOrganizationDetails){
					$arrOrganizationDetail1[]=$arrOrganizationDetails;
			
				}
			
			}
			$arrOrganizationDetailSheet[0]=array('CIN NUM','COMPANY NAME','COMPANY TYPE','WEBSITE','COMPANY HEADQUARTERS','COMPANY BACKGROUND','MISSION, VISION & VALUES','KEY PRODUCTS & SERVICES');
			$arrOrganizationDetailSheet[] = $arrOrganizationDetail1;
		
			//Getting the Organizations Social Media Details
			$orgSocialMediaDetails = $this->organization->getSocialMediaDetailsOfOrg($id);
			//Preparing the Array For Exporting
			foreach($orgSocialMediaDetails as $key=>$orgDetails){
				$arrSocialMediaDetails = array();
				foreach($orgDetails as $row){
					$arrSocialMediaDetails[]=$row;
				}
				$arrSocialMediaDetailsSheet[0] = array('CIN NUM','COMPANY NAME','BLOG','YOUTUBE','LINKEDIN','FACEBOOK','TWITTER');
				$arrSocialMediaDetailsSheet[]=$arrSocialMediaDetails;
			     
			}
			
			//Getting the Organizations KeyPeople  Details
			$orgkeyPeoples = $this->organization->getKeyPeopleDetailsOfOrg($id);
			if(!(empty($orgkeyPeoples))){
				//Preparing the Array For Exporting
				foreach($orgkeyPeoples as $key=>$orgDetails){
					$arrkeyPeoples =array();
					foreach($orgDetails as $row){
						$arrkeyPeoples[]=$row;
						    
					}
					$arrkeyPeoplesSheet[0] = array('CIN NUM','COMPANY','ROLE','SALUTATION','FIRST NAME','MIDDLE NAME','LAST NAME','TITLE','EMAIL');
					$arrkeyPeoplesSheet[]=$arrkeyPeoples;
				}
			}else{
			
				$arrkeyPeoplesSheet[0] = array('CIN NUM','COMPANY','ROLE','SALUTATION','FIRST NAME','MIDDLE NAME','LAST NAME','TITLE','EMAIL');
				}
		      					    
			$orgAdress = $this->organization->getAdreessOfOrg($id);
			foreach($orgAdress as $key=>$orgDetails){
				$arrOrgAddress = array();
				foreach($orgDetails as $row){
					$arrOrgAddress[]=$row;
				}
				$arrOrgAddressSheet[0] = array('CIN NUM','COMPANY','ADDRESS','CITY','POSTAL CODE','STATE','COUNTRY','PHONE','FAX','ADDITIONAL');
				$arrAdditionalContacts=$this->organization->getaddtionalContcat($id);
				//pr($arrAdditionalContacts);
				$phoneDetails='';
				$phoneDetails=implode("\n",$arrAdditionalContacts);
				$arrOrgAddress[]=$phoneDetails;
				$arrOrgAddressSheet[]=$arrOrgAddress;
				}
				
				
				}
			 
			
		$workbook = new Spreadsheet_Excel_Writer();

		$format_und =& $workbook->addFormat();
		$format_und->setBottom(2);//thick
		$format_und->setBold();
		$format_und->setColor('black');
		$format_und->setFontFamily('Calibri');
			
		$format_und->setSize(8);
			          
		$format_reg =& $workbook->addFormat();
		$format_reg->setColor('black');
		$format_reg->setFontFamily('Arial');
		                    
			
		$arr = array(
			      'COMPANY OVERVIEW'=>$arrOrganizationDetailSheet,
			      'ADDRESS'     =>$arrOrgAddressSheet,
			      'SOCIAL MEDIA'   =>$arrSocialMediaDetailsSheet,
				  'KEY PEOPLE'     =>$arrkeyPeoplesSheet
			
		);
	
		foreach($arr as $wbname=>$rows)
		{
			
			$rowcount = count($rows);
			$colcount = count($rows[0]);
	
			$worksheet =& $workbook->addWorksheet($wbname);
			//Setting the column width for 'COMPANY OVERVIEW' Sheet
			if($wbname=='COMPANY OVERVIEW'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,50.00);
				$worksheet->setColumn(2,2, 20.00);
		
				$worksheet->setColumn(3,4, 25.00);
				$worksheet->setColumn(5,7, 60.00);
		
			}
			//Setting the column width for 'SOCIAL MEDIA' Sheet
			if($wbname=='SOCIAL MEDIA'){
				$worksheet->setColumn(1,1,50.00);
				$worksheet->setColumn(2,3, 35.00);
				$worksheet->setColumn(4,5,60.00);
				$worksheet->setColumn(5,6,50.00);
		
			}
			//Setting the column width for 'KEY PEOPLE' Sheet
			if($wbname=='ADDRESS'){
		
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,50.00);
				$worksheet->setColumn(2,2, 30.00);
				$worksheet->setColumn(3,3,15.00);
				$worksheet->setColumn(4,6,20.00);
				$worksheet->setColumn(7,7,20.00);
				$worksheet->setColumn(8,8,20.00);
				$worksheet->setColumn(9,9,40.00);
			}

			if($wbname=='KEY PEOPLE'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,50.00);
				$worksheet->setColumn(2,2, 30.00);
				$worksheet->setColumn(3,3,20.00);
				$worksheet->setColumn(4,6,30.00);
				$worksheet->setColumn(7,7,70.00);
				$worksheet->setColumn(8,8,40.00);
			}


			for( $j=0; $j<$rowcount; $j++ )
			{
				for($i=0; $i<$colcount;$i++)
				{
					$fmt  =& $format_reg;
				
					if ($j==0){
						$fmt =& $format_und;
					
						    		 }
					if (isset($rows[$j][$i]))
					{
						$data=$rows[$j][$i];
						if($wbname=='ADDRESS'){
							$wrapFmt=& $format_reg;
							$wrapFmt->setTextWrap(true);
							$worksheet->write($j, $i, $data, $wrapFmt);
						}else
						$worksheet->write($j, $i, $data, $fmt);
							    }
						    		}
								        }
							        }		
							       		        
		//for downloading the file
		$workbook->send('organizations.xls');
		$workbook->close();
			
						    	}
							
	function update_org_status(){
		$arr['status'] = $this->input->post('status');
		$arr['orgIds'] = $this->input->post('orgIds');
		if($this->organization->updateOrgStatus($arr)){
			
//			$arr['modified_by'] =$this->loggedUserId;
//			$status = 100;
			if($arr['status']==COMPLETED)
				$status = STATUS_COMPLETED;
			if($arr['status'] == PROFILING)
				$status = STATUS_PROFILING;
			if($arr['status'] == REQUESTED)
				$status = STATUS_REQUESTED;
			if($arr['status'] == New1)
				$status = STATUS_NEW;
			
			foreach($arr['orgIds'] as $orgId){
				$this->update->insertUpdateEntry(ORG_STATUS_UPDATE,$status, MODULE_ORG_REQUEST, $orgId,$status);
			}
			
			$data['status'] = true;
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}

	/**
	 * Parsing the orga data anr sending data to model to save
	 * @author 	Vinayak
	 * @since	1.0.11
	 * @created  7 appr 2013
	 */
	function import_org_profiles_otsuka_xls(){
		// Increasing the max execution time to pasrse all sheet data
		ini_set("max_execution_time",7200);
		$arrCountries	=$this->Country_helper->listCountries();
		$arrStates		=$this->Country_helper->listStates();
		$arrCities		=$this->Country_helper->listCities();
		$arrKeyPeopleRoles=$this->organization->getAllKeyPeopleRoles();
		$organizationTypes=$this->organization->getAllOrganizationTypes();
											
		// Load the plugin
		$this->load->plugin('excelReader/reader2');
		$userId		=$this->session->userdata('user_id');
		$clientId	=$this->session->userdata('client_id');
		$orgID		= 0;
		$target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_profiles/";
		$overviewFileName	= random_string('unique', 20);
		$path_info = pathinfo($_FILES["overview_import"]['name']);
		$overview_file_target_path = $target_path . $overviewFileName . "." . $path_info['extension'];
		if($_FILES["overview_import"]['name']!=null){
			if($path_info['extension']=='xls'){
				if(move_uploaded_file($_FILES['overview_import']['tmp_name'], $overview_file_target_path)) {
					$reader				=	new Spreadsheet_Excel_Reader($overview_file_target_path, true, 'utf-8');
					//loop through each sheet
					foreach($reader->sheets as $k=>$details){
						//Parsing of 1st sheet  - Overview: $k = index of the sheet
						if($k==0){
							$numColumns=0;
							$existingOrgs=array();
							$row=1;
							foreach($details['cells'] as $data){
								if($row==1){
									//condition to check whether format of the column is correct or not
									if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="COMPANY TYPE" || trim($data[4])!="LOGO" || trim($data[5])!="WEBSITE"
										|| trim($data[6])!="COMPANY HEADQUARTERS" || trim($data[7])!="COMPANY BACKGROUND" || trim($data[8])!="MISSION, VISION & VALUES"  ||trim($data[9])!="FOUNDED" || trim($data[10])!="NPI NUMBER"){
										$arrImportStatusMsg['overview']['incorrect_format']='Uploaded File format is incorrect';
										break;
								 	}
								$numColumns=sizeof($data);
								}
								$organizationDetails=array();
								if($row>1){
									for($i=1;$i<=$numColumns;$i++){
										if(!isset($data[$i]))
										$data[$i]="";
									}
									$organizationDetails['cin_num']=trim($data[1]);
									$organizationDetails['name']=ucwords(trim($data[2]));
									$orgType=array_search(trim($data[3]),$organizationTypes);
									$organizationDetails['type_id']=$orgType;
									$organizationDetails['company_logo']=trim($data[4]);
									$organizationDetails['website']=trim($data[5]);
									$organizationDetails['headquarters']=trim($data[6]);
									$organizationDetails['background']=trim($data[7]);
									$organizationDetails['mission_vision']=trim($data[8]);
									$organizationDetails['founded']=trim($data[9]);
									$organizationDetails['npi_num']=trim($data[10]);
									$organizationDetails['profile_type'] = FULL;
									$profilType = trim($data[11]);
									if($profilType=='Basic'){
										$organizationDetails['profile_type'] =BASIC;
									}
									if($profilType=='Full Profile'){
										$organizationDetails['profile_type'] =FULL;
									}
									$organizationDetails['url']=trim($data[12]);
									$organizationDetails['status']=New1;
									$organizationDetails['created_by']	=$userId;
									$organizationDetails['created_on']	=date("Y-m-d H:i:s");
									//Save only if the 'cin_num' is not blank
									if($organizationDetails['cin_num']!=""){
										$id=$this->organization->saveOrganization($organizationDetails);
										//  echo $this->db->last_query();
										if($id==false){
											//array of already existing organizations
											$existingOrgs[]=$organizationDetails['name'].' has been updated';
										}else{
											$orgID	= $id;
										}
									}else{
										//aray of organizations having no 'cin_num'
										$arrImportStatusMsg['overview']['no_cin_num'][]= $organizationDetails['name'];
									}

								}
								$row++;
								$arrImportStatusMsg['overview']['success']=true;
							}
							$arrImportStatusMsg['overview']['existingOrgs']=$existingOrgs;
						}
					 
					 	else if($k==1){
					 		//Parsing of 2st sheet  - Adress: $k = index of the sheet
					 		$numColumns=0;
					 		$row=1;
						    foreach ($details['cells'] as $data) {
						    	//check wherether format is correct or not
						    	if($row==1){
						    		if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="ADDRESS" || trim($data[4])!="CITY" || trim($data[5])!="POSTAL CODE"
						    		 || trim($data[6])!="STATE" || trim($data[7])!="COUNTRY" || trim($data[8])!="PHONE" || trim($data[9])!="FAX" || trim($data[10])!="ADDITIONAL PHONE NUMBERS"){
						    		 	$arrImportStatusMsg['address']['incorrect_format']='Uploaded File format is incorrect';
						    		 	break;
						    		 }
						    		 $numColumns=sizeof($data);
						    	}
						    	$organizationDetails=array();
						    	if($row>1){
						    		for($i=1;$i<=$numColumns;$i++){
						    			if(!isset($data[$i]))
						    				$data[$i]="";
						    		}
						    		$countryId=0;
						    		$stateId=0;
						    		$cityId=0;
							        $organizationDetails['cin_num']=trim($data[1]);
							        $organizationDetails['name']=trim($data[2]);
							        $organizationDetails['address']=trim($data[3]);
									/*
							        if(array_key_exists(ucwords(trim($data[4])),$arrCities))
							        	$cityId=$arrCities[ucwords(trim($data[4]))]['city_id'];
									$organizationDetails['city_id']=$cityId;*/
									
							        $organizationDetails['postal_code']=trim($data[5]);
							        if(array_key_exists(ucwords(trim($data[6])),$arrStates))
							        	$stateId=$arrStates[ucwords(trim($data[6]))]['state_id'];
							        $organizationDetails['state_id']=$stateId;
									
									$city					= ucwords(trim($data[4]));
									if($city!=''){
									 $organizationDetails['city_id']= $this->kol->getCityIdByState($city,$stateId);
									}
									
									
							        if(array_key_exists(ucwords(trim($data[7])),$arrCountries))
							        	$countryId=$arrCountries[ucwords(trim($data[7]))]['country_id'];
							        $organizationDetails['country_id']=$countryId;
							        $organizationDetails['phone']=trim($data[8]);
							        $organizationDetails['fax']=trim($data[9]);
							        
							        $faxDetails=explode(" ",$organizationDetails['fax']);
							        $arrFaxValues=array();
							        $faxNumber="";
							        foreach($faxDetails as $value){
							        	if(strpos($value, "+")!=false){
							        		$faxNumber.=trim($value);
							        	}
							        	if(is_numeric($value)){
							        		$faxNumber.=trim($value);
							        	}
							        }
									$organizationDetails['addr_url']=trim($data[11]);
									$organizationDetails['created_by']	=$userId;
							        $organizationDetails['created_on']	=date("Y-m-d H:i:s");
							        
							        //Save only if the 'cin_num' is not blank
							        if($organizationDetails['cin_num']!=""){
							        	$orgID =$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
							        	if($orgID>0){
							        		$organizationDetails['id']	= $orgID;
							        	}
								        $id=$this->organization->updateImportedOrganization($organizationDetails);
								        if($id==false){
								        	//array of 'cin_num' not present in database
								        	$arrImportStatusMsg['address']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
								        }
							        }else{
							        	//aray of organizations  having no 'cin_num'
							        	$arrImportStatusMsg['address']['no_cin_num'][]= $organizationDetails['name'];
							        }		
							        
							        //Parsing and saving additional contact details
							        if($organizationDetails['cin_num']!=""){
							        	$arrContactDetails=array();
								        $orgId=$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
								        $aditionalContats=trim($data[10]);
								        $arrAditionalContactDetails=explode("\n",$aditionalContats);
								        foreach($arrAditionalContactDetails as $aditionalContat){
								        	$contactDetails=array();
								        	$phNumber="";
								        	$relatedTo="";
								        	if(strpos($aditionalContat, "-")!=false){
								        		$aditionalContatDetails=explode("-",$aditionalContat);
								        		 foreach($aditionalContatDetails as $value){
										        	if(strpos($value, "+")!=false){
										        		$phNumber.=trim($value);
										        	}else if(is_numeric($value)){
										        		$phNumber.=trim($value);
										        	}else {
										        		$relatedTo.=trim($value);
										        	}
										        }
								        	}else if(strpos($aditionalContat, ":")!=false){
												
												//echo $aditionalContat;
								        		$aditionalContatDetails=explode(":",$aditionalContat);
												$contactDetails['related_to']=$aditionalContatDetails[0];
												$contactDetails['phone']=$aditionalContatDetails[1];
								        	}else{
								        		$aditionalContatDetails=explode(" ",$aditionalContat);
								        	}
								        	$arrContactDetails[]=$contactDetails;
								        }
								        if($orgId!=0){
								        	//save additional contact details
								        	foreach($arrContactDetails as $row){
								        		$row['org_id']=$orgId;
								        		$row['created_by']	=$userId;
							        			$row['created_on']	=date("Y-m-d H:i:s");
							        			$this->organization->saveContact($row);
								        	}
								        }else{
								        	//set error details
								        }
							        }
						    	}
						    	$row++;					    	
						    	$arrImportStatusMsg['address']['success']=true;
						    }
					 	}
					 	else if($k==2){
					 		$medicalService =1;
					 		//Parsing of 3st sheet  - Mediacal Services: $k = index of the sheet
					 		$numColumns=0;
					 		$row=1;
					 	
							foreach($details['cells'] as $key=>$data) {
						    if($row==1){
									if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!='MEDICAL SERVICES' || trim($data[4])!='URL'){
										$arrImportStatusMsg['mediacal_services']['incorrect_format']='Uploaded File format is incorrect';
						    		 	break;
						    		 }
						    		 $numColumns=sizeof($data);
						    	}
								$medicalServiceDataDetails=array();
						    	if($row>1){
						    		for($i=1;$i<=$numColumns;$i++){
						    			if(!isset($data[$i]))
						    				$data[$i]="";
						    		}
									$cinNum  = trim($data[1]);
									$orgName =ucwords(trim($data[2]));
							        
									$medicalServiceName=trim($data[3]);
									$medicalServiceDataDetails['url'] = trim($data[4]);
									if($medicalServiceName!=''){
										$medicalServiceDataDetails['medical_service_id'] = $this->organization->saveOrgMedicalService($medicalServiceName);
							        
									}
							        //Save only if the 'cin_num' is not blank
									if($cinNum!=""){
										$orgID	= $this->organization->getOrgIdBySinNumber($cinNum);
										$medicalServiceDataDetails['org_id'] =$orgID;
										if($orgID==0){
								        	//array of 'cin_num' not present in database
											$arrImportStatusMsg['mediacal_services']['no_matching_cin_num'][]= $cinNum;
							        }else{
							        		if($medicalService ==1){
							        			$this->organization->deleteMedicalService($orgID);
							        			$medicalService++;
							        		}
											$this->organization->saveOrgMediacalAssociation($medicalServiceDataDetails);
											//echo $this->db->last_query();
										}
									}else{
							        	//aray of address detains having no 'cin_num'
										$arrImportStatusMsg['mediacal_services']['no_cin_num'][]= $orgName;
							        }		
							       		        
						    	}
						    	$row++;
								$arrImportStatusMsg['mediacal_services']['success']=true;
						    }
					 	}
					 	else if($k==3){
					 		//Parsing of 3st sheet  - Affiliate patnership: $k = index of the sheet
					 		$numColumns=0;
					 		$row=1;
							foreach($details['cells'] as $key=>$data) {
						    if($row==1){
									if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!='INSTITUTE NAME'
									|| trim($data[4])!='ADDRESS' || trim($data[5])!='CITY' || trim($data[6])!='POSTAL CODE'
									|| trim($data[7])!='STATE'|| trim($data[8])!='COUNTRY'|| trim($data[9])!='PHONE' ||   trim($data[10])!='NPI NUMBER'
									){
										$arrImportStatusMsg['affiliate_patnership']['incorrect_format']='Uploaded File format is incorrect';
						    		 	break;
						    		 }
						    		 $numColumns=sizeof($data);
						    	}
								$otherLoactionDetails=array();
						    	if($row>1){
						    		for($i=1;$i<=$numColumns;$i++){
						    			if(!isset($data[$i]))
						    				$data[$i]="";
						    		}
									$cinNum  = trim($data[1]);
									$orgName =ucwords(trim($data[2]));
									$subOrgName = ucwords(trim($data[3]));
									$otherLoactionDetails['address'] = trim($data[4]);
									/*if(array_key_exists(ucwords(trim($data[5])),$arrCities))
									$cityId=$arrCities[ucwords(trim($data[5]))]['city_id'];
									$otherLoactionDetails['city_id']=$cityId;*/
									$otherLoactionDetails['postal_code']=trim($data[6]);
									if(array_key_exists(ucwords(trim($data[7])),$arrStates))
									$stateId=$arrStates[ucwords(trim($data[7]))]['state_id'];
									$otherLoactionDetails['state_id']=$stateId;
									
									$city					= ucwords(trim($data[5]));
									if($city!=''){
									 $otherLoactionDetails['city_id']= $this->kol->getCityIdByState($city,$stateId);
									}
									
									
									if(array_key_exists(ucwords(trim($data[8])),$arrCountries))
									$countryId=$arrCountries[ucwords(trim($data[8]))]['country_id'];
									$otherLoactionDetails['country_id']=$countryId;
							        
									$otherLoactionDetails['phone']=$data[9];
									$otherLoactionDetails['npi_num']=$data[10];
									$otherLoactionDetails['url']=$data[11];
							        
									if($cinNum!=''){
										$otherLoactionDetails['org_id'] =$this->organization->getOrgIdBySinNumber($cinNum);
										if($otherLoactionDetails['org_id']!=0){
											//echo $this->db->last_query();
											$orgDetails['name'] = $subOrgName;
											$orgDetails['address'] = $otherLoactionDetails['address'];
											$orgDetails['city_id']=$otherLoactionDetails['city_id'];
											$orgDetails['state_id']=$otherLoactionDetails['state_id'];
											$orgDetails['country_id']=$otherLoactionDetails['country_id'];
											$orgDetails['postal_code']=$otherLoactionDetails['postal_code'];
											$orgDetails['status'] ='new';
											$orgDetails['created_by']	=$userId;
											$orgDetails['created_on']	=date("Y-m-d H:i:s");
											$otherLoactionDetails['sub_org_id'] = $this->organization->getOrgId($orgDetails);
										
											$this->organization->saveAffiliatesPartnerships($otherLoactionDetails);
										}else{
												
											$arrImportStatusMsg['affiliate_patnership']['no_matching_cin_num'][]= $cinNum;
										}
									}else{
										//aray of address detains having no 'cin_num'
										$arrImportStatusMsg['affiliate_patnership']['no_cin_num'][]=$orgName;
									}
								}
								$row++;
								$arrImportStatusMsg['other_locations']['success']=true;
							}
						}
							
					 else if($k==4){
					 	//Parsing of 3st sheet  - Social Media : $k = index of the sheet
					 	$numColumns=0;
					 	$row=1;
					 	foreach($details['cells'] as $data) {
					 		if($row==1){
					 			if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="BLOG" || trim($data[4])!="YOUTUBE" || trim($data[5])!="LINKEDIN"
					 			|| trim($data[6])!="FACEBOOK" || trim($data[7])!="TWITTER" ){
					 				$arrImportStatusMsg['social_media']['incorrect_format']='Uploaded File format is incorrect';
					 				break;
					 			}
					 			$numColumns=sizeof($data);
					 		}
					 		$organizationDetails=array();
					 		if($row>1){
					 			for($i=1;$i<=$numColumns;$i++){
					 				if(!isset($data[$i]))
					 				$data[$i]="";
					 			}
					 			$organizationDetails['cin_num']=trim($data[1]);
					 			$organizationDetails['name']=ucwords(trim($data[2]));
					 			 
					 			$organizationDetails['blog']=trim($data[3]);
					 			$organizationDetails['youtube']=trim($data[4]);
					 			$organizationDetails['linkedin']=trim($data[5]);
					 			$organizationDetails['facebook']=trim($data[6]);
					 			//$organizationDetails['myspace']=trim($data[7]);
					 			$organizationDetails['twitter']=trim($data[7]);
					 			 
					 			$organizationDetails['created_by']	=$userId;
					 			$organizationDetails['created_on']	=date("Y-m-d H:i:s");
					 			 
					 			//Save only if the 'cin_num' is not blank
					 			if($organizationDetails['cin_num']!=""){
					 				$orgID	= $this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
					 				if($orgID>0){
					 					$organizationDetails['id']	= $orgID;
					 				}
					 				$id=$this->organization->updateImportedOrganization($organizationDetails);
					 				if($id==false){
					 					//array of 'cin_num' not present in database
					 					$arrImportStatusMsg['social_media']['no_matching_cin_num'][]= $organizationDetails['name'];
					 				}
					 			}else{
					 				//aray of address detains having no 'cin_num'
					 				$arrImportStatusMsg['social_media']['no_cin_num'][]= $organizationDetails['name'];
					 			}

					 		}
					 		$row++;
					 		$arrImportStatusMsg['social_media']['success']=true;
					 	}
					 }
					 else if($k==5){
					 	$kePeople=1;
						 	//Parsing of 4th sheet  -key_people: $k = index of the sheet
					 		$numColumns=0;
					 		$row=1;
							$arrSalutations	= array(''=>0,'Dr.' => 1, 'Prof.' => 2, 'Mr.' => 3, 'Ms.' =>4);
							foreach($details['cells'] as $data) {
								if($row==1){
									if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="ROLE" || trim($data[4])!="SALUTATION" || trim($data[5])!="FIRST NAME"
									|| trim($data[6])!="MIDDLE NAME" || trim($data[7])!="LAST NAME" || trim($data[8])!="DEPARTMENT/DIVISION/CENTER" || trim($data[9])!="TITLE" || trim($data[10])!="EMAIL" ){
										$arrImportStatusMsg['key_people']['incorrect_format']='Uploaded File format is incorrect';
										break;
									}
									$numColumns=sizeof($data);
								}
								$organizationDetails=array();
								if($row>1){
									for($i=1;$i<=$numColumns;$i++){
										if(!isset($data[$i]))
										$data[$i]="";
									}
									$organizationDetails['cin_num']=trim($data[1]);
									$organizationDetails['name']=ucwords(trim($data[2]));
									 
									$roleId=array_search(trim(strtolower($data[3])),array_map('strtolower',$arrKeyPeopleRoles));
									$keyPeopleDetails['role_id']=$roleId;
									$keyPeopleDetails['salutation']=$arrSalutations[trim($data[4])];
									$keyPeopleDetails['first_name']=trim($data[5]);
									$keyPeopleDetails['middle_name']=trim($data[6]);
									$keyPeopleDetails['last_name']=trim($data[7]);
									$keyPeopleDetails['department']=trim($data[8]);
									$keyPeopleDetails['title']=trim($data[9]);
									$keyPeopleDetails['email']=trim($data[10]);
									$keyPeopleDetails['url']=trim($data[11]);
									 
									$keyPeopleDetails['created_by']	=$userId;
									$keyPeopleDetails['created_on']	=date("Y-m-d H:i:s");
									//Save only if the 'cin_num' is not blank
									if($organizationDetails['cin_num']!=""){
										$orgId=$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
										if($orgId==0){
											$orgId=$this->organization->getOrgIdByOrgName($organizationDetails['name']);
										}
										if($orgId!=0){
											$keyPeopleDetails['org_id']=$orgId;
											if($kePeople ==1){
											$this->organization->deleteKeyPeopleByOrgId($orgId);
											$kePeople++;
											}
											$this->organization->saveKeyPeople($keyPeopleDetails);
										}else{
											
							        		$arrImportStatusMsg['key_people']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
										}
									}else{
										//aray of address detains having no 'cin_num'
										$arrImportStatusMsg['key_people']['no_cin_num'][]= $organizationDetails['name'];
									}

								}
								$row++;
								$arrImportStatusMsg['key_people']['success']=true;
							}
					 }

					 else if($k==7){
					 		$fact=1;
				 			//Parsing of 7th sheet  - Stats Facts: $k = index of the sheet
							foreach($details['cells'] as $factKey=>$facts){
							 if($factKey==1){
							 	if(trim($facts[1])!="CIN NUM" || trim($facts[2])!="COMPANY NAME" || trim($facts[3])!="NO. OF BEDS"){
							 		$arrImportStatusMsg['stats_facts']['incorrect_format']='Uploaded File format is incorrect';
							 		break;
							 	}
							 	
							 	if(trim($facts[4])!="INPATIENT"  || trim($facts[5])!="BIRTHS" || trim($facts[6])!="OUTPATIENT"){
							 		$arrImportStatusMsg['stats_facts']['incorrect_format']='Uploaded File format is incorrect';
							 		break;
							 	}
							 	
							 	if( trim($facts[7])!="EMERGENCY DEPARTMENT" || trim($facts[8])!="NO. OF SURGERIES" ){
							 		$arrImportStatusMsg['stats_facts']['incorrect_format']='Uploaded File format is incorrect';
							 		break;
							 	}
							 	$numColumns=sizeof($facts);
							 }
								if($factKey!=1){
									$factDataDetails=array();
									$cinNum = $facts[1];

									$factDataDetails["no_of_beds"] 		= $facts[3];
									$factDataDetails["inpatient"]		= $facts[4];

									$factDataDetails["births"] 	 	    = $facts[5];
									$factDataDetails['outpatient']		= $facts[6];
									$factDataDetails["emergency_department"] 	  = $facts[7];
									$factDataDetails["no_of_surgeries"] 	  	  = $facts[8];
									$factDataDetails['link1'] = $facts[9];
									$factDataDetails['link2'] = $facts[10];
									if($cinNum!=''){
										$factDataDetails['org_id'] =$this->organization->getOrgIdBySinNumber($cinNum);
										if($factDataDetails['org_id']!=0){
											$this->organization->orgStatsFacats($factDataDetails);
											if($fact==1){
												$this->organization->deleteFacts($orgId);
												$fact++;
											}
												
										}else{
												
											$arrImportStatusMsg['stats_facts']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
										}
									}else{
										//aray of address detains having no 'cin_num'
										$arrImportStatusMsg['stats_facts']['no_cin_num'][]= $organizationDetails['name'];
									}
								}
								$arrImportStatusMsg['stats_facts']['success']=true;

							}
					 }
					 else if($k==8){
					 		//Parsing of 8th sheet  - Publication: $k = index of the sheet
							foreach($details['cells'] as $sub=>$orgPubData){
							 if($sub==1){
							 	if(trim($orgPubData[1])!="CIN NUM" || trim($orgPubData[2])!="COMPANY NAME" || trim($orgPubData[3])!="Article Title" ||  trim($orgPubData[4])!="PMID" || trim($orgPubData[5])!="Journal Name" || trim($orgPubData[6])!="Date" || trim($orgPubData[7])!="Authors" ){
							 		$arrImportStatusMsg['publication']['incorrect_format']='Uploaded File format is incorrect';
							 			break;
							 	}
							 	
							 	$numColumns=sizeof($data);
							 }
								if($sub!=1){
									$orgPubDetails=array();
									$cinNum = $orgPubData[1];
									$orgName =$orgPubData[2];
									$orgPubDetails['pmid'] = $orgPubData[4];
										
									if($cinNum!=""){
										$orgPubDetails['org_id'] =$this->organization->getOrgIdBySinNumber($cinNum);
										if($orgPubDetails['org_id'] ==0){
											//array of 'pin' not present in database
											$arrImportStatusMsg['publication']['no_matching_cin_num'][]= $cinNum;
										}else{
												
											$status = $this->pubmed_org->saveOrgPMID($orgPubDetails);
											if($status == false)
											$arrImportStatusMsg['publication']['pmid_exist'][]= $orgPubDetails['pmid'];

											$orgPubmedStatusData = array();
											$orgPubmedStatusData['id'] = $orgPubDetails['org_id'];
											$orgPubmedStatusData['is_pubmed_processed'] = 2;
											$this->pubmed_org->updatePubmedProcessedOrg($orgPubmedStatusData);
										}
									}else{
										//aray of media having no 'pin'
										$arrImportStatusMsg['publication']['no_pin_num'][]=  $orgName;
									}
								}
								$arrImportStatusMsg['publication']['success']=true;

							}

					 }
					 else if($k==9){
					 		//Parsing of 9th sheet  - Trial: $k = index of the sheet
							foreach($details['cells'] as $sub=>$orgClinicalData){
							 if($sub==1){
							 	if(trim($orgClinicalData[1])!="CIN NUM" || trim($orgClinicalData[2])!="COMPANY NAME" || trim($orgClinicalData[3])!="CTID" ||
									trim($orgClinicalData[4])!="Study Type" || trim($orgClinicalData[5])!="Trial Name" || 
									trim($orgClinicalData[6])!="Condition" || trim($orgClinicalData[7])!="Intervention" || 
									trim($orgClinicalData[8])!="Phase" || trim($orgClinicalData[9])!="Number of enrollees" || 
									trim($orgClinicalData[10])!="Number of trial sites" || trim($orgClinicalData[11])!="Sponsors" || 
									trim($orgClinicalData[12])!="Status" || trim($orgClinicalData[13])!="Start Date" ||
									trim($orgClinicalData[14])!="End Date" || trim($orgClinicalData[15])!="Minimum Age" || trim($orgClinicalData[16])!="Maximum Age" ||
									trim($orgClinicalData[17])!="Gender" || trim($orgClinicalData[18])!="Investigators" ||
									trim($orgClinicalData[19])!="Collaborator" || trim($orgClinicalData[20])!="Purpose" ||
									trim($orgClinicalData[21])!="Official Title" || trim($orgClinicalData[22])!="Keywords" ||
									trim($orgClinicalData[23])!="MeSH Terms"
									
							 	){
							 		$arrImportStatusMsg['trial']['incorrect_format']='Uploaded File format is incorrect';
							 			break;
							 	}
							 	$numColumns=sizeof($data);
							 }
								if($sub!=1){
									$orgClinicalDetails=array();
									$cinNum = $orgClinicalData[1];
									$orgName =$orgClinicalData[2];
									$orgClinicalDetails['ctid'] = $orgClinicalData[3];
										
									if($cinNum!=""){
										$orgClinicalDetails['org_id'] =$this->organization->getOrgIdBySinNumber($cinNum);

										if($orgClinicalDetails['org_id']==0){
											//array of 'pin' not present in database
											$arrImportStatusMsg['trial']['no_matching_cin_num'][]= $cinNum;
										}else{
											$status = $this->clinical_trial_org->saveCTID($orgClinicalDetails);
											if($status == false)
											$arrImportStatusMsg['trial']['ctid_exist'][]= $orgClinicalDetails['ctid'];

											$orgTrialStatusData = array();
											$orgTrialStatusData['id'] = $orgClinicalDetails['org_id'];
											$orgTrialStatusData['is_clinical_trial_processed'] = 0;
											$this->clinical_trial_org->updateClinicalTrialProcessedKol($orgTrialStatusData);
										}
									}else{

										$arrImportStatusMsg['trial']['no_cin_num'][]= $orgName;
									}
								}
								$arrImportStatusMsg['trial']['success']=true;

							}

					 }
					}
				}
			}
			else{
				$arrImportStatusMsg['overview']['file_type_missmatch']="file type is not 'xls'";
			}
		}
		$data['arrImportStatusMsg']=$arrImportStatusMsg;
		$data['contentPage'] 	=	'organizations/view_import_status';
		$this->load->view('layouts/analyst_view',$data);
	}

	/* Send publication data to View page
	 *
	 * @author Vinayak K
	 * @since 6 appr 2013
	 * @version 1.0.11
	 * @param $orgId,$subContentPage
	 * 			
	 */
	function view_publications($orgId = null,$subContentPage=''){
		if(!$orgId){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations');
		}
		$arrOrganizationDetail = array();
		// Getting the Organization details
		$arrOrganizationDetail = $this->organization->editOrganization($orgId);
			
		// If there is no record in the database
		if(!$arrOrganizationDetail){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations');
		}
		 
		$arrOrganizationTypes = $this->organization->getAllOrganizationTypes();
		$data['arrOrganizationTypes']	= $arrOrganizationTypes;
		// Set the Organization ID into the Session
		$this->session->set_userdata('organizationId', $orgId);
		
		$data['arrOrganization']	= $arrOrganizationDetail;
		$arrSalutations				= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']		= $arrSalutations;
		$data['arrYearRange']		= $this->pubmed_org->getOrgPubsYearsRange($orgId);
		$data['assignedUsers'] 		= $this->align_user->getAssignedOrgUsers($orgId);
		$data['contentPage'] 		=  'organizations/list_org_publication_view';
		$data['subContentPage']		= $subContentPage;
		$data['data']['rightSideContentPage']	= 'right_sidebar/org_publications';
		$data['data']['rightSideContentPageData']	= array('arrYearRange'=>$data['arrYearRange'],'orgId'=>$orgId);
		$this->load->view('layouts/client_view', $data);

	}
	
	/* Send trial data to View page
	 *
	 * @author Vinayak K
	 * @since 6 appr 2013
	 * @version 1.0.11
	 * @param $orgId,$subContentPage
	 * 			
	 */
	function view_clinical_trials($orgId = null,$subContentPage=''){
		if(!$orgId){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations');
		}
		$arrOrganizationDetail = array();
		// Getting the Organization details
		$arrOrganizationDetail = $this->organization->editOrganization($orgId);
			
		// If there is no record in the database
		if(!$arrOrganizationDetail){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations');
		}
		
		$data['assignedUsers'] = $this->align_user->getAssignedOrgUsers($orgId);
		// Set the Organization ID into the Session
		$this->session->set_userdata('organizationId', $orgId);
		
		$data['arrOrganization']	= $arrOrganizationDetail;
		$arrSalutations				= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']		= $arrSalutations;
		
		$arrOrganizationTypes = $this->organization->getAllOrganizationTypes();
		$data['arrOrganizationTypes']	= $arrOrganizationTypes;
		$data['contentPage'] 		=	'organizations/list_org_clinical_trials_view';
		$data['subContentPage']		=	$subContentPage;
		$data['data']['rightSideContentPage']	= 'right_sidebar/org_trials';
		$data['data']['rightSideContentPageData']	= array('orgId'=>$orgId);
		$this->load->view('layouts/client_view', $data);
	}
	
	/* Send Stats and facts data to View page
	 *
	 * @author Vinayak K
	 * @since 6 appr 2013
	 * @version 1.0.11
	 * @param $orgId,$subContentPage
	 * 			
	 */
	function view_stats_facts($orgId = null,$subContentPage=''){
		if(!$orgId){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations');
		}
		$arrOrganizationDetail = array();
		// Getting the Organization details
		$arrOrganizationDetail = $this->organization->editOrganization($orgId);
			
		// If there is no record in the database
		if(!$arrOrganizationDetail){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations');
		}
		 
		// Set the Organization ID into the Session
		$this->session->set_userdata('organizationId', $orgId);
		
		$data['arrOrganization']	= $arrOrganizationDetail;
		$arrSalutations				= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']		= $arrSalutations;
		
		$arrOrganizationTypes = $this->organization->getAllOrganizationTypes();
		$data['arrOrganizationTypes']	= $arrOrganizationTypes;
		$data['contentPage'] 		=	'organizations/list_stats_facts';
		$data['subContentPage']		=	$subContentPage;
		$this->load->view('layouts/client_view', $data);

	}
	
	/* send the stat_fact_details to Jggrid
	 *
	 * @author Vinayak K
	 * @since 6 appr 2013
	 * @version 1.0.11
	 * @param $orgId
	 * 			
	 */
	function list_stat_fact_details($orgId){
		
			$arrStatFacts = $this->organization->getStatsAndFacts($orgId);
			$data['rows'] 		= 	$arrStatFacts;
			echo json_encode($data);
		
	}
	
	/* send the sub_organizations details to view Page
	 *
	 * @author Vinayak K
	 * @since 6 appr 2013
	 * @version 1.0.11
	 * @param $orgId
	 * 			
	 */
	function view_sub_organizations($orgId=null,$subContentPage=null){
		if(!$orgId){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations');
		}
		$arrOrganizationDetail = array();
		// Getting the Organization details
		$arrOrganizationDetail = $this->organization->editOrganization($orgId);
			
		// If there is no record in the database
		if(!$arrOrganizationDetail){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations');
		}
		 
		// Set the Organization ID into the Session
		$this->session->set_userdata('organizationId', $orgId);
		$data['assignedUsers'] = $this->align_user->getAssignedOrgUsers($orgId);
		$arrOrganizationTypes = $this->organization->getAllOrganizationTypes();
		$data['arrOrganizationTypes']	= $arrOrganizationTypes;
		
		$data['arrOrganization']	= $arrOrganizationDetail;
		$data['contentPage'] 		=	'organizations/list_sub_organizations';
		$data['subContentPage']		=	$subContentPage;
		$this->load->view('layouts/client_view', $data);
	}
	
	/* send the Sub org details  to Jggrid
	 *
	 * @author Vinayak K
	 * @since 6 appr 2013
	 * @version 1.0.11
	 * @param $orgId
	 * 			
	 */
	function list_sub_org_details($orgId){
		$page					= (int)$this->input->post('page'); // get the requested page
		$limit					= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$data					=	array();
		$subOrgDetails			=	array();
		if($subOrgDetails	= $this->organization->getSubOrg($orgId)){
			//echo $this->db->last_query();
			$count	=	sizeof($subOrgDetails);
			if( $count >0 ) {
				$total_pages = ceil($count/$limit);
	        }else{
				$total_pages = 0;
	        }		
			$data['records']	=	$count;
			$data['total']		=	$total_pages;
			$data['page']		=	$page;
			$data['rows'] 		= 	$subOrgDetails;
		}else{
			$data['records']	=	0;
		}
		echo json_encode($data);
						    }
	
	/* send the medical services details  to Jggrid
	 *
	 * @author Vinayak K
	 * @since 6 appr 2013
	 * @version 1.0.11
	 * @param $orgId
	 * 			
	 */
	function list_medical_services($orgId){
		$page					= (int)$this->input->post('page'); // get the requested page
		$limit					= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$data					=	array();
		$medicalDetails			=	array();
		if($medicalDetails	= $this->organization->getMedicalServiceDetails($orgId)){
			$count	=	sizeof($medicalDetails);
			if( $count >0 ) {
				$total_pages = ceil($count/$limit);
			} else {
				$total_pages = 0;
		 	}
			$data['records']	=	$count;
			$data['total']		=	$total_pages;
			$data['page']		=	$page;
			$data['rows'] 		= 	$medicalDetails;
					}
		echo json_encode($data);
	}

	
	function list_assoc_people($orgId){
		//	$data['arrAssocPeople']	= $this->organization->listOrgAssociatedPpl($organizationId);
		$page					= (int)$this->input->post('page'); // get the requested page
		$limit					= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$data					=	array();
		$medicalDetails			=	array();
		if($arrAssocPeople	=  $this->organization->listOrgAssociatedPpl($orgId)){
			foreach($arrAssocPeople as $row){
				$details  = array();
				$details['id'] = $row['id'];
				$details['kol_name'] = $row['kol_name'];
				$details['title'] = $row['title'];
				$details['division'] = $row['division'];
				$asccoDetails[]=$details;
			}
			$count	=	sizeof($asccoDetails);
			if( $count >0 ) {
				$total_pages = ceil($count/$limit);
			} else {
				$total_pages = 0;
		 	}
			$data['records']	=	$count;
			$data['total']		=	$total_pages;
			$data['page']		=	$page;
			$data['rows'] 		= 	$asccoDetails;
					}
		echo json_encode($data);
	}
	
	function add_client_pre_kol($kolId,$type){
		$arrSalutations	= array(1=>'Dr.', 2=>'Prof.', 3=>'Mr.', 4=>'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		// Get the list of Specialties
		if($type =='keyPeople'){
			$arrKolDetail = $this->organization->getKeyPeopleDetail($kolId);
		}elseif($type =='author'){
			$arrKolDetail = $this->organization->getAuthorDetail($kolId);
			$arrKolDetail['middle_name'] = '';
			if($arrKolDetail['fore_name']!=''){
				
				$arrNames = explode(' ',$arrKolDetail['fore_name']);
				$arrKolDetail['first_name'] = $arrNames[0];
				$arrKolDetail['middle_name'] = $arrNames[1];
				
			}
		}else{
			$arrKolDetail = $this->organization->getInvestigatorDetail($kolId);
			//pr($arrKolDetail);
			
			$names =  explode(',',$arrKolDetail['last_name']);
			$kolName = explode(' ',$names[0]);
			//pr($kolName);
			//echo sizeOf($kolName);
			if(sizeOf($kolName)==2){
				$arrKolDetail['first_name'] = $kolName[0];
				$arrKolDetail['last_name'] = $kolName[1];
			}elseif(sizeOf($kolName)==3){
				$arrKolDetail['first_name'] = $kolName[0];
				$arrKolDetail['middle_name'] = $kolName[1];
				$arrKolDetail['last_name'] = $kolName[2];
			}elseif(sizeOf($kolName)==4){
				$arrKolDetail['first_name'] = $kolName[0];
				$arrKolDetail['middle_name'] = $kolName[1];
				$arrKolDetail['last_name'] = $kolName[2]." ".$kolName[3];
			}
			//pr($arrKolDetail);
		}
		
		$data['arrCountry']				=	$this->Country_helper->listCountries();
		$arrStates 						= array();
		$arrCities						= array();
		
		$this->load->model('Specialty');
		$arrSpecialties					= $this->Specialty->getAllSpecialties();
		$data['arrSpecialties']			= $arrSpecialties;
	
		$data['arrKols'] = $arrKolDetail;
		$data['kolId'] = $kolId;
		$this->load->view('organizations/add_client_kol',$data);
	}
	
	function view_network_map($orgId){
		$arrOrganizationDetail = array();
		// Getting the Organization details
		$arrOrganizationDetail = $this->organization->editOrganization($orgId);
			
		// If there is no record in the database
		if(!$arrOrganizationDetail){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations');
		}
		 
		// Set the Organization ID into the Session
		$this->session->set_userdata('organizationId', $orgId);
		
		$data['arrOrganization']	= $arrOrganizationDetail;
		$data['data']['additionalContent']	= '<div id="refinedByWrapper" class="rightRefinedByFilter">
					<div id="refinedByContainer">
						<div id="rightSideBarSlider" class="expandRightSideBar tooltip-demo tooltop-left"><a href="#" class="tooltipLink" rel="tooltip" title="Show Key People">&nbsp;</a></div>
						<label class="keyPeopleTextLabel">Click on Key People/Authors</label>
						<div id="searchLeftBar" style="display: none;">
							<h3>Key People</h3>
							<input id="search-names" type="text" onkeyup="filterOrgMembersList(this);">
							<div id="searchFiltersContainer" style="position: relative;">
								<ul>
									
								</ul>
							</div>
						</div>
					</div>
				</div>';
		$data['contentPage'] 		= 'organizations/view_network_map';
		$data['assignedUsers'] = $this->align_user->getAssignedOrgUsers($orgId);
		$this->load->view('layouts/client_view',$data);
	}
	
	function get_microview($idString){
		$idValues = explode("-",$idString);
		$type = $idValues[0];
		$id = $idValues[1];
		$arrDetails = array();
		$arrSalutations							= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']					= $arrSalutations;
		
		if($type == 'org'){
			$this->view_micro_org($id);
		}else if($type == 'kol'){
			$arrKol									= array();
			$arrKol									= $this->kol->getKolMicroData($id);
			$data['arrKol']							= $arrKol[0];
			$data['arrKol']['id']					= $id;
			//Get the count of "affilitions"
			$data['noOfAffilitions']				= array();;
			$noOfAffilitions 						= $this->kol->countAfiliations($id);
			$data['noOfAffilitions']				= $noOfAffilitions;
			//Get the count of "Events"
			$data['noOfEvents'] = array();
			$noOfEvents 							= $this->kol->countEvents($id);
			$data['noOfEvents']						= $noOfEvents;
			//Get the count of "Publications"
			$data['noOfPublications']				= array();;
			$noOfPublications 						= $this->kol->countPublications($id);
			$data['noOfPublications']				= $noOfPublications;
			//Get the count of "Trials"
			$data['noOfTrials'] 					= array();
			$noOfTrials 							= $this->kol->countTrials($id);
			$data['noOfTrials']						= $noOfTrials;
			if($data['arrKol']['city_id']!=0)
			$data['arrKol']['city']				= $this->Country_helper->getCityeById($data['arrKol']['city_id']);
			if($data['arrKol']['state_id']!=0){
				$data['arrKol']['state']			= $this->Country_helper->getStateById($data['arrKol']['state_id']);
				$data['arrKol'][0]['state_code']	= $this->Country_helper->getStatecodeByStateIdorName($data['arrKol']['state_id'],'id');
			}
			$data['type'] = $type;
			$this->load->view('kols/view_kol_micro_profile',$data);
		}else if($type == 'key'){
			$data['type'] = $type;
			$data['rowData'] = $this->organization->getKeyPeopleDetail($id);
			$this->load->view('organizations/org_member_microview',$data);
		}else if($type == 'auth'){
			$data['type'] = $type;
			$data['rowData'] = $this->organization->getAuthorDetail($id);
			$orgId = $idValues[2];
			$data['affiliationData'] = $this->organization->getFirstAuthorAffiliationData($orgId, $id);
			$this->load->view('organizations/org_member_microview',$data);
		}else if($type == 'invest'){
			$data['type'] = $type;
			$data['rowData'] = $this->organization->getInvestigatorDetail($id);
			$this->load->view('organizations/org_member_microview',$data);
		}else if($type == 'req'){
			$data['type'] = $type;
			$this->load->model('survey');
			$data['rowData'] = $this->survey->getNameDetails($id);
			$this->load->view('organizations/org_member_microview',$data);
		}
		
	}
	
	function export_as_pdf($orgId,$type){
	
		ini_set("max_execution_time",86400);
		ini_set('memory_limit',"800M");
		$this->load->plugin('export_pdf');
		
		$arrType = $this->organization->getOrgType($orgId);
	
		 $type = $arrType['type_id'];
	
		if($type!=8){
			
			$this->export_by_others($orgId);
		}else{
			$this->export_by_payor($orgId);
		}
		
	}
	
	function export_by_others($orgId,$type){
		
		$data['type']=0;
		$arrOrgDetail = $this->organization->getOrgDetailForPdf($orgId);
		//pr($arrOrgDetail);
		//break;
		$filename 	= $arrOrgDetail['name'];
		
		$data['arrDetail'] = $arrOrgDetail;
		

		$arrClinicalTrialsResults=$this->clinical_trial_org->listClinicalTrialsDetails($orgId,$limit=20);
		//pr($arrClinicalTrialsResults);
		foreach($arrClinicalTrialsResults as $arrClinicalTrialsResult){
				$arrClinicalTrial['id']			= $arrClinicalTrialsResult['id'];
				if($arrClinicalTrialsResult['start_date']!=''){
					$arrClinicalTrialsResult['date']		= $arrClinicalTrialsResult['start_date'];
				}
				if($arrClinicalTrialsResult['end_date']!='' && $arrClinicalTrialsResult['start_date']!=''){
					$arrClinicalTrialsResult['date']		.= '-'.$arrClinicalTrialsResult['end_date'];
				}
				if($arrClinicalTrialsResult['start_date']=='' && $arrClinicalTrialsResult['end_date']!=''){
					$arrClinicalTrialsResult['date']		= $arrClinicalTrialsResult['end_date'];
				}
				if($arrClinicalTrialsResult['start_date']=='' && $arrClinicalTrialsResult['end_date']==''){
					$arrClinicalTrialsResult['date']		= ' ';
				}
				$arrClinicalTrial['date'] 						= $arrClinicalTrialsResult['date'];
				$arrClinicalTrial['trial_name']	= $arrClinicalTrialsResult['trial_name'];
				//$arrClinicalTrial['status']		= $this->clinical_trial->getStatusNameById($arrClinicalTrialsResult['status_id']);
				$arrClinicalTrial['sponsors']	= $this->get_sponsers($arrClinicalTrialsResult['id']);
				$arrClinicalTrial['condition']	= $arrClinicalTrialsResult['condition'];
				$arrClinicalTrial['interventions']	= $this->get_interventions($arrClinicalTrialsResult['id']);
				$arrClinicalTrial['phase']		= $arrClinicalTrialsResult['phase'];
				$arrClinicalTrial['kol_role']		= $arrClinicalTrialsResult['kol_role'];
				//$arrClinicalTrial['user_id']	= $arrClinicalTrialsResult['user_id'];;
				$arrClinicalTrials[]			= $arrClinicalTrial;	
		}
		
		$arrPubDetails = $this->pubmed_org->listOrgPublicationDetails($orgId,$limit=20);
		foreach($arrPubDetails as $pubDetail){
			$arrPub =array();
			$arrPublication['issn_number']					= $pubDetail['issn_number'];
			$arrPublication['volume']						= $pubDetail['volume'];
			$arrPub['cin_num'] = $pubDetail['cin_num'];
			
		
			$arrPub['article_title'] = $pubDetail['article_title'];
			$arrPub['pmid'] = $pubDetail['pmid'];
			$arrPub['jname'] = $pubDetail['jname'];
			$arrPub['created_date'] = $pubDetail['created_date'];
			$arrPub['authors']			= $this->get_pub_authors($pubDetail['id']);
			$arrPublications[] = $arrPub;
		}
		
		
		$data['arrPublications'] = $arrPublications;
		$data['arrClinicalTrials'] = $arrClinicalTrials;
		
		$arrKeyPeople =  $this->organization->listKeyPeoples($orgId);
			foreach($arrKeyPeople as $row){
				$row1 = array();
				$row1['kol_name'] = $row['salutation']." ".$row['first_name']." ".$row['middle_name']." ".$row['last_name'];
				
				
				$row1['role'] = $row['role_id'];
				$row1['department'] = $row['department'];
				$row1['title'] = $row['title'];
				$arrKeyPeoples[]    = $row1;
			}
			//pr($arrDetails);
		$data['arrKeyPeoples'] = $arrKeyPeoples;
		
		
		$arrAssocPeople	=  $this->organization->listOrgAssociatedPpl($orgId);
		//	pr($arrAssocPeople);
			foreach($arrAssocPeople as $people){
				$arrDetail = array();
				$arrDetail['kol_name'] = $arrSalutations[$people['salutation']]." ".$people['first_name']." ".$people['middle_name']." ".$people['last_name'];
				$arrDetail['title'] = $people['title'];
				$arrDetail['department'] = $people['division'];
				$arrDetail['role'] = 'Associated People';
				$arrAssociltedPeople[]=$arrDetail;
			}
		$data['arrAssociltedPeople'] = $arrAssociltedPeople;
		//pr($data['arrKeyPeoples']);
		$subOrgDetails			= $this->organization->getSubOrg($orgId);
			foreach($subOrgDetails as $key=>$orgDetail){
				$arrSubOrgDetails =array();
				
				$arrSubOrgDetails['sub_org'] = $orgDetail['sub_org'];
				$arrSubOrgDetails['address'] = $orgDetail['address'];
				$arrSubOrgDetails[] = $orgDetail['city'];
				$arrSubOrgDetails['postal_code'] = $orgDetail['postal_code'];
				$arrSubOrgDetails['region'] = $orgDetail['region'];
				$arrSubOrgDetails['country'] = $orgDetail['country'];
				$arrSubOrgDetails['phone'] = $orgDetail['phone'];
				
				$arrSubOrgs[] =$arrSubOrgDetails;
			}
			
		$data['subOrgs'] = $arrSubOrgs;
		
		$arrDetails = $this->pubmed_org->getFistAuthors($orgId,$affilition=null,$limit=50);
		foreach($arrDetails as $row){
			
			$detail =array();
			$detail['id'] = $row['id'];
			
			if($row['last_name']!='' && $row['fore_name']!='')
				$authorName =$row['last_name']." ".$row['fore_name'];
			else if($row['fore_name']=='')
				$authorName =$row['last_name']." ".$row['initials'];
			else if($row['last_name']=='')
				$authorName =$row['fore_name']." ".$row['initials'];
			$detail['name'] = $authorName;
			$detail['num_pub'] = $row['num_pubs'];
			//pr($meshTerms);
			$detail['key_words'] = 	 $row['key_words'];
			$arrKeyAuthors[] = $detail;
		}
		
		$data['keyAuthors'] = $arrKeyAuthors;
		
		
		$arrDetails = $this->pubmed_org->getKeyInvestigators($orgId,$limit=50);
		foreach($arrDetails as $row){
			$detail =array();
			$detail['id'] = $row['id'];
			$detail['name'] = $row['last_name'];
			
			$detail['trial_count'] = $row['trial_count'];
			
		
			//$arrKeyWords 	= $this->pubmed_org->getKeywords($orgId,$detail['name']);
			//pr($arrKeyWords);
			//pr($meshTerms);
			$detail['key_words'] = 	 $row['key_words'];
			$arrKeyInvestigators[] = $detail;
		}
		$data['arrKeyInvestigators'] = $arrKeyInvestigators;
//		$this->load->view('organizations/export/org_pdf',$data);
		$html = $this->load->view('organizations/export/org_pdf',$data,true);
		pdf_create($html, $filename);
//		pr($data);
		
	}
	
	function load_more_media_updates(){
		$mediaSection = $this->input->post("mediaSection");
		$mediaUrl = $this->input->post("mediaUrl");
		$startFrom = $this->input->post("startFrom");
		$data = array();
		$data['mediaUrl'] = $mediaUrl;
		$data['startFrom'] = $startFrom;
		if($mediaSection == 'Facebook'){
			$this->load->view("media/facebook_updates",$data);
		}
		if($mediaSection == 'Twitter'){
			$this->load->view("media/twitter_updates",$data);
		}
		if($mediaSection == 'YOuTube'){
			$this->load->view("media/youtube_updates",$data);
		}
	}
	
	function add_sub_org(){
		$data['arrDetail'] = '';
		$data['arrCountry']				= $this->Country_helper->listCountries();
		$this->load->view('organizations/add_sub_org',$data);
	}
	
	function save_sub_org($orgId){
		//$orgName	 		= ucwords(trim($this->input->post('name')));
		$orgName	 		= trim($this->input->post('name'));
		$arrOrg['name']		= $orgName;
		$arrOrg['country_id']	 		=	trim($this->input->post('country_id'));
		$arrOrg['state_id']	 			=	trim($this->input->post('state_id'));
		$arrOrg['city_id']     			=	trim($this->input->post('city_id'));
		$arrOrg['postal_code']     		=	trim($this->input->post('postal_code'));
		$arrOrg['phone']     			=	trim($this->input->post('phone'));
		$arrOrg['address']     			=	trim($this->input->post('address'));
		$arrOrg['created_by']	 		= 	$this->loggedUserId;
		$arrOrg['created_on']	 		=	date("Y-m-d H:i:s");
		$arrOrg['status']	 			=	New1;
		$arrOrg['npi_num']        =	$this->input->post('npi_num');
		$arrOrg['sub_org_id'] = $this->organization->saveOrganization($arrOrg);
		
		if($arrOrg['sub_org_id']!=''){
			unset($arrOrg['created_by']);
			unset($arrOrg['created_on']);
			unset($arrOrg['name']);
			unset($arrOrg['status']);
			$arrOrg['org_id']	 		=	$orgId;
			if($id = $this->organization->saveAffiliatesPartnershipsManaul($arrOrg)){
				$arrOrg['affiliate_id'] = $id; 
				$arrOrg['status'] = "Saved";
			}else{
				$arrOrg['status'] = "Not";
			}
			
			
		}
		$arrOrg['created_by']	 		= 	$this->loggedUserId;
		$arrOrg['name'] = $orgName;
		echo json_encode($arrOrg);
		//ending post details
	}
	
	function add_client_keypeople($orgId){
		$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		$arrKeyPeopleRoles = $this->organization->getAllKeyPeopleRoles();
		$data['arrKeyPeopleRoles']	= $arrKeyPeopleRoles;
		$data['orgId'] = $orgId;
		$data['arrkeyPeople']='';
		$this->load->view('organizations/add_client_keypeople',$data);
	}
	
	function edit_client_keypeople($orgId,$id){
		$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		$arrKeyPeopleRoles = $this->organization->getAllKeyPeopleRoles();
		$data['arrKeyPeopleRoles']	= $arrKeyPeopleRoles;
		$data['orgId'] = $orgId;
		$data['arrkeyPeople'] = $this->organization->getKeyPeopleData($id);
		$this->load->view('organizations/add_client_keypeople',$data);
		
	}
	
	function edit_sub_org($orgId){
		$arrDetail = $this->organization->editOrganization($orgId);
//		echo $this->db->last_query();
		$data['arrCountry']				=	$this->Country_helper->listCountries();
		if($arrDetail['country_id'] != 0){
			$arrStates = $this->Country_helper->getStatesByCountryId($arrDetail['country_id']);
		}
		
		if($arrDetail['state_id'] != 0){
			$arrCities					= $this->Country_helper->getCitiesByStateId($arrDetail['state_id']);
		}
		$data['arrStates']				= $arrStates;
		$data['arrCities']				= $arrCities;
		$data['arrDetail']				= $arrDetail;
		$this->load->view('organizations/add_sub_org',$data);
	
	}
	
	function update_sub_org(){
		$arrOrg['name']	 		=	ucwords(trim($this->input->post('name')));
		$arrOrg['id']	 		=	ucwords(trim($this->input->post('id')));
		$orgName = $arrOrg['name'];
		$arrOrg['country_id']	 		=	trim($this->input->post('country_id'));
		$arrOrg['state_id']	 			=	trim($this->input->post('state_id'));
		$arrOrg['city_id']     			=	trim($this->input->post('city_id'));
		$arrOrg['postal_code']     		=	trim($this->input->post('postal_code'));
		$arrOrg['phone']     			=	trim($this->input->post('phone'));
		$arrOrg['address']     			=	trim($this->input->post('address'));
		$arrOrg['created_by']	 		= 	$this->loggedUserId;
		$arrOrg['created_on']	 		=	date("Y-m-d H:i:s");
		$arrOrg['status']	 			=	New1;
		$arrOrg['npi_num']        =	$this->input->post('npi_num');
		
		if($this->organization->updateOrganization($arrOrg)){
				$arrOrg['status']			= 'Saved';
				$arrOrg['sub_org_id']	= $arrOrg['id'];
				
			//	$this->session->set_userdata('organizationId', $lastInsertId);
		}else{
			$arrOrg['status']			= false;
		}
			
		echo json_encode($arrOrg);
	}
	
    function save_notes($kolId) {
        ini_set('memory_limit',"-1");
        ini_set("max_execution_time",0);
        $arr['note'] = trim($this->input->post('user_note'));
        $arr['created_by'] = $this->loggedUserId;
        $arr['created_on'] = date("Y-m-d H:i:s");
        $arr['org_id'] = $kolId;
        $arr['document']= '';
        $arr['document_name']= '';
        if($_FILES["note_file"]['name']!=''){
            $target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/kol_note_documents/";
            $path_info = pathinfo($_FILES["note_file"]['name']);
            $newFileName	= random_string('unique', 20).".".$path_info['extension'];
            $overview_file_target_path = $target_path ."/". $newFileName;
            if(move_uploaded_file($_FILES['note_file']['tmp_name'],$overview_file_target_path)){
                $arr['document'] = $newFileName;
                $fname = explode('.', $_FILES["note_file"]['name']);
                $arr['orginal_doc_name']= $_FILES["note_file"]['name'];
                $arr['document_name']= $fname[0];
                if($this->input->post('fileName')){
                    $arr['document_name']= trim($this->input->post('fileName'));
                }
            }
        }
        $arr['id'] = $this->organization->saveNote($arr);


        $arr['name'] = $this->session->userdata('user_full_name');
        $currentDateTime = $arr['created_on'];

        $arr['created_on'] = date('d M Y, h:i A', strtotime($currentDateTime));
        $arr['note'] = nl2br($arr['note']);
        $formData = $_POST;
        $formData = json_encode($formData);
        $arrLogDetails = array(
                'module' => 'organizations',
                'type' => LOG_ADD,
            'description' => 'Save Org Note',
            'status' => 'success',
                'transaction_id' => $arr['id'],
            'transaction_table_id' => ORG_NOTES,
                'transaction_name' => 'Save Org Note',
                'form_data' => $formData,
            'parent_object_id'=>$arr['org_id'],
        );
            
        $this->config->set_item('log_details', $arrLogDetails);
        //log_user_activity(null, true);
       
        //log_user_activity($arrLogDetails, true);			
        echo json_encode($arr);
    }

    function delete_notes($noteId) {
        $arrData = array();
        if ($this->organization->deleteNote($noteId)) {
            $arrData['status'] = true;
        } else {
            $arrData['status'] = false;
        }
        echo json_encode($arrData);
    }
    function delete_notes_attachment($noteId){
        $arrData = array();
        if ($this->organization->deleteNoteAttachment($noteId)) {
            $arrData['status'] = true;
        } else {
            $arrData['status'] = false;
        }
        echo json_encode($arrData);
    }
    function update_notes($noteId,$orginal_doc='',$kolId) {
        ini_set('memory_limit',"-1");
        ini_set("max_execution_time",0);
        $arr['note'] = trim($this->input->post('user_note'));
        $arr['modified_by'] = $this->loggedUserId;
        $arr['modified_on'] = date("Y-m-d H:i:s");
        if(trim($this->input->post('fileName'))!=''){
        $arr['document_name']= trim($this->input->post('fileName'));
        }    
        $arr['orginal_doc_name'] = '';
        if($orginal_doc!='undefined'){
            $arr['orginal_doc_name']= trim($orginal_doc);
        }
        $arr['id'] = $noteId;       
        if($_FILES["note_file"]['name']!=''){
            $target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/kol_note_documents/";
            $path_info = pathinfo($_FILES["note_file"]['name']);
            $newFileName	= random_string('unique', 20).".".$path_info['extension'];
            $overview_file_target_path = $target_path ."/". $newFileName;
            if(move_uploaded_file($_FILES['note_file']['tmp_name'],$overview_file_target_path)){
                $arr['document'] = $newFileName;
                $fname = explode('.', $_FILES["note_file"]['name']);
                 $arr['orginal_doc_name']= $_FILES["note_file"]['name'];
                $arr['document_name']= $fname[0];
                if($this->input->post('fileName')){
                    $arr['document_name']= trim($this->input->post('fileName'));
                }
            }
        }
        $arrUpdateData  = $arr;
        if ($this->organization->updateNote($arrUpdateData)) {
            $arr['name'] = $this->session->userdata('user_full_name');
            $currentDateTime = $arr['modified_on'];
            $arr['created_on'] = date('d M Y, h:i A', strtotime($currentDateTime));
            $arr['created_on'] = str_replace(',', " at ", $arr['created_on']);
            $arr['note'] = nl2br($arr['note']);
            $formData = $_POST;
            $formData = json_encode($formData);
            $arrLogDetails = array(
                    'module' => 'organizations',
                    'type' => LOG_UPDATE,
                    'description' => 'Update Org Note',
                    'status' => 'success',
                    'transaction_id' => $arr['id'],
                    'transaction_table_id' => ORG_NOTES,
                    'transaction_name' => 'Update Org Note',
                    'form_data' => $formData,
                    'parent_object_id' => $kolId,
            );
            
            $this->config->set_item('log_details', $arrLogDetails);
            //log_user_activity(null, true);
            echo json_encode($arr);
        }
    }

    function get_notes_by_id($noteId) {
//		echo "lll";
        $arr = $this->organization->getNotesById($noteId);
        $arr = $arr[0];
        if ($arr['modified_on'] != '')
            $currentDateTime = $arr['modified_on'];
        else
            $currentDateTime = $arr['created_on'];
        $arr['created_on'] = date('Y-m-d,h:i A', strtotime($currentDateTime));
        $arr['created_on'] = str_replace(',', " at ", $arr['created_on']);
//		pr($arr);
        echo json_encode($arr);
    }
    function note_document_download($noteId){
        $arrNotes = $this->organization->getNotesById($noteId);
        $this->load->helper('download');
        ob_clean();
        $data =  file_get_contents($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/kol_note_documents/".$arrNotes[0]['document']);
        $arrFileName    = explode(".",$arrNotes[0]['document']);
        $name = $arrNotes[0]['document_name'].".".$arrFileName[sizeof($arrFileName)-1];
        force_download($name, $data);
    }
	/**
	 * Parsing the orga data anr sending data to model to save
	 * @author 	Vinayak
	 * @since	1.0.11
	 * @created  7 appr 2013
	 */
	function import_payer_org_profiles(){
		// Increasing the max execution time to pasrse all sheet data
		ini_set("max_execution_time",7200);
		$arrCountries	=$this->Country_helper->listCountries();
		$arrStates		=$this->Country_helper->listStates();
		$arrCities		=$this->Country_helper->listCities();
		$arrKeyPeopleRoles=$this->organization->getAllKeyPeopleRoles();
		$organizationTypes=$this->organization->getAllOrganizationTypes();
									
		// Load the plugin
		$this->load->plugin('excelReader/reader2');
		$userId		=$this->session->userdata('user_id');
		$clientId	=$this->session->userdata('client_id');
		$orgID		= 0;
		$target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_profiles/";
		$overviewFileName	= random_string('unique', 20);
		$path_info = pathinfo($_FILES["overview_import"]['name']);
		$overview_file_target_path = $target_path . $overviewFileName . "." . $path_info['extension'];
		if($_FILES["overview_import"]['name']!=null){
			if($path_info['extension']=='xls'){
				if(move_uploaded_file($_FILES['overview_import']['tmp_name'], $overview_file_target_path)) {
					$reader				=	new Spreadsheet_Excel_Reader($overview_file_target_path, true, 'utf-8');
					//loop through each sheet
					foreach($reader->sheets as $k=>$details){
						//Parsing of 1st sheet  - Overview: $k = index of the sheet
						if($k==0){
							$numColumns=0;
							$existingOrgs=array();
							$row=1;
							foreach($details['cells'] as $data){
								if($row==1){
									//condition to check whether format of the column is correct or not
									if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="COMPANY TYPE" || trim($data[4])!="LOGO" || trim($data[5])!="WEBSITE"
										|| trim($data[6])!="COMPANY HEADQUARTERS" || trim($data[7])!="COMPANY BACKGROUND" || trim($data[8])!="MISSION, VISION & VALUES"  || trim($data[9])!="KEY PRODUCTS" || trim($data[10])!="MERGERS & ACQUISITIONS" || trim($data[11])!="TOP CLIENTS"  ){
										$arrImportStatusMsg['overview']['incorrect_format']='Uploaded File format is incorrect';
										break;
								 	}
								$numColumns=sizeof($data);
								}
								$organizationDetails=array();
								if($row>1){
									for($i=1;$i<=$numColumns;$i++){
										if(!isset($data[$i]))
										$data[$i]="";
									}
									$organizationDetails['cin_num']=trim($data[1]);
									$organizationDetails['name']=ucwords(trim($data[2]));
									$orgType=array_search(trim($data[3]),$organizationTypes);
									$organizationDetails['type_id']=$orgType;
									$organizationDetails['company_logo']=trim($data[4]);
									$organizationDetails['website']=trim($data[5]);
									$organizationDetails['headquarters']=trim($data[6]);
									$organizationDetails['background']=trim($data[7]);
									$organizationDetails['mission_vision']=trim($data[8]);
									$organizationDetails['key_products']=trim($data[9]);
									$organizationDetails['mergers']=trim($data[10]);
									$organizationDetails['clients']=trim($data[11]);
									$organizationDetails['profile_type'] = FULL;
									$profileType=trim($data[12]);
									if($profileType=='Basic'){
										$organizationDetails['profile_type'] = BASIC;
									}
									if($profileType=='Full Profile'){
										$organizationDetails['profile_type'] = FULL;
									}
									$organizationDetails['status']=New1;
									$organizationDetails['created_by']	=$userId;
									$organizationDetails['created_on']	=date("Y-m-d H:i:s");
									
									//break;
									//Save only if the 'cin_num' is not blank
									if($organizationDetails['cin_num']!=""){
										$id=$this->organization->saveOrganization($organizationDetails);
										if($id==false){
											//array of already existing organizations
											$existingOrgs[]=$organizationDetails['name'].' has been updated';
										}else{
											$orgID	= $id;
										}
									}else{
										//aray of organizations having no 'cin_num'
										$arrImportStatusMsg['overview']['no_cin_num'][]= $organizationDetails['name'];
									}

								}
								$row++;
								$arrImportStatusMsg['overview']['success']=true;
							}
							$arrImportStatusMsg['overview']['existingOrgs']=$existingOrgs;
						}
					 
					 	else if($k==1){
					 		//Parsing of 2st sheet  - Adress: $k = index of the sheet
					 		$numColumns=0;
					 		$row=1;
						    foreach ($details['cells'] as $data) {
						    	//check wherether format is correct or not
						    	if($row==1){
						    		if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="ADDRESS" || trim($data[4])!="CITY" || trim($data[5])!="POSTAL CODE"
						    		 || trim($data[6])!="STATE" || trim($data[7])!="COUNTRY" || trim($data[8])!="PHONE" || trim($data[9])!="FAX" || trim($data[10])!="ADDITIONAL PHONE NUMBERS" || trim($data[11])!="KEY REGIONAL OFFICES" ){
						    		 	$arrImportStatusMsg['address']['incorrect_format']='Uploaded File format is incorrect';
						    		 	break;
						    		 }
						    		 $numColumns=sizeof($data);
						    	}
						    	$organizationDetails=array();
						    	if($row>1){
						    		for($i=1;$i<=$numColumns;$i++){
						    			if(!isset($data[$i]))
						    				$data[$i]="";
						    		}
						    		$countryId=0;
						    		$stateId=0;
						    		$cityId=0;
							        $organizationDetails['cin_num']=trim($data[1]);
							        $organizationDetails['name']=trim($data[2]);
							        $organizationDetails['address']=trim($data[3]);
									/*if(array_key_exists(ucwords(trim($data[4])),$arrCities))
							        	$cityId=$arrCities[ucwords(trim($data[4]))]['city_id'];
									$organizationDetails['city_id']=$cityId;*/
									
									
							        $organizationDetails['postal_code']=trim($data[5]);
							        if(array_key_exists(ucwords(trim($data[6])),$arrStates))
							        	$stateId=$arrStates[ucwords(trim($data[6]))]['state_id'];
							        $organizationDetails['state_id']=$stateId;
									
									$city					= ucwords(trim($data[4]));
									if($city!=''){
									 $organizationDetails['city_id']= $this->kol->getCityIdByState($city,$stateId);
									}
									
							        if(array_key_exists(ucwords(trim($data[7])),$arrCountries))
							        	$countryId=$arrCountries[ucwords(trim($data[7]))]['country_id'];
							        $organizationDetails['country_id']=$countryId;
							        $organizationDetails['phone']=trim($data[8]);
							        $organizationDetails['fax']=trim($data[9]);
							        
							        $faxDetails=explode(" ",$organizationDetails['fax']);
							        $arrFaxValues=array();
							        $faxNumber="";
							        foreach($faxDetails as $value){
							        	if(strpos($value, "+")!=false){
							        		$faxNumber.=trim($value);
							        	}
							        	if(is_numeric($value)){
							        		$faxNumber.=trim($value);
							        	}
							        }
							       
							        $organizationDetails['key_reginal_offices']=trim($data[11]);
									$organizationDetails['addr_url']=trim($data[12]);
									$organizationDetails['created_by']	=$userId;
							        $organizationDetails['created_on']	=date("Y-m-d H:i:s");
							        
							        //Save only if the 'cin_num' is not blank
							        if($organizationDetails['cin_num']!=""){
							        	$orgID =$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
							        	if($orgID>0){
							        		$organizationDetails['id']	= $orgID;
							        	}
								        $id=$this->organization->updateImportedOrganization($organizationDetails);
								        if($id==false){
								        	//array of 'cin_num' not present in database
								        	$arrImportStatusMsg['address']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
								        }
							        }else{
							        	//aray of organizations  having no 'cin_num'
							        	$arrImportStatusMsg['address']['no_cin_num'][]= $organizationDetails['name'];
							        }		
							        
							        //Parsing and saving additional contact details
							        if($organizationDetails['cin_num']!=""){
							        	$arrContactDetails=array();
								        $orgId=$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
								        $aditionalContats=trim($data[10]);
								        $arrAditionalContactDetails=explode("\n",$aditionalContats);
								        foreach($arrAditionalContactDetails as $aditionalContat){
								        	$contactDetails=array();
								        	$phNumber="";
								        	$relatedTo="";
								        	if(strpos($aditionalContat, "-")!=false){
								        		$aditionalContatDetails=explode("-",$aditionalContat);
								        		 foreach($aditionalContatDetails as $value){
										        	if(strpos($value, "+")!=false){
										        		$phNumber.=trim($value);
										        	}else if(is_numeric($value)){
										        		$phNumber.=trim($value);
										        	}else {
										        		$relatedTo.=trim($value);
										        	}
										        }
								        	}else if(strpos($aditionalContat, ":")!=false){
												
												//echo $aditionalContat;
								        		$aditionalContatDetails=explode(":",$aditionalContat);
												$contactDetails['related_to']=$aditionalContatDetails[0];
												$contactDetails['phone']=$aditionalContatDetails[1];
								        	}else{
								        		$aditionalContatDetails=explode(" ",$aditionalContat);
								        	}
								        	$arrContactDetails[]=$contactDetails;
								        }
								        if($orgId!=0){
								        	//save additional contact details
								        	foreach($arrContactDetails as $row){
								        		$row['org_id']=$orgId;
								        		$row['created_by']	=$userId;
							        			$row['created_on']	=date("Y-m-d H:i:s");
							        			$this->organization->saveContact($row);
								        	}
								        }else{
								        	//set error details
								        }
							        }
						    	}
						    	$row++;					    	
						    	$arrImportStatusMsg['address']['success']=true;
						    }
						    
					 	}
					 	else if($k==2){
					 		
					 		$arrClaimsAndprocess = $this->organization->getClaimsaAndProcess();
					 		$fact =1;
					 		//Parsing of 3st sheet  - Mediacal Services: $k = index of the sheet
					 		$numColumns=0;
					 		$row=1;
					 	
							foreach($details['cells'] as $key=>$data) {
						    if($row==1){
									if( trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="NO. OF HOSPITALS" || trim($data[4])!="TOTAL NO. OF PHYSICIANS" || trim($data[5])!='NO. OF PHYSICIANS EMPLOYED' || trim($data[6])!='NO. OF PHYSICIANS AFFILIATED' ||
									
									trim($data[7])!='PHARMACY BENEFIT MANAGEMENT' || trim($data[8])!='SPECIALTY PHARMACY' || trim($data[9])!='NCQA STATUS' ||
									trim($data[10])!='MEDICARE STAR RATING' || trim($data[11])!='CLAIMS & EMR DATA' || trim($data[12])!='DATA PROCESSING'
									){
										$arrImportStatusMsg['facts']['incorrect_format']='Uploaded File format is incorrect';
						    		 	break;
						    		 }
						    		 $numColumns=sizeof($data);
						    	}
								$factDataDetails=array();
						    	if($row>1){
						    		for($i=1;$i<=$numColumns;$i++){
						    			if(!isset($data[$i]))
						    				$data[$i]="";
						    		}
									$cinNum  = trim($data[1]);
									$orgName =ucwords(trim($data[2]));
							        
									$factDataDetails['no_of_hospitals']=trim($data[3]);
									$factDataDetails['no_of_physicians']=trim($data[4]);
									$factDataDetails['physicians_employed']=trim($data[5]);
									$factDataDetails['no_of_affiliated']=trim($data[6]);
									$factDataDetails['benefit_management']=trim($data[7]);
									$factDataDetails['specialty_pharmacy']=trim($data[8]);
									$factDataDetails['ncqa_status']=trim($data[9]);
									$factDataDetails['start_rating']=trim($data[10]);
									
									
							        //Save only if the 'cin_num' is not blank
									if($cinNum!=""){
										$orgID	= $this->organization->getOrgIdBySinNumber($cinNum);
										$factDataDetails['org_id'] =$orgID;
										if($orgID==0){
								        	//array of 'cin_num' not present in database
											$arrImportStatusMsg['facts']['no_matching_cin_num'][]= $cinNum;
							       		 }else{
							        		if($fact ==1){
							        			$this->organization->deleteOrgPayerFacts($orgID);
							        			$fact++;
							        		}
											$id = $this->organization->saveOrgPayerFacts($factDataDetails);
											$claims =trim($data[11]);
											if($claims!=''){
												$claimsArray = explode(',',$claims);
												
												$arrClaimsData = array();
												foreach($claimsArray as $value){
													$arrClaims =array();
													 if(array_key_exists(trim($value),$arrClaimsAndprocess)){
													 	$arrClaims['type_id'] = CLAIMS;
													 	$arrClaims['fact_id'] = $id;
								        				$arrClaims['cliam_process_id']=$arrClaimsAndprocess[trim($value)]['id'];
								        				$this->organization->saveClaimData($arrClaims);
													 }
												}
							       		 	}
											$dataProcessing=trim($data[12]);
							       			 if($dataProcessing!=''){
												$processingArray = explode(',',$dataProcessing);
												
												$arrClaimsData = array();
												foreach($processingArray as $process){
													$arrProcess =array();
													 if(array_key_exists(trim($process),$arrClaimsAndprocess)){
													 	$arrProcess['type_id'] = DATA_PROCESSING;
													 	$arrProcess['fact_id'] = $id;
								        				$arrProcess['cliam_process_id']=$arrClaimsAndprocess[trim($process)]['id'];
								        				$this->organization->saveClaimData($arrProcess);
													 }
												}
							       		 	}
											
										}
									}else{
							        	//aray of address detains having no 'cin_num'
										$arrImportStatusMsg['facts']['no_cin_num'][]= $orgName;
							        }		
							       		        
						    	}
						    	$row++;
								$arrImportStatusMsg['facts']['success']=true;
						    }
						   
						   
					 	}
					 	else if($k==3){
					 		//Parsing of 3st sheet  - Affiliate patnership: $k = index of the sheet
					 		$numColumns=0;
					 		$row=1;
					 		$enroll=1;
							foreach($details['cells'] as $key=>$data) {
						    if($row==1){
							
						    	if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!='ENROLLMENT TYPE'
									
									){
										$arrImportStatusMsg['enrollment']['incorrect_format']='Uploaded File format is incorrect';
						    		 	break;
						    		 }
						    		 $numColumns=sizeof($data);
						    		unset($data[1]);
						    		unset($data[2]);
						    		unset($data[3]);
						    		 $years=$data;
						    		
						    		
						    	}
								$enrollementDetails=array();
						    	if($row>1){
						    		for($i=1;$i<=$numColumns;$i++){
						    			if(!isset($data[$i]))
						    				$data[$i]="";
						    		}
									$cinNum  = trim($data[1]);
									$orgName =ucwords(trim($data[2]));
									//pr($data);
									$enrollementDetails['type']=trim($data[3]);
									$enrollementDetails['created_on']=$this->loggedUserId;
									$enrollementDetails['created_by']=date("Y-m-d H:i:s");
									$enrollementDetails['client_id']=$this->session->userdata('client_id');
									//echo $cinNum;
									//$enrollementDetails['2009']=trim($data[4]);
									///$enrollementDetails['2010']=trim($data[5]);
									//$enrollementDetails['2011']=trim($data[6]);
							       // $enrollementDetails['2012']=trim($data[7]);
									if($cinNum!=''){
										$enrollementDetails['org_id'] =$this->organization->getOrgIdBySinNumber($cinNum);
										if($enrollementDetails['org_id']!=0){
											if($enroll ==1){
							        			$this->organization->deleteOrgEnrollement($enrollementDetails['org_id']);
							        			$enroll++;
							        		}
											$id = $this->organization->saveOrgEnrollement($enrollementDetails);
											// pr($years);
											$lenth=sizeOf($years)+4;
										
											for($k=4;$k<$lenth;$k++){
												$arr =array();
												$arr['year']=$years[$k];
												$arr['value']=preg_replace("/[^0-9]/", "", $data[$k]);//str_replace(",","",$data[$k]);
												$arr['enroll_id']=$id;
										
												$this->organization->saveEnrollements($arr);
												
											}
											
											
											
										}else{
												
											$arrImportStatusMsg['enrollment']['no_matching_cin_num'][]= $cinNum;
										}
									}else{
										//aray of address detains having no 'cin_num'
										$arrImportStatusMsg['enrollment']['no_cin_num'][]=$orgName;
									}
								}
								$row++;
								$arrImportStatusMsg['enrollment']['success']=true;
							}
							
						}
							
					 else if($k==4){
					 	
					 	$arrFormularyDropDownValues = $this->organization->getFormularyDropDownValues();
					 
					 	//Parsing of 3st sheet  - Social Media : $k = index of the sheet
					 	$numColumns=0;
					 	$row=1;
					 	$formulary=1;
					 	foreach($details['cells'] as $data) {
					 		if($row==1){
					 			if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="DRUG NAME" || trim($data[4])!="DRUG TIER" || trim($data[5])!="PA  CRITERIA"
					 			 ){
					 				$arrImportStatusMsg['formulary']['incorrect_format']='Uploaded File format is incorrect';
					 				//break;
					 			}
					 			$numColumns=sizeof($data);
					 		}
					 		$formularyDetails=array();
					 		if($row>1){
					 			for($i=1;$i<=$numColumns;$i++){
					 				if(!isset($data[$i]))
					 				$data[$i]="";
					 			}
					 			$cinNum=trim($data[1]);
					 			$name=ucwords(trim($data[2]));
					 			 
					 			$formularyDetails['drug_name']=trim($data[3]);
					 			$formularyDetails['created_by']	=$this->loggedUserId;
								$formularyDetails['created_on']	=date("Y-m-d H:i:s");
								$formularyDetails['client_id']	=$this->session->userdata('client_id');
					 			$drugs=trim($data[4]);
					 			$paCretaria=trim($data[5]);
					 			//$formularyDetails['pa_creteria']=trim($data[5]);
					 			
					 			//$formularyDetails['created_by']	=$userId;
					 			//$formularyDetails['created_on']	=date("Y-m-d H:i:s");
					 			 
					 			//Save only if the 'cin_num' is not blank
					 			if($cinNum!=""){
					 				$orgID	= $this->organization->getOrgIdBySinNumber($cinNum);
					 				
					 					if($orgID==0){
								        	//array of 'cin_num' not present in database
											$arrImportStatusMsg['formulary']['no_matching_cin_num'][]= $cinNum;
							       		 }else{
							       		 	$formularyDetails['org_id'] = $orgID;
							        		if($formulary ==1){
							        			$this->organization->deleteOrgFormulary($orgID);
							        			$formulary++;
							        		}
											$id = $this->organization->saveOrgFormularies($formularyDetails);
							       			 if($drugs!=''){
												$drugsArray = explode(',',$drugs);
												
												//$arrDrugsData = array();
												foreach($drugsArray as $value){
													$arrDrugsData =array();
													 if(array_key_exists(trim($value),$arrFormularyDropDownValues)){
													 	$arrDrugsData['type'] = DRUG_TIER;
													 	$arrDrugsData['form_id'] = $id;
								        				$arrDrugsData['drug_pa_id']=$arrFormularyDropDownValues[trim($value)]['id'];
								        				
								        				$this->organization->saveFormularyDropdownData($arrDrugsData);
													 }
													 
													 
												}
												
							       		 	}
							       		 	
							       		  if($paCretaria!=''){
												$paArray = explode(',',$paCretaria);
											
												//$arrDrugsData = array();
												foreach($paArray as $value){
													$arrPaData =array();
													 if(array_key_exists(trim($value),$arrFormularyDropDownValues)){
													 	$arrPaData['type'] = PA_CRITERIA;
													 	$arrPaData['form_id'] = $id;
								        				$arrPaData['drug_pa_id']=$arrFormularyDropDownValues[trim($value)]['id'];
								        				
								        				$this->organization->saveFormularyDropdownData($arrPaData);
													 }
													 
													 
												}
												
							       		 	}
											
											
										}
					 			}else{
					 				//aray of address detains having no 'cin_num'
					 				$arrImportStatusMsg['formulary']['no_cin_num'][]= $name;
					 			}

					 		}
					 		$row++;
					 		$arrImportStatusMsg['formulary']['success']=true;
					 	}
					 	
					 }
					 else if($k==6){
					 	$arrCollabarationCategories = $this->organization->getCollabarationCategories();
					 	$arrCollabarationRatings = $this->organization->getCollabarationRatings();
					 	//Parsing of 3st sheet  - Social Media : $k = index of the sheet
					 	$numColumns=0;
					 	$row=1;
					 	$rate=1;
					 	foreach($details['cells'] as $data) {
					 		if($row==1){
					 			if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="CATEGORY" || trim($data[4])!="RATING"
					 			 ){
					 				$arrImportStatusMsg['collabaration']['incorrect_format']='Uploaded File format is incorrect';
					 				break;
					 			}
					 			$numColumns=sizeof($data);
					 		}
					 		$formularyDetails=array();
					 		if($row>1){
					 			for($i=1;$i<=$numColumns;$i++){
					 				if(!isset($data[$i]))
					 				$data[$i]="";
					 			}
					 			$cinNum=trim($data[1]);
					 			$name=ucwords(trim($data[2]));
					 			 
					 			$category=trim($data[3]);
					 			 if(array_key_exists(trim($category),$arrCollabarationCategories)){
					 			 	$categoryId = $arrCollabarationCategories[$category]['id'];
					 			 }
					 			
					 			$ratings=trim($data[4]);
					 			//echo $ratings;
					 			//$formularyDetails['pa_creteria']=trim($data[5]);
					 			
					 			//$formularyDetails['created_by']	=$userId;
					 			//$formularyDetails['created_on']	=date("Y-m-d H:i:s");
					 			 
					 			//Save only if the 'cin_num' is not blank
					 			if($cinNum!=""){
					 				$orgID	= $this->organization->getOrgIdBySinNumber($cinNum);
					 				
					 					if($orgID==0){
								        	//array of 'cin_num' not present in database
											$arrImportStatusMsg['collabaration']['no_matching_cin_num'][]= $cinNum;
							       		 }else{
							       		 	
							       		 	//$formularyDetails['org_id'] = $orgID;
							        		if($rate==1){
							        			$this->organization->deleteCollabarationRatings($orgID);
							        			$rate++;
							        		}
											//$id = $this->organization->saveOrgFormularies($formularyDetails);
											
											if($ratings!=''){
												
												$arrRatings = explode(',',$ratings);
												foreach($arrRatings  as $rating){
													
													if(array_key_exists(trim($rating),$arrCollabarationRatings)){
														$ratings =array();
														$ratingId = $arrCollabarationRatings[trim($rating)]['id'];
					 			 						$ratings['category_id'] = $categoryId;
					 			 						$ratings['org_id'] = $orgID;
					 			 						$ratings['rating_id'] = $ratingId;
				 			 							$ratings['created_by']	=$this->loggedUserId;
														$ratings['created_on']	=date("Y-m-d H:i:s");
														$ratings['client_id']	=$this->session->userdata('client_id');
					 			 						$this->organization->saveCollabarationRatings($ratings);
					 			 						
					 			 					}
												}
											}
											
										}
					 			}else{
					 				//aray of address detains having no 'cin_num'
					 				$arrImportStatusMsg['collabaration']['no_cin_num'][]= $name;
					 			}

					 		}
					 		$row++;
					 		$arrImportStatusMsg['collabaration']['success']=true;
					 	}
					 	
					 }
					 else if($k==7){
					 	$kePeople=1;
						 	//Parsing of 4th sheet  -key_people: $k = index of the sheet
					 		$numColumns=0;
					 		$row=1;
							$arrSalutations	= array(''=>0,'Dr.' => 1, 'Prof.' => 2, 'Mr.' => 3, 'Ms.' =>4);
							foreach($details['cells'] as $data) {
								if($row==1){
									if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="ROLE" || trim($data[4])!="SALUTATION" || trim($data[5])!="FIRST NAME"
									|| trim($data[6])!="MIDDLE NAME" || trim($data[7])!="LAST NAME" || trim($data[8])!="DEPARTMENT/DIVISION/CENTER" || trim($data[9])!="TITLE" || trim($data[10])!="EMAIL" ){
										$arrImportStatusMsg['key_people']['incorrect_format']='Uploaded File format is incorrect';
										break;
									}
									$numColumns=sizeof($data);
								}
								$organizationDetails=array();
								if($row>1){
									for($i=1;$i<=$numColumns;$i++){
										if(!isset($data[$i]))
										$data[$i]="";
									}
									$organizationDetails['cin_num']=trim($data[1]);
									$organizationDetails['name']=ucwords(trim($data[2]));
									 
									$roleId=array_search(trim(strtolower($data[3])),array_map('strtolower',$arrKeyPeopleRoles));//array_search(trim($data[3]),$arrKeyPeopleRoles);
									$keyPeopleDetails['role_id']=$roleId;
									$keyPeopleDetails['salutation']=$arrSalutations[trim($data[4])];
									$keyPeopleDetails['first_name']=trim($data[5]);
									$keyPeopleDetails['middle_name']=trim($data[6]);
									$keyPeopleDetails['last_name']=trim($data[7]);
									$keyPeopleDetails['department']=trim($data[8]);
									$keyPeopleDetails['title']=trim($data[9]);
									$keyPeopleDetails['email']=trim($data[10]);
									$keyPeopleDetails['url']=trim($data[11]);
									$keyPeopleDetails['created_by']	=$userId;
									$keyPeopleDetails['created_on']	=date("Y-m-d H:i:s");
									//Save only if the 'cin_num' is not blank
									if($organizationDetails['cin_num']!=""){
										$orgId=$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
										if($orgId==0){
											$orgId=$this->organization->getOrgIdByOrgName($organizationDetails['name']);
										}
										if($orgId!=0){
											$keyPeopleDetails['org_id']=$orgId;
											if($kePeople ==1){
											$this->organization->deleteKeyPeopleByOrgId($orgId);
											$kePeople++;
											}
											$this->organization->saveKeyPeople($keyPeopleDetails);
										}else{
											
							        		$arrImportStatusMsg['key_people']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
										}
									}else{
										//aray of address detains having no 'cin_num'
										$arrImportStatusMsg['key_people']['no_cin_num'][]= $organizationDetails['name'];
									}

								}
								$row++;
								$arrImportStatusMsg['key_people']['success']=true;
							}
					 }

					 else if($k==5){
					 		$management = 1;
					 	//$arrDiseaseDropDownValues = $this->organization->getDiseaseDropDownValues();
					 		///pr($arrDiseaseDropDownValues);
				 			//Parsing of 7th sheet  - Stats Facts: $k = index of the sheet
							foreach($details['cells'] as $factKey=>$facts){
							 if($factKey==1){
							 	if(trim($facts[1])!="CIN NUM" || trim($facts[2])!="COMPANY NAME" || trim($facts[3])!="DISEASE NAME" || trim($facts[4])!="DISEASE MANAGEMENT PLATFORMS" ||
							 		trim($facts[5])!="IDENTIFICATION" || trim($facts[6])!="INTERVENTION" || trim($facts[7])!="MEASUREMENT"
							 	){
							 		$arrImportStatusMsg['disease_management']['incorrect_format']='Uploaded File format is incorrect';
							 		break;
							 	}
							 	
							 	
							 	$numColumns=sizeof($facts);
							 }
								if($factKey!=1){
									$managmentDataDetails=array();
									$cinNum = $facts[1];
									$name = $facts[2];
									$managmentDataDetails["disease_name"] 		= $facts[3];
									
									$managmentDataDetails['created_by']	=$this->loggedUserId;
									$managmentDataDetails['created_on']	=date("Y-m-d H:i:s");
									$managmentDataDetails['client_id'] = $this->session->userdata('client_id');
									$platForms	= $facts[4];
									$identification	= $facts[5];
									$intervention	= $facts[6];
									$measurement	= $facts[7];
									//$managmentDataDetails["identification"] 	 	    = $facts[5];
									
									//$managmentDataDetails["intervention"] 	= $facts[6];
									//$managmentDataDetails["measurement"]    = $facts[7];
									if($cinNum!=''){
										$managmentDataDetails['org_id'] =$this->organization->getOrgIdBySinNumber($cinNum);
										if($managmentDataDetails['org_id']!=0){
											
											if($management ==1){
												$this->organization->deleteDiseaseManagement($managmentDataDetails['org_id']);
												$management++;
											}
											$id = $this->organization->saveDeaseManagement($managmentDataDetails);
											 if($platForms!=''){
												$platFormArray = explode(',',$platForms);
												$arrDiseaseDropDownValues = $this->organization->getDiseaseDropDownValuesForParticulars(DISEASE_MANAGEMENT_PLATFORMS);
												//$arrDrugsData = array();
												foreach($platFormArray as $value){
													
													$arrPlatFormData =array();
													
													 if(array_key_exists(trim($value),$arrDiseaseDropDownValues)){
													 	//echo $value;
													 	$arrPlatFormData['type'] = DISEASE_MANAGEMENT_PLATFORMS;
													 	$arrPlatFormData['disease_id'] = $id;
								        				$arrPlatFormData['value_id']=$arrDiseaseDropDownValues[trim($value)]['id'];
								        				
								        				$this->organization->saveDiseaseDropdownData($arrPlatFormData);
													 }
												}
												
							       		 	}
											
										 
							       		 	
										if($identification!=''){
												$identificationArray = explode(',',$identification);
												$arrDiseaseDropDownValues = $this->organization->getDiseaseDropDownValuesForParticulars(IDENTIFICATION);
												//$arrDrugsData = array();
												foreach($identificationArray as $value){
													
													$arrIdentData =array();
													
													 if(array_key_exists(trim($value),$arrDiseaseDropDownValues)){
													 	//echo $value;
													 	$arrIdentData['type'] = IDENTIFICATION;
													 	$arrIdentData['disease_id'] = $id;
								        				$arrIdentData['value_id']=$arrDiseaseDropDownValues[trim($value)]['id'];
								        				
								        				$this->organization->saveDiseaseDropdownData($arrIdentData);
													 }
												}
												
							       		 	}
							       		 	
											if($intervention!=''){
												$interventionArray = explode(',',$intervention);
												$arrDiseaseDropDownValues = $this->organization->getDiseaseDropDownValuesForParticulars(INTERVENTION);
												//$arrDrugsData = array();
												foreach($interventionArray as $value){
													
													$arrInterData =array();
													
													 if(array_key_exists(trim($value),$arrDiseaseDropDownValues)){
													 	//echo $value;
													 	$arrInterData['type'] = INTERVENTION;
													 	$arrInterData['disease_id'] = $id;
								        				$arrInterData['value_id']=$arrDiseaseDropDownValues[trim($value)]['id'];
								        				//pr($arrPlatFormData);
								        				$this->organization->saveDiseaseDropdownData($arrInterData);
													 }
												}
												
							       		 	}
							       		 	
										if($measurement!=''){
												$measurementArray = explode(',',$measurement);
												$arrDiseaseDropDownValues = $this->organization->getDiseaseDropDownValuesForParticulars(MEASUREMENT);
												//$arrDrugsData = array();
												foreach($measurementArray as $value){
													
													$arrMeasuremenData =array();
													
													 if(array_key_exists(trim($value),$arrDiseaseDropDownValues)){
													 	//echo $value;
													 	$arrMeasuremenData['type'] = MEASUREMENT;
													 	$arrMeasuremenData['disease_id'] = $id;
								        				$arrMeasuremenData['value_id']=$arrDiseaseDropDownValues[trim($value)]['id'];
								        				//pr($arrPlatFormData);
								        				$this->organization->saveDiseaseDropdownData($arrMeasuremenData);
													 }
												}
												
							       		 	}
												
										}else{
												
											$arrImportStatusMsg['disease_management']['no_matching_cin_num'][]= $cinNum;
										}
									}else{
										//aray of address detains having no 'cin_num'
										$arrImportStatusMsg['disease_management']['no_cin_num'][]= $name;
									}
								}
								$arrImportStatusMsg['disease_management']['success']=true;

							}
							// break;
					 	}
					 	
					 else if($k==8){
					 	//Parsing of 3st sheet  - Social Media : $k = index of the sheet
					 	$numColumns=0;
					 	$row=1;
					 	foreach($details['cells'] as $data) {
					 		if($row==1){
					 			if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="BLOG" || trim($data[4])!="YOUTUBE" || trim($data[5])!="LINKEDIN"
					 			|| trim($data[6])!="FACEBOOK" || trim($data[7])!="TWITTER" ){
					 				$arrImportStatusMsg['social_media']['incorrect_format']='Uploaded File format is incorrect';
					 				break;
					 			}
					 			$numColumns=sizeof($data);
					 		}
					 		$organizationDetails=array();
					 		if($row>1){
					 			for($i=1;$i<=$numColumns;$i++){
					 				if(!isset($data[$i]))
					 				$data[$i]="";
					 			}
					 			$organizationDetails['cin_num']=trim($data[1]);
					 			$organizationDetails['name']=ucwords(trim($data[2]));
					 			 
					 			$organizationDetails['blog']=trim($data[3]);
					 			$organizationDetails['youtube']=trim($data[4]);
					 			$organizationDetails['linkedin']=trim($data[5]);
					 			$organizationDetails['facebook']=trim($data[6]);
					 			//$organizationDetails['myspace']=trim($data[7]);
					 			$organizationDetails['twitter']=trim($data[7]);
					 			 
					 			$organizationDetails['created_by']	=$userId;
					 			$organizationDetails['created_on']	=date("Y-m-d H:i:s");
					 			 
					 			//Save only if the 'cin_num' is not blank
					 			if($organizationDetails['cin_num']!=""){
					 				$orgID	= $this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
					 				if($orgID>0){
					 					$organizationDetails['id']	= $orgID;
					 				}
					 				$id=$this->organization->updateImportedOrganization($organizationDetails);
					 				if($id==false){
					 					//array of 'cin_num' not present in database
					 					$arrImportStatusMsg['social_media']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
					 				}
					 			}else{
					 				//aray of address detains having no 'cin_num'
					 				$arrImportStatusMsg['social_media']['no_cin_num'][]= $organizationDetails['name'];
					 			}

					 		}
					 		$row++;
					 		$arrImportStatusMsg['social_media']['success']=true;
					 	}
					 }
					 
					}
				}
			}
			else{
				$arrImportStatusMsg['overview']['file_type_missmatch']="file type is not 'xls'";
			}
		}
		$data['type'] = 'Payer';
		$data['arrImportStatusMsg']=$arrImportStatusMsg;
		$data['contentPage'] 	=	'organizations/view_import_status';
		$this->load->view('layouts/analyst_view',$data);
	}
	
	function test(){
		$this->organization->getClaimsaAndProcess();
	}
	
/**
	 * preparing all organizations to be export
	 * @author 	Vinayak
	 * @since	1.0.11
	 * @return Array
	 * @created 4 appr 2013
	 */
	function org_payer_export($orgIds){
		$clientId = $this->session->userdata('client_id');
	
		$this->load->plugin('phpxls/writer');
		$arrOrganizationDetailSheet[0]	= array('CIN NUM','COMPANY NAME','COMPANY TYPE','LOGO','WEBSITE','COMPANY HEADQUARTERS','COMPANY BACKGROUND','MISSION, VISION & VALUES','KEY PRODUCTS','MERGERS & ACQUISITIONS','TOP CLIENTS','PROFILE TYPE');

		
		$arrOrgAddressSheet[0]			= array('CIN NUM','COMPANY NAME','ADDRESS','CITY','POSTAL CODE','STATE','COUNTRY','PHONE','FAX','ADDITIONAL PHONE NUMBERS','KEY REGIONAL OFFICES');
		//$arrSocialMediaDetailsSheet[0]	= array('CIN NUM','COMPANY NAME','BLOG','YOUTUBE','LINKEDIN','FACEBOOK','TWITTER');
		$arrkeyPeoplesSheet[0]			= array('CIN NUM','COMPANY NAME','ROLE','SALUTATION','FIRST NAME','MIDDLE NAME','LAST NAME','TITLE','EMAIL');
		//$arrMedialserviceSheet[0]		= array('CIN NUM','COMPANY NAME','MEDICAL SERVICES');
		//$arrSubOrgSheet[0]		= array('CIN NUM','COMPANY NAME','INSTITUTE NAME','ADDRESS','CITY','POSTAL CODE','STATE','COUNTRY','PHONE','NPI NUMBER');
		$arrStatFactSheet[0]		= array('CIN NUM','COMPANY NAME','NO. OF HOSPITALS','TOTAL NO. OF PHYSICIANS','NO. OF PHYSICIANS EMPLOYED','NO. OF PHYSICIANS AFFILIATED','PHARMACY BENEFIT MANAGEMENT ','SPECIALTY PHARMACY','NCQA STATUS','MEDICARE STAR RATING','CLAIMS & EMR DATA','DATA PROCESSING');

		$arrEnrollementSheet[0]		= array('CIN NUM','COMPANY NAME',"ENROLLMENT TYPE");
		$arrkeyPeoplesSheet[0] = array('CIN NUM','COMPANY NAME','ROLE','SALUTATION','FIRST NAME','MIDDLE NAME','LAST NAME','DEPARTMENT/DIVISION/CENTER','TITLE','EMAIL');
		$arrFormularyheet[0] = array('CIN NUM','COMPANY NAME','DRUG NAME','DRUG TIER','PA  CRITERIA');
		
		$arrManagementSheet[0] = array('CIN NUM','COMPANY NAME','DISEASE NAME','DISEASE MANAGEMENT PLATFORMS','IDENTIFICATION','INTERVENTION','MEASUREMENT');
		$arrCollabarationSheet[0] = array('CIN NUM','COMPANY NAME','CATEGORY','RATING');
		$arrSocialMediaDetailsSheet[0]	= array('CIN NUM','COMPANY NAME','BLOG','YOUTUBE','LINKEDIN','FACEBOOK','TWITTER');
		if($clientId == INTERNAL_CLIENT_ID){
			$arrOrganizationDetailSheet[0][]='URL';
			$arrOrgAddressSheet[0][] = 'URL';
			$arrkeyPeoplesSheet[0][] = 'URL';
			$arrMedialserviceSheet[0][] = 'URL';
			$arrSubOrgSheet[0][] = 'URL';
			$arrStatFactSheet[0][] = 'URL1';
			$arrStatFactSheet[0][] = 'URL2';
		}
		//pr($arrOrganizationDetailSheet);
		//pr($arrOrgAddressSheet);
		//pr($arrkeyPeoplesSheet);
	//	pr($arrMedialserviceSheet);
	//	pr($arrSubOrgSheet);
	//	pr($arrStatFactSheet);
	//	pr($arrSubOrgSheet);
		//break;
			$arrMaxYear = $this->organization->getMaxEnrollYear($orgIds);
			for($i=2009;$i<=$arrMaxYear['maxyear'];$i++){
				array_push($arrEnrollementSheet[0],$i);
			}
			foreach($orgIds as $id){
				//Getting the Organizations Details
				$arrOrganizationDetail	= $this->organization->getOrgDetails($id);
				$arrOrganizationDetail1	= array();
				$arrOrganizationDetail1[0] = $arrOrganizationDetail[0]['cin_num'];
				$arrOrganizationDetail1[1] = $arrOrganizationDetail[0]['name'];
				//Getting the Organizations Address Details	
				$orgAdress				= $this->organization->getAdreessOfOrg($id);
				//Getting the Organizations Social Media Details									
				$orgSocialMediaDetails	= $this->organization->getSocialMediaDetailsOfOrg($id);
				//Getting the Organizations KeyPeople  Details
				$orgkeyPeoples			= $this->organization->getKeyPeopleDetailsOfOrg($id);
				
				//Preparing the Array For Exporting
				
				foreach($arrOrganizationDetail as $key=>$orgValue){
						$arrOrganizations =array();
						$arrOrganizations[] =$orgValue['cin_num'];
						$arrOrganizations[] =$orgValue['name'];
						$arrOrganizations[] =$orgValue['type'];
						$arrOrganizations[] =$orgValue['company_logo'];
						$arrOrganizations[] =$orgValue['website'];
						$arrOrganizations[] =$orgValue['headquarters'];
						$arrOrganizations[] =$orgValue['background'];
						$arrOrganizations[] =$orgValue['mission_vision'];
						$arrOrganizations[] =$orgValue['key_products'];
						$arrOrganizations[] =$orgValue['mergers'];
						$arrOrganizations[] =$orgValue['clients'];
						if($orgValue['profile_type']==BASIC){
							$arrOrganizations[] ='Basic';
						}
					if($orgValue['profile_type']==FULL){
							$arrOrganizations[] ='Full Profile';
						}
						$arrOrganizationDetailSheet[] = $arrOrganizations;
						
				}
				
					
		//	pr($arrOrganizationDetailSheet);
				//Preparing the Array For Exporting
				$arrSocialMediaDetails = array();
			//pr($orgSocialMediaDetails);
				foreach($orgSocialMediaDetails as $key=>$orgDetails){
					foreach($orgDetails as $row){
						$arrSocialMediaDetails[]= $row;
					}
				}
				$arrSocialMediaDetailsSheet[]	= $arrSocialMediaDetails;
				
				if(!(empty($orgkeyPeoples))){
					//Preparing the Array For Exporting
					foreach($orgkeyPeoples as $key=>$orgDetails){
						$arrkeyPeoples =array();
						foreach($orgDetails as $row){
							$arrkeyPeoples[]=$row;
						}
						$arrkeyPeoplesSheet[]	= $arrkeyPeoples;
					}
				}
				foreach($orgAdress as $key=>$orgDetails){
					$arrOrgAddress = array();
					$arrOrgAddress[] = $orgDetails['cin_num'];
					$arrOrgAddress[] = $orgDetails['name'];
					$arrOrgAddress[] = $orgDetails['address'];
					$arrOrgAddress[] = $orgDetails['city'];
					$arrOrgAddress[] = $orgDetails['postal_code'];
					$arrOrgAddress[] = $orgDetails['region'];
				
					$arrOrgAddress[] = $orgDetails['country'];
					$arrOrgAddress[] = $orgDetails['phone'];
					$arrOrgAddress[] = $orgDetails['fax'];
					$arrAdditionalContacts=$this->organization->getaddtionalContcat($id);
					//pr($arrAdditionalContacts);
					$phoneDetails='';
					$phoneDetails=implode("\n",$arrAdditionalContacts);
					$arrOrgAddress[]=$phoneDetails;
				
					$arrOrgAddress[] = $orgDetails['key_reginal_offices'];
					$arrOrgAddressSheet[]=$arrOrgAddress;
					
				}
				$arrStatsFacts =  $this->organization->getOrgPayerStatsFacts($id);
				
				foreach($arrStatsFacts as $key=>$statfactDetail){
					$arrStatDetails =array();
					$arrStatDetails[] = $arrOrganizationDetail1[0];
					$arrStatDetails[] = $arrOrganizationDetail1[1];
					$arrStatDetails[] = $statfactDetail['no_of_hospitals'];
					$arrStatDetails[] = $statfactDetail['no_of_physicians'];
					$arrStatDetails[] = $statfactDetail['physicians_employed'];
					$arrStatDetails[] = $statfactDetail['no_of_affiliated'];
					$arrStatDetails[] = $statfactDetail['benefit_management'];
					
					$arrStatDetails[] = $statfactDetail['specialty_pharmacy'];
					$arrStatDetails[] = $statfactDetail['ncqa_status'];
					$arrStatDetails[] = $statfactDetail['start_rating'];
					
					//$arrStatDetails[] = $statfactDetail['ncqa_status'];
					$arrStatDetails[] = $statfactDetail['claims'];
					$arrStatDetails[] = $statfactDetail['processing'];
					
					//if($clientId == INTERNAL_CLIENT_ID){
					///	$arrStatDetails[] = $statfactDetail['link1'];
					//	$arrStatDetails[] = $statfactDetail['link2'];
					//}
					$arrStatFactSheet[] =$arrStatDetails;
				}
				
				$arrEnrollements =  $this->organization->getOrgPayerEnrollements($id);
				//pr($arrEnrollements);
//			$currYear = date("Y") - 1;
//			for($i = $currYear;$i >= $currYear-3;$i-- ){
//				$year[] = $i;
//			}
			
		$arrEnrollements =  $this->organization->getOrgPayerEnrollements($id);
//		$year = $this->get_enrollment_years();
		$arrMaxYearByOrgId = $this->organization->getMaxEnrollYear($id);
//		pr($arrMaxYearByOrgId);
		for($i=2009;$i<=$arrMaxYearByOrgId['maxyear'];$i++){
					$year[] = $i;
				}
//		pr($year);
		$years	= $this->organization->getAllOrgEnrollData($id,$year);
		foreach($arrEnrollements as $row){
			$arr = array();
			$arr[] = $arrOrganizationDetail1[0];
			$arr[] = $arrOrganizationDetail1[1];	
			$arr[] = $row['type'];
//			$arr[] =$years[$row['id']][$year[4]];
//			$arr[] =$years[$row['id']][$year[3]];
//			$arr[] = $years[$row['id']][$year[2]];
//			$arr[] = $years[$row['id']][$year[1]];
//			$arr[] = $years[$row['id']][$year[0]];
			foreach($year as $yr){
				$arr[] =$years[$row['id']][$yr];
			}
			$arrEnrollementSheet[]=$arr;
		}
				
			/*foreach($arrEnrollements as $key=>$arrtDetail){
					$arrEnrollDetails =array();
					$arrEnrollDetails[] = $arrOrganizationDetail1[0];
					$arrEnrollDetails[] = $arrOrganizationDetail1[1];
					$arrEnrollDetails[] = $arrtDetail['type'];
				
					
					
				//$arr = $this->organization->getYearData($arrtDetail['id']);
				//echo $this->db->last_query();
				/*pr($arr);
					foreach($arr as $key1=>$value1){
//					array_push($arrEnrollementSheet[0],$key1);
						$arrEnrollDetails[] = $value1;
				}*/
					
					//$arrEnrollDetails[] = $years[$arrtDetail['id']]['2009'];
					//$arrEnrollDetails[] = $years[$arrtDetail['id']]['2010'];
					//$arrEnrollDetails[] = $years[$arrtDetail['id']]['2011'];
					//$arrEnrollDetails[] = $years[$arrtDetail['id']]['2012'];
//				$arrEnrollDetails[] = $years[$arrtDetail['id']]['2013'];
					
					
					//if($clientId == INTERNAL_CLIENT_ID){
					///	$arrStatDetails[] = $statfactDetail['link1'];
					//	$arrStatDetails[] = $statfactDetail['link2'];
					//}
					
//				$arrEnrollementSheet[] =$arrEnrollDetails;
//			}
				
//			$arrEnrollementSheet[0] = array_unique($arrEnrollementSheet[0]);
					//pr($arrEnrollementSheet[0]);
//			foreach($arrEnrollementSheet[0] as $value){
//				$arrr[]=$value;
//
//			}
//			$arrEnrollementSheet[0] = $arrr;
				$arrFormularies =  $this->organization->getOrgPayerFormularies($id);
				//pr($arrFormularies);
				foreach($arrFormularies as $key=>$arrtDetail){
					$arrFormularies =array();
					$arrFormularies[] = $arrOrganizationDetail1[0];
					$arrFormularies[] = $arrOrganizationDetail1[1];
					$arrFormularies[] = $arrtDetail['drug_name'];
					$arrFormularies[] = $this->organization->getFormularyDrugValues($arrtDetail['id'],DRUG_TIER);
					$arrFormularies[] = $this->organization->getFormularyDrugValues($arrtDetail['id'],PA_CRITERIA);
					
					
					//if($clientId == INTERNAL_CLIENT_ID){
					///	$arrStatDetails[] = $statfactDetail['link1'];
					//	$arrStatDetails[] = $statfactDetail['link2'];
					//}
					$arrFormularyheet[] =$arrFormularies;
				}
				
				$arrManagements =  $this->organization->getOrgPayerDiseaseManagements($id);
				//pr($arrFormularies);
				foreach($arrManagements as $key=>$arrtDetail){
					$arrManagmenDetails =array();
					$arrManagmenDetails[] = $arrOrganizationDetail1[0];
					$arrManagmenDetails[] = $arrOrganizationDetail1[1];
					$arrManagmenDetails[] = $arrtDetail['disease_name'];
					$arrManagmenDetails[] = $this->organization->getPayerDiseaseDropDownValues($arrtDetail['id'],DISEASE_MANAGEMENT_PLATFORMS);
					$arrManagmenDetails[] = $this->organization->getPayerDiseaseDropDownValues($arrtDetail['id'],IDENTIFICATION);
					$arrManagmenDetails[] = $this->organization->getPayerDiseaseDropDownValues($arrtDetail['id'],INTERVENTION);
					$arrManagmenDetails[] = $this->organization->getPayerDiseaseDropDownValues($arrtDetail['id'],MEASUREMENT);
					
					//if($clientId == INTERNAL_CLIENT_ID){
					///	$arrStatDetails[] = $statfactDetail['link1'];
					//	$arrStatDetails[] = $statfactDetail['link2'];
					//}
					$arrManagementSheet[] =$arrManagmenDetails;
				}
				
				$arrCaregories =  $this->organization->getOrgCollabarationCategories();
				$arrRatings		= $this->organization->getOrgCollabarationRatings($id);
				//pr($arrFormularies);
				foreach($arrCaregories as $key=>$category){
					$arrRatinDetails =array();
					$arrRatinDetails[] = $arrOrganizationDetail1[0];
					$arrRatinDetails[] = $arrOrganizationDetail1[1];
					$arrRatinDetails[] = $category;
					if(array_key_exists($key,$arrRatings)){
						$arrRatinDetails[] =$arrRatings[$key];
					}else{
						$arrRatinDetails[]='';
					}
					
					$arrCollabarationSheet[] =$arrRatinDetails;
				}
			}
				
			$workbook = new Spreadsheet_Excel_Writer();
			$workbook->setVersion(8);
			$format_und =& $workbook->addFormat();
			$format_und->setBottom(2);//thick
			$format_und->setBold();
			$format_und->setColor('black');
			$format_und->setFontFamily('Calibri');
			$format_und->setAlign('center');
			$format_und->setSize(11);
				
			$format_reg =& $workbook->addFormat();
			$format_reg->setColor('black');
			$format_reg->setFontFamily('Calibri');
			$format_reg->setSize(11);
		
			$arr = array(
						'COMPANY OVERVIEW'	=> $arrOrganizationDetailSheet,
						'ADDRESS'     		=> $arrOrgAddressSheet,
						'FACTS'  			=>$arrStatFactSheet,
						'ENROLLMENT'  		=>	$arrEnrollementSheet,
						'FORMULARY'   			=>	$arrFormularyheet,
						'DISEASE MANAGEMENT'   =>	$arrManagementSheet,
						'COLLABORATION RATING' =>$arrCollabarationSheet,
						'KEY PEOPLE'   =>	$arrkeyPeoplesSheet,
						'SOCIAL MEDIA' => $arrSocialMediaDetailsSheet
						
			);
			
		foreach($arr as $wbname=>$rows)
			    {

			$rowcount = count($rows);
			$colcount = count($rows[0]);
				
			$worksheet =& $workbook->addWorksheet($wbname);
			//Setting the column width for 'COMPANY OVERVIEW' Sheet
			if($wbname=='COMPANY OVERVIEW'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,50.00);
				$worksheet->setColumn(2,2, 20.00);
				$worksheet->setColumn(3,4, 25.00);
				$worksheet->setColumn(5,7, 60.00);
				$worksheet->setColumn(8,9, 30.00);
				$worksheet->setColumn(10,10, 50.00);

			            }
			//Setting the column width for 'SOCIAL MEDIA' Sheet
			if($wbname=='ENROLLMENT'){
				$worksheet->setColumn(0,0,10.00);
				$worksheet->setColumn(1,1,40.00);
				$worksheet->setColumn(2,2, 20.00);
				$worksheet->setColumn(3,6, 15.00);
					
			            }
			//Setting the column width for 'KEY PEOPLE' Sheet
			if($wbname=='ADDRESS'){

				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,50.00);
				$worksheet->setColumn(2,2, 30.00);
				$worksheet->setColumn(3,3,15.00);
				$worksheet->setColumn(4,6,20.00);
				$worksheet->setColumn(7,7,20.00);
				$worksheet->setColumn(8,8,20.00);
				$worksheet->setColumn(9,9,40.00);
			        }
			if($wbname=='FORMULARY'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,40.00);
				$worksheet->setColumn(2,5, 25.00);
			    }

			if($wbname=='DISEASE MANAGEMENT'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,40.00);
				$worksheet->setColumn(2,2,30.00);
				$worksheet->setColumn(3,3, 50.00);
				$worksheet->setColumn(4,4, 30.00);
				$worksheet->setColumn(5,6, 40.00);
					
			}
			if($wbname=='FACTS'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,30.00);
				$worksheet->setColumn(2,4, 30.00);
				$worksheet->setColumn(5,6, 40.00);
				$worksheet->setColumn(6,7, 30.00);
				$worksheet->setColumn(8,9, 40.00);
				$worksheet->setColumn(10,11, 40.00);
			
			}	
			if($wbname=='AFFILIATES & PARTNERSHIPS'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,40.00);
				$worksheet->setColumn(2,2, 40.00);
				$worksheet->setColumn(3,3, 50.00);
				$worksheet->setColumn(4,8, 30.00);
				$worksheet->setColumn(9,9, 70.00);
			}
	
			if($wbname=='COLLABORATION RATING'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,40.00);
				$worksheet->setColumn(2,2, 50.00);
				$worksheet->setColumn(3,3, 40.00);
							
						}
												
			if($wbname=='KEY PEOPLE'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,50.00);
				$worksheet->setColumn(2,2, 30.00);
				$worksheet->setColumn(3,3,20.00);
				$worksheet->setColumn(4,6,30.00);
				$worksheet->setColumn(7,7,70.00);
				$worksheet->setColumn(8,8,40.00);
					}
				
			if($wbname=='PUBLICATION'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,50.00);
				$worksheet->setColumn(2,2, 50.00);
				$worksheet->setColumn(3,3,15.00);
				$worksheet->setColumn(4,4,50.00);
				$worksheet->setColumn(5,5,10.00);
				$worksheet->setColumn(6,6,50.00);
					}
				
			if($wbname=='TRIAL'){
				$worksheet->setColumn(0,0, 10);//setColumn(startcol,endcol,float)
				$worksheet->setColumn(1,1,40.00);
				$worksheet->setColumn(2,2, 20.00);
				$worksheet->setColumn(3,3,20.00);
				$worksheet->setColumn(4,4,45.00);
				$worksheet->setColumn(5,5,25.00);
				$worksheet->setColumn(6,6,30.00);
				$worksheet->setColumn(7,7,15.00);
				$worksheet->setColumn(8,9,25.00);
				$worksheet->setColumn(10,10,25.00);
				$worksheet->setColumn(11,16,20.00);
				$worksheet->setColumn(17,18,30.00);
				$worksheet->setColumn(19,24,30.00);
			}
			
			    	//Setting the column width for 'SOCIAL MEDIA' Sheet
			if($wbname=='SOCIAL MEDIA'){
				$worksheet->setColumn(1,1,50.00);
				$worksheet->setColumn(2,3, 35.00);
				$worksheet->setColumn(4,5,60.00);
				$worksheet->setColumn(5,6,50.00);
					
            }
							
			for( $j=0; $j<$rowcount; $j++ )
			{
				for($i=0; $i<$colcount;$i++)
				{
					$fmt  =& $format_reg;
					if ($j==0){
						$fmt =& $format_und;
					}
					if (isset($rows[$j][$i]))
					{
						//    $data[]=$rows[$j][$i];
						/*    if($wbname=='ADDRESS'){
						 $wrapFmt=& $format_reg;
						 $wrapFmt->setTextWrap(true);
						 $worksheet->write($j, $i, $data, $wrapFmt);
							}else
							*/
						//   pr($rows[$j][$i]);
						$worksheet->writeString($j, $i, utf8_decode($rows[$j][$i]), $fmt);
					}
				}
						}
					}
		//pr($data);
		//		exit();
		//for downloading the file
		$fileName = $arrOrganizationDetail1[1];
		$workbook->send($fileName.'.xls');
		$workbook->close();
				
		
	}
	
	function add_enrollment($org_id) {
		$data['arrEnrollData1']='';
		$data['orgId'] = $org_id;
		$this->load->view('organizations/add_org_enrollments',$data);
	}
	
	function add_enroll_detail($len){
		$data['created_by']		=	$this->loggedUserId;
		$data['created_on']		=	date("Y-m-d H:i:s");
		$data['client_id']		=	trim($this->session->userdata('client_id'));
		$data['org_id']			=	trim($this->input->post('org_id'));
		$data['type']			=	trim($this->input->post('type'));
		
		$year = $this->get_enrollment_years();
			$orderYear = array_reverse($year);
			for($i=2009;$i<=$len+2009;$i++){
				$varName = "yr".$i;
			$varValue = "val".$i;
				$arrEnroll[$i] = trim($this->input->post($varName));
			$arrEnrollVal[$i] = trim($this->input->post($varValue));
			}
		$lastInsertId = $this->organization->addEnrollmentDetails($data,$arrEnroll,$arrEnrollVal);
		if($lastInsertId){
			$data['status'] 	= true;
			$data['lastId'] 	= $lastInsertId;
			$data['year'] 		= $arrEnroll;
			$data['value'] 		= $arrEnrollVal;
			$data['currYear'] 	= $orderYear;
			
			$this->update->insertUpdateEntry(ORG_ENROLLEMET_ADD, $lastInsertId, MODULE_ORG_ENROLLMENT, $data['org_id']);
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}
		
	function get_enrollment_years() {
		$currYear = date("Y");
		$currMonth = date("m");
		if($currMonth <= 3){
			$currYear = $currYear-1;
		}
		for($i = $currYear;$i >= $currYear-4;$i-- ){
			$year[] = $i;
		}
		return $year;
	}
	
	function edit_enrollment($org_id,$enrollId){
		$data['orgId'] = $org_id;
		$currYear = date("Y");
		$currMonth = date("m");
		if($currMonth <= 3){
			$currYear = $currYear-1;
		}
		for($i = $currYear;$i >= $currYear-2009;$i-- ){
			$year[] = $i;
		}
		$data['arrEnrollData'] = $this->organization->getEnrollmentsById($org_id,$enrollId,$year);
		$this->load->view('organizations/add_org_enrollments',$data);
	}
	
	function update_enroll_detail($len) {
		
		$data['modified_by']		=	$this->loggedUserId;
		$data['modified_on']		=	date("Y-m-d H:i:s");
		$data['client_id']			=	trim($this->session->userdata('client_id'));
		$data['org_id']				=	trim($this->input->post('org_id'));
		$data['type']				=	trim($this->input->post('type'));
		$data['id']					=	trim($this->input->post('id'));
		
		$year = $this->get_enrollment_years();
			$orderYear = array_reverse($year);
			for($i=2009;$i<=$len+2009;$i++){
				$varName = "yr".$i;
			$varValue = "val".$i;
				$arrEnroll[$i] = trim($this->input->post($varName));
			$arrEnrollVal[$i] = trim($this->input->post($varValue));
			}
		if($this->organization->updateEnrollmentDetails($data,$arrEnroll,$arrEnrollVal)){
			$data['status'] 	= true;
			$data['lastId'] 	= $data['id'];
			$data['year'] 		= $arrEnroll;
			$data['value'] 		= $arrEnrollVal;
			$data['currYear'] 	= $orderYear;
			
			$this->update->insertUpdateEntry(ORG_ENROLLEMET_UPDATE, $data['id'], MODULE_ORG_ENROLLMENT, $data['org_id']);
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
		}
	
	function delete_enroll_detail($id) {
		if($this->organization->deleteOrgEnrollById($id)){
			$data['status'] = "true";
			//$this->update->insertUpdateEntry(ORG_ENROLLEMET_DELETE, $id, MODULE_ORG_ENROLLMENT, $data['org_id']);
		}else{
			$data['status'] = "false";
		}
		echo json_encode($data);
	}
	
	function add_formulary($org_id) {
		$data['orgId'] = $org_id;
		$arrFormularyDropdown = $this->organization->getAllFormularyDropdown();
		foreach ($arrFormularyDropdown as $row){
			if($row['type'] == 1){
				$data['drug_tier'][$row['id']] = $row['drug_pa'];
			}else if($row['type'] == 2){
				$data['pa_criteria'][$row['id']] = $row['drug_pa'];
			}
		}
		$this->load->view('organizations/add_org_formulary',$data);
	}
	
	function add_formulary_detail() {
		$arrFormularyDetail['created_by']		=	$this->loggedUserId;
		$arrFormularyDetail['created_on']		=	date("Y-m-d H:i:s");
		$arrFormularyDetail['client_id']		=	$this->session->userdata('client_id');
		$arrFormularyDetail['org_id']			=	$this->input->post('org_id');
		$arrFormularyDetail['drug_name']		=	$this->input->post('name');
		$arrFormularyDetail['drug_pa']			=	$this->input->post('drug_tier');
		$arrFormularyDetail['pa_criteria']		=	$this->input->post('pa_criteria');
		$lastInsertId = $this->organization->addFormularyDetail($arrFormularyDetail);
		if($lastInsertId){
			$arrFormularyDetail['lastId'] = $lastInsertId;
			$arrFormularyDetail['status'] = true;
			$this->update->insertUpdateEntry(ORG_FORMULARY_ADD, $lastInsertId, MODULE_ORG_FORMULARY, $arrFormularyDetail['org_id']);
		}else{
			$arrFormularyDetail['status'] = false;
		}
		echo json_encode($arrFormularyDetail);
	}
	
	function edit_formulary($org_id,$formId) {
		$data['orgId'] = $org_id;
		$arrFormularyDropdown = $this->organization->getAllFormularyDropdown();
			foreach ($arrFormularyDropdown as $row){
				if($row['type'] == 1){
					$data['drug_tier'][$row['id']] = $row['drug_pa'];
				}else if($row['type'] == 2){
					$data['pa_criteria'][$row['id']] = $row['drug_pa'];
				}
			}
		$data['arrFormularyData'] = $this->organization->getFormularyById($formId);	
		$data['arrFormularyMappedData'] = $this->organization->getFormularyMappedById($org_id,$formId);
		$this->load->view('organizations/add_org_formulary',$data);
	}
	
	function update_formulary_detail() {
		$arrFormularyDetail['modified_by']		=	$this->loggedUserId;
		$arrFormularyDetail['modified_on']		=	date("Y-m-d H:i:s");
		$arrFormularyDetail['client_id']		=	$this->session->userdata('client_id');
		$arrFormularyDetail['id']				=	$this->input->post('id');
		$arrFormularyDetail['org_id']			=	$this->input->post('org_id');
		$arrFormularyDetail['drug_name']		=	$this->input->post('name');
		$arrFormularyDetail['drug_pa']			=	$this->input->post('drug_tier');
		$arrFormularyDetail['pa_criteria']		=	$this->input->post('pa_criteria');
		if($this->organization->updateFormularyDetail($arrFormularyDetail)){
			$arrFormularyDetail['lastId'] = $arrFormularyDetail['id'];
			$arrFormularyDetail['status'] = true;
			$this->update->insertUpdateEntry(ORG_FORMULARY_UPDATE, $lastInsertId, MODULE_ORG_FORMULARY, $arrFormularyDetail['org_id']);
		}else{
			$arrFormularyDetail['status'] = false;
		}
		echo json_encode($arrFormularyDetail);
	}
	
	function delete_formulary_detail($id) {
		if($this->organization->deleteOrgFormularyById($id)){
			$data['status'] = "true";
		}else{
			$data['status'] = "false";
		}
		echo json_encode($data);
	}
	function add_disease_management($org_id){
		$arrData['orgId'] = $org_id;
		$arrDiseaseDropdown = $this->organization->getAllDiseaseDropdown();
		foreach ($arrDiseaseDropdown as $key=>$row){
			if($row['type'] == DISEASE_MANAGEMENT_PLATFORMS){
				$arrData['disease_management_platforms'][$row['id']]= $row['value'];
			}else if($row['type'] == IDENTIFICATION){
				$arrData['identification'][$row['id']]= $row['value'];
			}else if($row['type'] == INTERVENTION){
				$arrData['intervention'][$row['id']]= $row['value'];
			}else if($row['type'] == MEASUREMENT){
				$arrData['measurement'][$row['id']]= $row['value'];
			}
		}
		$this->load->view('organizations/add_org_disease_management',$arrData);
	}
	
	function add_disease_management_detail() {
		$arrDiseaseMngmt['created_by']		=	$this->loggedUserId;
		$arrDiseaseMngmt['created_on']		=	date("Y-m-d H:i:s");
		$arrDiseaseMngmt['client_id']		=	$this->session->userdata('client_id');
		$arrDiseaseMngmt['org_id']			=	$this->input->post("org_id");
		$arrDiseaseMngmt['disease_name']	=	$this->input->post("disease_name");
		$arrDiseaseMngmt['dm_platform']		=	$this->input->post("dm_platform");
		$arrDiseaseMngmt['identification']	=	$this->input->post("identification");
		$arrDiseaseMngmt['intervention']	=	$this->input->post("intervention");
		$arrDiseaseMngmt['measurement']		=	$this->input->post("measurement");
		$lastInsertId = $this->organization->addDiseaseManagementDetail($arrDiseaseMngmt);
		if($lastInsertId){
			$arrDiseaseMngmt['lastId']	=	$lastInsertId;	
			$arrDiseaseMngmt['status']	=	true;
			$this->update->insertUpdateEntry(ORG_DISEASE_ADD, $lastInsertId, MODULE_ORG_DISEASE, $arrDiseaseMngmt['org_id']);
		}else{
			$arrDiseaseMngmt['status']	=	false;
		}
		echo json_encode($arrDiseaseMngmt);
	}
	
	function edit_disease_management($org_id,$dmId) {
		$data['orgId'] = $org_id;
		$arrDiseaseDropdown = $this->organization->getAllDiseaseDropdown();
		foreach ($arrDiseaseDropdown as $key=>$row){
			if($row['type'] == DISEASE_MANAGEMENT_PLATFORMS){
				$data['disease_management_platforms'][$row['id']]= $row['value'];
			}else if($row['type'] == IDENTIFICATION){
				$data['identification'][$row['id']]= $row['value'];
			}else if($row['type'] == INTERVENTION){
				$data['intervention'][$row['id']]= $row['value'];
			}else if($row['type'] == MEASUREMENT){
				$data['measurement'][$row['id']]= $row['value'];
			}
		}
		$data['arrDmData'] = $this->organization->getDiseaseManagementById($dmId);	
		$data['arrDmMappedData'] = $this->organization->getDiseaseManagementMappedById($org_id,$dmId);
		$this->load->view('organizations/add_org_disease_management',$data);
	}
	
	function update_disease_management_detail() {
		$arrDiseaseMngmt['modified_by']		=	$this->loggedUserId;
		$arrDiseaseMngmt['modified_on']		=	date("Y-m-d H:i:s");
		$arrDiseaseMngmt['client_id']		=	$this->session->userdata('client_id');
		$arrDiseaseMngmt['id']				=	$this->input->post("id");
		$arrDiseaseMngmt['org_id']			=	$this->input->post("org_id");
		$arrDiseaseMngmt['disease_name']	=	$this->input->post("disease_name");
		$arrDiseaseMngmt['dm_platform']		=	$this->input->post("dm_platform");
		$arrDiseaseMngmt['identification']	=	$this->input->post("identification");
		$arrDiseaseMngmt['intervention']	=	$this->input->post("intervention");
		$arrDiseaseMngmt['measurement']		=	$this->input->post("measurement");
		if($this->organization->updateDiseaseManagementDetail($arrDiseaseMngmt)){
			$arrDiseaseMngmt['lastId']	=	$arrDiseaseMngmt['id'];	
			$arrDiseaseMngmt['status']	=	true;
			$this->update->insertUpdateEntry(ORG_DISEASE_UPDATE, $lastInsertId, MODULE_ORG_DISEASE, $arrDiseaseMngmt['org_id']);
		}else{
			$arrDiseaseMngmt['status']	=	false;
		}
		echo json_encode($arrDiseaseMngmt);
	}
	
	function delete_disease_management_detail($id) {
		if($this->organization->deleteOrgDiseaseManagementById($id)){
			$data['status'] = "true";
		}else{
			$data['status'] = "false";
		}
		echo json_encode($data);
	}
	
	function view_page() {
		$data['contentPage'] 	=	'organizations/abc';
		$this->load->view('layouts/client_view',$data);
	}
	
	function add_collaboration_rating($org_id){
		$data['orgId'] = $org_id;
		$arrCollabRatings = $this->organization->getAllCollabarationRatings();
		$data['arrCollabCat'] 			= $this->organization->getCollaborationCategories();
		foreach ($arrCollabRatings as $key=>$value){
			if($value['category'] == 1){
				$data['arrCollabCat'][0]['cat'][$value['id']]=$value['rating'];
			}else if($value['category'] == 2){
				$data['arrCollabCat'][1]['cat'][$value['id']]=$value['rating'];
			}else if($value['category'] == 3){
				$data['arrCollabCat'][2]['cat'][$value['id']]=$value['rating'];
			}else if($value['category'] == 4){
				$data['arrCollabCat'][3]['cat'][$value['id']]=$value['rating'];
			}else if($value['category'] == 5){
				$data['arrCollabCat'][4]['cat'][$value['id']]=$value['rating'];
			}
		}
		$this->load->view('organizations/add_org_collaboration_category',$data);
//		pr($data);
	}
	
	function add_collaboration_rating_detail() {
//		pr($this->session->userdata);
		$data['created_by']			=	$this->loggedUserId;
		$data['created_on']			=	date("Y-m-d H:i:s");
		$data['client_id']			=	$this->session->userdata('client_id');
		$data['org_id']				=	$this->input->post('org_id');
		$arrCollaData['cat0']		=	$this->input->post('cat0');
		$arrCollaData['cat1']		=	$this->input->post('cat1');
		$arrCollaData['cat2']		=	$this->input->post('cat2');
		$arrCollaData['cat3']		=	$this->input->post('cat3');
		$arrCollaData['cat4']		=	$this->input->post('cat4');
		$arrCollaCat[0]				=	$this->input->post('catKey0');
		$arrCollaCat[1]				=	$this->input->post('catKey1');
		$arrCollaCat[2]				=	$this->input->post('catKey2');
		$arrCollaCat[3]				=	$this->input->post('catKey3');
		$arrCollaCat[4]				=	$this->input->post('catKey4');
		
		$i = 0;
		foreach ($arrCollaData as $k=>$v){
//			if(isset($v) && !empty($v)){
				$arr[$arrCollaCat[$i]] = $v;
//			}
			$i++;
		}	
		if($this->organization->addCollaborationRatingsData($arr,$data)){
			$arrCollaCat['c0'] = $arrCollaCat[0];
			$arrCollaCat['c1'] = $arrCollaCat[1];
			$arrCollaCat['c2'] = $arrCollaCat[2];
			$arrCollaCat['c3'] = $arrCollaCat[3];
			$arrCollaCat['c4'] = $arrCollaCat[4];
			$arrCollaCat['status'] = true;
			$this->update->insertUpdateEntry(ORG_COLLABARATION_ADD, $data['org_id'], MODULE_ORG_COLLABARATION, $data['org_id']);
		}else{
			$arrCollaCat['status'] = false;
		}
		echo json_encode($arrCollaCat);
	}
	
	function edit_collaboration_rating($org_id) {
		$data['orgId'] = $org_id;
		$arrCollabRatings = $this->organization->getAllCollabarationRatings();
		$data['arrCollabCat'] 			= $this->organization->getCollaborationCategories();
		foreach ($arrCollabRatings as $key=>$value){
			if($value['category'] == 1){
				$data['arrCollabCat'][0]['cat'][$value['id']]=$value['rating'];
			}else if($value['category'] == 2){
				$data['arrCollabCat'][1]['cat'][$value['id']]=$value['rating'];
			}else if($value['category'] == 3){
				$data['arrCollabCat'][2]['cat'][$value['id']]=$value['rating'];
			}else if($value['category'] == 4){
				$data['arrCollabCat'][3]['cat'][$value['id']]=$value['rating'];
			}else if($value['category'] == 5){
				$data['arrCollabCat'][4]['cat'][$value['id']]=$value['rating'];
			}
		}
		$data['arrExistRating'] = $this->organization->getAllCollaborationMappedData($org_id);
		$this->load->view('organizations/add_org_collaboration_category',$data);
	}
	
	function export_by_payor($orgId){
		
		$data['type'] = PAYOR;
		$arrOrgDetail = $this->organization->getOrgDetailForPdf($orgId);
		
	
		$filename 	= $arrOrgDetail['name'];
		
		$data['arrDetail'] = $arrOrgDetail;
		
		$arrKeyPeople =  $this->organization->listKeyPeoples($orgId);
			foreach($arrKeyPeople as $row){
				$row1 = array();
				$row1['kol_name'] = $row['salutation']." ".$row['first_name']." ".$row['middle_name']." ".$row['last_name'];
				
				
				$row1['role'] = $row['role_id'];
				$row1['title'] = $row['title'];
				$row1['department'] = $row['department'];
				$arrKeyPeoples[]    = $row1;
			}
			//pr($arrDetails);
		$data['arrKeyPeoples'] = $arrKeyPeoples;
		
		
		$arrAssocPeople	=  $this->organization->listOrgAssociatedPpl($orgId);
		//	pr($arrAssocPeople);
		foreach($arrAssocPeople as $people){
			$arrDetail = array();
			$arrDetail['kol_name'] = $arrSalutations[$people['salutation']]." ".$people['first_name']." ".$people['middle_name']." ".$people['last_name'];
			$arrDetail['title'] = $people['title'];
			$arrDetail['department'] = $people['division'];
			$arrDetail['role'] = 'Associated People';
			$arrAssociltedPeople[]=$arrDetail;
		}
		$data['arrAssociltedPeople'] = $arrAssociltedPeople;
		
		$arrStatsFacts =  $this->organization->getOrgPayerStatsFacts($orgId);
		$data['arrFacts'] = $arrStatsFacts;
			
		$arrEnrollements =  $this->organization->getOrgPayerEnrollements($orgId);
		$year = $this->get_enrollment_years();
				$years	= $this->organization->getAllOrgEnrollData($orgId,$year);
		foreach($arrEnrollements as $row){
			$arr = array();
			
			$arr['type'] = $row['type'];
			$arr[$year[0]] = $years[$row['id']][$year[0]];
			$arr[$year[1]] = $years[$row['id']][$year[1]];
			$arr[$year[2]] = $years[$row['id']][$year[2]];
			$arr[$year[3]] =$years[$row['id']][$year[3]];
			$arr[$year[4]] =$years[$row['id']][$year[4]];
			$arrEnrollements1[]=$arr;
		}
		$data['year'] =$year;
		$data['arrEnrollements'] =$arrEnrollements1;
		
		$arrFormularies =  $this->organization->getOrgPayerFormularies($orgId);
		//pr($arrFormularies);
		foreach($arrFormularies as $key=>$arrtDetail){
		
	
			$arrtDetail['drugs'] = $this->organization->getFormularyDrugValues($arrtDetail['id'],DRUG_TIER);
			$arrtDetail['criteria'] = $this->organization->getFormularyDrugValues($arrtDetail['id'],PA_CRITERIA);
			$arrtDetail1[] =$arrtDetail;
		}
		
		$data['arrFormularies'] =$arrtDetail1;
		
		$arrManagements =  $this->organization->getOrgPayerDiseaseManagements($orgId);
		//pr($arrFormularies);
		foreach($arrManagements as $key=>$arrtDetail){
			$arrManagmenDetails =array();
		
			$arrManagmenDetails['disease_name'] = $arrtDetail['disease_name'];
			$arrManagmenDetails['plat_forms'] = $this->organization->getPayerDiseaseDropDownValues($arrtDetail['id'],DISEASE_MANAGEMENT_PLATFORMS);
			$arrManagmenDetails['identification'] = $this->organization->getPayerDiseaseDropDownValues($arrtDetail['id'],IDENTIFICATION);
			$arrManagmenDetails['intervention'] = $this->organization->getPayerDiseaseDropDownValues($arrtDetail['id'],INTERVENTION);
			$arrManagmenDetails['measurement'] = $this->organization->getPayerDiseaseDropDownValues($arrtDetail['id'],MEASUREMENT);
			
			//if($clientId == INTERNAL_CLIENT_ID){
			///	$arrStatDetails[] = $statfactDetail['link1'];
			//	$arrStatDetails[] = $statfactDetail['link2'];
			//}
			$arrManagementSheet[] =$arrManagmenDetails;
		}
		
		$data['arrManagements'] =$arrManagementSheet;
		
		$arrCaregories =  $this->organization->getOrgCollabarationCategories();
		$arrRatings		= $this->organization->getOrgCollabarationRatings($orgId);
		foreach($arrCaregories as $key=>$category){
			$arrRatinDetails =array();
			
			$arrRatinDetails['category'] = $category;
			if(array_key_exists($key,$arrRatings)){
				$arrRatinDetails['rating'] =$arrRatings[$key];
			}else{
				$arrRatinDetails['rating']='';
			}
			
			$arrCollabarationSheet[] =$arrRatinDetails;
		}
		
		$data['arrCollabarations'] =$arrCollabarationSheet;
		//$this->load->view('organizations/export/org_pdf',$data);
		$html = $this->load->view('organizations/export/org_pdf',$data,true);
		pdf_create($html, $filename);
		
	}
	
	function add_client_org($orgId){
		$arrData['orgName']		= $this->organization->getOrgNameByOrgId($orgId);
		$arrData['arrCountry']	= $this->Country_helper->listCountries();
		$this->load->view('organizations/add_client_org',$arrData);
	}
	
	function add_client_org_request($orgId){
		$arrData['orgData']		= $this->organization->getOrgDataByOrgId($orgId);
		$arrData['arrCountry']	= $this->Country_helper->listCountries();
		if($arrData['orgData']['state_id'] != 0){
			$arrData['arrState']	= $this->Country_helper->getStatesByCountryId($arrData['orgData']['country_id']);
		}
		if($arrData['orgData']['city_id'] != 0){
			$arrData['arrCity']	= $this->Country_helper->getCitiesByStateId($arrData['orgData']['state_id']);
		}
//		pr($arrData['orgData']);
		$this->load->view('organizations/add_client_org',$arrData);
	}

	function remove_comma_from_enrollment() {
		$res = $this->db->get('org_enrollment_years');
		foreach ($res->result_array() as $row){
			$retData[$row['id']] =$row['value'];// preg_replace("/[^0-9]/", "", $row['value']);//trim($row['value']);
			$this->db->where('id',$row['id']);
			$row['value'] = preg_replace("/[^0-9]/", "", $row['value']);
			$this->db->update('org_enrollment_years',$row); 
		}
		pr($retData);
	}

	/* Getting organization data for "micro view"
	 * 
	 * 
	 */
	function view_micro_profile_for_org_request($orgId){
		$count='';
		$arrOrg=array();
		$arrOrg = $this->organization->getOrgMicroData($orgId);
		$data['arrOrg']=$arrOrg;
		$data['kyePeopleCount']=$this->organization->kyePeopleCount($orgId);
		$data['associatedPplCount']=$this->organization->getOrgAssociatedPplCount($orgId);
		$data['associatedPplCount'] = $data['kyePeopleCount']+$data['associatedPplCount'];
		if($data['arrOrg'][0]['city_id']!=0){
			$data['arrOrg'][0]['city']=$this->Country_helper->getCityeById($data['arrOrg'][0]['city_id']);
		}
		if($data['arrOrg'][0]['state_id']!=0){
			$data['arrOrg'][0]['state']=$this->Country_helper->getStateById($data['arrOrg'][0]['state_id']);
			$data['arrOrg'][0]['state_code']	=	$this->Country_helper->getStatecodeByStateIdorName($data['arrOrg'][0]['state_id'],'id');
		}
		$this->load->view('organizations/view_micro_profile_for_org_request',$data);
	}

	function import_page(){
		$data ['contentPage'] = 'organizations/import_page';
		$this->load->view ( 'layouts/analyst_view', $data );
	}
	
	function read_and_import_org_files(){
			ini_set("max_execution_time",7200);
		$arrCountries	=$this->Country_helper->listCountries();
		$arrStates		=$this->Country_helper->listStates();
		$arrCities		=$this->Country_helper->listCities();
		$arrKeyPeopleRoles=$this->organization->getAllKeyPeopleRoles();
		$organizationTypes=$this->organization->getAllOrganizationTypes();
			
		// Load the plugin
		$this->load->plugin('excelReader/reader2');
		$userId		=$this->session->userdata('user_id');
		$clientId	=$this->session->userdata('client_id');
		$initialTime = microtime(true);
		ini_set("memory_limit","2000M");
		$uhPath = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_profiles/uh/";
		//$arrUHFiles = $this->input->post('uh_files');
		
		$files = $this->input->post('files');
		$arrFiles = array();
		$organizationDetailCount = array();
		foreach($files as $row){
			$pos = strpos($row,'&');
			$folderNAme = substr($row,0,$pos);
			$arrFiles[$folderNAme][]=substr($row,$pos+1);
		}
		foreach($arrFiles as $folderName=>$uniFiles) {
				foreach($uniFiles as $name){
					$arrImportStatusMsg[$name]=array();
					$startTime = microtime(true);
					// Increasing the max execution time to pasrse all sheet data
				
					$orgID		= 0;
					$target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_imports/university/uploaded/";
					$overviewFileName	= random_string('unique', 20);
					$name= str_replace(';', '', $name);
					$overview_file_target_path = $target_path . "/".$folderName."/".$name;
					if(true){
						if(true){
							if(true) {
								$reader				=	new Spreadsheet_Excel_Reader($overview_file_target_path, true, 'utf-8');
								//loop through each sheet
								foreach($reader->sheets as $k=>$details){
									//Parsing of 1st sheet  - Overview: $k = index of the sheet
									if($k==0){
										$numColumns=0;
										$existingOrgs=array();
										$row=1;
										foreach($details['cells'] as $data){
											if($row==1){
												//condition to check whether format of the column is correct or not
												if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="COMPANY TYPE" || trim($data[4])!="LOGO" || trim($data[5])!="WEBSITE"
												|| trim($data[6])!="COMPANY HEADQUARTERS" || trim($data[7])!="COMPANY BACKGROUND" || trim($data[8])!="MISSION, VISION & VALUES"  ||trim($data[9])!="FOUNDED" || trim($data[10])!="NPI NUMBER"){
													$arrImportStatusMsg[$name]['overview']['incorrect_format']='Uploaded File format is incorrect';
													break;
												}
												$numColumns=sizeof($data);
											}
											$organizationDetails=array();
											if($row>1){
												for($i=1;$i<=$numColumns;$i++){
													if(!isset($data[$i]))
													$data[$i]="";
												}
												$organizationDetails['cin_num']=trim($data[1]);
												//$organizationDetails['name']=ucwords(trim($data[2]));
												$organizationDetails['name']=trim($data[2]);
												$orgType=array_search(trim($data[3]),$organizationTypes);
												$organizationDetails['type_id']=$orgType;
												$organizationDetails['company_logo']=trim($data[4]);
												$organizationDetails['website']=trim($data[5]);
												$organizationDetails['headquarters']=trim($data[6]);
												$organizationDetails['background']=trim($data[7]);
												$organizationDetails['mission_vision']=trim($data[8]);
												$organizationDetails['founded']=trim($data[9]);
												$organizationDetails['npi_num']=trim($data[10]);
												$organizationDetails['profile_type'] = FULL;
												$profilType = trim($data[11]);
												if($profilType=='Basic'){
													$organizationDetails['profile_type'] =BASIC;
												}
												if($profilType=='Full Profile'){
													$organizationDetails['profile_type'] =FULL;
												}
												$organizationDetails['url']=trim($data[12]);
												$organizationDetails['status']=New1;
												$organizationDetails['created_by']	=$userId;
												$organizationDetails['created_on']	=date("Y-m-d H:i:s");
												//Save only if the 'cin_num' is not blank
												if($organizationDetails['cin_num']!=""){
													$id=$this->organization->saveOrganization($organizationDetails);
													//  echo $this->db->last_query();
													if($id==false){
														//array of already existing organizations
														$existingOrgs[]=$organizationDetails['name'].' has been updated';
													}else{
														$orgID	= $id;
													}
												}else{
													//aray of organizations having no 'cin_num'
													$arrImportStatusMsg[$name]['overview']['no_cin_num'][]= $organizationDetails['name'];
												}
			
											}
											$row++;
											$arrImportStatusMsg[$name]['overview']['success']=true;
										}
										$arrImportStatusMsg[$name]['overview']['existingOrgs']=$existingOrgs;
										
									}
			
									else if($k==1){
										//Parsing of 2st sheet  - Adress: $k = index of the sheet
										$numColumns=0;
										$row=1;
										foreach ($details['cells'] as $data) {
											//check wherether format is correct or not
											if($row==1){
												if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="ADDRESS" || trim($data[4])!="CITY" || trim($data[5])!="POSTAL CODE"
												|| trim($data[6])!="STATE" || trim($data[7])!="COUNTRY" || trim($data[8])!="PHONE" || trim($data[9])!="FAX" || trim($data[10])!="ADDITIONAL PHONE NUMBERS"){
													$arrImportStatusMsg[$name]['address']['incorrect_format']='Uploaded File format is incorrect';
													break;
												}
												$numColumns=sizeof($data);
											}
											$organizationDetails=array();
											if($row>1){
												for($i=1;$i<=$numColumns;$i++){
													if(!isset($data[$i]))
													$data[$i]="";
												}
												$countryId=0;
												$stateId=0;
												$cityId=0;
												$organizationDetails['cin_num']=trim($data[1]);
												$organizationDetails['name']=trim($data[2]);
												$organizationDetails['address']=trim($data[3]);
												
												/*if(array_key_exists(ucwords(trim($data[4])),$arrCities))
												$cityId=$arrCities[ucwords(trim($data[4]))]['city_id'];
												$organizationDetails['city_id']=$cityId;*/
												
												$organizationDetails['postal_code']=trim($data[5]);
												if(array_key_exists(ucwords(trim($data[6])),$arrStates))
												$stateId=$arrStates[ucwords(trim($data[6]))]['state_id'];
												$organizationDetails['state_id']=$stateId;
												$city					= ucwords(trim($data[4]));
												if($city!=''){
									 				$organizationDetails['city_id']= $this->kol->getCityIdByState($city,$stateId);
												}
												
												if(array_key_exists(ucwords(trim($data[7])),$arrCountries))
												$countryId=$arrCountries[ucwords(trim($data[7]))]['country_id'];
												$organizationDetails['country_id']=$countryId;
												$organizationDetails['phone']=trim($data[8]);
												$organizationDetails['fax']=trim($data[9]);
												$faxDetails=explode(" ",$organizationDetails['fax']);
												$arrFaxValues=array();
												$faxNumber="";
												foreach($faxDetails as $value){
													if(strpos($value, "+")!=false){
														$faxNumber.=trim($value);
													}
													if(is_numeric($value)){
														$faxNumber.=trim($value);
													}
												}
												$organizationDetails['addr_url']=trim($data[11]);
												$organizationDetails['email']=trim($data[12]);
												$organizationDetails['created_by']	=$userId;
												$organizationDetails['created_on']	=date("Y-m-d H:i:s");
												 
												//Save only if the 'cin_num' is not blank
												if($organizationDetails['cin_num']!=""){
													$orgID =$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
													if($orgID>0){
														$organizationDetails['id']	= $orgID;
													}
													$id=$this->organization->updateImportedOrganization($organizationDetails);
													if($id==false){
														//array of 'cin_num' not present in database
														$arrImportStatusMsg[$name]['address']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
													}
												}else{
													//aray of organizations  having no 'cin_num'
													$arrImportStatusMsg[$name]['address']['no_cin_num'][]= $organizationDetails['name'];
												}
												 
												//Parsing and saving additional contact details
												if($organizationDetails['cin_num']!=""){
													$arrContactDetails=array();
													$orgId=$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
													$aditionalContats=trim($data[10]);
													$arrAditionalContactDetails=explode("\n",$aditionalContats);
													foreach($arrAditionalContactDetails as $aditionalContat){
														$contactDetails=array();
														$phNumber="";
														$relatedTo="";
														if(strpos($aditionalContat, "-")!=false){
															$aditionalContatDetails=explode("-",$aditionalContat);
															foreach($aditionalContatDetails as $value){
																if(strpos($value, "+")!=false){
																	$phNumber.=trim($value);
																}else if(is_numeric($value)){
																	$phNumber.=trim($value);
																}else {
																	$relatedTo.=trim($value);
																}
															}
														}else if(strpos($aditionalContat, ":")!=false){
			
															//echo $aditionalContat;
															$aditionalContatDetails=explode(":",$aditionalContat);
															$contactDetails['related_to']=$aditionalContatDetails[0];
															$contactDetails['phone']=$aditionalContatDetails[1];
														}else{
															$aditionalContatDetails=explode(" ",$aditionalContat);
														}
														$arrContactDetails[]=$contactDetails;
													}
													if($orgId!=0){
														//save additional contact details
														foreach($arrContactDetails as $row){
															$row['org_id']=$orgId;
															$row['created_by']	=$userId;
															$row['created_on']	=date("Y-m-d H:i:s");
															$this->organization->saveContact($row);
														}
													}else{
														//set error details
													}
												}
											}
											$row++;
											$arrImportStatusMsg[$name]['address']['success']=true;
										}
									}
									else if($k==2){
										$bulkInsertOfMedical =array();
										$medicalService =1;
										//Parsing of 3st sheet  - Mediacal Services: $k = index of the sheet
										$numColumns=0;
										$row=1;
											
										foreach($details['cells'] as $key=>$data) {
											if($row==1){
												if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!='MEDICAL SERVICES' || trim($data[4])!='URL'){
													$arrImportStatusMsg[$name]['mediacal_services']['incorrect_format']='Uploaded File format is incorrect';
													break;
												}
												$numColumns=sizeof($data);
											}
											$medicalServiceDataDetails=array();
											if($row>1){
												for($i=1;$i<=$numColumns;$i++){
													if(!isset($data[$i]))
													$data[$i]="";
												}
												$cinNum  = trim($data[1]);
												//$orgName =ucwords(trim($data[2]));
												$orgName =trim($data[2]);
												 
												$medicalServiceName=trim($data[3]);
												$medicalServiceDataDetails['url'] = trim($data[4]);
												if($medicalServiceName!=''){
													$medicalServiceDataDetails['medical_service_id'] = $this->organization->saveOrgMedicalService($medicalServiceName);
													 
												}
												//Save only if the 'cin_num' is not blank
												if($cinNum!=""){
													$orgID	= $this->organization->getOrgIdBySinNumber($cinNum);
													$medicalServiceDataDetails['org_id'] =$orgID;
													if($orgID==0){
														//array of 'cin_num' not present in database
														$arrImportStatusMsg[$name]['mediacal_services']['no_matching_cin_num'][]= $cinNum;
													}else{
														
													if(!(isset($organizationDetailCount[$orgID]['medicalCount']))){
														$organizationDetailCount[$orgID]['medicalCount'] = $this->organization->getCountOfMedical($orgID);
														//echo $this->db->last_query();
													}
														$bulkInsertOfMedical[] = $medicalServiceDataDetails;
														
														
														//$this->organization->saveOrgMediacalAssociation($medicalServiceDataDetails);
														//echo $this->db->last_query();
													}
												}else{
													//aray of address detains having no 'cin_num'
													$arrImportStatusMsg[$name]['mediacal_services']['no_cin_num'][]= $orgName;
												}
			
											}
											$row++;
											$arrImportStatusMsg[$name]['mediacal_services']['success']=true;
										}
										
										//pr($organizationDetailCount);
										$this->organization->OrgMediacalServicesByBulk($bulkInsertOfMedical);
									//	exit();
										
									}
									else if($k==3){
										$arrAffliationDetails = array();
										//Parsing of 3st sheet  - Affiliate patnership: $k = index of the sheet
										$numColumns=0;
										$row=1;
										foreach($details['cells'] as $key=>$data) {
											if($row==1){
												if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!='INSTITUTE NAME'
												|| trim($data[4])!='ADDRESS' || trim($data[5])!='CITY' || trim($data[6])!='POSTAL CODE'
												|| trim($data[7])!='STATE'|| trim($data[8])!='COUNTRY'|| trim($data[9])!='PHONE' ||   trim($data[10])!='NPI NUMBER'
												){
													$arrImportStatusMsg[$name]['affiliate_patnership']['incorrect_format']='Uploaded File format is incorrect';
													break;
												}
												$numColumns=sizeof($data);
											}
											$otherLoactionDetails=array();
											if($row>1){
												for($i=1;$i<=$numColumns;$i++){
													if(!isset($data[$i]))
													$data[$i]="";
												}
												$cinNum  = trim($data[1]);
												//$orgName =ucwords(trim($data[2]));
												$orgName =trim($data[2]);
												$subOrgName = trim($data[3]);
												//$subOrgName = ucwords($subOrgName);
												$otherLoactionDetails['address'] = trim($data[4]);
												
												/*if(array_key_exists(ucwords(trim($data[5])),$arrCities))
												$cityId=$arrCities[ucwords(trim($data[5]))]['city_id'];
												$otherLoactionDetails['city_id']=$cityId;*/
												
												$otherLoactionDetails['postal_code']=trim($data[6]);
												if(array_key_exists(ucwords(trim($data[7])),$arrStates))
												$stateId=$arrStates[ucwords(trim($data[7]))]['state_id'];
												$otherLoactionDetails['state_id']=$stateId;
												
												$city					= ucwords(trim($data[5]));
												if($city!=''){
									 				$otherLoactionDetails['city_id']= $this->kol->getCityIdByState($city,$stateId);
												}
												
												if(array_key_exists(ucwords(trim($data[8])),$arrCountries))
												$countryId=$arrCountries[ucwords(trim($data[8]))]['country_id'];
												$otherLoactionDetails['country_id']=$countryId;
												 
												$otherLoactionDetails['phone']=$data[9];
												$otherLoactionDetails['npi_num']=$data[10];
												$otherLoactionDetails['url']=$data[11];
												
												if($cinNum!=''){
													$otherLoactionDetails['org_id'] =$this->organization->getOrgIdBySinNumber($cinNum);
													if($otherLoactionDetails['org_id']!=0){
														//echo $this->db->last_query();
														$orgDetails['name'] = $subOrgName;
														$orgDetails['address'] = $otherLoactionDetails['address'];
														$orgDetails['city_id']=$otherLoactionDetails['city_id'];
														$orgDetails['state_id']=$otherLoactionDetails['state_id'];
														$orgDetails['country_id']=$otherLoactionDetails['country_id'];
														$orgDetails['postal_code']=$otherLoactionDetails['postal_code'];
														$orgDetails['email']=trim($data[12]);
														$orgDetails['phone']=$otherLoactionDetails['phone'];
														$orgDetails['status'] ='new';
														$orgDetails['created_by']	=$userId;
														$orgDetails['created_on']	=date("Y-m-d H:i:s");
														$otherLoactionDetails['sub_org_id'] = $this->organization->getOrgId($orgDetails);
														$arrAffliationDetails[]=$otherLoactionDetails;
													if(!(isset($organizationDetailCount[$otherLoactionDetails['org_id']]['affiliateCount']))){
														$organizationDetailCount[$otherLoactionDetails['org_id']]['affiliateCount'] = $this->organization->getCountOfAffiliates($otherLoactionDetails['org_id']);
														//echo $this->db->last_query();
													}
														$this->organization->saveAffiliatesPartnerships($otherLoactionDetails);
													}else{
			
														$arrImportStatusMsg[$name]['affiliate_patnership']['no_matching_cin_num'][]= $cinNum;
													}
												}else{
													//aray of address detains having no 'cin_num'
													$arrImportStatusMsg[$name]['affiliate_patnership']['no_cin_num'][]=$orgName;
												}
											}
											$row++;
											$arrImportStatusMsg[$name]['other_locations']['success']=true;
										}
										
										//$this->organization->saveAffiliatesPartnershipsBulk($arrAffliationDetails);
									}
										
								 else if($k==4){
								 	//Parsing of 3st sheet  - Social Media : $k = index of the sheet
								 	$numColumns=0;
								 	$row=1;
								 	foreach($details['cells'] as $data) {
								 		if($row==1){
								 			if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="BLOG" || trim($data[4])!="YOUTUBE" || trim($data[5])!="LINKEDIN"
								 			|| trim($data[6])!="FACEBOOK" || trim($data[7])!="TWITTER" ){
								 				$arrImportStatusMsg[$name]['social_media']['incorrect_format']='Uploaded File format is incorrect';
								 				break;
								 			}
								 			$numColumns=sizeof($data);
								 		}
								 		$organizationDetails=array();
								 		if($row>1){
								 			for($i=1;$i<=$numColumns;$i++){
								 				if(!isset($data[$i]))
								 				$data[$i]="";
								 			}
								 			$organizationDetails['cin_num']=trim($data[1]);
								 			//$organizationDetails['name']=ucwords(trim($data[2]));
								 			$organizationDetails['name']=trim($data[2]);
			
								 			$organizationDetails['blog']=trim($data[3]);
								 			$organizationDetails['youtube']=trim($data[4]);
								 			$organizationDetails['linkedin']=trim($data[5]);
								 			$organizationDetails['facebook']=trim($data[6]);
								 			//$organizationDetails['myspace']=trim($data[7]);
								 			$organizationDetails['twitter']=trim($data[7]);
			
								 			$organizationDetails['created_by']	=$userId;
								 			$organizationDetails['created_on']	=date("Y-m-d H:i:s");
			
								 			//Save only if the 'cin_num' is not blank
								 			if($organizationDetails['cin_num']!=""){
								 				$orgID	= $this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
								 				if($orgID>0){
								 					$organizationDetails['id']	= $orgID;
								 				}
								 				$id=$this->organization->updateImportedOrganization($organizationDetails);
								 				if($id==false){
								 					//array of 'cin_num' not present in database
								 					$arrImportStatusMsg[$name]['social_media']['no_matching_cin_num'][]= $organizationDetails['name'];
								 				}
								 			}else{
								 				//aray of address detains having no 'cin_num'
								 				$arrImportStatusMsg[$name]['social_media']['no_cin_num'][]= $organizationDetails['name'];
								 			}
			
								 		}
								 		$row++;
								 		$arrImportStatusMsg[$name]['social_media']['success']=true;
								 	}
								 }
								 else if($k==5){
								 	$arrKeyPeopleDetails = array();
								 	$kePeople=1;
								 	//Parsing of 4th sheet  -key_people: $k = index of the sheet
								 	$numColumns=0;
								 	$row=1;
										$arrSalutations	= array(''=>0,'Dr.' => 1, 'Prof.' => 2, 'Mr.' => 3, 'Ms.' =>4);
										foreach($details['cells'] as $data) {
											if($row==1){
												if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="ROLE" || trim($data[4])!="SALUTATION" || trim($data[5])!="FIRST NAME"
												|| trim($data[6])!="MIDDLE NAME" || trim($data[7])!="LAST NAME" || trim($data[8])!="DEPARTMENT/DIVISION/CENTER" || trim($data[9])!="TITLE" || trim($data[10])!="EMAIL" ){
													$arrImportStatusMsg[$name]['key_people']['incorrect_format']='Uploaded File format is incorrect';
													break;
												}
												$numColumns=sizeof($data);
											}
											$organizationDetails=array();
											if($row>1){
												for($i=1;$i<=$numColumns;$i++){
													if(!isset($data[$i]))
													$data[$i]="";
												}
												$organizationDetails['cin_num']=trim($data[1]);
												//$organizationDetails['name']=ucwords(trim($data[2]));
												$organizationDetails['name']=trim($data[2]);
												$roleId=array_search(trim(strtolower($data[3])),array_map('strtolower',$arrKeyPeopleRoles));//array_search(trim($data[3]),$arrKeyPeopleRoles);
												$keyPeopleDetails['role_id']=$roleId;
												$keyPeopleDetails['salutation']=$arrSalutations[trim($data[4])];
												$keyPeopleDetails['first_name']=trim($data[5]);
												$keyPeopleDetails['middle_name']=trim($data[6]);
												$keyPeopleDetails['last_name']=trim($data[7]);
												$keyPeopleDetails['department']=trim($data[8]);
												$keyPeopleDetails['title']=trim($data[9]);
												$keyPeopleDetails['email']=trim($data[10]);
												$keyPeopleDetails['url']=trim($data[11]);
			
												$keyPeopleDetails['created_by']	=$userId;
												$keyPeopleDetails['created_on']	=date("Y-m-d H:i:s");
												//Save only if the 'cin_num' is not blank
												if($organizationDetails['cin_num']!=""){
													$orgId=$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
													if($orgId==0){
														$orgId=$this->organization->getOrgIdByOrgName($organizationDetails['name']);
													}
													if($orgId!=0){
														$keyPeopleDetails['org_id']=$orgId;
														//if($kePeople ==1){
															//$this->organization->deleteKeyPeopleByOrgId($orgId);
															//$kePeople++;
														//}
													if(!(isset($organizationDetailCount[$orgId]['keyPeopleCount']))){
														$organizationDetailCount[$orgId]['keyPeopleCount'] = $this->organization->getCountOfKeyPeople($orgId);
														//echo $this->db->last_query();
													}
														
														$arrKeyPeopleDetails[] = $keyPeopleDetails;
														//$this->organization->saveKeyPeople($keyPeopleDetails);
													}else{
															
														$arrImportStatusMsg[$name]['key_people']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
													}
												}else{
													//aray of address detains having no 'cin_num'
													$arrImportStatusMsg[$name]['key_people']['no_cin_num'][]= $organizationDetails['name'];
												}
			
											}
											$row++;
											$arrImportStatusMsg[$name]['key_people']['success']=true;
										}
										
										$this->organization->saveKeyPeopleBulk($arrKeyPeopleDetails);
								 }
			
								 else if($k==7){
								 	$fact=1;
								 	//Parsing of 7th sheet  - Stats Facts: $k = index of the sheet
										foreach($details['cells'] as $factKey=>$facts){
										 if($factKey==1){
										 	if(trim($facts[1])!="CIN NUM" || trim($facts[2])!="COMPANY NAME" || trim($facts[3])!="NO. OF BEDS"){
										 		$arrImportStatusMsg[$name]['stats_facts']['incorrect_format']='Uploaded File format is incorrect';
										 		break;
										 	}
										 		
										 	if(trim($facts[4])!="INPATIENT"  || trim($facts[5])!="BIRTHS" || trim($facts[6])!="OUTPATIENT"){
										 		$arrImportStatusMsg[$name]['stats_facts']['incorrect_format']='Uploaded File format is incorrect';
										 		break;
										 	}
										 		
										 	if( trim($facts[7])!="EMERGENCY DEPARTMENT" || trim($facts[8])!="NO. OF SURGERIES" ){
										 		$arrImportStatusMsg[$name]['stats_facts']['incorrect_format']='Uploaded File format is incorrect';
										 		break;
										 	}
										 	$numColumns=sizeof($facts);
										 }
											if($factKey!=1){
												$factDataDetails=array();
												$cinNum = $facts[1];
			
												$factDataDetails["no_of_beds"] 		= $facts[3];
												$factDataDetails["inpatient"]		= $facts[4];
			
												$factDataDetails["births"] 	 	    = $facts[5];
												$factDataDetails['outpatient']		= $facts[6];
												$factDataDetails["emergency_department"] 	  = $facts[7];
												$factDataDetails["no_of_surgeries"] 	  	  = $facts[8];
												$factDataDetails['link1'] = $facts[9];
												$factDataDetails['link2'] = $facts[10];
												if($cinNum!=''){
													$factDataDetails['org_id'] =$this->organization->getOrgIdBySinNumber($cinNum);
													if($factDataDetails['org_id']!=0){
														$this->organization->orgStatsFacats($factDataDetails);
														///if($fact==1){
															//$this->organization->deleteFacts($orgId);
															//$fact++;
														//}
			
													}else{
			
														$arrImportStatusMsg[$name]['stats_facts']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
													}
												}else{
													//aray of address detains having no 'cin_num'
													$arrImportStatusMsg[$name]['stats_facts']['no_cin_num'][]= $organizationDetails['name'];
												}
											}
											$arrImportStatusMsg[$name]['stats_facts']['success']=true;
			
										}
								 }
								 else if($k==8){
								 	//Parsing of 8th sheet  - Publication: $k = index of the sheet
										foreach($details['cells'] as $sub=>$orgPubData){
										 if($sub==1){
										 	if(trim($orgPubData[1])!="CIN NUM" || trim($orgPubData[2])!="COMPANY NAME" || trim($orgPubData[3])!="Article Title" ||  trim($orgPubData[4])!="PMID" || trim($orgPubData[5])!="Journal Name" || trim($orgPubData[6])!="Date" || trim($orgPubData[7])!="Authors" ){
										 		$arrImportStatusMsg[$name]['publication']['incorrect_format']='Uploaded File format is incorrect';
										 		break;
										 	}
										 		
										 	$numColumns=sizeof($data);
										 }
											if($sub!=1){
												$orgPubDetails=array();
												$cinNum = $orgPubData[1];
												$orgName =$orgPubData[2];
												$orgPubDetails['pmid'] = $orgPubData[4];
			
												if($cinNum!=""){
													$orgPubDetails['org_id'] =$this->organization->getOrgIdBySinNumber($cinNum);
													if($orgPubDetails['org_id'] ==0){
														//array of 'pin' not present in database
														$arrImportStatusMsg[$name]['publication']['no_matching_cin_num'][]= $cinNum;
													}else{
													
														if(!(isset($organizationDetailCount[$orgPubDetails['org_id']]['pmidCount']))){
														$organizationDetailCount[$orgPubDetails['org_id']]['pmidCount'] = $this->organization->getCountOfPmids($orgPubDetails['org_id']);
														//echo $this->db->last_query();
														}
														$status = $this->pubmed_org->saveOrgPMID($orgPubDetails);
														if($status == false)
														$arrImportStatusMsg[$name]['publication']['pmid_exist'][]= $orgPubDetails['pmid'];
			
														$orgPubmedStatusData = array();
														$orgPubmedStatusData['id'] = $orgPubDetails['org_id'];
														$orgPubmedStatusData['is_pubmed_processed'] = 2;
														$this->pubmed_org->updatePubmedProcessedOrg($orgPubmedStatusData);
													}
												}else{
													//aray of media having no 'pin'
													$arrImportStatusMsg[$name]['publication']['no_pin_num'][]=  $orgName;
												}
											}
											$arrImportStatusMsg[$name]['publication']['success']=true;
			
										}
			
								 }
								 else if($k==9){
								 	//Parsing of 9th sheet  - Trial: $k = index of the sheet
										foreach($details['cells'] as $sub=>$orgClinicalData){
										 if($sub==1){
										 	if(trim($orgClinicalData[1])!="CIN NUM" || trim($orgClinicalData[2])!="COMPANY NAME" || trim($orgClinicalData[3])!="CTID" ||
												trim($orgClinicalData[4])!="Study Type" || trim($orgClinicalData[5])!="Trial Name" ||
												trim($orgClinicalData[6])!="Condition" || trim($orgClinicalData[7])!="Intervention" ||
												trim($orgClinicalData[8])!="Phase" || trim($orgClinicalData[9])!="Number of enrollees" ||
												trim($orgClinicalData[10])!="Number of trial sites" || trim($orgClinicalData[11])!="Sponsors" ||
												trim($orgClinicalData[12])!="Status" || trim($orgClinicalData[13])!="Start Date" ||
												trim($orgClinicalData[14])!="End Date" || trim($orgClinicalData[15])!="Minimum Age" || trim($orgClinicalData[16])!="Maximum Age" ||
												trim($orgClinicalData[17])!="Gender" || trim($orgClinicalData[18])!="Investigators" ||
												trim($orgClinicalData[19])!="Collaborator" || trim($orgClinicalData[20])!="Purpose" ||
												trim($orgClinicalData[21])!="Official Title" || trim($orgClinicalData[22])!="Keywords" ||
												trim($orgClinicalData[23])!="MeSH Terms"
												
										 	){
										 		$arrImportStatusMsg[$name]['trial']['incorrect_format']='Uploaded File format is incorrect';
										 		break;
										 	}
										 	$numColumns=sizeof($data);
										 }
											if($sub!=1){
												$orgClinicalDetails=array();
												$cinNum = $orgClinicalData[1];
												$orgName =$orgClinicalData[2];
												$orgClinicalDetails['ctid'] = $orgClinicalData[3];
			
												if($cinNum!=""){
													$orgClinicalDetails['org_id'] =$this->organization->getOrgIdBySinNumber($cinNum);
			
													if($orgClinicalDetails['org_id']==0){
														//array of 'pin' not present in database
														$arrImportStatusMsg[$name]['trial']['no_matching_cin_num'][]= $cinNum;
													}else{
													if(!(isset($organizationDetailCount[$orgClinicalDetails['org_id']]['ctidCount']))){
														$organizationDetailCount[$orgClinicalDetails['org_id']]['ctidCount'] = $this->organization->getCountOfCtids($orgClinicalDetails['org_id']);
														//echo $this->db->last_query();
														}
														$status = $this->clinical_trial_org->saveCTID($orgClinicalDetails);
														if($status == false)
														$arrImportStatusMsg[$name]['trial']['ctid_exist'][]= $orgClinicalDetails['ctid'];
			
														$orgTrialStatusData = array();
														$orgTrialStatusData['id'] = $orgClinicalDetails['org_id'];
														$orgTrialStatusData['is_clinical_trial_processed'] = 0;
														$this->clinical_trial_org->updateClinicalTrialProcessedKol($orgTrialStatusData);
													}
												}else{
			
													$arrImportStatusMsg[$name]['trial']['no_cin_num'][]= $orgName;
												}
											}
											$arrImportStatusMsg[$name]['trial']['success']=true;
			
										}
			
								 }
								}
							}
						}
						else{
							$arrImportStatusMsg['overview']['file_type_missmatch']="file type is not 'xls'";
						}
					}
					
					//$data['arrImportStatusMsg']=$arrImportStatusMsg;
					////$data['contentPage'] 	=	'organizations/view_import_status';
					$data['timeTaken']		=	"Time Taken for Import ".$entry.": ".( microtime(true)-$startTime)."";
				//	;
				}
				$data['arrImportStatusMsg'][] = $arrImportStatusMsg;
				//pr($data);
				
				
		}
		
		
		foreach($organizationDetailCount as $key=>$row){
			$row['id']=$key;
			$row['name'] = $this->organization->getOrgNameByOrgId($row['id']);
					
			if(isset($row['medicalCount'])){
					$medicalCount = $this->organization->getCountOfMedical($key);
					$row['medicalCountAfterImport'] = $medicalCount-$row['medicalCount'];
			}
			if(isset($row['pmidCount'])){
					$pmidCount = $this->organization->getCountOfPmids($key);
					$row['pmidCountAfterImport'] = $pmidCount-$row['pmidCount'];
			}
			if(isset($row['ctidCount'])){
					$ctidCount = $this->organization->getCountOfCtids($key);
					$row['ctidCountAfterImport'] = $ctidCount-$row['ctidCount'];
			}
			
			if(isset($row['keyPeopleCount'])){
					$keyPeopleCount = $this->organization->getCountOfKeyPeople($key);
					$row['keyPeopleCountAfterImport'] = $keyPeopleCount-$row['keyPeopleCount'];
			}
			$organizationDetailCount1[]=$row;
			
		}
			
		//pr($organizationDetailCount);
			$data['arrCounts'] = $organizationDetailCount1;
			$data['type'] = 'Uni';
			$data['contentPage'] 		= 'organizations/view_import_status';
			echo "Total Time Taken : ".( microtime(true)-$initialTime);
			$this->load->view('layouts/analyst_view',$data);
	}
	
	function read_and_import_payer_files(){
		ini_set("max_execution_time",7200);
		$arrCountries	=$this->Country_helper->listCountries();
		$arrStates		=$this->Country_helper->listStates();
		$arrCities		=$this->Country_helper->listCities();
		$arrKeyPeopleRoles=$this->organization->getAllKeyPeopleRoles();
		$organizationTypes=$this->organization->getAllOrganizationTypes();
	 	$arrCollabarationCategories = $this->organization->getCollabarationCategories();
	 	$arrCollabarationRatings = $this->organization->getCollabarationRatings();
	 	$arrClaimsAndprocess = $this->organization->getClaimsaAndProcess();
	 	$arrFormularyDropDownValues = $this->organization->getFormularyDropDownValues();
			
		// Load the plugin
		$this->load->plugin('excelReader/reader2');
		$userId		=$this->session->userdata('user_id');
		$clientId	=$this->session->userdata('client_id');
		$orgID		= 0;
		$files = $this->input->post('files');
		$arrFiles = array();
		$organizationDetailCount = array();
		foreach($files as $row){
			$pos = strpos($row,'&');
			$folderNAme = substr($row,0,$pos);
			$arrFiles[$folderNAme][]=substr($row,$pos+1);
		}
		//pr($arrFiles);
		
		$initialTime = microtime(true);
		ini_set("memory_limit","2000M");
		$payerPath = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_imports/payer/uploaded/";
		
		foreach($arrFiles as $folder=>$files) {
			
			foreach($files as $filename){
				$arrImportStatusMsg[$filename]=array();
				$startTime = microtime(true);
					// Increasing the max execution time to pasrse all sheet data
					//$overviewFileName	= random_string('unique', 20);
					$overview_file_target_path = $payerPath."/".$folder."/".$filename;
					if(true){
						if(true){
							if(true) {
								$reader				=	new Spreadsheet_Excel_Reader($overview_file_target_path, true, 'utf-8');
								//loop through each sheet
								foreach($reader->sheets as $k=>$details){
									//Parsing of 1st sheet  - Overview: $k = index of the sheet
									if($k==0){
										$numColumns=0;
										$existingOrgs=array();
										$row=1;
										foreach($details['cells'] as $data){
											if($row==1){
												//condition to check whether format of the column is correct or not
												if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="COMPANY TYPE" || trim($data[4])!="LOGO" || trim($data[5])!="WEBSITE"
												|| trim($data[6])!="COMPANY HEADQUARTERS" || trim($data[7])!="COMPANY BACKGROUND" || trim($data[8])!="MISSION, VISION & VALUES"  || trim($data[9])!="KEY PRODUCTS" || trim($data[10])!="MERGERS & ACQUISITIONS" || trim($data[11])!="TOP CLIENTS"  ){
													$arrImportStatusMsg[$filename]['overview']['incorrect_format']='Uploaded File format is incorrect';
													break;
												}
												$numColumns=sizeof($data);
											}
											$organizationDetails=array();
											if($row>1){
												for($i=1;$i<=$numColumns;$i++){
													if(!isset($data[$i]))
													$data[$i]="";
												}
												$organizationDetails['cin_num']=trim($data[1]);
												$organizationDetails['name']=ucwords(trim($data[2]));
												$orgType=array_search(trim($data[3]),$organizationTypes);
												$organizationDetails['type_id']=$orgType;
												$organizationDetails['company_logo']=trim($data[4]);
												$organizationDetails['website']=trim($data[5]);
												$organizationDetails['headquarters']=trim($data[6]);
												$organizationDetails['background']=trim($data[7]);
												$organizationDetails['mission_vision']=trim($data[8]);
												$organizationDetails['key_products']=trim($data[9]);
												$organizationDetails['mergers']=trim($data[10]);
												$organizationDetails['clients']=trim($data[11]);
												$organizationDetails['profile_type'] = FULL;
												$profileType=trim($data[12]);
												if($profileType=='Basic'){
													$organizationDetails['profile_type'] = BASIC;
												}
												if($profileType=='Full Profile'){
													$organizationDetails['profile_type'] = FULL;
												}
												$organizationDetails['status']=New1;
												$organizationDetails['created_by']	=$userId;
												$organizationDetails['created_on']	=date("Y-m-d H:i:s");
													
												//break;
												//Save only if the 'cin_num' is not blank
												if($organizationDetails['cin_num']!=""){
													$id=$this->organization->saveOrganization($organizationDetails);
													if($id==false){
														//array of already existing organizations
														$existingOrgs[]=$organizationDetails['name'].' has been updated';
													}else{
														$orgID	= $id;
													}
												}else{
													//aray of organizations having no 'cin_num'
													$arrImportStatusMsg[$filename]['overview']['no_cin_num'][]= $organizationDetails['name'];
												}
			
											}
											$row++;
											$arrImportStatusMsg[$filename]['overview']['success']=true;
										}
										$arrImportStatusMsg[$filename]['overview']['existingOrgs']=$existingOrgs;
									}
			
									else if($k==1){
										//Parsing of 2st sheet  - Adress: $k = index of the sheet
										$numColumns=0;
										$row=1;
										foreach ($details['cells'] as $data) {
											//check wherether format is correct or not
											if($row==1){
												if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="ADDRESS" || trim($data[4])!="CITY" || trim($data[5])!="POSTAL CODE"
												|| trim($data[6])!="STATE" || trim($data[7])!="COUNTRY" || trim($data[8])!="PHONE" || trim($data[9])!="FAX" || trim($data[10])!="ADDITIONAL PHONE NUMBERS" || trim($data[11])!="KEY REGIONAL OFFICES" ){
													$arrImportStatusMsg[$filename]['address']['incorrect_format']='Uploaded File format is incorrect';
													break;
												}
												$numColumns=sizeof($data);
											}
											$organizationDetails=array();
											if($row>1){
												for($i=1;$i<=$numColumns;$i++){
													if(!isset($data[$i]))
													$data[$i]="";
												}
												$countryId=0;
												$stateId=0;
												$cityId=0;
												$organizationDetails['cin_num']=trim($data[1]);
												$organizationDetails['name']=trim($data[2]);
												$organizationDetails['address']=trim($data[3]);
												/*
												if(array_key_exists(ucwords(trim($data[4])),$arrCities))
												$cityId=$arrCities[ucwords(trim($data[4]))]['city_id'];
												$organizationDetails['city_id']=$cityId;*/
												
												$organizationDetails['postal_code']=trim($data[5]);
												if(array_key_exists(ucwords(trim($data[6])),$arrStates))
												$stateId=$arrStates[ucwords(trim($data[6]))]['state_id'];
												$organizationDetails['state_id']=$stateId;
												
												$city					= ucwords(trim($data[4]));
												if($city!=''){
									 				$organizationDetails['city_id']= $this->kol->getCityIdByState($city,$stateId);
												}
												if(array_key_exists(ucwords(trim($data[7])),$arrCountries))
												$countryId=$arrCountries[ucwords(trim($data[7]))]['country_id'];
												$organizationDetails['country_id']=$countryId;
												$organizationDetails['phone']=trim($data[8]);
												$organizationDetails['fax']=trim($data[9]);
												 
												$faxDetails=explode(" ",$organizationDetails['fax']);
												$arrFaxValues=array();
												$faxNumber="";
												foreach($faxDetails as $value){
													if(strpos($value, "+")!=false){
														$faxNumber.=trim($value);
													}
													if(is_numeric($value)){
														$faxNumber.=trim($value);
													}
												}
			
												$organizationDetails['key_reginal_offices']=trim($data[11]);
												$organizationDetails['addr_url']=trim($data[12]);
												$organizationDetails['created_by']	=$userId;
												$organizationDetails['created_on']	=date("Y-m-d H:i:s");
												 
												//Save only if the 'cin_num' is not blank
												if($organizationDetails['cin_num']!=""){
													$orgID =$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
													if($orgID>0){
														$organizationDetails['id']	= $orgID;
													}
													$id=$this->organization->updateImportedOrganization($organizationDetails);
													if($id==false){
														//array of 'cin_num' not present in database
														$arrImportStatusMsg[$filename]['address']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
													}
												}else{
													//aray of organizations  having no 'cin_num'
													$arrImportStatusMsg[$filename]['address']['no_cin_num'][]= $organizationDetails['name'];
												}
												 
												//Parsing and saving additional contact details
												if($organizationDetails['cin_num']!=""){
													$arrContactDetails=array();
													$orgId=$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
													$aditionalContats=trim($data[10]);
													$arrAditionalContactDetails=explode("\n",$aditionalContats);
													foreach($arrAditionalContactDetails as $aditionalContat){
														$contactDetails=array();
														$phNumber="";
														$relatedTo="";
														if(strpos($aditionalContat, "-")!=false){
															$aditionalContatDetails=explode("-",$aditionalContat);
															foreach($aditionalContatDetails as $value){
																if(strpos($value, "+")!=false){
																	$phNumber.=trim($value);
																}else if(is_numeric($value)){
																	$phNumber.=trim($value);
																}else {
																	$relatedTo.=trim($value);
																}
															}
														}else if(strpos($aditionalContat, ":")!=false){
			
															//echo $aditionalContat;
															$aditionalContatDetails=explode(":",$aditionalContat);
															$contactDetails['related_to']=$aditionalContatDetails[0];
															$contactDetails['phone']=$aditionalContatDetails[1];
														}else{
															$aditionalContatDetails=explode(" ",$aditionalContat);
														}
														$arrContactDetails[]=$contactDetails;
													}
													if($orgId!=0){
														//save additional contact details
														foreach($arrContactDetails as $row){
															$row['org_id']=$orgId;
															$row['created_by']	=$userId;
															$row['created_on']	=date("Y-m-d H:i:s");
															$this->organization->saveContact($row);
														}
													}else{
														//set error details
													}
												}
											}
											$row++;
											$arrImportStatusMsg[$filename]['address']['success']=true;
										}
			
									}
									else if($k==2){
			
										
										$fact =1;
										//Parsing of 3st sheet  - Mediacal Services: $k = index of the sheet
										$numColumns=0;
										$row=1;
											
										foreach($details['cells'] as $key=>$data) {
											if($row==1){
												if( trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="NO. OF HOSPITALS" || trim($data[4])!="TOTAL NO. OF PHYSICIANS" || trim($data[5])!='NO. OF PHYSICIANS EMPLOYED' || trim($data[6])!='NO. OF PHYSICIANS AFFILIATED' ||
													
												trim($data[7])!='PHARMACY BENEFIT MANAGEMENT' || trim($data[8])!='SPECIALTY PHARMACY' || trim($data[9])!='NCQA STATUS' ||
												trim($data[10])!='MEDICARE STAR RATING' || trim($data[11])!='CLAIMS & EMR DATA' || trim($data[12])!='DATA PROCESSING'
												){
													$arrImportStatusMsg[$filename]['facts']['incorrect_format']='Uploaded File format is incorrect';
													break;
												}
												$numColumns=sizeof($data);
											}
											$factDataDetails=array();
											if($row>1){
												for($i=1;$i<=$numColumns;$i++){
													if(!isset($data[$i]))
													$data[$i]="";
												}
												$cinNum  = trim($data[1]);
												$orgName =ucwords(trim($data[2]));
												 
												$factDataDetails['no_of_hospitals']=trim($data[3]);
												$factDataDetails['no_of_physicians']=trim($data[4]);
												$factDataDetails['physicians_employed']=trim($data[5]);
												$factDataDetails['no_of_affiliated']=trim($data[6]);
												$factDataDetails['benefit_management']=trim($data[7]);
												$factDataDetails['specialty_pharmacy']=trim($data[8]);
												$factDataDetails['ncqa_status']=trim($data[9]);
												$factDataDetails['start_rating']=trim($data[10]);
												//Save only if the 'cin_num' is not blank
												if($cinNum!=""){
													$orgID	= $this->organization->getOrgIdBySinNumber($cinNum);
													$factDataDetails['org_id'] =$orgID;
													if($orgID==0){
														//array of 'cin_num' not present in database
														$arrImportStatusMsg[$filename]['facts']['no_matching_cin_num'][]= $cinNum;
													}else{
														if($fact ==1){
															//$this->organization->deleteOrgPayerFacts($orgID);
															//$fact++;
														}
														$id = $this->organization->saveOrgPayerFacts($factDataDetails);
														$claims =trim($data[11]);
														if($claims!=''){
															$claimsArray = explode(',',$claims);
			
															$arrClaimsData = array();
															foreach($claimsArray as $value){
																$arrClaims =array();
																if(array_key_exists(trim($value),$arrClaimsAndprocess)){
																	$arrClaims['type_id'] = CLAIMS;
																	$arrClaims['fact_id'] = $id;
																	$arrClaims['cliam_process_id']=$arrClaimsAndprocess[trim($value)]['id'];
																	$this->organization->saveClaimData($arrClaims);
																}
															}
														}
														$dataProcessing=trim($data[12]);
														if($dataProcessing!=''){
															$processingArray = explode(',',$dataProcessing);
			
															$arrClaimsData = array();
															foreach($processingArray as $process){
																$arrProcess =array();
																if(array_key_exists(trim($process),$arrClaimsAndprocess)){
																	$arrProcess['type_id'] = DATA_PROCESSING;
																	$arrProcess['fact_id'] = $id;
																	$arrProcess['cliam_process_id']=$arrClaimsAndprocess[trim($process)]['id'];
																	$this->organization->saveClaimData($arrProcess);
																}
															}
														}
															
													}
												}else{
													//aray of address detains having no 'cin_num'
													$arrImportStatusMsg[$filename]['facts']['no_cin_num'][]= $orgName;
												}
			
											}
											$row++;
											$arrImportStatusMsg[$filename]['facts']['success']=true;
										}
									}
									else if($k==3){
										//Parsing of 3st sheet  - Affiliate patnership: $k = index of the sheet
										$numColumns=0;
										$row=1;
										$enroll=1;
										foreach($details['cells'] as $key=>$data) {
											if($row==1){
												if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!='ENROLLMENT TYPE'
												){
													$arrImportStatusMsg[$filename]['enrollment']['incorrect_format']='Uploaded File format is incorrect';
													break;
												}
												$numColumns=sizeof($data);
												unset($data[1]);
												unset($data[2]);
												unset($data[3]);
												$years=$data;
											}
											$enrollementDetails=array();
											if($row>1){
												for($i=1;$i<=$numColumns;$i++){
													if(!isset($data[$i]))
													$data[$i]="";
												}
												$cinNum  = trim($data[1]);
												$orgName =ucwords(trim($data[2]));
												//pr($data);
												$enrollementDetails['type']=trim($data[3]);
												//echo $cinNum;
												//$enrollementDetails['2009']=trim($data[4]);
												///$enrollementDetails['2010']=trim($data[5]);
												//$enrollementDetails['2011']=trim($data[6]);
												// $enrollementDetails['2012']=trim($data[7]);
												if($cinNum!=''){
													$enrollementDetails['org_id'] =$this->organization->getOrgIdBySinNumber($cinNum);
													
													if($enrollementDetails['org_id']!=0){
														//$orgId = $enrollementDetails['org_id'];
													//	if($enroll ==1){
															//$this->organization->deleteOrgEnrollement($enrollementDetails['org_id']);
															//$enroll++;
														//}
														if(!(isset($organizationDetailCount[$enrollementDetails['org_id']]['enrollementCount']))){
															$organizationDetailCount[$enrollementDetails['org_id']]['enrollementCount'] = $this->organization->getCountOfEnrollments($enrollementDetails['org_id']);
														}
														$id = $this->organization->saveOrgEnrollement($enrollementDetails);
														// pr($years);
														$lenth=sizeOf($years)+4;
			
														for($k=4;$k<$lenth;$k++){
															$arr =array();
															$arr['year']=$years[$k];
															$arr['value']=preg_replace("/[^0-9]/", "", $data[$k]);//str_replace(",","",$data[$k]);
															$arr['enroll_id']=$id;
			
															$this->organization->saveEnrollements($arr);
			
														}
													}else{
			
														$arrImportStatusMsg[$filename]['enrollment']['no_matching_cin_num'][]= $cinNum;
													}
												}else{
													//aray of address detains having no 'cin_num'
													$arrImportStatusMsg[$filename]['enrollment']['no_cin_num'][]=$orgName;
												}
											}
											$row++;
											$arrImportStatusMsg[$filename]['enrollment']['success']=true;
										}
											
									}
										
								 else if($k==4){
								 		
			
								 	//Parsing of 3st sheet  - Social Media : $k = index of the sheet
								 	$numColumns=0;
								 	$row=1;
								 	$formulary=1;
								 	foreach($details['cells'] as $data) {
								 		if($row==1){
								 			if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="DRUG NAME" || trim($data[4])!="DRUG TIER" || trim($data[5])!="PA  CRITERIA"
								 			){
								 				$arrImportStatusMsg[$filename]['formulary']['incorrect_format']='Uploaded File format is incorrect';
								 				//break;
								 			}
								 			$numColumns=sizeof($data);
								 		}
								 		$formularyDetails=array();
								 		if($row>1){
								 			for($i=1;$i<=$numColumns;$i++){
								 				if(!isset($data[$i]))
								 				$data[$i]="";
								 			}
								 			$cinNum=trim($data[1]);
								 			$name=ucwords(trim($data[2]));
			
								 			$formularyDetails['drug_name']=trim($data[3]);
								 			$formularyDetails['created_by']	=$this->loggedUserId;
								 			$formularyDetails['created_on']	=date("Y-m-d H:i:s");
								 			$formularyDetails['client_id']	=$this->session->userdata('client_id');
								 			$drugs=trim($data[4]);
								 			$paCretaria=trim($data[5]);
								 			//$formularyDetails['pa_creteria']=trim($data[5]);
								 				
								 			//$formularyDetails['created_by']	=$userId;
								 			//$formularyDetails['created_on']	=date("Y-m-d H:i:s");
			
								 			//Save only if the 'cin_num' is not blank
								 			if($cinNum!=""){
								 				$orgID	= $this->organization->getOrgIdBySinNumber($cinNum);
			
								 				if($orgID==0){
								 					//array of 'cin_num' not present in database
														$arrImportStatusMsg[$filename]['formulary']['no_matching_cin_num'][]= $cinNum;
								 				}else{
								 					$formularyDetails['org_id'] = $orgID;
								 					//if($formulary ==1){
								 						//$this->organization->deleteOrgFormulary($orgID);
								 						//$formulary++;
								 					//}
								 						if(!(isset($organizationDetailCount[$orgID]['formularyCount']))){
															$organizationDetailCount[$orgID]['formularyCount'] = $this->organization->getCountOfFormularies($orgID);
														}
														$id = $this->organization->saveOrgFormularies($formularyDetails);
														if($drugs!=''){
															$drugsArray = explode(',',$drugs);
			
															//$arrDrugsData = array();
															foreach($drugsArray as $value){
																$arrDrugsData =array();
																if(array_key_exists(trim($value),$arrFormularyDropDownValues)){
																	$arrDrugsData['type'] = DRUG_TIER;
																	$arrDrugsData['form_id'] = $id;
																	$arrDrugsData['drug_pa_id']=$arrFormularyDropDownValues[trim($value)]['id'];
			
																	$this->organization->saveFormularyDropdownData($arrDrugsData);
																}
															}
														}
														if($paCretaria!=''){
															$paArray = explode(',',$paCretaria);
																
															//$arrDrugsData = array();
															foreach($paArray as $value){
																$arrPaData =array();
																if(array_key_exists(trim($value),$arrFormularyDropDownValues)){
																	$arrPaData['type'] = PA_CRITERIA;
																	$arrPaData['form_id'] = $id;
																	$arrPaData['drug_pa_id']=$arrFormularyDropDownValues[trim($value)]['id'];
			
																	$this->organization->saveFormularyDropdownData($arrPaData);
																}
															}
														}
													}
								 			}else{
								 				//aray of address detains having no 'cin_num'
								 				$arrImportStatusMsg[$filename]['formulary']['no_cin_num'][]= $name;
								 			}
			
								 		}
								 		$row++;
								 		$arrImportStatusMsg[$filename]['formulary']['success']=true;
								 	}
								 		
								 }
								 else if($k==6){
								
								 	//Parsing of 3st sheet  - Social Media : $k = index of the sheet
								 	$numColumns=0;
								 	$row=1;
								 	$rate=1;
								 	foreach($details['cells'] as $data) {
								 		if($row==1){
								 			if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="CATEGORY" || trim($data[4])!="RATING"
								 			){
								 				$arrImportStatusMsg[$filename]['collabaration']['incorrect_format']='Uploaded File format is incorrect';
								 				break;
								 			}
								 			$numColumns=sizeof($data);
								 		}
								 		$formularyDetails=array();
								 		if($row>1){
								 			for($i=1;$i<=$numColumns;$i++){
								 				if(!isset($data[$i]))
								 				$data[$i]="";
								 			}
								 			$cinNum=trim($data[1]);
								 			$name=ucwords(trim($data[2]));
			
								 			$category=trim($data[3]);
								 			if(array_key_exists(trim($category),$arrCollabarationCategories)){
								 				$categoryId = $arrCollabarationCategories[$category]['id'];
								 			}
								 				
								 			$ratings=trim($data[4]);
								 			//echo $ratings;
								 			//$formularyDetails['pa_creteria']=trim($data[5]);
								 				
								 			//$formularyDetails['created_by']	=$userId;
								 			//$formularyDetails['created_on']	=date("Y-m-d H:i:s");
			
								 			//Save only if the 'cin_num' is not blank
								 			if($cinNum!=""){
								 				$orgID	= $this->organization->getOrgIdBySinNumber($cinNum);
			
								 				if($orgID==0){
								 					//array of 'cin_num' not present in database
														$arrImportStatusMsg[$filename]['collabaration']['no_matching_cin_num'][]= $cinNum;
								 				}else{
			
								 					//$formularyDetails['org_id'] = $orgID;
								 					if($rate==1){
								 						$this->organization->deleteCollabarationRatings($orgID);
								 						$rate++;
								 					}
														//$id = $this->organization->saveOrgFormularies($formularyDetails);
								 						
														if($ratings!=''){
			
															$arrRatings = explode(',',$ratings);
															foreach($arrRatings  as $rating){
																	
																if(array_key_exists(trim($rating),$arrCollabarationRatings)){
																	$ratings =array();
																	$ratingId = $arrCollabarationRatings[trim($rating)]['id'];
																	$ratings['category_id'] = $categoryId;
																	$ratings['org_id'] = $orgID;
																	$ratings['rating_id'] = $ratingId;
																	$ratings['created_by']	=$this->loggedUserId;
																	$ratings['created_on']	=date("Y-m-d H:i:s");
																	$ratings['client_id']	=$this->session->userdata('client_id');
																	$this->organization->saveCollabarationRatings($ratings);
			
																}
															}
														}
															
													}
								 			}else{
								 				//aray of address detains having no 'cin_num'
								 				$arrImportStatusMsg[$filename]['collabaration']['no_cin_num'][]= $name;
								 			}
			
								 		}
								 		$row++;
								 		$arrImportStatusMsg[$filename]['collabaration']['success']=true;
								 	}
								 		
								 }
								 else if($k==7){
								 	$arrKeyPeopleDetails = array();
								 	$kePeople=1;
								 	//Parsing of 4th sheet  -key_people: $k = index of the sheet
								 	$numColumns=0;
								 	$row=1;
										$arrSalutations	= array(''=>0,'Dr.' => 1, 'Prof.' => 2, 'Mr.' => 3, 'Ms.' =>4);
										foreach($details['cells'] as $data) {
											if($row==1){
												if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="ROLE" || trim($data[4])!="SALUTATION" || trim($data[5])!="FIRST NAME"
												|| trim($data[6])!="MIDDLE NAME" || trim($data[7])!="LAST NAME" || trim($data[8])!="DEPARTMENT/DIVISION/CENTER" || trim($data[9])!="TITLE" || trim($data[10])!="EMAIL" ){
													$arrImportStatusMsg[$filename]['key_people']['incorrect_format']='Uploaded File format is incorrect';
													break;
												}
												$numColumns=sizeof($data);
											}
											$organizationDetails=array();
											if($row>1){
												for($i=1;$i<=$numColumns;$i++){
													if(!isset($data[$i]))
													$data[$i]="";
												}
												$organizationDetails['cin_num']=trim($data[1]);
												$organizationDetails['name']=ucwords(trim($data[2]));
			
												$roleId=array_search(trim(strtolower($data[3])),array_map('strtolower',$arrKeyPeopleRoles));//array_search(trim($data[3]),$arrKeyPeopleRoles);
												$keyPeopleDetails['role_id']=$roleId;
												$keyPeopleDetails['salutation']=$arrSalutations[trim($data[4])];
												$keyPeopleDetails['first_name']=trim($data[5]);
												$keyPeopleDetails['middle_name']=trim($data[6]);
												$keyPeopleDetails['last_name']=trim($data[7]);
												$keyPeopleDetails['department']=trim($data[8]);
												$keyPeopleDetails['title']=trim($data[9]);
												$keyPeopleDetails['email']=trim($data[10]);
												$keyPeopleDetails['url']=trim($data[11]);
												$keyPeopleDetails['created_by']	=$userId;
												$keyPeopleDetails['created_on']	=date("Y-m-d H:i:s");
												//Save only if the 'cin_num' is not blank
												if($organizationDetails['cin_num']!=""){
													$orgId=$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
													if($orgId==0){
														$orgId=$this->organization->getOrgIdByOrgName($organizationDetails['name']);
													}
													if($orgId!=0){
														$keyPeopleDetails['org_id']=$orgId;
														//if($kePeople ==1){
														//	$this->organization->deleteKeyPeopleByOrgId($orgId);
														//	$kePeople++;
														//}
														if(!(isset($organizationDetailCount[$orgId]['keyPeopleCount']))){
															$organizationDetailCount[$orgId]['keyPeopleCount'] = $this->organization->getCountOfKeyPeople($orgId);
														}
														$arrKeyPeopleDetails[]=$keyPeopleDetails;
													//	$this->organization->saveKeyPeople($keyPeopleDetails);
													}else{
															
														$arrImportStatusMsg[$filename]['key_people']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
													}
												}else{
													//aray of address detains having no 'cin_num'
													$arrImportStatusMsg[$filename]['key_people']['no_cin_num'][]= $organizationDetails['name'];
												}
			
											}
											$row++;
											$arrImportStatusMsg[$filename]['key_people']['success']=true;
										}
										$this->organization->saveKeyPeopleBulk($arrKeyPeopleDetails);
								 }
			
								 else if($k==5){
								 	$management = 1;
								 	///pr($arrDiseaseDropDownValues);
								 	//Parsing of 7th sheet  - Stats Facts: $k = index of the sheet
										foreach($details['cells'] as $factKey=>$facts){
										 if($factKey==1){
										 	if(trim($facts[1])!="CIN NUM" || trim($facts[2])!="COMPANY NAME" || trim($facts[3])!="DISEASE NAME" || trim($facts[4])!="DISEASE MANAGEMENT PLATFORMS" ||
										 	trim($facts[5])!="IDENTIFICATION" || trim($facts[6])!="INTERVENTION" || trim($facts[7])!="MEASUREMENT"
										 	){
										 		$arrImportStatusMsg[$filename]['disease_management']['incorrect_format']='Uploaded File format is incorrect';
										 		break;
										 	}
										 		
										 		
										 	$numColumns=sizeof($facts);
										 }
											if($factKey!=1){
												$managmentDataDetails=array();
												$cinNum = $facts[1];
												$name = $facts[2];
												$managmentDataDetails["disease_name"] 		= $facts[3];
													
												$managmentDataDetails['created_by']	=$this->loggedUserId;
												$managmentDataDetails['created_on']	=date("Y-m-d H:i:s");
												$managmentDataDetails['client_id'] = $this->session->userdata('client_id');
												$platForms	= $facts[4];
												$identification	= $facts[5];
												$intervention	= $facts[6];
												$measurement	= $facts[7];
												//$managmentDataDetails["identification"] 	 	    = $facts[5];
													
												//$managmentDataDetails["intervention"] 	= $facts[6];
												//$managmentDataDetails["measurement"]    = $facts[7];
												if($cinNum!=''){
													$managmentDataDetails['org_id'] =$this->organization->getOrgIdBySinNumber($cinNum);
													if($managmentDataDetails['org_id']!=0){
															
													//	if($management ==1){
														//	$this->organization->deleteDiseaseManagement($managmentDataDetails['org_id']);
															//$management++;
														//}
													if(!(isset($organizationDetailCount[$managmentDataDetails['org_id']]['diseaseCount']))){
															$organizationDetailCount[$managmentDataDetails['org_id']]['diseaseCount'] = $this->organization->getCountOfDisease($managmentDataDetails['org_id']);
														}
														$id = $this->organization->saveDeaseManagement($managmentDataDetails);
														if($platForms!=''){
															$platFormArray = explode(',',$platForms);
															$arrDiseaseDropDownValues = $this->organization->getDiseaseDropDownValuesForParticulars(DISEASE_MANAGEMENT_PLATFORMS);
															//$arrDrugsData = array();
															foreach($platFormArray as $value){
																	
																$arrPlatFormData =array();
																	
																if(array_key_exists(trim($value),$arrDiseaseDropDownValues)){
																	//echo $value;
																	$arrPlatFormData['type'] = DISEASE_MANAGEMENT_PLATFORMS;
																	$arrPlatFormData['disease_id'] = $id;
																	$arrPlatFormData['value_id']=$arrDiseaseDropDownValues[trim($value)]['id'];
			
																	$this->organization->saveDiseaseDropdownData($arrPlatFormData);
																}
															}
			
														}
			
														if($identification!=''){
															$identificationArray = explode(',',$identification);
															$arrDiseaseDropDownValues = $this->organization->getDiseaseDropDownValuesForParticulars(IDENTIFICATION);
															//$arrDrugsData = array();
															foreach($identificationArray as $value){
																	
																$arrIdentData =array();
																	
																if(array_key_exists(trim($value),$arrDiseaseDropDownValues)){
																	//echo $value;
																	$arrIdentData['type'] = IDENTIFICATION;
																	$arrIdentData['disease_id'] = $id;
																	$arrIdentData['value_id']=$arrDiseaseDropDownValues[trim($value)]['id'];
			
																	$this->organization->saveDiseaseDropdownData($arrIdentData);
																}
															}
			
														}
			
														if($intervention!=''){
															$interventionArray = explode(',',$intervention);
															$arrDiseaseDropDownValues = $this->organization->getDiseaseDropDownValuesForParticulars(INTERVENTION);
															//$arrDrugsData = array();
															foreach($interventionArray as $value){
																	
																$arrInterData =array();
																	
																if(array_key_exists(trim($value),$arrDiseaseDropDownValues)){
																	//echo $value;
																	$arrInterData['type'] = INTERVENTION;
																	$arrInterData['disease_id'] = $id;
																	$arrInterData['value_id']=$arrDiseaseDropDownValues[trim($value)]['id'];
																	//pr($arrPlatFormData);
																	$this->organization->saveDiseaseDropdownData($arrInterData);
																}
															}
			
														}
			
														if($measurement!=''){
															$measurementArray = explode(',',$measurement);
															$arrDiseaseDropDownValues = $this->organization->getDiseaseDropDownValuesForParticulars(MEASUREMENT);
															//$arrDrugsData = array();
															foreach($measurementArray as $value){
																	
																$arrMeasuremenData =array();
																	
																if(array_key_exists(trim($value),$arrDiseaseDropDownValues)){
																	//echo $value;
																	$arrMeasuremenData['type'] = MEASUREMENT;
																	$arrMeasuremenData['disease_id'] = $id;
																	$arrMeasuremenData['value_id']=$arrDiseaseDropDownValues[trim($value)]['id'];
																	//pr($arrPlatFormData);
																	$this->organization->saveDiseaseDropdownData($arrMeasuremenData);
																}
															}
			
														}
			
													}else{
			
														$arrImportStatusMsg[$filename]['disease_management']['no_matching_cin_num'][]= $cinNum;
													}
												}else{
													//aray of address detains having no 'cin_num'
													$arrImportStatusMsg[$filename]['disease_management']['no_cin_num'][]= $name;
												}
											}
											$arrImportStatusMsg[$filename]['disease_management']['success']=true;
			
										}
										// break;
								 }
								 	
								 else if($k==8){
								 	//Parsing of 3st sheet  - Social Media : $k = index of the sheet
								 	$numColumns=0;
								 	$row=1;
								 	foreach($details['cells'] as $data) {
								 		if($row==1){
								 			if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="BLOG" || trim($data[4])!="YOUTUBE" || trim($data[5])!="LINKEDIN"
								 			|| trim($data[6])!="FACEBOOK" || trim($data[7])!="TWITTER" ){
								 				$arrImportStatusMsg[$filename]['social_media']['incorrect_format']='Uploaded File format is incorrect';
								 				break;
								 			}
								 			$numColumns=sizeof($data);
								 		}
								 		$organizationDetails=array();
								 		if($row>1){
								 			for($i=1;$i<=$numColumns;$i++){
								 				if(!isset($data[$i]))
								 				$data[$i]="";
								 			}
								 			$organizationDetails['cin_num']=trim($data[1]);
								 			$organizationDetails['name']=ucwords(trim($data[2]));
			
								 			$organizationDetails['blog']=trim($data[3]);
								 			$organizationDetails['youtube']=trim($data[4]);
								 			$organizationDetails['linkedin']=trim($data[5]);
								 			$organizationDetails['facebook']=trim($data[6]);
								 			//$organizationDetails['myspace']=trim($data[7]);
								 			$organizationDetails['twitter']=trim($data[7]);
			
								 			$organizationDetails['created_by']	=$userId;
								 			$organizationDetails['created_on']	=date("Y-m-d H:i:s");
			
								 			//Save only if the 'cin_num' is not blank
								 			if($organizationDetails['cin_num']!=""){
								 				$orgID	= $this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
								 				if($orgID>0){
								 					$organizationDetails['id']	= $orgID;
								 				}
								 				$id=$this->organization->updateImportedOrganization($organizationDetails);
								 				if($id==false){
								 					//array of 'cin_num' not present in database
								 					$arrImportStatusMsg[$filename]['social_media']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
								 				}
								 			}else{
								 				//aray of address detains having no 'cin_num'
								 				$arrImportStatusMsg[$filename]['social_media']['no_cin_num'][]= $organizationDetails['name'];
								 			}
			
								 		}
								 		$row++;
								 		$arrImportStatusMsg[$filename]['social_media']['success']=true;
								 	}
								 }
			
								}
							}
						}
						else{
							$arrImportStatusMsg[$filename]['overview']['file_type_missmatch']="file type is not 'xls'";
						}
					}
			}
				$data['arrImportStatusMsg'][] = $arrImportStatusMsg;
		}
		
		$stTime = microtime(true);
		foreach($organizationDetailCount as $key=>$count){
			$count['id'] = $key;
			if(isset($count['enrollementCount'])){
				
					$enrollementCount = $this->organization->getCountOfEnrollments($key);
					$count['enrollementCountAfterImport'] = $enrollementCount-$count['enrollementCount'];
			}
			if(isset($count['formularyCount'])){
					$formularyCount = $this->organization->getCountOfFormularies($key);
					$count['formularyCountAfterImport'] = $formularyCount-$count['formularyCount'];
			}
			if(isset($count['keyPeopleCount'])){
					$keyPeopleCount = $this->organization->getCountOfKeyPeople($key);
					$count['keyPeopleCountAfterImport'] = $keyPeopleCount-$count['keyPeopleCount'];
			}
			if(isset($count['diseaseCount'])){
					$diseaseCount = $this->organization->getCountOfDisease($key);
					$count['diseaseCountAfterImport'] = $diseaseCount-$count['diseaseCount'];
			}
			$organizationDetailCount1[] = $count;
		}
		
		$ndTime = microtime(true);
		//echo $stTime-$ndTime."dddddddd";
		
		
		
		
		$data['type'] = 'Payer';
		$data['arrCounts'] = $organizationDetailCount1;
		//$data['arrImportStatusMsg']=$arrImportStatusMsg;
		$data['contentPage'] 	=	'organizations/view_import_status';
		$data['timeTaken']	=	"Time Taken for Import ".$entry.": ".( microtime(true)-$startTime)."";
		 $this->load->view('layouts/analyst_view',$data);
		echo "Total Time Taken : ".( microtime(true)-$initialTime);
	}

	function list_import_files(){
		$arrUHFiles = array();
		$payerPath = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_profiles/uh/";
		if ($handle = opendir($payerPath)) {
			/* This is the correct way to loop over the directory. */
			while (false !== ($entry = readdir($handle))) {
				if($entry !='.' && $entry !='..' && $entry !='.svn'){
					$arrUHFiles[] = $entry;
				}
			}
		}
		
		$arrPayerFiles = array();
		$payerPath = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_profiles/payer/";
		if ($handle = opendir($payerPath)) {
			/* This is the correct way to loop over the directory. */
			while (false !== ($entry = readdir($handle))) {
				if($entry !='.' && $entry !='..' && $entry !='.svn'){
					$arrPayerFiles[] = $entry;
				}
			}
		}
		
		$data['arrUHFiles'] 	= $arrUHFiles;
		$data['arrPayerFiles'] 	= $arrPayerFiles;
		$data['contentPage'] 	=	'organizations/list_import_files';
		$this->load->view('layouts/analyst_view',$data);
	}
	
	function delete_enrollment_duplicate_year(){
		$enroll = array();
		$arrEnroll = $this->db->get('org_enrollment_years');
		foreach ($arrEnroll->result_array() as $row){
			if(!array_key_exists($row['year'], $enroll[$row['enroll_id']])){
				$enroll[$row['enroll_id']][$row['year']] = $row['value'];
				$arrData[$row['id']] = $row;
			}else{
				$arrDuplicate[$row['id']] = $row;
				$this->db->where('id',$row['id']);
				$this->db->delete('org_enrollment_years');
			}
		}
	}
	
	function add_org_saved_filters() {
		$data['savedFilters'] = $this->organization->getAllCustomFilterByUser($this->loggedUserId);
		$this->load->view('search/add_saved_filters',$data);
	}
	
	function save_custom_filters() {
		$arrData['name'] 			= trim(ucfirst($this->input->post('filterName')));
		$arrData['filter_type'] 	= 2;
		$arrData['filter_value'] 	= json_encode($this->input->post('saveFilter'));
		$arrData['created_on'] 		= date('Y-m-d H:i:s');
		$arrData['created_by'] 		= $this->loggedUserId;
		$arrData['client_id'] 		= $this->session->userdata('client_id');
		$arrData['applied_on'] 		= date('Y-m-d H:i:s');
		$lastId = $this->organization->saveCustomFilters($arrData);
		if($lastId){
			$data['status'] = true;
			$data['id'] = $lastId;
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}
	
	function get_filter_by_id($id) {
		$arrData['id'] = $id;
		$arrData['applied_on'] = date('Y-m-d H:i:s');
		$data = $this->organization->getFilterById($arrData);
		if($data){
			$data1['status'] = true;
			$data1['filterData'] = json_decode($data);
		}else{
			$data1['status'] = false;
		}
		echo json_encode($data1);
	}
	
	function update_custom_filters(){
		$arrData['name'] 			= $this->input->post('filterName');
		$arrData['id'] 				= $this->input->post('filterId');
		$arrData['filter_value'] 	= json_encode($this->input->post('saveFilter'));
		$arrData['modified_on'] 	= date('Y-m-d H:i:s');
		$arrData['created_by'] 		= $this->loggedUserId;
		$arrData['client_id'] 		= $this->session->userdata('client_id');
		if($this->organization->updateCustomFilters($arrData)){
			$data['status'] = true;
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}
	
	function get_org_saved_filters() {
		$data['savedFilters'] = $this->organization->getAllCustomFilterByUser($this->loggedUserId);
		$this->load->view('search/edit_saved_filters',$data);
	}
	
	function delete_saved_filter($filterId) {
		if($this->organization->deleteSavedFilter($filterId)){
			$data['status'] = true;
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}
	
	function update_saved_filter() {
		$arrData['id'] 				= $this->input->post('id');
		$arrData['name'] 			= $this->input->post('filterName');
		if($this->organization->updateSavedFilter($arrData)){
			$data['status'] = true;
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}
	
	function reset_applied_filter(){
		$userId = $this->loggedUserId;
		$data = $this->organization->resetAppliedFilter($userId);
		if($data)
			$status['status'] = true;
		else
			$status['status'] = false;
		echo json_encode($status);	
	}
	
	function view_interactions($organizationId,$subContentPage=''){
		
            $clientId = $this->session->userdata('client_id');

            $this->load->model('interaction');
            $clientId				= $this->session->userdata('client_id');
            $data['arrGroupings']	= $this->interaction->getAllGroupings($clientId);
            $data['arrModes']		= $this->interaction->getAllModesOfClient($clientId);
            $data['arrTopics']		= $this->interaction->getAllTopicsOfClient($clientId);
            $data['arrType']		= $this->interaction->getAllTypesOfClient();
            $data['arrProduct']		= $this->common_helpers->getUserProducts();
            $data['arrUsers']		= $this->Client_User->getClientUsers($clientId);
			$managerId = $this->session->userdata("user_id");
	        $filterData['arrManager'] = $this->common_helpers->getAllManagersForReports($managerId);
	        foreach ($filterData['arrManager'] as $row){
	        	$data['arrManager'][$row['id']] = $row['first_name']." ".$row['last_name'];
	        }
            $startFrom		= $this->input->post('startFrom');
            if(!$organizationId){
            $this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
            redirect('organizations/list_organizations');
            }
            $arrOrganizationDetail = array();
            // Getting the Organization details
            $arrOrganizationDetail = $this->organization->editOrganization($organizationId);

            // If there is no record in the database
            if(!$arrOrganizationDetail){
                            $this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
                            redirect('organizations/list_organizations');
                    }

            // Set the Organization ID into the Session
            $this->session->set_userdata('organizationId', $organizationId);
  		
            $arrOrganizationTypes = $this->organization->getAllOrganizationTypes();
            //$data['arrAssocPeople']	= $this->organization->listOrgAssociatedPpl($organizationId);
            $data['arrOrganizationTypes']	= $arrOrganizationTypes;
            //$clientId=1;
            $arrFilters['interactionFor'] = 'org';
            $arrInteractionsResults=$this->interaction->getKolInteractions($clientId,$organizationId,$userId,$arrFilters,$limit=10,'');
            $count=$this->interaction->getKolInteractions($clientId,$organizationId,$userId,$arrFilters,$limit='all','');
            //	echo $this->db->last_query();
            $data['arrInteractionsResults']=	$arrInteractionsResults;
            $data['arrOrganization']	= $arrOrganizationDetail;
            $data['assignedUsers'] = $this->align_user->getAssignedOrgUsers($organizationId);
            $data['contentPage'] 	= 'organizations/interactions/view_numeric_report';
            $data['orgId'] 	= $organizationId;
            $data['subContentPage']	=	$subContentPage;
            $data['count'] = $count;

            $interactionIds = array();
            foreach($arrInteractionsResults as $row){
                    $interactionIds[] = $row['id'];
            }
            //pr($interactionIds);
            $data['interactionIds'] = implode($interactionIds,',');

            if($count==0){
                    $data['mes'] = "No interactions found";
            }

            $data['startFrom'] = $startForm;
            $this->load->view('layouts/client_view',$data);
	}

        
	
	function view_org_interactions($organizationId){
		
		$clientId = $this->session->userdata('client_id');
		$arrFilters['end_date']	 	= $this->input->post('ed');
		$arrFilters['start_date']	 	= $this->input->post('sd');
		$arrFilters['objective_id']	 	= $this->input->post('type');
		$arrFilters['product_id'] 		= $this->input->post('product');
		$arrFilters['topic_id']		= $this->input->post('topic');
		$arrFilters['mode']		= $this->input->post('mode');
		$arrFilters['grouping']		= $this->input->post('grouping');
		$arrFilters['user_id']		= $this->input->post('user_id');
		$arrFilters['kol_id']		= $this->input->post('kol_id');
		$startFrom		= $this->input->post('startFrom');
		
		$arrInteractionsResults=$this->interaction->getInteractionsOfOrgKols($clientId,$organizationId,$arrFilters,$startFrom,10);
		
		$count=$this->interaction->getInteractionsOfOrgKols($clientId,$organizationId,$arrFilters,$startFrom,'all');
		$data['startFrom'] = $startFrom;
		$data['arrInteractionsResults']=	$arrInteractionsResults;
	
		$data['contentPage'] 	= 'organizations/interactions/show_interaction_details';
		
		
		$data['count'] = $count;
	if($count==0){
			$data['mes'] = "No interactions found for the criteria selected by you";
		}
		
		$this->load->view('organizations/interactions/show_interaction_details',$data);
	}
	
	/**
	 * Gets the interactions belogs to perticular client user with in the perticular date range. 
	 * and prepares a json data and returns.
	 * @author 	Ramesh B
	 * @Created on: 22-08-11
	 * @since	3.0
	 * @return JSON
	 */
	function list_interactions_by_date_range($orgId){
		$this->load->model('interaction');
		$page				= (int)$this->input->post('page'); // get the requested page 
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$arrInteractions	= array();
		$data				= array();
		$arrFilters['objective_id']	 	= $this->input->post('type');
		$arrFilters['product_id'] 		= $this->input->post('product');
		$arrFilters['topic_id']		= $this->input->post('topic');
		$arrFilters['mode']		= $this->input->post('mode');
		$arrFilters['grouping']		= $this->input->post('grouping');
		$arrFilters['kol_id']		= $this->input->post('kol_id');
	//	pr($arrFilters);
		$arrFilters['end_date']	 	= $this->input->post('ed');
		$arrFilters['start_date']	 	= $this->input->post('sd');
		
		$clientId	=$this->session->userdata('client_id');
		$arrSalutations	= array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$userId=0;
		if($this->session->userdata('user_role_id')==ROLE_USER)
			$userId=$this->session->userdata('user_id');
		
		$arrFilters['interactionFor'] = $this->input->post('interaction_for');
		$arrInteractions=array();
		if($arrInteractionsResults=$this->interaction->getInteractionsOfOrgKols($clientId,$orgId,$arrFilters)){
			foreach($arrInteractionsResults as $arrInteractionResult){
				$arr=array();
				$arrTypes =array();
				$arrProduct = array();
				$arrInteraction['date']				= sql_date_to_app_date($arrInteractionResult['date']);
				if($arrInteraction['date']=="00/00/0000")
					$arrInteraction['date']			= '';
				$arrInteraction['mode_name']		= $arrInteractionResult['mode_name'];
				$arrInteraction['id']				= $arrInteractionResult['id'];
				
				foreach($arrInteractionResult['topic_name'] as $row){
				
					$arrProduct['product'][] = $row['product_name'];
					$arrTypes['type'][] = $row['objective_name'];
									
					
				}
				
				$arrInteraction['objective_name']	= implode(', ',$arrTypes['type']);
				$arrInteraction['product_name']		= implode(', ',$arrProduct['product']);
				$arrInteraction['follow_up_on']		= sql_date_to_app_date($arrInteractionResult['follow_up_on']);
				if($arrInteraction['follow_up_on']=="00/00/0000")
					$arrInteraction['follow_up_on']	= '';
			//	$arrInteraction['kol_name']=$arrSalutations[$arrInteractionResult['salutation']]." ".$arrInteractionResult['first_name']." ".$arrInteractionResult['middle_name']." ".$arrInteractionResult['last_name'];
				$arrInteraction['kol_name']			= $arrInteractionResult['kol_name'];
				$arrUserDetails						= $this->Client_User->editUser($arrInteractionResult['created_by']);
				$arrInteraction['recorded_by']		= $arrUserDetails['first_name']." ".$arrUserDetails['last_name'];
				$arrInteractions[]					= $arrInteraction;
			}
			
			$count				= sizeof($arrInteractions);
			if( $count >0 ){
				$total_pages	= ceil($count/$limit);
			}else{
				$total_pages	= 0;
			}
			$data['records']	= $count;
			$data['total']		= $total_pages;
			$data['page']		= $page;
			$data['rows']		= $arrInteractions;
			//pr($arrInteractions);
		}
	
		echo json_encode($data);
	}
	
function edit_org_interaction($interactionId,$kolId=null){
		$clientId		= $this->session->userdata('client_id');
		$userId			= 0;
		$data['kolId1']	= null;
		if($this->session->userdata('user_role_id')==ROLE_USER){
			$userId		= $this->session->userdata('user_id');
		}
		$arrTopics							= $this->interaction->getInteractionTopics($interactionId);
		$interactionDetails					= $this->interaction->getInteractionDetails($interactionId);
		$interactionDetails['attendies']	= $this->interaction->getInteractionAttendis($interactionId);
		foreach($arrTopics as $row){
			$row['topics']					= $this->interaction->getTpicByProduct($interactionDetails['grouping'],$row['product_id'],$row['objective_id']);
			$arr[]							= $row;
		}
		$interactionDetails['arrSelectedTopics']	= $arr;
		$interactionDetails['noOfKols']				= sizeOf($interactionDetails['attendies'])-1;
		$interactionDetails['noOfObjectives']		= sizeOf($interactionDetails['arrSelectedTopics'])-1;
		$arrUserDetails								= $this->Client_User->editUser($interactionDetails['created_by']);
		$interactionDetails['user_name']			= $arrUserDetails['first_name']." ".$arrUserDetails['last_name'];
		$interactionDetails['fromtime']				= $this->common_helpers->convert24HourTo12HoureFormat($interactionDetails['fromtime']);
		$interactionDetails['totime']				= $this->common_helpers->convert24HourTo12HoureFormat($interactionDetails['totime']);
		if($interactionDetails['fromtime'] == "")
			$interactionDetails['fromtime']			= "00:00:00";
		if($interactionDetails['totime'] == "")
			$interactionDetails['totime']			= "00:00:00";
		
		$data['arrKolDetails']	= $this->kol->getKolNames();
		$data['arrModes']		= $this->interaction->getAllModesOfClient($clientId);
		$data['arrTopics']		= $this->interaction->getAllTopicsOfClient($clientId);
		//$data['arrBrands']=$this->interaction->getAllBrandsOfClient($clientId);
	//	$data['arrRoles']		= $this->interaction->getAllRolesOfClient($clientId);
	//	$data['arrCategories']	= $this->interaction->getAllCategoriesOfClient($clientId);
		$this->load->model('specialty');
		$data['arrSpecialties']	= $this->specialty->getAllSpecialties();
		$data['arrDocs']		= $this->interaction->getInteractionDocs($interactionId);
		$data['arrProduct']		= $this->interaction->getAllProductsOfClient($clientId);
		$data['arrUsers'] 		= $this->kol->getAllNonProfiledKols();
		$data['internalUsers']	= $this->interaction->getInternalUsers($interactionId);
		$data['arrGroupings']	= $this->interaction->getAllGroupings($clientId);
		$data['arrType']		= $this->interaction->getAllTypesOfClient();
		if($interactionDetails['location_type']==-1){
			$interactionDetails['location']	= '';
			$interactionDetails['state_id']	= '';
			$interactionDetails['address']	= '';
			$interactionDetails['city_id']	= '';
			$interactionDetails['postal_code']	= '';
		}
		$data['interactionDetails']	= $interactionDetails;
		//if(!empty($kolId)){
			$kolContactDetails		= $this->kol->getKolDetailsById($interactionDetails['attendies'][0]['id']);
			$arrPrimaryContact		= array();
			$arrPrimaryContact[0]	= array(
										'id'=> -1,
										'location'=>'Primary',
										'address'=>$kolContactDetails[0]['address1'].' '.$kolContactDetails[0]['address2'],
										'country'=>$kolContactDetails[0]['Country'],
										'state'=>$kolContactDetails[0]['Region'],
										'city'=>$kolContactDetails[0]['City']
									);
			$arrSecondaryContact	= $this->kol->listAdditionalContacts($interactionDetails['attendies'][0]['id']);
			$data['kolLocations']	= array_merge($arrPrimaryContact,$arrSecondaryContact);
		//}
	//	$userid = $this->session->userdata['user_id'];
	//	$usre1 = $data['arrUsers'][$userid];
		//$data['arrUsers']
		//unset($data['arrUsers'][$userid]);
	//	$data['arrUsers'][$userid]=$usre1;
		
	//	$arr1[$userid]=$usre1;
		//$data['arrUsers1'] = array_reverse($data['arrUsers']);
	//	foreach($data['arrUsers'] as $key=>$value){
	//		$arr1[$key] = $value;
	//	}
		//pr($arr1);
	//	$data['arrUsers']=$arr1;
	/*	
		$arrObjectives=array();
		$arrObjectivesResults		=	$this->planning->getPlannedObjectives($userId,$clientId);
		foreach($arrObjectivesResults as $row)
			$arrObjectives[$row['id']]=$row['name'];
		//send the kol specialty also it the interaction if for kol specific
		if($kolId!=null){
			$kolDetails=$this->kol->getKolDetailsById($kolId);
			$data['kolSpecialty']=$kolDetails[0]['specialty'];
		}
		if(isset($interactionDetails['kol_id'])){
			$data['kolId'] = $interactionDetails['kol_id'];
		}
		$data['arrObjectives']=$arrObjectives;
	*/
		$this->load->model('Country_helper');
		$data['arrCountry']=$this->Country_helper->listCountries();
		$data['arrStates']			= $this->Country_helper->listStates();
		if(isset($interactionDetails['city_id'])){
			$data['arrCities']		= $this->Country_helper->getCitiesByStateId($interactionDetails['state_id']);
		}
		if($kolId!=null){
			$data['kolId1']=$kolId;
		}
		if($kolId==null){
			$this->load->view("organizations/interactions/interaction_form",$data);
		}else{
			$this->load->view("interactions/interaction_form_within_kol",$data);
		}
	}

	function save_interaction(){
		$arrKols				= $this->payment->getAllKolsName1();
		
		$kolNames				= '';
		$seperator				= '';
		//Prepare a interaction details array fro post data
		$arrInteractionDetails	= array();
		$calendarEventId		= 0;
		$callFrom				= 0;
		$id						= $this->input->post('interaction_id');
		$isRequestFrom 			= $this->input->post('is_from');
		if($id!=null && $id!='')
			$arrInteractionDetails['id']	= $id;
	//	$arrInteractionDetails['objective_id']		=	$this->input->post('objective_id');
		$arrInteractionDetails['client_id']			=	$this->session->userdata('client_id');
		//$arrInteractionDetails['kol_id']			=	$this->input->post('kol_id');
		//$kolName  									= 	trim($this->input->post('kol_name'));
		
		//-- Prparing array for No fo attendis
		$noOfkolfiles 			= $this->input->post('noOfKols');
		$arrName['kol_name']	= trim($this->input->post('kol_name'));
		$arrName['kol_id']	= trim($this->input->post('kol_id'));
	//	$arrName['category_id'] = $this->input->post('category');
	//	$arrName['role_id']		= $this->input->post('role');
		$arrName['note'] 		= $this->input->post('attendee_note');
		$arrKolId[]=$arrName;
		if($noOfkolfiles >= 1){
			for($i=1;$i<=$noOfkolfiles;$i++){
				if($this->input->post('kol_name'.$i)!=''){
					$arrName1['kol_name']		= trim($this->input->post('kol_name'.$i));
					$kolNames	.= $seperator.$arrName1['kol_name'];
					$seperator	= ', ';
					//	$arrName1['category_id']	= $this->input->post('category'.$i);
				//	$arrName1['role_id']		= $this->input->post('role'.$i);
					$arrName1['kol_id'] = trim($this->input->post('kol_id_auto'.$i));
					$arrName1['note']	= $this->input->post('attendee_note'.$i);
				
					if($arrName1['kol_id']==''){
							
						$arrName1['kol_id'] = array_search($arrName1['kol_name'],$arrKols);
					}
				
					//$arrName1['kol_id'] = array_search($arrName1['kol_name'],$arrKols);
						if($arrName1['kol_id']==''){
							$kolName	= $arrName1['kol_name'];
							$kolSaved='';
								$checkCamma = strpos($kolName,',');
								$kolDetail=array();
								if($checkCamma!=''){
									
									$kolNameExplodeBy = explode(',',$kolName);
									//pr($kolNameExplodeBy);
									if(sizeOf($kolNameExplodeBy)==1){
											$kolDetail['first_name'] = $kolNameExplodeBy[0];
										}
									if(sizeOf($kolNameExplodeBy)==2){
											$kolDetail['last_name'] = $kolNameExplodeBy[0];
											$kolDetail['first_name'] = $kolNameExplodeBy[1];
										}
									if(sizeOf($kolNameExplodeBy)==3){
										$kolDetail['last_name'] = $kolNameExplodeBy[0];
										$kolDetail['first_name'] = $kolNameExplodeBy[1];
										$kolDetail['middle_name'] = $kolNameExplodeBy[2];
									}
									
									$checkKolname = $kolDetail['first_name']." ".$kolDetail['middle_name']." ".$kolDetail['last_name'];
									$kolId = array_search($checkKolname,$arrKols);
									if($kolId==''){
										$kolDetail['created_by'] = $this->session->userdata('user_id');
										$kolDetail['status'] = PRENEW;
										$arrName1['kol_id'] = $this->payment->savenNotProfiledKols($kolDetail);
									}else{
										$arrName1['kol_id'] =$kolId;
									}
									$kolSaved = 'Saved';
									
								}
								if($kolSaved!='Saved'){
									
									$splitByspace = explode(" ",$kolName);
								
									if(sizeOf($splitByspace)==2){
											
										$kolDetail['first_name'] = $splitByspace[0];
											$kolDetail['last_name'] = $splitByspace[1];
									}
									
									if(sizeOf($splitByspace)==3){
									
										$kolDetail['first_name'] = $splitByspace[0];
										$kolDetail['middle_name'] = $splitByspace[1];
										$kolDetail['last_name'] = $splitByspace[2];
										
									}
									
									if(sizeOf($splitByspace)>3){
										$kolDetail['first_name'] = $splitByspace[0];
										$kolDetail['middle_name'] = $splitByspace[1];
										$kolDetail['last_name'] = $splitByspace[2]." ". $splitByspace[3];
									
									}
									$kolDetail['created_by'] = $this->session->userdata('user_id');
									$kolDetail['status'] = PRENEW;
									
									$arrName1['kol_id'] = $this->payment->savenNotProfiledKols($kolDetail);
								}
								
					
						//echo $this->db->last_query();
					}
			
				$arrKolId[]=$arrName1;
				}
				
			}
		}
		//pr($arrData);
	
		
		
		//-- end Of Preparing arr for No fo attnedis
		//Preparing Array for Topics
		$noOfObjectives				= $this->input->post('noOfObjectives');		
		$topicDeatil['topic_id'] 	= $this->input->post('topic');
		$topicDeatil['objective_id']= $this->input->post('objective');
		$topicDeatil['product_id']	= $this->input->post('product');
		$topicDeatil['order']		= $this->input->post('order');
		$arrTopicDetail[]			= $topicDeatil;
		if($noOfObjectives>=1){
			for($j=1;$j<=$noOfObjectives;$j++){
				if($this->input->post('topic'.$j)!=''){
					$topicDeatil1['topic_id']		= $this->input->post('topic'.$j);
					$topicDeatil1['objective_id']	= $this->input->post('objective'.$j);
					$topicDeatil1['product_id']		= $this->input->post('product'.$j);
					$topicDeatil1['order']			= $this->input->post('order'.$j);
					$arrTopicDetail[]				= $topicDeatil1;
				}
			}
			
		}
		//End of preparing array
		
		$kolId1  = $this->input->post('kol_id');
		if(isset($kolId1) && $kolId1!=''){
			$callFrom								= 1;
			$kolId									= $this->input->post('kol_id');
		}
		$arrInteractionDetails['total_attendies']	= $this->input->post('total_attendies');
		$arrInteractionDetails['date']				= app_date_to_sql_date($this->input->post('date'));
		$arrInteractionDetails['fromtime']			= $this->input->post('timefmhr').":".$this->input->post('timefmmin')." ".$this->input->post('timefmap');
	//	$arrInteractionDetails['totime']			= $this->input->post('timetohr').":".$this->input->post('timetomin')." ".$this->input->post('timetoap');
		$arrInteractionDetails['mode']				= $this->input->post('mode');
	//	$arrInteractionDetails['location']			= $this->input->post('int_location');
		$arrInteractionDetails['follow_up_on']		= app_date_to_sql_date($this->input->post('follow_up_on'));
		if(empty($arrInteractionDetails['follow_up_on'])){
			$arrInteractionDetails['reminder']		=	0;
		}else{
			$arrInteractionDetails['reminder']		=	1;
		}
		$arrInteractionDetails['grouping']			= $this->input->post('grouping');
		$arrInteractionDetails['notes']				= $this->input->post('notes');
		$arrInteractionDetails['location_type']		= $this->input->post('selectedLocation');
		if($arrInteractionDetails['location_type']==-1){
			$kolContactDetails						= $this->kol->getKolDetailsById($kolId);
			$arrInteractionDetails['location']		= 'Primary';
			$arrInteractionDetails['address']		= $kolContactDetails[0]['address1'].' '.$kolContactDetails[0]['address2'];
			$arrInteractionDetails['city_id']		= $kolContactDetails[0]['city_id'];
			$arrInteractionDetails['state_id']		= $kolContactDetails[0]['state_id'];
			$arrInteractionDetails['postal_code']	= $kolContactDetails[0]['postal_code'];
			$arrInteractionDetails['country_id']	= $kolContactDetails[0]['country_id'];
		}else if($arrInteractionDetails['location_type']>0){
			$arrKolLocations						= $this->kol->getAdditionalContactByType($kolId,$arrInteractionDetails['location_type']);
			$arrInteractionDetails['location']		= $arrKolLocations[0]['location'];
			$arrInteractionDetails['address']		= $arrKolLocations[0]['address'];
			$arrInteractionDetails['city_id']		= $arrKolLocations[0]['city_id'];
			$arrInteractionDetails['state_id']		= $arrKolLocations[0]['state_id'];
			$arrInteractionDetails['country_id']		= $arrKolLocations[0]['country_id'];
			$arrInteractionDetails['postal_code']	= '';
		}else{
			$arrInteractionDetails['location']		= $this->input->post('location_name');
			$arrInteractionDetails['address']		= $this->input->post('address');
			$arrInteractionDetails['city_id']		= $this->input->post('city');
			$arrInteractionDetails['state_id']		= $this->input->post('state');
			$arrInteractionDetails['postal_code']	= $this->input->post('postal_code');
			$arrInteractionDetails['country_id']	= $this->input->post('country_id');
		}
		
		$arrInteractionDetails['calendar_event_id'] = $this->input->post('calendar_event_id');
		//$arrKolDetails							= $this->kol->getKolDetailsById($arrInteractionDetails['kol_id']);
		//$arrInteractionDetails['therapeutic_area']= $arrKolDetails[0]['specialty'];
		$arrInteractionDetails['fromtime']			= $this->common_helpers->convert12HourTo24HoureFormat($arrInteractionDetails['fromtime']);
		//$arrInteractionDetails['totime']			= $this->common_helpers->convert12HourTo24HoureFormat($arrInteractionDetails['totime']);
		
		
		$interactionId="";
		//Interaction calendar event details
		$returnData = array();
		$userId								=$this->session->userdata('user_id');
		$clientId							=$this->session->userdata('client_id');
		$arrEventDetails=array();
	//	$arrKolName							=$this->kol->getKolName($arrInteractionDetails['kol_id']);
		$arrEventDetails['subject']			="Follow up Meeting: ".$kolNames;
		$arrEventDetails['starttime']		=$arrInteractionDetails['follow_up_on'];
		$arrEventDetails['endtime']			=$arrInteractionDetails['follow_up_on'];
		$arrEventDetails['isalldayevent']	=true;
		$arrEventDetails['description']		='Interaction Description: '.$arrInteractionDetails['notes'];
		$arrEventDetails['location']		=$arrInteractionDetails['location'];
		$arrEventDetails['color']			="9";
		$arrEventDetails['client_id']		=$clientId;
		$arrEventDetails['event_type']		=EVENT_TYPE_INTERACTION;
		
		$intarnalUsers =$this->input->post('users');
				
		//Update the interaction if the id is already present else save a new interaction record
		if($id!=null && $id!=''){
			//Add/Update the calender event if reminder is checked
			if($arrInteractionDetails['reminder']==true){
				if($arrInteractionDetails['calendar_event_id']!=0){
					//Update the calender event
					$arrEventDetails['id']				=$arrInteractionDetails['calendar_event_id'];
					$arrEventDetails['modified_by']		=$userId;
					$arrEventDetails['modified_on']		=date("Y-m-d H:i:s");
					$this->calendar->updateEvent($arrEventDetails);
					$calendarEventId=$arrEventDetails['id'];
					
				}else {
					//Add the calender event
					$arrInteractionDetails['calendar_event_id']=$calendarEventId;
					$arrEventDetails['created_by']		=$userId;
					$arrEventDetails['created_on']		=date("Y-m-d H:i:s");
					$calendarEventId=$this->calendar->addEvent($arrEventDetails);
				}
				
			}else{
				//If reminder is unchecked and interaction has any calender event then delete that
				if($arrInteractionDetails['calendar_event_id']!=0){
					$this->calendar->deleteEvent($arrInteractionDetails['calendar_event_id']);
					$calendarEventId=0;
				}
			}
			$arrInteractionDetails['calendar_event_id']=$calendarEventId;
			$arrInteractionDetails['modified_by']	=	$this->session->userdata('user_id');
			$arrInteractionDetails['modified_on']	=	date('Y-m-d H:i:s');
			$isSaved=$this->interaction->updateInteraction($arrInteractionDetails);
			
			$interactionId=$arrInteractionDetails['id'];
			
			
			$this->interaction->deleteInteractionAttendis($arrInteractionDetails['id']);
			$this->interaction->deleteInteractionTopicDetail($arrInteractionDetails['id']);
			$this->interaction->deleteInteractionUsers($arrInteractionDetails['id']);
			foreach($arrKolId as $kolAndCatdetail){
				unset($kolAndCatdetail['kol_name']);
				$kolAndCatdetail['interaction_id'] = $arrInteractionDetails['id'];
				$kolAndCatdetail['specialty_id'] = $this->interaction->getSpecialtyIdByKol($kolAndCatdetail['kol_id']);
				$this->interaction->saveInteractionAttendis($kolAndCatdetail);
				
				$this->update->insertUpdateEntry(INTERACTION_UPDATE,$arrInteractionDetails['id'], MODULE_INTERACTION, $kolAndCatdetail['kol_id']);
				
			}
			
			foreach($arrTopicDetail as $topicDeatl){
				$topicDeatl['interaction_id'] = $arrInteractionDetails['id'];
				$this->interaction->saveInteractionTopicDetail($topicDeatl);
			}
			if(!empty($intarnalUsers) && (sizeof($intarnalUsers)>0))
			foreach($intarnalUsers as $user){
				$users['user_id'] = $user;
				$users['interaction_id'] = $arrInteractionDetails['id'];
				$this->interaction->saveInteractionInternalUsers($users);
			}
		}
		else{
			//Save the calender event if reminder is checked
			if($arrInteractionDetails['reminder']==true){
				$arrEventDetails['created_by']		=$userId;
				$arrEventDetails['created_on']		=date("Y-m-d H:i:s");
				  
				$calendarEventId=$this->calendar->addEvent($arrEventDetails);
			}
			$arrInteractionDetails['calendar_event_id']=$calendarEventId;
			$arrInteractionDetails['created_by']	=	$this->session->userdata('user_id');
			$arrInteractionDetails['created_on']	=	date('Y-m-d H:i:s');		
			$interactionId=$this->interaction->saveInteraction($arrInteractionDetails);
			foreach($arrKolId as $kolAndCatdetail){
				unset($kolAndCatdetail['kol_name']);
				$kolAndCatdetail['interaction_id'] = $interactionId;
				$kolAndCatdetail['specialty_id'] = $this->interaction->getSpecialtyIdByKol($kolAndCatdetail['kol_id']);
				$this->interaction->saveInteractionAttendis($kolAndCatdetail);
			
				$this->update->insertUpdateEntry(INTERACTION_ADD,$interactionId, MODULE_INTERACTION, $kolAndCatdetail['kol_id']);
			}
			
			foreach($arrTopicDetail as $topicDeatl){
				$topicDeatl['interaction_id'] = $interactionId;
				$this->interaction->saveInteractionTopicDetail($topicDeatl);
			}
			if(!empty($intarnalUsers) && (sizeof($intarnalUsers)>0))
			foreach($intarnalUsers as $user){
				$users['user_id'] = $user;
				$users['interaction_id'] = $interactionId;
				$this->interaction->saveInteractionInternalUsers($users);
				//echo $this->db->last_query();
			}
		}
		

	//pr($_POST);
		//If the action is from within profile
		$data['true']=true;
		echo json_encode($data);
		
	}
	
	function view_events($orgId) {
		if(!$orgId){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations');
		}
		$arrOrganizationDetail = array();
		// Getting the Organization details
		$arrOrganizationDetail = $this->organization->editOrganization($orgId);
			
		// If there is no record in the database
		if(!$arrOrganizationDetail){
			$this->session->set_flashdata('errorMessage', 'Invalid Organization Id');
			redirect('organizations/list_organizations');
		}
		$arrOrganizationTypes = $this->organization->getAllOrganizationTypes();
		$data['arrOrganizationTypes']	= $arrOrganizationTypes;
		// Set the Organization ID into the Session
		
		$data['arrOrganization']	= $arrOrganizationDetail;
		$data['assignedUsers'] = $this->align_user->getAssignedOrgUsers($orgId);
		$data['contentPage'] 	= 'organizations/view_org_events';
		$data['data']['rightSideContentPage']	= 'right_sidebar/org_events';
		$data['data']['rightSideContentPageData']	= array('orgId'=>$orgId);
		$this->load->view('layouts/client_view',$data);
	}
	
	function get_events_by_id($orgId) {
		$orgName = $this->organization->getOrgNameById($orgId);
		
		$page				= (int)$this->input->post('page'); // get the requested page 
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$data 				= array();
		$arrEventsData		= array();
		if($arrEventData = $this->organization->getAllEventsByOrgName(trim($orgName))){	
			foreach($arrEventData as $eventData){
				$arrEventDatas['event_id']				= $eventData['event_id'];
				$arrEventDatas['events_name']			= $eventData['events_name'];
				$arrEventDatas['event_type_name']		= $eventData['event_type_name'];
				$arrEventDatas['start']					= $eventData['start'];
				$arrEventDatas['end']					= $eventData['end'];
				$arrEventDatas['address']				= $eventData['address'];

					if($eventData['country_id'] != 0){
						$arrEventDatas['country']=$this->Country_helper->getCountryById($eventData['country_id']);
					}else{
						$arrEventDatas['country'] = '';					
					}
					if($eventData['state_id'] != 0){
						$arrEventDatas['state'] = $this->Country_helper->getStateById($eventData['state_id']);
					}else{
						$arrEventDatas['state'] = '';
					}
					if($eventData['city_id'] != 0){
						$arrEventDatas['city']=$this->Country_helper->getCityeById($eventData['city_id']);
					}else{
						$arrEventDatas['city'] = '';
					}
				$arrEventDatas['num_kol']				= $eventData['num_kol'];
				$arrEventsData[] = $arrEventDatas;
			}
			$count				= sizeof($arrEventsData);				
			if( $count >0 ){ 
				$total_pages	= ceil($count/$limit); 
			}else{ 
				$total_pages	= 0; 
			} 
			$data['records']	= $count;
			$data['total']		= $total_pages;
			$data['page']		= $page;				
			$data['rows']		= $arrEventsData;  
		}
		ob_start('ob_gzhandler');
		echo json_encode($data);
		
//		pr($arrEventsData);
	}
	
	function get_kols_by_event_id($eventId,$orgId){
		$orgName = $this->organization->getOrgNameById($orgId);
		$arrKolIds = $this->organization->getAllKolIdsByEventId($eventId,trim($orgName));
		foreach ($arrKolIds as $kol){
			$kolIds[] = $kol['kol_id']; 
		}
		$page				= (int)$this->input->post('page'); // get the requested page 
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$data 				= array();
		$arrKolsDetail		= array();
		if($arrKolsData = $this->organization->getKolDetailsByIds($kolIds)){
			foreach ($arrKolsData as $row){
				$arrSalutations				= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
				$kolName					= $arrSalutations[$row['salutation']].' '.$this->common_helpers->get_name_format($row['first_name'],$row['middle_name'],$row['last_name']);//$row[FIRST_ORDER] . ' '. $row[SECOND_ORDER] . ' '. $row[THIRD_ORDER];
				$arrKols['id']				= $row['id'];
				$arrKols['micro']			= '<label><div onclick="viewKolMicroProfile('.$row['id'].',event); return false;" class="tooltip-demo tooltop-top microViewIcon Male"><a rel="tooltip" class="tooltipLink" href="#" data-original-title="Profile Snapshot">&nbsp;</a></div></label>';
				$arrKols['name'] 			= $kolName;
				$arrKols['specialty']		= $row['specialty_name'];
				$arrKols['state']			= $row['Region'];
				$arrKols['country']			= $row['Country'];
				$arrKols['phone']			= $row['primary_phone'];
				$arrKols['email']			= $row['primary_email'];
				$arrKolsDetail[] = $arrKols;
			}
			$count				= sizeof($arrKolsDetail);				
			if( $count >0 ){ 
				$total_pages	= ceil($count/$limit); 
			}else{ 
				$total_pages	= 0; 
			} 
			$data['records']	= $count;
			$data['total']		= $total_pages;
			$data['page']		= $page;				
			$data['rows']		= $arrKolsDetail; 
//			pr($arrKolsDetail);
		}
		ob_start('ob_gzhandler');
		echo json_encode($data);
	}
	
	function edit_basic_info($id){
		$data = array();
		$data['arrBasicInfo'] 	=	$this->organization->getOrgBasicInfoById($id);	
		$data['orgTypes'] 		=	$this->organization->getAllOrganizationTypes();
		$data['arrMedicalServices'] =	$this->organization->getAllMedicalService();
		$data['orgMedicalServies'] =	$this->organization->getMedicalServiceDetailsById($id);
		$data['arrCities']		=	$this->Country_helper->getCitiesByStateId($data['arrBasicInfo']['state_id']);
		$data['arrStates']		=	$this->Country_helper->getStatesByCountryId($data['arrBasicInfo']['country_id']);
		$data['arrCountry']		=	$this->Country_helper->listCountries();
//		$data['orgStatFacts']	=	$this->organization->listCountries();
//		$data['orgPayerFacts']	=	$this->organization->listCountries();
//		$data['contentPage'] 	= 'organizations/edit_org/edit_org_basic_info';
//		$this->load->view('layouts/client_view',$data);
//		pr($data['orgMedicalServies']);
		$this->load->view('organizations/edit_org/edit_org_basic_info',$data); 
	}
	
	function update_org_profile(){
		$arrData = array();
		$arrData['id'] = $this->input->post("id");
		$arrData['profile_type'] = $this->input->post("profile_type");
		$arrData['name'] = $this->input->post("comp_name");
		$arrData['type_id'] = $this->input->post("org_type");
		$arrData['npi_num'] = $this->input->post("npi_num");
		$arrData['key_reginal_offices'] = $this->input->post("key_reg_off");
		$arrData['website'] = $this->input->post("website");
		$arrData['founded'] = $this->input->post("founded");
		$arrData['headquarters'] = $this->input->post("comp_hq");
		$arrData['address'] = $this->input->post("address");
		$arrData['city_id'] = $this->input->post("city_id");
		$arrData['state_id'] = $this->input->post("state_id");
		$arrData['country_id'] = $this->input->post("country_id");
		$arrData['postal_code'] = $this->input->post("postal_code");
		$arrData['fax'] = $this->input->post("fax");
		$arrData['phone'] = $this->input->post("phone");
		$arrData['background'] = $this->input->post("comp_background");
		$arrData['products_services'] = $this->input->post("product_services");
		$arrData['mission_vision'] = $this->input->post("mission_vission");
		$arrData['key_products'] = $this->input->post("key_product");
		$arrData['mergers'] = $this->input->post("mergers");
		$arrData['clients'] = $this->input->post("top_client");
		
		if($arrData['type_id'] != 8){
			$arrMedicalService = array();
			$medical_services = $this->input->post("medicalServies");
			$this->organization->deleteMedicalService($arrData['id']);
			foreach ($medical_services as $key=>$val){
				$arrMedicalService[] = array('medical_service_id'=>$val,'org_id'=>$arrData['id']);
			}
			$this->organization->saveMedicalService($arrMedicalService);				
		}
		$result = $this->organization->updateOrganization($arrData);
		if($result){
			redirect("organizations/view/".$arrData['id']."");
		}
	}
	
	function edit_affiliations_and_partners($orgId){
		
		$data['arrCities']		=	$this->Country_helper->getCitiesByStateId($data['arrBasicInfo']['state_id']);
		$data['arrStates']		=	$this->Country_helper->getStatesByCountryId($data['arrBasicInfo']['country_id']);
		$data['arrCountry']		=	$this->Country_helper->listCountries();
		$this->load->view('organizations/edit_org/edit_affiliations_and_partners',$data);
	}
	
	function edit_facts($orgId){
		$data['arrFacts'] = $this->organization->getFactsById($orgId);
		$this->load->view('organizations/edit_org/edit_facts',$data);
	}
	
	function add_facts($orgId){
		$data['org_id'] = $orgId;
		$this->load->view('organizations/edit_org/edit_facts',$data);	
	}
	function save_org_facts(){
		$arrData = array();
	    $orgId 								= $this->input->post("org_id");
	    $arrData['org_id'] 					= $this->input->post("org_id");
	    $arrData['no_of_beds'] 				= $this->input->post("no_of_beds");
	    $arrData['inpatient'] 				= $this->input->post("inpatient");
	    $arrData['outpatient'] 				= $this->input->post("outpatient");
	    $arrData['births'] 					= $this->input->post("births");
	    $arrData['emergency_department'] 	= $this->input->post("emrg_depart");
	    $arrData['no_of_surgeries'] 		= $this->input->post("no_of_surg");
	    $arrData['link1'] 					= $this->input->post("link1");
	    $arrData['link2'] 					= $this->input->post("link2");
	    
	    $data = $this->organization->saveOrgFacts($arrData);
		if($data){
				redirect("organizations/view/".$orgId."");
			}
	}
	function update_org_facts(){
	    $arrData = array();
	    $orgId 								= $this->input->post("org_id");
	    $arrData['id'] 						= $this->input->post("id");
	    $arrData['no_of_beds'] 				= $this->input->post("no_of_beds");
	    $arrData['inpatient'] 				= $this->input->post("inpatient");
	    $arrData['outpatient'] 				= $this->input->post("outpatient");
	    $arrData['births'] 					= $this->input->post("births");
	    $arrData['emergency_department'] 	= $this->input->post("emrg_depart");
	    $arrData['no_of_surgeries'] 		= $this->input->post("no_of_surg");
	    $arrData['link1'] 					= $this->input->post("link1");
	    $arrData['link2'] 					= $this->input->post("link2");
	    $data = $this->organization->updateOrgFacts($arrData);
		if($data){
				redirect("organizations/view/".$orgId."");
			} 
	}
	
	function edit_payer_facts($orgId){
		$data['arrPayerFacts'] = $this->organization->getPayerFactsById($orgId);
		$data['orgClaimProcess'] = $this->organization->getClaimsaAndProcess();
		$this->load->view('organizations/edit_org/edit_payer_facts',$data);
	}
	
	function update_org_payer_facts(){
    	$arrData = array();
	    $orgId 									= $this->input->post("org_id");
	    $arrData['id'] 							= $this->input->post("id");
	    $arrData['no_of_hospitals'] 			= $this->input->post("no_of_hospitals");
	    $arrData['no_of_physicians'] 			= $this->input->post("no_of_physicians");
	    $arrData['no_of_affiliated'] 			= $this->input->post("no_of_affiliated");
	    $arrData['benefit_management'] 			= $this->input->post("benefit_management");
	    $arrData['specialty_pharmacy'] 			= $this->input->post("specialty_pharmacy");
	    $arrData['ncqa_status'] 				= $this->input->post("ncqa_status");
	    $arrData['start_rating'] 				= $this->input->post("start_rating");
	    $arrData['physicians_employed'] 		= $this->input->post("physicians_employed");
		$data=$this->organization->updatePayerFacts($arrData);
		$claim_emr = $this->input->post('claim_emr');
		$data_process = $this->input->post('data_process');
		if($data){
			foreach ($claim_emr as $k => $v){
				$arrClaim['fact_id']			=	$arrData['id'];
				$arrClaim['cliam_process_id']	=	$v;
				$arrClaim['type_id']			=	1;
				$arrClaimData[] = $arrClaim; 		
			}
			foreach ($data_process as $k => $v){
				$arrProcess['fact_id']			=	$arrData['id'];
				$arrProcess['cliam_process_id']	=	$v;
				$arrProcess['type_id']			=	2;
				$arrClaimData[]					=	$arrProcess;		
			}
			$this->organization->update_org_claims_process_mapped_data($arrClaimData,$arrData['id']);
		}
		redirect("organizations/view/".$orgId."");
	}
	
	function add_payer_facts($orgId){
		$data['org_id'] = $orgId;
		$data['orgClaimProcess'] = $this->organization->getClaimsaAndProcess();
		$this->load->view('organizations/edit_org/edit_payer_facts',$data);
	}
	
	function save_org_payer_facts(){
		$arrData = array();
	    $orgId 									= $this->input->post("org_id");
	    $arrData['org_id'] 						= $this->input->post("org_id");
	    $arrData['no_of_hospitals'] 			= $this->input->post("no_of_hospitals");
	    $arrData['no_of_physicians'] 			= $this->input->post("no_of_physicians");
	    $arrData['no_of_affiliated'] 			= $this->input->post("no_of_affiliated");
	    $arrData['benefit_management'] 			= $this->input->post("benefit_management");
	    $arrData['specialty_pharmacy'] 			= $this->input->post("specialty_pharmacy");
	    $arrData['ncqa_status'] 				= $this->input->post("ncqa_status");
	    $arrData['start_rating'] 				= $this->input->post("start_rating");
	    $arrData['physicians_employed'] 		= $this->input->post("physicians_employed");
	    $data = $this->organization->savePayerFacts($arrData);
	    $claim_emr = $this->input->post('claim_emr');
		$data_process = $this->input->post('data_process');
		if($data){
			foreach ($claim_emr as $k => $v){
				$arrClaim['fact_id']			=	$data;
				$arrClaim['cliam_process_id']	=	$v;
				$arrClaim['type_id']			=	1;
				$arrClaimData[] = $arrClaim; 		
			}
			foreach ($data_process as $k => $v){
				$arrProcess['fact_id']			=	$data;
				$arrProcess['cliam_process_id']	=	$v;
				$arrProcess['type_id']			=	2;
				$arrClaimData[]					=	$arrProcess;		
			}
			if(sizeof($arrClaimData)>0){
				$this->organization->save_org_claims_process_mapped_data($arrClaimData);
			}
		}
		redirect("organizations/view/".$orgId."");
	}
	
	function delete_sub_org($orgId){
		$result = $this->organization->deleteSubOrg($orgId);
		if($result){
			$data['status'] = true;
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}
	
	function edit_social_media($orgId){
		$data['socialMedia'] = $this->organization->getOrgSocialMediaById($orgId);
		$this->load->view("organizations/edit_social_media",$data);
	}
	
	function update_org_social_media(){
//		pr($_POST);
		$arrData = array();
	    $orgId 							= $this->input->post("org_id");
	    $arrData['id'] 					= $this->input->post("org_id");
//	    $arrData['blog'] 				= $this->input->post("blogger");
	    $arrData['facebook'] 			= $this->input->post("facebook");
	    $arrData['twitter'] 			= $this->input->post("twitter");
//	    $arrData['linkedin'] 			= $this->input->post("linkedin");
	    $arrData['youtube'] 			= $this->input->post("youtube");
	    if($this->organization->updateOrgSocialMedia($arrData)){
	    	redirect("organizations/view/".$orgId."/social_media");
	    }
	}
	
	function add_client_kol($kolId = null){
		$arrSalutations	= array(1=>'Dr.', 2=>'Prof.', 3=>'Mr.', 4=>'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		// Get the list of Specialties
		if($kolId != null){
			$arrKolDetail = $this->kol->editKol($kolId);
			$data['arrCountry']				=	$this->Country_helper->listCountries();
			$arrStates 						= array();
			$arrCities						= array();
			if($arrKolDetail['country_id'] != 0){
				$arrStates = $this->Country_helper->getStatesByCountryId($arrKolDetail['country_id']);
			}
			if($arrKolDetail['state_id'] 	!= 0){
				$arrCities 					= $this->Country_helper->getCitiesByStateId($arrKolDetail['state_id']);
			}
			$data['arrStates']				= $arrStates;
			$data['arrCities']				= $arrCities;
			
			
			if($arrKolDetail['org_id']!=0){
				$arrKolDetail['org_name'] = $this->organization->getOrgNameByOrgId($arrKolDetail['org_id']);
			}
		}else
			$data['arrCountry']				=	$this->Country_helper->listCountries();
		
		$this->load->model('Specialty');
		$arrSpecialties					= $this->Specialty->getAllSpecialties();
		$data['arrSpecialties']			= $arrSpecialties;
		
		$data['arrKols'] = $arrKolDetail;
		$data['kolId'] = $kolId;
		$this->load->view('organizations/add_client_kol',$data);
	}
	
	function process_url_parameters($urlString){
		$filters = $this->filters_to_array($urlString);
		$organizationId = (isset($filters['AISSELID'])) ? $filters['AISSELID'] : null;
		$orgName = (isset($filters['ONAME'])) ? $filters['ONAME'] : null;
		$CGDMAPPID = (isset($filters['CGDMAPPID'])) ? $filters['CGDMAPPID'] : null;
		$CGDMUSERID = (isset($filters['CGDMUSERID'])) ? $filters['CGDMUSERID'] : null;
		
		if($organizationId != null && $organizationId != ''){
			$orgIdPrefix = substr($organizationId,0,1);
			$organizationId = substr($organizationId,1,strlen($organizationId)-1);
			
			if($organizationId != null && $organizationId != '' && is_numeric($organizationId))
				return $organizationId;
		}
		//First cehck all the parameters are set or not
		if($orgName != null && $orgName != ''){
			redirect(base_url()."requested_orgs/show_client_requested_orgs/".$urlString);
		}
		
		return $organizationId;
	}
	
	/**
	 * 
	 * @author 	Ramesh B 
	 * @since	
	 * @return 
	 * @created 15 Jan 2014
	 */
	function filters_to_array($reportFilters){
		$filters = array();
		if($reportFilters != ''){
			$reportFiltersElements = explode(':',$reportFilters);
			foreach ($reportFiltersElements as $filterElement){
				$filterElements = explode('=',$filterElement);
				$filterName = $filterElements[0];
				$filterValue = $filterElements[1];
				$filters[$filterName] = $filterValue;
			}
		}
		return $filters;
	}
	
	function single_org_export($orgId,$type){
		$orgIds=array();
		$orgIds[]=$orgId;
		if($type==8){
			$this->org_payer_export_excel($orgIds);
//			$this->org_export_excel($orgIds);
//			$this->org_payer_export($orgIds);
		}else{
//			$this->org_export($orgIds);
			$this->org_export_excel($orgIds);
//			$this->org_payer_export_excel($orgIds);
		}
	}
	
	function multiple_org_export($values,$type){
//		$values=$this->input->post('org_ids');
//		echo $values;
//		exit();
		//$values = 250,245,246;
		$orgIds=explode(',',$values);
	
		//$orgIds = array(250,245,246);
		if($type==8){
//			$this->org_payer_export($orgIds);
			$this->org_payer_export_excel($orgIds);
		}else{
//			$this->org_export($orgIds);
			$this->org_export_excel($orgIds);
		}
	}
	
	function org_export_excel($orgIds){
		$startTime = microtime(true);
		ini_set('memory_limit',"-1");
		ini_set("max_execution_time",0);
		$this->load->plugin('php_excel/Classes/PHPExcel.php');
		$clientId = $this->session->userdata('client_id');
//		$orgIds = array(1053,555,320,976,310);
		foreach($orgIds as $id){
			//Getting the Organizations Details
			$arrOrganizationDetail[$id]	= $this->organization->getOrgDetails($id);
			$orgAdress[$id]				= $this->organization->getAdreessOfOrg($id);
			$orgMedialService[$id]		= $this->organization->getOrgMediaclServiceDetail($id);
			$subOrgDetails[$id]			= $this->organization->getSubOrg($id);
			$orgSocialMediaDetails[$id]	= $this->organization->getSocialMediaDetailsOfOrg($id);
			$orgkeyPeoples[$id]			= $this->organization->getKeyPeopleDetailsOfOrg($id);
			$arrAssocitedPeople[$id]	= $this->organization->listOrgAssociatedPpl($id);
			$arrStatsFacts[$id] 		=  $this->organization->getOrgStatsFacts($id);
			$arrPubDetails[$id] 		= $this->pubmed_org->listOrgPublicationDetails($id,null);
			$arrClinicalTrialsResults[$id] = $this->clinical_trial_org->listClinicalTrialsDetails($id);
		}
//		$arrOrganizationDetail	=	$this->organization->getOrgDetails(1053);
//		pr($arrOrganizationDetail);
//		pr($orgAdress);
//		pr($orgMedialService);
//		pr($subOrgDetails);
//		pr($orgSocialMediaDetails);
//		pr($orgkeyPeoples);
//		pr($arrAssocitedPeople);
//		pr($arrStatsFacts);
//		pr($arrPubDetails);
//		pr($arrClinicalTrialsResults);
//		exit();
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		//Prepare sheet and headers
		
		// Company overview section 
		$objWorksheet = $objPHPExcel->getActiveSheet();
		$objWorksheet->setTitle('Company Overview');
		//Add header
		$objWorksheet->setCellValue('A1', 'CIN NUM')
						->setCellValue('B1', 'Company Name')
						->setCellValue('C1', 'Company Type')
						->setCellValue('D1', 'Logo')
						->setCellValue('E1', 'Website')
						->setCellValue('F1', 'Company Headquarters')
						->setCellValue('G1', 'Company Background')
						->setCellValue('H1', 'Mission, Vission & Values')
						->setCellValue('I1', 'Founded')
						->setCellValue('J1', 'NPI Number')
						->setCellValue('K1', 'Profile Type');
		if($clientId == INTERNAL_CLIENT_ID){
			$objWorksheet->setCellValue('L1', 'URL');
		}
//		$objPHPExcel->addSheet($objWorksheet);
		foreach($orgIds as $id){
			//Getting the Organizations Details
			$arrOrganizationDetail[$id]	= $this->organization->getOrgDetails($id);
		}
//		pr($arrOrganizationDetail);
//		exit();
		$i = 2;
		foreach($orgIds as $id){
			//Getting the Organizations Details
			foreach ($arrOrganizationDetail[$id] as $row){
				$objWorksheet->setCellValue('A'.$i, $row['cin_num'])
									->setCellValue('B'.$i, $row['name'])
									->setCellValue('C'.$i, $row['type'])
									->setCellValue('D'.$i, $row['company_logo'])
									->setCellValue('E'.$i, $row['website'])
									->setCellValue('F'.$i, $row['headquarters'])
									->setCellValue('G'.$i, $row['background'])
									->setCellValue('H'.$i, $row['mission_vision'])
									->setCellValue('I'.$i, $row['founded'])
									->setCellValue('J'.$i, $row['npi_num']);
						if($orgValue['profile_type']==BASIC){
							$objWorksheet->setCellValue('K'.$i, "Basic");
						}				
						
						if($orgValue['profile_type']==FULL){
							$objWorksheet->setCellValue('K'.$i, "Full Profile");
						}	
						if($clientId==INTERNAL_CLIENT_ID){
							$objWorksheet->setCellValue('L'.$i, $row['url']);
						}
				$i++;			
			}
		}
		// Address section 
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle('Address');
		//Add header
		$objWorksheet->setCellValue('A1', 'CIN NUM')
						->setCellValue('B1', 'Company Name')
						->setCellValue('C1', 'Address')
						->setCellValue('D1', 'City')
						->setCellValue('E1', 'Postal Code')
						->setCellValue('F1', 'State')
						->setCellValue('G1', 'Country')
						->setCellValue('H1', 'Phone')
						->setCellValue('I1', 'Fax')
						->setCellValue('J1', 'Additional Phone Numbers');
		if($clientId == INTERNAL_CLIENT_ID){
			$objWorksheet->setCellValue('K1', 'URL');
		}
		
		$i = 2;
		foreach($orgIds as $id){
			//Getting the Organizations Details
			foreach ($orgAdress[$id] as $row){
				$objWorksheet->setCellValue('A'.$i, $row['cin_num'])
									->setCellValue('B'.$i, $row['name'])
									->setCellValue('C'.$i, $row['address'])
									->setCellValue('D'.$i, $row['city'])
									->setCellValue('E'.$i, $row['postal_code'])
									->setCellValue('F'.$i, $row['region'])
									->setCellValue('G'.$i, $row['country'])
									->setCellValue('H'.$i, $row['phone'])
									->setCellValue('I'.$i, $row['fax']);
						$arrAdditionalContacts=$this->organization->getaddtionalContcat($id);
						//pr($arrAdditionalContacts);
						$phoneDetails='';
						$phoneDetails=implode("\n",$arrAdditionalContacts);
						$objWorksheet->setCellValue('J'.$i, $phoneDetails);
						if($clientId==INTERNAL_CLIENT_ID){
							if(isset($row['url']))
							$objWorksheet->setCellValue('K'.$i, $row['url']);
						}
				$i++;			
			}
		}
		
		$objPHPExcel->addSheet($objWorksheet);
		
		// Medical Services section 
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle('Medical Services');
		//Add header
		$objWorksheet->setCellValue('A1', 'CIN NUM')
						->setCellValue('B1', 'Company Name')
						->setCellValue('C1', 'Medical Services');
		if($clientId == INTERNAL_CLIENT_ID){
			$objWorksheet->setCellValue('D1', 'URL');
		}

		$i = 2;
		foreach($orgIds as $id){
			//Getting the Organizations Details
			foreach ($orgMedialService[$id] as $row){
				$objWorksheet->setCellValue('A'.$i, $row['cin_num'])
									->setCellValue('B'.$i, $row['name'])
									->setCellValue('C'.$i, $row['medical_service']);
		
						if($clientId==INTERNAL_CLIENT_ID){
							if(isset($row['url']))
							$objWorksheet->setCellValue('D'.$i, $row['url']);
						}
				$i++;			
			}
		}
		
		$objPHPExcel->addSheet($objWorksheet);
		
		// Affiliates & Partnership section 
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle('Affiliates & Partnership');
		//Add header
		$objWorksheet->setCellValue('A1', 'CIN NUM')
						->setCellValue('B1', 'Company Name')
						->setCellValue('C1', 'Institute Name')
						->setCellValue('D1', 'Address')
						->setCellValue('E1', 'City')
						->setCellValue('F1', 'Postal Code')
						->setCellValue('G1', 'State')
						->setCellValue('H1', 'Country')
						->setCellValue('I1', 'Phone')
						->setCellValue('J1', 'NPI Number');
		if($clientId == INTERNAL_CLIENT_ID){
			$objWorksheet->setCellValue('K1', 'URL');
		}

		$i = 2;
		foreach($orgIds as $id){
			//Getting the Organizations Details
			foreach ($subOrgDetails[$id] as $row){
				$objWorksheet->setCellValue('A'.$i, $row['cin_num'])
									->setCellValue('B'.$i, $row['name'])
									->setCellValue('C'.$i, $row['sub_org'])
									->setCellValue('D'.$i, $row['address'])
									->setCellValue('E'.$i, $row['city'])
									->setCellValue('F'.$i, $row['postal_code'])
									->setCellValue('G'.$i, $row['region'])
									->setCellValue('H'.$i, $row['country'])
									->setCellValue('I'.$i, $row['phone'])
									->setCellValue('J'.$i, $row['npi_num']);
		
						if($clientId==INTERNAL_CLIENT_ID){
							$objWorksheet->setCellValue('K'.$i, $row['url']);
						}
				$i++;			
			}
		}
		
		$objPHPExcel->addSheet($objWorksheet);
						
		// Social Media section 
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle('Social Media');
		//Add header
		$objWorksheet->setCellValue('A1', 'CIN NUM')
						->setCellValue('B1', 'Company Name')
						->setCellValue('C1', 'Blog')
						->setCellValue('D1', 'Youtube')
						->setCellValue('E1', 'Linkedin')
						->setCellValue('F1', 'Facebook')
						->setCellValue('G1', 'Twitter');

		$i = 2;
		foreach($orgIds as $id){
			//Getting the Organizations Details
			foreach ($orgSocialMediaDetails[$id] as $row){
				$objWorksheet->setCellValue('A'.$i, $row['cin_num'])
									->setCellValue('B'.$i, $row['name'])
									->setCellValue('C'.$i, $row['blog'])
									->setCellValue('D'.$i, $row['youtube'])
									->setCellValue('E'.$i, $row['linkedin'])
									->setCellValue('F'.$i, $row['facebook'])
									->setCellValue('G'.$i, $row['twitter']);
				$i++;						
			}
		}	
						
		$objPHPExcel->addSheet($objWorksheet);
						
		// Key people section 
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle('Key People');
		//Add header
		$objWorksheet->setCellValue('A1', 'CIN NUM')
						->setCellValue('B1', 'Company Name')
						->setCellValue('C1', 'Role')
						->setCellValue('D1', 'Salutation')
						->setCellValue('E1', 'First Name')
						->setCellValue('F1', 'Middle Name')
						->setCellValue('G1', 'Last Name')
						->setCellValue('H1', 'Department/Division/Center')
						->setCellValue('I1', 'Title')
						->setCellValue('J1', 'Email');
		if($clientId == INTERNAL_CLIENT_ID){
			$objWorksheet->setCellValue('K1', 'URL');
		}
		
		$i = 2;
		foreach($orgIds as $id){
			//Getting the Organizations Details
			foreach ($orgkeyPeoples[$id] as $row){
				$objWorksheet->setCellValue('A'.$i, $row['cin_num'])
									->setCellValue('B'.$i, $row['name'])
									->setCellValue('C'.$i, $row['role'])
									->setCellValue('D'.$i, $row['salutation'])
									->setCellValue('E'.$i, $row['first_name'])
									->setCellValue('F'.$i, $row['middle_name'])
									->setCellValue('G'.$i, $row['last_name'])
									->setCellValue('H'.$i, $row['department'])
									->setCellValue('I'.$i, $row['title'])
									->setCellValue('J'.$i, $row['email']);
		
						if($clientId==INTERNAL_CLIENT_ID){
							$objWorksheet->setCellValue('K'.$i, $row['url']);
						}
				$i++;			
			}
			
		}
		
		$objPHPExcel->addSheet($objWorksheet);
		
		// Associated People section $arrAssocitedPeople
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle('Associated People');
		// Add header
		$objWorksheet->setCellValue('A1', 'CIN NUM')
						->setCellValue('B1', 'Company Name')
						->setCellValue('C1', 'KOL Name')
						->setCellValue('D1', 'Specialty')
						->setCellValue('E1', 'Country')
						->setCellValue('F1', 'Phone')
						->setCellValue('G1', 'Email');
						
		$i = 2;
		$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		foreach($orgIds as $id){
			//Getting the Organizations Details
			foreach ($arrAssocitedPeople[$id] as $row){
				$kolName = $arrSalutations[$row['salutation']]." ".$row['first_name']." ".$row['middle_name']." ".$row['last_name'];
				$objWorksheet->setCellValue('A'.$i, $row['cin_num'])
									->setCellValue('B'.$i, $row['name'])
									->setCellValue('C'.$i, $kolName)
									->setCellValue('D'.$i, $row['specialty'])
									->setCellValue('E'.$i, $row['country'])
									->setCellValue('F'.$i, $row['phone'])
									->setCellValue('G'.$i, $row['email']);
				$i++;					
			}
		}				
		$objPHPExcel->addSheet($objWorksheet);
						
		// Facts section 
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle('Facts');
		//Add header
		$objWorksheet->setCellValue('A1', 'CIN NUM')
						->setCellValue('B1', 'Company Name')
						->setCellValue('C1', 'NO. Of Beds')
						->setCellValue('D1', 'Inpatient')
						->setCellValue('E1', 'Births')
						->setCellValue('F1', 'Outpatient')
						->setCellValue('G1', 'Emergency Department')
						->setCellValue('H1', 'NO. Of Surgeries');
		if($clientId == INTERNAL_CLIENT_ID){
			$objWorksheet->setCellValue('I1', 'URL1')
						->setCellValue('J1', 'URL2');
		}
		
		$i = 2;
		foreach($orgIds as $id){
			//Getting the Organizations Details
			foreach ($arrStatsFacts[$id] as $row){
				$objWorksheet->setCellValue('A'.$i, $row['cin_num'])
									->setCellValue('B'.$i, $row['name'])
									->setCellValue('C'.$i, $row['no_of_beds'])
									->setCellValue('D'.$i, $row['inpatient'])
									->setCellValue('E'.$i, $row['births'])
									->setCellValue('F'.$i, $row['outpatient'])
									->setCellValue('G'.$i, $row['emergency_department'])
									->setCellValue('H'.$i, $row['no_of_surgeries']);
		
						if($clientId==INTERNAL_CLIENT_ID){
							$objWorksheet->setCellValue('I'.$i, $row['link1'])
										->setCellValue('J'.$i, $row['link2']);
						}
				$i++;			
			}
			
		}
		
		$objPHPExcel->addSheet($objWorksheet);
		
		// Publications section 
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle('Publications');
		//Add header
		$objWorksheet->setCellValue('A1', 'CIN NUM')
						->setCellValue('B1', 'Company Name')
						->setCellValue('C1', 'Article Title')
						->setCellValue('D1', 'PMID')
						->setCellValue('E1', 'Journal Name')
						->setCellValue('F1', 'Date')
						->setCellValue('G1', 'Authors');
						
		$i = 2;
		foreach($orgIds as $id){
			//Getting the Organizations Details
			foreach ($arrPubDetails[$id] as $row){
				$objWorksheet->setCellValue('A'.$i, $row['cin_num'])
									->setCellValue('B'.$i, $row['orgName'])
									->setCellValue('C'.$i, $row['article_title'])
									->setCellValue('D'.$i, $row['pmid'])
									->setCellValue('E'.$i, $row['jname'])
									->setCellValue('F'.$i, $this->organization->convertDateToMM_DD_YYYY($row['created_date']))
									->setCellValue('G'.$i, $this->get_pub_authors($row['id']));
				$i++;			
			}
			
		}
						
		$objPHPExcel->addSheet($objWorksheet);
						
		// Trial section 
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle('Trial');
		//Add header
		$objWorksheet->setCellValue('A1', 'CIN NUM')
						->setCellValue('B1', 'Company Name')
						->setCellValue('C1', 'CTID')
						->setCellValue('D1', 'Study Type')
						->setCellValue('E1', 'Trial Name')
						->setCellValue('F1', 'Condition')
						->setCellValue('G1', 'Intervention')
						->setCellValue('H1', 'Phase')
						->setCellValue('I1', 'Number of Enrollees')
						->setCellValue('J1', 'Number of Trial Sites')
						->setCellValue('K1', 'Sponsers')
						->setCellValue('L1', 'Status')
						->setCellValue('M1', 'Start Date')
						->setCellValue('N1', 'End Date')
						->setCellValue('O1', 'Minimum Age')
						->setCellValue('P1', 'Maximum Age')
						->setCellValue('Q1', 'Gender')
						->setCellValue('R1', 'Investigators')
						->setCellValue('S1', 'Collaborator')
						->setCellValue('T1', 'Purpose')
						->setCellValue('U1', 'Official Title')
						->setCellValue('V1', 'Keywords')
						->setCellValue('W1', 'MeSH Terms');

		$i = 2;
		foreach($orgIds as $id){
			//Getting the Organizations Details
			foreach ($arrClinicalTrialsResults[$id] as $row){
				$objWorksheet->setCellValue('A'.$i, $row['cin_num'])
									->setCellValue('B'.$i, $row['name'])
									->setCellValue('C'.$i, $row['ct_id'])
									->setCellValue('D'.$i, $row['study_type'])
									->setCellValue('E'.$i, $row['trial_name'])
									->setCellValue('F'.$i, $row['condition'])
									->setCellValue('G'.$i, $this->get_interventions($row['id']))
									->setCellValue('H'.$i, $row['phase'])
									->setCellValue('I'.$i, $row['no_of_enrollees'])
									->setCellValue('J'.$i, $row['no_of_trial_sites'])
									->setCellValue('K'.$i, $this->get_sponsers($row['id']))
									->setCellValue('L'.$i, $this->clinical_trial->getStatusNameById($row['status_id']))
									->setCellValue('M'.$i, $row['start_date'])
									->setCellValue('N'.$i, $row['end_date'])
									->setCellValue('O'.$i, $row['min_age'])
									->setCellValue('P'.$i, $row['max_age'])
									->setCellValue('Q'.$i, $row['gender'])
									->setCellValue('R'.$i, $this->get_investigators($row['id']))
									->setCellValue('S'.$i, $row['collaborator'])
									->setCellValue('T'.$i, $row['purpose'])
									->setCellValue('U'.$i, $row['official_title']);
									$arrKeywordsData	= '';
									$separator			= '';
									foreach($this->clinical_trial->listCTIKeyWords($row['id']) as $key=>$row){
										$arrKeywordsData	.=	$separator.$row['name'];
										$separator	= ',';
									}
									$arrMeshtermsData	= '';
									$separator			= '';
									foreach($this->clinical_trial->listCTMeshTerms($row['id']) as $key=>$row){
										$arrMeshtermsData	.=	$separator.$row['term_name'];
										$separator	= ',';
									}
						$objWorksheet->setCellValue('V'.$i, $arrKeywordsData)
									->setCellValue('W'.$i, $arrMeshtermsData);
				$i++;			
			}
		}				
		$objPHPExcel->addSheet($objWorksheet);
		
		$styleArray = array(
			'borders' => array(
				'bottom' => array(
					'style' => PHPExcel_Style_Border::BORDER_THICK,
					'color' => array('argb' => '0000000'),
				),
			),
		);
		
		$arrStyles =  array(
                  'font'    => array(
                      'bold'      => true,
                      'italic'    => false
                  ),
                  'borders' => array(
                      'bottom'     => array(
                          'style' => PHPExcel_Style_Border::BORDER_THICK,
                          'color' => array(
                              'rgb' => '000000'
                          )
                      ),
                      'quotePrefix'    => true
                  )
              );
              
		foreach(range('A','L') as $columnID) {
		    $objPHPExcel->getSheet(0)->getColumnDimension($columnID)->setWidth(30);
		}
        $objPHPExcel->getSheet(0)->getStyle('A1:L1')->applyFromArray($arrStyles);
         
		foreach(range('A','K') as $columnID) {
		    $objPHPExcel->getSheet(1)->getColumnDimension($columnID)->setWidth(30);
		}
        $objPHPExcel->getSheet(1)->getStyle('A1:K1')->applyFromArray($arrStyles);
         
		foreach(range('A','D') as $columnID) {
		    $objPHPExcel->getSheet(2)->getColumnDimension($columnID)->setWidth(30);
		}
        $objPHPExcel->getSheet(2)->getStyle('A1:D1')->applyFromArray($arrStyles);
        
		foreach(range('A','K') as $columnID) {
		    $objPHPExcel->getSheet(3)->getColumnDimension($columnID)->setWidth(30);
		}
       	$objPHPExcel->getSheet(3)->getStyle('A1:K1')->applyFromArray($arrStyles);
       	
		foreach(range('A','G') as $columnID) {
		    $objPHPExcel->getSheet(4)->getColumnDimension($columnID)->setWidth(30);
		}
       	$objPHPExcel->getSheet(4)->getStyle('A1:G1')->applyFromArray($arrStyles);
       	
		foreach(range('A','K') as $columnID) {
		    $objPHPExcel->getSheet(5)->getColumnDimension($columnID)->setWidth(30);
		}
       	$objPHPExcel->getSheet(5)->getStyle('A1:K1')->applyFromArray($arrStyles);
       	
		foreach(range('A','G') as $columnID) {
		    $objPHPExcel->getSheet(6)->getColumnDimension($columnID)->setWidth(30);
		}
       	$objPHPExcel->getSheet(6)->getStyle('A1:G1')->applyFromArray($arrStyles);
       	
		foreach(range('A','J') as $columnID) {
		    $objPHPExcel->getSheet(7)->getColumnDimension($columnID)->setWidth(30);
		}
       	$objPHPExcel->getSheet(7)->getStyle('A1:J1')->applyFromArray($arrStyles);
       	
		foreach(range('A','G') as $columnID) {
		    $objPHPExcel->getSheet(8)->getColumnDimension($columnID)->setWidth(30);
		}
       	$objPHPExcel->getSheet(8)->getStyle('A1:G1')->applyFromArray($arrStyles);
       	
       	foreach(range('A','W') as $columnID) {
		    $objPHPExcel->getSheet(9)->getColumnDimension($columnID)->setWidth(30);
		}
       	$objPHPExcel->getSheet(9)->getStyle('A1:W1')->applyFromArray($arrStyles);
       	
		$objPHPExcel->setActiveSheetIndex(0);
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

		// Redirect output to a client’s web browser (Excel2007)
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment;filename="Organization_profiles.xlsx"');
		header('Cache-Control: max-age=0');
		// If you're serving to IE 9, then the following may be needed
		header('Cache-Control: max-age=1');

		// If you're serving to IE over SSL, then the following may be needed
		header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
		header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
		header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
		header ('Pragma: public'); // HTTP/1.0

		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save('php://output');
		exit;
		
	}
	
	function org_payer_export_excel($orgIds){
		$startTime = microtime(true);
		ini_set('memory_limit',"-1");
		ini_set("max_execution_time",0);
		$this->load->plugin('php_excel/Classes/PHPExcel.php');
		$clientId = $this->session->userdata('client_id');
		$arrOrganizationDetail1	= array();
		foreach($orgIds as $id){
			//Getting the Organizations Details
			$arrOrganizationDetail[$id]	= $this->organization->getOrgDetails($id);
			$arrOrganizationDetail1[$id][0] = $arrOrganizationDetail[$id][0]['cin_num'];
			$arrOrganizationDetail1[$id][1] = $arrOrganizationDetail[$id][0]['name'];
			$orgAdress[$id]				= $this->organization->getAdreessOfOrg($id);
			$arrStatsFacts[$id]			= $this->organization->getOrgPayerStatsFacts($id);
			$arrFormularies[$id]		= $this->organization->getOrgPayerFormularies($id);
			$arrManagements[$id]		= $this->organization->getOrgPayerDiseaseManagements($id);
			$arrRatings[$id]			= $this->organization->getOrgCollabarationRatings($id);
			$orgkeyPeoples[$id]			= $this->organization->getKeyPeopleDetailsOfOrg($id);
			$orgSocialMediaDetails[$id]	= $this->organization->getSocialMediaDetailsOfOrg($id);
		}
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->setActiveSheetIndex(0);
		//Prepare sheet and headers
		
		// Company overview section 
		$objWorksheet = $objPHPExcel->getActiveSheet();
		$objWorksheet->setTitle('Company Overview');
		//Add header
		$objWorksheet->setCellValue('A1', 'CIN NUM')
						->setCellValue('B1', 'Company Name')
						->setCellValue('C1', 'Company Type')
						->setCellValue('D1', 'Logo')
						->setCellValue('E1', 'Website')
						->setCellValue('F1', 'Company Headquarters')
						->setCellValue('G1', 'Company Background')
						->setCellValue('H1', 'Mission, Vission & Values')
						->setCellValue('I1', 'Key Products')
						->setCellValue('J1', 'Mergers & Acquisitions')
						->setCellValue('K1', 'Top Clients')
						->setCellValue('L1', 'Profile Type');
		if($clientId == INTERNAL_CLIENT_ID){
			$objWorksheet->setCellValue('M1', 'URL');
		}
		$i = 2;
		foreach($orgIds as $id){
			//Getting the Organizations Details
			foreach ($arrOrganizationDetail[$id] as $row){
				$objWorksheet->setCellValue('A'.$i, $row['cin_num'])
									->setCellValue('B'.$i, $row['name'])
									->setCellValue('C'.$i, $row['type'])
									->setCellValue('D'.$i, $row['company_logo'])
									->setCellValue('E'.$i, $row['website'])
									->setCellValue('F'.$i, $row['headquarters'])
									->setCellValue('G'.$i, $row['background'])
									->setCellValue('H'.$i, $row['mission_vision'])
									->setCellValue('I'.$i, $row['key_products'])
									->setCellValue('J'.$i, $row['mergers'])
									->setCellValue('K'.$i, $row['clients']);
						if($row['profile_type']==BASIC){
							$objWorksheet->setCellValue('L'.$i, "Basic");
						}				
						
						if($row['profile_type']==FULL){
							$objWorksheet->setCellValue('L'.$i, "Full Profile");
						}	
						if($clientId==INTERNAL_CLIENT_ID){
							$objWorksheet->setCellValue('M'.$i, $row['url']);
						}
				$i++;			
			}
		}
		// Address section 
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle('Address');
		//Add header
		$objWorksheet->setCellValue('A1', 'CIN NUM')
						->setCellValue('B1', 'Company Name')
						->setCellValue('C1', 'Address')
						->setCellValue('D1', 'City')
						->setCellValue('E1', 'Postal Code')
						->setCellValue('F1', 'State')
						->setCellValue('G1', 'Country')
						->setCellValue('H1', 'Phone')
						->setCellValue('I1', 'Fax')
						->setCellValue('J1', 'Additional Phone Numbers')
						->setCellValue('K1', 'Key Regional Offices');
		
		$i = 2;
		foreach($orgIds as $id){
			//Getting the Organizations Details
			foreach ($orgAdress[$id] as $row){
				$objWorksheet->setCellValue('A'.$i, $row['cin_num'])
									->setCellValue('B'.$i, $row['name'])
									->setCellValue('C'.$i, $row['address'])
									->setCellValue('D'.$i, $row['city'])
									->setCellValue('E'.$i, $row['postal_code'])
									->setCellValue('F'.$i, $row['region'])
									->setCellValue('G'.$i, $row['country'])
									->setCellValue('H'.$i, $row['phone'])
									->setCellValue('I'.$i, $row['fax']);
									$arrAdditionalContacts=$this->organization->getaddtionalContcat($id);
									//pr($arrAdditionalContacts);
									$phoneDetails='';
									$phoneDetails=implode("\n",$arrAdditionalContacts);
						$objWorksheet->setCellValue('J'.$i, $phoneDetails)
									->setCellValue('K'.$i, $row['key_reginal_offices']);
		
				$i++;			
			}
		}
		
		$objPHPExcel->addSheet($objWorksheet);
		
		// Facts section 
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle('Facts');
		//Add header
		$objWorksheet->setCellValue('A1', 'CIN NUM')
						->setCellValue('B1', 'Company Name')
						->setCellValue('C1', 'No. of Hospitals')
						->setCellValue('D1', 'Total No. Physicians')
						->setCellValue('E1', 'No. Physicians Employed')
						->setCellValue('F1', 'No. Of Physicians Affiliated')
						->setCellValue('G1', 'Pharmacy Benefit Management')
						->setCellValue('H1', 'Specialty Pharmacy')
						->setCellValue('I1', 'NCQA Status')
						->setCellValue('J1', 'Medicare Star Rating')
						->setCellValue('K1', 'Claims & EMR Data')
						->setCellValue('L1', 'Data Processing');
		if($clientId == INTERNAL_CLIENT_ID){
			$objWorksheet->setCellValue('M1', 'URL1');
			$objWorksheet->setCellValue('N1', 'URL2');
		}

		$i = 2;
		foreach($orgIds as $id){
			//Getting the Organizations Details
			foreach ($arrStatsFacts[$id] as $row){
				$objWorksheet->setCellValue('A'.$i, $arrOrganizationDetail1[$id][0])
									->setCellValue('B'.$i, $arrOrganizationDetail1[$id][1])
									->setCellValue('C'.$i, $row['no_of_hospitals'])
									->setCellValue('D'.$i, $row['no_of_physicians'])
									->setCellValue('E'.$i, $row['physicians_employed'])
									->setCellValue('F'.$i, $row['no_of_affiliated'])
									->setCellValue('G'.$i, $row['benefit_management'])
									->setCellValue('H'.$i, $row['specialty_pharmacy'])
									->setCellValue('I'.$i, $row['ncqa_status'])
									->setCellValue('J'.$i, $row['start_rating'])
									->setCellValue('K'.$i, $row['claims'])
									->setCellValue('L'.$i, $row['processing']);
		
				$i++;			
			}
		}
		
		$objPHPExcel->addSheet($objWorksheet);
		
		
		// Enrollments section 
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle('Enrollment');
		//Add header
		$objWorksheet->setCellValue('A1', 'CIN NUM')
						->setCellValue('B1', 'Company Name')
						->setCellValue('C1', 'Enrollment Type');
		$arrMaxYear = $this->organization->getMaxEnrollYear($orgIds);
		$alphabet = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
		$y = 3;
		for($i=2009;$i<=$arrMaxYear['maxyear'];$i++){
			$objWorksheet->setCellValue($alphabet[$y]."1", $i);
			$year[] = $i;
			$y++;
		}				
		$i = 2;
		foreach($orgIds as $id){
			$arrEnrollements =  $this->organization->getOrgPayerEnrollements($id);
			$years	= $this->organization->getAllOrgEnrollData($id,$year);
			//Getting the Organizations Details
			foreach ($arrEnrollements as $row){
				$objWorksheet->setCellValue('A'.$i, $arrOrganizationDetail1[$id][0])
									->setCellValue('B'.$i, $arrOrganizationDetail1[$id][1])
									->setCellValue('C'.$i, $row['type']);
				$y = 3;
				foreach($year as $k=>$yr){
					$objWorksheet->setCellValue($alphabet[$y].$i, $years[$row['id']][$yr]);
					$y++;
				}
		
				$i++;			
			}
		}
//		exit();
		$objPHPExcel->addSheet($objWorksheet);
		
		// Formulary section 
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle('Formulary');
		//Add header
		$objWorksheet->setCellValue('A1', 'CIN NUM')
						->setCellValue('B1', 'Company Name')
						->setCellValue('C1', 'Drug Name')
						->setCellValue('D1', 'Drub Tier')
						->setCellValue('E1', 'PA Criteria');

		$i = 2;
		foreach($orgIds as $id){
			//Getting the Organizations Details
			foreach ($arrFormularies[$id] as $row){
				$objWorksheet->setCellValue('A'.$i, $arrOrganizationDetail1[$id][0])
									->setCellValue('B'.$i, $arrOrganizationDetail1[$id][1])
									->setCellValue('C'.$i, $row['drug_name'])
									->setCellValue('D'.$i, $this->organization->getFormularyDrugValues($row['id'],DRUG_TIER))
									->setCellValue('E'.$i, $this->organization->getFormularyDrugValues($row['id'],PA_CRITERIA));
				$i++;						
			}
		}	
						
		$objPHPExcel->addSheet($objWorksheet);

		// Disease Management section 
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle('Disease Management');
		//Add header
		$objWorksheet->setCellValue('A1', 'CIN NUM')
						->setCellValue('B1', 'Company Name')
						->setCellValue('C1', 'Disease Name')
						->setCellValue('D1', 'Disease Management Platforms')
						->setCellValue('E1', 'Identification')
						->setCellValue('F1', 'Intervention')
						->setCellValue('G1', 'Measurement');
						
		$i = 2;
		foreach($orgIds as $id){
			//Getting the Organizations Details
			foreach ($arrManagements[$id] as $row){
				$objWorksheet->setCellValue('A'.$i, $arrOrganizationDetail1[$id][0])
									->setCellValue('B'.$i, $arrOrganizationDetail1[$id][1])
									->setCellValue('C'.$i, $row['disease_name'])
									->setCellValue('D'.$i, $this->organization->getPayerDiseaseDropDownValues($row['id'],DISEASE_MANAGEMENT_PLATFORMS))
									->setCellValue('E'.$i, $this->organization->getPayerDiseaseDropDownValues($row['id'],IDENTIFICATION))
									->setCellValue('F'.$i, $this->organization->getPayerDiseaseDropDownValues($row['id'],INTERVENTION))
									->setCellValue('G'.$i, $this->organization->getPayerDiseaseDropDownValues($row['id'],MEASUREMENT));
				$i++;			
			}
			
		}
		
		$objPHPExcel->addSheet($objWorksheet);
		
		// Collaboration Rating section 
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle('Collaboration Rating');
		// Add header
		$objWorksheet->setCellValue('A1', 'CIN NUM')
						->setCellValue('B1', 'Company Name')
						->setCellValue('C1', 'Category')
						->setCellValue('D1', 'Rating');
		$i = 2;
		$arrCaregories =  $this->organization->getOrgCollabarationCategories();
		foreach($orgIds as $id){
			//Getting the Organizations Details
			foreach ($arrCaregories as $key=>$row){
				$objWorksheet->setCellValue('A'.$i, $arrOrganizationDetail1[$id][0])
									->setCellValue('B'.$i, $arrOrganizationDetail1[$id][1])
									->setCellValue('C'.$i, $row);
							if(array_key_exists($key,$arrRatings[$id])){
								$objWorksheet->setCellValue('D'.$i, $arrRatings[$id][$key]);
							}	
				$i++;					
			}
		}				
		$objPHPExcel->addSheet($objWorksheet);
						
		// Key People section 
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle('Key People');
		//Add header
		$objWorksheet->setCellValue('A1', 'CIN NUM')
						->setCellValue('B1', 'Company Name')
						->setCellValue('C1', 'Role')
						->setCellValue('D1', 'Salutaion')
						->setCellValue('E1', 'First Name')
						->setCellValue('F1', 'Middle Name')
						->setCellValue('G1', 'Last Name')
						->setCellValue('H1', 'Department/Division/Center')
						->setCellValue('I1', 'Title')
						->setCellValue('J1', 'Email');
				if($clientId==INTERNAL_CLIENT_ID){
					$objWorksheet->setCellValue('K1', 'URL');
				}
		
		$i = 2;
		foreach($orgIds as $id){
			//Getting the Organizations Details
			foreach ($orgkeyPeoples[$id] as $row){
				$objWorksheet->setCellValue('A'.$i, $row['cin_num'])
									->setCellValue('B'.$i, $row['name'])
									->setCellValue('C'.$i, $row['role'])
									->setCellValue('D'.$i, $row['salutation'])
									->setCellValue('E'.$i, $row['first_name'])
									->setCellValue('F'.$i, $row['middle_name'])
									->setCellValue('G'.$i, $row['last_name'])
									->setCellValue('H'.$i, $row['department'])
									->setCellValue('I'.$i, $row['title'])
									->setCellValue('J'.$i, $row['email']);
		
						if($clientId==INTERNAL_CLIENT_ID){
							$objWorksheet->setCellValue('K'.$i, $row['url']);
						}
				$i++;			
			}
			
		}
		
		$objPHPExcel->addSheet($objWorksheet);
		
		// Social Media section 
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle('Social Media');
		//Add header
		$objWorksheet->setCellValue('A1', 'CIN NUM')
						->setCellValue('B1', 'Company Name')
						->setCellValue('C1', 'Blog')
						->setCellValue('D1', 'Youtube')
						->setCellValue('E1', 'Linkedin')
						->setCellValue('F1', 'Facebook')
						->setCellValue('G1', 'Twitter');
						
		$i = 2;
		foreach($orgIds as $id){
			//Getting the Organizations Details
			foreach ($orgSocialMediaDetails[$id] as $row){
				$objWorksheet->setCellValue('A'.$i, $row['cin_num'])
									->setCellValue('B'.$i, $row['name'])
									->setCellValue('C'.$i, $row['blog'])
									->setCellValue('D'.$i, $row['youtube'])
									->setCellValue('E'.$i, $row['linkedin'])
									->setCellValue('F'.$i, $row['facebook'])
									->setCellValue('G'.$i, $row['twitter']);
				$i++;			
			}
			
		}
						
		$objPHPExcel->addSheet($objWorksheet);
		
		$styleArray = array(
			'borders' => array(
				'bottom' => array(
					'style' => PHPExcel_Style_Border::BORDER_THICK,
					'color' => array('argb' => '0000000'),
				),
			),
		);
		
		$arrStyles =  array(
                  'font'    => array(
                      'bold'      => true,
                      'italic'    => false
                  ),
                  'borders' => array(
                      'bottom'     => array(
                          'style' => PHPExcel_Style_Border::BORDER_THICK,
                          'color' => array(
                              'rgb' => '000000'
                          )
                      ),
                      'quotePrefix'    => true
                  )
              );
              
		foreach(range('A','M') as $columnID) {
		    $objPHPExcel->getSheet(0)->getColumnDimension($columnID)->setWidth(30);
		}
        $objPHPExcel->getSheet(0)->getStyle('A1:M1')->applyFromArray($arrStyles);
         
		foreach(range('A','K') as $columnID) {
		    $objPHPExcel->getSheet(1)->getColumnDimension($columnID)->setWidth(30);
		}
        $objPHPExcel->getSheet(1)->getStyle('A1:K1')->applyFromArray($arrStyles);
         
		foreach(range('A','N') as $columnID) {
		    $objPHPExcel->getSheet(2)->getColumnDimension($columnID)->setWidth(30);
		}
        $objPHPExcel->getSheet(2)->getStyle('A1:N1')->applyFromArray($arrStyles);
        
		foreach(range('A','I') as $columnID) {
		    $objPHPExcel->getSheet(3)->getColumnDimension($columnID)->setWidth(30);
		}
       	$objPHPExcel->getSheet(3)->getStyle('A1:I1')->applyFromArray($arrStyles);
       	
		foreach(range('A','E') as $columnID) {
		    $objPHPExcel->getSheet(4)->getColumnDimension($columnID)->setWidth(30);
		}
       	$objPHPExcel->getSheet(4)->getStyle('A1:E1')->applyFromArray($arrStyles);
       	
		foreach(range('A','G') as $columnID) {
		    $objPHPExcel->getSheet(5)->getColumnDimension($columnID)->setWidth(30);
		}
       	$objPHPExcel->getSheet(5)->getStyle('A1:G1')->applyFromArray($arrStyles);
       	
		foreach(range('A','D') as $columnID) {
		    $objPHPExcel->getSheet(6)->getColumnDimension($columnID)->setWidth(30);
		}
       	$objPHPExcel->getSheet(6)->getStyle('A1:D1')->applyFromArray($arrStyles);
       	
		foreach(range('A','K') as $columnID) {
		    $objPHPExcel->getSheet(7)->getColumnDimension($columnID)->setWidth(30);
		}
       	$objPHPExcel->getSheet(7)->getStyle('A1:K1')->applyFromArray($arrStyles);
       	
		foreach(range('A','G') as $columnID) {
		    $objPHPExcel->getSheet(8)->getColumnDimension($columnID)->setWidth(30);
		}
       	$objPHPExcel->getSheet(8)->getStyle('A1:G1')->applyFromArray($arrStyles);
       	
		$objPHPExcel->setActiveSheetIndex(0);
		
		
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

		// Redirect output to a client’s web browser (Excel2007)
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment;filename="Organization_payer_profiles.xlsx"');
		header('Cache-Control: max-age=0');
		// If you're serving to IE 9, then the following may be needed
		header('Cache-Control: max-age=1');

		// If you're serving to IE over SSL, then the following may be needed
		header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
		header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
		header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
		header ('Pragma: public'); // HTTP/1.0

		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save('php://output');
		exit;
		
	}
        
        /**
	 * Adding a new organization based on type
         * type :'department','institution','managed_care_org','practise','pharmacy'
	 * @author 	Shruti Purushan
	 * @Created on: 16-10-2015
	 * @return
	 */
	
	function add_org($id=''){
             $this->load->model('Specialty');
             if (!is_numeric($id)){
                    $contentPage=$id;
                    
                  
                    if($contentPage=="pharmacy"){
                        $specialtyName            = $this->Specialty->getAllSpecialties("pharamacy");
                    }
                    elseif($contentPage=="department"){
                        $specialtyName            = $this->Specialty->getAllSpecialties("department");
                    }
                    elseif($contentPage=="managed_care_org"){
                        $specialtyName            = $this->Specialty->getAllSpecialties("mco");
                    }
                    else{
                         $specialtyName            = $this->Specialty->getAllSpecialties();
                    }
             }
                $mcoType            = $this->organization->getMcoTypeNames();
                $addressType            = $this->organization->getAddressTypeNames();
                $data['arrCountries']=$this->Country_helper->listCountries();
                $first_key = key($data['arrCountries']);
                $data['arrFirstCountry'] = $data['arrCountries'][$first_key]['country_id'];
                if(!is_numeric($id)){
//                 	$data['arrStates'] = $this->Country_helper->getStatesByCountryId($data['arrFirstCountry']);
                	$data['arrStates'] = array();
                	$data['checkKolAssignedToUser']=true;
                }
                $data['arrInstitutions']=$this->Country_helper->listCountries();
                $validationStatus            = $this->organization->getValidationStatusNames();
                $arrMcoTypeTemp = array();
        		foreach ($mcoType as $key => $value) {
        			$arrMcoTypeTemp[$value['id']] = ($value['name']);
        		}
                        $arrAddressTypeTemp = array();
        		foreach ($addressType as $key => $value) {
        			$arrAddressTypeTemp[$value['id']] = ($value['name']);
        		}
                        $arrValidationStatusTemp = array();
        		foreach ($validationStatus as $key => $value) {
        			$arrValidationStatusTemp[$value['id']] = ($value['name']);
        		}
                $data['validationStatus']=$arrValidationStatusTemp;
		
                $data['mcoType']=$arrMcoTypeTemp;
                $data['addressType']=$arrAddressTypeTemp;
                if((!empty($id)) && (is_numeric($id))){
                    $data['locationData'] = $this->organization->getLocationByOrganizationId($id);
                    $data['locationData'] = $data['locationData'][0];
                    $arr = $this->kol->getKolPrimaryPhoneDetails($id);
                    if (isset($arr['id'])) {
                    	$data['locationData']['phone_number_primary'] = $arr['number'];
                    	$data['locationData']['phone_type_primary'] = $arr['type'];
                    } else {
                    	$data['locationData']['phone_number_primary'] = '';
                    	$data['locationData']['phone_type_primary'] = '';
                    }	
                    $data['arrCountries'] = $this->Country_helper->listCountries();
            		$data['arrStates'] = $this->Country_helper->getStatesByCountryId($data['locationData']['country_id']);
                    
                     $stateID=$data['locationData']['state_id'];
                    $data['arrCities']=$this->Country_helper->getCitiesByStateId($stateID);
//                    $data['arrStates'] = $this->Country_helper->listStates();
                    $data['orgDetails']= $this->organization->editOrg($id);
                    $orgType =$data['orgDetails'][0]['org_type'];
                    if($orgType=="pharmacy"){
                        $specialtyName            = $this->Specialty->getAllSpecialties("pharamacy");
                    }
                    elseif($orgType=="department"){
                        $specialtyName            = $this->Specialty->getAllSpecialties("department");
                    }
                    elseif($orgType=="managed_care_org"){
                        $specialtyName            = $this->Specialty->getAllSpecialties("mco");
                    }
                    
                    else{
                         $specialtyName            = $this->Specialty->getAllSpecialties();
                    }
                    $data['contactRestrictions']= $this->organization->getContactRestrictions($id);
                    $data['checkKolAssignedToUser']=$this->organization->checkOrgAissenedToUser($id);
		         }
                   
                $data['specialtyName']=$specialtyName;
                $data['arrPhoneType'] = $this->kol->getPhoneType();
                $data['contentPage'] 	=	'organizations/add_org';
				$this->load->view('layouts/client_view', $data);
	
	}
        
         /**
	 * Saving a new organization based on type
	 * @author 	Shruti Purushan
	 * @Created on: 16-10-2015
	 * @return
	 */
        function save_org(){
                $previousUrl=$this->input->post('previousUrl');
                $org_id = $this->input->post('id');
		if($org_id==null || $org_id=='') {
                        $arrData = array();
                        $data=array();
                        $orgData=array();
			$arrData['name'] = $this->input->post('name');
			$arrData['foundation'] = $this->input->post('foundation');
			$arrData['phone'] = $this->input->post('phone');
			$arrData['specialty'] = $this->input->post('specialty');
			$arrData['admission_per_year'] = $this->input->post('admission_per_year');
			$arrData['website'] = $this->input->post('website');
			$arrData['patients_per_week'] = $this->input->post('patients_per_week');
			$arrData['institution_type']	= $this->input->post('institution_type');
			$arrData['number_of_beds']	= $this->input->post('number_of_beds');
			$arrData['fax']	= $this->input->post('fax');
			$arrData['num_of_physician'] = $this->input->post('num_of_physician');
			$arrData['licensing_opertunities'] = $this->input->post('licensing_opertunities');
			$arrData['email'] = $this->input->post('email');
			$arrData['rx_vol'] = $this->input->post('rx_vol');
			$arrData['num_of_residents'] = $this->input->post('num_of_residents');
			$arrData['ists'] = $this->input->post('ists');
			$arrData['size']	= $this->input->post('size');
			$arrData['background']	= $this->input->post('background');
			$arrData['research']	= $this->input->post('research');
			$arrData['csts']	= $this->input->post('csts');
			$arrData['irb_present']	= $this->input->post('irb_present');
                        $arrData['ceo_name']	= $this->input->post('ceo_name');
                        $arrData['org_type']	= $this->input->post('org_type');
                         if($arrData['org_type'] == "managed_care_org")
                        	$arrData['org_type'] = "Managed Care Organization";
                        $arrOrgTypes = $this->organization->getMatchingOrgTypes($arrData['org_type']);                    
                        reset($arrOrgTypes);
						$arrData['type_id'] = key($arrOrgTypes);
						if($arrData['type_id']==''){
						   $typeId = $this->organization->getOrgTypeByName($arrData['org_type']);
						  $arrData['type_id'] = $typeId['id'];
						}
						$typeId = $this->organization->getOrgTypeByName($arrData['institution_type']);
						$arrData['type_id'] = $typeId['id'];
						$arrData['status_otsuka'] = "ACTV";
                        $arrData['mco_type']	= $this->input->post('mco_type');
                        if($this->input->post('address2')!="")
                        $arrData['address'] 	= trim($this->input->post('address1').', '.$this->input->post('address2'));
                        else
                        $arrData['address'] 	= trim($this->input->post('address1'));
                        $arrData['country_id'] 	= $this->input->post('country_id');
                        $arrData['state_id'] 	= $this->input->post('state_id');
                        $arrData['city_id'] 		= $this->input->post('city_id');
                        
                        if($arrData['state_id'] == '')
			            	unset($arrData['state_id']);
			             if($arrData['state_id'] == '')
			            	unset($arrData['state_id']);
                        
                        $arrData['postal_code'] 	= $this->input->post('postal_code');
                        $arrData['status']	= "Completed";
                        $arrData['profile_type']	= 1;
                        //pr($arrData);exit;
                        $data['visit'] = $this->input->post('visit');
                        $data['call'] = $this->input->post('call');
                        $data['fax'] = $this->input->post('contact_fax');
                        $data['mail'] = $this->input->post('mail');
                        $data['email'] = $this->input->post('emailCheck');
                        $data['contact_type'] = "organization";
                        $lastId	=$this->organization->saveOrg($arrData,$data);
                        
                          //Add Log activity
                        $formData = $_POST;
                        $formData = json_encode($formData);
                        $arrLogDetails = array(
                        'module' => 'Organization',
                        'type' => LOG_ADD,
                        'description' => 'New Organization',
                        'status' => 'success',
                        'transaction_id' => $lastId,
                        'transaction_table_id' => ORGANIZATIONS,
                        'transaction_name' => "New Organization",
                        'form_data' => $formData,
                        'parent_object_id' => $lastId
                        );
                        $this->config->set_item('log_details', $arrLogDetails);
                        log_user_activity(null,true);
                        //exit;
                        $orgData['org_id'] 			= $lastId;
                        $orgData['main'] 		= $this->input->post('organization');
                        $orgData['address1'] 			= trim($this->input->post('address1'));
                        $orgData['address2'] 			= trim($this->input->post('address2'));
                        $orgData['address3'] 			= trim($this->input->post('address3'));
                        $orgData['validation_status'] 		= trim($this->input->post('validation_status'));
                        $orgData['address_type'] 		= trim($this->input->post('address_type'));
                        $orgData['country_id'] 	= $this->input->post('country_id');
                        $orgData['state_id'] 	= $this->input->post('state_id');
                        $orgData['city_id'] 		= $this->input->post('city_id');
                        
                        if($orgData['state_id'] == '')
			            	unset($orgData['state_id']);
			             if($orgData['state_id'] == '')
			            	unset($orgData['state_id']);
                        
                        $orgData['postal_code'] 	= $this->input->post('postal_code');
                          $orgData['phone_number_primary'] 	= $this->input->post('phone_number_primary');
                $orgData['phone_type_primary'] 	= $this->input->post('phone_type_primary');
                        
                        if($this->input->post('is_primary') == "1")
                            $orgData['is_primary'] 			= $this->input->post('is_primary');
                        $orgData['created_by'] 		= $this->loggedUserId;
                        $orgData['created_on'] 		= date('Y-m-d H:i:s');
                        $orgData['modified_by'] 		= $this->loggedUserId;
                        $orgData['modified_on'] 		= date('Y-m-d H:i:s');
                        $orgLocLasId = $this->organization->saveLocation($orgData);
                        
                        if(isset($orgData['phone_type_primary']) && $orgData['phone_type_primary'] > 0){
                       		$orgPhone = array();
                       		$orgPhone['type'] = $this->input->post('phone_type_primary');
					        $orgPhone['number'] = $this->input->post('phone_number_primary');
					        $orgPhone['contact_type'] = 'organization';
					        $orgPhone['contact'] = $lastId;
					        $orgPhone['is_primary'] = $this->input->post('is_primary');
					        $orgPhone['location_id'] = $orgLocLasId;
					        $orgPhone['created_by'] = $this->loggedUserId;
					        $orgPhone['created_on'] = date('Y-m-d H:i:s');
					        $lastPhoneId = $this->kol->savePhone($orgPhone);
                        }
                        //Assign User
                        $arrAssignData = array();
                        $arrAssignData['user_id'] = $this->loggedUserId;
                        $arrAssignData['org_id'] = $lastId;
                        $saveAssignId = $this->organization->saveOrgAssignClient($arrAssignData);
//                        redirect($previousUrl);
                         redirect('/organizations/view/'.$lastId); 
                } else {
                        $arrData = array();
                        $data=array();
                        $orgData=array();
                        $arrData['id'] = $this->input->post('id');
			$arrData['name'] = $this->input->post('name');
			$arrData['foundation'] = $this->input->post('foundation');
			$arrData['phone'] = $this->input->post('phone');
			$arrData['specialty'] = $this->input->post('specialty');
			$arrData['admission_per_year'] = $this->input->post('admission_per_year');
			$arrData['website'] = $this->input->post('website');
			$arrData['patients_per_week'] = $this->input->post('patients_per_week');
			$arrData['institution_type']	= $this->input->post('institution_type');
			$arrData['number_of_beds']	= $this->input->post('number_of_beds');
			$arrData['fax']	= $this->input->post('fax');
			$arrData['num_of_physician'] = $this->input->post('num_of_physician');
			$arrData['licensing_opertunities'] = $this->input->post('licensing_opertunities');
			$arrData['email'] = $this->input->post('email');
			$arrData['rx_vol'] = $this->input->post('rx_vol');
			$arrData['num_of_residents'] = $this->input->post('num_of_residents');
			$arrData['ists'] = $this->input->post('ists');
			$arrData['size']	= $this->input->post('size');
			$arrData['research']	= $this->input->post('research');
			$arrData['background']	= $this->input->post('background');
			$arrData['csts']	= $this->input->post('csts');
			$typeId = $this->organization->getOrgTypeByName($arrData['institution_type']);
			$arrData['type_id'] = $typeId['id'];
			$arrData['irb_present']	= $this->input->post('irb_present');
                        $arrData['ceo_name']	= $this->input->post('ceo_name');
                        $arrData['mco_type']	= $this->input->post('mco_type');
                        $arrData['status']	= "Completed";
                        if($this->input->post('address2')!="")
                        $arrData['address'] 	= trim($this->input->post('address1').', '.$this->input->post('address2'));
                        else
                        $arrData['address'] 	= trim($this->input->post('address1'));
                        $arrData['country_id'] 	= $this->input->post('country_id');
                        $arrData['state_id'] 	= $this->input->post('state_id');
                        $arrData['city_id'] 		= $this->input->post('city_id');
                        
                        if($arrData['state_id'] == '')
			            	unset($arrData['state_id']);
			             if($arrData['state_id'] == '')
			            	unset($arrData['state_id']);
                        
                        $arrData['postal_code'] 	= $this->input->post('postal_code');
                        $data['visit'] = $this->input->post('visit');
                        $data['call'] = $this->input->post('call');
                        $data['fax'] = $this->input->post('contact_fax');
                        $data['mail'] = $this->input->post('mail');
                        $data['email'] = $this->input->post('emailCheck');
                        $data['contact_type'] = "organization";
                        $data['contact'] = $this->input->post('id');
						$this->organization->updateOrg($arrData,$data);
                        $orgID=$arrData['id'];
                          //Add Log activity
                        $formData = $_POST;
                        $formData = json_encode($formData);
                        $arrLogDetails = array(
                        'module' => 'Organization',
                        'type' => LOG_UPDATE,
                        'description' => 'Update Organization',
                        'status' => 'success',
                        'transaction_id' => $orgID,
                        'transaction_table_id' => ORGANIZATIONS,
                        'transaction_name' => "Update Organization",
                        'form_data' => $formData,
                        'parent_object_id' => $orgID
                        );
                        $this->config->set_item('log_details', $arrLogDetails);
                        log_user_activity(null,true);
                        //exit;
                        $orgData['org_id'] 			= $this->input->post('id');
                        
                        $orgData['main'] 		= $this->input->post('organization');
                        $orgData['address1'] 			= trim($this->input->post('address1'));
                        $orgData['address2'] 			= trim($this->input->post('address2'));
                        $orgData['address3'] 			= trim($this->input->post('address3'));
                        $orgData['validation_status'] 		= trim($this->input->post('validation_status'));
                        $orgData['address_type'] 		= trim($this->input->post('address_type'));
                        $orgData['country_id'] 	= $this->input->post('country_id');
                        $orgData['state_id'] 	= $this->input->post('state_id');
                        $orgData['city_id'] 		= $this->input->post('city_id');
                        if($orgData['state_id'] == '')
			            	unset($orgData['state_id']);
			             if($orgData['state_id'] == '')
			            	unset($orgData['state_id']);
                        $orgData['postal_code'] 	= $this->input->post('postal_code');
                        $orgData['phone_number_primary'] 	= $this->input->post('phone_number_primary');
                		$orgData['phone_type_primary'] 	= $this->input->post('phone_type_primary');
                        if($this->input->post('is_primary') == "1")
                            $orgData['is_primary'] 			= $this->input->post('is_primary');
                        $orgData['created_by'] 		= $this->loggedUserId;
                        $orgData['created_on'] 		= date('Y-m-d H:i:s');
                        $orgData['modified_by'] 		= $this->loggedUserId;
                        $orgData['modified_on'] 		= date('Y-m-d H:i:s');
                         $orgId=$arrData['id'];
                       if($orgData['id'] > 0){
                       		$orgData['id'] 			= $this->input->post('org_location_id');
                       		$this->organization->updateOrgLocation($orgData);
                       		$arrPhoneDataExist['contact'] = $this->input->post('id');
                       		$arrPhoneDataExist['location_id'] = $this->input->post('org_location_id');
                       }else{
                       		$orgLocLasId = $this->organization->saveLocation($orgData);
                       		$arrPhoneDataExist['contact'] = $this->input->post('id');
                       		$arrPhoneDataExist['location_id'] = $orgLocLasId;
                       }
                       
                       $isExist = $this->kol->getKoPhoneByLocationId($arrPhoneDataExist);
                       
                       if($isExist > 0){
                       	if ($this->input->post('phone_number_primary') != '' || $this->input->post('phone_type_primary') != '') {
                       		$arrPhoneData = array();
                       		$arrPhoneData['type'] = trim($this->input->post('phone_type_primary'));
                       		$arrPhoneData['number'] = trim($this->input->post('phone_number_primary'));
                       		$arrPhoneData['is_primary'] = 1;
                       		$arrPhoneData['contact'] = $this->input->post('id');
                       		$arrPhoneData['contact_type'] = "organization";
                       		$arrPhoneData['location_id'] = $this->input->post('org_location_id');
                       		$arrPhoneData['modified_by'] = $this->loggedUserId;
                       		$arrPhoneData['modified_on'] = date('Y-m-d H:i:s');
                       		$this->kol->updateOlPhone($arrPhoneData);
                       		//             		echo $this->db->last_query();
                       	}
                       }else{
	                       	if ($this->input->post('phone_number_primary') != '') {
	                       		$arrPhoneData = array();
	                       		$arrPhoneData['type'] = trim($this->input->post('phone_type_primary'));
	                       		$arrPhoneData['number'] = trim($this->input->post('phone_number_primary'));
	                       		$arrPhoneData['is_primary'] = 1;
	                       		$arrPhoneData['contact'] = $this->input->post('id');
	                       		$arrPhoneData['location_id'] = $this->input->post('org_location_id');
	                       		$arrPhoneData['contact_type'] = "organization";
	                       		$arrPhoneData['created_by'] = $this->loggedUserId;
	                       		$arrPhoneData['created_on'] = date('Y-m-d H:i:s');
	                       		$this->kol->savePhone($arrPhoneData);
	                       	}
                       }
                 //    redirect($previousUrl);
                        redirect('/organizations/view/'.$orgId);   
                }
        }
        
       /*
        * To get List of Institution Names By passing  Name for autocomltete 
        * @author Shruti Purushan
        * @created on 16-10-2015
        */
	function get_institution_names_for_autocomplete($Name){
		$Name		= utf8_urldecode($this->input->post($Name));
		$arrKolNames1	= array();
		$arrKolNames	= $this->organization->getAllInstitutionNamesForAutocomplete($Name);
          	$flag	= 1;
		foreach($arrKolNames['kols'] as $key=>$row){
			if($flag){
				$arrKolNames1[]='<div class="autocompleteHeading"></div><div class="dataSet"><label name="'.$row[0].'" class="kolName" style="display:block">'.$row[0]."</label><label class='orgName'>".$row[1]."</label><span style='display:none' class='id1'>".$key."</span></div>";
				$flag	= 0;
			}else{
				$arrKolNames1[]='<div class="dataSet"><label name="'.$row[0].'" class="kolName" style="display:block">'.$row[0]."</label><label class='orgName'>".$row[1]."</label><span style='display:none' class='id1'>".$key."</span></div>";
			}
		}
		if((sizeof($arrKolNames['kols'])<1) && (sizeof($arrKolNames['customers'])<1)){
			$arrKolNames1[]	= "<div style='padding-left:5px;'>No results found for ".$Name."</div><div><label name='No results found for ".$Name."' class='kolName' style='display:block'></label><label class='orgName'></label><span style='display:none' class='id1'></span></div>";
		}
		$arr['query']		= $Name;
		$arr['suggestions']	= $arrKolNames1;
		echo json_encode($arr);

	}
        
        function add_location($orgId=null) {
           $data['arrCountries'] = $this->Country_helper->listCountries();
    		$first_key = key($data['arrCountries']);
    		$data['arrFirstCountry'] = $data['arrCountries'][$first_key]['country_id'];
//     		$data['arrStates'] = $this->Country_helper->getStatesByCountryId($data['arrFirstCountry']);
    		$data['arrStates'] = array();
            $addressType            = $this->organization->getAddressTypeNames();
            $validationStatus            = $this->organization->getValidationStatusNames();
            $data['arrInstitutions']=$this->Country_helper->listCountries();
            $arrAddressTypeTemp = array();
		foreach ($addressType as $key => $value) {
			$arrAddressTypeTemp[$value['id']] = ($value['name']);
            }
            $data['orgId']=$orgId;
            $arrValidationStatusTemp = array();
		foreach ($validationStatus as $key => $value) {
			$arrValidationStatusTemp[$value['id']] = ($value['name']);
		}
                $data['validationStatus']=$arrValidationStatusTemp;
            $data['addressType']=$arrAddressTypeTemp;
//            pr($data);
            $this->load->view('organizations/add_location', $data);
        }
        
        function save_location() {
            $id = $this->input->post('id');
            if(!empty($id)) {
                $arrData['id'] 			= $this->input->post('id');
                $arrData['org_id'] 			= $this->input->post('org_id');
                $arrData['main'] 		= $this->input->post('organization');
                $arrData['address1'] 			= trim($this->input->post('address1'));
                $arrData['address2'] 			= trim($this->input->post('address2'));
                $arrData['address3'] 			= trim($this->input->post('address3'));
                $arrData['validation_status'] 		= trim($this->input->post('validation_status'));
                $arrData['address_type'] 		= trim($this->input->post('address_type'));
                $arrData['country_id'] 	= $this->input->post('country_id');
                $arrData['state_id'] 	= $this->input->post('state_id');
                $arrData['city_id'] 		= $this->input->post('city_id');
                $arrData['postal_code'] 	= $this->input->post('postal_code');
                $arrData['phone_number_primary'] 	= $this->input->post('phone_number_primary');
                $arrData['phone_type_primary'] 	= $this->input->post('phone_type_primary');
                if($this->input->post('is_primary') == "1")
                    $arrData['is_primary'] 			= $this->input->post('is_primary');
                $arrData['modified_by'] 		= $this->loggedUserId;
                $arrData['modified_on'] 		= date('Y-m-d H:i:s');
                $lastId = $this->organization->saveLocation($arrData);
                if($lastId){
                     $formData = $_POST;
		$formData = json_encode($formData);
		$arrLogDetails = array(
				'module' => 'Organization',
                'type' => LOG_ADD,
                'description' => 'Update Location Org',
                'status' => 'success',
                'transaction_id' => $arrData['id'],
            	'transaction_table_id' => ORG_LOCATIONS,
                'transaction_name' => "Update Location Org",
            	'form_data' => $formData,
                'parent_object_id' =>  $arrData['org_id'] 	
            );

       	

		$this->config->set_item('log_details', $arrLogDetails);
                log_user_activity(null,true);
                        $data['status'] = true;
                }else{
                        $data['status'] = false;
                }
                
                $lastId = $arrData['id'];
                $this->kol->deleteLocStaff($lastId);
                $this->kol->deleteLocPhone($lastId);
                
            } else {
                $arrData['org_id'] 			= $this->input->post('org_id');
                $arrData['main'] 		= $this->input->post('organization');
                $arrData['address1'] 			= trim($this->input->post('address1'));
                $arrData['address2'] 			= trim($this->input->post('address2'));
                $arrData['address3'] 			= trim($this->input->post('address3'));
                $arrData['validation_status'] 		= trim($this->input->post('validation_status'));
                $arrData['address_type'] 		= trim($this->input->post('address_type'));
                $arrData['country_id'] 	= $this->input->post('country_id');
                $arrData['state_id'] 	= $this->input->post('state_id');
                $arrData['city_id'] 		= $this->input->post('city_id');
                $arrData['postal_code'] 	= $this->input->post('postal_code');
                $arrData['phone_number_primary'] 	= $this->input->post('phone_number_primary');
                $arrData['phone_type_primary'] 	= $this->input->post('phone_type_primary');
                    $genericId = $this->common_helpers->getGenericId("Organization Locations");
            $arrData['generic_id'] = $genericId;
           
                if($this->input->post('is_primary') == "1")
                    $arrData['is_primary'] 			= $this->input->post('is_primary');
                $arrData['created_by'] 		= $this->loggedUserId;
                $arrData['created_on'] 		= date('Y-m-d H:i:s');
                $arrData['modified_by'] 		= $this->loggedUserId;
                $arrData['modified_on'] 		= date('Y-m-d H:i:s');
                $lastId = $this->organization->saveLocation($arrData);
                if($lastId){
                        $formData = $_POST;
		$formData = json_encode($formData);
		$arrLogDetails = array(
				'module' => 'Organization',
                'type' => LOG_ADD,
                'description' => 'Save Location Org',
                'status' => 'success',
                'transaction_id' => $lastId,
            	'transaction_table_id' => ORG_LOCATIONS,
                'transaction_name' => "Save Location Org",
            	'form_data' => $formData,
                'parent_object_id' =>   $arrData['org_id']
            );

       	

		$this->config->set_item('log_details', $arrLogDetails);
                log_user_activity(null,true);
                        $data['status'] = true;
                        $data['id'] = $lastId;
                }else{
                        $data['status'] = false;
                }
                
            }
            if($this->input->post('is_primary') == "1"){
                    $arrOrgDetails = array();
                    $arrOrgDetails['id'] = $arrData['org_id'];
                    $arrOrgDetails['address']=$arrData['address1'].", ".$arrData['address2'];
                    $arrOrgDetails['country_id'] = $arrData['country_id'];
                    $arrOrgDetails['state_id'] = $arrData['state_id'];
                    $arrOrgDetails['city_id'] = $arrData['city_id'];
                    $arrOrgDetails['postal_code'] = $arrData['postal_code'];
                    $arrOrgDetails['modified_by'] 		= $this->loggedUserId;
                    $arrOrgDetails['modified_on'] 		= date('Y-m-d H:i:s');
                    $this->organization->updateOrgAsPrimary($arrOrgDetails);
                
            }
            $arrStaffTitles = $this->input->post('staff_title');
            $arrStaffNames = $this->input->post('staff_name');
            $arrStaffPhones = $this->input->post('staff_phone');
            $i = 0;
            foreach($arrStaffTitles as $staff_title){
                if($staff_title != "") {
                $arrStaffData = array('title' => $staff_title,
                'name' => $arrStaffNames[$i],
                'phone_number' => $arrStaffPhones[$i],
    //                    if($arrData['kol_id'] != "") {
                'contact_type' => "org_location",
                'contact' => $this->input->post('org_id'),
                'location_id' => $lastId,
    //                    }
                'created_by' => $this->loggedUserId,
                'created_on' => date('Y-m-d H:i:s'),
                'modified_by' => $this->loggedUserId,
                'modified_on' => date('Y-m-d H:i:s'));
                $lastStaffId = $this->kol->saveStaff($arrStaffData);
                }
                $i++;
            }


            $arrPhoneTypes = $this->input->post('phone_type');
            $arrPhoneNumbers = $this->input->post('phone_number');
            $i = 0;
            foreach($arrPhoneTypes as $phone_type){
                if($phone_type != "") {
                $arrPhoneData = array('type' => $phone_type,
                'number' => $arrPhoneNumbers[$i],
    //                    if($arrData['kol_id'] != "") {
                'contact_type' => "org_location",
                'contact' => $this->input->post('org_id'),
                'location_id' => $lastId,
    //                    }
                'created_by' => $this->loggedUserId,
                'created_on' => date('Y-m-d H:i:s'),
                'modified_by' => $this->loggedUserId,
                'modified_on' => date('Y-m-d H:i:s'));
                $lastPhoneId = $this->kol->savePhone($arrPhoneData);
                }
                $i++;
            }
            
            echo json_encode($data);
        }
        
        function list_locations($orgId=null)
	{
		$locations		=	array();
                $locations = $this->organization->listLocationDetails($orgId);
                foreach($locations as $row){
					$row['dAllowed']= $this->common_helpers->isActionAllowed('location','delete',$row);
					$row['eAllowed']= $this->common_helpers->isActionAllowed('location','edit',$row);
					if($row['is_primary'])
						$row['is_primary'] = "<span class='is_primary'>&nbsp;</span>";
					else
						$row['is_primary'] = "";
					$arrLocations[]	=	$row;
					}
                $data['orgId'] = $orgId;
		$data['rows'] = $arrLocations;
		echo json_encode($data);
	}
         function edit_location($id=null) {
            $data['locationData'] = $this->organization->getLocationById($id);
            $data['locationData'] = $data['locationData'][0];
            $data['staffData'] = $this->kol->getStaffs($id, 'location');
            $data['phoneData'] = $this->kol->getPhones($id, 'location');
            $data['arrCountries']=$this->Country_helper->listCountries();
            $validationStatus            = $this->organization->getValidationStatusNames();
            $data['arrStates'] = $this->Country_helper->getStatesByCountryId($data['locationData']['country_id']);
            if($data['locationData']['state_id'] != '' && $data['locationData']['state_id'] != 0 )
            	$data['arrCities']=$this->Country_helper->getCitiesByStateId($data['locationData']['state_id']);
             $addressType            = $this->organization->getAddressTypeNames();
            $arrAddressTypeTemp = array();
		foreach ($addressType as $key => $value) {
			$arrAddressTypeTemp[$value['id']] = ($value['name']);
            }
            $arrValidationStatusTemp = array();
		foreach ($validationStatus as $key => $value) {
			$arrValidationStatusTemp[$value['id']] = ($value['name']);
		}
                $data['validationStatus']=$arrValidationStatusTemp;
            $data['addressType']=$arrAddressTypeTemp;
            $this->load->view('organizations/add_location', $data);
        }
/**
         * Delete location of kol
         */
        function delete_location($id = null,$orgId) {
        	$msg = '';
        	$rowPhoneData = $this->db->get_where('phone_numbers', array('contact' => $orgId,'location_id' => $id))->result();
        	$rowStaffData = $this->db->get_where('staffs', array('contact' => $orgId,'location_id' => $id))->result();
        	if(sizeof($rowPhoneData) > 0 && sizeof($rowStaffData) > 0){
        		$msg = 'Kindly delete associated records from Phone/Staff Section';
        	}else if(sizeof($rowPhoneData) > 0){
        		$msg = 'Kindly delete associated record from Phone Section';
        	}else if(sizeof($rowStaffData) > 0){
        		$msg = 'Kindly delete associated record from Staff Section';
        	}else{
        		$this->kol->deleteStaff("", $id, $orgId);
        		$this->kol->deletePhone("", $id, $orgId);
        		$this->organization->deleteLocation($id);
        	}
        	echo json_encode($msg);
        }
        function view_location($id=null) {
            $data['locationData'] = $this->organization->getLocationById($id);
            $result= $this->common_helpers->getUserName( $data['locationData'][0]['created_by']);
            $country_id=$data['locationData'][0]['country_id'];
            $state_id=$data['locationData'][0]['state_id'];
            $city_id=$data['locationData'][0]['city_id'];
            $data['locationData'] = $data['locationData'][0];
            $data['staffData'] = $this->kol->getStaffs($id, 'location');
            $data['phoneData'] = $this->kol->getPhones($id, 'location');
            $data['created_by'] = $result;
            $data['country_id']=$this->Country_helper->getCountryById($country_id);
            $data['state_id'] = $this->Country_helper->getStateById($state_id);
            $data['city_id']=$this->Country_helper->getCityeById($city_id);
            $this->load->view('organizations/view_location', $data);
        }
        
	function view_org_interactions2($orgId){
		$clientId = $this->session->userdata('client_id');
		$data['arrGroupings']	= $this->interaction->getAllGroupings($clientId);
		$data['arrModes']		= $this->interaction->getAllModesOfClient($clientId);
		$data['arrTopics']		= $this->interaction->getAllTopicsOfClient($clientId);
		$data['arrType']		= $this->interaction->getAllTypesOfClient();
		$data['arrProduct']		= $this->common_helpers->getUserProducts();
		$data['arrUsers']		= $this->Client_User->getClientUsers($clientId);
		$arrOrganizationDetail = array();
		$arrOrganizationDetail = $this->organization->editOrganization($organizationId);
		// If there is no record in the database
		if(!$arrOrganizationDetail){
			return false;
		}
		// Set the KOL ID into the Session
		$this->session->set_userdata('organizationId', $organizationId);
		$data['arrOrganization']		= $arrOrganizationDetail;
		$arrSalutations				= array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']		= $arrSalutations;
		//Get Kol profile Score
		$arrFilters = '';
		$userId=0;
		if($this->session->userdata('user_role_id')==ROLE_USER)
			$userId=$this->session->userdata('user_id');
		$arrInteractionsResults=$this->interaction->getKolInteractions($clientId,$orgId,$userId,$arrFilters,$limit=10,'');
		$count=$this->interaction->getKolInteractions($clientId,$orgId,$userId,$arrFilters,$limit='all','');
		$data['arrInteractionsResults']=	$arrInteractionsResults;
		//$data['arrOrganization']	= $arrOrganizationDetail;
		$data['contentPage'] 	= 'interactions/list_kol_interactions';
		$data['orgId'] 	= $orgId;

		$data['count'] = $count;
		if($count==0){
			$data['mes'] = "No interactions found";
		}

		$interactionIds = array();
		foreach($arrInteractionsResults as $row){
			$interactionIds[] = $row['id'];
		}
		//pr($interactionIds);
		$data['interactionIds'] = implode($interactionIds,',');
		$data['assignedUsers'] = $this->align_user->getAssignedOrgUsers($organizationId);
		//pr($data);
		//$data['startFrom'] = $startForm;
// 		pr($data);
		$this->load->view('layouts/client_view',$data);    	
	}
        
        function getOrgDetails($id){
            $arrOrganizationDetail=array();
            $arrOrganizationDetail	= $this->organization->getOrgFullDetails($id);
            echo json_encode($arrOrganizationDetail);
        }

	/**
	 * List the Locations data for view_biography"
	 *
	 */
	function list_kol_details($type,$orglId = null) {
		if($type == 'phone'){
			$responce = array();
			$phone = array();
			$phone = $this->organization->getPhones($orglId, 'organization');
			//     		echo $this->db->last_query();exit;
			foreach ($phone as $row) {
				$responce->rows[$i]['id']=$row['id'];
				if ($row['is_primary']==0)
					$row['is_primary'] = "No";
					else
						$row['is_primary'] = "Yes";
						$responce[] = $row;
			}
		}
		if($type == 'staff'){
			$responce = array();
			$staff = array();
			$staff = $this->organization->getStaffs($orglId, 'organization');
			//     		echo $this->db->last_query();exit;
			foreach ($staff as $row) {
				$responce->rows[$i]['id']=$row['id'];
				$responce[] = $row;
			}
		}
		echo json_encode($responce);
	}
	/**
	 * Add/Update Phone for kol
	 */
	function add_update_phone($organizationId = null,$type,$id) {
		if($type=='edit'){
			$tableName = 'phone_numbers';
			$data['getSavedDetails'] = $this->kol->getAdditionalDetails($tableName,$id);
			$data['displayContent'] = true;
		}else{
			$data['displayContent'] = false;
		}
		$data['orgId'] = $organizationId;
		$data['arrPhoneType'] = $this->kol->getPhoneType();
		$arrLocations= $this->organization->getLocationByOrganizationId($organizationId);
		foreach($arrLocations as $row){
			$data['arrLocations'] = $row['id'];
		}
		$this->load->view('organizations/add_update_phone',$data);
	}
	/**
	 * Add/Update Staff for kol
	 */
	function add_update_staffs($organizationId = null,$type,$id) {
		if($type=='edit'){
			$tableName = 'staffs';
			$data['getSavedDetails'] = $this->kol->getAdditionalDetails($tableName,$id);
			$data['displayContent'] = true;
		}else{
			$data['displayContent'] = false;
		}
		$data['arrPhoneType'] = $this->kol->getPhoneType();
		$data['arrStaffTitle'] = $this->kol->getStaffTitle();
		$arrLocations= $this->organization->getLocationByOrganizationId($organizationId);
		foreach($arrLocations as $row){
			$data['arrLocations'] = $row['id'];
		}
		$data['orgId'] = $organizationId;
		$this->load->view('organizations/add_update_staff',$data);
	}
	
	function parent_association($org_id){
		$data['selected_org_id'] = $org_id;
		$this->load->view('organizations/parent_association', $data);
	}
}