<style type="text/css">

    input.error {
        background-position: 10px center;
        background-repeat: no-repeat;
    }
    .cancelIcon {
        margin-top: 5px !important;
    }

    label.error {
        padding: 2px 0px !important;
        background: none !important;
        border-color:none !important;
        border: none !important;
    }

    select.error {
        border: 1px solid red !important;
    }

    screen.css  error,.notice,.success {
        border: red;
        margin-bottom: 1em;
        padding: 0.8em;
    }

    #new_staff {
        display: none;
    }

    #new_phone {
        display: none;
    }

    td{
        vertical-align: top;
    }
    .error.postalerror{
    	display: block !important;
    	text-align: left !important;
    	color: green !important;
    }
    .alignRight{
    	vertical-align: top !important;
    }
    .requestedKols 	tr td{
    	padding: 0;
    }
    .requestedKols input[type="text"], .requestedKols select{
    	width: 200px;
    	margin-bottom: 5px;
    }
    #postal_code{
    	width: 192px;
    }
    #org_type{
    	width: 207px;
    }
</style>
<script type="text/javascript">
    var validationRules = {
    	
    	client_type: {
            required: true
        },
        client: {
            required: true
        }
    };
    var validationMessages = {
    	client_type: {
            required: "Required"
        },
        client: {
            required: "Required"
        }
    };
    $('#saveKolClient').click(function () {
        if (!$("#saveKolAssignClientForm").validate().form()) {
            return false;
        }
        $('.msgBox').removeClass('success');
        $('.msgBox').addClass('notice');
        $('.msgBox').show();
        $('.msgBox').html('Saving the data... <img src="<?php echo base_url() ?>images/ajax_loader_black.gif" />');
        $id = '<?php if($displayContent) echo $getSavedDetails['id'];?>';
        $.ajax({
            url: '<?php echo base_url() ?>kols/save_client_assign/'+$id,
            type: 'post',
            dataType: 'json',
            data: $('#saveKolAssignClientForm').serialize(),
            beforeSend: function(){
    			$("#saveKolClient").attr("disabled", "disabled");
            },
            success: function (returnData) {
                if (returnData.status == true) {
                    $('.msgBox').html('<?php echo lang("KOL"); ?> Assign Client saved successfully');
                    $('.msgBox').fadeOut(1500);
                    setTimeout(ReloadGrid, 2000);
                } else {
                    $('.msgBox').html('Error saving <?php echo lang("KOL"); ?> Staff');
                    $('.msgBox').fadeOut(1500);
                }
            }
        });
    });
    function ReloadGrid() {
    	$('#saveKolClient').removeAttr("disabled");
        $("#addAssignClientKols").dialog("close");
        getAssignedData();
    }

</script>
<div class="msgBox"></div>

<div id="similarNames">

</div>

<h4 style="border-bottom: 1px solid #bbbbbb;">Assign Profile</h4>

<form action="save_assign_client" method="post" id="saveKolAssignClientForm" name="saveKolAssignClientForm">
    <table class="requestedKols">
        <tbody>
            <tr>
                <td>
                    <table>
                        <tr>
                            <td class="alignRight">
                                <label for="client">User<span class="required">*</span> :</label>
                            </td>
                            <td>
                                <select name="client" id="client" style="max-width: 200px;" class="required">
						             <option value="">--Select--</option>
						            <?php foreach ($arrClients as $row){?>
						            <option value="<?php echo $row['id'];?>" <?php if(isset($getSavedDetails['user_id']) && $getSavedDetails['user_id']==$row['id']) echo "selected='selected'";?>><?php echo $row['first_name'].' '.$row['last_name'];?></option>
						            <?php }?>
						        </select>
                            </td>
                        </tr>
                    </table>
                </td>
                <td>
                    <table>
						<tr>
                            <td class="alignRight">
                                <label for="client_type">Type<span class="required">*</span> :</label>
                            </td>
                            <td>
                                <select name="client_type" id="client_type" style="max-width: 200px;" class="required">
						             <option value="">--Select--</option>
						            <?php foreach ($arrClientsType as $row){?>
						            <option value="<?php echo $row['id'];?>" <?php if(isset($getSavedDetails['type']) && $getSavedDetails['type']==$row['id']) echo "selected='selected'";?>><?php echo $row['name'];?></option>
						            <?php }?>
						        </select>
						        <input type="hidden" name="kol_id" value="<?php echo $kolId; ?>"/>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>

            <!-- End of Personal and Professional Information -->
        </tbody>
    </table>
<table>
	<tbody>
	    <tr>
	        <td colspan="2">
	            <div class="formButtons">	
                   		<input type="button" value="Save" name="submit" id="saveKolClient"></input>
	            </div>
	        </td>
	    </tr>
	</tbody>
</table>

</form>