<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$hook['post_controller_constructor'][] = array(	
		'class' 	=> 'custom_post_controller_hooks',
		'function'	=> 'checkUserLogin',
		'filename'	=> 'custom_post_controller_hooks.php',
		'filepath'	=> 'hooks'
);	
$hook['post_controller_constructor'][] = array(
		'class' 	=> 'custom_post_controller_hooks',
		'function'	=> 'getUserRolesPermissions',
		'filename'	=> 'custom_post_controller_hooks.php',
		'filepath'	=> 'hooks'
);	
?>