<style>
.msgContent{
	padding-left: 1px;
	padding-top: 18px;
}
.buttonMsgContent{
	padding-top: 17px;
	padding-left: 101px;
}
.microView .ui-dialog-content {
background-color: white !important;
 min-height: 99px !important;
}
</style>
<div class="msgContent">

	<p>
	<b>The feature you are trying to access is not available in the free trial version.</b>
	
	
	</p>
	<div class="buttonMsgContent">
		<button onclick="showAlertMessage()">Request a demo</button>
		
		<button onclick="closeDialogeBox()"> Cancel</button>
	</div>

</div>