<?php
/*
 * To reset selected KOL data
 *  
 * @Author		: Laxman K
 * @since 		: Otsuka v1.0.5 KOLM v4.3
 * Created on	: 19-11-2012
 *  
 */
?>
<br />
<h4>Reset KOL(s) Data</h4>
<form action="reset_kol_data" name="resetkoldata" method="post">
	<table>
		<tr>
			<td colspan="2">
				KOL ID(s) : <input type="text" name="kol_ids" style="width:300px" /> comma (,) separated KOL Id's
			</td>
		</tr>
		<tr>
			<td colspan="2">
				Reset data for below selected area(s)
			</td>
		</tr>
		<tr>
			<td>
				<input type="checkbox" name="arrSections[]" value="edu" />
				Education
			</td>
			<td>
				<input type="checkbox" name="arrSections[]" value="aff" />
				Affiliation
			</td>
		</tr>
		<tr>
			<td>
				<input type="checkbox" name="arrSections[]" value="events" />
				Events
			</td>
			<td>
				<input type="checkbox" name="arrSections[]" value="ct" />
				Clinical Trials
			</td>
		</tr>
		<tr>
			<td>
				<input type="checkbox" name="arrSections[]" value="pinfo" />
				Personal Info
			</td>
			<td>
				<input type="checkbox" name="arrSections[]" value="contacts" />
				Additional Contacts
			</td>
		</tr>
		<tr>
			<td colspan="2" align="center">
				<input type="submit" name="process" value="Process" />
			</td>
		</tr>
	</table>
</form>
<?php echo $msg;?>