<?php
/**
*File To Know Basics.
*Created By:
*Created On:7:20:27 PM
*/
	$autoSearchOptions = "width: 255, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
?>
<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array('search/kol_filters');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<script type="text/javascript">
		var options, a;
		
		// Autocomplet Options for the 'role' field 
	  	var SpecialtyNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_specialty_names',
				<?php echo $autoSearchOptions;?>
				
			};	

		// Autocomplet Options for the 'role' field 
	  	var educationNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_institute_names',
				<?php echo $autoSearchOptions;?>
				
			};	

	 	// Autocomplet Options for the 'Organizer' field 
		var organizationNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_organization_names',
				<?php echo $autoSearchOptions;?>
				
			};	

		// Autocomplet Options for the 'country' field
		var countryNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>country_helpers/get_country_names',
				<?php echo $autoSearchOptions;?>
				
			};	

		// Autocomplet Options for the 'country' field
		var eventNameNameAutoCompleteOptions = {
				serviceUrl: '<?php echo base_url();?>kols/get_search_eventLookup_names',
				<?php echo $autoSearchOptions;?>
				
			};	

/*
		$(document).ready(function(){

			// Trigger the Autocompleter for 'education' field of  Event'
			a = $('#specialty').autocomplete(SpecialtyNameAutoCompleteOptions);

			// Trigger the Autocompleter for 'education' field of  Event'
			a = $('#education').autocomplete(educationNameAutoCompleteOptions);

			// Trigger the Autocompleter for 'organizer' field of  Event'
			a = $('#organization').autocomplete(organizationNameAutoCompleteOptions);

			// Trigger the Autocompleter for 'country' field of  Event'
			a = $('#country').autocomplete(countryNameAutoCompleteOptions);

			// Trigger the Autocompleter for 'country' field of  Event'
			a = $('#eventName').autocomplete(eventNameNameAutoCompleteOptions);

		});
*/
</script>




<div id="searchFiltersElements">
	<form action="<?php echo base_url()?>kols/<?php if($searchType=='simple') echo 'filter_search_kols'; else echo 'filter_adv_search_kols';?>" name="searchFilterForm" method="post" id="searchFilterForm">
			<input type="hidden" name="search_type" id="searchType" value="<?php echo $searchType; ?>"/>
			<input type="hidden" name="filterCategory" id="filterCategory" value="people"/>
		<?php if($keyword!=null) {?>
			<input type="hidden" name="keyword" id="keyword" value="<?php echo $keyword; ?>"/>
		<?php }?>
		<?php if($arrAdvSearchFields!=null){ ?>
			<input type="hidden" name="keywords" id="hiddenSearchField" value="<?php echo $arrAdvSearchFields['keywords']; ?>"/>
			<input type="hidden" name="first_name" id="hiddenSearchField" value="<?php echo $arrAdvSearchFields['first_name']; ?>"/>
			<input type="hidden" name="middle_name" id="hiddenSearchField" value="<?php echo $arrAdvSearchFields['middle_name']; ?>"/>
			<input type="hidden" name="last_name" id="hiddenSearchField" value="<?php echo $arrAdvSearchFields['last_name']; ?>"/>
			<input type="hidden" name="sub_specialty" id="hiddenSearchField" value="<?php echo $arrAdvSearchFields['sub_specialty']; ?>"/>
			<input type="hidden" name="title" id="hiddenSearchField" value="<?php echo $arrAdvSearchFields['title']; ?>"/>
			<input type="hidden" name="postal_code" id="hiddenSearchField" value="<?php echo $arrAdvSearchFields['postal_code']; ?>"/>
		<?php }?>
		<p>
			<label>Specialty</label>
			<?php if($arrAdvSearchFields!=null && $arrAdvSearchFields['specialty']!=''){?>
				<input type="text" name="specialty" id="specialty" value="<?php echo $arrAdvSearchFields['specialty'];?>"/>
			<?php } else {?>
			<input type="text" name="specialty" id="specialty" value="<?php if($arrFilterFields!=null) echo $arrFilterFields['specialty']; else echo ""; ?>"/>
			<?php }?>
		</p>
		<p>
			<label>Country</label>
			<?php if($arrAdvSearchFields!=null && $arrAdvSearchFields['country']!=''){?>
				<input type="text" name="country" id="country" value="<?php echo $arrAdvSearchFields['country'];?>"/>
			<?php } else {?>
			<input type="text" name="country" id="country" value="<?php if($arrFilterFields!=null) echo $arrFilterFields['country']; else echo ""; ?>"/>
			<?php }?>
		</p>
		<p>
			<label>Organization</label>
			<?php if($arrAdvSearchFields!=null && $arrAdvSearchFields['organization']!=''){?>
				<input type="text" name="organization" id="organization" value="<?php echo $arrAdvSearchFields['organization'];?>"/>
			<?php } else {?>
				<input type="text" name="organization" id="organization" value="<?php if($arrFilterFields!=null) echo $arrFilterFields['organization']; else echo ""; ?>"/>
			<?php }?>
		</p>
		<p>
			<label>Education </label>
			<input type="text" name="education" id="education" value="<?php if($arrFilterFields!=null) echo $arrFilterFields['education']; else echo ""; ?>"/>
		</p>
		<p>
			<label>Event Name</label>
			<input type="text" name="event_name" id="eventName" value="<?php if($arrFilterFields!=null) echo $arrFilterFields['event_name']; else echo ""; ?>"/>
		</p>
		<input type="button" name="do_earch" id="doFilter" onClick="doSearchFilter(-1)" value="Filter"/>
	</form>
</div>