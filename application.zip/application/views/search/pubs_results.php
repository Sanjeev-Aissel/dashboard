<?php
/**
*File To show Pubmed search result page.
*
*@author: Ambarish N
*@created on: 09-02-11
*/
?>

<!--  Autocomplete Plugin -->
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.autocomplete.js"></script>
	
<style>
/* added by laxman */
	.span-4 {
		width:175px;
	}
	#searchResultsContainer {
		margin-left:2px;
		margin-right:2px;
		margin-top: 0px;
		margin-right:0px;
	}
	
	#searchResultsContainer table,table.listResultSet{
		border-left:1px solid #ccc;
		border-top:1px solid #ccc;
		border-left:1px solid #eee;
		border-top:1px solid #eee;
		border-bottom:1px solid #EEEEEE;	
		width:100%;
		border: 0px;
	}
	
	#searchResultsContainer table tbody tr.ui-widget-content{
		border:1px solid #ccc;
		border:1px solid #eee;
		border: 0px;
	}
	
	#searchResultsContainer table th,table.listResultSet th{
		text-align:center;	
		background: #22A1ED;
		color:#FFFFFF;
		background: none;
		color:#777;
		border: 0px;
	}
	
	#searchResultsContainer table td, #searchResultsContainer table th,table.listResultSet th,table.listResultSet td{
		font-size:12px;
		color:#333333;
		padding:6px 2px 6px 3px;
		vertical-align:top;
		white-space:normal;
		border-right:1px solid #ccc;
		border-bottom:1px solid #ccc;
		border-right:1px solid #eee;
		border-bottom:0px solid #eee;
		border: 0px;
		border-bottom: 1px solid #dddddd;
	}
	#searchResultsContainer .searchResultsMsg #resFor{
		padding-left: 0px !important;
	}
</style>
<script type="text/javascript">
	var noOfRecordsPerPage	= 10;
	function updateRecordsPerPage(viewType){
		noOfRecordsPerPage	= $('#noOfRecordsPerPage').val();
		doSearchFilter(0);
	}
	function doSearchFilter(startIndex){
		$('#searchResultsContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		var formAction=$("#searchFilterForm").attr("action");
		if(noOfRecordsPerPage>0){
			formAction	+= "/"+noOfRecordsPerPage;
		}
		var data=$("#searchFilterForm").serialize();
		data=data+"&page="+startIndex;
		/*
		var formAction="http://localhost/kolm/kols/filter_search_kols"
		dvar data={};
		data['country']=document.getElementById('country').value;
		data['specialty']=document.getElementById('specialty').value;
		data['organization']=document.getElementById('organization').value;
		data['education']=document.getElementById('education').value;
		data['event_name']=document.getElementById('eventName').value;
		data['page']=startIndex;
		*/
		$.ajax({
			type: "post",
			dataType:"text",
			data: data,
			url: formAction,
			success: function(returnData){
				$("#searchResultsContainer").html(returnData);
			},
			complete: function(){
				$('#searchResultsContainer').unblock();
			}
		});
	}

	//uncheck all the checkbox and reload the filtered results
	function resetFilters(){
		$.each($("#categoriesContainer input[type='checkbox']:checked"), function() {
			$(this).removeAttr('checked');
		});
		$.each($("#categoriesContainer input[type='text']"), function() {
			$(this).val('');
		});
		$(".hiddenSearchField").each(function(){
			$(this).val('');
		});
		doSearchFilter1(-1);
	}

	function doSearchFilter1(startIndex,thisEle){
		var expandedCategories = new Array();
		$('.expanded').each(function(){
			var parentId=$(this).parent().attr('id');
			expandedCategories.push(parentId);
		});
		var collapsedCategories = new Array();
		$('.collapsed').each(function(){
			var parentId=$(this).parent().attr('id');
			collapsedCategories.push(parentId);
		});
		//show loading image
		//$('.loadingIndicator').show();

		$('#searchResultsContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		//If 'All' is selected uncheck other checkbox of that category, 
		//Else uncheck the checkbox representing 'All', do the same for all categories
		if(thisEle!=null){
			if($(thisEle).val()=='journal'){
				$('.journalElement').each(function(){
					$(this).removeAttr('checked');
				});
			}else {
				if($(thisEle).attr('class')=='journalElement')
					$('#allJournals').removeAttr('checked');
			}
	
			if($(thisEle).val()=='affiliation'){
				$('.affiliationElement').each(function(){
					$(this).removeAttr('checked');
				});
			}else {
				if($(thisEle).attr('class')=='affiliationElement')
					$('#allAffiliations').removeAttr('checked');
			}
	
			if($(thisEle).val()=='meshterm'){
				$('.meshtermElement').each(function(){
					$(this).removeAttr('checked');
				});
			}else {
				if($(thisEle).attr('class')=='meshtermElement')
					$('#allMeshterms').removeAttr('checked');
			}
	
			if($(thisEle).val()=='substance'){
				$('.substanceElement').each(function(){
					$(this).removeAttr('checked');
				});
			}else {
				if($(thisEle).attr('class')=='substanceElement')
					$('#allSubstances').removeAttr('checked');
			}
	
		}
		//End of toggling 'All' and 'Others'
		
		//Get Selected check box value for each Category separatly
		var journalValues = new Array();
		$.each($("input[name='journal_ids[]']:checked"), function() {
			journalValues.push($(this).val());
		});
		var affiliationValues = new Array();
		$.each($("input[name='affiliation_ids[]']:checked"), function() {
			affiliationValues.push($(this).val());
		});
		var meshtermValues = new Array();
		$.each($("input[name='meshterm_ids[]']:checked"), function() {
			meshtermValues.push($(this).val());
		});
		
		var substanceValues = new Array();
		$.each($("input[name='substance_ids[]']:checked"), function() {
			substanceValues.push($(this).val());
		});
		//End of Selecting Checkbox value for each Category separatly
		
		//Make all check boxes disabled while Loading
		$("#searchFiltersElements input[type='checkbox']").each(function(){
			$(this).attr({'disabled': true});
		});
		
		
		var formAction=$("#searchFilterForm").attr("action");
		var data=$("#searchFilterForm").serialize();
		data=data+"&page="+startIndex;
		data=data+"&journals="+journalValues;
		data=data+"&affiliations="+affiliationValues;
		data=data+"&meshterms="+meshtermValues;
		data=data+"&substances="+substanceValues;
		
		//Send Request to reload the filtered search results
		$.ajax({
			type: "post",
			dataType:"text",
			data: data,
			url: formAction,
			success: function(returnData){
				$("#searchResultsContainer").html(returnData);
			},
			complete: function(){
				//hide loading image
				$('.loadingIndicator').hide();
				$('#searchResultsContainer').unblock();
			}
		});
		//Send Request to reload the filtered 'Filter CheckBox's'
		$.ajax({
			type: "post",
			dataType:"text",
			data: data,
			url: '<?php echo base_url();?>pubmeds/reload_pub_filters',
			success: function(returnData){
				$("#searchFiltersContainer").html(returnData);
			},
			complete: function(){
				//hide loading image
				$('.loadingIndicator').hide();
				$('#searchResultsContainer').unblock();
				//Expanding and collapseing the categoties
				$.each(expandedCategories, function(index, value) {
					$('#'+value+' label.facet-toggle').removeClass('collapsed');
					$('#'+value+' label.facet-toggle').addClass('expanded');
					$('#searchLeftBar #'+value+' ul').show(); 
				});	
				$.each(collapsedCategories, function(index, value) {
					$('#'+value+' label.facet-toggle').removeClass('expanded');
					$('#'+value+' label.facet-toggle').addClass('collapsed');
					$('#searchLeftBar #'+value+' ul').hide(); 
				});
			}
		});
	}

	$(document).ready(function(){
		
		// Settings for the Dialog Box
		var pubMicroProfileDialogOpts = {
				title: "Publication Snapshot",
				modal: true,
				autoOpen: false,
				width: 800,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};
		
		$("#pubMicroProfile").dialog(pubMicroProfileDialogOpts);		
	});
	
	/**
	* Opens the Modal Box with the Micro Profile content of KOL
	* @param: kolId
	*/
	function viewPubMicroProfile(pubId){
		$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#pubMicroProfile").dialog("open");
		$(".profileContent").load('<?php echo base_url().'pubmeds/view_micro_pub/'?>'+pubId);
		return false;
	}



</script>
<div id="searchContainer">
	<div id="searchTopMenus"></div>
	<div id="refinedByWrapper" class="rightRefinedByFilter">
		<div id="refinedByContainer">
			<div id="rightSideBarSlider" class="expandRightSideBar tooltip-demo tooltop-left"><a href="#" class="tooltipLink" rel='tooltip' title="Show Refine By">&nbsp;</a></div>
			<div id="searchLeftBar" style="display: none;">
				<div id="resetBttnContainer"><label class="tooltip-demo tooltop-left" id="resetBttn" onclick="resetFilters();"><a href="#" class="tooltipLink" rel='tooltip' title="Reset Filters">&nbsp;</a></label>Reset</div>
				<h3><div class="funnelIcon sprite_iconSet"></div>Refine By</h3>
				<div id="searchFiltersContainer">
					<?php echo $this->load->view($filterPage,$filterData);?>
				</div>
			</div>
		</div>
	</div>
	<br />
	<div id="searchResultsContainer" class="span-23 last">
		<?php echo $this->load->view($pubsResultsPage,$pubsResultsData);?>
	</div>

	<div class="clear">&nbsp;</div>
	
	<!-- Container for the 'Publication Micro Profile' modal box -->
	<div id="dailog1">	
		<div id="pubMicroProfile" class="microProfileDialogBox">
			<div class="profileContent"></div>
		</div>
	</div>
	<!--End of  Container for the 'Publication Micro Profile' modal box -->
	
</div>