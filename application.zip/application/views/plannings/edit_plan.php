<?php
/**
 * Contains a form to edit plans
 * 
 * @package views.plannings
 * @author Ramesh B
 * @since 3.1
 * @created 13-09-2011
*/
$kolAutoCompleteOptions = "width: 160, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
?>

<style type="text/css">
	#editPlanForm label {
		background-color: #FFFFFF;
	    display: inline;
	    float: left;
	    line-height: 30px;
	    padding-right: 3px;
	    text-align: right;
	    width: 140px;
	}
	
	#editPlanForm select{
		width: 200px;
	}
	
	#planEditContainer {
		background-color: #FFFFFF;
	}
	
	#CalendarControl {
		z-index: 1030;
	}
	#editPlanForm input[type='text']{
		width: 100px;
	}
	#editPlanForm input[type='button']{
		margin-left: 215px;
	}
</style>
<script type="text/javascript">

	var kolAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_autocomplete',
		<?php echo $kolAutoCompleteOptions;?>,
				onSelect: function(event, ui) { 
			
			var kolId = $(event).children('.id1').html();
		
			var selText = $(event).children('.kolName').html();
		
			selText=selText.replace(/\&amp;/g,'&');
		
		
			$('#kolId').val(selText);
			//$('#kolId').val(kolId);
			
			//$('#kolNameForAuto').val(selText);
			
		 }
	};
	var kolAutoComplete	= $('#kolId').autocomplete(kolAutoCompleteOptions);
	
	$(document).ready(function(){
		<?php 
			/** @Author Ramesh
			 ** @since  22 Aug 2012
			 **The following code is used to disable caching in IE
	 		**/
			$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
			$this->output->set_header("Pragma: no-cache"); 
		?>
		//Validate the plans form using jquery plugin
		$("#editPlanForm").validate({
			debug:true,
			onkeyup:true
		});
		
		$("#month").rules("add", {
			 required: true,
			 validMonth : true,
			 messages: {
			   required: "Required input",
			   validMonth: "Month should not be past"
			 }
		});

		$("#targets").rules("add", {
			 digits: true,
			 messages: {
				digits: "Please enter only digits"
			 }
		});
		 $('.map-info.tooltop-bottom').tooltip({
	     	selector: "a[rel=tooltip]",
	    	placement:'bottom',
	    	delay:tooltipDelay
	    });
	});
</script>

	<form name="editPlanForm" id="editPlanForm" action="<?php echo base_url()?>plannings/update_plan">
		<div class="msgBoxContainer"><div class="planMsgBox"></div></div>
		<input type="hidden" name="plan_id" id="planId" value="<?php echo $arrPlanDetails['id'];?>"></input>
		<table id="plansDetails">
			<tr>
				<td>
					<label>Product :<span class="required">*</span></label>
					<select name="objective_id" id="objectiveId" class="required">
						<option value="">Select Product</option>
						<?php if(isset($arrObjectives)){?>
							<?php foreach($arrObjectives as $key => $value){?>
								<option value="<?php echo $key;?>" <?php if($arrPlanDetails['objective_id']==$key) echo 'selected="selected"';?> ><?php echo $value;?></option>
							<?php }?>
						<?php }?>
					</select>
				</td>
			</tr>
			<tr>
				<td>
					<label for="kolId"><?php echo lang("KOL");?> Name :<span class="required">*</span></label>
<!--					<input type="text" name="kol_id"  id="kolId" class="required autocompleteInputBox" value="<?php if($arrPlanDetails!=null) echo $arrPlanDetails['first_name']." ".$arrPlanDetails['middle_name']." ".$arrPlanDetails['last_name'];?>" style="width: 200px;"/>-->
						<input type="text" name="kol_id"  id="kolId" class="required autocompleteInputBox" value="<?php if($arrPlanDetails!=null) echo $this->common_helpers->get_name_format($arrPlanDetails['first_name'],$arrPlanDetails['middle_name'],$arrPlanDetails['last_name']);?>" style="width: 200px;"/>
					<span id="tooltip-about-name-format" class="map-info tooltop-bottom"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Enter <?php echo lang("KOL");?> name in the format of First_name Middle_name Last_name</span>">&nbsp;</a></span>
				</td>
			</tr>
			<tr>
				<td>
					<label for="userId">Assign To :<span class="required">*</span></label>
					<select name="user_id" id="userId" class="required">
						<option value="">Select Responsible</option>
						<?php if(isset($arrUsers)){?>
							<?php foreach($arrUsers as $key => $value){?>
								<option value="<?php echo $key;?>" <?php if($arrPlanDetails['user_id']==$key) echo 'selected="selected"';?>><?php echo $value;?></option>
							<?php }?>
						<?php }?>
					</select>
				</td>
			</tr>
			<tr>
				<td>
					<label for="month">Month :<span class="required">*</span></label>
					<input type="text" name="month" id="month" value="<?php if($arrPlanDetails['plan_date']!='00-0000')echo $arrPlanDetails['plan_date'];?>" class="required" onfocus="showCalendarControl(this.id);"></input>
				</td>
			</tr>
			<tr>
				<td>
					<label for="targets">Targets :<span class="required">*</span></label>
					<input type="text" name="targets" id="targets"  value="<?php echo $arrPlanDetails['targets'];?>" class="required"></input>
				</td>
			</tr>
		</table>
		<input type="button" name="save_plans" value="Save" onclick="updatePlan();"/>
	</form>