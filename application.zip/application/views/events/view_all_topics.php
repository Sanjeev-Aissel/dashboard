<?php
/**
 * All Events  Topic  by Specialty Model box contents holder page
 * 
 * @author Ramesh B
 * @since	2.5
 * @created: 01-07-2011
 */
?>
<style>
/*
#viewAllTopicsContainer div{
	float: left;
}

#viewAllTopicsContainer #topicsHolder{
	min-height: 150px;
	width: 150px;
}

#viewAllTopicsContainer #topicsHolder select{	
	width: 100%;
}

#viewAllTopicsContainer input[type="button"]{	
	margin-left: 180px;
}
*/
#viewAllTopicsContainer select{
	width:275px;
}
#topicsHolder select{
	height: 75px;
}
</style>
<script type="text/javascript">
	function loadTopics(specialtyId){

		var specialtyId=$("#specialtyHolder select").val();
		$("#menu2 li a").each(function(){
			if($(this).hasClass('selectedTab')){
				$(this).removeClass('selectedTab')
			}
		});
		$("#topic_"+specialtyId+" a").addClass('selectedTab');
		$('#topicsHolder').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		$.ajax({
			type: "post",
			dataType:"json",
			url: '<?php echo base_url();?>kols/get_topics_by_specialty/'+specialtyId,
			success: function(returnData){
				var selectOptions="";
				$.each(returnData,function(key,value){
					selectOptions+="<option value='"+key+"'>"+value+"</option>";
				});
				if(selectOptions=="")
					selectOptions="<option value='0'> No Topics Found</option>";				
				$("#topicsHolder select").html(selectOptions);
			},
			complete: function(){
				//hide loading image
				$('#topicsHolder').unblock();
				
			}
		});
	}

	function showSelectedTopic(){
		var topicId=$("#topicsHolder select").val();
		var topicName=$("#topicsHolder select option:selected").text();
		if(topicId!=0)
			addSelectedTopicToList(topicId,topicName);
		$("#eventTopics").dialog("close");
	}

	$(document).ready(function(){
		//loadTopics(1);
	});
</script>
<div id="viewAllTopicsContainer">
	<h3>Topic(s) from Specialty</h3>
	<!-- 
	<div id="menu2">
		<ul>
			<?php $i=0; foreach($arrSpecialties as $key => $value){?>
				<li id="topic_<?php echo $key;?>"><a <?php if($i==0) echo "class='selectedTab'";?> href="#1" title="Link 1" onclick="loadTopics('<?php echo $key;?>');"><?php echo $value;?></a></li>
			<?php $i++; if($i>=20) break;}?>
		</ul>
	</div>
	 -->
	 <table>
	 	<tr>
	 		<td class="alignRight">Select Specialty:</td>
	 		<td><div id="specialtyHolder">
	 			<select onchange="loadTopics();">
					<option>Select Specialty</option>
					<?php  foreach($arrSpecialties as $key => $value){?>
						<option value="<?php echo $key;?>"> <?php echo $value;?></option>
					<?php }?>
				</select>
				</div>
	 		</td>
	 	</tr>
	 	<tr>
	 		<td class="alignRight" style="vertical-align: top;">Select Topic(s):</td>
	 		<td>
 				<div id="topicsHolder">
					<select multiple="multiple"></select>
				</div>
	 		</td>
	 	</tr>
	 	<tr>
	 		<td colspan="2" class="alignCenter"><input type="button" value="Ok" onclick="showSelectedTopic();" /></td>
	 	</tr>
	 </table>
</div>
