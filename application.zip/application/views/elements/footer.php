<style>
.copyRightText{
	float: right;
    padding-right: 5px;
}
.copyRightText a{
	text-decoration: none;
}
</style>
<div id="footerWrapper">
	<div class="copyRightText">
		<a href="<?php echo base_url()?>client_users/show_terms_page/terms" class="privacy" target="new">Terms of Service</a> 
		| <?php echo APP_PRODUCT_INFO_FOOTER;?>
		<span>Copyright &copy; <?php echo COPYRIGHT;?> <a href="http://www.aissel.com" target="new">Aissel</a> Technologies</span>
		<span>Powered by <a href="http://www.aissel.com" target="new">Aissel</a></span>
	</div>
</div>