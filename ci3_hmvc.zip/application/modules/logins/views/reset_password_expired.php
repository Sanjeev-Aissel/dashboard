<!-- 
 * View File to Show Reset Password Link expiry Message 
 * @Author	: Kishan Ravindra (00001111)
 -->
<div class='alert alert-danger'>
	<h4 align="center">
		Your activation key is incorrect or expired. Please check your email again and follow the instructions.
		or <a href='<?php echo base_url();?>logins/logins/show_forgot_password_page'>Retry</a>. 
	</h4>
</div>