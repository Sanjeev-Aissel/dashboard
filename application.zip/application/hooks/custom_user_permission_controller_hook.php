<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| Check user permission to access each method
| -------------------------------------------------------------------------
| Author: Laxman K
| Since : 24-06-2015
*/
class Custom_user_permission{
    var $CI;
    var $moduleName;
    var $controllerName;
    var $methodName;
    var $param;
    var $params;
	function Custom_user_permission(){
    	$this->CI =& get_instance();
    	$this->CI->load->helper('url');
    	$this->CI->load->plugin('geo_location');
    	$this->CI->load->model('common_helpers');
    	$this->moduleName	= $this->CI->uri->segment(1);
    	$this->controllerName	= $this->CI->uri->segment(2);
    	$this->methodName	= $this->CI->uri->segment(3);
    	$this->param	= $this->CI->uri->segment(4);
    	$this->params	= (isset($_SERVER['PATH_INFO'])?$_SERVER['PATH_INFO']:'');
    }
    function is_user_allowed_to_access_page(){
    	//print_r($this->CI->session->userdata);
    	//echo $this->moduleName.'-'.$this->controllerName.'-'.$this->methodName;
    	if(!$this->CI->session->userdata('logged_in')) {
    		//echo 'is not logged in';
	    	if(!$this->checkForAllowedUrlsWithoutLogin()){
				if($this->moduleName!="m")
		    		redirect(base_url().'login');
	    		else
	    			redirect(base_url().MOBILE_URL_SEGMENT.'login');
	    	}else{
	    		//echo 'not allowed';
	    		//redirect(base_url().'error/message/not_allowed');
//                     header('Location:'.base_url().$this->CI->session->userdata("back_url"));
	    	}
    	}else{
    		$isAnalyst	= $this->CI->session->userdata('is_analyst');
    		//echo 'logged in';
    		if(!$isAnalyst){
    			//redirect(base_url().MOBILE_URL_SEGMENT.'alerts');
    		}
    		//print_r($this->CI->session->userdata);
    	}
    }
    
    function checkForAllowedUrlsWithoutLogin(){
    	//Array of all the urls which are allowed without login
    	$isAllowed	= false;
    	if(empty($this->moduleName)){
    		$this->moduleName	= '';
    	}
    	if(empty($this->controllerName)){
    		$this->controllerName	= '';
    	}
    	if(empty($this->controllerName)){
    		$this->methodName	= '';
    	}
    	$arrAllowedUrls		= array();
    	$arrAllowedUrls[]	= array('module'=>'scaffolding','ignore'=>'controller');
    	$arrAllowedUrls[]	= array('module'=>'login','ignore'=>'controller');
    	$arrAllowedUrls[]	= array('module'=>'users','controller'=>'forgot_password','method'=>'');
    	$arrAllowedUrls[]	= array('module'=>'users','controller'=>'users','method'=>'forgot_password');
    	$arrAllowedUrls[]	= array('module'=>'users','controller'=>'reset_password','ignore'=>'method');
    	$arrAllowedUrls[]	= array('module'=>str_replace('/','',MOBILE_URL_SEGMENT),'controller'=>'login','method'=>'');
    	$arrAllowedUrls[]	= array('module'=>IPAD_URL_SEGMENT,'controller'=>'login','method'=>'');
    	$arrAllowedUrls[]	= array('module'=>'error','ignore'=>'controller');
    	$arrAllowedUrls[]	= array('module'=>'demo','controller'=>'','method'=>'');
    	$arrAllowedUrls[]	= array('module'=>'demo','controller'=>'welcome','method'=>'');
        $arrAllowedUrls[]	= array('module'=>'notifications','controller'=>'emails','method'=>'send_mail');
    	//$arrAllowedUrls[]	= array('module'=>'demo','controller'=>'welcome','method'=>'phpinfo');
    	if(empty($this->moduleName)){
    		return true; //load default controller
    	}
    	foreach($arrAllowedUrls as $row){
    		//echo $this->moduleName.'-'.$this->controllerName.'-'.$this->methodName.' <br />';
    		//echo $row['module'].'-'.$row['controller'].'-'.$row['method'].' <br />';
    		if(isset($row['ignore'])){
    			switch($row['ignore']){
    				case 'controller'	: if($row['module']==$this->moduleName){$isAllowed	= true;}
    					break;
    				case 'method'	: if($row['module']==$this->moduleName && $row['controller']==$this->controllerName){$isAllowed	= true;}
    					break;
    			}
	    		if($isAllowed){
	    			break;
	    		}
    		}else if($row['module']==$this->moduleName && $row['controller']==$this->controllerName && $row['method']==$this->methodName){
    			$isAllowed	= true;
    			break;
    		}
    	}
    	return $isAllowed;
    }
    function log_activity(){
    	//echo '<pre>';print_r($_SERVER);echo '</pre>';
    	$isEnabled	= $this->CI->config->item('log_user_activity');
    	if(LOG_USER_ACTIVITY && $isEnabled){
    	    //Device detect
    	    $mobile = mobile_device_detect();
    	    $isMobileDevice	= false;
    	    $deviceFrom = 'd';
    	    if(isset($mobile[1]) && $mobile[1] != 'Apple iPad'){
    	        $isMobileDevice	 = true;
    	        $deviceFrom = 'm';
    	        if($this->controllerName=='logins')
    	            $this->controllerName = 'login';
    	    }
    	    if(IS_IPAD_REQUEST){
    	        $deviceFrom = 'i';
    	    }
    	    
	    	$arrData	= array();
	    	$arrData['module']	= $deviceFrom;
	    	$arrData['controller']	= $this->moduleName;
	    	$arrData['method']	= $this->controllerName;
	    	$arrData['param']	= $this->params;
	    	if(($this->moduleName == 'kols' || $this->controllerName == 'kols') && ($this->controllerName == 'view' || $this->methodName == 'view')){
	    		$arrData['miscellaneous1']	= 'kols';
	    		$param = explode('/', $this->params);
	    		foreach($param as $row){
	    			if($row!=NULL){
	    				$kol_id = $this->CI->common_helpers->getKolidOrUniqueId($row);
	    				if($kol_id > 0){
	    					$arrData['miscellaneous2']	= $kol_id;
	    					break;
	    				}
	    			}
	    		}
	    	}
	    	if($this->CI->session->userdata('logged_in')){
	    		$arrData['created_by']	= $this->CI->session->userdata('user_id');
	    	}
	    	$arrData['created_on']	= date("Y-m-d H:i:s");
	    	if(isset($_SERVER['HTTP_REFERER'])){
	    		$arrData['url']	= $_SERVER['HTTP_REFERER'];
	    	}else{
	    		$arrData['url']	= $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	    	}
	    	$arrData['ip_address']	= $_SERVER['REMOTE_ADDR'];
	    	
	    	$ip_address = $arrData['ip_address'];
	    	$query = $this->CI->db->query("select ipAddress from ip_address_location where ipAddress = '$ip_address' ");
	    	$afftectedRows = $this->CI->db->affected_rows();
	  
	    	if ($afftectedRows == 1) {
	    		$arrData['os']	= $this->getOS($_SERVER['HTTP_USER_AGENT']);
	    		$arrData['browser']	= $this->getBrowser($_SERVER['HTTP_USER_AGENT']);
	    		$arrLogDetails	= $this->CI->config->item('log_details');
	    		foreach($arrLogDetails as $key=>$value){
	    			if(!empty($value))
	    				$arrData[$key]	= $value;
	    		}
// 	    		pr($arrData);
	    		if($arrData['module']!='i' && $arrData['module']!='m'){
	    		    $arrData['module']	= 'd';
	    		    $arrData['controller']	= $this->moduleName;
	    		    $arrData['method']	= $this->controllerName;
	    		    $arrData['param']	= $this->methodName;
	    		}else{
	    		    $arrData['module']	= $deviceFrom;
	    		    if($this->moduleName =='i' || $this->moduleName =='m'){
	    		        if($this->methodName == 'save_clinical_trial_manual'){
	    		            $this->controllerName = 'kols';
	    		        }
    	    		    $arrData['controller']	= $this->controllerName;
    	    		    $arrData['method']	= $this->methodName;
	    		    }else{
	    		        $arrData['controller']	= $this->moduleName;
	    		        $arrData['method']	= $this->controllerName;
	    		    }
	    		    $arrData['param']	= $this->params;
	    		}
	    		$this->CI->db->insert('log_activities',$arrData);
	    	}else{
	    		//Get errors and locations
	    		//$locations = $ipLite->getCity($ip_address);
	    		$locations = get_geolocation($ip_address);
	    		//$errors = $ipLite->getError();
	    		//var_dump($locations);
	    		//Getting the result
	    		$arrIpData = array();
	    		if (!empty($locations) && is_array($locations)) {
	    			foreach ($locations as $field => $val) {
	    				$arrIpData[$field] = $val;
	    			}
	    		}
	    		//pr($arrIpData);
	    		$this->CI->db->insert('ip_address_location',$arrIpData);
	    		$arrData['os']	= $this->getOS($_SERVER['HTTP_USER_AGENT']);
	    		$arrData['browser']	= $this->getBrowser($_SERVER['HTTP_USER_AGENT']);
	    		$arrLogDetails	= $this->CI->config->item('log_details');
	    		foreach($arrLogDetails as $key=>$value){
	    			if(!empty($value))
	    				$arrData[$key]	= $value;
	    		}
	    		if($arrData['module']!='i' && $arrData['module']!='m'){
	    		    $arrData['module']	= 'd';
	    		    $arrData['controller']	= $this->moduleName;
	    		    $arrData['method']	= $this->controllerName;
	    		    $arrData['param']	= $this->methodName;
	    		}else{
	    		    $arrData['module']	= $deviceFrom;
	    		    if($this->moduleName =='i' || $this->moduleName =='m'){
	    		        if($this->methodName == 'save_clinical_trial_manual'){
	    		            $this->controllerName = 'kols';
	    		        }
	    		        $arrData['controller']	= $this->controllerName;
	    		        $arrData['method']	= $this->methodName;
	    		    }else{
	    		        $arrData['controller']	= $this->moduleName;
	    		        $arrData['method']	= $this->controllerName;
	    		    }
	    		    $arrData['param']	= $this->params;
	    		}
	    		$this->CI->db->insert('log_activities',$arrData);
	    	}
	    	//print_r($arrData);
    	}
    }
    function getOS($user_agent) {
    	$os_platform    =   "Unknown OS Platform";
    	$os_array       =   array(
                            '/windows nt 10/i'     =>  'Windows 10',
                            '/windows nt 6.3/i'     =>  'Windows 8.1',
                            '/windows nt 6.2/i'     =>  'Windows 8',
                            '/windows nt 6.1/i'     =>  'Windows 7',
                            '/windows nt 6.0/i'     =>  'Windows Vista',
                            '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                            '/windows nt 5.1/i'     =>  'Windows XP',
                            '/windows xp/i'         =>  'Windows XP',
                            '/windows nt 5.0/i'     =>  'Windows 2000',
                            '/windows me/i'         =>  'Windows ME',
                            '/win98/i'              =>  'Windows 98',
                            '/win95/i'              =>  'Windows 95',
                            '/win16/i'              =>  'Windows 3.11',
                            '/macintosh|mac os x/i' =>  'Mac OS X',
                            '/mac_powerpc/i'        =>  'Mac OS 9',
                            '/linux/i'              =>  'Linux',
                            '/ubuntu/i'             =>  'Ubuntu',
                            '/iphone/i'             =>  'iPhone',
                            '/ipod/i'               =>  'iPod',
                            '/ipad/i'               =>  'iPad',
                            '/android/i'            =>  'Android',
                            '/blackberry/i'         =>  'BlackBerry',
                            '/webos/i'              =>  'Mobile'
                            );
                            foreach ($os_array as $regex => $value) {
                            	if (preg_match($regex, $user_agent)) {
                            		$os_platform    =   $value;break;
                            	}
                            }
                            return $os_platform;

    }

    function getBrowser($user_agent) {
    	$browser        =   "Unknown Browser";
    	$browser_array  =   array(
                            '/msie/i'       =>  'Internet Explorer',
                            '/firefox/i'    =>  'Firefox',
    						'/chrome/i'     =>  'Chrome',
                            '/safari/i'     =>  'Safari',
                            '/opera/i'      =>  'Opera',
                            '/netscape/i'   =>  'Netscape',
                            '/maxthon/i'    =>  'Maxthon',
                            '/konqueror/i'  =>  'Konqueror',
                            '/mobile/i'     =>  'Native Browser'
                            );
                            foreach ($browser_array as $regex => $value) {
                            	if (preg_match($regex, $user_agent)) {
                            		$browser    =   $value;break;
                            	}
                            }
                            return $browser;
    }

}
