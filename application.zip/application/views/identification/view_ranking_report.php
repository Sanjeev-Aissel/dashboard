<table id="rankingTable">
	<thead>
		<tr>
			<th rowspan="2">#</th>
			<th class="name" rowspan="2">Name</th>
			<th class="assoc">Associations</th>
			<th class='event' colspan="3">Congresses & Conferences</th>
			<th class="editorial">Editorial Boards</th>
			<th class="expoert">Expert center</th>
			<th class="pub" colspan="6">Publications All Years</th>
			<th class="trial">Clinical Trials</th>
			<th>Guidelines</th>
			<th rowspan="21">Score</th>
		</tr>
		<tr>
			<th class="assoc">Total</th>
			<th class='event'>Total</th>
			<th class='event'>Speaking</th>
			<th class='event'>Organizing Committee</th>
			<th class="editorial">Total</th>
			<th class="expert">Total</th>
			<th class="pub">All Pubs</th>
			<th class="pub">Lead Author</th>
			<th class="pub">Middle Author</th>
			<th class="pub">Single Author</th>
			<th class="pub">First Author</th>
			<th class="pub">Last Author</th>
			<th class="trial">Total</th>
			<th>Total</th>
		</tr>
	</thead>
	<tbody>
		<?php $i=1; foreach($arrData as $kol){?>
			<tr>
				<td> <?php echo $i;?> </td>
				<td class="name"> <?php echo $kol['first_name'].' '.$kol['middle_name'].' '.$kol['last_name'];?> </td>
				<td class="assoc"> <?php echo $kol['numas'];?> </td>
				<td class='event'> <?php echo $kol['numevc'];?> </td>
				<td class='event'> <?php echo $kol['numspc'];?> </td>
				<td class='event'> <?php echo $kol['numocc'];?> </td>
				<td class="editorial"> <?php echo $kol['numeb'];?> </td>
				<td class="expert"> <?php echo $kol['numec'];?> </td>
				<td class="pub"> <?php echo $kol['nump'];?> </td>
				<td class="pub"> <?php echo $kol['leadc'];?> </td>
				<td class="pub"> <?php echo $kol['numma'];?> </td>
				<td class="pub"> <?php echo $kol['numsa'];?> </td>
				<td class="pub"> <?php echo $kol['numfa'];?> </td>
				<td class="pub"> <?php echo $kol['numla'];?> </td>
				<td class="trial"> <?php echo '0';?> </td>
				<td> <?php echo $kol['numgc'];?> </td>
				<td> <?php echo $kol['score'];?> </td>
			</tr>
		<?php $i++;}?>
	</tbody>
</table>