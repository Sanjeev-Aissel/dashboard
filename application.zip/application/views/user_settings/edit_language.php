<script type="text/javascript">
	function updatePasswordData(){
			var newPswd = $("#newPswd").val();
			var cnfPswd = $("#cnfPswd").val();
			if(newPswd == cnfPswd && (newPswd.length || cnfPswd.length) >= 6 && (newPswd || cnfPswd) !=''){
				alert("yes");
			}else{
				alert("no");
			}
		}

	function changeLanguage(){
		var langVal = $('#lang').val();
		if(langVal!=''){	
			$('#language').submit();
		}
	}
</script>
<div class="topHeader">
	<div class="headerTitle">
		<div class="titleOfPage"><h3>Language Settings</h3></div>
	</div>
</div>
<div>
<!--	<form id="passwordEditedData" action="" method="post">-->
		<table class="userDetails" style="width:50% !important;">
			<tr>
				<th>Choose Language :</th>
				<td>
					<div id="languageBar">
						<form action="<?php echo base_url()?>user_settings/change_language" method="post" id="language">
							<select onchange="changeLanguage()" name="language" id="lang">
								<option value="english" selected="selected" >English</option>
							<?php /*	<option value="korea" <?php if(isset($this->session->userdata['lang'])){if($this->session->userdata['lang']=='korea'){?> selected="selected" <?php }}?>>Korean</option>
								<option value="chinese" <?php if(isset($this->session->userdata['lang'])){if($this->session->userdata['lang']=='chinese'){?> selected="selected" <?php }}?>>Chinese</option>
							*/?>
							</select>
						</form>
					</div>
				</td>
			</tr>
		</table>
<!--	</form>-->
	<table class="userDetails">
		<tr>
			<td colspan="2">
				<div id="submitBtn" style="margin-left: 167px; margin-top: 15px;">
<!--					<input type="button" onclick="updatePasswordData();"  value="Save">-->
				</div>
			</td>
		</tr>
	</table>
</div>