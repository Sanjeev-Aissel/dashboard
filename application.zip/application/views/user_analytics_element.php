<?php 
$i = 1;
if($startFrom > 0)
$i = $startFrom+1;
foreach($arrUserAnalytics as $row){?>
	<tr id='<?php echo $i;?>' class="analytics-row <?php if ($row['is_login_failed'] == 1) echo "loginFailed";?>">
		<td class="leftAlign">
			<?php 
				if ($row['is_login_failed'] == 1 && $row['username'] != '')
					echo $row['username'];
				else
					echo $row['user_name'];	
			
			?>
		</td>
		<td class="leftAlign">
			<?php 
				if ($row['name'] == '')
					echo "--------------------";
				else
					echo $row['name'];	
			?>
		</td>
		<td><?php echo $row['login_time']?></td>
		<td><?php if($row['logout_time']==null)echo "--------------------"; else echo $row['logout_time']?></td>
	</tr>
<?php $i++;}?>