<script>
var base_url = "<?php echo base_url(); ?>";
var product = "<?php echo lang("Overview.Product");?>";
</script>
<?php
		$queued_js_scripts =array('i18n/grid.locale-en','jquery.jqGrid.min','jquery/jquery.validate1.9.min',
							'jquery/jquery-ui-1.8.16.datepicket',
							'chosen.jquery',
//							'reports/view_interaction_reports'
							'reports/interaction_filters',
							'highcharts2_2_2/highcharts3.0.5',
							'highcharts2_2_2/modules/exporting3.0.5'
							);
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
	<!-- Load c3.css -->
<link href="<?php echo base_url();?>c3js/c3.css" rel="stylesheet" type="text/css">

<!-- Load d3.js and c3.js -->
<script src="<?php echo base_url();?>c3js/d3.v3.min.js" charset="utf-8"></script>
<script src="<?php echo base_url();?>c3js/c3.min.js"></script>
<?php
if($layout_type){
echo '<script src="'.base_url().'js/jquery.autocomplete.js"></script>';
}?>   
<!--<script language="javascript" type="text/javascript" src="<?php echo base_url()?>js/chosen.jquery.js"></script>-->
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/refinedByFilter.css" />
<style type="text/css">
/*	#totalOrganizationChart{
		margin-left: 160px;	
	}	
	#pubsChart {
		width: 580px;
	}
	#meshTermsChart {
		width: 400px;
	}
	#substancesChart{
		width: 500px;
	}
	#pubJournalsChart{
		width: 600px;
	}

	#kolsByCountryChart{
		margin-left: -5px !important;
	}
	
	#kolsBySpecialtyChart{
		margin-left: -5px !important;
	}
*/
	#kolsByEventTypeChart {
	     margin: auto;
	}
	#kolsPubChart{
	/*	margin-left: 280px !important; 
		position: absolute;
		min-height: 420px;
    	min-width: 580px;*/
	}
	
	#kolsActivitiesChart{
	/*	margin-left:265px; 
		position: absolute;*/
		min-width: 600px;
		min-height: 420px;
	}
	#kolsActivitiesChart .highcharts-container{
		margin:auto;
	}
	#gbox_listKolsByActivityReportResultSet{
		margin:auto;
	}
	#eventsByTimeline{
	/*	position: absolute !important;*/
		min-width: 700px;
		min-height: 420px;
	}
	#eventsByTimeline .highcharts-container{
		margin: auto;
	} 
	 
	.pieCharts div{
		margin: auto;
	}
	
	#contents{
		text-align:center;
	}
	
	#eventsByActivityContainer fieldset {
		width:98%;
		padding:2px;
	/*	margin-left:360px; */ 
	}
	
	#eventsByActivityContainer fieldset legend{
		margin: 0 46%;
	}
	#searchLeftBar{
		display: inline;
		float: left;
	}
	
	#timeLineSliderContainer{
		display: block;
		padding-top: 25px;
	}
	
	#kolId{
		width:150px;
	}
	/*
	#scatTable{
		width:auto;
	}*/
	.span-4 {
		width:170px;
	}
	#searchFiltersElements ul{
		padding-left: 1px;
		margin-right: 0px;
		padding-left: 5px;
	}
	#searchFiltersElements ul li{
		font-size: 12px;
		list-style: none;
		color:#000000;
		font-style: normal;
		font-family: inherit;
	}
	
	#searchLeftBar li.category{
		border-top:1px dotted #999999;
		overflow:visible;
		position:relative;
	/*	margin-right: 10px;*/
	}
	
	#searchLeftBar li#categoryCountry{
		border-top:0px dotted #999999;
		margin-top:0;
		padding-top:0;
	}
	
	#searchLeftBar label.facet-toggle {
		background:transparent url("<?php echo base_url();?>images/sprite_facetsearch_v7.png") no-repeat scroll 0 -61px;
		cursor:pointer;
		display:block;
		font-size:85%;
		height:11px;
		position:absolute;
		right:0;
		text-indent:-99999px;
		top:10px !important;
		width:11px;
	}
	
	#searchLeftBar label.facet-toggle:hover {
		background-position: 0px -76px;
	}
	
	#searchLeftBar label.collapsed{
		background-position:-20px -61px;
	}
	
	#searchFiltersElements ul li.allIndicator{
		font-weight: bold;
	}
	
	#searchFiltersElements ul li.allIndicator label{
		padding-left:4px;
		font-weight: bold;
	}
	
	#searchFiltersElements  input[type="checkbox"] {
		margin-left: -18px;
	}
	#categoriesContainer ul li label{
		margin-left: -6px;
		font-family:inherit;
		font-size:11px;
		font-style:normal;
		font-weight: normal;
	}
	#resetBttnContainer{
		text-align: right;
		vertical-align: middle;
		font-style: normal;
		color: #000099;
	}
	.highcharts-axis text{
		fill:#000000 !important;
		color:#000000;
	}
	
	th.ui-th-column div{
        white-space:normal !important;
        height:auto !important;
        padding:1px;
    }
    #lui_kolsProfileScore{
    	width:0;
    }
/*    #profileScoreGridContainer{
    	margin-left:133px;
    	width:800px;
    }

    .gridWrapper{
    	overflow: scroll !important;
    }
  */
    .myclass td{
    	color:blue !important;
    }
    
	 .professionalExp1{
	 	color:#2222BB;
	 }
	 .researchColumn1{
	 	color:#DD2222;
	 }
	 
	 .eventsColumn1{
	 	color:brown;
	 }
	
	 #profileScoreGridContainer label.facet-toggle {
	    background: url("<?php echo base_url()?>images/kolm-sprite-image.png") no-repeat scroll -8px -91px transparent;
	}
	 #profileScoreGridContainer label.collapsed {
	    background-position: -28px -91px;
	}
	
	 #profileScoreGridContainer label.facet-toggle {
	    cursor: pointer;
	    display: block;
	    font-size: 85%;
	    height: 11px;
	    position: relative;
	    right: 0;
	    text-indent: -99999px;
	    top: 14px;
	    width: 11px;
	    margin-left: 19px;
	}
	#profileScoreGridContainer label{
		font-weight:normal;
	}
	
/*	#eventsByActivityContainer #gridContainer{
		overflow: auto !important;
	}
*/ 
	#refinedByContainer{
		border:0px;
	}
	#kolsActivitiesChart, #gridContainer{
		width: 850px !important;
	}
	.title-bar-actions{
		float:right;
		margin-right: 19px;
		margin-top: -6px;
	}
	.title-bar-actions .sprite_iconSet{
		float:right;
		margin-left: 0;
	}
	#searchFiltersElements ul li.search-field{
		padding-bottom: 0px;
	    padding-left: 10px;
	    padding-top: 0px;
	}
	#categoriesContainer .category{
		padding: 0 5px 0 15px;
	}
	#categoriesContainer table{
		margin-bottom: 0 !important;
	}
	.chzn-container-multi .chzn-choices .search-field input{
		color: #444444 !important;
	}
	#interactionsByChannel{
	    height:100%;
	    width:100%;
	    text-align: center;
	}
</style>
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
<style>
/*    Enable Verticle separator between content and side menu list  By Laxman   */
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
	.refinedBySideBar{
		position: absolute; 
		right: 0px;
		z-index: 100;
	}
	#chartType{
		margin:0px;
	}
	#chartType_chzn{
		vertical-align: top;
	}
	.ui-state-default.ui-th-column-header.ui-th-ltr{
		text-align: center;
	}
	table.ui-jqgrid-btable tr.jqgfirstrow td { border: none; }
	table.ui-jqgrid-btable { height: 1px; }
	#refineGridContainer{
		margin-top: 30px;
	}
	
	.tabsWrapper ul.tabsContainer{
		list-style: none;
		border-bottom: 1px solid #D0CCC9;
	    line-height: 21px;
	    margin: 0px;
	}
	.tabsWrapper ul.tabsContainer li{
		display: inline;
		background-color: #ECECEC;
		border:1px solid #D0CCC9;
		border-bottom-color: #ececec;
		padding: 2px 5px;
	}
	.tabsWrapper ul.tabsContainer li.current{
		border-bottom: 2px solid #fff;
		background-color: #fff;
	}
	.tabsWrapper ul.tabsContainer li.current a{
		color:#333333;
	}
	.tabsWrapper ul.tabsContainer li a{
		text-decoration: none;
		padding: 0 5px;
		font-weight: bold;
		color: #333333;
	}
	.tabsWrapper div.tabsContent{
		border: 1px solid #D0CCC9;
		padding:5px;
		border-top: 0px;
	}
	.tabsWrapper .tabsContent div.tabContent{
		display: none;
	}
	.tabContent{
		display: block;
		text-align: center;
		overflow: hidden;
	}
	<?php if(IS_IPAD_REQUEST == 1){ ?>
		.tabsContainer li{
			font-size: 12px;
		}
		#chartTitleContainer{
			font-size: 12px;
		}
	<?php }?>
</style>
<?php 
	$fromDate = date("Y-m-d", strtotime("-3 months"));
	$toDate = date("Y-m-d");
//	echo $fromDate." - ".$toDate;
?>
<script type="text/javascript">
$(document).ready(function(){
	$("#chartType").chosen({disable_search_threshold: 10});
});

var currentChartId = "list";
$(document).ready(function(){
//	alert("dd");
//	listInteractions();
//	$("#fromDate").val("<?php echo $fromDate?>");
//	$("#toDate").val("<?php echo $toDate?>");
//	doSearchFilter1();
//	listInteractions(); 
	$("#list").click(function(){
		currentChartId = "list";
		$("#numericReportContainer").css("display","none");
		$("#pageChartContainer").css("display","none");
		$("#calenderContent").css("display","none");
		$('#gridTabContainer').css("display","block");
	
		$("#gridContainer").html("");
		// Append the required div and table
		$("#gridContainer").html('<div id="listInteractionsPage"></div><table id="listInteractionsResultSet"></table>');
		doSearchFilter1(-1);
	});
	
	$("#report").click(function(){
		currentChartId = "report";
		$("#numericReportContainer").css("display","block");
		$("#pageChartContainer").css("display","none");
		$("#calenderContent").css("display","none");
		$('#gridTabContainer').css("display","none");
		doSearchFilter1(-1);
	});
	
	/*
	$("#chart").click(function(){
		currentChartId = "chart";
		$("#numericReportContainer").css("display","none");
		$("#calenderContent").css("display","none");
		$("#pageChartContainer").css("display","block");
		$('#gridTabContainer').css("display","none");
		generateChartReport();
	});
    */      
	$('.tabsWrapper ul.tabsContainer li').click(function (){
		var currentTab	= $(this).attr('name');
		$('.tabsWrapper ul.tabsContainer li').removeClass('current');
		$('.tabsWrapper .tabsContent div.tabContent').hide();
		$(this).addClass('current');
		$('.tabsWrapper .tabsContent div.'+currentTab).show();
	});
	
	
});
var is_ipad_request = '<?php echo IS_IPAD_REQUEST;?>';
var ipad_base_url = '<?php echo base_url().IPAD_URL_SEGMENT;?>/';
</script>
<?php if(IS_IPAD_REQUEST == 1){ ?>
	<div style="margin-bottom: 10px;">
		<!-- <a class="btn btn-default" href="<?php echo base_url().IPAD_URL_SEGMENT;?>/reports/list_all_ireports" >Back</a> -->
	</div>
	<style>
	   .ui-datepicker{
	       left: 750px !important;
	   }
	</style>
<?php }?>
<div id="container">
	<div id="chartSelect">
		<label>Type</label>
		<select name="chart_type" id="chartType" onchange="doSearchFilter1()" style="width: 250px;">
			<option value="" >Events/Interactions Summary</option>
			<option value="1" >Monthly By Interaction Type</option>
			<option value="2" >Monthly By <?php echo lang('Overview.Product');?></option>
			<option value="3" >Monthly By Category</option>
			<option value="4" >Monthly By Discussion Type</option>
			<option value="5" >Monthly By Topic</option>
			<!--<option value="6" >Monthly By Sub Topic</option>-->
<!--			<option value="4" >Monthly By Product</option>-->
<!--			<option value="5" >Monthly By Type</option>-->
<!--			<option value="6" >Monthly By Topics</option>-->
<!--			<option value="7" >Monthly By Sub Topics</option>-->
		</select>
	</div>
	</br>
	<div class="tabsWrapper" id="test">
		<ul class="tabsContainer">
			<li class="current" name="tab0"><a id="list" href="#">Report</a></li>
			<li name="tab1"><a id="report" href="#">Chart</a></li>
		</ul>
		<div class="tabsContent">
			<div class="tab0 tabContent" style="display:block;">
				<div id="gridTabContainer" style="margin-top: 20px;">
					<div class="gridWrapper" id="gridContainer">
						<div id="listInteractionsPage"></div>
						<table id="listInteractionsResultSet" class="gridWidth">Please select filter for report</table>
					</div>
					<div class="gridWrapper" id="refineGridContainer"></div>
				</div>
			</div>
			<div class="tab1 tabContent" style="display:none;">
				<div id="chartsContainer">
					<table id="dashboardTable" class="tableSections">
						<tr class="tableHeader">
							<th id="chartTitleContainer"></th>
						</tr>
						<tr>
							<td>
						<div class="pieCharts">
							<div id="kolsByCountryChartLoaderContainer">
								<div id="interactionsByChannel" class="gridWidth"></div>
							</div>
						</div>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<form action="<?php echo base_url()?>reports/list_interactions/1" method="post" id="exportInteractionDetails">
	<input type="hidden" value="" name="exportIds" id="exportIds"></input>
	<input type="hidden" value="interactions" name="export_method" id="export_method"></input>
	<input type="hidden" value="" name="filters" id="filters"></input>
	<input type="hidden" value="" name="type" id="type">
	<div id="hiddenElements">
		
	</div>
</form>

<form action="<?php echo base_url()?>reports/list_interactions" method="post" id="excel_export_by_different_categories">
	<input type="hidden" value="interactions_by_category" name="export_method" id="export_method"></input>
	<input type="hidden" value="" name="interexportIds" id="interexportIds"></input>
	<input type="hidden" value="" name="interfilters" id="interfilters"></input>
	<input type="hidden" value="true" name="isExport" id="isExport"></input>
	<input type="hidden" value="" name="type" id="type">
	<div id="hiddenElementsCategory">
		
	</div>
</form>