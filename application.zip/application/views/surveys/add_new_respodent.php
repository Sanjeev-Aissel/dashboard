<style>
	.form_container{
		margin-right: 50px;
    	text-align: center;
	}
	.form_container .each_field input:not([type='button']),select{
		width: 200px;
	}
	.form_container .each_field string{
		color: red;
	}
	.form_container .each_field textarea{
		width: 190px;
	}
	.form_container .each_field label {
		width : 112px;
		display: inline-block;
		text-align: right !important;
		vertical-align: top;
	}
	.form_container .each_field{
		margin: 2px;
	}
	.form_label{
		margin-bottom: 20px; 
		font-weight: bold;
		color: #333333;
	}
	.form_label label{
		font-size: 11px;
		font-weight: bold;
	}
	#similar_names table tr th{
		padding: 2px 0 2px 4px;
		color: #333333;
    	font-size: 12px;
	}
	#similar_names table tr td {
		padding: 2px 0 2px 4px;
		color: #333333;
    	font-size: 12px;
	}
	#similar_names table tr:hover{
		background-color: #d3dfed;
	}
	#similar_names .button_section{
		margin-top: 12px;
    	text-align: center;
	}
</style>
<?php 
	$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter1(-1);}";
	$autoSearchOptions1 = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 2,onSelect : function(event, ui) {doSearchFilter1(-1);}";
?>
<script>
	
var stateNameAutoCompleteOptions = {
	serviceUrl: '<?php echo base_url();?>country_helpers/get_state_names_by_country_id',
	<?php echo $autoSearchOptions1;?>,
	onSelect : function(event, ui) {
		var stateId = $(event).children('.autocompleteStateId').html();
		var selText = $(event).children('.stateName').attr('name');
		selText=selText.replace(/\&amp;/g,'&');
		$('#state').val(selText);
		$('#stateIdForAutocomplete').val(stateId);
	}
};

var cityNameAutoCompleteOptions = {
	serviceUrl: '<?php echo base_url();?>country_helpers/get_city_names_by_state_id_and_country_id',
	<?php echo $autoSearchOptions;?>,
	onSelect : function(event, ui) {
		var cityId = $(event).children('.autocompleteCityId').html();
		var selText = $(event).children('.cityName').attr('name');
		selText=selText.replace(/\&amp;/g,'&');
		$('#city').val(selText);
		$('#cityIdForAutocomplete').val(cityId);
	}
};

$(document).ready(function (){
	if(whichOne){
		$(".form_label").text("Add Missing Respodent");
	}else{
		$(".form_label").text("Add Missing Influencer");
	}
		
	$('#state').autocomplete(stateNameAutoCompleteOptions);
	$('#city').autocomplete(cityNameAutoCompleteOptions);
	
	$("#state").focus(function (){
		country_name = $("#country_id").val();
	});
	
	$("#state").keyup(function (){
		$("#city").val("");
		$("#cityIdForAutocomplete").val("");
	});
	
	$("#city").focus(function (){
		country_name = $("#country_id").val();
		state_name = $("#stateIdForAutocomplete").val();
	}); 

	$("#organization").keyup(function(){
		$('#organization').autocomplete(organizationNameAutoCompleteOptions);
	});
		
	// Autocomplet Options for the 'Organizer' field 
	var organizationNameAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>kols/get_organization_names',
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
				var selText = $(event).children('.organizations').html();
				var selId = $(event).children('.organizations').attr('name');
				selText=selText.replace(/\&amp;/g,'&');
				$('#organization').val(selText);
				$('#organizationId').val(selId);
				if(event.length>20){
					if(event.substring(0,21)=="No results found for "){
						return false;
					}
				}
				$(".autocomplete").hide();
			}
	};	

	$("#specialty").keyup(function(){
		$('#specialty').autocomplete(SpecialtyNameAutoCompleteOptions);
	});
		
		
	// Autocomplet Options for the 'role' field 
	var SpecialtyNameAutoCompleteOptions = {
		serviceUrl: '<?php echo base_url();?>surveys/get_all_specialty_for_autocomplete',
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
					var selText = $(event).children('.specialties').html();
					var selId = $(event).children('.specialties').attr('name');
					selText=selText.replace(/\&amp;/g,'&');
					$('#specialty').val(selText);
					$('#specialtyId').val(selId);
					if(event.length>20){
					if(event.substring(0,21)=="No results found for "){
						return false;
					}
				}
				$(".autocomplete").hide();
			}
		};	
});

function resetStateCity(){
	$("#city").val("");
	$("#cityIdForAutocomplete").val("");
	$("#state").val("");
	$("#stateIdForAutocomplete").val("");
}

function closeDialog(){
	$("#addNewKol").dialog('option','width',550);
	$("#addNewKol").dialog('option','position',['center', 80]);
	$("#addNewKol").dialog("close");
}

function save_missing_contact(appendId){
	var first_name = $("#first_name").val();
	var middle_name = $("#middle_name").val();
	var last_name = $("#last_name").val();
	var country = $("#country_id option:selected").text();
	var state = $("#state").val();
	var city = $("#city").val();
	var postal_code = $("#postal_code").val();
	//var npi = $("#npi").val();
	var organization = $("#organization").val();
	var speciality = $("#specialty").val();

	if(first_name == '' || last_name == '' || state == '' || city == ''){
		$("#msg").text('Please fill all mandatory fields');
		$("#msg").css('color','red');
		$("#msg").show();
	}
	else
	{
		var dataString = 'first_name='+ first_name + '&middle_name='+middle_name + '&last_name='+last_name + '&country='+country + '&state='+state + '&city='+city + '&postal_code='+postal_code + '&organization='+organization + '&speciality='+speciality;
		$.ajax({
			type: "POST",
			url: "<?php echo base_url();?>/surveys/save_missing_contact",
			data: dataString,
			cache: false,
			success: function(result){
				result = JSON.parse(result);
				if(result.status == 'success'){
					if(appendId){
						var getQuestionId = appendId.split(/\s*\-\s*/g);
						var questionId = getQuestionId[1];
						var html = '';
						html += '<div>';
						html += '<div class="influencerDetails"><label>Name:</label> <span>'+result.formattedName+'</span></div>';
						html += '<div class="influencerDetails"><label>City:</label> <span>'+result.city+'</span></div>';
						html += '<div class="influencerDetails"><label>State:</label> <span>'+result.state+'</span></div>';
						html += '<div class="influencerDetails"><label>Country:</label> <span>'+result.country+'</span></div>';
						html += '<div class="influencerDetails"><label>Postal Code:</label> <span>'+result.postal_code+'</span></div>';
						html += '<div class="influencerDetails" style="width: 5%;"><div onclick="deleteRow(this);" class="actionIcon deleteIcon" alt="Delete" title="Delete"></div></div>';
						html += '</div>';
						$("#"+appendId).find(".answers").append(html);
						$("#msg").text('Influencer added successfully');
					}else{
						$('#respondentName').val(result.formattedName);
						$('#respCity').text(result.city);
						$('#respState').text(result.state);
						$('#respCountry').text(result.country);
						$('#respPostalCode').text(result.postal_code);
						$("#showHiderespondentDetails").show();
						$("#msg").text('Respodent added successfully');
					}
					
					$("#msg").css('color','green');
					$("#msg").show();
					setTimeout(function(){ closeDialog(); }, 2000);
				}else{
					$("#msg").text('Unable to add respodent. Please try again later');
					$("#msg").css('color','red');
					$("#msg").show();
					setTimeout(function(){ closeDialog(); }, 2000);
				}
				
			}
		});
	}
	
}

</script>
<form id="stagingIcontact" method="post" >
	<div class="form_label">
		<label>Add Missing Respodent</label>
	</div>
	<div class="msgBox"></div>
	<div class="form_container">
		<div class="each_field">
			<label>First name<string>*</string> : </label>
			<input type="text" name="first_name" id="first_name"></input>	
		</div>
		<div class="each_field">
			<label>Middle name : </label>
			<input type="text" name="middle_name" id="middle_name"></input>	
		</div>
		<div class="each_field">
			<label>Last name<string>*</string> : </label>
			<input type="text" name="last_name" id="last_name" ></input>	
		</div>
		<div class="each_field">
			<label>Country : </label>
			<select name="country" id="country_id"  onchange="resetStateCity();">
				<option value="">-- Select --</option>
					<?php foreach( $arrCountry as $country ){ ?>
					<option value="<?php echo $country['country_id'];?>" <?php if($country['country_id']==254){?> selected="selected" <?php }?>>
					<?php echo $country['country_name'];?>
					</option>
					<?php }?>
			</select>
		</div>
		<div class="each_field">
			<label>State<string>*</string> : </label>
			<input type="text" name="state" class="autocompleteInputBox" id="state" value="" title=""/>
			<input type="hidden" id="stateIdForAutocomplete" value='' name="state_id">
		</div>
		<div class="each_field">
			<label>City<string>*</string> : </label>
			<input type="text" name="city" class="autocompleteInputBox" id="city" value="" title=""/>
			<input type="hidden" id="cityIdForAutocomplete" value='' name="city_id">
		</div>
		<div class="each_field">
			<label>Postal code : </label>
			<input type="text" name="postal_code" id="postal_code"></input>	
		</div>
		<!-- <div class="each_field">
			<label>NPI Number : </label>
			<input type="text" name="npi" id="npi"></input>		
		</div> -->
		<div class="each_field">
			<label>Organization : </label>
			<input type="text" name="organization" class="autocompleteInputBox" id="organization"></input>	
		</div>
		<div class="each_field">
			<label>Specialty : </label>
			<input type="text" name="specialty" class="autocompleteInputBox" id="specialty"></input>	
		</div>
		<div class="each_field"  style="text-align: center; padding-left: 114px;">
			<input type="button" value="Save" onclick="save_missing_contact('<?php if($appendId){echo $appendId;}?>');" ></input>
			<p id="msg" style="display:none;"></p>
		</div>
	</div>
</form>
<div id="similar_names"></div>