<?php
?>

<script>

	function importFiles(){
		$('#filesContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		$('#fileImport').submit();
		
	}

		
	function deleteFiles(){

		$('#filesContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		var arrFiles = new Array();
		var arrFolders  = new Array();

		$.each($('input[name="files[]"]:checked'),function(){
			arrFiles.push($(this).val());

			//$('#'+$(this).val()).remove();
		});

		$.each($('input[name="folders[]"]:checked'),function(){
			arrFolders.push($(this).val());
		});
		var data = {};
		data['files'] = arrFiles;
		data['folders'] = arrFolders;
		data['type'] = $('#type').val();
		$.ajax({
			url:'<?php echo base_url()?>organizations/delete_files',
			data:data,
			type:'post',
			success:function(){
				
				$.each($('input[name="folders[]"]:checked'),function(){
					$(this).parent().parent('tr').remove();
				});
				$.each($('input[name="files[]"]:checked'),function(){
				//arrFiles.push($(this).val());
					$(this).parent().parent('tr').remove();
				
				});
				$('#filesContainer').unblock();
			}

			});
		


	}

	function chkALL(obj){
		if($(obj).attr('checked')=='checked'){
			$.each($('input[name="files[]"]'),function(){
				$(this).attr('checked','checked');
			});

			$.each($('input[name="folders[]"]'),function(){
				$(this).attr('checked','checked');
			});
		}else{
			$.each($('input[name="files[]"]'),function(){
				$(this).removeAttr('checked');
			});

			$.each($('input[name="folders[]"]'),function(){
				$(this).removeAttr('checked');
			});
		}
	}

	function chkChlidFile(obj,classValue){
		if($(obj).attr('checked')=='checked'){
			$.each($('.'+classValue),function(){
				$(this).attr('checked','checked');
			});

			$.each($('.'+classValue),function(){
				$(this).attr('checked','checked');
			});
		}else{
			$.each($('.'+classValue),function(){
				$(this).removeAttr('checked');
			});

			$.each($('.'+classValue),function(){
				$(this).removeAttr('checked');
			});
		}

	}

	function showKolImportBox(){
		$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#exportKolsContainer").dialog("open");
		$("#exportKolsProfileContent").load('<?php echo base_url();?>kols/analyst_kol_import_page');
		
		return false;	
	}
	$(document).ready(function(){
		// Settings for the Dialog Box
		var modalBoxAddOpts = {
				title: "",
				modal: true,
				autoOpen: false,
				width: 600,
				dialogClass: "microView",
				position: ['center', 160],
				open: function() {
					//display correct dialog content
				}
		};
		$("#exportKolsContainer").dialog(modalBoxAddOpts);
	});

</script>
<div><b><?php if($type=='uni') {echo 'University/Hospitals';}else{echo $type;}?></b></div>
<div>
	<input type="checkbox" name="selectAll" onclick="chkALL(this)"></input><label>Select All</label>
</div>
<div id="filesContainer">
		<input type="hidden" id="type" value="<?php echo $type;?>"></input>
		<form action="<?php if($type=='uni'){echo base_url() ?>imports/read_and_import_org_files<?php }else{echo base_url() ?>imports/read_and_import_payer_files<?php }?>" method="post" id="fileImport">
			<table style="width:0%">
			
				<?php $i=0; foreach($arrProfiles as $folderName =>$fileName1){?>
					<div id="<?php echo $folderName?>"></div>
					<tr>
					<td><input type="checkbox" name="folders[]" value="<?php echo $folderName?>" id="" onclick="chkChlidFile(this,this.value)"></td>
						<td>
							<?php echo $folderName;?>
						</td>
						
					</tr>
					
					<?php foreach($fileName1 as $fileName){?>
					
					<tr id="">
						<td></td>
						<th>
							<input type="checkbox" name="files[]" value="<?php echo $folderName."&".$fileName;?>" id="<?php echo 'uh'.$i?>" class="<?php echo $folderName;?>">
						</th>
						<td>
							<label for="<?php echo 'uh'.$i?>"><?php echo $fileName;?></label>
						</td>
					</tr>
					</div>
				<?php $i++;}}?>
			</table>
			<input type="button" value="Import" onclick="importFiles()">
			<input type="button" value="Delete" onclick="deleteFiles();"></input>
		</form>
	</div>
	
		<div id="exportKolsDialog">	
		<div id="exportKolsContainer" class="microProfileDialogBox">
			<div class="profileContent" id="exportKolsProfileContent"></div>
		</div>
	</div>