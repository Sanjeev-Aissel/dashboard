<?php
/**
*File To Know Basics.
*Created By:
*Created On:7:57:04 PM
*/
?>
<script type="text/javascript">
	if(!js_files_loaded){
		<?php
				// prepare array of JS files to insert into queue
			$queued_js_scripts = array('search/kol_search_results','chosen.jquery');
			// add the JS files into queue i.e Append to the existing queue
			$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
			$viewType	= $this->uri->segment(3);
		?>
	}
</script>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet">
<style type="text/css">
	
	#searchResultsContainer {
		margin-top: 0px;
	}
	#checkAll {
		float: left;
		font-size:12px;
		width:81px;
	}
	#peopleAdvSearchFieldsContainer table.listResultSet {
		margin-top: 0px;
	}
	
	#peopleAdvSearchFieldsContainer table.listResultSet tr:hover{
		background-color: #d0e5f5;
		background-color: #D3DFED;
	}
	#peopleAdvSearchFieldsContainer tr.searchPagination:hover{
		background-color: white;
	}
	#peopleAdvSearchFieldsContainer tr.selectedRow{
		background:#d8dfea repeat-x scroll 50% 50% !important;
	}
	#peopleAdvSearchFieldsContainer .loadingIndicator {
		background-image: url("../images/ajax-loader-round.gif");
		background-position:center;
		background-repeat:no-repeat;
		position:absolute;
		top:250px;
		left:550px;
		height: 75px;
		width: 75px;
	}
	.blockUI .blockMsg .blockPage {
		border: 0px;
	}
	
	#searchResultsContainer .searchResultsMsg {
		padding-right:0px;
		margin-right: 0px;
		padding-bottom:5px;
		border:1px solid #BBBBBB;
		border-left:0px;
		border-right:0px;
	}
	.progress .bar {
	    -moz-box-shadow: 0 -1px 0 rgba(0, 0, 0, 0.15) inset;
	    -moz-box-sizing: border-box;
	    background-color: #0E90D2;
	   /* background-image: -moz-linear-gradient(center top , #149BDF, #0480BE); */
	    background-image: -moz-linear-gradient(right top , #149BDF, #0B5CB0);
	    background-repeat: repeat-x;
	    color: #FFFFFF;
	    font-size: 12px;
	    height: 10px;
	    text-align: center;
	    text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25);
	    width: 0;
	}
	.progress {
	    -moz-border-radius: 0px;
	    -webkit-border-radius: 0px;
	    border-radius: 0px;
	    -moz-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1) inset;
	    background-color: #F7F7F7;
	    background-image: -moz-linear-gradient(center top , #F5F5F5, #F9F9F9);
	    background-repeat: repeat-x;
	    height: 10px;
	   /* margin-bottom: 18px;*/
	    overflow: hidden;
	}
	table.listResultSet td {
		vertical-align: middle !important;
		font-size: 11px !important;
	}
	#searchResultsContainer .searchResultsMsg #resFor{
		margin-top: 2px;
	}
	.exportOptions{
		display: none;
	}
	
	#profileType_chzn{
		font-size: 12px;
		width: 109px; 
		/*margin-left: 8px;*/ 
		margin-top: 1px;
	}
	#profileType_chzn a.chzn-single{
		height: 18px;
		line-height: 18px;
	}
	.chzn-container-single .chzn-single div{
		top: -3px !important;
	}
/*	.chzn-container .chzn-results li{
		padding: 3px 4px !important;
		line-height: 12px !important;
	}
*/
	.chzn-drop{
		min-width: 106px !important;
	}
	#addFilters1{
		display: inline;
		cursor: pointer;
		background: url("<?php echo base_url()?>images/save_active.png") no-repeat scroll 0 0 / 15px auto;
		padding-right: 16px;
	}
	#addFilters:HOVER #addFilters1{
		display: inline;
		cursor: pointer;
		background: url("<?php echo base_url()?>images/save_inactive.png") no-repeat scroll 0 0 / 15px auto;
		padding-right: 16px;
	}
</style>
	
	<script type="text/javascript">
/*	
		checked=false;
		function checkedAll (thisEle) {
			if($(thisEle).attr("checked")==true){
				$.each($('input[name="list[]"]'),function(){
					$('input[name="list[]"]').attr("checked","checked");
				});
			}else{
					$.each($('input[name="list[]"]'),function(){
					$('input[name="list[]"]').removeAttr("checked");
				});
			}
	      }
	
		function displayModelBox(){
			var values = new Array();
			if(allPageSelected == false){				
				$.each($("input[name='list[]']:checked"), function() {
				  values.push($(this).val());				 
				});
			}
			else
				values=allPageKolIds;
			if(values==''){
				jAlert("Please select atleast one KOL");
			}else{
				$("#categoryModalBox .profileContent").html("<div class='microViewLoading'>Loading...</div>");
				$("#categoryModalBox").dialog("open");
				$(".addListContent").load('<?php echo base_url()?>my_list_kols/add_list/'+values);
			}
			return false;	
		}
	
	
		$(document).ready(function(){
			  var keyword=$('#keywords').val();
		       if(keyword!='')
		    	   $('#categotyKols').hide();
	    	   
		// Added by laxman for IE6 to change background color of tr on mouse over	
				$('table.listResultSet tr').hover (function () {
				  $(this).addClass ("rowhover");
				}, function () {
				  $(this).removeClass ("rowhover");
				});
		//   End 
			
			var categoryAddOpts = {
					title: "Add Payment",
					modal: true,
					autoOpen: false,
					width: 500,
					draggable:false,
					dialogClass: "microView",
					position: ['center', modalBoxTopPosition],
					open: function() {
						//display correct dialog content
					}
			};
			$("#categoryModalBox").dialog(categoryAddOpts);
		
			$('table.listResultSet tr').click(function(){
				$('table.listResultSet tr').each(function(){
					if($(this).hasClass('selectedRow')){
						$(this).removeClass('selectedRow');
					}
				});
				$(this).addClass('selectedRow');
			});
		});
		*/
		$(document).ready(function(){

	 	 	<?php if(isset($profileType) && $profileType != ''){ ?>
					var profileType = "<?php echo $profileType;?>";
					$("#profileType option[value='"+profileType+"']").attr("selected","selected");
					$("#profileType").trigger('liszt:updated');
//					$("#profTypeText").html($("#profileType option[value='"+profileType+"']").text());
			<?php }
				if($kolsCount==0) 
					$msgText = "No KTLs found";
				else{
					$msgText = "<div id='countMsg'>".$msg['countMsg']." </div>";
				}
			?>
				var msgText = "<?php echo $msgText;?>";
				$("#countAdvKolMsg").html(msgText);
			
		});
	</script>
		<script type="text/javascript">
			var arrSearchInputs	= new Array;
			var searchType	= '<?php echo $searchType;?>';
		</script>
		<input type="hidden" name="kols_count" id="kolsCount" value="<?php echo $kolsCount;?>" />
		<form id="list" class="clear">
			<table class="listResultSet">
				<thead>
					<tr class="tableInfo">
						<th>
							<input type='checkbox' name='checkall' onclick='checkedAll(this);' />
						</th>
						<th colspan="<?php echo ($viewType=='list')?'7':'4';?>">
							<label style="line-height: 27px;vertical-align: top;float: left;"><?php echo lang("Mykols.SelectAll");?></label>
							<div id="filtersApplied" class="tooltip-demo tooltop-bottom" style="float: left;">
								<span class="filterSections"><strong><?php echo (($kolsCount==0)?'No KTLs found':'Results');?> with <a href="#" onclick="return false;" rel="tooltip" data-original-title="<?php echo str_replace('Search results for ','',$msg['resFor']);?>">Search</a></strong></span>
							<?php // pr($msg['resFor']);
								if(!empty($filtersApplied)){
//                                                                    pr($filtersApplied);
									echo '<span class="filterSections"><strong> and Refined By:</strong> <label id="profTypeText" style="font-weight: normal !important;">&nbsp;</label> '.$filtersApplied.'</span> | ';
									echo '<div id="resetBttnContainer"><a href="#" onclick="resetFilters();">Reset Filters</a><label class="tooltip-demo tooltop-bottom" id="resetBttn" onclick="resetFilters();"><a href="#" class="tooltipLink" rel="tooltip" title="Reset Filters">&nbsp;</a></label></div>';
									echo '<div id="addFilters" onclick="addFilters();" style="display: inline;color: #000099;"><a href="#" rel="tooltip" title="Save all active filter selections"><div id="addFilters1" ></div></a>&nbsp;<a href="#">Save Filters</a></div>&nbsp;&nbsp;';
								}else if(!empty($savedQueryFilterApplied)){
									echo '<span class="filterSections"><strong> and Refined By:</strong> <label id="profTypeText" style="font-weight: normal !important;">&nbsp;</label> '.$savedQueryFilterApplied.'</span> | <div style="display: inline;color: #000099;">'.$savedFilterName.'</div>';
									echo '<div id="resetBttnContainer"><a href="#" onclick="resetFilters();">Reset Filters</a><label class="tooltip-demo tooltop-bottom" id="resetBttn" onclick="resetFilters();"><a href="#" class="tooltipLink" rel="tooltip" title="Reset Filters">&nbsp;</a></label></div>';
									echo '&nbsp;&nbsp;';
								}
							?>
							</div>
							<?php 
								if(!empty($filtersApplied)){
									echo '<div id="resetBttnContainer"><a href="#" onclick="resetFilters();">Reset Filters</a><label class="tooltip-demo tooltop-bottom" id="resetBttn" onclick="resetFilters();"><a href="#" class="tooltipLink" rel="tooltip" title="Reset Filters">&nbsp;</a></label></div>';
								}else if(!empty($savedQueryFilterApplied)){
									echo '<div id="resetBttnContainer"><a href="#" onclick="resetFilters();">Reset Filters</a><label class="tooltip-demo tooltop-bottom" id="resetBttn" onclick="resetFilters();"><a href="#" class="tooltipLink" rel="tooltip" title="Reset Filters">&nbsp;</a></label></div>';
									echo '&nbsp;&nbsp;';
								}
							?>
							<?php
//								echo '<label style="float:right;">'; 	
//								if($kolsCount>0){
//									echo "<div id='countMsg'>".$msg['countMsg']." </div>";
//								}
//								echo '</label>';
							?>
						</th>
					</tr>
				</thead>
				<tbody>
				<!-- Sart of loop trough each search result, and displaying as a row result -->
				
				<?php 
				$evenOrOddRow	= true;
				$kolDetails		= array();
				foreach($arrKols as $key=>$arrkolDetails){
					if($searchType=='advanced'){
						$kolDetails	= (isset($arrkolDetails[1])?$arrkolDetails[1]:$arrkolDetails);
					}else{
						$kolDetails	= $arrkolDetails;
					}
							
					if(!empty($kolDetails['id'])){
						if(!isset($kolDetails['gender'])){
							$kolDetails['gender']	= 'kolMicroViewIcon';
						}else if($kolDetails['gender']==''){
							$kolDetails['gender']	= 'kolMicroViewIcon';
						}
						if($evenOrOddRow){
							$evenOrOddRow	= false;
						}else{
							$evenOrOddRow	= true;
						}
				?>
						<tr id="kol<?php echo $kolDetails['id'];?>" class="<?php echo ($evenOrOddRow)?'evenRow':'oddRow';?>">
							<td width="3%">
								<input type="checkbox" name="list[]" value="<?php echo $kolDetails['id']?>" id="list"></input>					
							</td>
							<?php if(isset($kolDetails['profile_image']) && $kolDetails['profile_image'] != ''){?>
								<td width="5%">
									<div class="tooltip-demo tooltop-bottom">
										<a href="#" class="tooltipLink" rel='tooltip' title="Profile Snapshot">
											<img class="defaultProfileIcon"  onClick="viewKolMicroProfile('<?php echo $kolDetails['id'];?>',event); return false;"  width="40" src="<?php echo base_url().'images/kol_images/resized/'.$kolDetails['profile_image'].''?>" />
										</a>
									</div>
								</td>
							<?php }
							 else{ ?>
								<!--
									<td width="5%"><img class="micro_view_icon"  width="40" src="<?php echo base_url().'images/user_doctor.jpg'?>" /></td>
									<td width="5%"><div class="defaultProfileIcon"></div></td>	
								-->
									<td width="5%">
										<div class="tooltip-demo tooltop-bottom">
											<a href="#" class="tooltipLink" rel='tooltip' title="Profile Snapshot">
												<div  onClick="viewKolMicroProfile('<?php echo $kolDetails['id'];?>',event); return false;" class="defaultProfileIcon <?php echo $kolDetails['gender'];?>"></div>
											</a>
										</div>
									</td>
							 <?php }?>
							<td width="100%">
								<span class="record_name"><a href="<?php echo base_url();?>kols/view/<?php echo $kolDetails['unique_id'];?>" target="_NEW"><?php echo $arrSalutations[$kolDetails['salutation']].' '.$this->common_helpers->get_name_format($kolDetails['first_name'],$kolDetails['middle_name'],$kolDetails['last_name']);//echo $arrSalutations[$kolDetails['salutation']] . ' '; echo $kolDetails['first_name']." ".$kolDetails['middle_name']." ".$kolDetails['last_name']?></a></span>
								<?php echo "<br />"; ?>
								<?php if(isset($kolDetails['specs']))
										echo $kolDetails['specs'];
									 if(isset($kolDetails['specs']) && isset($kolDetails['country']))
									 	echo ', ';
								?>
								<?php if(isset($kolDetails['country']))
									echo $kolDetails['country'];
								if(isset($kolDetails['country']) && isset($kolDetails['name']))
									echo "<br />";
								?>
								<?php echo $kolDetails['name'];?>
								
							</td>
							<td>
								<?php /*
									if($searchType=='advanced'){
									//	echo "<br />".$kolDetails['relative_count']."% Match Found";
										//echo "<br />".round(($kolDetails['relative_count']*100)/$totalRelativeCount)."% Match Found";
										
								?>
								<div class="progress">
									<div class="bar tooltip-demo tooltop-top" style="width: <?php echo $kolDetails['relative_count'];?>%;"><a  onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="<?php echo $kolDetails['relative_count'];?>%">&nbsp;</a></div>
								</div>
								<?php } */ ?>
							</td>
							<!--<td width="1%"><label><div class="microViewIcon <?php echo $kolDetails['gender'];?>" onClick="viewKolMicroProfile('<?php echo $kolDetails['id'];?>',event); return false;"></div></label></td>
						--></tr>
					<?php
						} 
					}
					
					?>
						<tr class="searchPagination" style="background-color: white;">
							<td colspan="5">
								<select id="noOfRecordsPerPage" name="noOfRecordsPerPage" onchange="updateRecordsPerPage()">	
									<?php 
									/*	
										for($i=10;$i<151;$i+=10){
											if($i==$this->ajax_pagination->per_page){
												echo '<option value="'.$i.'" selected="selected">'.$i.'</option>';
											}else{
												echo '<option value="'.$i.'" >'.$i.'</option>';
											}
										}
									*/
										$arrPaginationValues	= explode(',',PAGINATION_VALUES);
										foreach($arrPaginationValues as $key =>$value){
											if($value==$this->ajax_pagination->per_page){
													echo '<option value="'.$value.'" selected="selected">'.$value.'</option>';
												}else{
													echo '<option value="'.$value.'" >'.$value.'</option>';
												}
										}	
										echo '</select> Records Per Page ';
									
										$config['first_link'] = 'First';
										$config['div'] = 'searchResultsContainer'; //Div tag id
										//$urlPrfix="filter_search_kols";
										$urlPrfix="filter_adv_search_kols1";
										//$config['base_url'] = base_url()."kols/".$urlPrfix;
										
										$config['total_rows'] = $kolsCount;
										$config['per_page'] = $this->ajax_pagination->per_page;
										$config['postVar'] = 'page';
										
										$this->ajax_pagination->initialize($config);
										print $this->ajax_pagination->create_links();
									?>				
							</td>
						</tr>
				</tbody>
			</table>
		</form>
		
		<div class="loadingIndicator" style="display: none;">
			
		</div>