<?php

/**
 * This is the 'Roles' Controller class  which controlles the all the request
 * comming for Role related activites.
 * 
 * @package application.controllers	
 * @author Vinayak B
 * @since  3.5.1
 * @created: 22-12-11
 */
Class Roles extends Controller{
	
	function Roles(){
		parent::Controller();	
		$this->load->model('role');
		$this->load->model('access_object');
		
	}
	
	/*
	 * To load View page that cintains List Of Roles
	 *  
	 * @author Vinayak
 	 * @since  3.5.1
 	 * @created  22-12-11
	 * 
	 */
	function list_roles(){
		$arrRoles = $this->role->listRoles();
		$data['arrRoles'] = $arrRoles;
		$data['contentPage'] = 'roles/list_roles';
		//Add Log activity
		$arrLogDetails = array(
				'type' => LIST_RECORD,
				'description' => "Visited List of User Roles Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View List of User Roles Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/analyst_view',$data);
	}
	
	/*
	 * To load View page that cintains Form to add Role
	 *  
	 * @author Vinayak
 	 * @since  3.5.1
 	 * @created  22-12-11
	 * 
	 */
	function add_role(){
		$data['arrRoles'] ='';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited Add User Role Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View Add User Role Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('roles/add_role',$data);
	}
	
	/*
	 * Passing Role details to Role model for saving
	 *  
	 * @author Vinayak
 	 * @since  3.5.1
 	 * @created  22-12-11
	 * 
	 */
	function save_role(){
		$arrRoles['role']=$this->input->post('role');
		if($lastInsertId = $this->role->saveRole($arrRoles)){
			//Add Log activity
			$formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Save Role',
					'status' => STATUS_SUCCESS,
					'transaction_id' => $lastInsertId,
					'transaction_table_id' => USER_ROLES,
					'transaction_name' => "Save Role",
					'form_data' => $formData,
					'parent_object_id' => $lastInsertId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
				$data['saved']			= true;
				$data['lastInsertId']	= $lastInsertId;
				$data['arrRoles']		= $arrRoles;
				$this->access_object->insertAccessPermissionsForRole($lastInsertId);
		}else{
			$data['saved']="sorry! Role Name is already present in database";
			//Add Log activity
			$formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => $data['saved'],
					'status' => STATUS_FAIL,
					'transaction_id' => $lastInsertId,
					'transaction_table_id' => USER_ROLES,
					'transaction_name' => "Save Role",
					'form_data' => $formData,
					'parent_object_id' => $lastInsertId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
			
		}
		echo json_encode($data);
	}
	
	/*
	 * Passing Role id to get Particular Role detail for editing
	 *  
	 * @author Vinayak
 	 * @since  3.5.1
 	 * @created  22-12-11
	 * 
	 */
	function edit_role($roleId){
		$arrRoles = $this->role->getRolebyId($roleId);
		$data['arrRoles']=$arrRoles;
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited Edit User Role Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View Edit User Role Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('roles/add_role',$data);
	}
	
	/*
	 * Passing Role details to Role model for Updating
	 *  
	 * @author Vinayak
 	 * @since  3.5.1
 	 * @created  22-12-11
	 */
	function update_role(){
		$arrRoles['id']=$this->input->post('id');
		$arrRoles['role']=$this->input->post('role');
		if( $this->role->updateRole($arrRoles)){
			//Add Log activity
			$formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => 'Update Role',
					'status' => STATUS_SUCCESS,
					'transaction_id' => $arrRoles['id'],
					'transaction_table_id' => USER_ROLES,
					'transaction_name' => "Update Role",
					'form_data' => $formData,
					'parent_object_id' => $arrRoles['id']
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
				$data['saved']			= true;
				$data['arrRoles']		= $arrRoles;
		}else{
			$data['saved']="sorry! Role Name is already present in database";
			//Add Log activity
			$formData = $_POST;
			$formData = json_encode($formData);
			$arrLogDetails = array(
					'type' => EDIT_RECORD,
					'description' => $data['saved'],
					'status' => STATUS_FAIL,
					'transaction_id' => $arrRoles['id'],
					'transaction_table_id' => USER_ROLES,
					'transaction_name' => "Update Role",
					'form_data' => $formData,
					'parent_object_id' => $arrRoles['id']
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null,true);
			
		}
		echo json_encode($data);
	}
	
	/*
	 * Passing Role Id to Role Model to delete Role
	 *  
	 * @author Vinayak
 	 * @since  3.5.1
 	 * @created  22-12-11
	 */
	function delete_role($roleId){
		if($this->role->deleteRole($roleId)){
			$data['deleted']=true;
		}else{
			$data['deleted']=false;
		}
		echo json_encode($data);
	}
}