	<style type="text/css">
	
	.userTable{
	  <?php if($userRoleId == ROLE_ADMIN){?>
		margin-left:240px;
	  <?php } else { ?>
                margin-left:40px;
          <?php } ?>
	}
        .formButtons{
              <?php if($userRoleId == ROLE_ADMIN){?>
                text-align: left;
              <?php } ?>
        }
	.userTable .labelForfields{
		float:left;
		font-size:16px;
		margin-right:38px;
		text-align:right;
		width:130px;
		font-family:lucida Grande;
                <?php if (!IS_IPAD_REQUEST) { ?>
                    margin-top:-2px;
                <?php } else { ?>
                     margin-top:5px;
                <?php } ?>
	}
	  	 span.require {
    color: #F00;
}                
	.userTable input[type="text"],input[type="password"]{
		margin-left:-29px;
		margin-top:0;
		<?php if (!IS_IPAD_REQUEST) { ?>
                  width:160px; 
                <?php } else { ?>
                   width:200px; 
                <?php } ?>
	
	}
	
	.userTable select{
		margin-left:-29px;
		margin-top:0;
                <?php if (!IS_IPAD_REQUEST) { ?>
                  width:160px; 
                <?php } else { ?>
                   width:200px; 
                <?php } ?>
		
	}
	.userTable input[type="button"]{
              <?php if($userRoleId != ROLE_ADMIN){?>
		margin-right:48px;
                
              <?php } else { ?>
                margin-left: 58px;
              <?php } ?>
                width:70px;
		text-align:center;
		
	}
	
	
	.userTable label.error {
		background:none repeat scroll 0 0 transparent;
		border:0 none;
		color:red;
		font-weight:normal;
		margin:0;
		padding:0;
		text-align:center;
	}
	select.error{
		padding:0px;
	}
        <?php if (IS_IPAD_REQUEST) { ?>
        .ipadCSS{
            
    /* display: block; */
    width: 100%;
    height: 30px;
    padding:0px !important; 
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
    border: 1px solid #ccc;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;

        }
        <?php } ?>
	</style>
	<script type="text/javascript">
	var validationRules	=  {
			Country: {
				required:true
			},
		};
		var validationMessages = {
				Country: {
			required: "xax"
		}
		};
function closeDialog(){
	$("#userContainer").dialog("close");
}
</script>
<div class="clientUserMsgBox"></div>
<form action="#"   method="post" name="saveCountryform" id="saveCountryform" class="validateForm" style="width:450px">
	<input type="hidden" name="CountryId" id="CountryId" value="<?php if(isset($Countrydetails->CountryId)){ echo $Countrydetails->CountryId; }?>"></input>
		<table class="anaylystForm clientTbl userTable">
			<tr>
				<td>
					<div class="labelForfields">Country Name<span class="require">*</span></div>
                    :<input type='text' id="Country" name="Country" placeholder='Country Name' class="required ipadCSS" value="<?php if(isset($Countrydetails->Country)){ echo $Countrydetails->Country; }?>"/>
				</td>
			</tr>
			<tr>
				<td>
					<div class="labelForfields">Capital</div>
                    :<input type='text' name="Capital" placeholder='Capital' value="<?php if(isset($Countrydetails->Capital)){ echo $Countrydetails->Capital; }?>"/>
				</td>
			</tr>
			<tr>
				<td>
					<div class="labelForfields">Global Region</div>
                    :<input type='text' name="GlobalRegion" placeholder='Global Region' value="<?php if(isset($Countrydetails->GlobalRegion)){ echo $Countrydetails->GlobalRegion; }?>"/>
				</td>
			</tr>	
			<tr>
				<td>
					<div class="labelForfields">Nationality Singular</div>
                    :<input type='text' name="NationalitySingular" placeholder='Nationality Singular' value="<?php if(isset($Countrydetails->NationalitySingular)){ echo $Countrydetails->NationalitySingular; }?>"/>
				</td>
			</tr>
			<tr>
				<td>
					<div class="labelForfields">Nationality Plural</div>
                    :<input type='text' name="NationalityPlural" placeholder='Nationality Plural' value="<?php if(isset($Countrydetails->NationalityPlural)){ echo $Countrydetails->NationalityPlural; }?>"/>
				</td>
			</tr>
			<tr>
				<td>
					<div class="labelForfields">Currency</div>
                    :<input type='text' name="Currency" placeholder='Currency' value="<?php if(isset($Countrydetails->Currency)){ echo $Countrydetails->Currency; }?>"/>
				</td>
			</tr>	
			<tr>
				<td>
					<div class="labelForfields">Currency code</div>
                    :<input type='text' name="CurrencyCode" placeholder='Currency code' value="<?php if(isset($Countrydetails->CurrencyCode)){ echo $Countrydetails->CurrencyCode; }?>"/>
				</td>
			</tr>
			<tr>
				<td>
					<div class="labelForfields">Population</div>
                    :<input type='text' name="Population" placeholder='Population' value="<?php if(isset($Countrydetails->Population)){ echo $Countrydetails->Population; }?>"/>
				</td>
			</tr>
			<tr>
				<td>
					<div class="formButtons">
                     <input type="button" value="Save" name="submit" onclick="saveCountryDetails();" ></input>
                   <input type="button" value="Cancel" onclick=closeDialog()></input>
                     </div>
				</td>
			</tr>
	</table>
</form>