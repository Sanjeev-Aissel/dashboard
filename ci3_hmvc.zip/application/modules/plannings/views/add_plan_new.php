<?php
/**
 * Contains a form to add plans
 * 
 * @package views.plannings
 * @author Ramesh B
 * @since 3.1
 * @created 12-09-2011
 */
$kolAutoCompleteOptions = "width: 160, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";


?>


<script type='text/javascript' src="<?php echo base_url() ?>js/jquery/jquery-ui-1.8.16.datepicket.js"></script>
<style type="text/css">
    #addPlansForm input[type="text"]{
        width:155px;
    }
    .error{
        color:#ff0000;   
    }
    #objectiveId_chzn{
        width:163px !Important;   
    }
    .required{
        color:#ff0000;
    }
    .add-icon{
        background-image: url("<?php echo base_url(); ?>images/add_active.png");
        background-repeat: no-repeat;
        background-size: 20px auto;
        cursor: pointer;
        display: inline-block;
        height: 27px;
        vertical-align: middle;
        width: 25px;
        background-size: 21px;
        background-repeat: no-repeat;
    }
    .remove-icon{
        background-image: url("<?php echo base_url(); ?>images/delete_active.png");
        background-repeat: no-repeat;
        background-size: 20px auto;
        cursor: pointer;
        display: inline-block;
        height: 27px;
        vertical-align: middle;
        width: 25px;
        background-size: 21px;
    }
    /*	div.addIcon {
                    margin-top: 24px;
            }
    */
    #createPlansContiner #plansDetails tr td select{
        width:190px;
    }
    div.actionIcon{
        margin-top: 15px;
    }
    .pd{
        width:75px;
        font-weight: bold;
    }
    table.tabularGrid caption{
        /*background:url("<?php echo base_url(); ?>images/kolm-sprite-image.png") repeat-x scroll -2px -236px transparent;*/
        background: #ececec none repeat scroll 0 0;
        box-shadow: 0 0 4px #d1d1d1 inset;
        color: #333333;
        padding-left: 5px;
    }
    table.tabularGrid td:FIRST-CHILD{
        padding-left: 5px;
    }
    table.interactionDetails td:nth-child(1){
        width: 150px !important;
    }
    table.interactionDetails td:nth-child(2){
        width: 300px !important;
    }
    table.interactionDetails td:nth-child(3){
        width: 150px !important;
    }
    #interactionMicroProfileContent table.highlightHeadings tr th{
        background-color: #eee;
    }
    h5.heading{
        background: none repeat scroll 0 0 #D8E5F4;
        color: #2D53AF;
        margin-bottom: 2px;
        padding: 5px;
    }

    #historyContainer > div > div{
        border-bottom: 1px solid #bbbbbb;
    }
    #historyContainer ul{
        list-style: none;
    }
    .align-label{
    	width: 75px;
    	float: left;
    	margin-top: 6px;
    }
</style>
<script language="javascript" type="text/javascript" src="<?php echo base_url() ?>js/chosen.jquery.js"></script>
<script language="javascript" type="text/javascript" src="<?php echo base_url() ?>js/jquery/jquery.validate1.9.min.js"></script>
<link href="<?php echo base_url(); ?>css/chosen.css" media="screen" rel="stylesheet">
<script type="text/javascript">
    var globalId = '';
    var kolAutoCompleteOptions = {
        serviceUrl: '<?php echo base_url(); ?>kols/get_kol_names_for_autocomplete',
<?php echo $kolAutoCompleteOptions; ?>,
                onSelect: function (event, ui) {
                    var kolId = $(event).children('.id1').html();
                    var selText = $(event).children('.kolName').html();
                    selText = selText.replace(/\&amp;/g, '&');
                    $('#' + globalId).val(selText);
                    $('#' + globalId.replace("kolName", "kolId")).val(kolId);
                }
    };
    $(".test1").live("focus", function () {
        globalId = $(this).attr('id');
    });
    var kolAutoComplete = $('#kolName1').autocomplete(kolAutoCompleteOptions);
//$.validator.setDefaults({ ignore: ":hidden:not(select)" })
    $(document).ready(function () {
       // $( "#datepicker1" ).datepicker({ minDate: 0});
       //  $( "#datepicker2" ).datepicker({ minDate: 0});
//        $.validator.setDefaults({ ignore: ":hidden:not(select)" }) //for all select        //validate the plans 
        $('table.tabularGrid caption div.collapseSlider').click(function () {
            if ($(this).attr('class') != "collapseSlider") {
                $(this).parent().parent().find('tr').hide();
                $(this).find('a').attr('data-original-title', 'Expand');
            } else {
                $(this).parent().parent().find('tr').show();
                $(this).find('a').attr('data-original-title', 'Collapse');
            }
            $(this).toggleClass('expandSlider');
        });
        //Function to handle request to add another plan, to the same objective
        $("#addMorePlan").click(function () {

            //get the number of plans already entered in this page, by default it is 1
            var numberOfPlans = $("#numberOfPlans").val();
            numberOfPlans++;
            var planFormContent = $("#plan1").html();
            var newPlanContent = '<tr id="plan' + numberOfPlans + '">' + planFormContent + '</tr>';
            $("#plansDetails").append(newPlanContent);
            //remove add another plan button from other plans, as it is unnessesary to give this button infront of each plan
            $('#plan' + numberOfPlans + ' #addMorePlan').attr('id', 'cancelPlan' + numberOfPlans);
            var cancelButton = '<div class="remove-icon" alt="Cancel Plan" title="Delete" onclick="cancelPlan(' + numberOfPlans + ')" />';
            $('#plan' + numberOfPlans + ' #cancelPlan' + numberOfPlans).html(cancelButton);

            //Rename the names and ids of all the inputs for this plan
            $('#plan' + numberOfPlans + ' #kolName1').attr('id', 'kolName' + numberOfPlans);
            $('#plan' + numberOfPlans + ' #kolName' + numberOfPlans).attr('name', 'kol_name_' + numberOfPlans);
            $('#plan' + numberOfPlans + ' #kolId1').attr('id', 'kolId' + numberOfPlans);
            $('#plan' + numberOfPlans + ' #kolId' + numberOfPlans).attr('name', 'kol_id_' + numberOfPlans);
            $('#plan' + numberOfPlans + ' td:nth-child(1) label').attr('for', 'kolId' + numberOfPlans);
            $('#plan' + numberOfPlans + ' #kolId' + numberOfPlans).val('');
            $('#plan' + numberOfPlans + ' #kolId' + numberOfPlans).removeClass('error');
;    

            $('#plan' + numberOfPlans + " .chzn-container").remove();
            $('#plan' + numberOfPlans + " > td").first().append(' <select name="kol_id_' + numberOfPlans + '[]" id="kolName' + numberOfPlans + '" multiple="multiple" class="required chosenMultipleSelectKOLS"  data-placeholder="Select <?php echo lang("KOL"); ?>(s)"><option value="sdf">' + $("#kolName1").html() + '</option></select>');
              $("#kolName"+numberOfPlans+ "> option").each(function() {
                $(this).removeAttr('selected');
            });
           
    $('.chosenMultipleSelectKOLS').chosen({
                allow_single_deselect: true

            });
          $("#kolName" + numberOfPlans).trigger("chosen:updated");
            //$.validator.setDefaults({ignore: ":hidden:not(select)"})
//     $.validator.setDefaults({ ignore: ":hidden:not(select)" })
            $('#plan' + numberOfPlans + ' #userId1').attr('id', 'userId' + numberOfPlans);
            $('#plan' + numberOfPlans + ' #userId' + numberOfPlans).attr('name', 'user_id_' + numberOfPlans);
            $('#plan' + numberOfPlans + ' td:nth-child(2) label').attr('for', 'userId' + numberOfPlans);
            $('#plan' + numberOfPlans + ' #userId' + numberOfPlans).val('');
            $('#plan' + numberOfPlans + ' #userId' + numberOfPlans).removeClass('error');

            $('#plan' + numberOfPlans + ' #status1').attr('id', 'status' + numberOfPlans);
            $('#plan' + numberOfPlans + ' #status' + numberOfPlans).attr('name', 'status_' + numberOfPlans);
            $('#plan' + numberOfPlans + ' td:nth-child(3) label').attr('for', 'status' + numberOfPlans);
            $('#plan' + numberOfPlans + ' #status' + numberOfPlans).val('');
            $('#plan' + numberOfPlans + ' #status' + numberOfPlans).removeClass('error');

//            $('#plan' + numberOfPlans + ' #targets1').attr('id', 'targets' + numberOfPlans);
//            $('#plan' + numberOfPlans + ' #targets' + numberOfPlans).attr('name', 'targets_' + numberOfPlans);
//            $('#plan' + numberOfPlans + ' td:nth-child(4) label').attr('for', 'targets' + numberOfPlans);
//            $('#plan' + numberOfPlans + ' #targets' + numberOfPlans).val('');
//            $('#plan' + numberOfPlans + ' #targets' + numberOfPlans).removeClass('error');

            $('#plan' + numberOfPlans + ' #planCancel1').attr('id', 'planCancel' + numberOfPlans);
            $('#plan' + numberOfPlans + ' #planCancel' + numberOfPlans).attr('name', 'plan_cancel_' + numberOfPlans);

            //Set the updated value of number of plans in this page

            $("#numberOfPlans").val(numberOfPlans);

            //Remove the error messages
            $('#plan' + numberOfPlans + ' label.error').remove();

            //remove the class 'duplicatePlan' from all td's if exist
            $('#plan' + numberOfPlans + ' td').each(function () {
                $(this).removeClass('duplicatePlan');
            });
//            $('#month' + numberOfPlans).rules("add", {
//                required: true,
//                validMonth: true,
//                messages: {
//                    required: "Required input",
//                    validMonth: "Month should not be past"
//                }
//            });
//            $("#targets" + numberOfPlans).rules("add", {
//                digits: true,
//                messages: {
//                    digits: "Please enter only digits"
//                }
//            });

            var kolAutoComplete = $('#kolName' + numberOfPlans).autocomplete(kolAutoCompleteOptions);
        });

        //Validate the plans form using jquery plugin

        $("#addPlansForm").validate({
            debug: false,
            onkeyup: false
        });
        $("#datepicker1").focus(function () {
            $('#datepicker1').datepicker({                
                dateFormat: 'mm/dd/yy',
                onSelect: function(dateText, inst) {
                	$("#datepicker1").removeClass("error");
                	$("#datepicker1").next('label').remove();
    		    }
             });
            $('#datepicker1').datepicker("show");
        });
        $("#datepicker2").focus(function () {
            $('#datepicker2').datepicker({
               	minDate: 0,
               	dateFormat: 'mm/dd/yy',
               	onSelect: function(dateText, inst) {
               		$("#datepicker2").removeClass("error");
               		$("#datepicker2").next('label').remove();
    				var startDate = new Date($("#datepicker1").val());
    				var endDate = new Date($("#datepicker2").val());
    				startDate.setHours(0, 0, 0, 0);
    				endDate.setHours(0, 0, 0, 0);
    			    if (endDate < startDate) {
    			        $("#dateError").show();
    			    }else{
    			    	$("#dateError").hide();
        			}
    		    }
             });
            $('#datepicker2').datepicker("show");
        });

        $(document).on('change','.chosenMultipleSelectKOLS',function() {
            $(this).next().find(".required").remove();
        });
//        $("#targets1").rules("add", {
//            digits: true,
//            messages: {
//                digits: "Please enter only digits"
//            }
//        });
//
//
//        $("#month1").rules("add", {
//            required: true,
//            validMonth: true,
//            messages: {
//                required: "Required input",
//                validMonth: "Month should not be past"
//            }
//        });


        jQuery.validator.addMethod("greaterThanZero1", function (value, element) {
            return this.optional(element) || (parseFloat(value) > 0);
        }, "* Amount must be greater than zero");
        
    });

    //Cancel the adding plan, just hide the plan and set it as cancelled, while saving exclude the plans whose planCancelled is '1'
    function cancelPlan(planNumber) {
        $("tr#plan" + planNumber + " #planCancel" + planNumber).val(1);
        $("tr#plan" + planNumber).fadeOut(600, function () {
            $("tr#plan" + planNumber).remove();
        });
    }

    function validatePlans() {
//        $.validator.setDefaults({ ignore: ":hidden:not(select)" }) //for all select        //validate the plans 

        if (!$("#addPlansForm").validate().form()) {


            return false;
        } else {
//            alert();
//        $(".chzn-choices").each(function(){
//                if($(this).lenght==1){
//               var id= $(this).closest('.chzn-container-active').attr('id');
//               var data=id.splie("_");
//               alert(data[0]);
//            }
//    });
            return true;

        }
    }


function initChosen(){
    $('.chosenMultipleSelectKOLS').chosen({
                allow_single_deselect: true

            });
    
}
    function validateChosen() {
        var chosenError = false;
        $(".chzn-container-multi > .chzn-choices").each(function () {

            var id = $(this).closest('.chzn-container-multi').attr('id');
            if (!$(this).children().hasClass('search-choice')) {
                chosenError = true;
                $(".msg_" + id).remove();
                $("#" + id).append("<span class='msg_" + id + " required'>This field is required.</span>");

            } else {
                $(".msg_" + id).remove();
            }
        });
        return chosenError;
    }
    //Save all the plans using AJAX.
    function savePlans() {
		var startDate = Date.parse($('#datepicker1').val());
		var endDate = Date.parse($('#datepicker2').val());
		 if ((endDate) < (startDate)) {
			 jAlert("End date should be greater or Equal than Start date");
			 $('#plan_end').val('');
			 return false;
		 }
        //remove the class 'duplicatePlan' from all td's if exist
        $("#addPlansForm td").each(function () {
            $(this).removeClass('duplicatePlan');
        });

        //validate the plans 
        if (!$("#addPlansForm").validate().form()) {

            validateChosen();

            return false;
        } else {


            var chosenError = validateChosen();
            if (chosenError == true)
                return false;
        }

        if($("#dateError").is(":visible")){
        	return false;
        }
        



        var numberOfPlans = $("#numberOfPlans").val();
        var isAllMatched = true;
//        for (i = 1; i <= numberOfPlans; i++) {
//            if (document.getElementById('kolName' + i) != null) {
//                var enteredKolText = $('#kolName' + i).val();
//                var matched = false;
//                $.each(allKols, function (key, value) {
//                    if (value == enteredKolText) {
//                        matched = true;
//                    }
//                });
//                if (!matched) {
//                    isAllMatched = false;
//                    $("#kolName" + i).after('<label for="kolId" generated="true" class="error">KOL Not Exists.</label>');
//                }
//            }
//        }
        if (isAllMatched) {
            //Show Saving message...
            $('div.planMsgBox').removeClass('success');
            $('div.planMsgBox').addClass('notice');
            $('div.planMsgBox').show();
            $('div.planMsgBox').html('Saving the data... <img src="<?php echo base_url() ?>images/ajax_loader_black.gif" />');

            //Serialize the form data
            var data = $("#addPlansForm").serialize();

            $.ajax({
                url: "<?php echo base_url() ?>plannings/save_plans",
                data: data,
                type: 'POST',
                dataType: 'json',
                success: function (returnData) {
                    if (returnData.success == true) {
                        $('div.planMsgBox').fadeOut('500');
                        $('#addPlansForm #objectiveId').val('');
                        $('#plan1 #kolId1').val('');
                        $('#plan1 #kolName1').val('');
                        $('#plan1 #userId1').val('');
                        $('#plan1 #month1').val('');
                        $('#plan1 #targets1').val('');
                        $('#plan1 #numberOfPlans').val('1');
                        $("input").val();
                        window.location.href="<?php echo base_url() ?>plannings/show_plans/plans";
                    } else {
                        $('div.planMsgBox').addClass('notice');
                        $('div.planMsgBox').fadeIn('500');
                        $('div.planMsgBox').html('Error occurred while trying to save data.Try again.');
                        if (returnData.duplicate == true)
                            $('div.planMsgBox').html('Plan name already exists');
                    }


                }
            });
        }
    }
    $('.chosenMultipleSelectKOLS').chosen({
        allow_single_deselect: true
    });
    
    
    function cancelPlans(){
    
       window.location.href="<?php echo base_url() ?>plannings/show_plans/plans";
    }
</script>

<div id="createPlansContiner">
    <form name="addPlansForm" id="addPlansForm" action="<?php echo base_url() ?>plannings/save_plans" >
        <div class="msgBoxContainer"><div class="planMsgBox"></div></div>
        <input type="hidden" id="numberOfPlans" name="number_of_plans"  value="<?php if($plan_id!=''){ echo $noOfRows;} else { echo "1";}?>"></input>
        <p id="objectivesSelect">





        <table class="highlightHeadings tabularGrid">
            <caption>Plan Details
                <div id="collapseExpandButton" class="expandSlider collapseSlider">
                    <a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
                </div>
            </caption>
            <tr>
                <td class='pd'>Plan Name:<span class="required">*</span></td><td><input value="<?php if($plan_id!=''){ echo $planDetails[0]['plan_name'];} ?>" class="required" type="text" name="plan_name" /></td>
            </tr>

            <tr>
                <td class='pd'>Start Date:<span class="required">*</span></td><td class=''><input value="<?php if($plan_id!=''){ echo $planDetails[0]['plan_start'];} ?>" class="required" id="datepicker1" type="text" placeholder="Select date" name="plan_start" /></td>
                <td class='pd'>End Date:<span class="required">*</span></td><td><input value="<?php if($plan_id!=''){ echo $planDetails[0]['plan_end'];} ?>" class="required" id="datepicker2" type="text" placeholder="Select date" name="plan_end" /><span id="dateError" style="color:red;display:none;">Start Date should not be greater than End Date</span></td>
            </tr>
            <tr>

            </tr>
            <tr>
                <td class='pd'>Description:</td><td><textarea  name="plan_desc" ><?php if($plan_id!=''){ echo $planDetails[0]['plan_description'];} ?></textarea></td>
            </tr>

        </table>


        </p>

        <table class="highlightHeadings tabularGrid">
            <caption>Objectives
                <div id="collapseExpandButton" class="expandSlider collapseSlider">
                    <a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
                </div>
            </caption>
  <?php if ($plan_id == '') { ?>
            <tr>
                <td class='pd'><div class="align-label">Objective:<span class="required">*</span></div></td><td>
                    <select name="objective_id[]" id="objectiveId" multiple="multiple" class="required chosenMultipleSelectKOLS" data-placeholder="Select Objective">
                        <option disabled="disabled" value="">Select Objective</option>
                        <?php if (isset($arrObjectives)) { ?>
                            <?php foreach ($arrObjectives as $key => $value) { ?>
                                <option value="<?php echo $key; ?>"><?php echo $value; ?></option>
                            <?php } ?>
                        <?php } ?>
                    </select></td>


            </tr>
  <?php } else { ?>
            
           <tr>
                <td class='pd'><div class="align-label">Objective:<span class="required">*</span></div></td><td>
                    <select name="objective_id[]" id="objectiveId" multiple="multiple" class="required chosenMultipleSelectKOLS" data-placeholder="Select Objective">
                        <option disabled="disabled" value="">Select Objective</option>
                        <?php if (isset($arrObjectives)) { ?>
                            <?php foreach ($arrObjectives as $key => $value) {
                                    foreach ($arrObj as $row){
                                        if($row['id']==$key)
                                            $selected=true;
                                    }
                                ?>
                        <?php if($selected==true){ ?>
                                <option selected value="<?php echo $key; ?>"><?php echo $value; ?></option>
                                
                        <?php } else { ?>
                                 <option value="<?php echo $key; ?>"><?php echo $value; ?></option>
                        <?php } ?>
                            <?php $selected=false;} ?>
                        <?php } ?>
                    </select></td>


            </tr> 
            
  <?php } ?>


        </table>
        <table id="plansDetails" class="highlightHeadings tabularGrid">
            <caption>Assign Profiles
                <div id="collapseExpandButton" class="expandSlider collapseSlider">
                    <a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
                </div>
            </caption>
            <?php if ($plan_id == '') { ?>
                <tr id="plan1">
                    <td>
                    <div class="align-label"><label for="kolId1">KTL Name:<span class="required">*</span></label></div>
                       
                        
    <!--                    <input type="text" name="kol_name_1"  id="kolName1" class="test1 required autocompleteInputBox" />
                        <input type="hidden" name="kol_id_1"  id="kolId1" />-->
                        <!--<span id="tooltip-about-name-format" class="map-info tooltop-bottom"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Enter KOL name in the format of First_name Middle_name Last_name</span>">&nbsp;</a></span>-->
                        <select name="kol_id_1[]" id="kolName1" multiple="multiple" class="required chosenMultipleSelectKOLS" data-placeholder="Select KTL(s)">
                            <option value=""></option>
                            <?php
                            foreach ($arrKols as $key => $values) {

                                $selected = '';
                                ?>
                                <option value="<?php echo $key ?>"><?php echo $values ?></option>;
                            <?php }
                            ?>

                        </select>

                    </td>
                    <td>
                        <label for="userId1">Assign To:<span class="required">*</span></label>
                        <select name="user_id_1" id="userId1" class="required">
                            <option value="">Select Responsible</option>
                            <?php if (isset($arrUsers)) { ?>
                                <?php foreach ($arrUsers as $key => $value) { ?>
                                    <option value="<?php echo $key; ?>"><?php echo $value; ?></option>
                                <?php } ?>
                            <?php } ?>
                        </select>
                    </td>
                    <td>
                        <label for="status1">Status:<span class="required">*</span></label>
                        <select name="status_1" id="status1" class="required">
                            <option value="">Select Status</option>
                            <option value="new">New</option>
                            <option value="in progress">In Progress</option>
                            <option value="completed">Completed</option>
                        </select>
                    </td><!--
                    <td>
                        <label for="targets1">Targets :<span class="required">*</span></label>
                        <input type="text" name="targets_1" id="targets1"  class="required"></input>
                        <input type="hidden" name="plan_cancel_1"  id="planCancel1" value="0"></input>
                    </td>-->
                    <td id="addDeleteLinks">
                        <label id="addMorePlan"><div class="add-icon"></div></label>
                    </td>
                </tr>

            <?php } else { $i=1;
                foreach ($planDetails as $data) {
                    $kols=explode(",",$data['kols']);
                    ?>

                    <tr id="plan<?php echo $i;  ?>">
                        <td valign="middle">
                            <div class="align-label"><label for="kolId<?php echo $i;  ?>"><?php echo lang("KOL"); ?> Name :<span class="required">*</span></label></div>
                       
        <!--                    <input type="text" name="kol_name_1"  id="kolName1" class="test1 required autocompleteInputBox" />
                            <input type="hidden" name="kol_id_1"  id="kolId1" />-->
                            <!--<span id="tooltip-about-name-format" class="map-info tooltop-bottom"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Enter KOL name in the format of First_name Middle_name Last_name</span>">&nbsp;</a></span>-->
                           
                    <select name="kol_id_<?php echo $i;  ?>[]" id="kolName<?php echo $i;  ?>" multiple="multiple" class="required chosenMultipleSelectKOLS" data-placeholder="Select KTL(s)">
                                <option value=""></option>
                                <?php
                                    foreach ($arrKols as $key => $values) {

                                         foreach ($kols as $id){
                                             if($id==$key)
                                                 $selected=true;
                                         }
                                        ?>

                                        <?php if($selected==true) { ?>
                                            <option selected value="<?php echo $key ?>"><?php echo $values ?></option>;

                                        <?php } else {?>
                                             <option value="<?php echo $key ?>"><?php echo $values ?></option>;

                                        <?php } ?>   
                                    <?php $selected=false;}
                                ?>

                            </select>

                        </td>
                        <td>
                            <label for="userId<?php echo $i;  ?>">Assign To :<span class="required">*</span></label>
                            <select name="user_id_<?php echo $i;  ?>" id="userId1" class="required">
                                <option value="">Select Responsible</option>
                                <?php if (isset($arrUsers)) { ?>
                                    <?php foreach ($arrUsers as $key => $value) { 
                                        if($data['user_id']==$key){
                                        ?>
                                        <option selected value="<?php echo $key; ?>"><?php echo $value; ?></option>
                                        
                                        <?php } else { ?>
                                         <option value="<?php echo $key; ?>"><?php echo $value; ?></option>
                                        <?php } ?>
                                    <?php } ?>
        <?php } ?>
                            </select>
                        </td>
                        <td>
                            <label for="status<?php echo $i;  ?>">Status :<span class="required">*</span></label>
                            <select name="status_<?php echo $i;  ?>" id="status1" class="required">
                                <option value="">Select Status</option>
                                <option <?php if($data['status']=="new"){ echo "selected";} ?> value="new">New</option>
                                <option  <?php if($data['status']=="in progress"){ echo "selected";} ?>  value="in progress">In Progress</option>
                                <option  <?php if($data['status']=="completed"){ echo "selected";} ?>  value="completed">Completed</option>
                            </select>
                        </td><!--
                        <td>
                            <label for="targets1">Targets :<span class="required">*</span></label>
                            <input type="text" name="targets_1" id="targets1"  class="required"></input>
                            <input type="hidden" name="plan_cancel_1"  id="planCancel1" value="0"></input>
                        </td>-->
                        <?php if($i==1) {?>
                        <td id="addDeleteLinks">
                            <label id="addMorePlan"><div class="add-icon"></div></label>
                        </td>
                        <?php } else { ?>
                        <td  id="addDeleteLinks">
                        <label id="cancelPlan<?php echo $i ?>"> <div class="remove-icon" alt="Cancel Plan" title="Delete" onclick="cancelPlan(<?php echo $i ?>)" /></label>
                         </td>
                        <?php } ?>
                    </tr>
   <input type="hidden" name="plan_id" value="<?php echo $plan_id ?>" ></input>



                <?php $i++; }
               echo '<script type="text/javascript">',
     'initChosen();',
     '</script>'
;
               
            }
            
            ?>
        </table>


    </form>
    <center><input type="button" name="save_plans" value="Save" onclick="savePlans();" />&nbsp;<input type="button" name="save_plans" value="Cancel" onclick="cancelPlans();" /></center>
</div>
