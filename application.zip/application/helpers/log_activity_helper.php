<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
    define('ACCESS_OBJECTS','1');
    define('ACCESS_PERMISSIONS','2');
    define('ACP_ZIPTERR','3');
    define('ADDITIONAL_CONTACTS','4');
    define('ADDITIONAL_CONTACTS_IREPORTS','5');
    define('ADDITIONAL_CONTACTS_LAT_LONG','6');
    define('ADDITIONAL_CONTACTS_NEW','7');
    define('ADDITIONAL_CONTACTS_OTHERS','8');
    define('ADDITIONAL_ROLES','9');
    define('ADDITIONALCONTACTS','10');
    define('ADDRESS','11');
    define('AFFILIATES_PARTNERSHIPS','12');
    define('AFFILIATION','13');
    define('ALIGNMENT','14');
    define('API_LOG','15');
    define('ASMT_CATEGORIES','16');
    define('ASMT_CRITERIA','17');
    define('ASMT_KOLS_RATING','18');
    define('ASMT_RATINGS','19');
    define('ASMT_RULES','20');
    define('BEST_TIME','21');
    define('BLUE','22');
    define('CALENDAR_EVENTS','23');
    define('CATEGORIES','24');
    define('CITIES','25');
    define('CITIES_OLD','26');
    define('CITY_DIST','27');
    define('CLIENT_EVENT_PAYMENTS','28');
    define('CLIENT_EVENTS','29');
    define('CLIENT_USERS','30');
    define('CLIENT_USERS_TERRITORY','31');
    define('CLIENTS','32');
    define('CLIENTS_KOLS','33');
    define('CLINICAL_TRIALS','34');
    define('COACHING','35');
    define('COACHING_COMMENT','36');
    define('COACHING_SKILL_RATING','37');
    define('COACHINGS','38');
    define('COMPLIANCE_MONITORING','39');
    define('COMPLIANCE_MONITORING_KOLS','40');
    define('COMPLIANCE_MONITORING_ORGANIZATIONS','41');
    define('COMPLIANCE_MONITORING_TOPICS','42');
    define('COMPLIANCE_TOPIC_TPYE','43');
    define('CONF_EVENT_TYPES','44');
    define('CONF_SESSION_TYPES','45');
    define('CONGRESS_SOURCES','46');
    define('CONSOLIDATED_LIST$','47');
    define('CONSOLIDATED_LIST_DUP_MAP','48');
    define('CONSOLIDATED_LIST_UNIQ','49');
    define('CONTACT_RESTRICTIONS','50');
    define('CONTRACTS','51');
    define('COUNTRIES','52');
    define('CT_INTERVENTIONS','53');
    define('CT_INVESTIGATORS','54');
    define('CT_KEYWORDS','55');
    define('CT_MESH_TERMS','56');
    define('CT_SPONSERS','57');
    define('CTS_INTERVENTIONS','58');
    define('CTS_INVESTIGATORS','59');
    define('CTS_KEYWORDS','60');
    define('CTS_MESH_TERMS','61');
    define('CTS_SPONSERS','62');
    define('CTS_STATUSES','63');
    define('CUSTOM_FILTERS','64');
    define('CUSTOMER','65');
    define('CUSTOMER_ENGAGEMENT_KOLS','66');
    define('CUSTOMER_ENGAGEMENT_QUESTION_TYPE','67');
    define('CUSTOMER_ENGAGEMENT_QUESTIONS','68');
    define('CUSTOMER_ENGAGEMENT_RESPONSES','69');
    define('CUSTOMER_ENGAGEMENTS','70');
    define('DEGREES','71');
    define('DISCLAIMER','72');
    define('DMAS','73');
    define('DUPLICATES','74');
    define('EMAILS','75');
    define('EMPLOYEE','76');
    define('ENGAGEMENT_STATUS','77');
    define('ENGAGEMENT_TYPES','78');
    define('ENTITIES','79');
    define('ENTITY_TAGS','80');
    define('EVENT','81');
    define('EVENT_ADDRESS','82');
    define('EVENT_ATTENDEE','83');
    define('EVENT_CONTACT','84');
    define('EVENT_CUSTOMER','85');
    define('EVENT_DYNAMIC','86');
    define('EVENT_ORGANIZER_TYPES','87');
    define('EVENT_ROLES','88');
    define('EVENT_SPONSOR_TYPES','89');
    define('EVENT_TOPICS','90');
    define('EVENTS','91');
    define('FEEDBACK_TYPES','92');
    define('FEEDBACKS','93');
    define('GROUP_PRODUCTS','94');
    define('GROUPS','95');
    define('HCP_FOOTPRINT','96');
    define('HCP_TERRITORY','97');
    define('ICONTACTS','98');
    define('ICONTACTS_1','99');
    define('ID_ANALYSIS','100');
    define('ID_PROCESSED_PUBS','101');
    define('ID_PROJECT','102');
    define('ID_PROJECT_INPUTS','103');
    define('ID_PROJECT_NAME_COMBINATIONS','104');
    define('ID_UNIQUE_AUTHORS','105');
    define('IMAP_NEW_STAGING','106');
    define('IMPORTED_KOLS','107');
    define('INSTITUTIONS','108');
    define('INTERACTION_CATEGORY','109');
    define('INTERACTION_COMM_OBJECTIVES','110');
    define('INTERACTION_DOCS','111');
    define('INTERACTION_GROUPING','112');
    define('INTERACTION_INTERNAL_USERS','113');
    define('INTERACTION_LOCATION_TYPES','114');
    define('INTERACTION_MIRF','115');
    define('INTERACTION_MIRF_PRODUCTS','116');
    define('INTERACTION_SUB_TOPICS','117');
    define('INTERACTION_SUB_TOPICS_ASSOCIATION','118');
    define('INTERACTION_TOPIC_MAPPING','119');
    define('INTERACTION_TOPICS','120');
    define('INTERACTION_TOPICS_BY_TYPE','121');
    define('INTERACTION_TYPE_BY_PRODUCT','122');
    define('INTERACTION_TYPES','123');
    define('INTERACTIONS','124');
    define('INTERACTIONS_ABOUT','125');
    define('INTERACTIONS_ATTENDEES','126');
    define('INTERACTIONS_BRANDS','127');
    define('INTERACTIONS_CATEGORIES','128');
    define('INTERACTIONS_DISCUSSION_TOPIC_MAPPED_DATA','129');
    define('INTERACTIONS_MODES','130');
    define('INTERACTIONS_OTHER_ATTENDEES','131');
    define('INTERACTIONS_PRODUCTS','132');
    define('INTERACTIONS_ROLES','133');
    define('INTERACTIONS_THERAPEUTIC_AREAS','134');
    define('INTERACTIONS_TOPIC_MAPPED_DATA','135');
    define('INTERACTIONS_TOPICS','136');
    define('INVESTIGATIONAL_AGENT','137');
    define('IP_ADDRESS_LOCATION','138');
    define('IPRO_MCAD','139');
    define('IPROFILE_HCP','140');
    define('JSON_STORE','141');
    define('KEY_INSIGHT_TOPICS','142');
    define('KEY_INSIGHT_TOPICS_ASSOCIATION','143');
    define('KEY_PEOPLE_ROLES','144');
    define('KEY_PEOPLES','145');
    define('KOL_ACTIVITIES_COUNT','146');
    define('KOL_ADDITIONAL_CONTACTS','147');
    define('KOL_ANANLYTICS','148');
    define('KOL_CLINICAL_TRIALS','149');
    define('KOL_CTIDS','150');
    define('KOL_EDUCATIONS','151');
    define('KOL_EVENTS','152');
    define('KOL_LOCATIONS','153');
    define('KOL_MDMS','154');
    define('KOL_MEMBERSHIPS','155');
    define('KOL_NAME_COMBINATIONS','156');
    define('KOL_NOTES','157');
    define('KOL_PERSONAL_INFO','158');
    define('KOL_PMIDS','159');
    define('KOL_PRODUCTS','160');
    define('KOL_PUBLICATIONS','161');
    define('KOL_PUBLICATIONS_COPY','162');
    define('KOL_SUB_SPECIALTY','163');
    define('KOLS','164');
    define('KOLS_AISSEL_MDM_IDS','165');
    define('KOLS_CLIENT_VISIBILITY','166');
    define('LAT_LONG_BY_ZIP','167');
    define('LIST_CATEGORIES','168');
    define('LIST_KOLS','169');
    define('LIST_NAMES','170');
    define('LOG_ACTIVITIES','171');
    define('MEDIA_ENTITY_MERGE','172');
    define('MEDIA_TAGS','173');
    define('MEDICAL_INSIGHT','174');
    define('MEDICAL_SERVICES','175');
    define('MESH_DICTIONARY_TERMS','176');
    define('MESH_SEARCH_TERMS','177');
    define('MESH_SUB_TERMS','178');
    define('MML_SUB_TOPIC_ASSOC$','179');
    define('MSL_ACTIVITY_REPORT_DATA','180');
    define('NBC','181');
    define('NEAR_BY_CONTACTS','182');
    define('NOTIFICATIONS','183');
    define('OBJECTIVES','184');
    define('OL_KEY_STATUSES','185');
    define('OL_SPEAKER_PRODUCT','186');
    define('ONLINE_EVENT_TYPES','187');
    define('ORG_ADDITIONAL_CONTACTS','188');
    define('ORG_ADDRESS_TYPE','189');
    define('ORG_CLAIMS_PROCESS','190');
    define('ORG_CLAIMS_PROCESS_MAPPED_DATA','191');
    define('ORG_CLINICAL_TRIALS','192');
    define('ORG_COLLABARATION_CATEGORIES_RATINGS','193');
    define('ORG_CTIDS','194');
    define('ORG_DISEASE_DROP_DOWN_VALUES','195');
    define('ORG_DISEASE_MANAGEMENTS','196');
    define('ORG_DISEASE_MAPPED_DATA','197');
    define('ORG_ENROLLMENT_YEARS','198');
    define('ORG_ENROLLMENTS','199');
    define('ORG_FORMLUARY_MAPPED_DATA','200');
    define('ORG_FORMULARIES','201');
    define('ORG_FORMULARY_DROPDOWN_VALUES','202');
    define('ORG_LOCATIONS','203');
    define('ORG_MCO_TYPE','204');
    define('ORG_MEDICAL_SERVICES','205');
    define('ORG_NAME_COMBINATIONS','206');
    define('ORG_NOTES','207');
    define('ORG_PAYER_COLLABARATION_CATEGORIES','208');
    define('ORG_PAYER_COLLABARATION_MAPPED_DATA','209');
    define('ORG_PAYER_FACTS','210');
    define('ORG_PMIDS','211');
    define('ORG_PUBLICATIONS','212');
    define('ORG_STATS_FACTS','213');
    define('ORGANIZATION_TYPES','214');
    define('ORGANIZATIONS','215');
    define('PASSWORD_ANALYTICS','216');
    define('PAYMENT_SPLIT','217');
    define('PAYMENT_THRESHHOLDS','218');
    define('PAYMENT_TYPES','219');
    define('PAYMENTS','220');
    define('PAYMENTS_PAID_BY','221');
    define('PAYMENTS_REQUESTED_BY','222');
    define('PERMISSIONS','223');
    define('PERSONAL_INFO_DOCS','224');
    define('PHONE_NUMBERS','225');
    define('PLAN_DETAILS','226');
    define('PLAN_OBJECTIVES','227');
    define('PLAN_PROFILES','228');
    define('PLANS','229');
    define('POSTAL_CODES','230');
    define('PRIVATEADDRESSES','231');
    define('PRODUCTS','232');
    define('PRODUCTS1','233');
    define('PROFESSIONAL_SUFFIX','234');
    define('PROJECT_KOLS','235');
    define('PROJECTS','236');
    define('PROXYNETWORKS','237');
    define('PUBLICATION_ARTICLE_IDS','238');
    define('PUBLICATION_HISTORY','239');
    define('PUBLICATION_MESH_TERMS','240');
    define('PUBLICATION_SUBSTANCES','241');
    define('PUBLICATIONS','242');
    define('PUBLICATIONS_AUTHORS','243');
    define('PUBLICATIONS_CC','244');
    define('PUBLICATIONS_TYPES','245');
    define('PUBMED_ARTICLE_IDS','246');
    define('PUBMED_AUTHORS','247');
    define('PUBMED_CC','248');
    define('PUBMED_JOURNALS','249');
    define('PUBMED_MESH_TERMS','250');
    define('PUBMED_PUBLICATIONS_TYPES','251');
    define('PUBMED_SUBSTANCES','252');
    define('RATING','253');
    define('REALIGNMENT','254');
    define('RED','255');
    define('REGIONS','256');
    define('ROLES','257');
    define('ROSTER','258');
    define('RSS_ENTITY','259');
    define('RSS_FEED','260');
    define('RSS_LINK','261');
    define('SALES_REPORT_MASTER_DATA','262');
    define('SEGMENTS','263');
    define('SKILL','264');
    define('SKILL_GROUP','265');
    define('SKILL_GROUP_DETAIL','266');
    define('SKILL_GROUP_DISTRIBUTION','267');
    define('SKILL_MASTER','268');
    define('SKILL_RATING','269');
    define('SKILL_RATING_MASTER','270');
    define('SKILL_TEMPLATE','271');
    define('SOURCE_TYPE','272');
    define('SPEAKER_EVALUATIONS','273');
    define('SPEAKER_IMPORT','274');
    define('SPEAKER_RATINGS','275');
    define('SPECIALTIES','276');
    define('SPHERE_OF_INFLUENCE','277');
    define('STAFFS','278');
    define('STAGING_ICONTACTS','279');
    define('STAGING_ICONTACTS_1','280');
    define('STAGING_ICONTACTS_DELETED','281');
    define('STATE_LICENSES','282');
    define('SUBNETS','283');
    define('SUBTIOP','284');
    define('SURVEY_ANSWERS','285');
    define('SURVEY_ANSWERS_ANUP','286');
    define('SURVEY_ANSWERS_ANUP_04SEP','287');
    define('SURVEY_CATEGORIES','288');
    define('SURVEY_KOL_NAMES','289');
    define('SURVEY_ORG_NAMES','290');
    define('SURVEY_QUERIES','291');
    define('SURVEY_QUESTIONS','292');
    define('SURVEY_ROLES','293');
    define('SURVEYS','294');
    define('TEMP_PUBS','295');
    define('THERAPUTIC_AREA_PRODUCTS','296');
    define('THERAPUTIC_AREAS','297');
    define('TITLES','298');
    define('TOPICS_BY_PROD_TYPE$','299');
    define('TRANSACTION_TABLES','300');
    define('UPDATES','301');
    define('USER_BLACKLISTS','302');
    define('USER_BOOKMARKS','303');
    define('USER_COMMENTS','304');
    define('USER_GROUPS','305');
    define('USER_KOLS','306');
    define('USER_LOGS','307');
    define('USER_NOTIFICATIONS','308');
    define('USER_ORG_REQUESTS','309');
    define('USER_ORGS','310');
    define('USER_REQUESTS','311');
    define('USER_ROLES','312');
    define('USER_SETTING_TYPES','313');
    define('USER_SETTINGS','314');
    define('USERS','315');
    define('USERS_ANALYTICS','316');
    define('VALIDATION_STATUS','317');
    define('VARIABLE_RADIUS_ANALYTICS','318');
    define('WALLCOMMENTS','319');
    define('WALLLIKES_TRACK','320');
    define('WALLPOSTS','321');
    define('ZIP_CODES','322');
    define('ZIPTERR','323');
    define('KOL_UPDATE_STATUS','324');
if (!function_exists('log_user_activity')) {
    function log_user_activity($arrData = array(), $isVerboseSet=false) {
        $CI = & get_instance();
        $verBoseTrack = $CI->config->item('verbose_log');
        if ($isVerboseSet == true && $verBoseTrack == true) {
            $CI->load->helper('url');
//            $moduleName = $CI->uri->segment(1);
            $controllerName = $CI->uri->segment(1);
            $methodName = $CI->uri->segment(2);
            $param = $CI->uri->segment(3);
            $paramiPadDesktop = $CI->uri->segment(4);
            $params = $_SERVER['PATH_INFO'];
            $isEnabled = $CI->config->item('log_user_activity');
            if (LOG_USER_ACTIVITY && $isEnabled) {
                $arrData = array();
                //Device detect
                $mobile = mobile_device_detect();
                $isMobileDevice	= false;
                $deviceFrom = 'd';
                if(isset($mobile[1]) && $mobile[1] != 'Apple iPad'){
                    $isMobileDevice	 = true;
                    $deviceFrom = 'm';
                    if($methodName=='logins')
                        $methodName = 'login';
                }
                if(IS_IPAD_REQUEST){
                    $deviceFrom = 'i';
                }
                if($controllerName=='m' || $controllerName=='i'){
                    $arrData['controller'] = $methodName;
                    $arrData['method'] = $param;
                    $arrData['param'] = $paramiPadDesktop;
                }else{
                    $arrData['controller'] = $controllerName;
                    $arrData['method'] = $methodName;
                    $arrData['param'] = $param;
                }
                if ($CI->session->userdata('logged_in')) {
                    $arrData['created_by'] = $CI->session->userdata('user_id');
                }
                $arrData['created_on'] = date("Y-m-d H:i:s");
                if (isset($_SERVER['HTTP_REFERER'])) {
                    $arrData['url'] = $_SERVER['HTTP_REFERER'];
                } else {
                    $arrData['url'] = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
                }
                $arrData['ip_address'] = $_SERVER['REMOTE_ADDR'];
                $arrData['os'] = getOS($_SERVER['HTTP_USER_AGENT']);
                $arrData['browser'] = getBrowser($_SERVER['HTTP_USER_AGENT']);
                $arrLogDetails = $CI->config->item('log_details');
                foreach ($arrLogDetails as $key => $value) {
                    if (!empty($value))
                        $arrData[$key] = $value;
                }
                
                $arrData['module'] = $deviceFrom;
//                 pr($arrData);exit;
                $CI->db->insert('log_activities', $arrData);
//                print_r($arrData);
            }
        }
        //return TRUE;
    }

}
if (!function_exists('getOS')) {

    function getOS($user_agent) {
        $os_platform = "Unknown OS Platform";
        $os_array = array(
            '/windows nt 10/i' => 'Windows 10',
            '/windows nt 6.3/i' => 'Windows 8.1',
            '/windows nt 6.2/i' => 'Windows 8',
            '/windows nt 6.1/i' => 'Windows 7',
            '/windows nt 6.0/i' => 'Windows Vista',
            '/windows nt 5.2/i' => 'Windows Server 2003/XP x64',
            '/windows nt 5.1/i' => 'Windows XP',
            '/windows xp/i' => 'Windows XP',
            '/windows nt 5.0/i' => 'Windows 2000',
            '/windows me/i' => 'Windows ME',
            '/win98/i' => 'Windows 98',
            '/win95/i' => 'Windows 95',
            '/win16/i' => 'Windows 3.11',
            '/macintosh|mac os x/i' => 'iOS',
            '/mac_powerpc/i' => 'Mac OS 9',
            '/linux/i' => 'Linux',
            '/ubuntu/i' => 'Ubuntu',
            '/iphone/i' => 'iPhone',
            '/ipod/i' => 'iPod',
            '/ipad/i' => 'iPad',
            '/android/i' => 'Android',
            '/blackberry/i' => 'BlackBerry',
            '/webos/i' => 'Mobile'
        );
        foreach ($os_array as $regex => $value) {
            if (preg_match($regex, $user_agent)) {
                $os_platform = $value;
                break;
            }
        }
        return $os_platform;
    }

}
if (!function_exists('getBrowser')) {

    function getBrowser($user_agent) {
        $browser = "Unknown Browser";
        $browser_array = array(
            '/msie/i' => 'Internet Explorer',
            '/firefox/i' => 'Firefox',
            '/chrome/i' => 'Chrome',
            '/safari/i' => 'Safari',
            '/opera/i' => 'Opera',
            '/netscape/i' => 'Netscape',
            '/maxthon/i' => 'Maxthon',
            '/konqueror/i' => 'Konqueror',
            '/mobile/i' => 'Native Browser'
        );
        foreach ($browser_array as $regex => $value) {
            if (preg_match($regex, $user_agent)) {
                $browser = $value;
                break;
            }
        }
        return $browser;
    }

}