<table>
		<tbody>
			<tr>
				<td><label for="client">Client <span class="required">*</span></label></td>
				<td>
					<select name="client" id="client">
						<option value="">--Select Client--</option>
						<?php 
							foreach ($arrClientList as $arrList){
						?>
						<option value="<?php echo $arrList['id'];?>"><?php echo $arrList['name']; ?></option>
						<?php 
							}
						?>
					</select>
				</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><span style="display: none;" id="errorMsg"></span></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td>
					<input type="hidden" name="kol_id" id="kol_id" value="<?php echo $kol_id;?>"/>
					<button onclick="saveAssociation('associate');">Associate</button>
					<button onclick="saveAssociation('disassociate');">Disassociate</button>
  				</td>
			</tr>
		</tbody>
</table>
<script>
function saveAssociation(associationFlag){
	var client = $("#client").val();
	var kol_id = $("#kol_id").val();
	var dataString = 'client='+ client +'&kol_id='+kol_id +'&associationFlag='+associationFlag;
	if(client=='')
	{
		$("#errorMsg").css('color','red');
		$("#errorMsg").text('Please choose client');
		$("#errorMsg").show();
	}
	else
	{
		// AJAX Code To Submit Form.
		$.ajax({
			type: "POST",
			url: "<?php echo base_url()?>/kols/save_kol_client_association",
			data: dataString,
			cache: false,
			success: function(result){
				if(result){
					$("#errorMsg").css('color','green');
					$("#errorMsg").text('Updated successfully');
					$("#errorMsg").show();
				}else{
					$("#errorMsg").css('color','red');
					$("#errorMsg").text('Unable to process request');
					$("#errorMsg").show();
				}
			}
		});
	}
	return false;
}
</script>