<form id="add_module" class="validateForm">
			<div class="form-group row" id="">
					<label class="col-sm-4 col-form-label">Module-name:</label>
					<div class="col-sm-8">
						<input type="text" name="module_name" value="" id="module_name" class="form-control">
			    		<div id="role_action_duplicate" style="margin-top: 14px;">

		    			</div>
			    	</div>
			</div>
			<div class="form-group row">
					<label class="col-sm-4 col-form-label"></label>
			   		<div class="col-sm-8">
			     		<button type="submit" class="btn btn-primary" onclick="saveNewModule();return false;">Save</button>    
			         	<button class="btn btn-primary" onclick="close_dialog();return false;">Cancel</button>
			    	</div>
			</div>
</form>
<script>
$("#add_module").validate({
	rules: {
		module_name: "required",
	},
	messages: {
		module_name: {
			required: "Please enter the action name",
		}
	}
});
</script>