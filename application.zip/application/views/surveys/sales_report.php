<?php
/*
 * for Sales report
 * @author Laxman K
 * @since 6.0.9 iMap v1.0
 * Created on	: 22-12-2014
 *  
 */
	$queued_js_scripts =array(	'i18n/grid.locale-en',
							'jquery.jqGrid.min'
						);
	// add the JS files into queue i.e Append to the existing queue
	$prevjs = $this->config->item('js_files_to_load');
	if($prevjs == null)
		$prevjs = array();
	$this->config->set_item('js_files_to_load',array_merge($prevjs,$queued_js_scripts));
?>
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
<style type="text/css">
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
	.reportTypeButton:disabled{
		/*background:gray;*/
	}
	#surveysSummaryList table td{
		vertical-align: top;
	}
	#surveysSummaryList caption{
		background-color: #D3DFED;
		font-weight: bold;
	}
	#overallSummaryData th,#top5TerritoryWrapper th, #bottom5TerritoryWrapper th{
		background-color: #eee;
	}
	#overallSummaryData,#top5TerritoryData, #bottom5TerritoryData{
		border:1px solid;
	}
	#overallSummaryData td,#top5TerritoryWrapper td, #bottom5TerritoryWrapper td,#overallSummaryData th,#top5TerritoryWrapper th, #bottom5TerritoryWrapper th{
		border-bottom:1px solid;
	}
	th, td, caption {
		padding: 4px 5px;
	}
	#regionWrapper,#districtWrapper,#territoryWrapper, #overallSummaryWrapper, #top5TerritoryWrapper, #bottom5TerritoryWrapper{
		padding: 2px;
		width:33%;
	}
	#surveysSummaryList{
		display: none;
	}
</style>
<script>
var activeReportType	= '';
$('.reportDataWrapper').hide();
function exportGridToExcel(){
	var surveyId	= $('#surveyId').val();
	window.location	= '<?php echo base_url();?>surveys/export_salesreport_to_excel/'+surveyId;
	/*switch(activeReportType){
		case 'sales report':window.location	= '<?php echo base_url();?>surveys/export_salesreport_to_excel/'+surveyId;
			break;
		case 'summary report':
			break;
	}*/
}
function loadReport(){
	switch(activeReportType){
		case 'sales report':listData();
			break;
		case 'summary report':listSummaryData();
			break;
	}
}
function listData(){
	$("#gridContainer").html("");
	$("#gridContainer").html('<div id="listSurveysPage"></div><table id="listSurveysResultSet"></table>');
	activeReportType	= 'sales report';
	$('.reportDataWrapper').hide();
	$('#surveysList').show();
	$('.reportTypeButton').removeAttr('disabled');
	$('#surveysButton').attr('disabled','disabled');
	var surveyId	= $('#surveyId').val();
	var ele=document.getElementById('surveysList');
	var gridWidth=ele.clientWidth;
	gridWidth-=5;
	jQuery("#listSurveysResultSet").jqGrid({
		url:base_url+'surveys/sales_report_grid/'+surveyId,
		datatype: "json",
	   	colNames:['Id','Question','Region','District','Territory','Territory Id','User Name','Respondents','Local','National','Zero Influencer Count','Influencers','Staging Local','Staging National','Zero Influencer Count','Staging Influencers','Total Influencers','Call Plan','Call Plan in %','Title','Email','Manager'],
	   	colModel:[
			{name:'id',index:'id', hidden:true},
			{name:'survey_name',index:'survey_name'},
	   		{name:'region',index:'region', resizable:false},
	   		{name:'district',index:'district', resizable:false},
	   		{name:'territory_name',index:'territory_name', resizable:false},
	   		{name:'territory',index:'territory', resizable:true},
	   		{name:'user_name',index:'user_name', resizable:true},
	   		{name:'respondents_count',width:100,index:'respondents_count'},
	   		{name:'prod_local',index:'prod_local',width:100},
	   		{name:'prod_national',index:'prod_national',width:100},
	   		{name:'prod_zero_influencers',index:'prod_zero_influencers',width:100},
	   		{name:'prod_responses',index:'prod_responses',width:100},
	   		{name:'staging_local',index:'staging_local',width:100},
	   		{name:'staging_national',index:'staging_national',width:100},
	   		{name:'staging_zero_influencers',index:'staging_zero_influencers',width:100},
	   		{name:'staging_responses',index:'staging_responses',width:105},
	   		{name:'total',index:'total',width:100},
	   		{name:'call_plan',index:'call_plan',width:100},
	   		{name:'call_plan_percentage',index:'call_plan_percentage',width:100},
	   		{name:'title',index:'title'},
	   		{name:'email',index:'email'},
	   		{name:'manager_name',index:'manager_name'}
	   	],
	   	rowNum:10,
	   	rownumbers: true,
	   	autowidth: false, 
	   	loadonce:true,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",		 
	   	pager: '#listSurveysPage',
	   	mtype: "POST",
	   	sortname: 'user_name',
	    viewrecords: true,
	    sortorder: "asc",
	    shrinkToFit:false,
	    jsonReader: { repeatitems : false, id: "0" }, 
	    caption:'Sales Report',
	    grouping: false, 
		gridComplete: function(){},
   		rowList:paginationValues
	});
	jQuery("#listSurveysResultSet").jqGrid('navGrid','#listSurveysPage',{edit:false,add:false,del:false,search:false,refresh:false});
	//Toolbar search bar below the Table Headers
	jQuery("#listSurveysResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
	//Toggle Toolbar Search
	jQuery("#listSurveysResultSet").jqGrid('navButtonAdd',"#listSurveysPage",{
		caption:"Search",title:"Toggle Search",
		onClickButton:function(){
			if(jQuery(".ui-search-toolbar").css("display")=="none") {
				jQuery(".ui-search-toolbar").css("display","");
			} else {
				jQuery(".ui-search-toolbar").css("display","none");
			}
		}
	});
	jQuery("#listSurveysResultSet").jqGrid('navButtonAdd',"#listSurveysPage",{
	    id:'ExportToExcel',
	    caption:'Export To Excel',
	    title:'Export To Excel',
	    onClickButton : exportGridToExcel,
	    buttonicon: 'ui-icon-print'
	});
	jQuery("#listSurveysResultSet").jqGrid('setGridWidth',gridWidth);
}
function roundNumber(num) {
    return +(Math.round(num + "e+2")  + "e-2");
}
function listSummaryData(){
	$('tr.rowData').remove();
	activeReportType	= 'summary report';
	$('.reportDataWrapper').hide();
	$('#surveysSummaryList').show();
	$('.reportTypeButton').removeAttr('disabled');
	$('#surveysSummaryButton').attr('disabled','disabled');
	var surveyId	= $('#surveyId').val();
	$.ajax({
		type: "post",
		dataType:"json",
		url: base_url+'surveys/sales_summary_report/'+surveyId,
		success: function(returnData){
			var record	= '';
			var obj	= '';
			var respondentCount	= 0;
			var callPlanCount	= 0;
			var completionPercentage	= 0;
			var rowPercentage	= 0;
			var rowcallPlanCount	= 0;
			for (var i = 0; i < returnData.region.length; i++) {
				obj	= returnData.region[i];
				record	+= '<tr class="rowData"><td>'+(i+1)+'</td><td>'+obj.name+'</td><td>'+obj.respondent_count+'</td><td>'+obj.call_plan+'</td><td>'+obj.completed+'%</td></tr>';
				respondentCount	+= parseInt(obj.respondent_count);
				callPlanCount	+= parseInt(obj.call_plan);
				//completionPercentage	+= parseFloat(obj.completed);
			}
			completionPercentage	= parseFloat(respondentCount/callPlanCount)*100;
			var overallData	= '<tr class="rowData"><th></th><th>Grand Total</th><th>'+respondentCount+'</th><th>'+callPlanCount+'</th><th>'+roundNumber(completionPercentage)+'%</th></tr>';
			$('#overallSummaryWrapper #overallSummaryData').append(overallData);
			returnData.region.sort(function(a,b){ return b.completed - a.completed });
			returnData.district.sort(function(a,b){ return b.completed - a.completed });
			returnData.territory.sort(function(a,b){ return b.completed - a.completed });
			summaryGrid(returnData.region,'region');
			summaryGrid(returnData.district,'district');
			summaryGrid(returnData.territory,'territory');
			record	= '';
			for (var i = 0; i < 5; i++) {
				obj	= returnData.territory[i];
				record	+= '<tr class="rowData"><td></td><td>'+obj.name+'</td><td>'+obj.respondent_count+'</td><td>'+obj.call_plan+'</td><td>'+obj.completed+'%</td></tr>';
			}
			$('#top5TerritoryWrapper #top5TerritoryData').append(record);
			record	= '';
			for (var i = (returnData.territory.length-1); i >= (returnData.territory.length-5); i--) {
				obj	= returnData.territory[i];
				record	+= '<tr class="rowData"><td></td><td>'+obj.name+'</td><td>'+obj.respondent_count+'</td><td>'+obj.call_plan+'</td><td>'+obj.completed+'%</td></tr>';
			}
			$('#bottom5TerritoryWrapper #bottom5TerritoryData').append(record);
			record	= '';
		}
	});
}
function summaryGrid(arrJsonData,type){
	var ele=document.getElementById(type+'GridContainer');
	var gridWidth=ele.clientWidth;
	$("#"+type+"GridContainer").html("");
	$("#"+type+"GridContainer").html('<div id="'+type+'Page"></div><table id="'+type+'ResultSet"></table>');
	
	var columnNamesForGrid	= ['Name','Respondents','Call Plan','% Completion'];
	var columnDataForGrid	= [
	           	            { name: 'name', index: 'name'},
	        	            { name: 'respondent_count', index: 'respondent_count',align:'center'},
	        	            { name: 'call_plan', index: 'call_plan',align:'center'},
	        	            { name: 'completed', index: 'completed',align:'center'}
	        	        ];
	var gridCaption = (type+"  Completion Metrics").toUpperCase();
	var data = {
            "page": "1",
            "rows":arrJsonData
        },
    grid = $("#"+type+"ResultSet");
    grid.jqGrid({
    	colNames:columnNamesForGrid,
        colModel:columnDataForGrid,
        pager: '#'+type+'Page',
        datatype: "jsonstring",
        datastr: data,
        jsonReader: { repeatitems: false },
        rowNum: 10,
    	rownumbers: true,
    	sortname: 'completed',
	    sortorder: 'desc',
        viewrecords: true,
        caption: gridCaption,
        height: "auto",
        ignoreCase: true,
        rowList:paginationValues
    });
    grid.jqGrid('navGrid', '#'+type+'Page',{edit:false,add:false,del:false,search:false,refresh:false});
    grid.jqGrid('filterToolbar', { defaultSearch: 'cn',searchOnEnter : false, stringResult: true });
    grid.jqGrid('navButtonAdd','#'+type+'Page',{
		caption:"Search",title:"Toggle Search",
		onClickButton:function(){
			if(jQuery(".ui-search-toolbar").css("display")=="none") {
				jQuery(".ui-search-toolbar").css("display","");
			} else {
				jQuery(".ui-search-toolbar").css("display","none");
			}
		}
	});
    grid.jqGrid('setGridWidth',gridWidth);
    initilizeGridSearchPlaceholder();
}
$(document).ready(function(){
	listData();
});
</script>
<div id="container">
	<div id="surveyContainer">
		Survey: <select id="surveyId" name="survey_id" onchange="loadReport();">
			<option value="999">Select</option>
			<?php foreach($arrSurveys as $key=>$row){
				echo '<option value="'.$row['id'].'">'.$row['name'].'</option>';
			}?>
		</select>
		<input type="button" onclick="listData();" value="Sales Report" id="surveysButton" class="reportTypeButton" />
		<input type="button" onclick="listSummaryData();" value="Summary Report" id="surveysSummaryButton" class="reportTypeButton" />
		<div id="surveysList" class="reportDataWrapper">
			<div class="gridWrapper" id="gridContainer">
				<div id="listSurveysPage"></div>
				<table id="listSurveysResultSet"></table>
			</div>
		</div>
		<div id="surveysSummaryList" class="reportDataWrapper">
			<table style="margin:0;">
				<tr>
					<td id="overallSummaryWrapper">
						<table id="overallSummaryData">
							<caption>Survey Completion Metrics</caption>
							<tr>
								<th></th><th>Name</th><th>Respondent Count</th><th>Count Call Plan</th><th>% Completion</th>
							</tr>
						</table>
					</td>
					<td id="top5TerritoryWrapper">
						<table id="top5TerritoryData">
							<caption>Top 5 Territory Completion Metrics</caption>
							<tr>
								<th></th><th>Name</th><th>Respondent Count</th><th>Count Call Plan</th><th>% Completion</th>
							</tr>
						</table>
					</td>
					<td id="bottom5TerritoryWrapper">
						<table id="bottom5TerritoryData">
							<caption>Bottom 5 Territory Completion Metrics</caption>
							<tr>
								<th></th><th>Name</th><th>Respondent Count</th><th>Count Call Plan</th><th>% Completion</th>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			<table>
				<tr>
					<td id="regionWrapper">
						<div class="gridWrapper" id="regionGridContainer">
							<div id="regionPage"></div>
							<table id="regionResultSet"></table>
						</div>
					</td>
					<td id="districtWrapper">
						<div class="gridWrapper" id="districtGridContainer">
							<div id="districtPage"></div>
							<table id="districtResultSet"></table>
						</div>
					</td>
					<td id="territoryWrapper">
						<div class="gridWrapper" id="territoryGridContainer">
							<div id="territoryPage"></div>
							<table id="territoryResultSet"></table>
						</div>
					</td>
				</tr>
			</table>
		</div>
	</div>
</div>