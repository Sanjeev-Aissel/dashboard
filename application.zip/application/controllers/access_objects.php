<?php
/**
 * This is Controller for 'Access Objects'
 * 
 * @author Ramesh B
 * @since  3.6
 * @package application.controllers	
 * @created 21-12-2011
 */

class Access_objects extends Controller{
 	
 	private $loggedUserId	= null;
 	
 	//Constructor
	function Access_objects(){
		parent::Controller();
		$this->load->model('common_helpers');		
		$this->load->model("access_object");	
		$this->load->model("role");
		$this->load->model("permission");
		$this->loggedUserId = $this->session->userdata('user_id');
	}
	
	/**
	 * Read all the files from the given directory and get the function and the doc comments details
	 * @author 	Ramesh B
	 * @since	3.6
	 * @created 21-12-2011
	 */	
	function auto_populate_access_objects(){
		$arrRoles = $this->role->getRoles();
		$dirPath=$_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."application/controllers";
		if ($handle = opendir($dirPath)) {
			/* This is the correct way to loop over the directory. */
			while (false !== ($entry = readdir($handle))) {
				if($entry !='.' && $entry !='..' && $entry !='.svn' && $entry !='mobile'){
					//Get functions and the doc comments details for the given controller file
					$arrData=$this->common_helpers->getDefinedFunctionsAndCommentsInFile($entry,$dirPath);
					
					$arrFilteredAcos=array();
					foreach($arrData as $row){
						//Proced only if the function has a doc comments and has a doc tag 'ACL-SubApp'
						if(isset($row['comments']) && isset($row['comments']['ACL-SubApp'])){
							$accessObjectDetails=array();
							$accessObjectDetails['controller']=$row['cls_name'];
							$accessObjectDetails['method']=$row['fun_name'];
							$accessObjectDetails['alias']=$row['comments']['ACL-Alias'];
							$accessObjectDetails['desc']=$row['comments']['ACL-Discription'];
							$accessObjectDetails['category']=$row['comments']['ACL-Category'];
							$accessObjectDetails['sub_app']=$row['comments']['ACL-SubApp'];
							$returnVal=$this->access_object->saveAccessObject($accessObjectDetails);
							
							if($returnVal){
								$this->permission->saveAccessPemissions($arrRoles,$returnVal);
							}else{
								echo 'already exist';
							}
						}
					}
				}			
			}
	
			/* This is the WRONG way to loop over the directory. */
			while ($entry = readdir($handle)) {
				echo "$entry\n";
			}
		}
	    closedir($handle);
	}
	
	/**
	 * Reads all controller classes from the controller directory and lists the names
	 * @author 	Ramesh B
	 * @since	3.6
	 * @created 21-12-2011
	 */	
	function auto_list_all_controller_access_objects(){
		$arrControllerNames=array();
		$dirPath=$_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."application/controllers";
		if ($handle = opendir($dirPath)) {
			/* This is the correct way to loop over the directory. */
			while (false !== ($entry = readdir($handle))) {
				if($entry !='.' && $entry !='..' && $entry !='.svn' && $entry !='mobile'){
					$arrControllerNames[]=trim($entry);
					//Get functions and the doc comments details for the given controller file
					//$arrData=$this->common_helpers->getDefinedFunctionsAndCommentsInFile($entry,$dirPath);
				}			
			}
		
			/* This is the WRONG way to loop over the directory. */
			while ($entry = readdir($handle)) {
				echo "$entry\n";
			}
		}
	    closedir($handle);
	    return $arrControllerNames;
	}
	
	/**
	 * Reads all functions and the doc comments from the given 'Controller' class and lists them
	 * @author 	Ramesh B
	 * @since	3.6
	 * @created 21-12-2011
	 */	
	function auto_list_all_function_access_objects($controllerName){
		$controllerName.='.php';
		$arrControllerNames=array();
		$dirPath=$_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."application/controllers";
		$arrData=$this->common_helpers->getDefinedFunctionsAndCommentsInFile($controllerName,$dirPath);
		$arrFilteredAcos=array();
		foreach($arrData as $row){
			//Proced only if the function has a doc comments and has a doc tag 'ACL-SubApp'
			if(isset($row['comments']) && isset($row['comments']['ACL-SubApp'])){
				$accessObjectDetails='';
				//$accessObjectDetails['controller']=$row['cls_name'];
				$accessObjectDetails=$row['fun_name'];
				//$accessObjectDetails['alias']=$row['comments']['ACL-Alias'];
				//$accessObjectDetails['desc']=$row['comments']['ACL-Discription'];
				//$accessObjectDetails['category']=$row['comments']['ACL-Category'];
				//$accessObjectDetails['sub_app']=$row['comments']['ACL-SubApp'];
				$arrFilteredAcos[]=$accessObjectDetails;
			}
		}
		
		$this->db->select('method');
		$this->db->where('controller',str_replace('.php','',$controllerName));
		$arrResultset =$this->db->get('access_objects');
		foreach($arrResultset->result_array() as $row){
			$arr[]=$row['method'];
		}
		//pr($arr);
		$arr1=array_diff($arrFilteredAcos, $arr);
		$arrFilteredAcos1=array();
		foreach($arr1 as $value){
			$arr3=array();
			$arr3['method']=$value;
			$arrFilteredAcos1[]=$arr3;
		}
		echo json_encode($arrFilteredAcos1);
	}
	
	function add_access_object(){
		$arrControllerNames = $this->auto_list_all_controller_access_objects();
		$arrControllers=array();
		foreach($arrControllerNames as $key=>$value){
			$arrControllers[]=str_replace('.php','',$value);
			
		}
		$data['arrControllerNames'] = $arrControllers;
		$this->load->view('access_objects/add_access_object',$data);
		
	}
	
	function save_access_objects_manually(){
		$accessObjectDetails['controller']	=	$this->input->post('controller');
		$accessObjectDetails['method']		=	$this->input->post('method');
		$accessObjectDetails['alias']		=	$this->input->post('alias');
		$accessObjectDetails['category']	=	$this->input->post('category');
		
		$accessObjectId = $this->access_object->saveAccessObject($accessObjectDetails);
		
		$arrRoles = $this->role->getRoles();
		$arrRole =array();
		foreach($arrRoles as $row){
			$arrRole[]=$row['id'];
		}
		
		$this->permission->saveAccessPemissions($arrRole,$accessObjectId);
		redirect('permissions/show_permissions');
		
	}
	
	function directory_map(){
		$this->load->helper('directory_helper');
		pr(directory_map($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."application/controllers"));
	
	}
}