<?php
/**
* Description:
*
*  @package application.views.kols
*  @author:Developer
*
*  @created on:Dec 13, 2010
*
*/

function listRecordsPerPage($maxRecords=100,$increament=10){
	$rowList="";
 	for($i=10;$i<=$maxRecords;$i+=$increament){
 		$rowList.=$i.",";
 	}
 	$rowList=substr($rowList,0,-1);
 	return $rowList; 
}
?>
<script src="<?php echo base_url();?>js/imgAreaSelect.js" type="text/javascript"></script>
<style type="text/css">
#contentWrapper.span-24 {
    background-image: url("../../images/verticlesep.jpg");
    background-position: 168px 50%;
    background-repeat: repeat-y;
}
			/** This box has been added as a quickfix. Try to resolve this at the earliest */
			.dummyTextAreaBox{
				
			}
			
			/** Firefox only Hack */
			:root *> .firstTextArea div.wysiwyg iframe{
				margin-top:-250px;
			}
			div.wysiwyg{
			
			}
			div.wysiwyg iframe{
			
			}
			.validateForm textarea {
			    height: 135px;
			    width: 90%;
			}
			.imgareaselect-outer{
				z-index: 1500 !important;
			}
			#latLongLoader{
				position: absolute;
    			margin-top: 1px;
    			margin-left: 4px;
    			display: none;
			}
		</style>
		
		<script type="text/javascript" language="javascript">
		//Validation ruled for Overviewform
		var validationRules	=  {
			gender: {
				required:true
				
			},
			specialty: {
				required:true
			},
			first_name: {
				required:true
			},
			
			last_name: {
				required:true
			},
			salutation: {
				required:true
			
			},
			license:{
				alphaNumeric:true
			}
			

				
		};

		var validationMessages = {
				gender: {
					required: "Required"
				},
				specialty: {
					required: "Required"
				},
				first_name: {
					required: "Required"
				},
				last_name: {
					required: "Required"
				},
				salutation: {
					required: "Required"
				}
			
		};

		var validationRulesForContact	=  {
				country_id: {
					required:true
				},
				primary_phone: {
					required:true,
					phoneUS: true
				},
				fax:{
					phoneUS: true
				},
				city_id:{
					required:true
				},
				address1:{
					required:true
				},
				postal_code:{
					alphaNumeric:true
				}
				
				
			};
		
		var validationMessagesForContact = {
				country_id: {
					required: "Required"
				},
				primary_phone: {
					required: "Required"
				},
				city_id: {
					required: "Required"
				},
				address1:{
					required: "Required"
				}
			
		};
			// WYSIWYG editor initialition
	    	var rtfEditorOptions = {
	            	controls:{
	    				insertImage:{visible: false},
	    				insertTable:{visible: false}
	            	},
	            	initialContent:'',
	            	autoGrow:true,
	            	formWidth:600,
	            	formHeight:250
	    	    };

			var uploadImageDialogOpts = {
					title: "Upload Image",
					modal: true,
					autoOpen: false,
					height: 550,
					width: 600,
					open: function() {
						//display correct dialog content
						//$("#uploadImage").load("/application/new_company");
					}
			};
			
			var organizationProfileDialogOpts = {
					title: "Create Organization Profile",
					modal: true,
					autoOpen: false,
					height: 400,
					width: 800,
					open: function() {
						//display correct dialog content
						//$("#organizationProfile").load("/application/new_company");
					}
			};    	    

			var options, a;
			
			// Autocomplet Options for the 'Organization Name' field
		  	var organizationAutoCompleteOptions = {
					serviceUrl: '<?php echo base_url();?>kols/get_organization_names',
					width: 255,
					delimiter: /(,|;)\s*/,
					deferRequestBy: 200, //miliseconds
					noCache: true, //set to true, to disable caching
					minChars: 3
				};		

					
			$(document).ready(function(){

				$.validator.addMethod("alphaNumeric", function(value, element) {
			        return this.optional(element) || /^[a-z0-9\-]+$/i.test(value);
			    }, "This Field must contain only letters, numbers, or dashes.");


				//RTF is disabled as per client request
	    		//Rtf editor for 'Biography' fields
	    		//$('#biographyDummy').css("display", "none").wysiwyg(rtfEditorOptions);
	    		//$('#biographyDummy2').css("display", "none").wysiwyg(rtfEditorOptions);
	    		//$('#biography').wysiwyg(rtfEditorOptions);
	    	
	    		//Rtf editor for 'researchInterests' fields
	    		//$("#researchInterests").wysiwyg(rtfEditorOptions);
	    	
	    		//Rtf editor for 'notes' fields
	    		//$("#notes").wysiwyg(rtfEditorOptions);	
	    						
				//Remove all the 'AutoCompleteContainer' divs' created automatically. If not, too many will get created
				$('div[id^="AutocompleteContainter_"]').remove();
								
				jQuery("#JQBlistContactsResultSet").jqGrid({
					
				   	url:'<?php echo base_url();?>kols/list_contacts',
					datatype: "json",
				   	colNames:['Id','Related To','Phone','email','Action'],
				   	colModel:[
						{name:'id',index:'id', hidden:true},
				   		{name:'related_to',index:'related_to', width:280,editable:true},
				   		{name:'phone',index:'phone',width:300,editable:true},
				   		{name:'email',index:'email',width:280,editable:true},
				   		{name:'act',width:60,search:false}		   			
				   	],
				   	rowNum:10,
				   	rowList:paginationValues,
				   	rownumbers: true,
				   	loadonce:true,
				   	ignoreCase:true,
				   	hiddengrid:false,
				   	height: "auto",		   
				   	pager: '#listContactsPager',
				   	mtype: "POST",
				   	sortname: 'id',
				    viewrecords: true,
				    sortorder: "desc",
				    gridComplete: function(){
					    var ids = jQuery("#JQBlistContactsResultSet").jqGrid('getDataIDs'); 
					    	for(var i=0;i < ids.length;i++){ 
						    	var cl = ids[i];				    	
						    	be = "<a href='#' onclick=\"editContact('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png'></a>";
						    	be += "&nbsp; | &nbsp;";
						    	be += "<a href='#' onclick=\"deleteContact('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png'></a>";

						    	jQuery("#JQBlistContactsResultSet").jqGrid('setRowData',ids[i],{act:be}); 
						    	} 
					    	jQuery("#JQBlistContactsResultSet").jqGrid('navGrid','hideCol',"id"); 
					    	},
			    	loadComplete: function() {
			    	    	$("option[value=100000000]").text('All');
			    		},
				    jsonReader: { repeatitems : false, id: "0" }, 
				    editurl:"<?php echo base_url();?>kols/update_contact",		   
				    caption:"Contact Details"		    
				});
				jQuery("#JQBlistContactsResultSet").jqGrid('navGrid','#listContactsPager',{edit:false,add:false,del:false,search:false,refresh:false});	
				//Toolbar search bar below the Table Headers
				jQuery("#JQBlistContactsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
				//Toolbar search bar above the Table Headers
				//jQuery("#t_JQBlistOthersResultSet").height(25).jqGrid('filterGrid',"JQBlistOthersResultSet",{gridModel:true,gridToolbar:true});
				
				jQuery("#JQBlistContactsResultSet").jqGrid('navGrid','#presize',{edit:false,add:false,del:false});
				jQuery("#JQBlistContactsResultSet").jqGrid('gridResize',{minWidth:550,maxWidth:2000,minHeight:200, maxHeight:550});
				
				//Toggle Toolbar Search 
				jQuery("#JQBlistContactsResultSet").jqGrid('navButtonAdd',"#listContactsPager",{caption:"Search",title:"Toggle Search",
					onClickButton:function(){ 			
						if(jQuery(".ui-search-toolbar").css("display")=="none") {
							jQuery(".ui-search-toolbar").css("display","");
						} else {
							jQuery(".ui-search-toolbar").css("display","none");
						}
						
					} 
				}); 

								
				// Trigger the Autocompleter for 'Organization Name' field
		    	a = $('#org_id').autocomplete(organizationAutoCompleteOptions);
				
				$("#savePersonalInfo").click(function(){
					updateKolOverview();
				});

				$("#saveContactInfo").click(function(){
					updateKolContact();
				});
				$("#saveBiographyInfo").click(function(){
					$('#researchInterests').addClass('required');
					updateKolOverview();
				});
				$("#saveReferenceInfo").click(function(){
					updateKolOverview();
				});

				$('.msgBoxs').ajaxStart(function(){
					$(this).show();
					$(this).fadeIn("fast");
					$(this).removeClass('success');
					$(this).addClass('notice');
					$(this).html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
					
				});
				
				$('.msgBoxs').ajaxComplete(function(){
					$(this).fadeOut(1300);
				});

				$("#uploadImage").dialog(uploadImageDialogOpts);
					
				$("#uploadImageLink").click(
						function (){
							$("#uploadImage").dialog("open");
							return false;
				});

				$("#organizationProfile").dialog(organizationProfileDialogOpts);
					
				$("#organizationProfileLink").click(
						function (){
							$("#organizationProfile").dialog("open");
							return false;
				});				


				/**
				* Save the 'Contact Details'
				*/
				$("#saveContact").click(function(){				
					id = $("#contactId").val();
					var data={};
					data['id']=id;
					data['related_to']	=	$("#contactRelatedTo").val();
					data['phone']		=	$("#contactPhone").val();
					data['email']		=	$("#contactEmail").val();
					data['kol_id']		=	$("#kolId").val();

					$('div.contactMsgBox').removeClass('success');
					$('div.contactMsgBox').addClass('notice');
					$('div.contactMsgBox').show();
					$('div.contactMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
												
					
					if(id == ''){
						formAction = '<?php echo base_url();?>kols/save_contact';
					}else{
						formAction = '<?php echo base_url();?>kols/update_contact';
					}					
				
					 $.post(formAction, data,
							 function(returnData){
					     		if(returnData.saved == true){
									// Clear the existing form details
									$("#contactRelatedTo").val("");
									$("#contactPhone").val("");
									$("#contactEmail").val("");
									
									// If we are updating
									$("tr.ui-state-highlight").removeClass('ui-state-highlight');
									if(id == ''){									
										var datarow = {
														id:returnData.lastInsertId,
														related_to:returnData.data.related_to,
														phone:returnData.data.phone,
														email:returnData.data.email
														
													}; 
										var su=jQuery("#JQBlistContactsResultSet").jqGrid('addRowData',returnData.lastInsertId,datarow); 
										
										}else{
												//jQuery("#JQBlistGovernmentResultSet").trigger("reloadGrid");
												jQuery("#JQBlistContactsResultSet").jqGrid('setRowData',returnData.data.id,{
																		id:returnData.lastInsertId,
																		related_to:returnData.data.related_to,
																		phone:returnData.data.phone,
																		email:returnData.data.email
																						}); 
												$("tr#"+returnData.data.id).addClass('ui-state-highlight');
											}
									
									
									
									
									if(id != ''){
										// Modify the text of 'Button' from 'Update' to 'Add'
										$("#saveContact").val("Add");

										// Re-Set the Hidden Eduction Id value
										$("#contactId").val("");									
									}
									$('div.contactMsgBox').fadeOut(1500);
									$(".contactMsgBox").hide();
						     	}else{
									// Display Error Message
							     }
							},"json");
				});
			});
			//- End of Document.Ready function
			
			function autoResizeGrid(){
				$("#JQBlistContactsResultSet").fluidGrid({ example:".gridContainer", offset:-10 });
				return false;
			}

			/**
			* Edit the 'Contact Details'
			*/
			function editContact(id){
					var rd=jQuery("#JQBlistContactsResultSet").jqGrid('getRowData',id); 
							
					// Get the values from TR - Table Row, which is under editing
					related_to 		= rd.related_to;
					phone			= rd.phone;
					email			= rd.email;
					

					// Add the values to the form
					$("#contactRelatedTo").val(related_to);
					$("#contactPhone").val(phone);
					$("#contactEmail").val(email);

					// Modify the text of 'Button' from 'Add' to 'Update'
					$("#saveContact").val("Update");

					// Set the Hidden Eduction Id value
					$("#contactId").val(id);
					
			

				// Remove the row from the Table
				$("#contact_"+id).remove();
			}

			/**
			* Delete the 'Contact Details'
			*/
			function deleteContact(id){								
				var formAction = '<?php echo base_url();?>kols/delete_contact/'+id;
				jQuery("#JQBlistContactsResultSet").jqGrid('delGridRow',id,{reloadAfterSubmit:false,url:formAction});    		
			}		 

			
			function updateKolOverview(){
				
				if(!$("#overviewForm").validate().form()){
					
					return false;
				}
				formAction = '<?php echo base_url();?>kols/update_kol';
				$(' div.msgBox').removeClass('success');
				$('div.msgBox').addClass('notice');
				$('div.msgBox').show();
				$('div.msgBox').html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
				$.ajax({
					type: "post",
					data: $("#overviewForm").serialize(),
					url: formAction,
					success: function(returnData){
						if(returnData){
							$('div.msgBox').addClass('success');
							$('div.msgBox').text('Updated the data successfully');
						}
					},
					complete: function(){
						$('div.msgBox').fadeOut(1300);
						$(".msgBox").hide();
						$('.formError').hide();
					}
					
				});
			};	

	function updateKolContact(){
				
				if(!$("#contactForm").validate().form()){
					
					return false;
				}
				formAction = '<?php echo base_url();?>kols/update_kol_contact';
				$(' div.msgBox').removeClass('success');
				$('div.msgBox').addClass('notice');
				$('div.msgBox').show();
				$('div.msgBox').html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
				$.ajax({
					type: "post",
					data: $("#contactForm").serialize(),
					url: formAction,
					success: function(returnData){
						if(returnData){
							$('div.msgBox').addClass('success');
							$('div.msgBox').text('Updated the data successfully');
						}
					},
					complete: function(){
						$('div.msgBox').fadeOut(1300);
						$(".msgBox").hide();
						$('.formError').hide();
					}
					
				});
			};	

			/**
			* Validate the text for 'Numeric Only'
			*/
			function allowNumericOnly1(src) {
				if(!src.value.match(/^\+?\d*$/)) {
					//src.value=src.value.replace(/\+?[^0-9]/g,'');
				}
			}

			function allowNumericOnly1(src) {
				if(!src.value.match(/^\+?\d*$/)) {
					src.value=src.value.replace(/\+?[^0-9]/g,'');
				}
			}

			jQuery.validator.addMethod("phoneUS", function(phone_number, element) {
				phone_number = phone_number.replace(/\s+/g, "");
				return this.optional(element) || phone_number.length > 9 &&
				phone_number.match(/^\+?\d*$/);
				}, "Please specify a valid phone number");


			
			$(function(){
				
				$("#overviewForm").validate({
					debug:true,
					onkeyup:true,
					rules: validationRules,
					messages: validationMessages
				});

				$("#contactForm").validate({
					debug:true,
					onkeyup:true,
					rules: validationRulesForContact,
					messages: validationMessagesForContact
				});
			});	
			function resetProfileImage(){
				$.ajax({
					type: "post",
					data: 'kol_id=<?php echo $arrKol['id']?>',
					url: '<?php echo base_url();?>kols/reset_profile_image',
					success: function(returnData){
						if(returnData){
							$('#imageStatusInfo').addClass('success');
							$('#imageStatusInfo').text(returnData);
						}
					},
					complete: function(){
						$('#imageStatusInfo').fadeOut(2300);
					}
				});
			}
		</script>
		
	    <style type="text/css">
			table#additionalContacts label {
				text-align:left;
			}
						
			textarea#url{
				height:20px;
			}
		</style>  		
		
		
		
		<script type="text/javascript">
			$(function() {
				$(".verticalTabs").tabs().addClass( "ui-tabs-vertical ui-helper-clearfix" );
				$(".verticalTabs ul").removeClass( "ui-corner-all");
				$(".verticalTabs ul").addClass( "ui-corner-tr ui-corner-br");
				$(".verticalTabs li").removeClass( "ui-corner-top" ).addClass( "ui-corner-left" );
		
				// Add the Custom Class to control View
				$(".verticalTabs > div").addClass( "verticalTabDataWrapper" );
		
				// As the CustomClass is getting added to some other un-intentional elements, remove that class from them
				$("#kolShortDetails").removeClass("verticalTabDataWrapper");
				$(".profileImage").removeClass("verticalTabDataWrapper");
			});


			$(function() {
				// Initiate the 'Ternary Navigation
				$("#kolOverviewTernaryNav").tabs().addClass("ui-tabs-vertical ui-helper-clearfix" );

				// Remove the Surrounding Border
				$("#kolOverviewTernaryNav" ).removeClass("ui-widget-content");

				// Remove the Round Corner
				$("#kolOverviewTernaryNav ul").removeClass("ui-corner-all ui-widget-header");
				
				$("#kolOverviewTernaryNav li").removeClass( "ui-corner-top" );

				// Add the Custom Class to control View
				$("#kolOverviewTernaryNav > div").addClass( "span-18 last" );

				//Validation to check first letter alphet only
			
			});

			function makeFirstLetterCapltal(value,thisObject){
				var upper = value.charAt(0).toUpperCase();
				var valueWithFirstLetterCap =  value.replace(value[0],upper);
				$(thisObject).val(valueWithFirstLetterCap);
			}	
			
		</script>
		
			
		<div id="kolOverviewTernaryNav">
			<div class="leftBar">
				<?php $this->load->view('elements/kol_short_details');?>
				<a  href="#" style="margin:0px;" id="uploadImageLink">Upload Image</a>
						
				
				<ul  class="span-4 ternaryNav">				
					<li><a href="#profId">Prof Info</a></li>
					<li><a href="#contactInfoId">Contact Info</a></li>
					<li><a href="#biographyId">Biography</a></li>
					<li><a href="#referencesId">References</a></li>                        
				</ul>
			</div>
			<!--  Start of 'Edit Kol Form' Container -->
			<div id="editKolForm"  class="span-19 last" style="margin-left: 15px;">
				<!-- Start of Persnoal and Professional Information -->
				<form action="update_kol" method="post" id="overviewForm" class="validateForm" name="personalForm">
					<input type="hidden" name="kol_id" id="kolId" value="<?php echo $arrKol['id']?>"></input>
					<div id="profId">
						<div class="msgBoxContainer"><div class="msgBox"></div></div>
					 	<h1>Personal and Professional Information</h1>
						<p>
							<label for="npiNum" style="font-size: 20px">Profile Type :</label>
							<input type="radio" name="profile_type" value="Full Profile" <?php if($arrKol['profile_type']=="Full Profile"){?>checked="checked" <?php }?>>Full Profile</input>
							<input type="radio" name="profile_type" value="Basic Plus" <?php if($arrKol['profile_type']=="Basic Plus"){?>checked="checked" <?php }?>>Basic Plus </input>
							<input type="radio" name="profile_type" value="Basic" <?php if($arrKol['profile_type']=="Basic"){?>checked="checked" <?php }?>>Basic</input>
							<input type="radio" name="profile_type" value="User Added" <?php if($arrKol['profile_type']=="User Added"){?>checked="checked" <?php }?>>User Added</input>
							<input type="radio" name="profile_type" value="Legacy" <?php if($arrKol['profile_type']=="Legacy"){?>checked="checked" <?php }?>>Legacy</input>
						</p>
						<table class="analystForm" id="overviewTbl">	
							
							<tr>
								<td>
									
								
								</td>
							</tr>
							<tr>
								<td>	
									<p>
										<label>Salutation:<span class="required">*</span></label>
										<select name="salutation" id="salutation" style=" width: 255px;" class="required">
											<option value="">--- Select ---</option>
												<?php 
												foreach($arrSalutations as $key => $value){
													if($key == $arrKol['salutation'])
														echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
													else
														echo '<option value="'.$key.'">'.$value.'</option>';
												}
												?>
						    			</select>
					    			</p>
								</td>
								<td>
									<p>
										<label for="gender">Gender:<span class="required">*</span></label>
										<select name="gender" id="gender" style=" width: 255px;" class="required">
											<option value="">--- Select ---</option>
											<option value="Male" <?php if($arrKol['gender'] == 'Male') echo 'selected="selected"'?>>Male</option>
											<option value="Female" <?php if($arrKol['gender'] == 'Female') echo 'selected="selected"'?>>Female</option>
								    	</select>
							    	</p>
								</td>
							</tr>	   
									
							<tr>		
								<td>	
									<p>
										<label for="">First Name:<span class="required">*</span></label>
										<input type="text" name="first_name" id="first_name" value="<?php echo $arrKol['first_name'];?>" maxlength="50" class="required gray" onkeyup="makeFirstLetterCapltal(this.value,this)"></input>
									</p>
								</td>
								<td>   
									<p>
										<label for="middle_name">Middle Name:<span class="required">*</span></label>
										<input type="text" name="middle_name" id="middle_name" value="<?php echo $arrKol['middle_name'];?>"  maxlength="50" class="gray" onkeyup="makeFirstLetterCapltal(this.value,this)"></input>
									</p>
								</td>
							</tr>
							<tr>	
								<td>      
									<p>
										<label for="last_name">Last Name:<span class="required">*</span></label>
										<input type="text" name="last_name" id="last_name" value="<?php echo $arrKol['last_name'];?>"  maxlength="50" class="required gray" onkeyup="makeFirstLetterCapltal(this.value,this)"></input>
									</p>
								</td>	       
								<td>
									<p>
										<label for="suffix"">Suffix:</label>
										<input type="text" name="suffix" id="suffix" value="<?php echo $arrKol['suffix'];?>" maxlength="50"/>
									</p>
								</td>
							</tr>
							<tr>	
								<td>										    	
									<p>
										<label for="specialty">Specialty:<span class="required">*</span></label>
										<select name="specialty" id="specialty" class="required" style=" width: 255px;">
											<option value="">--- Select ---</option>
											<?php 
											foreach($arrSpecialties as $key => $value){
											if($key == $arrKol['specialty'])
												echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
											else
												echo '<option value="'.$key.'">'.$value.'</option>';
											}
											?>
										</select>
									</p>
								</td>
								<td>
									<p>
										<label for="sub_specialty">Sub-specialty:</label>
										<input type="text" name="sub_specialty" id="sub_specialty" value="<?php echo $arrKol['sub_specialty'];?>"></input>
									 </p> 
								</td>
							</tr>
							<tr>
								<td>       
									<p>	
										<label for="org_id">Organization Name:<span class="required">*</span></label>
										<input style="vertical-align: top;margin-top: 5px;"  class="required" type="text" name="org_id" id="org_id" value="<?php echo $arrKol['org_id'];?>"></input>
										<a href="<?php echo base_url()?>organizations/add_organization/about" target="_new" ><img style="vertical-align: top;" src="<?php echo base_url();?>images/bullet_add.png" alt="Add New Organization" title="Add New Organization"/></a>
									</p> 
								</td>
								
								<td>	
									<p>
										<label for="contactDivision">Division:</label>
										<input type="text" name="division" id="contactDivision" value="<?php echo $arrKol['division'];?>"></input> 
									 </p>
								</td>
							</tr>	
							<tr>
								<td>
									<p>
										<label for="title">Title: </label>
										<input type="text" name="title" id="title" value="<?php echo $arrKol['title_name'];?>" ></input> 
									</p>
								</td>	     
								<td>      
									<p>
										<label for="license">License#:</label>
										<input type="text" name="license" id="license" value="<?php echo $arrKol['license'];?>"></input>
									</p>
								</td>
							</tr>	
							<tr>
								<td>
									<p>
										<label for="npiNum">NPI Number</label>
										<input type="text" name="npi_num" id="npiNum" value="<?php echo $arrKol['npi_num'];?>"></input>
									</p>
								</td>	     
								<td>
									
								</td>	     
							</tr>	
							
							<tr>		       			
								<td colspan="2">	
									<div class="formButtons">	
										<input type="button" value="Save" name="submit" id="savePersonalInfo"></input>
									</div>
								</td>
							</tr>
						</table>     
					</div>
					<!-- End of Personal and Professional Information -->
				
				
					
               
               
					<!-- Start of Biography and Clinical Research Interests-->
					<div id="biographyId">
						<div class="msgBoxContainer"><div class="msgBox"></div></div>
     		
							<h1>Biography and Clinical Research Interests</h1>
							    
							<p>
								<label for="biography" class="fullWidth">Biography</label>
								<div class="firstTextArea">
									<textarea  class="textArea" rows="25" cols="50" name="biography" id="biography" class="required"><?php echo $arrKol['biography'];?></textarea>
								</div>
							</p>
							
							<p>
								<label for="researchInterests" class="fullWidth">Clinical Research Interests<span class="required">*</span></label>
								<textarea class="textArea" rows="25" cols="50" name="research_interests" id="researchInterests" class=""><?php echo $arrKol['research_interests'];?></textarea>
							</p>
							       
							<div class="formButtons">	
								<input type="button" value="Save" name="submit" id="saveBiographyInfo"></input>
							</div>
					</div>	      
					<!-- End of Biography and Clinical Research Interests-->
    	
					<div id="referencesId">
						<div class="msgBoxContainer"><div class="msgBox"></div></div>
							    
							<h1>Reference Information</h1>
							      
							<p>
								<label for="notes" class="fullWidth">Notes:</label>
								<div class="firstTextArea">
									<textarea class="textArea" rows="8" cols="50" name="notes" id="notes"><?php echo $arrKol['notes'];?></textarea>
								</div>								
							</p>
							       
							<p>
								<label for="url" class="fullWidth">Url </label>
								<textarea class="textArea" rows="8" cols="50" name="url" id="url"><?php echo $arrKol['url'];?></textarea>
							</p>
							       			
							<div class="formButtons">	
								<input type="button" value="Save" name="submit" id="saveReferenceInfo"></input>
							</div>
							      <br />
							      <br />
							      <br />
							      <br />
							 
					</div>
					<!-- End of Reference Information Form-->
				

				</form>
				<!-- End of 'Kol' overview form -->	
				<div class="clear">&nbsp;</div>
				
				<!-- Start of Contact Information -->
					<div id="contactInfoId">
					<form action="update_kol" method="post" id="contactForm" class="validateForm" name="contactForm">		    
						<input type="hidden" name="kol_id" id="kolId" value="<?php echo $arrKol['id']?>"></input>
						<div class="msgBoxContainer"><div class="msgBox"></div></div>
							<h1>Contact Information</h1>
								<table class="analystForm" id="contactTbl">   
									<tr>
										<td>	
											<p>
											
												<label for="primary_phone">Primary Phone:<span class="required">*</span></label>
												<input type="text" name="primary_phone" id="primary_phone" value="<?php echo $arrKol['primary_phone'];?>" onkeyup="allowNumericOnly(this)" class="required gray"></input>
											</p>
										</td>
										<td>
											<p>
												<label for="fax">Fax</label>
												<input type="text" name="fax" id="fax" value="<?php echo $arrKol['fax'];?>" onkeyup="allowNumericOnly(this)"></input>
											</p>
										</td>
									</tr>
									<tr>
										<td>
											<p>
												<label for="primary_email">Primary Email:</label>
												<input type="text" name="primary_email" id="primary_email" value="<?php echo $arrKol['primary_email'];?>" class="email"></input>
											</p>
										</td>
										<td>
										
										</td>       
									</tr>	
									<tr>
										<td>
											<p>
												<label for="address1">Address 1:<span class="required">*</span></label>
												<input type="text" name="address1" id="address1" value="<?php echo $arrKol['address1'];?>" class="required gray"></input>
											</p>
										</td>       
										<td>	       
											<p>
												<label for="address2">Address 2:</label>
												<input type="text" name="address2" id="address2" value="<?php echo $arrKol['address2'];?>" class="gray"></input>
											</p>
										</td>
									</tr>
									<tr>	       
										<td>   
											<p> 
											<label for="country_id">Country:<span class="required">*</span></label>
												<select  style=" width: 255px;" name="country_id" id="country_id" onchange="getStatesByCountryId();" class="required">
													<option value="">-- Select --</option>
													<?php 
													foreach( $arrCountry as $country){
														if($country['country_id'] == $arrKol['country_id'])
															echo '<option value="'.$country['country_id'].'" selected="selected">'.$country['country_name'].'</option>';
														else
															echo '<option value="'.$country['country_id'].'">'.$country['country_name'].'</option>';
													}
													?>
												</select>
											</p>
										</td>   
										<td>													   
											<p>
												<label for="state_id">State:</label>
												<select  style=" width: 255px;" name="state_id" id="state_id" onchange="getCitiesByStateId();" class="">		
													<option value="">-- Select State --</option>
													<?php 
													foreach( $arrStates as $state){
														if($state['state_id'] == $arrKol['state_id'])
															echo '<option value="'.$state['state_id'].'" selected="selected">'.$state['state_name'].'</option>';
														else
															echo '<option value="'.$state['state_id'].'">'.$state['state_name'].'</option>';
													}
													?>
												</select>
												<img id="loadingStates" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
											</p>
										</td>
									</tr>
									<tr>
										<td>	    
											<p>
												<label for="city_id">City:<span class="required">*</span></label>
												<select  style=" width: 255px;" name="city_id" id="city_id" class="required">
													<option value="">-- Select City --</option>
													<?php 
													foreach( $arrCities as $city){
														if($city['city_id'] == $arrKol['city_id'])
															echo '<option value="'.$city['city_id'].'" selected="selected">'.$city['city_name'].'</option>';
														else
															echo '<option value="'.$city['city_id'].'">'.$city['city_name'].'</option>';
													}
													?>												
												</select>
												<img id="loadingCities" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
											</p>
										</td>
										<td>
											<p>
												<label for="postal_code">Postal Code:</label>
												<input type="text" name="postal_code" id="postal_code" value="<?php echo $arrKol['postal_code'];?>" class=""></input>
											</p>
										</td>
									</tr>
									<tr>
										<td>	    
											<p>
												<label for="latitude">Latitude:</label>
												<input type="text" name="latitude" id="latitude" value="<?php echo $latitude;?>" class=""></input>
											</p>
										</td>
										<td>
											<p>
												<label for="longitude">Longitude:</label>
												<input type="text" name="longitude" id="longitude" value="<?php echo $longitude;?>" class=""></input>
											</p>
										</td>
									</tr>
									<tr>
										<td>
											<a onclick="getLatLong();" style="cursor: pointer;">Get Lat & Long</a>
											<img src="<?php echo base_url()?>images/ajax_loader_black.gif" id="latLongLoader"/>
										</td>
									</tr>
									<tr>
										<td>&nbsp;</td>
									</tr>
									<tr>
										<td colspan="2">	    
												<div class="formButtons">	
													<input type="button" value="Save" name="submit" id="saveContactInfo"></input>
												</div>
										</td>
									</tr>
								</table>
					
						<div class="msgBoxContainer"><div class="contactMsgBox"></div></div>
						<h1>Add Additional Contact Details</h1>
						<input type="hidden" name="id" id="contactId" value=""></input>
						
							<table class="analystForm additionalContactsForm">
								<tr>
									<td>	
										<p>
											<label for="contactRelatedTo">Related To:</label>
											<input type="text" name="related_to" value="" id="contactRelatedTo" ></input>
										</p>
									</td>
									
									<td>
										<p>
											<label for="contactPhone">Phone No:</label>
											<input type="text" name="phone" value="" id="contactPhone" onkeyup="allowNumericOnly1(this)" title="enter" class="gray"></input>
										</p>
									</td>
									
									<td>	
										<p>
											<label for="contactEmail">Email:</label>
											<input type="text" name="email" value="" id="contactEmail" class="email"></input>
										</p>
									</td>		
									
									<td colspan="2">
										<br />
										<div class="formButtons">
											<input type="button" value="Add" name="submit" id="saveContact">
	                      				</div>
	                      			</td>
								</tr>						
							</table>
						
						<!--List Contacts details-->
							<!-- Start of JQGrid based Table to list Government Results -->
							<div class="gridWrapper">
								<table id="JQBlistContactsResultSet"></table>
								<div id="listContactsPager"></div>
							</div>						
						</form>
					</div>  
					<!-- End of Contact Information -->
				
			</div>
			<!--  End of 'Edit Kol Form' Container -->
						
		</div> 

		<script type="text/javascript">
			function preview(img, selection) {
				var scaleX = 100 / selection.width; 
				var scaleY = 100 / selection.height; 
				$('#smallImage').css({ 
					width: Math.round(scaleX * 400) + 'px', 
					height: Math.round(scaleY * 300) + 'px',
					marginLeft: '-' + Math.round(scaleX * selection.x1) + 'px', 
					marginTop: '-' + Math.round(scaleY * selection.y1) + 'px' 
				});
				$('#x1').val(selection.x1);
				$('#y1').val(selection.y1);
				$('#x2').val(selection.x2);
				$('#y2').val(selection.y2);
				$('#w').val(selection.width);
				$('#h').val(selection.height);
			} 
			
			$(document).ready(function () { 
				$('#save_thumb').click(function() {
					var x1 = $('#x1').val();
					var y1 = $('#y1').val();
					var x2 = $('#x2').val();
					var y2 = $('#y2').val();
					var w = $('#w').val();
					var h = $('#h').val();
					if(x1=="" || y1=="" || x2=="" || y2=="" || w=="" || h==""){
						jAlert("You must make a selection first");
						return false;
					}else{
						return true;
					}
				});
			}); 
			
		
			function uploadImage(){
				$("#imageUploadProgressBar").show();
				$("#frmUploadImage").submit();
		
				$("#imageUploaderFrame").load(function(){
					$("#imageUploadProgressBar").hide();
					$("#mediumImageContainer").show();
						
					up_output = $(this).contents().find("#output").text();
					if (up_output == "success"){
						up_output += '<br />' + $(this).contents().find("#message").html();
		
						$('#kolUploadImage').val('');
						
						//$("#mediumImageContainer").html(up_output);
						imageSrc	= $(this).contents().find("#imageSrc").html();
						$('#thumbnail').attr('src', imageSrc);
						$('#smallImage').attr('src', imageSrc);
						$('#thumbImagePath').val(imageSrc);
						$('#thumbnail').imgAreaSelect({ aspectRatio: '1:1', onSelectChange: preview }); 
						$('.imgareaselect-outer').css('z-index','9999');
						$('.imgareaselect-selection').css('z-index','9999');
						$('.imgareaselect-border1').css('z-index','9999');
						$('.imgareaselect-border2').css('z-index','9999');
						
					}else if(up_output=='Fail'){
							jAlert("Plese upload only image");
						}
				});
			}

			function getLatLong(){
				$("#latLongLoader").show();
				var address = $("#address1").val();
				var postalCode = $("#postal_code").val();
				var country = $("#country_id option:selected").text();
				var state = $("#state_id option:selected").text();
				var city = $("#city_id option:selected").text();
				var dataString = 'address='+address+'&country='+country+'&state='+state+'&city='+city+'&postalCode='+postalCode;
				$.ajax({
					type: "POST",
					url: "<?php echo base_url()?>kols/get_lat_long_dynamically",
					data: dataString,
					cache: false,
					success: function(jsonResult){
						var result = $.parseJSON(jsonResult);
						if(result){
							$("#latitude").val(result.lat);
							$("#longitude").val(result.lon);
						}else{
							$("#latitude").val('');
							$("#longitude").val('');
							alert("Latitude and Longitude not found for given address");
						}
					},
					complete: function (jsonResult) {
						$("#latLongLoader").hide();
				     }
				});
			}
		
		</script>

	<!-- Modal Container for the 'Upload Image' -->
	<div id="dialog1">	
		<!-- modal content -->
		<div id="uploadImage">
			<!-- creating form for 'Image Upload' modal. --> 
			<form enctype="multipart/form-data" method="post" id="frmUploadImage" action="<?php echo base_url()?>kols/upload_image/<?php echo $kolId ?>" target="imageUploaderFrame">
				<div id="imageStatusInfo"></div>
				<label>Upload Image: </label><input type="file" name="kol_image" id="kolUploadImage"/>
				<input type="button" value="Upload" onClick="uploadImage()" />
				<input type="button" value="Set default Image" onClick="resetProfileImage()" /><br />
				<img src="<?php echo base_url()?>images/image_upload.gif" width="128" height="15" id="imageUploadProgressBar" style="display:none"/>
			</form>
			<br /><br />
			<div align="center" id="mediumImageContainer" style="display:none">
				<div style="width:400px; height:300px;">
					<p class="imageUploadText">Preview and Crop</p>
					<img id="thumbnail" src="upload_pic/resized_pic.jpg" alt="Create Thumbnail"/>
				</div>
				<div style="float:left; position:relative; overflow:hidden; width:100px; height:100px; display: none;">
					<p class="imageUploadText">Preview</p>
					<img id="smallImage" src="upload_pic/resized_pic.jpg" style="position: relative;" alt="Thumbnail Preview" />
				</div>
				<br style="clear:both;"/>
				<form name="thumbnail"  action="<?php echo base_url()?>kols/crop_image" method="post">
					<input type="hidden" name="x1" value="" id="x1" />
					<input type="hidden" name="y1" value="" id="y1" />
					<input type="hidden" name="x2" value="" id="x2" />
					<input type="hidden" name="y2" value="" id="y2" />
					<input type="hidden" name="w" value="" id="w" />
					<input type="hidden" name="h" value="" id="h" />
					<input type="hidden" name="thumbImagePath" value="" id="thumbImagePath" />
					<br /><br /><br />
					<input type="submit" class="button" name="upload_thumbnail" value="Save Thumbnail" id="save_thumb" />
				</form>
			</div>
			<!-- End of the modal content for the 'Image Upload' form -->
		</div>
	</div>
	<!-- End of Modal Container for the 'Upload Image' -->
	
	<div id="dailog2">	
		<!-- modal content -->
		<div id="organizationProfile">
			<!-- creating form for 'Organization' modal. --> 
				<?php //echo $this->load->view('organizations/add_organization');?>
			<!-- End of the modal content for the 'Image Upload' form -->
		</div>
	</div>
	
	<iframe id="imageUploaderFrame" name="imageUploaderFrame" style="display:none"></iframe>
	