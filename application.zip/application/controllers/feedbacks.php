<?php
/**
 * File Description : controller for feedback
 * 
 * @author		Laxman K
 * @since		5.0
 * @Created on  Aug 21, 2012
 */


class Feedbacks extends Controller{
 	private $loggedUserId	= null;
 	//Constructor
	function Feedbacks(){
		parent::Controller();
		$this->load->model('feedback');
		$this->load->model('interaction');
		$this->loggedUserId	= $this->session->userdata('user_id');
		$this->load->helper('File');
	}
	
	
	function add_feedback(){
		$data['arrFeedbackTypes'] = $this->feedback->getFeedbackTypes();		
		$this->load->view('feedbacks/add',$data);
	}
	
	function save_feedback(){
		$arrData['type_id'] = $this->input->post('feedback_type');
		$arrData['client_id']	= $this->session->userdata('client_id');
		$arrData['subject']	= $this->input->post('subject');
		$arrData['description']= trim($this->input->post('description'));
		$arrData['created_by']	= $this->loggedUserId;
		$arrData['created_on']	= date('Y-m-d H:i:s');
		//$target_path = "documents/feedbacks";
		$target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/feedbacks";
		if($_FILES["feedback_file"]['name']!=null && $_FILES["feedback_file"]['name']!=""){
			//Get the file information, use for file validations like allowed file type, file size etc
			$path_info = pathinfo($_FILES["feedback_file"]['name']);
			$path_info['size']=$_FILES["feedback_file"]['size'];
			//Generate a random name
			$newFileName	= random_string('unique', 20).".".$path_info['extension'];
			$overview_file_target_path = $target_path ."/". $newFileName; 
			//Move uploaded file in to interactions document location
			if (move_uploaded_file($_FILES['feedback_file']['tmp_name'], $overview_file_target_path)){
				$arrData['file_type']	= get_mime_by_extension($newFileName);
				$arrData['file_name'] = $_FILES["feedback_file"]['name'];
				$arrData['file_path']	= $newFileName;
			}
		}
		if($this->feedback->saveFeedbackDetails($arrData)){
			//$this->send_feedback_email($arrData);
			$data['status']=$this->create_ticket($arrData);
			//$data['status']='Sent';
		}else{
			$data['status']='Failed';
		}
		echo $data['status'];
	}
	
	
	function list_feedbacks(){
		//$data['arrFeedbackInfo'] = $this->feedback->getAllFeedbackOfLoggedUser($this->loggedUserId);
		//Add Log activity
		$arrLogDetails = array(
				'type' => LIST_RECORD,
				'description' => "Visited List Feedbacks Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View List Feedbacks Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$data['contentPage']	= 'feedbacks/list_feedbacks';
		$this->load->view('layouts/analyst_view',$data);
	}

	function list_feedbacks_grid(){
		$page				= (int)$this->input->post('page'); // get the requested page 
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$arrFeedbackDetails = array();
		$data 				= array();
		
		if($arrFeedbackDetails = $this->feedback->getAllFeedbacks()){
			foreach($arrFeedbackDetails as $row){
				//$row['action']		= '<div class="actionIcon editIcon"><a href="'.base_url().'kols/edit_kol/'.$row['id'].'" title="Edit">&nbsp;</a></div><div class="actionIcon deleteIcon"><a onclick="deleteSelectedKols('.$row['id'].');" href="#" title="delete">&nbsp;</a></div>';
			/*	if($row['type_id']==1){
					$row['feedback_type']='Software';
				}elseif($row['type_id']==2){
					$row['feedback_type'] = 'Suggestion';
				}else{
					$row['feedback_type'] = 'Content';
				}
			*/
				$arrFileExtension	= explode('.',$row['file_path']);
				if($row['file_name']!=""){
					$row['file_name']='<a href="'.base_url().'feedbacks/file_download/'.$row['id'].'">'.$row['file_name'].'</a>';
				}
				$arrFeedbackDetail[] = $row;
			}
			$count=sizeof($arrFeedbackDetails);				
			if( $count >0 ){ 
				$total_pages = ceil($count/$limit); 
			}else{ 
				$total_pages = 0; 
			} 
			$data['records']= $count;
			$data['total']  = $total_pages;
			$data['page']	= $page;
			$data['rows']	= $arrFeedbackDetail;			
		}
		echo json_encode($data);
	}
	
	
	function file_download($feedbackId=0){
		if($feedbackId!=0){
			$arrData	= $this->feedback->getFeedbackDetails($feedbackId);
			$this->load->helper('download');
			$data =  file_get_contents($_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/feedbacks/".$arrData['file_path']);
		//	echo $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/feedbacks/".$arrData[0]['file_path'];
			$extension	= explode('.',$arrData['file_path']);
			force_download($arrData['file_name'].'.'.$extension[1],$data);
		}
	}
	
/*	
	function send_feedback_email($arrData){

//		$feedbackReceiverMailId  = 'ITHelp@Otsuka-us.com';
		$clientId = $this->session->userdata('client_id');
		$feedbackReceiverMailId  = $this->feedback->getSupportEmailIdByClientId($clientId);//FEEDBACK_EMAIL_ID;
		if(empty($feedbackReceiverMailId)){
			$feedbackReceiverMailId = "support@aissel.com";
		}
		$config['protocol']  = PROTOCOL;
		$config['smtp_host'] = HOST;         
		$config['smtp_port'] = PORT;
		$config['smtp_user'] = USER;
		$config['smtp_pass'] = PASS;
		$config['mailtype']	 = 'html';
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		//$this->email->clear(true);
		$userFullName = $this->session->userdata('user_full_name');
		$userEmail	= $this->session->userdata['email'];
		$userName	= $this->session->userdata['user_name'];
		$this->load->model('Client_User');
		$clientName	= $this->Client_User->getClientName($arrData['client_id']);
		
        $this->email->subject(PRODUCT_VERSION.' ticket submitted by user - '.$userName.'('.$clientName.')');
        $this->email->from(USER,$userFullName);
        $this->email->to($feedbackReceiverMailId);
        $this->email->reply_to($userEmail, $userFullName);
        $emailData	= 'Subject : '.$arrData['subject'].'<br />';
        $emailData	.= 'Description : '.$arrData['description'].'<br />';
        $this->email->message($emailData);
        if(isset($arrData['file_path'])){
	        $attachedDoc = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/feedbacks/".$arrData['file_path'];
	        $this->email->attach($attachedDoc,'attachment');
        }
        $this->email->set_crlf("\r\n");
      //  echo $feedbackReceiverMailId."--".$clientName."--".$userEmail."--".USER."--".$userName;exit;
        if($this->email->send()){
			$data['status'] = "Success";
		}else{
			$data['status'] = "Sending e mail failed";
         	//echo $this->email->print_debugger();
		}
		echo json_encode($data);
	}*/
function send_feedback_email($arrData){
		$clientId = $this->session->userdata('client_id');
		$feedbackReceiverMailId  = $this->feedback->getSupportEmailIdByClientId($clientId);//FEEDBACK_EMAIL_ID;
		$config['protocol']  = PROTOCOL;
		$config['smtp_host'] = HOST;         
		$config['smtp_port'] = PORT;
		$config['smtp_user'] = USER;
		$config['smtp_pass'] = PASS;
		$config['mailtype']	 = 'html';
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		//$this->email->clear(true);

		$userEmail	= $this->session->userdata['email'];
		$userName	= $this->session->userdata['user_name'];
		$this->load->model('Client_User');
		$clientName	= $this->Client_User->getClientName($arrData['client_id']);
        $this->email->subject(PRODUCT_NAME.' ticket submitted by user - '.$userName.'('.$clientName.')');
        $this->email->from($userEmail,$userEmail);
        $this->email->to($feedbackReceiverMailId);
        $emailData	= 'Subject : '.$arrData['subject'].'<br />';
        $emailData	.= 'Description : '.$arrData['description'].'<br />';
        $this->email->message($emailData);
        if(isset($arrData['file_path'])){
	        $attachedDoc = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/feedbacks/".$arrData['file_path'];
	        $this->email->attach($attachedDoc,'attachment');
        }

        if($this->email->send()){
			$data['status'] = "Success";
		}else{
			$data['status'] = "Sending e mail failed";
         	echo $this->email->print_debugger();
		}
		echo json_encode($data);
	}
	
	function create_ticket($arrData){
		$api_key = "FOcTo2EyLXCqds250";
		$password = "aisselon1323";
		$yourdomain = "aisselkolm";
		$userEmail	= $this->session->userdata['email'];
		$userName	= $this->session->userdata['user_name'];
		$clientId = $this->session->userdata('client_id');
		$this->load->model('Client_User');
		$clientName	= $this->Client_User->getClientName($clientId);
		$description	= 'Subject : '.$arrData['subject'].'<br />';
        $description	.= 'Description : '.$arrData['description'].'<br />';
        $arrFeedbackTypes = $this->feedback->getFeedbackTypes();
		$ticket_payload = array(
			'email' => $userEmail,
			'subject' => PRODUCT_NAME.' ticket submitted by user - '.$userName.'('.$clientName.')',
		//	'priority' => 2,
		//	'attachments[]' =>  curl_file_create("data/x.png", "image/png", "x.png"),
			'status' => 2,
			'type'	=> $arrFeedbackTypes[$arrData['type_id']]['name'],
			'description' => $description
		);
		if(isset($arrData['file_path'])){
	        $attachedDoc = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."/documents/feedbacks/".$arrData['file_path'];
	        $ticket_payload['attachments[]']	=	curl_file_create($attachedDoc, "image/png", $arrData['file_path']);
        }
		//pr($arrFeedbackTypes);
		//pr($ticket_payload);
		$header[] = "Content-type: application/json";
		$url = "https://$yourdomain.freshdesk.com/api/v2/tickets";	//v2/ticket_fields
	    $curl = curl_init($url);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	    curl_setopt($curl, CURLOPT_HEADER, false);
	    curl_setopt($curl, CURLOPT_POST, true);
	    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
	    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	    curl_setopt($curl, CURLOPT_USERPWD, "$api_key:$password");
	    curl_setopt($curl, CURLOPT_POSTFIELDS, $ticket_payload);
	    $server_output = curl_exec($curl);
	    $info = curl_getinfo($curl);
		$header_size = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
		$headers = substr($server_output, 0, $header_size);
		$response = substr($server_output, $header_size);
		curl_close($curl);
		if($info['http_code'] == 201) {
		  /*echo "Ticket created successfully, the response is given below \n";
		  echo "Response Headers are \n";
		  echo $headers."\n";
		  echo "Response Body \n";
		  echo "$response \n";*/
			return 'Success';
		} else {
		  /*if($info['http_code'] == 404) {
		    echo "Error, Please check the end point \n";
		  } else {
		    echo "Error, HTTP Status Code : " . $info['http_code'] . "\n";
		    echo "Headers are ".$headers;
		    echo "Response are ".$response;
		  }*/
			return 'Failed';
		}
	}
	
}