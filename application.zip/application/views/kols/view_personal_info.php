<?php
/**
 * Shows the client added kols personal info , if there is no info then shows add button
 * 
 * @author Ramesh B
 * @since	2.2
 * @created: 05-05-2011
 */
?>
<style>
	.microView p {
		margin:0 0 4px;
		float: left;
		width:100%;
	}
	
	.personalInfoContainer #viewFamilyInfo,.personalInfoContainer #viewContactInfo,.personalInfoContainer #viewInterestInfo,.personalInfoContainer #viewUploadInfo {
		float: left;
		clear: both;
		width: 100%;
		border-bottom: 0px dotted;
	}
	
	.personalInfoContainer div#viewFamilyInfo div div{
		width: 24%;
		float: left;
	}

	.personalInfoContainer #viewFamilyInfo p,.personalInfoContainer #viewContactInfo p {
		width: 25%;
		float:left;
		text-align:left;
		color: #777777;
	}
	
	.personalInfoContainer #viewFamilyInfo p label,.personalInfoContainer #viewContactInfo p label{
		width: 47%;
		text-align: right;
		float: left;
		padding-right:10px;
	}
	
	.personalInfoContainer #viewInterestInfo td {
		width: 50%;
	}
	
	.personalInfoContainer #viewInterestInfo td label{
		float: left;
		width: 23%;
		padding-right:10px;
		text-align: right;
	}
	
	.personalInfoContainer #viewInterestInfo td input{
		width: 60%;
	}
	
	.personalInfoContainer fieldset {
		margin: 0px;
		border: 1px solid #969696;
		padding: 0 0 0 10px;
	}
	
	.personalInfoContainer fieldset legend{
		margin-left:15px;
		padding-left:5px;
		padding-right:5px;
		font-size: 12px;
		color: #333333;
	}
	
	.personalInfoContainer input:disabled {
		border: 0px;
		color: #626262;
	}
	
	div#viewPersonalInfo {
		border:0px solid #EEEEEE;
		padding: 10px;
		color:#626262;
		min-height: 500px;
		width: 98%;
		padding-top:0px;
	}
	
	.personalInfoContainer div.viewUploadedFiles p{
		float: left;
		width: 12%;
		padding-left:5px;
		text-align:left;
	}
	
</style>

<script type="text/javascript">
	$(document).ready(function(){
		var personalInfoModalOptions = {
			title: "Personal Info",
			modal: true,
			autoOpen: false,
			width: 800,
			position: ['center', modalBoxTopPosition],
			dialogClass: "microView",
			open: function() {
				//display correct dialog content
			}
		};

		$("#personalInfoModalBox").dialog(personalInfoModalOptions);
		
	});

	function addAnotherUpload(){
		var noOfFiles=0;
		$('#addPersonalInfoForm .uploadContainer').each(function(){
			noOfFiles++;
		});
		var uploadedFiles=0;
		$('#addPersonalInfoForm .uploadedFiles').each(function(){
			uploadedFiles++;
		});
		var fileNumber=noOfFiles-uploadedFiles;
		if(noOfFiles<5){
			fileNumber++;
			noOfFiles++;
			var newUpload="<div id=\"uploadFileds\" class=\"uploadContainer\"><p><label for=docName"+fileNumber+">Doc Name:</label>	<input type=\"text\" name=\"doc_name"+fileNumber+"\" id=\"docName"+fileNumber+"\" /></p><p><label for=\"description"+fileNumber+"\">Description:</label><input type=\"text\" name=\"description"+fileNumber+"\" id=\"description"+fileNumber+"\" /></p><p><label for=\"filePath"+fileNumber+"\">Upload:</label><input type=\"file\" name=\"file_path"+fileNumber+"\" id=\"filePath"+fileNumber+"\"></input></p><label id=\"addMoreFile\" onclick=\"deleteFile(this);\"><img src=\"<?php echo base_url();?>images/delete.png\" alt=\"Delete\" title=\"Delete\"/></label></div>";
			$("#addPersonalInfoForm #uploadInfoFieldSet").append(newUpload);
			$("#uploadInfo input[name='no_of_files']").val(noOfFiles);
		} else {
			jAlert('Maximum Limit(5 files) Reached');
		}
	}

	//deletes the document with given document id
	function deleteDocument(documentId){
		var noOfFiles=$("#uploadInfo input[name='no_of_files']").val();
		jConfirm("Confirm Delete ?","Please confirm",function(r){
				if(r){
					$.ajax({
						url:'<?php echo base_url();?>kols/delete_personal_info_doc/'+documentId,
						dataType:'json',
						success:function(returnData){
							if(returnData==true){
								$("#doc"+documentId).remove();
								$("#viewDoc"+documentId).remove();
								noOfFiles--;
								$("#uploadInfo input[name='no_of_files']").val(noOfFiles);
								if(noOfFiles==5){
									$("#uploadInfo input[name='file_path1']").removeAttr('disabled');
								}
							}
						}
					});
					}else{
						return false;	
						}
			});
	}
	//deletes the document with given document id
	function deleteViewDocument(documentId){
		jConfirm("Confirm Delete ?","Please confirm",function(r){
				if(r){
					$.ajax({
						url:'<?php echo base_url();?>kols/delete_personal_info_doc/'+documentId,
						dataType:'json',
						success:function(returnData){
							if(returnData==true){
								$("#viewDoc"+documentId).remove();
							}
						}
					});
					}else{
						return false
					}
			});
	}

	function showAddPersonalInfoBox(){
		$("#personalInfoModalBox .profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#personalInfoModalBox").dialog("open");
		$("#personalInfoModalBox .profileContent").load('<?php echo base_url()?>kols/add_personal_info');
		return false;	
	}

	function showEditPersonalInfoBox(){
		$('div.ui-widget-content').each(function(){
			$(this).html();
		});
		$("#personalInfoModalBox .profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#personalInfoModalBox").dialog("open");
		$("#personalInfoModalBox .profileContent").load('<?php echo base_url()?>kols/edit_personal_info');
		return false;	
	}

	function deleteFile(object){
		$(object).parent().remove();
	}
</script>

<!-- If Personal Info is blank then show add Button -->
<?php if(isset($kolPersonalInfo) && sizeof($kolPersonalInfo)==0) {?>
	<div class="addLink" style="float: right;">
		<label onclick="showAddPersonalInfoBox();">
			<div class="actionIcon addIcon"></div>
			Add Personal Info
		</label>
	</div>
<?php } else {?>
<!-- If Personal Info is Not blank then DisPlay Details and show Edit Button -->
	
	<div id="viewPersonalInfo" class="personalInfoContainer">
		<div class="exportOptionsContainer">
			<ul class="pageRightOptions">
				<li>
					<input type="button" id="editButton" value="Edit" name="edit_button" onclick="showEditPersonalInfoBox();"/>
				</li>
			</ul>
		</div>
		<?php if(isset($kolPersonalInfo)) {?>
			<input type="hidden" name="personal_info_id" value="<?php echo $kolPersonalInfo['id'];?>">
		<?php }?>
		<!-- Family Info -->
		<div id="viewFamilyInfo">
		<fieldset><legend>Family</legend>
			<div>
				<p>
					<label for=spouseName>Spouse Name:</label>
					<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['spouse_name'];?>
				</p>
				<p>
					<label for=gender>Gender:</label>
					<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['gender'];?>
				</p>
				<p>
					<label for=birthday>Birthday:</label>
					<?php if($kolPersonalInfo['birthday']!='0000-00-00') echo $this->common_helpers->convertDateToMM_DD_YYYY($kolPersonalInfo['birthday']);?>
				</p>
				<p>
					<label for=languages>Languages Known:</label>
					<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['languages'];?>
				</p>
				<p>
					<label for=hometown>Hometown:</label>
					<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['home_town'];?>
				</p>
				<p>
					<label for=anniversary>Anniversary:</label>
					<?php if($kolPersonalInfo['anniversary']!='0000-00-00') echo $this->common_helpers->convertDateToMM_DD_YYYY($kolPersonalInfo['anniversary']);?>
				</p>
				<p>
					<label for=children>Children:</label>
					<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['children'];?>
				</p>
				<p>
					<label for=pets>Pets:</label>
					<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['pets'];?>
				</p>
			</div>
		</fieldset>
		</div>
		<!-- Contact Info -->
		<div id="viewContactInfo">
		<fieldset><legend>Contact</legend>
			<p>
				<label for=homePhone>Home Phone:</label>
				<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['home_phone'];?>
			</p>
			<p>
				<label for=cellPhone>Cell Phone:</label>
				<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['cell_phone'];?>
			</p>
			<p>
				<label for=IMScreenName1>IM Screen Name:</label>
				<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['IM_screen_name1'];?>
			</p>
			<p>
				<label for=IMScreenName2>IM Screen Name:</label>
				<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['IM_screen_name2'];?>
			</p>
		</fieldset>
		</div>
		<!-- Interests Info -->
		<div id="viewInterestInfo">
		<fieldset><legend>Interest</legend>
			<table>
				<tr>
					<td>
						<p>
							<label for=specialInterests>Special Interests:</label>
							<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['special_interests'];?>
						</p>
					</td>
					<td>
						<p>
							<label for=sports>Sports:</label>
							<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['sports'];?>
						</p>
					</td>
				</tr>
				<tr>
					<td>
						<p>
							<label for=music>Music:</label>
							<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['music'];?>
						</p>
					</td>
					<td>
						<p>
							<label for=activities>Activities:</label>
							<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['activities'];?>
						</p>
					</td>
				</tr>
				<tr>
					<td>
						<p>
							<label for=books>Books:</label>
							<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['books'];?>
						</p>
					</td>
					<td>
						<p>
							<label for=vacation>Vacation:</label>
							<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['vacation'];?>
						</p>
					</td>
				</tr>
				<tr>
					<td>
						<p>
							<label for=journals>Journals:</label>
							<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['journals'];?>
						</p>
					</td>
					<td>
						<p>
							<label for=magazines>Magazines:</label>
							<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['magazines'];?>
						</p>
					</td>
				</tr>
			</table>
		</fieldset>
		</div>
		<!-- Upload Info -->
		<div id="viewUploadInfo">
		<fieldset id="viewUploadInfoFieldSet"><legend>Uploads</legend>
			<?php if(isset($arrDocuments) && sizeof($arrDocuments)>0){
				foreach($arrDocuments as $documentDetails){	?>
				<div class="uploadContainer viewUploadedFiles" id="viewDoc<?php echo $documentDetails['id'];?>">
					<p>
						<?php $fileDetails=explode('.',$documentDetails['doc_path']);
							switch($fileDetails[1]){
								case 'xlsx'		: $fileDetails[1]='xls';break;
								case 'docsx'	: $fileDetails[1]='doc';break;
							}
							$fileExt=$fileDetails[1];
							$imagePath	= base_url().'images/'.$fileExt.'_img.bmp';
							if (!file_exists($imagePath)) {
							    $imagePath	= base_url().'images/file_icon.jpg';
							}
						?>
						<a href="<?php echo base_url()?>kols/download_file/<?php echo $documentDetails['doc_path'];?>" class="removeLabel" target="_new" title="download"><img alt="File Type" src="<?php echo $imagePath;?>" width="25px" /></a><br />
						<?php echo $documentDetails['description'];?><br />
						<?php echo $documentDetails['doc_name'].".".$fileExt;?>
							<label class="removeLabel" onclick="deleteViewDocument(<?php echo $documentDetails['id'];?>);"><img src="<?php echo base_url();?>images/delete.png" alt="Delete" title="Delete"/></label>
						<br />
					</p>
					<!--  
					<p>
						<label>Description:</label>
						<?php echo $documentDetails['description'];?>
					</p>
					<p>
						<a href="<?php echo base_url()?>kols/dounload_file/<?php echo $documentDetails['doc_path'];?>" class="removeLabel" >View</a>
					</p>
					-->
				</div>
			<?php }}?>				
		</fieldset>
		</div>
	</div>

<?php }?>

<!-- Add Or Edit Personal Info Model Box -->
<div id="personalInfoModalBox">
	<div class="profileContent"></div>
</div>