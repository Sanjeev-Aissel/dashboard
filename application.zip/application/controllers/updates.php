<?php
/**
*Controller for update operations
*@author Ramesh B
*@since 4.2
*@package application.controllers	
*@created on 05-07-2012
*/

class Updates extends Controller{
	
	function Updates(){
		parent:: Controller();
		$this->load->model('pubmed');
		$this->load->model('clinical_trial');
		$this->load->model('kol');
		$this->load->model('interaction');
		$this->load->model('payment');
		$this->load->model('organization');
		$this->load->model('survey');
		$this->load->model('common_helpers');
	}
	
	
	/**
	 * Fetches the updates with the given limits
	 * @author 	Ramesh B
	 * @since June 2 2012
	 * @version 4.2
	 * @params 
	 * @return unknown_type
	 */	
	function show_updates(){
		$this->load->model('kol');
		$this->load->model('Client_User');
		$startFrom = $this->input->post('start_from');
		$limit = 100;
		if($startFrom == null || $startFrom == '')
			$startFrom = '0';
		$categoryId = $this->input->post('category_id');
		if($categoryId == null || $categoryId == '')
			$categoryId = '0';

		$kolId		 = $this->input->post("kol_id");
		$kolId = $this->common_helpers->getKolidOrUniqueId($kolId);
		$viewType		 = $this->input->post("view_type");
//                pr($viewType);
//                eixt;
		
		//by default show only mycontacts updates
		if($this->input->post('start_from') == null)
			$viewType = MY_RECORDS;
		$this->load->model('kol','');
		if($viewType != null && $viewType == MY_RECORDS){
			$viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
			if(sizeof($viewMyKols) == 0)
				$viewMyKols = array(0);
				
			$viewType = $viewMyKols;
		}else{
			$viewType = array();
		}
			
		$clientId = $this->session->userdata('client_id');
		$data['clientUsers']	= $this->Client_User->getUsers($clientId);	

		if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN){
			$userId = $this->input->post('user_id');
			$startDate = $this->common_helpers->convertDateToYYYY_MM_DD($this->input->post('start_date'));
			if($startDate == null || $startDate == '' || $startDate == '--')
				$startDate = null;
			$endDate = $this->common_helpers->convertDateToYYYY_MM_DD($this->input->post('end_date'));
			if($endDate == '--')
				$endDate = null;
			$data['arrUpdates'] = $this->update->listUpdates($startFrom, $limit, $categoryId, $kolId, $viewType, $userId, $startDate, $endDate);
//                        pr($data['arrUpdates']);
//                        exit;
		}else{
			$data['arrUpdates'] = $this->update->listUpdates($startFrom, $limit, $categoryId, $kolId, $viewType);
		}
		//$data['contentPage'] 	=	'updates/recent_updates';
		//$data['contentPage'] 	=	'updates/recent_updates_new';
		//$data['contentPage'] 	=	'updates/recent_updates_new1';
		$data['contentPage'] 	=	'updates/recent_activity';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited recent activity Page",
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
				'kols_or_org_id' => $kolId,
				'transaction_name' => "View recent activity"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$data['startFrom'] = $startFrom;
		if($this->input->post('start_from') == null){
			$arrModules = array();
			$arrModules["kols"] = 'KTL';
            //$arrModules["Organization"] = 'HCO';
			$arrModules["coaching"] = 'Field Coaching';
			//$arrModules["Compliance"] = 'Compliance Monitoring';
			$arrModules["interactions"] = 'Interactions';
			//$arrModules["Speaker Evaluation"] = 'Speaker Evaluation';
			//$arrModules["Medical Insight"] = 'Medical Insight';
              $arrModules["notifications"] = 'Notifications';
              $arrModules["payments"] = 'Payments';
              $arrModules["contracts"] = 'Contracts';
              $arrModules["plannings"] = 'Plans';
             // $arrModules["objective"] = 'Objectives';
                     
			//$arrModules[MODULE_INTERACTION] = 'Interaction';
			//$arrModules[MODULE_PAYMENT] = 'Payment';
			$data['arrModules'] = $arrModules;
			
			$this->load->view('layouts/client_view', $data);
		}
		else{
			
			$this->load->view('updates/update_element', $data);
		}
	}
	
	
	/**
	 * Fetches the updates with the given limits
	 * @author 	Ramesh B
	 * @since June 2 2012
	 * @version 4.2
	 * @params 
	 * @return unknown_type
	 */	
	function show_updates_analyst(){
		$this->common_helpers->checkUsers();
		$this->load->model('kol');
		$this->load->model('Client_User');
		$startFrom = $this->input->post('start_from');
		$limit = 30;
		if($startFrom == null || $startFrom == '')
			$startFrom = '0';
		$categoryId = $this->input->post('category_id');
		if($categoryId == null || $categoryId == '')
			$categoryId = '0';
		
		$kolId		 = $this->input->post("kol_id");
		$viewType		 = $this->input->post("view_type");
		
		$this->load->model('kol','');
		if($viewType != null && $viewType == MY_RECORDS){
			$viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
			if(sizeof($viewMyKols) == 0)
				$viewMyKols = array(0);
				
			$viewType = $viewMyKols;
		}else{
			$viewType = array();
		}
		
		$clientId = $this->session->userdata('client_id');
		$data['clientUsers']	= $this->Client_User->getUsers($clientId);	

		if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN){
			$userId = $this->input->post('user_id');
			$startDate = $this->common_helpers->convertDateToYYYY_MM_DD($this->input->post('start_date'));
			if($startDate == null || $startDate == '' || $startDate == '--')
				$startDate = null;
			$endDate = $this->common_helpers->convertDateToYYYY_MM_DD($this->input->post('end_date'));
			if($endDate == '--')
				$endDate = null;
			$data['arrUpdates'] = $this->update->listUpdates($startFrom, $limit, $categoryId, $kolId, $viewType, $userId, $startDate, $endDate);
		}else{
			$data['arrUpdates'] = $this->update->listUpdates($startFrom, $limit, $categoryId, $kolId, $viewType);
		}
		$data['contentPage'] 	=	'updates/recent_updates';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited Recent Updates Page",
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
				'kols_or_org_id' => $kolId,
				'transaction_name' => "View Recent Updates"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$data['startFrom'] = $startFrom;
		if($this->input->post('start_from') == null){
			$arrModules = array();
			$arrModules["kol_overview"] = 'Overview';
			$arrModules["kol_education"] = 'Education';
			$arrModules["kol_affiliation"] = 'Affiliation';
			$arrModules["kol_event"] = 'Event';
			$arrModules["kol_publication"] = 'Publication';
			$arrModules["kol_trial"] = 'Trial';
			//$arrModules[MODULE_INTERACTION] = 'Interaction';
			//$arrModules[MODULE_PAYMENT] = 'Payment';
			$data['arrModules'] = $arrModules;
			$this->load->view('layouts/analyst_view', $data);
		}
		else{
			$this->load->view('updates/update_element', $data);
		}
	}
	
	
	/**
	 * Prepares the detaild updates details by fetches the updates entry for the given updates type, parent and date
	 * @author 	Ramesh B
	 * @since June 6 2012
	 * @version 4.2
	 * @params 
	 * @return unknown_type
	 */	
	function get_detailed_updates(){
		$updateType = $this->input->post('utype');
		$parentObjectId = $this->input->post('pid');
		$createdDay = $this->input->post('cday');
		$createdBy = $this->input->post('cby');
		
		$arrUpdateEntries = $this->update->getUpdatesByParam($updateType, $parentObjectId, $createdDay, $createdBy);
		//pr($arrUpdateEntries);
		$updateEntryhtml = "";
		switch ($updateType){
			case KOL_PROFILE_IMPORT : 	foreach($arrUpdateEntries as $update){
											$updateEntryhtml .= "<div class='update-row-detailed'>";
											$updateEntryhtml .= $update['object_id'];
											$updateEntryhtml .= "</div>";
										}
									 	break;
			case "New HCP" : 		foreach($arrUpdateEntries as $update){
											$updateEntryhtml .= "<div class='update-row-detailed'>";
											$updateEntryhtml .= $update['object_id'];
											$updateEntryhtml .= "</div>";
										}
									 	break;
			case KOL_PROFILE_DELETE : 	foreach($arrUpdateEntries as $update){
											$updateEntryhtml .= "<div class='update-row-detailed'>";
											$updateEntryhtml .= $update['object_id'];
											$updateEntryhtml .= "</div>";
										}
									 	break;
			case "Update HCP" : 	foreach($arrUpdateEntries as $update){
													$updateEntryhtml .= "<div class='update-row-detailed'>";
													$updateEntryhtml .= $update['object_id'];
													$updateEntryhtml .= "</div>";
												}
											 	break;
			case KOL_PROFILE_CONTACT_ADD :	foreach($arrUpdateEntries as $update){
												$updateEntryhtml .= "<div class='update-row-detailed'>";
												$updateEntryhtml .= $update['object_id'];
												$updateEntryhtml .= "</div>";
											}
										 	break;
			case KOL_PROFILE_CONTACT_UPDATE : 	foreach($arrUpdateEntries as $update){
													$updateEntryhtml .= "<div class='update-row-detailed'>";
													$updateEntryhtml .= $update['object_id'];
													$updateEntryhtml .= "</div>";
												}
											 	break;
			case KOL_PROFILE_CONTACT_DELETE : 	foreach($arrUpdateEntries as $update){
													$updateEntryhtml .= "<div class='update-row-detailed'>";
													$updateEntryhtml .= "</div>";
												}
											 	break;
			case KOL_PROFILE_EDUCATION_ADD : 	foreach($arrUpdateEntries as $update){
													$education	=	$this->kol->getEducationById($update['object_id']);
													$updateEntryhtml .=$this->prepareEducationUpdateEntry($education);
												}
											 	break;
			case KOL_PROFILE_EDUCATION_UPDATE : foreach($arrUpdateEntries as $update){
													$education	=	$this->kol->getEducationById($update['object_id']);
													$updateEntryhtml .=$this->prepareEducationUpdateEntry($education);
												}
											 	break;
			case KOL_PROFILE_EDUCATION_DELETE : foreach($arrUpdateEntries as $update){
													$education	=	$this->kol->getEducationById($update['object_id']);
													$updateEntryhtml .=$this->prepareEducationUpdateEntry($education);
												}
											 	break;
			case KOL_PROFILE_AFFILITION_ADD : 	foreach($arrUpdateEntries as $update){
													$updateEntryhtml .= "<div class='update-row-detailed'>";
													$affiliation	=	$this->kol->getAffiliationById($update['object_id']);
													$updateEntryhtml .= "<div class='text-line'>".$affiliation['name']."</div>";
													$updateEntryhtml .= "<div onclick='viewAffMicroProfile(".$update['object_id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Affiliation Snapshot'>&nbsp;</a></div>";
													$updateEntryhtml .= "</div>";
												}
											 	break;
			case KOL_PROFILE_AFFILITION_UPDATE : 	foreach($arrUpdateEntries as $update){
														$updateEntryhtml .= "<div class='update-row-detailed'>";
														$affiliation	=	$this->kol->getAffiliationById($update['object_id']);
														$updateEntryhtml .= "<div class='text-line'>".$affiliation['name']."</div>";
														$updateEntryhtml .= "<div onclick='viewAffMicroProfile(".$update['object_id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Affiliation Snapshot'>&nbsp;</a></div>";
														$updateEntryhtml .= "</div>";
													}
												 	break;
			case KOL_PROFILE_AFFILITION_DELETE : 	foreach($arrUpdateEntries as $update){
														$updateEntryhtml .= "<div class='update-row-detailed'>";
														$affiliation	=	$this->kol->getAffiliationById($update['object_id']);
														$updateEntryhtml .= "<div class='text-line'>".$affiliation['name']."</div>";
														$updateEntryhtml .= "<div onclick='viewAffMicroProfile(".$update['object_id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Affiliation Snapshot'>&nbsp;</a></div>";
														$updateEntryhtml .= "</div>";
													}
												 	break;
			case KOL_PROFILE_EVENT_ADD : 	foreach($arrUpdateEntries as $update){
												$updateEntryhtml .= "<div class='update-row-detailed'>";
												$event	=	$this->kol->getEventById($update['object_id']);
												$updateEntryhtml .= "<div class='text-line'>".$event['name']."</div>";
												$updateEntryhtml .= "<div onclick='viewEventMicroProfile(".$update['object_id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Event Snapshot'>&nbsp;</a></div>";
												$updateEntryhtml .= "</div>";
											}
										 	break;
			case KOL_PROFILE_EVENT_UPDATE : 	foreach($arrUpdateEntries as $update){
													$updateEntryhtml .= "<div class='update-row-detailed'>";
													$event	=	$this->kol->getEventById($update['object_id']);
													$updateEntryhtml .= "<div class='text-line'>".$event['name']."</div>";
													$updateEntryhtml .= "<div onclick='viewEventMicroProfile(".$update['object_id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Event Snapshot'>&nbsp;</a></div>";
													$updateEntryhtml .= "</div>";
												}
											 	break;
			case KOL_PROFILE_EVENT_DELETE : foreach($arrUpdateEntries as $update){
												$updateEntryhtml .= "<div class='update-row-detailed'>";
												$event	=	$this->kol->getEventById($update['object_id']);
												$updateEntryhtml .= "<div class='text-line'>".$event['name']."</div>";
												$updateEntryhtml .= "<div onclick='viewEventMicroProfile(".$update['object_id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Event Snapshot'>&nbsp;</a></div>";
												$updateEntryhtml .= "</div>";
											}
										 	break;
			case KOL_PROFILE_SOCIAL_MEDIA_UPDATE : 	foreach($arrUpdateEntries as $update){
														$updateEntryhtml .= "<div class='update-row-detailed'>";
														$arrKolDetails = $this->kol->getKolDetailsById($update['object_id']);
														$arrKolDetails = $arrKolDetails[0];
														if($arrKolDetails['blog'] != '');
															$updateEntryhtml .= $arrKolDetails['blog']."<br>";
														if($arrKolDetails['linked_in'] != '');
															$updateEntryhtml .= $arrKolDetails['linked_in']."<br>";
														if($arrKolDetails['facebook'] != '');
															$updateEntryhtml .= $arrKolDetails['facebook']."<br>";
														if($arrKolDetails['twitter'] != '');
															$updateEntryhtml .= $arrKolDetails['twitter']."<br>";
														if($arrKolDetails['you_tube'] != '');
															$updateEntryhtml .= $arrKolDetails['you_tube'];
														$updateEntryhtml .= "</div>";
													}
												 	break;
			case KOL_PROFILE_PUBLICATION_ADD : foreach($arrUpdateEntries as $update){
													$updateEntryhtml .= "<div class='update-row-detailed'>";
													$publication=$this->pubmed->getPublicationDetail($update['object_id']);
													$updateEntryhtml .= "<div class='text-line'>".$publication['article_title']."</div>";
													$updateEntryhtml .= "<div onclick='viewPubMicroProfile(".$update['object_id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Publication Snapshot'>&nbsp;</a></div>";
													$updateEntryhtml .= "</div>";
												}
											 	break;
			case KOL_PROFILE_PUBLICATION_DELETE : 	foreach($arrUpdateEntries as $update){
														$updateEntryhtml .= "<div class='update-row-detailed'>";
														$publication=$this->pubmed->getKolPublicationDetail($update['object_id']);
														$updateEntryhtml .= "<div class='text-line'>".$publication['article_title']."</div>";
														$updateEntryhtml .= "<div onclick='viewPubMicroProfile(".$publication['id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Publication Snapshot'>&nbsp;</a></div>";
														$updateEntryhtml .= "</div>";
													}
												 	break;
			case KOL_PROFILE_PUBLICATION_VERIFY : 	foreach($arrUpdateEntries as $update){
														$updateEntryhtml .= "<div class='update-row-detailed'>";
														$publication=$this->pubmed->getKolPublicationDetail($update['object_id']);
														$updateEntryhtml .= "<div class='text-line'>".$publication['article_title']."</div>";
														$updateEntryhtml .= "<div onclick='viewPubMicroProfile(".$publication['id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Publication Snapshot'>&nbsp;</a></div>";
														$updateEntryhtml .= "</div>";
													}
												 	break;
			case KOL_PROFILE_PUBLICATION_UNVERIFY : 	foreach($arrUpdateEntries as $update){
															$updateEntryhtml .= "<div class='update-row-detailed'>";
															$publication=$this->pubmed->getKolPublicationDetail($update['object_id']);
															$updateEntryhtml .= "<div class='text-line'>".$publication['article_title']."</div>";
															$updateEntryhtml .= "<div onclick='viewPubMicroProfile(".$publication['id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Publication Snapshot'>&nbsp;</a></div>";
															$updateEntryhtml .= "</div>";
														}
													 	break;
			case KOL_PROFILE_PUBLICATION_UPDATE : 	foreach($arrUpdateEntries as $update){
															$updateEntryhtml .= "<div class='update-row-detailed'>";
															$publication=$this->pubmed->getPublicationDetail($update['object_id']);
															$updateEntryhtml .= "<div class='text-line'>".$publication['article_title']."</div>";
															$updateEntryhtml .= "<div onclick='viewPubMicroProfile(".$publication['id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Publication Snapshot'>&nbsp;</a></div>";
															$updateEntryhtml .= "</div>";
														}
													 	break;
			case KOL_PROFILE_TRIAL_ADD : 	foreach($arrUpdateEntries as $update){
												$updateEntryhtml .= "<div class='update-row-detailed'>";
												$trial	=	$this->clinical_trial->getClinicalTrial($update['object_id']);
												$updateEntryhtml .= "<div class='text-line'>".$trial['trial_name']."</div>";
												$updateEntryhtml .= "<div onclick='viewClinicalTrialMicroProfile(".$update['object_id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Clinical Trial Snapshot'>&nbsp;</a></div>";
												$updateEntryhtml .= "</div>";
											}
										 	break;
			case KOL_PROFILE_TRIAL_UPDATE : 	foreach($arrUpdateEntries as $update){
													$updateEntryhtml .= "<div class='update-row-detailed'>";
													$trial	=	$this->clinical_trial->getClinicalTrial($update['object_id']);
													$updateEntryhtml .= "<div class='text-line'>".$trial['trial_name']."</div>";
													$updateEntryhtml .= "<div onclick='viewClinicalTrialMicroProfile(".$update['object_id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Clinical Trial Snapshot'>&nbsp;</a></div>";
													$updateEntryhtml .= "</div>";
												}
											 	break;
			case KOL_PROFILE_TRIAL_DELETE : 	foreach($arrUpdateEntries as $update){
													$updateEntryhtml .= "<div class='update-row-detailed'>";
													$trial	=	$this->clinical_trial->getClinicalTrial($update['object_id']);
													$updateEntryhtml .= "<div class='text-line'>".$trial['trial_name']."</div>";
													$updateEntryhtml .= "<div onclick='viewClinicalTrialMicroProfile(".$update['object_id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Clinical Trial Snapshot'>&nbsp;</a></div>";
													$updateEntryhtml .= "</div>";
												}
											 	break;
			case KOL_PERSONAL_INFO_ADD : 	foreach($arrUpdateEntries as $update){
												$updateEntryhtml .= "<div class='update-row-detailed'>";
												$updateEntryhtml .= $update['object_id'];
												$updateEntryhtml .= "</div>";
											}
										 	break;
			case KOL_PERSONAL_INFO_UPDATE : 	foreach($arrUpdateEntries as $update){
													$updateEntryhtml .= "<div class='update-row-detailed'>";
													$updateEntryhtml .= $update['object_id'];
													$updateEntryhtml .= "</div>";
												}
											 	break;
	
			case ORG_IMPORT : 	$orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
								$updateEntryhtml .="Imported Organization <a href='".base_url()."/organization/view/".$update['object_id']."'>".$orgName."</a> ";
									 	break;
			case "New Organization" : 	$orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
								$updateEntryhtml .="Added Organization <a href='".base_url()."/organization/view/".$update['object_id']."'>".$orgName."</a> ";
									 	break;
			case ORG_DELETE : 	$orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
								$updateEntryhtml .="Deleted Organization ";
									 	break;	
			case ORG_ABOUT_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
										$updateEntryhtml .="Updated Organization <a href='".base_url()."/organization/view/".$update['object_id']."'>".$orgName."</a> ";
									 	break;
			case ORG_ADDRESS_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
										$updateEntryhtml .="Updated Address information for organization <a href='".base_url()."/organization/view/".$update['object_id']."'>".$orgName."</a> ";
									 	break;	
			case ORG_CONTACT_ADD : 		$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
										$updateEntryhtml .="Added ".$update['number']." Contact information for organization <a href='".base_url()."/organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
									 	break;
			case ORG_CONTACT_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
										$updateEntryhtml .="Updated ".$update['number']." Contact information for organization <a href='".base_url()."/organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
									 	break;	
			case ORG_CONTACT_DELETE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
										$updateEntryhtml .="Deleted ".$update['number']." Contact information for organization <a href='".base_url()."/organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
									 	break;
			case ORG_SOCIAL_MEDIA_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
											$updateEntryhtml .="Updated Social Media information for organization <a href='".base_url()."/organization/view/".$update['object_id']."'>".$orgName."</a> ";
									 		break;
			case ORG_KEY_PEOPLE_ADD : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
										$updateEntryhtml .="Added ".$update['number']." Key People information for organization <a href='".base_url()."/organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
									 	break;	
			case ORG_KEY_PEOPLE_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
											$updateEntryhtml .="Updated ".$update['number']." Key People information for organization <a href='".base_url()."/organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
										 	break;
			case ORG_KEY_PEOPLE_DELETE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
											$updateEntryhtml .="Deleted ".$update['number']." Key People information for organization <a href='".base_url()."/organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
										 	break;
										 	
		 	case ORG_PUBLICATION_ADD : foreach($arrUpdateEntries as $update){
										$updateEntryhtml .= "<div class='update-row-detailed'>";
										$publication=$this->pubmed->getPublicationDetail($update['object_id']);
										$updateEntryhtml .= "<div class='text-line'>".$publication['article_title']."</div>";
										$updateEntryhtml .= "<div onclick='viewPubMicroProfile(".$update['object_id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Publication Snapshot'>&nbsp;</a></div>";
										$updateEntryhtml .= "</div>";
									}
								 	break;
			 	
 			case ORG_PUBLICATION_UPDATE : 	foreach($arrUpdateEntries as $update){
														$updateEntryhtml .= "<div class='update-row-detailed'>";
														$publication=$this->pubmed->getPublicationDetail($update['object_id']);
														$updateEntryhtml .= "<div class='text-line'>".$publication['article_title']."</div>";
														$updateEntryhtml .= "<div onclick='viewPubMicroProfile(".$publication['id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Publication Snapshot'>&nbsp;</a></div>";
														$updateEntryhtml .= "</div>";
													}
											 	break;
			case ORG_PUBLICATION_VERIFY : 	foreach($arrUpdateEntries as $update){
														$updateEntryhtml .= "<div class='update-row-detailed'>";
														$publication=$this->pubmed->getOrgPublicationDetail($update['object_id']);
														$updateEntryhtml .= "<div class='text-line'>".$publication['article_title']."</div>";
														$updateEntryhtml .= "<div onclick='viewPubMicroProfile(".$publication['id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Publication Snapshot'>&nbsp;</a></div>";
														$updateEntryhtml .= "</div>";
													}
												 	break;
			case ORG_PUBLICATION_UNVERIFY : 	foreach($arrUpdateEntries as $update){
															$updateEntryhtml .= "<div class='update-row-detailed'>";
															$publication=$this->pubmed->getOrgPublicationDetail($update['object_id']);
															$updateEntryhtml .= "<div class='text-line'>".$publication['article_title']."</div>";
															$updateEntryhtml .= "<div onclick='viewPubMicroProfile(".$publication['id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Publication Snapshot'>&nbsp;</a></div>";
															$updateEntryhtml .= "</div>";
														}
													 	break;								 	
											 	
			case ORG_TRIAL_ADD : 	foreach($arrUpdateEntries as $update){
												$updateEntryhtml .= "<div class='update-row-detailed'>";
												$trial	=	$this->clinical_trial->getClinicalTrial($update['object_id']);
												$updateEntryhtml .= "<div class='text-line'>".$trial['trial_name']."</div>";
												$updateEntryhtml .= "<div onclick='viewClinicalTrialMicroProfile(".$update['object_id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Clinical Trial Snapshot'>&nbsp;</a></div>";
												$updateEntryhtml .= "</div>";
											}
										 	break;
			case ORG_TRIAL_UPDATE : 	foreach($arrUpdateEntries as $update){
													$updateEntryhtml .= "<div class='update-row-detailed'>";
													$trial	=	$this->clinical_trial->getClinicalTrial($update['object_id']);
													$updateEntryhtml .= "<div class='text-line'>".$trial['trial_name']."</div>";
													$updateEntryhtml .= "<div onclick='viewClinicalTrialMicroProfile(".$update['object_id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Clinical Trial Snapshot'>&nbsp;</a></div>";
													$updateEntryhtml .= "</div>";
												}
											 	break;
	 	
			case USER_ADD : $user = $this->Client_User->editUser($update['object_id']);	
							$updateEntryhtml .="Added User ".$user['first_name'];
									 	break;
			case USER_UPDATE : 	$user = $this->Client_User->editUser($update['object_id']);	
							$updateEntryhtml .="Updated User ".$user['first_name'];
									 	break;
			case USER_DELETE : 	$updateEntryhtml .="Deleted User";
									 	break;		
			case CLIENT_ADD : 	$updateEntryhtml .="Added Client";
									 	break;
			case CLIENT_UPDATE : 	$updateEntryhtml .="Updated Client";
									break;
			case CLIENT_DELETE : 	$updateEntryhtml .="Updated Client";
									break;
															
			case KOL_LIST_CREATE : 	$updateEntryhtml .="Updated Client";
									break;
			case KOL_LIST_UPDATE : 	$updateEntryhtml .="Updated Client";
									break;
			case KOL_LIST_ADD : 	$updateEntryhtml .="Updated Client";
									break;																		
			case KOL_LIST_DELETE : 	$updateEntryhtml .="Updated Client";
									break;
	
			case OBJECTIVE_ADD : 	$updateEntryhtml .="Updated Client";
									break;
			case OBJECTIVE_UPDATE : 	$updateEntryhtml .="Updated Client";
									break;																		
			case OBJECTIVE_DELETE : 	$updateEntryhtml .="Updated Client";
									break;
	
			case PLAN_ADD : 	$updateEntryhtml .="Updated Client";
									break;
			case PLAN_UPDATE : 	$updateEntryhtml .="Updated Client";
									break;																		
			case PLAN_DELETE : 	$updateEntryhtml .="Updated Client";
									break;
	
			case "New Interaction" : 	foreach($arrUpdateEntries as $update){
										$updateEntryhtml .= "<div class='update-row-detailed'>";
										$interactionDetails=$this->interaction->getInteractionDetails($update['object_id']);
										$interactionDetails['objective_name']	= '';
										$separator	= '';
										foreach($interactionDetails['aboutTopics']['objective_names'] as $key=>$name){
											$interactionDetails['objective_name'] .= $separator.$name;
											$separator	= ', ';
										}
										$updateEntryhtml .= "<div class='text-line'>".$interactionDetails['objective_name'].", ".$interactionDetails['date']."</div>";
										$updateEntryhtml .= "<div id='micro-intr".$update['object_id']."' onclick='viewInteractionMicroProfile(".$update['object_id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Interaction Snapshot'>&nbsp;</a></div>";
										$updateEntryhtml .= "</div>";
									}
									break;
			case INTERACTION_UPDATE : 	foreach($arrUpdateEntries as $update){
											$updateEntryhtml .= "<div class='update-row-detailed'>";
											$interactionDetails=$this->interaction->getInteractionDetails($update['object_id']);
											$interactionDetails['objective_name']	= '';
											$separator	= '';
											foreach($interactionDetails['aboutTopics']['objective_names'] as $key=>$name){
												$interactionDetails['objective_name'] .= $separator.$name;
												$separator	= ', ';
											}
											$updateEntryhtml .= "<div class='text-line'>".$interactionDetails['objective_name'].", ".$interactionDetails['date']."</div>";
											$updateEntryhtml .= "<div id='micro-intr".$update['object_id']."' onclick='viewInteractionMicroProfile(".$update['object_id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Interaction Snapshot'>&nbsp;</a></div>";
											$updateEntryhtml .= "</div>";
										}
										break;																		
			case INTERACTION_DELETE : 	$updateEntryhtml .="Updated Client";
									break;
	
			case PAYMENT_ADD : 	foreach($arrUpdateEntries as $update){
									$updateEntryhtml .= "<div class='update-row-detailed'>";
									$paymentDetails=$this->payment->getPaymentById($update['object_id']);
									$updateEntryhtml .= "<div class='text-line'>".$paymentDetails['date'].", ".$paymentDetails['reason'].", ".$paymentDetails['payment']."</div>";
									$updateEntryhtml .= "<div id='micro-payment".$update['object_id']."' onclick='viewPaymentMicroProfile(".$update['object_id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Payment Snapshot'>&nbsp;</a></div>";
									$updateEntryhtml .= "</div>";
								}
								break;	
			case PAYMENT_UPDATE : 	foreach($arrUpdateEntries as $update){
										$updateEntryhtml .= "<div class='update-row-detailed'>";
										$paymentDetails=$this->payment->getPaymentById($update['object_id']);
										$updateEntryhtml .= "<div class='text-line'>".$paymentDetails['date'].", ".$paymentDetails['reason'].", ".$paymentDetails['amount']."</div>";
										$updateEntryhtml .= "<div id='micro-payment".$update['object_id']."' onclick='viewPaymentMicroProfile(".$update['object_id']."); return false;' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Payment Snapshot'>&nbsp;</a></div>";
										$updateEntryhtml .= "</div>";
									}
									break;																	
			case PAYMENT_DELETE : 	$updateEntryhtml .="Updated Client";
									break;
	
			case EVENT_ADD : 	$updateEntryhtml .="Updated Client";
									break;
			case EVENT_UPDATE : 	$updateEntryhtml .="Updated Client";
									break;																		
			case EVENT_DELETE : 	$updateEntryhtml .="Updated Client";
									break;
	
			case CONTRACT_ADD : 	$updateEntryhtml .="Updated Client";
									break;
			case CONTRACT_UPDATE : 	$updateEntryhtml .="Updated Client";
									break;																		
			case CONTRACT_DELETE : 	$updateEntryhtml .="Updated Client";
									break;
																	
			case CALENDER_EVENT_ADD : 	$updateEntryhtml .="Updated Client";
									break;
			case CALENDER_EVENT_UPDATE : 	$updateEntryhtml .="Updated Client";
									break;																		
			case CALENDER_EVENT_DELETE : 	$updateEntryhtml .="Updated Client";
									break;								
	
			default:$updateEntryhtml .="................";
							break;	
		}
		
		echo $updateEntryhtml;
	}
	
	function prepareEducationUpdateEntry($education){
		$updateEntryhtml = "<div class='update-row-detailed'>";
		$education['date']	=	'';
		if($education['start_date'] != '')
			$education['date']	.=	$education['start_date'];
		else
			$education['date']	.=	'NA';
			
	//	if(($education['start_date'] != '') && ($education['end_date']))
			$education['date']	.=	" - ";
		
		if($education['end_date'] != '')
			$education['date']	.=	$education['end_date'];
		else
			$education['date']	.=	'NA';
		
		if($education['date']=='NA - NA'){
			$education['date']	=	'Not Available';
		}
		$updateEntryhtml .= "<div class='text-line'>";
		if($education['name'] != '')
			$updateEntryhtml .= $education['name'];
		if($education['honor_name'] != '')
			$updateEntryhtml .= $education['honor_name'];
		if($education['degree'] != '')
			$updateEntryhtml .= ", ".$education['degree'];
		if($education['specialty'] != '')
			$updateEntryhtml .= ", ".$education['specialty'];
		if($education['date'] != '')
			$updateEntryhtml .= ", ".$education['date'];
		$updateEntryhtml .= "</div>";
		//$updateEntryhtml .= "<div onclick='viewPubMicroProfile(".$update['object_id'].")' class='tooltip-demo tooltop-right microViewIcon'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Publication Snapshot'>&nbsp;</a></div>";
		$updateEntryhtml .= "</div>";
		
		return $updateEntryhtml;
	}
	
	function update_activity_status(){
		$updateType = $this->input->post('utype');
		$parentObjectId = $this->input->post('pid');
		$createdDay = $this->input->post('cday');
		$createdBy = $this->input->post('cby');
		$publishStatus = $this->input->post('publish_status');
		
		$isUpdates = $this->update->updateActivityStatus($updateType, $parentObjectId, $createdDay, $createdBy, $publishStatus);
		echo $isUpdates;
	}
	
	function delete_activities(){
		$updateType = $this->input->post('utype');
		$parentObjectId = $this->input->post('pid');
		$createdDay = $this->input->post('cday');
		$createdBy = $this->input->post('cby');
		$publishStatus = $this->input->post('publish_status');
		
		$isDeleted = $this->update->deleteActivitiesByParam($updateType, $parentObjectId, $createdDay, $createdBy);
		echo $isDeleted;
	}
	
	function update_selected_activities(){
		$arrSlectedActivities = $this->input->post('selected_activities');
		$publishStatus = $this->input->post('publish_status');
		foreach ($arrSlectedActivities as $activity){
			$activityElements = explode("/",$activity);
			$createdBy = $activityElements[0];
			$updateType = $activityElements[1];
			$parentObjectId = $activityElements[2];
			$createdDay = $activityElements[3];
			$isUpdates = $this->update->updateActivityStatus($updateType, $parentObjectId, $createdDay, $createdBy, $publishStatus);
		}
	}
	
	
	function delete_selected_activities(){
		$arrSlectedActivities = $this->input->post('selected_activities');
		foreach ($arrSlectedActivities as $activity){
			$activityElements = explode("/",$activity);
			$createdBy = $activityElements[0];
			$updateType = $activityElements[1];
			$parentObjectId = $activityElements[2];
			$createdDay = $activityElements[3];
			$isDeleted = $this->update->deleteActivitiesByParam($updateType, $parentObjectId, $createdDay, $createdBy);
		}
	}
	
}