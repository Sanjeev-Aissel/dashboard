<?php
/**
 * @Author : Sanjeev K
 * @Desc : Model for Organization from analyst module
 * @Since : KOLM_hmvc 1.0
 * @Package : application.models
 * @Created : 12-06-2018
 * @Refactored : 13-06-2018
 */
class Organization extends CI_Model {
	
	/**
	 * @Author : Sanjeev K
	 * @Method : saveOrganization()
	 * @param  : $organizationDetails
	 * @return : last inserted org id
	 */
	function saveOrganization($organizationDetails){
		$orgName = '';
		$orgName = $organizationDetails['name'];
		$this->db->where('name',$orgName);
		if(isset($organizationDetails['cin_num'])){
			$this->db->where('cin_num',$organizationDetails['cin_num']);
		}
		if($arrOrganization = $this->db->get('organizations')){
			if($arrOrganization->num_rows!=0){
				$result=$arrOrganization->row();
				if($result!=null)
					$id=$result->id;
					$organizationDetails['id']	= $id;
					$this->updateImportedOrganization($organizationDetails);
					return $id;
			}else{
				if($this->db->insert('organizations',$organizationDetails)){
					return $this->db->insert_id();
				}else{
					return false;
				}
			}
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : saveLocation()
	 * @param  : $arrLocation
	 * @return : last inserted org location id
	 */
	function saveLocation($arrLocation) {
		if(isset($arrLocation['id'])) {
			$id = $arrLocation['id'];
			unset($arrLocation['id']);
			if($arrLocation["is_primary"] == "1") {
				$primary_flag = array('is_primary' => 0);
				$this->db->where('org_id',$arrLocation['org_id']);
				$this->db->update('org_locations',$primary_flag);
			}
	
			$this->db->where('id',$id);
			if($this->db->update('org_locations',$arrLocation)){
				return true;
			}else{
				return false;
			}
		} else {
	
			if($arrLocation["is_primary"] == "1") {
				$primary_flag = array('is_primary' => 0);
				$this->db->where('org_id',$arrLocation['org_id']);
				$this->db->update('org_locations',$primary_flag);
			}
	
			if($this->db->insert('org_locations',$arrLocation)){
				return $this->db->insert_id();
			}else{
				return false;
			}
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getAllOrganizationTypes()
	 * @param  : none
	 * @return : array of org types
	 */
	function getAllOrganizationTypes(){
		$arrOrganizationTypes	= array();
	
		$arrOrganizationTypesResult = $this->db->get('organization_types');
		foreach($arrOrganizationTypesResult->result_array() as $arrOrganizationType){
			$arrOrganizationTypes[$arrOrganizationType['id']]	= $arrOrganizationType['type'];
		}
		return $arrOrganizationTypes;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : updateOrgTypeForOrganization()
	 * @param  : $arrData
	 * @return : On update returns true, or false
	 */
	function updateOrgTypeForOrganization($arrData) {
		$this->db->where('id',$arrData['id']);
		$result = $this->db->update('organizations',$arrData);
		if($result)
			return true;
			else
				return false;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : listOrganizationGridDetails()
	 * @param  : $limit,$start,$doCount,$sidx,$sord,$whereResultArray
	 * @return : all kols orgs to client
	 */
	function listOrganizationGridDetails($limit=null,$startFrom=null,$doCount=null,$sidx = '',$sord = '',$where = ''){
		if(!$doCount){
				$this->db->select(array('organizations.*','client_users.user_name as user_full_name','countries.country','organization_types.type','org_client_visibility.id AS ovid'));
			}
			$this->db->join('client_users', 'client_users.id = organizations.created_by', 'left');
			$this->db->join('organization_types', 'organization_types.id = organizations.type_id', 'left');
			$this->db->join('countries','countries.countryId = organizations.country_id', 'left');
			$this->db->join('org_client_visibility','org_client_visibility.org_id = organizations.id', 'left');
				
			//Add the where conditions for any jqgrid filters
			if(isset($where['name'])){
				$this->db->where("(organizations.name LIKE '%".$where['name']."%')");
			}
			if(isset($where['founded'])){
				$this->db->like('organizations.founded',$where['founded']);
			}
			if(isset($where['type'])){
				$this->db->like('organization_types.type',$where['type']);
			}
			if(isset($where['is_pubmed_processed'])){
				if(preg_match("/[yes]{1,}/i",$where['is_pubmed_processed']))
					$where['is_pubmed_processed'] = 1;
				elseif(preg_match("/[no]{1,}/i",$where['is_pubmed_processed']))
					$where['is_pubmed_processed'] = 0;
				elseif(preg_match("/[recrawl]{1,}/i",$where['is_pubmed_processed']))
					$where['is_pubmed_processed'] = 2;
				$this->db->like('organizations.is_pubmed_processed',$where['is_pubmed_processed']);
			}
			if(isset($where['is_clinical_trial_processed'])){
				if(preg_match("/[yes]{1,}/i",$where['is_clinical_trial_processed']))
					$where['is_clinical_trial_processed'] = 1;
				elseif(preg_match("/[no]{1,}/i",$where['is_clinical_trial_processed']))
					$where['is_clinical_trial_processed'] = 0;
				$this->db->like('organizations.is_clinical_trial_processed',$where['is_clinical_trial_processed']);
			}
			if(isset($where['profile_type'])){
				if(preg_match("/[basic]{1,}/i",$where['profile_type']))
					$where['profile_type'] = 1;
				elseif(preg_match("/[full]{1,}/i",$where['profile_type']))
					$where['profile_type'] = 2;
				$this->db->like('organizations.profile_type',$where['profile_type']);
			}
			if(isset($where['created_by'])){
				$this->db->like('client_users.user_name',$where['created_by']);
			}
			if(isset($where['status'])){
				$this->db->like('organizations.status',$where['status']);
			}
		
			//Client specific condition
			$analystSelectedclientId = $this->session->userdata('analyst_client');
			$this->db->where('org_client_visibility.client_id', $analystSelectedclientId);
	//		$this->db->where("(client_users.client_id=".INTERNAL_CLIENT_ID." or kols.status='".COMPLETED."')");
		
			if($doCount){
				/* $this->db->distinct(); */
				$count=$this->db->count_all_results('organizations');
				return $count;
			} else {
				if($sidx!='' && $sord!=''){
					switch($sidx){
						case 'name' : $this->db->order_by("organizations.name",$sord);
						   				break;
						case 'status' :$this->db->order_by("organizations.status",$sord);
						   				break;
						case 'type_id' :$this->db->order_by("organization_types.type",$sord);
						   				break;
						case 'is_pubmed_processed' :$this->db->order_by("organizations.is_pubmed_processed",$sord);
						   				break;
						case 'is_clinical_trial_processed' :$this->db->order_by("organizations.is_clinical_trial_processed",$sord);
						   				break;	
						case 'profile_type' :$this->db->order_by("organizations.profile_type",$sord);
						   				break;	
						case 'created_by' :$this->db->order_by("client_users.user_name",$sord);
						   				break;
						case 'status' :$this->db->order_by("organizations.status",$sord);
						   				break;
					}
					//$this->db->order_by($sidx,$sord);
				}
				$this->db->order_by('name','asc');
			
				$arrOrgDetail	=	$this->db->get('organizations',$limit,$startFrom);
				return $arrOrgDetail;
			}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getOrgs()
	 * @param  : columnName, columnValue, searchType (WHERE / LIKE / FIND_IN_SET)
	 * @return : data matching the search criteria. ( SearchType on columnName = columnValue )
	 */
	function getOrgs($colName=null, $colValue=null, $searchType = null) {
		if($colName != null && $colValue != null && $searchType != null){
			switch(strtoupper($searchType)){
				Case "WHERE":
					$this->db->where($colName, $colValue);
					break;
				Case "LIKE":
					$this->db->like($colName, $colValue);
					break;
				Case "FIND_IN_SET":
					$this->db->where('id IS NOT NULL',' AND find_in_set('.$colValue.','.$colName.')',false);
					break;
			}
		}
		$this->db->order_by('name');
		$query = $this->db->get('organizations');
		return $query->result_array();
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getAllKeyPeopleRoles()
	 * @param  : none
	 * @return : array of Key People Roles
	 */
	function getAllKeyPeopleRoles(){
		$arrKeyPeopleRoles	= array();
	
		$arrKeyPeopleRolesResult = $this->db->get('key_people_roles');
		foreach($arrKeyPeopleRolesResult->result_array() as $arrKeyPeopleRole){
			$arrKeyPeopleRoles[$arrKeyPeopleRole['id']]	= $arrKeyPeopleRole['role'];
		}
		return $arrKeyPeopleRoles;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : editOrganization()
	 * @param  : $id
	 * @return : array of Organization Detail
	 */
	function editOrganization($id){
		$arrOrganizationDetail	= array();
		$this->db->select('organizations.*, org_client_visibility.id AS ovid');
		$this->db->join('org_client_visibility','org_client_visibility.org_id = organizations.id', 'left');
		$this->db->where('org_client_visibility.id',$id);
		if($arrOrganizationDetailResult	=	$this->db->get('organizations')){
			// If the results are not available
			if($arrOrganizationDetailResult->num_rows() == 0){
				return false;
			}
	
			foreach($arrOrganizationDetailResult->result_array() as $arrOrganization){
				if($arrOrganization['postal_code']=='0'){
					$arrOrganization['postal_code']='';
				}
				$arrOrganizationDetail	= $arrOrganization;
			}
			//                pr($arrOrganizationDetail);
			return $arrOrganizationDetail;
		}else{
			return false;
		}
	}

	/**
	 * @Author : Sanjeev K
	 * @Method : listContacts()
	 * @param  : $orgId
	 * @return : array of Contact Details
	 */
	function listContacts($orgId = null){
		if($orgId != null){
			$this->db->where('org_id', $orgId);
	
	
			if($arrContactDetails = $this->db->get('org_additional_contacts')){
				return $arrContactDetails;
			}
		}else{
			return false;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : updateOrganization()
	 * @param  : $organizationDetails, $affPartnershipDetails = 0
	 * @return : On update returns true, or false
	 */
	function updateOrganization($organizationDetails, $affPartnershipDetails = 0){
		$this->db->where('id',$organizationDetails['id']);
		if($this->db->update('organizations',$organizationDetails)){
			//return true;
			if($affPartnershipDetails != 0){
	
				$this->db->insert('affiliates_partnerships',$affPartnershipDetails);
				return true;
			}else{
				return true;
			}
		}else
			return false;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : getKeyPeopleRoleNameById()
	 * @param  : $roleId
	 * @return : $roleName
	 */
	function getKeyPeopleRoleNameById($roleId=''){
	
		$roleName='';
		if($roleId !=''){
			$this->db->select('role');
			$this->db->where('id',$roleId);
			$arrRoleName = $this->db->get('key_people_roles');
			foreach($arrRoleName->result_array() as $row){
				$roleName = $row['role'];
			}
		}
		return $roleName;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : saveKeyPeople()
	 * @param  : $keyPeopleDetails
	 * @return : last_inserted on true | false on failure
	 */
	function saveKeyPeople($keyPeopleDetails){
		if($this->db->insert('key_peoples',$keyPeopleDetails)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}	
	
	/**
	 * @Author : Sanjeev K
	 * @Method : listKeyPeoples()
	 * @param  : $organizationId
	 * @return : $arrKeyPeopleDetails | false on failure
	 */
	function listKeyPeoples($organizationId = null){
		$arrKeyPeopleDetails = array();
		//Get the Events of KolId
		if($organizationId != null){
			$this->db->where('org_id', $organizationId);
	
			$this->db->select(array('key_peoples.*','key_people_roles.role','client_users.client_id','CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name'));
			$this->db->join('key_people_roles','key_people_roles.id = key_peoples.role_id', 'left');
			$this->db->join('organizations','organizations.id = key_peoples.org_id', 'left');
			$this->db->join('client_users','client_users.id = key_peoples.created_by', 'left');
			//For Salutation loading
			$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
			if($arrKeyPeopleDetailsResult = $this->db->get('key_peoples')){
				foreach($arrKeyPeopleDetailsResult->result_array() as $arrKeyPeople){
					$arrKeyPeople['eAllowed'] = $this->common_helper->isActionAllowed('org_details','edit',$arrKeyPeople);
					$arrKeyPeople['role_id'] = $arrKeyPeople['role'];
					if($arrKeyPeople['salutation'] !='0'){
						$arrKeyPeople['salutation'] = $arrSalutations[$arrKeyPeople['salutation']];
					}
					$arrKeyPeopleDetails[] = $arrKeyPeople;
				}
				return $arrKeyPeopleDetails;
			}
		}else{
			return false;
		}
	}
}
