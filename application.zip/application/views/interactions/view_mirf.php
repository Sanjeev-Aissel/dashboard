<?php //
/**
 * Element page to add the mirf  form details
 * 
 * @package application.views.interaction
 * @author Shruti Purushan
 * @created: 29-09-15
 */

$queued_js_scripts = array('jquery/jquery-ui-1.8.16.datepicket',
    'chosen.jquery'
);
// add the JS files into queue i.e Append to the existing queue
$this->config->set_item('js_files_to_load', array_merge($this->config->item('js_files_to_load'), $queued_js_scripts));
$interactionKolAutoCompleteOptions = "width: 300, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
$currentController = $this->uri->segment(1);
$currentMethod = $this->uri->segment(2);
if($currentController=='kols'){
$kolID = $this->uri->segment(3);
}
$userName	= $this->session->userdata('user_full_name');
$userId	= $this->session->userdata('user_id');
//$userTerritory	= $this->session->userdata('user_territory');
$firstName=$kolDetails[0]['first_name'];
$middleName=" ".$kolDetails[0]['middle_name'];
$lastName=" ".$kolDetails[0]['last_name'];
$kolName=$firstName.$middleName.$lastName;

$mirfWithin=0;
$link = $_SERVER['HTTP_REFERER'];
    $link_array = explode('/',$link);
     $page = end($link_array);
     if($page=="interaction_report")
         $mirfWithin=1;
?>
<!--<script src="<?php echo base_url(); ?>js/jquery.autocomplete.js"></script>-->
<script src="<?php echo base_url(); ?>js/jquery/jquery.validate1.9.min.js"></script>
<style type="text/css">
    /*    Enable Verticle separator between content and side menu list  By Laxman   */
    #contentWrapper.span-23 {
        background-image: url("<?php echo base_url(); ?>images/verticlesep_terNav.jpg");
        background-position: 135px 50%;
        background-repeat: repeat-y;
    }
    /*	#medContainer{
                    width: 800px;
                    margin-top: -75px;
                    margin-top: 0px;
                    float: right;
            }*/
    select.chosenSelect{
        width:200px;
    }
    td .chzn-container-multi .chzn-choices{
        height: 60px !important;
    }
    .alignRight{
        padding-right:0px;
    }
    .alignCenter{
        text-align: center;
    }
    table caption{
        background:url("<?php echo base_url(); ?>images/kolm-sprite-image.png") repeat-x scroll -2px -236px transparent;
    }
    /*table {
    border: 1px solid #DDDDDD;
}*/
     .validation
    {
      color: red;
        margin-left: 74px;
    margin-top: -10px;

    }
    .chzn-container-single .chzn-default {
    color: #555 !important;
  }
label {
    /*float: left;*/
}
.item {
    float: left;
    width:200px;
}
.inputTypeWidth{
    width:60%;
}
th{
    width:200px;
}
 .disabledDiv{
            background: #ececec;
    box-shadow: 0 0 4px #d1d1d1 inset;
    border: 1px solid #ececec;
    margin-bottom: 0px;
    color:#a8a8a8 !important;
    }
    .spanSign{
        color:#a8a8a8;
    }
     .input-disabled{background-color:#EBEBE4 !important;
     }
      .inputTypeWidth{
        width:220px;
    }
     <?php if($mirfWithin == 1){?>
    	#contentWrapper.span-23 {
		background-image:none;
	}
    <?php }?>
</style>
<link href="<?php echo base_url(); ?>css/chosen.css" media="screen" rel="stylesheet">
<script type="text/javascript">
</script>
<?php if($currentController=="reports") { ?>
    <button onclick="hideViewMirf()">Back</button>
<?php } else { ?>
<button value="Back To List Interactions" onclick="window.history.back();">Back To List Interactions </button>
<?php } ?>
<div class="pdfExportIcon sprite_iconSet tooltip-demo tooltop-left"  style="float: right; margin-right: 30px;">
	<a class="tooltipLink tooltip-left" rel="tooltip" href="<?php echo base_url();?>interactions/export_pdf/<?php echo $arrData['id']; ?>" data-original-title="Export to PDF">&nbsp;</a>
</div>

    <div id="medContainer">
        <h5  style="font-weight: bold; text-align: center;">Unsolicited Off-Label Question</h5>  <?php $productArray=array_flip($productArray);
         ?>
        
            <table>
                 <tr>
                    <th class="alignRight">UOQ ID:</th>
                    <td><?php echo $arrData['generic_id'];?></td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <th class="alignRight">Date of the Request:</th>
                    <td><?php echo $arrData['date_of_request'];?></td>
                    <td>&nbsp;</td>
                </tr>
<!--                <tr  class="ch">
				<th class="alignRight">Product:</th>
				<td>
                                  <?php if(in_array($productArray['ABILIFY MAINTENA'], $selectedProductIds)) echo "ABILIFY MAINTENA"; ?>
                                   
                                </td>
                               <td class="alignLeft">
                                   <input type="checkbox" id="b" name="firstProduct[]" value="1">Single-Use Vial 
				</td>
                                 <td class="alignLeft">
                                   <input type="checkbox" id="b" name="firstProduct[]" value="2">Dual Chamber Syringe 
				</td>
                                 <td class="alignLeft">
                                   <input type="checkbox" id="b" name="firstProduct[]" value="3">Non-kit Specific Inquiry 
				</td>
			</tr>
              
                 <tr>
				<th class="alignRight"></th>
				<td>
                                   <?php if(in_array($productArray['ABILIFY'], $selectedProductIds)) echo "ABILIFY"; ?>
                                </td>
                                <td class="alignLeft">
                                    <?php if(in_array($productArray['NUEDEXTA'], $selectedProductIds)) echo "NUEDEXTA"; ?>
                                  
                                   
				</td>
			</tr>
                         <tr>
				<th class="alignRight"></th>
				<td><?php if(in_array($productArray['REXULTI'], $selectedProductIds)) echo "REXULTI"; ?>
                                  
                                </td>
                                <td class="alignLeft">
                                    <?php if(in_array($productArray['SAMSCA'], $selectedProductIds)) echo "SAMSCA"; ?>
                                  
				</td>
			</tr>
                        <tr>
				<th class="alignRight"></th>
				<td> <?php if(in_array($productArray['SPRYCEL'], $selectedProductIds)) echo "SPRYCEL"; ?>
                                </td>
                                <td class="alignLeft">Other:<?php echo $otherProductValue;?>
				</td>
			</tr>-->
                  <tr  class="ch">
				<th class="alignRight">PRODUCT:</th>
				<td>
                                     <label><input type="checkbox" style="display:none;" id="productFirst" class="par" name="product[]"  disabled="disabled" value="<?php echo $productArray['ABILIFY MAINTENA'];?> " <?php if(in_array($productArray['ABILIFY MAINTENA'], $selectedProductIds)) echo "checked = 'checked'"; ?>>ABILIFY MAINTENA</label>
                                    <input type="checkbox"  style="display:none;" class="par" name="first_product_value"  id="first_product_value" value='1'/>
                                </td>
                                <td class="alignLeft">
                                   <label><input type="checkbox" class="childCheckBox" id='is_single_use_vial' disabled="disabled" name="is_single_use_vial" value="1" <?php if(in_array($productArray['ABILIFY MAINTENA'], $selectedProductIds) && $productDetails[$productArray['ABILIFY MAINTENA']]['is_single_use_vial']==1 ) echo "checked = 'checked'"; ?>>Single-Use Vial</label> 
				</td>
                                 <td class="alignLeft">
                                   <label><input type="checkbox" class="childCheckBox" id='is_dual_chamber_syringe' disabled="disabled" name="is_dual_chamber_syringe" value="1" <?php if(in_array($productArray['ABILIFY MAINTENA'], $selectedProductIds) && $productDetails[$productArray['ABILIFY MAINTENA']]['is_dual_chamber_syringe']==1 ) echo "checked = 'checked'"; ?>>Dual Chamber Syringe</label> 
				</td>
                                 <td class="alignLeft">
                                   <label><input type="checkbox" class="childCheckBox" id='is_non_kit_specific_enquiry' disabled="disabled" name="is_non_kit_specific_enquiry" value="1" <?php if(in_array($productArray['ABILIFY MAINTENA'], $selectedProductIds) && $productDetails[$productArray['ABILIFY MAINTENA']]['is_non_kit_specific_enquiry']==1 ) echo "checked = 'checked'"; ?>>Non-kit Specific Inquiry</label> 
				</td>
			</tr>
              
                 <tr>
				<th class="alignRight"></th>
				<td>
                                    <label><input type="checkbox" id="b" disabled="disabled" name="product[]" value="<?php echo $productArray['ABILIFY'];?> " <?php if((in_array($productArray['ABILIFY'], $selectedProductIds))) echo "checked = 'checked'"; 
                                    ?>>ABILIFY</label>
                                </td>
                                <td class="alignLeft">
                                   <label><input type="checkbox" id="b" disabled="disabled" name="product[]" value="<?php echo $productArray['NUEDEXTA'];?> " <?php if((in_array($productArray['NUEDEXTA'], $selectedProductIds))) echo "checked = 'checked'"; ?>>NUEDEXTA</label>
                                  
                                   
				</td>
			</tr>
                         <tr>
				<th class="alignRight"></th>
				<td><label><input type="checkbox" id="b" disabled="disabled" name="product[]" value="<?php echo $productArray['REXULTI'];?> " <?php if((in_array($productArray['REXULTI'], $selectedProductIds))) echo "checked = 'checked'"; ?>>REXULTI</label>
                                  
                                </td>
                                <td class="alignLeft">
                                    <label><input type="checkbox" id="b" disabled="disabled" name="product[]" value="<?php echo $productArray['SAMSCA'];?> " <?php if(( in_array($productArray['SAMSCA'], $selectedProductIds))) echo "checked = 'checked'"; ?>>SAMSCA</label>
                                  
				</td>
			</tr>
                        <tr>
				<th class="alignRight"></th>
				<td> <label><input type="checkbox" id="b" disabled="disabled" name="product[]" value="<?php echo $productArray['SPRYCEL'];?> " <?php if(( in_array($productArray['SPRYCEL'], $selectedProductIds))) echo "checked = 'checked'"; ?>>SPRYCEL</label>
                                </td>
                                <td class="alignLeft">
                                    <label><input type="checkbox" id="b" disabled="disabled" name="product[]" value="0" <?php if(($otherProductValue!=="")) echo "checked = 'checked'";?> >Other:</label>
                                    <input class=" alignLeft"  type="text"  name="otherProduct" id="otherProduct" disabled value="<?php echo $otherProductValue;?>">
				</td>
			</tr>
            </table>
            <table style="margin-top:5px;">
                <caption style="font-weight: bold;"><?php echo lang("HCP"); ?> REQUESTOR INFORMATION</caption>
                <tr>    
                    <th class="alignRight">NAME:</th>
                    <td><?php echo $arrData['kol_id'];?>
                    </td>
                    <th class="alignRight">DEGREE:</th>
                    <td><?php echo $arrData['degree'];?>
                    </td>
                </tr>
                <tr>
                    <th class="alignRight">SPECIALTY (if applicable):</th>
                    <td><?php echo $arrData['specialty'];?>
                    </td>
                    <th class="alignRight">STATE LIC#:</th>
                    <td><?php echo $arrData['licence'];?>
                    </td>
                </tr>
                <tr>    
                    <th class="alignRight">INSTITUTION/OFFICE:</th>
                    <td><?php echo $arrData['institution'];?>
                    </td>
                    <th class="alignRight">ADDRESS:</th>
                    <td><?php echo $arrData['address'];?>
                    </td>
                </tr>
                <tr>
                    <th class="alignRight">CITY:</th>
                    <td><?php echo $arrData['city'];?>
                    </td>
                    <th class="alignRight">STATE:</th>
                    <td><?php echo $arrData['state'];?>
                    </td>
                </tr>
                <tr>
                    <th class="alignRight">ZIP CODE:</th>
                    <td><?php echo $arrData['zip_code'];?>
                    </td>
                    <th class="alignRight">TELEPHONE #:</th>
                    <td><?php echo $arrData['telephone'];?>
                    </td>
                </tr>

            </table>
        <table style="margin-top:5px;" class="disabledDiv">
            <tr >
                <th class="alignRight">DELIVERY:</th>
                <td colspan="1">
                    <label><input type="checkbox" disabled="disabled" name="email_id" value="1"  <?php if (isset($mirfDetails[0]['email_id']) && ($mirfDetails[0]['email_id']) != 0) echo "checked = 'checked'"; ?>>Email</label>

                    <!--                                </td>
                                                    <td colspan="0" class="alignRight">-->
                    &nbsp;  &nbsp; <label for="male">E-mail address:</label>
                    <!--				</td>
                                                    <td colspan="5" >-->
                    <input class="inputTypeWidth input-disabled" disabled type="text" name="email" value="<?php if (isset($mirfDetails[0]['email']) && ($mirfDetails[0]['email']) != 0) echo $mirfDetails[0]['email'];
else echo ''; ?>">
                </td>
            </tr>
            <tr>
                <th class="alignRight"></th>
                <td>
                    <label><input type="checkbox" disabled="disabled" id="b" name="mail" value="1"  <?php if (isset($mirfDetails[0]['mail']) && ($mirfDetails[0]['mail']) != 0) echo "checked = 'checked'"; ?>>Mail</label>


                    <!--                                </td>
                                                    <td class="alignRight"> -->
                    &nbsp;  &nbsp;  <label><input type="checkbox" id="b" disabled="disabled"  name="fax_id" value="1"
<?php if (isset($mirfDetails[0]['fax_id']) && ($mirfDetails[0]['fax_id']) != 0) echo "checked = 'checked'"; ?>>Fax / Fax #:</label>

                    <!--				</td>
                                                    <td>-->
                    <input class="inputTypeWidth input-disabled" disabled type="text" name="fax" value="<?php if (isset($mirfDetails[0]['fax']) && ($mirfDetails[0]['fax']) != 0) echo $mirfDetails[0]['fax'] ;
else echo ''; ?>">
                </td>
            </tr>
            <tr>
                <th class="alignRight"></th>
                <td colspan="5">
                    <label><input type="checkbox" id="b" disabled="disabled" name="answer_provided" value="1" <?php if (isset($mirfDetails[0]['answer_provided']) && ($mirfDetails[0]['answer_provided']) != 0) echo "checked = 'checked'"; ?>>Answer Provided– no response from Medical Information required. (Please document response)</label>

                </td>
            </tr>

        </table>
              
              <table style="margin-top:5px;" class="textLabel">
                <hr/><center> <label  style="font-weight: bold; text-align: center;" >Adverse events MUST NOT be reported on this form. </label><br/></center> 
                <center> <label style="font-weight: bold; text-align: center;"> Adverse Events/Product Complaints MUST be reported to 1-800-438-9927.</label></center> 
              
                 </table>
            <table style="margin-top:5px;">
                 <caption style="font-weight: bold;">MEDICAL INFORMATION REQUEST(s) – <?php echo lang("HCP"); ?> QUESTION <span class="spanSign"> AND SIGNATURE REQUIRED</span></caption>
                <tr><th class="alignRight"><?php echo lang("HCP"); ?> QUESTION:</th> <td> <?php echo $arrData['mir_questions'];?></td>
                </tr>

                </tr>-->
            </table>
          <table style="margin-top:5px;" class="disabledDiv">
            <hr/><tr><th colspan="5">Your signature below confirms that your request(s) and/or question(s) was (were) not prompted or solicited by anyone at
Otsuka America Pharmaceutical, Inc., and that the wording above accurately states your request(s) and/or question(s).</th>
              </tr> <tr> <th>
                      <?php echo lang("HCP"); ?> SIGNATURE (REQUIRED): &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;X <span style="width:97%;">__________________________________________________________________________________________________________________________</span>
                </th>
        </table>
            <table style="margin-top:5px;">
                <caption style="font-weight: bold;">MSL INFORMATION</caption>
                <tr><th colspan="5">If Answer Provided is selected above, provide a brief description of the answer provided and resources utilized for each question.</th></tr>
               
                <tr><th class="alignRight">MSL Response:</th> <td>   
                       <?php echo $arrData['msl_info'];?></td>
                </tr>
            </table>
             <table style="margin-top:5px;">
                 <tr>
                    <th class="alignRight">MSL NAME:</th>
                    <td><?php echo $arrData['client_id'];?></td>
                    <td>&nbsp;</td>
                    <th class="alignRight">TERRITORY:</th>
                    <td><?php 
                            echo $userTerritory; ?></td>
                </tr>
            </table>
        </form>
          <table style="margin-top:5px;">
               
                <tr><th colspan="5">PLEASE FAX/E-MAIL THIS REQUEST FOR INFORMATION TO: 301-212-8634 / <a href="mailto:faxmedicalinformation@otsuka-us.com">faxmedicalinformation@otsuka-us.com</a></th></tr>
               
            </table>
    </div>
