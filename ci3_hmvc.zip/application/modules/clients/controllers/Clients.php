<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Clients extends MX_Controller{
	function __construct()
	{
		parent::__construct();
		$this->load->model('client');
		$this->load->model('helpers/common_helper');
		$this->load->model('configurations/configuration');
		$this->load->model('helpers/country_helper');
		$this->load->library('SimpleLoginSecure');
	}
	function list_clients() {
		$data['showNavBar']=true;
		$data['contentPage']='list_clients';
		$this->load->view(ANALYST_LAYOUT,$data);
	}
	function list_users() {
		$data['showNavBar']=true;
		$data['arrClients'] = $this->common_helper->getEntityById('clients',array ());
		$data['contentPage']='list_users';
		$this->load->view(ANALYST_LAYOUT,$data);
	}
	function list_clients_grid(){
		$field='field';
		$data='data';
		$responce =array();
		$page = isset($_POST['page'])?$_POST['page']:1;
		$limit = isset($_POST['rows'])?$_POST['rows']:10;// get how many rows we want to have into the grid
		$sidx = isset($_POST['sidx'])?$_POST['sidx']:'name';// get index row - i.e. user click to sort
		$sord = isset($_POST['sord'])?$_POST['sord']:'';// get the direction
		$filterData	= isset($_POST['filters'])?$_POST['filters']:'';
		$arrFilter=array();
		$arrFilter=json_decode(stripslashes($filterData));
		$searchString=$this->common_helper->search_nested_arrays($arrFilter,$data);
		$searchField=$this->common_helper->search_nested_arrays($arrFilter,$field);
		$arrFilter=array();
		foreach($searchField as $key => $val){
			$arrFilter[$val]=$searchString[$key];
		}
		if(!$sidx) $sidx =1;
		$count= $this->client->listClients($start,$limit,$sidx,$sord,$arrFilter,true);
		
		if( $count >0 ) {
			$total_pages = ceil($count/$limit);
		} else {
			$total_pages = 0;
		}
		$this->load->helper('text');
		if ($page > $total_pages) $page=$total_pages;
		$start = $limit*$page - $limit; // do not put $limit*($page - 1)
		if ($start<0) $start = 0;
		$resultSet = $this->client->listClients($start,$limit,$sidx,$sord,$arrFilter,false);
		$response = array();
		foreach($resultSet->result_array() as $row) {
			$row['id'] =$row['id'];
			$row['name'] =$row['name'];
			$row['notes'] =$row['notes'];
			$row['support_email_id'] =$row['support_email_id'];
			$response[] = $row;
		}
		$responce['rows']= $response;
		$responce['page'] = $page;
		$responce['total'] = $total_pages;
		$responce['records'] = $count;
		echo json_encode($responce);
	}
	function add_client($clientId=null){
		$arrClient = array();
		if($clientId!=null){
			$arrClient=$this->common_helper->getEntityById('clients', array ('id' => $clientId));
			$arrClient=$arrClient[0];
		}
		$data['showNavBar']=true;
		$data['arrClient']=$arrClient;
		$data['contentPage'] ='add_client';
		$this->load->view(ANALYST_LAYOUT,$data);
	}
	function add_user($userId=NULL){
		$client_id =  $this->session->userdata('client_id');
		$data['arrCountry']=$this->country_helper->listCountries();
		$data['arrUsers']=null;
		$data['arrManagers']=null;
		if($userId!=NULL){
			$arrUserDetails=$this->common_helper->getEntityById('client_users', array ('id' => $userId));
			$data['arrUsers']=$arrUserDetails[0];
			$data['arrStates']=$this->country_helper->getStatesByCountryId($data['arrUsers']['country_id']);
			$data['arrCities']=$this->country_helper->getCitiesByStateId($data['arrUsers']['state_id']);
		}
		$data['arrClients']=  $this->common_helper->getEntityById('clients',array ());
		$data['contentPage'] ='add_user';
		$data['showNavBar']=true;
		$this->load->view(ANALYST_LAYOUT,$data);
	}
	function save_client(){
		$arrClient['id']				=	$this->input->post('client_id');
		$arrClient['name']				=	$this->input->post('client_name');
		$arrClient['notes']				=	$this->input->post('client_notes');
		$arrClient['support_email_id']	=	$this->input->post('client_email');
		//Check if client logo is uploaded and proceed
		if(!empty($_FILES['client_logo']['name'])) {
			$target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."images/client_logos/logos/";
			$date_for_prefix = date('Y_M_d');
			$newFileName=md5($date_for_prefix.$_FILES["client_logo"]['name']);
			$existing_file_name=$this->input->post('client_logo_name');
			//check if already present and uploaded pic is same,
			//if not, den upload and delete old one
			if($newFileName!=$existing_file_name){
				$overview_file_target_path = $target_path ."/". $newFileName;
				if(move_uploaded_file($_FILES['client_logo']['tmp_name'],$overview_file_target_path)){
					$arrClient['client_logo']=$newFileName;
					unlink($target_path."/".$existing_file_name);
				}
			}
		}
		//Check if client favicon is uploaded and proceed
		if(!empty($_FILES['client_favicon']['name'])) {
			$target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."images/client_logos/favicons/";
			$date_for_prefix = date('Y_M_d');
			$newFileName=md5($date_for_prefix.$_FILES["client_favicon"]['name']);
			$overview_file_target_path = $target_path ."/". $newFileName;
			$existing_file_name=$this->input->post('client_favicon_name');
			if($newFileName!=$existing_file_name){
				$overview_file_target_path = $target_path ."/". $newFileName;
				if(move_uploaded_file($_FILES['client_favicon']['tmp_name'],$overview_file_target_path)){
					$arrClient['client_favicon']=$newFileName;
					unlink($target_path."/".$existing_file_name);
				}
			}
		} 
		if($this->client->saveClient($arrClient)>=0){
			$data['saved'] =true;
			$data['msg']  = "Saved Successfully";
		}else{
			$data['saved'] =false;
			$data['msg']  = "Error in updating data...!!";
		}
		echo json_encode($data);
	}
	function list_users_grid($client_id=null){
		$page		= $_REQUEST['page'];
		$limit 		= $_REQUEST['rows']; // get how many rows we want
		$sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
		$sord = $_REQUEST['sord']; // get the direction
		if(!$sidx) $sidx =1;
		$filterData=$_REQUEST['filters'];
		$arrFilter=array();
		$arrFilter=json_decode(stripslashes($filterData));
		$field='field';
		$op='op';
		$data='data';
		$groupOp='groupOp';
		$searchGroupOperator=$this->common_helper->search_nested_arrays($arrFilter, $groupOp);
		$searchString=$this->common_helper->search_nested_arrays($arrFilter, $data);
		$searchOper=$this->common_helper->search_nested_arrays($arrFilter, $op);
		$searchField=$this->common_helper->search_nested_arrays($arrFilter, $field);
		$whereResultArray=array();
		foreach($searchField as $key=> $val){
			$whereResultArray[$val]=$searchString[$key];
		}
		$whereResultArray['client_id']=$client_id;
		$searchGroupOperator=$searchGroupOperator[0];
		$searchResults=array();
		$count	=	$this->client->getUsersList($limit,$start,true,$sidx,$sord,$whereResultArray);
		if( $count >0 ) {
			$total_pages = ceil($count/$limit);
		} else {
			$total_pages = 0;
		}
		if ($page > $total_pages) $page=$total_pages;
		$start = $limit*$page - $limit; 
		if ($start < 0) $start = 0;
		$arrUserDetailResult = array();
		$data 				= array();
		if($arrUserDetailResult = $this->client->getUsersList($limit,$start,false,$sidx,$sord,$whereResultArray)){
			$data['records']= $count;
			$data['total']  = $total_pages;
			$data['page']	= $page;
			$data['rows']	= $arrUserDetailResult;
		}
		echo json_encode($data);
	}
	function update_user_status(){
		$userId = $this->input->post('user_id');
		if(!is_array($userId)){
			$userId	= explode(',',$userId);
		}
		$status = $this->input->post('status');
		echo $this->client->updateUserStatus($userId,$status);
	}
	function export_users($users){
		$data[0]=array('ID','User Full Name','Login Name','Email ID','Client Name','Company Name','Contact','Status');
		$i=1;
		$arrUsers	= explode(',',$users);
		$whereResultArray=array();
		$whereResultArray['user_ids']=$arrUsers;
		if($arrUserDetailResult = $this->client->getUsersList(sizeof($arrUsers),0,false,'','',$whereResultArray)){
			foreach ($arrUserDetailResult as $row){
				$data[$i][]						= $row['id'];
				$data[$i][]						= $row['first_name']." ".$row['last_name'];
				$data[$i][]						= $row['user_name'];
				$data[$i][]						= $row['email'];
				$data[$i][]						= $row['name'];
				$data[$i][]						= $row['company_name'];
				$data[$i][]						= $row['contact'];
				$data[$i][]						= $row['status'];
				$i++;
			}
		}
		$sheet['title']					='Users';
		$sheet['content']				=$data;
		
		$sheets[]=$sheet;

		$arr_export_details['file_name']	='user_details.xls';
		$arr_export_details['sheets']		=$sheets;
		export_as_xls($arr_export_details); //helper function for export 
	}
	function get_client_managers($clientId){
		$arrManagers = array();
		$arrManagers = $this->client->getClientManagers($clientId);		
		echo json_encode($arrManagers);
	}
	function get_client_roles($clientId){
		$arrClientRoles = array();
		$arrClientRoles= $this->client->getClientRoles($clientId);
		echo json_encode($arrClientRoles);
	}
	function save_user(){
		if(!empty($_FILES['profile_pic']['name'])) {
			$target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."images/user_profile_pictures";
			$date_for_prefix = date('Y_M_d');
			$newFileName=md5($date_for_prefix.$_FILES["profile_pic"]['name']);
			$existing_file_name=$this->input->post('old_profile_pic');
			//check if already present and uploaded pic is same,
			//if not, den upload and delete old one
			$overview_file_target_path = $target_path ."/". $newFileName;
			if(move_uploaded_file($_FILES['profile_pic']['tmp_name'],$overview_file_target_path)){
				$arrUser['profile_pic']=$newFileName;
				unlink($target_path."/".$existing_file_name);
			}
		}
		$hasher = new PasswordHash(PHPASS_HASH_STRENGTH, PHPASS_HASH_PORTABLE);
		$arrUser['id']				=	$this->input->post('user_id');
		
		$arrUser['client_id']		=	$this->input->post('client_id');
		$arrUser['user_role_id']	=	$this->input->post('user_role_id');
		
		$arrUser['manager_id']		=	$this->input->post('manager_id');
		$arrUser['is_manager']		=	$this->input->post('mark_as_mgr');
		
		$arrUser['first_name']		=	$this->input->post('first_name');
		$arrUser['last_name']		=	$this->input->post('last_name');
		
		$arrUser['email']			=	$this->input->post('email');
		$arrUser['contact']			=	$this->input->post('contact');
		
		$arrUser['title']		    =	$this->input->post('title');
		$arrUser['company_name']	=	$this->input->post('company_name');
		
		$arrUser['country_id']		=	$this->input->post('country_id');
		$arrUser['state_id']		=	$this->input->post('state_id');
		
		$arrUser['city_id']			=	$this->input->post('city_id');
		$arrUser['postal_code']		=	$this->input->post('postal_code');

		$arrUser['address']			=	$this->input->post('address');
		$arrUser['user_name']		=	$this->input->post('user_name');
		$arrUser['password']		=	$hasher->HashPassword($this->input->post('password'));
		$arrUser['is_test_user']	=	$this->input->post('is_test_user');

		$retId=$this->client->saveUser($arrUser);
		if($this->client->saveUser($arrUser)>=0){
			$data['saved'] =true;
			$data['msg']  = "Saved Successfully";
		}else{
			$data['saved'] =false;
			$data['msg']  = "Error in updating data...!!";
		}
		echo json_encode($data);
	}
	
	function analysis_client(){
		//$this->load->view('clients/select_client');
		$data['arrClients']=  $this->common_helper->getEntityById('clients',array ());
		$data['contentPage'] ='select_client';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	
	function select_analysis_client(){
		$client_id = $this->input->post('client_id');	
		$store_session_data = array(
			'analyst_client'=>$client_id
		);
		$this->session->set_userdata($store_session_data);
		$data['status'] = 'success';
		echo json_encode($data);
	}
	function get_client_ajax(){
		$arr_client_list = $this->common_helper->getEntityById('clients',array ());
		echo json_encode($arr_client_list);
	}
}