<?php
/**
 * Contain functuions to calculate  all kols acvtivity count.
 * @package application.controllers	
 * @author: Vinayak K
 * @version :3.10
 * 
 */
 
class profile_ratings extends Controller{
	private $loggedUserId	= null;
	
	// constructor to initialize the data
	function profile_ratings(){
		parent::Controller();
		$this->load->model('pubmed');
		$this->load->model('kol_rating');
	}
	
	/*
	 * Caluculates and inserts Kols acivity Count
	 * @author Vinayak
	 * @since 3.10
	 * @created on 10-April-2012
	 */
	function caluculateAndInsertActivitesCount($kolIds=null){
	//$kolIds =array(1,2,3,4,5);
		$kolIds = $this->input->post('sel');
		if($kolIds!=null){
			$this->db->where_in('kol_id',$kolIds);
			$this->db->delete('kol_activities_count');
		}else{
			$this->db->query("delete from kol_activities_count");
		}
		$this->db->select('id');
		$this->db->where_not_in('id',0);
		$this->db->where('status',COMPLETED);
		if($kolIds!=null){
			$this->db->where_in('id',$kolIds);
		}
		$arrKolidsResult = $this->db->get('kols');
	
		//$arrKolidsResult =$this->db->query("select id from kols where id!=0 and status='Completed'");
	
		foreach($arrKolidsResult->result_array() as $row){
			
			$arrKols[]=$row['id'];
		}
		$arrActvites=array();
		foreach($arrKols as $id){
			//Aff Count
			$affCountResultSet=$this->db->query("select count(*) as count from kol_memberships where kol_id=$id");
			//echo $this->db->last_query();
			$affCount='';
			foreach($affCountResultSet->result() as $affCountRow){
				$affCount=$affCountRow->count;
			}
			
			$arrActvites[$id]['affCount']=$affCount;
			
			//Event Count
			$eventsCountResultSet=$this->db->query("select count(*) as count from kol_events where kol_id=$id");
			$eventCount='';
			foreach($eventsCountResultSet->result() as $eveCountRow){
				$eventsCount=$eveCountRow->count;
			}
			$arrActvites[$id]['eventsCount']=$eventsCount;
			
			//Pubs Count
			$pubsCountResultSet=$this->db->query("select count(*) as count from kol_publications where kol_id=$id and kol_publications.is_verified=1 and kol_publications.is_deleted=0");
			$pubsCount='';
			foreach($pubsCountResultSet->result() as $pubCountRow){
				$pubsCount=$pubCountRow->count;
			}
			$arrActvites[$id]['pubsCount']=$pubsCount;
			
			//trialsCount
			$trialCountResultSet=$this->db->query("select count(*) as count from kol_clinical_trials where kol_id=$id");
			$trialCount='';
			foreach($trialCountResultSet->result() as $trailCountRow){
				$trialCount=$trailCountRow->count;
			}
			$arrActvites[$id]['trialCount']=$trialCount;
			
			//PracstiseCount
			$practsiseResultSet = $this->db->query("select count(*) as count
													from kol_memberships
													left join engagement_types on kol_memberships.engagement_id=engagement_types.id
													where kol_memberships.type='university' and engagement_types.engagement_type='Clinical Practice' and kol_id=$id
													");
			$practiseCount ='';
			foreach($practsiseResultSet->result() as $practiseCountRow){
				$practiseCount=$practiseCountRow->count;
			}
			$arrActvites[$id]['practiseCount']=$practiseCount;
			
			//TeachingCount
			$teachingResultSet = $this->db->query("select count(*) as count
													from kol_memberships
													left join engagement_types on kol_memberships.engagement_id=engagement_types.id
													where kol_memberships.type='university' and engagement_types.engagement_type='Teaching' and kol_id=$id
													");
			$teachingCount ='';
			foreach($teachingResultSet->result() as $teachingCountRow){
				$teachingCount=$teachingCountRow->count;
			}
			$arrActvites[$id]['teachingCount']=$teachingCount;
			
			///Society Exec Committee
			$socialComitteResultSet = $this->db->query("select count(*) as count
													from kol_memberships
													left join engagement_types on kol_memberships.engagement_id=engagement_types.id
													where kol_memberships.type='association' and engagement_types.engagement_type='Leadership' and kol_id=$id
													");
			$socialComitteCount ='';
			foreach($socialComitteResultSet->result() as $socialComitteRow){
				$socialComitteCount=$socialComitteRow->count;
			}
			$arrActvites[$id]['socialComitteCount']=$socialComitteCount;
			
			//Society Board Memberships
			$socialBoardResultSet = $this->db->query("select count(*) as count
													from kol_memberships
													left join engagement_types on kol_memberships.engagement_id=engagement_types.id
													where kol_memberships.type='association' and engagement_types.engagement_type='Board of Director' and kol_id=$id
													");
			$socialBoardCount ='';
			foreach($socialBoardResultSet->result() as $socialBoardRow){
				$socialBoardCount=$socialBoardRow->count;
			}
			$arrActvites[$id]['socialBoardCount']=$socialBoardCount;
			
			//Guidelines
			$guidelinesResultSet = $this->db->query("select count(*) as count
													from kol_memberships
													left join engagement_types on kol_memberships.engagement_id=engagement_types.id
													where engagement_types.engagement_type='Guideline' and kol_id=$id
													");
			$guidelineCount ='';
			foreach($guidelinesResultSet->result() as $guidelineRow){
				$guidelineCount=$guidelineRow->count;
			}
			$arrActvites[$id]['guidelineCount']=$guidelineCount;
			
				//Government Agency Affiliations
			$governmentResultSet = $this->db->query("select count(*) as count
													from kol_memberships
													where type='government' and kol_id=$id
													");
			$governmentCount ='';
			foreach($governmentResultSet->result() as $governmentRow){
				$governmentCount=$governmentRow->count;
			}
			$arrActvites[$id]['governmentCount']=$governmentCount;
			
			
			//Executive Committee
			$executiveResultSet = $this->db->query("select count(*) as count 
						from kol_events
						where kol_id =$id and (role='President' OR role='Vice President' OR role='Chair' OR role='Co-chair' or  role='Director')
									");
			$executiveCount ='';
			foreach($executiveResultSet->result() as $executiveRow){
				$executiveCount=$executiveRow->count;
			}
			$arrActvites[$id]['executiveCount']=$executiveCount;
			
			//Speaking Engagements
			$speakingResultSet = $this->db->query("select count(*) as count 
						from kol_events
						where kol_id =$id and (role='Speaker' OR role='Keynote Speaker')
									");
			$speakingCount ='';
			foreach($speakingResultSet->result() as $speakingRow){
				$speakingCount=$speakingRow->count;
			}
			$arrActvites[$id]['speakingCount']=$speakingCount;
			
			//Faculty at Events
			$facultyResultSet = $this->db->query("select count(*) as count 
						from kol_events
						where kol_id =$id and (role='Faculty')
									");
			$facultyCount ='';
			foreach($facultyResultSet->result() as $facultyRow){
				$facultyCount=$facultyRow->count;
			}
			$arrActvites[$id]['facultyCount']=$facultyCount;
			
			//Panelist at Events
			$panelistResultSet = $this->db->query("select count(*) as count 
						from kol_events
						where kol_id =$id and (role='Panelist' or role='Moderator' or role='Coordinator')
									");
			$panelistCount ='';
			foreach($panelistResultSet->result() as $panelistRow){
				$panelistCount=$panelistRow->count;
			}
			$arrActvites[$id]['panelistCount']=$panelistCount;
			
		
	
		$yearRange		=$arrYears=$this->pubmed->getKolPubsYearsRange($id);
	
		$arrSingleAuthPubs		=	$this->pubmed->getKolPubsWithSingleAuthor($id,$yearRange['min_year'],$yearRange['max_year']);
		$arrFirstAuthPubs		=	$this->pubmed->getKolPubsWithFirstAuthorship($id,$yearRange['min_year'],$yearRange['max_year']);
		$arrLastAuthPubs		=	$this->pubmed->getKolPubsWithLastAuthorship($id,$yearRange['min_year'],$yearRange['max_year']);
	//	$arrMiddleAuthPubs		=	$this->pubmed->getKolPubsWithMiddleAuthorship($id,'','');
		
		$arrSingleAuthPubsCount		=	sizeof($arrSingleAuthPubs);
		$arrFirstAuthPubsCount		=	sizeof($arrFirstAuthPubs);
		$arrLastAuthPubsCount		=	0;
		$arrMiddleAuthPubsCount		=	0;
		
		foreach($arrLastAuthPubs as $lastAuthPub){
			if($lastAuthPub['auth_pos']==$lastAuthPub['max_pos'] && $lastAuthPub['max_pos']!=1)
				$arrLastAuthPubsCount++;
		}
		
		$aurhPoscount = array((int)$arrFirstAuthPubsCount,(int)$arrSingleAuthPubsCount,(int)$arrLastAuthPubsCount);
		
		$arrSum=array_sum($aurhPoscount);
		
		$arrActvites[$id]['authPosCount']=$arrSum;
		
		}
		
		//Count of Professonal Experience
		//Get the count of Practise
		
		
		foreach($arrActvites as $id=>$value){
			$arrActvites[$id]['totalScore']=array_sum($value);
		}
		
		foreach($arrActvites as $id=>$value){
			$arrActvites[$id]['totalAllScore']=$value['authPosCount']+$value['panelistCount']+$value['facultyCount']+$value['speakingCount']+$value['executiveCount']+$value['governmentCount']+$value['guidelineCount']+$value['socialBoardCount']+$value['socialComitteCount']+$value['teachingCount']+$value['practiseCount']+$value['trialCount'];
			$arrActvites[$id]['totalProfessionalCount'] = $value['practiseCount']+$value['teachingCount']+$value['socialComitteCount']+$value['socialBoardCount']+$value['guidelineCount']+$value['governmentCount'];
			$arrActvites[$id]['totalEvents'] = $value['panelistCount']+$value['facultyCount']+$value['speakingCount']+$value['executiveCount'];
			$arrActvites[$id]['totalResearch'] = $value['authPosCount']+$value['trialCount'];
		}
		$bulkInsert='';
		$seperator	= '';
		foreach($arrActvites as $kolId=>$value){
			
			$bulkInsert	.= $seperator;
			$bulkInsert	.= "($kolId,".$value['affCount'].",".$value['pubsCount'].",".$value['eventsCount'].",".$value['trialCount'].",".$value['totalScore'].",".$value['authPosCount'].",".$value['panelistCount'].",".$value['facultyCount'].",".$value['speakingCount'].",".$value['executiveCount'].",".$value['governmentCount'].",".$value['guidelineCount'].",".$value['socialBoardCount'].",".$value['socialComitteCount'].",".$value['teachingCount'].",".$value['practiseCount'].",".$value['totalAllScore'].",".$value['totalProfessionalCount'].",".$value['totalEvents'].",".$value['totalResearch'].")";
			$seperator	= ',';
		}
	
		if($this->db->query("insert into kol_activities_count(`kol_id`,`affCount`,`pubsCount`,`eventsCount`,`trialCount`,`totalScore`,`authPosCount`,`panelistCount`,`facultyCount`,`speakingCount`,`executiveCount`,`governmentCount`,`guidelineCount`,`socialBoardCount`,`socialComitteCount`,`teachingCount`,`practiseCount`,`totalAllScore`,`totalProfessionalCount`,`totalEvents`,`totalResearch`) values $bulkInsert")){
			
			if($kolIds!=null){
				$data['status'] = true;
				echo json_encode($data);
			
			}else{
				echo COMPLETED;
			}
			
		$this->db->select('kol_id');
		$arrKolsResultset = $this->db->get('kol_activities_count');
		foreach($arrKolsResultset->result_array() as $kolId1){
		
			$kolTotalActivitiesCount 	= $this->kol_rating->getKolTotalActivityCount1($kolId1['kol_id']);
			//echo $kolTotalActivitiesCount;
			
			$spcilatyId  = $this->kol_rating->gerSpecilatyIdByKol($kolId1['kol_id']);
			
			$maxCount = $this->kol_rating->getMaxTotalCountOfKolBySpecialty($spcilatyId);
			$pforfileScore['profileScore']	=($kolTotalActivitiesCount/$maxCount)*100;
			$this->db->where('kol_activities_count.kol_id',$kolId1['kol_id']);
			$this->db->update('kol_activities_count',$pforfileScore);
			
		}
		//$maxCountOfAllIndividualParam = $this->kol_rating->getMaxCountBySpecialty($spcilatyId);
		//$summMxCountOfAllIndividualParam = array_sum($maxCountOfAllIndividualParam[0]);
		
		}else{
			if($kolIds!=null){
				$data['status'] = true;
				echo json_encode($data);
			}else{
				echo "Not completed";
			}
			
		}
		if($kolIds == null){
			$filePath=$_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."system/logs/jobs/cron_job_status.txt";
			$content = "profile_score_data_cron.php :: ".date("Y-m-d H:i:s")."::success :: no comments\r\n";
			echo $content;
			file_put_contents($filePath,$content, FILE_APPEND | LOCK_EX);
		}
		$content = "profile_score_data_cron.php :: ".date("Y-m-d H:i:s")."::success :: no comments\r\n";
		echo $content;
	}
	
	/*
	 * get all Parameters count of KOL
	 * @author Vinayak
	 * @since 3.10
	 * @created on 9-April-2012
	 */
	function get_count_of_all_parameter($kolId){
		$arrAllParameter=array();
	
		$arr = $this->kol_rating->getCountOfAllParameter($kolId);
		foreach($arr as $key=>$value){
			
			$arrAllParameter['Practice'] 					= (int)$value['practiseCount'];
			$arrAllParameter['Teaching Experience']			= (int)$value['teachingCount'];
			$arrAllParameter['Society Exec Committee'] 		= (int)$value['socialComitteCount'];
			$arrAllParameter['Society Board Memberships'] 	= (int)$value['socialBoardCount'];
			$arrAllParameter['Guidelines'] = (int)$value['guidelineCount'];
			$arrAllParameter['Government Agency Affiliations'] = (int)$value['governmentCount'];
			$arrAllParameter['Researcher Status'] = (int)$value['authPosCount'];
			$arrAllParameter['Clinical Trials'] = (int)$value['trialCount'];
			$arrAllParameter['Executive Committee'] = (int)$value['executiveCount'];
			$arrAllParameter['Speaking Engagements'] = (int)$value['speakingCount'];
			$arrAllParameter['Faculty at Events'] = (int)$value['facultyCount'];
			$arrAllParameter['Panelist at Events'] = (int)$value['panelistCount'];
			$arrAllParameter['Total'] = (int)$value['totalAllScore'];
			
			
		//echo $kolTotalActivitiesCount;
		
			$spcilatyId  = $this->kol_rating->gerSpecilatyIdByKol($kolId);
			$maxCountOfAllIndividualParam = $this->kol_rating->getMaxCountBySpecialty($spcilatyId);
			$summMxCountOfAllIndividualParam = array_sum($maxCountOfAllIndividualParam[0]);
			$kolsPforfileScore	=($arrAllParameter['Total']/$summMxCountOfAllIndividualParam)*100;
				//s$arrAllParameter['Profile Score'] = $value['practiseCount'];
			$arrAllParameter['Profile score'] = $kolsPforfileScore;	
		}
	
		
		foreach($arrAllParameter as $key=>$value){
			
			$arr1[]=$key;
			$arr2[]=$value;
		}
		
		$arr3[]=$arr1;
		$arr3[]=$arr2;
		echo json_encode($arr3);
	}
	
	/*
	 * Show profile Score Chart
	 * @author Vinayak
	 * @since 3.10
	 * @created on 10-April-2012
	 */
	function show_profile_score_chart($kolId,$specialtyId,$forDashboard = false){
		$data['kolId'] = $kolId;
		$data['specailtyId'] = $specialtyId;
		$data['forDashboard'] = $forDashboard;
		
		$arrAllParameter=array();
	
		$arr = $this->kol_rating->getCountOfAllParameter($kolId);
		$arrSalutations						= array(0=>'',1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$maxCategoriesCount  = $this->kol_rating->getmaxCategoriesCounts($specialtyId);
		
		$maxCountOfIndivdaulParam = $this->kol_rating->getMaxCountBySpecialty($specialtyId);
		
		foreach($arr as $key=>$value){
			
			$professional = 'Professional Experience';
			$events = 'Events Presence';
			$research = "Research";
			//Start of Professional
			$arrAllParameter[$professional]['practiseCount'] = $value['practiseCount'];
			$arrAllParameter[$professional]['practiseScore'] = round(((($value['practiseCount']/$maxCountOfIndivdaulParam[0]['max(practiseCount)'])*100)))."%";
			
			
			$arrAllParameter[$professional]['teachingCount'] = $value['teachingCount'];
			$arrAllParameter[$professional]['teachingScore'] = round(((($value['teachingCount']/$maxCountOfIndivdaulParam[0]['max(teachingCount)'])*100)))."%";
			
			$arrAllParameter[$professional]['socialComitteCount'] = $value['socialComitteCount'];
			$arrAllParameter[$professional]['socialComitteScore'] = round((($value['socialComitteCount']/$maxCountOfIndivdaulParam[0]['max(socialComitteCount)'])*100))."%";
			
			$arrAllParameter[$professional]['socialBoardCount'] = $value['socialBoardCount'];
			$arrAllParameter[$professional]['socialBoardScore'] = round((($value['socialBoardCount']/$maxCountOfIndivdaulParam[0]['max(socialBoardCount)'])*100))."%";
			
			$arrAllParameter[$professional]['guidelineCount'] = $value['guidelineCount'];
			$arrAllParameter[$professional]['guidelineBoardScore'] = round((($value['guidelineCount']/$maxCountOfIndivdaulParam[0]['max(guidelineCount)'])*100))."%";
			
			$arrAllParameter[$professional]['governmentCount'] = $value['governmentCount'];
			$arrAllParameter[$professional]['governmentScore'] = round((($value['governmentCount']/$maxCountOfIndivdaulParam[0]['max(governmentCount)'])*100))."%";
			
			$arrAllParameter[$professional]['totalProfessionalCount'] = $value['totalProfessionalCount'];
			$arrAllParameter[$professional]['professionalScore'] = round((($value['totalProfessionalCount']/$maxCategoriesCount[0]['maxProfessionalCount'])*100))."%";
			
			//End of Professional
			
			//Start of Events
			
			$arrAllParameter[$events]['executiveCount']    = $value['executiveCount'];
			$arrAllParameter[$events]['executiveScore']    = round((($value['executiveCount']/$maxCountOfIndivdaulParam[0]['max(executiveCount)'])*100))."%";
			
			$arrAllParameter[$events]['speakingCount']    = $value['speakingCount'];
			$arrAllParameter[$events]['speakingScore']    = round((($value['speakingCount']/$maxCountOfIndivdaulParam[0]['max(speakingCount)'])*100))."%";
			
			$arrAllParameter[$events]['facultyCount']    = $value['facultyCount'];
			$arrAllParameter[$events]['facultyScore']    = round((($value['facultyCount']/$maxCountOfIndivdaulParam[0]['max(facultyCount)'])*100))."%";
			
			$arrAllParameter[$events]['panelistCount']    = $value['panelistCount'];
			$arrAllParameter[$events]['panelistScore']    = round((($value['panelistCount']/$maxCountOfIndivdaulParam[0]['max(panelistCount)'])*100))."%";
			
			$arrAllParameter[$events]['totalEvents']    = $value['totalEvents'];
			$arrAllParameter[$events]['eventScore']    = round((($value['totalEvents']/$maxCategoriesCount[0]['maxEventsPresenceCount'])*100))."%";;
			//end of events
			
			//Start of Research
			$arrAllParameter[$research]['authPosCount']    = $value['authPosCount'];
			$arrAllParameter[$research]['authPosScore']    = round((($value['authPosCount']/$maxCountOfIndivdaulParam[0]['max(authPosCount)']))*100)."%";
			
			
			$arrAllParameter[$research]['trialCount']    = $value['trialCount'];
			$arrAllParameter[$research]['trialScore']    = round((($value['trialCount']/$maxCountOfIndivdaulParam[0]['max(trialCount)'])*100))."%";
			
			$arrAllParameter[$research]['totalResearch']    = $value['totalResearch'];
			$arrAllParameter[$research]['researchScore']    = round((($value['totalResearch']/$maxCategoriesCount[0]['maxResearchCount'])*100))."%";
			//$arrAllParameter['Practice'] 					= (int)$value['practiseCount'];
		//	$arrAllParameter['Teaching Experience']			= (int)$value['teachingCount'];
			//$arrAllParameter['Society Exec Committee'] 		= (int)$value['socialComitteCount'];
			//$arrAllParameter['Society Board Memberships'] 	= (int)$value['socialBoardCount'];
			//$arrAllParameter['Guidelines'] = (int)$value['guidelineCount'];
			//$arrAllParameter['Government Agency Affiliations'] = (int)$value['governmentCount'];
		//	$arrAllParameter['Researcher Status'] = (int)$value['authPosCount'];
			//$arrAllParameter['Clinical Trials'] = (int)$value['trialCount'];
			//$arrAllParameter['Executive Committee'] = (int)$value['executiveCount'];
			//$arrAllParameter['Speaking Engagements'] = (int)$value['speakingCount'];
			//$arrAllParameter['Facultyat Events'] = (int)$value['facultyCount'];
			//$arrAllParameter['Panelistat Events'] = (int)$value['panelistCount'];
			$arrAllParameter['Total'] = $value['totalAllScore'];
			$arrAllParameter['kol_name'] = $arrSalutations[$value['salutation']]." ".$value['first_name']." ".$value['middle_name']." ".$value['last_name'];
			
			
		//echo $kolTotalActivitiesCount;
		
// 			$spcilatyId  = $this->kol_rating->gerSpecilatyIdByKol($kolId);
			$maxCount = $this->kol_rating->getMaxTotalCountOfKolBySpecialty($specialtyId);
			
			//$summMxCountOfAllIndividualParam = array_sum($maxCountOfAllIndividualParam[0]);
			$kolsPforfileScore	=round(($arrAllParameter['Total']/$maxCount)*100)."%";
				//s$arrAllParameter['Profile Score'] = $value['practiseCount'];
			$arrAllParameter['Profile score'] = $kolsPforfileScore;	
			
		//
		}
		
		$data['arrAllParameter'] = $arrAllParameter;
		$this->load->view('profile_ratings/profile_score_chart',$data);
		//pr($arrAllParameter);
	}
	
	/*
	 * get the
	 * @author Vinayak
	 * @since 3.10
	 * @created on 9-April-2012
	 */
	function getAllKolsCount($specialtyId){
		$page					= (int)$this->input->post('page'); // get the requested page 
		$limit					= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$arrContactDetails		= array();
		$data					= array();
		$kolId					= $this->input->post('kolId');
		$maxCategoriesCount 	= $this->kol_rating->getmaxCategoriesCounts($specialtyId);
		$maxCountOfIndivdaulParam = $this->kol_rating->getMaxCountBySpecialty($specialtyId);
		$maxCount				= $this->kol_rating->getMaxTotalCountOfKolBySpecialty($specialtyId);
		$arrKolsCountOfIndividualParam = $this->kol_rating->getAllKolsCountOfIndividualParam($specialtyId);
		$arrAllParameter 		= array();
		$arrSalutations			= array(0=>'',1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		foreach($arrKolsCountOfIndividualParam as $key=>$value){
			//$value['kol_name']			= '<a target="_NEW" href="'.base_url().'kols/view/'.$value['kol_id'].'">'.$arrSalutations[$value['salutation']]." ".$value['first_name']." ".$value['middle_name']." ".$value['last_name'].'<a>';
				//s$arrAllParameter['Profile Score'] = $value['practiseCount'];
			//Professional Experience
//			$value['kol_name']	 = $arrSalutations[$value['salutation']]." ".$value[FIRST_ORDER]." ".$value[SECOND_ORDER]." ".$value[THIRD_ORDER];
			$value['kol_name']	 = $arrSalutations[$value['salutation']]." ".$this->common_helpers->get_name_format($value['first_name'],$value['middle_name'],$value['last_name']);
			$value['practiseCount'] 	= round(((($value['practiseCount']/$maxCountOfIndivdaulParam[0]['max(practiseCount)'])*100)))."%"." (".$value['practiseCount'].")";
			$value['teachingCount'] 	= round(((($value['teachingCount']/$maxCountOfIndivdaulParam[0]['max(teachingCount)'])*100)))."%"." (".$value['teachingCount'].")";
			$value['socialComitteCount']= round(((($value['socialComitteCount']/$maxCountOfIndivdaulParam[0]['max(socialComitteCount)'])*100)))."%"." (".$value['socialComitteCount'].")";
			$value['socialBoardCount']	= round(((($value['socialBoardCount']/$maxCountOfIndivdaulParam[0]['max(socialBoardCount)'])*100)))."%"." (".$value['socialBoardCount'].")";
			$value['guidelineCount']	= round(((($value['guidelineCount']/$maxCountOfIndivdaulParam[0]['max(guidelineCount)'])*100)))."%"." (".$value['guidelineCount'].")";;
			$value['governmentCount']	= round(((($value['governmentCount']/$maxCountOfIndivdaulParam[0]['max(governmentCount)'])*100)))."%"." (".$value['governmentCount'].")";
			$value['professionalScore'] =  round((($value['totalProfessionalCount']/$maxCategoriesCount[0]['maxProfessionalCount'])*100))."%"." (".$value['totalProfessionalCount'].")";	
			//Research
			$value['authPosCount']		= round((($value['authPosCount']/$maxCountOfIndivdaulParam[0]['max(authPosCount)']))*100)."%"." (".$value['authPosCount'].")";
			$value['trialCount']		= round((($value['trialCount']/$maxCountOfIndivdaulParam[0]['max(trialCount)']))*100)."%"." (".$value['trialCount'].")";;
			$value['reasearchScore']    = round((($value['totalResearch']/$maxCategoriesCount[0]['maxResearchCount'])*100))."%"." (".$value['totalResearch'].")";
			$value['executiveCount']    = round((($value['executiveCount']/$maxCountOfIndivdaulParam[0]['max(executiveCount)'])*100))."%"." (".$value['executiveCount'].")";
			$value['speakingCount']		= round((($value['speakingCount']/$maxCountOfIndivdaulParam[0]['max(speakingCount)'])*100))."%"." (".$value['speakingCount'].")";
			$value['facultyCount']		= round((($value['facultyCount']/$maxCountOfIndivdaulParam[0]['max(facultyCount)'])*100))."%"." (".$value['facultyCount'].")";
			$value['panelistCount']		= round((($value['panelistCount']/$maxCountOfIndivdaulParam[0]['max(panelistCount)'])*100))."%"." (".$value['panelistCount'].")";
			$value['eventScore']        =  round((($value['totalEvents']/$maxCategoriesCount[0]['maxEventsPresenceCount'])*100))."%"." (".$value['totalEvents'].")";
			//$summMxCountOfAllIndividualParam = array_sum($maxCountOfAllIndividualParam[0]);
			$kolsPforfileScore			= (($value['totalAllScore']/$maxCount)*100);
			$value['profile_score']     =  round($kolsPforfileScore)."%"." (".$value['totalAllScore'].")";	
			$arrAllParameter[]			= $value;
			if($value['kol_id']==$kolId){
				$value['pos']				= $key ;
				$arrAllParameter[0]['pos']	= $value['pos'];
			}
		}
		//pr($arrAllParameter);
		$count				=	sizeof($arrAllParameter);				
		if( $count >0 ) { 
			$total_pages 	= ceil($count/$limit); 
		} else { 
			$total_pages 	= 0; 
		} 
		$data['records']	=	$count;
		$data['total']		=	$total_pages;
		$data['page']		=	$page;
		$data['rows'] 		= 	$arrAllParameter;
		echo json_encode($data);
	}
	
	function updateCity(){
		
		$this->db->select('id,city,state_id,city_id as cityId4');
		$this->db->join('cities','cities.cityId=kols.city_id','left');
		$this->db->where_not_in('city_id','');
		$this->db->where('is_imported',1);
		$arrResultSet = $this->db->get('kols');
		
		foreach($arrResultSet->result_array() as $row){
			$arrCities[]=$row;
		}
	//	pr($arrCities);
		
		foreach($arrCities as $row1){
			$arr=array();
			$this->db->select('cityId');
			if($row1['state_id']!=''){
				$this->db->where('regionId',$row1['state_id']);
			}
			$this->db->where('city',$row1['city']);
			$city = $this->db->get('cities');
			echo $this->db->last_query();
			foreach($city->result_array() as $row4){
				
				$row1['city_id'] = $row4['cityId'];
			}
			unset($row1['city']);
			unset($row1['state_id']);
			unset($row1['cityId4']);
			$arrKols[]=$row1;
			//echo $cityId;
			
			
		}
		
		foreach($arrKols as $row5){
			
			$this->db->where('id',$row5['id']);
			$this->db->update('kols',$row5);
		}
		
	}
	
function updateOrgCity(){
		ini_set("max_execution_time",86400);
		ini_set('memory_limit',"800M");
		$this->db->select('id,city,state_id,city_id as cityId4');
		$this->db->join('cities','cities.cityId=organizations.city_id','left');
		$this->db->where_not_in('city_id','');
		//$this->db->where('id',1414);
		$arrResultSet = $this->db->get('organizations');
		
		foreach($arrResultSet->result_array() as $row){
			$arrCities[]=$row;
		}
		
		foreach($arrCities as $row1){
			$arr=array();
			$this->db->select('cityId');
			if($row1['state_id']!=''){
				$this->db->where('regionId',$row1['state_id']);
			}
			$this->db->where('city',$row1['city']);
			$city = $this->db->get('cities');
			//echo $this->db->last_query();
			foreach($city->result_array() as $row4){
				
				$row1['city_id'] = $row4['cityId'];
			}
			unset($row1['city']);
			unset($row1['state_id']);
			unset($row1['cityId4']);
			$arrKols[]=$row1;
			//echo $cityId;
			
			
		}
		foreach($arrKols as $row5){
			
			$this->db->where('id',$row5['id']);
			$this->db->update('organizations',$row5);
			echo $this->db->last_query();
		}
		
	}
	
	
function updateOrgAffilaiteCity(){
		ini_set("max_execution_time",86400);
		ini_set('memory_limit',"800M");
		$this->db->select('id,city,state_id,city_id as cityId4');
		$this->db->join('cities','cities.cityId=affiliates_partnerships.city_id','left');
		$this->db->where_not_in('city_id','');
		//$this->db->where('id',1414);
		$arrResultSet = $this->db->get('affiliates_partnerships');
		
		foreach($arrResultSet->result_array() as $row){
			$arrCities[]=$row;
		}
		
		foreach($arrCities as $row1){
			$arr=array();
			$this->db->select('cityId');
			if($row1['state_id']!=''){
				$this->db->where('regionId',$row1['state_id']);
			}
			$this->db->where('city',$row1['city']);
			$city = $this->db->get('cities');
			//echo $this->db->last_query();
			foreach($city->result_array() as $row4){
				
				$row1['city_id'] = $row4['cityId'];
			}
			unset($row1['city']);
			unset($row1['state_id']);
			unset($row1['cityId4']);
			$arrKols[]=$row1;
			//echo $cityId;
			
			
		}
		foreach($arrKols as $row5){
			
			$this->db->where('id',$row5['id']);
			$this->db->update('affiliates_partnerships',$row5);
			//echo $this->db->last_query();
		}
		
	}
}