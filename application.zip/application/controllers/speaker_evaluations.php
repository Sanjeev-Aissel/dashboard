<?php

/**
 * This is Controller for 'Access Objects'
 * 
 * @author Ramesh B
 * @since  3.6
 * @package application.controllers	
 * @created 21-12-2011
 */
class speaker_evaluations extends Controller {

    private $loggedUserId = null;

    //Constructor
    function speaker_evaluations() {
        parent::Controller();
        $this->load->model('common_helpers');
        $this->load->model('speaker_evaluation');
        $this->loggedUserId = $this->session->userdata('user_id');
    }

    function add_evaluation($kolId) {
        $this->load->model('kol');
        $this->load->model('client_user');
        $data['arrKolDetail'] = $this->kol->editKol($kolId);

        $userId = $this->session->userdata('user_id');
        $data['userDetails'] = $this->client_user->getUserdetail($userId);
        $data['contentPage'] = 'speakers/add_evaluation_form';
        $formData = $_POST;
        $formData = json_encode($formData);
        $arrLogDetails = array(
            'type' => LOG_ADD,
            'description' => 'Add Speaker',
            'status' => 'success',
            'transaction_id' => '',
            'transaction_table_id' => SPEAKER_EVALUATIONS,
            'transaction_name' => "Add Sepaker",
            'form_data' => $formData
        );
        $this->config->set_item('log_details', $arrLogDetails);

        log_user_activity($arrLogDetails, true);
        //$this->load->view('speakers/add_evaluation_form');
        $this->load->view('speakers/add_evaluation_form', $data);
    }

    function save_evaluation($kolId = null) {
        $arrQuestions = array(1 => 'Product / Topic Knowledge', 2 => 'Effectiveness of delivery', 3 => 'Ability to answer questions', 4 => "Ability to hold the audience's
attention", 5 => 'Ability to engage audience in discussion', 6 => 'Provided an impactful presentation', 7 => 'Ability to present in fair and balanced manner');
        //pr($_POST);
        $_POST['speaker_background'] = implode(', ', $_POST['speaker_background']);
        $arr = $_POST;
        foreach ($arr as $key => $row) {
            if ($key == 'program_date') {
                list($month, $day, $year) = split('[/.-]', $row);
                $row = $year . "-" . $month . "-" . $day;
            }
            $arr1[$key] = trim($row);

            //	$arrRatings[] = 
        }
        $arr1['venu_city'] = $_POST['city'];
        if (!empty($_POST['state'])) {
            $arr1['venu_city'] .= ', ' . $_POST['state'];
        }
        foreach ($arrQuestions as $quest => $row) {
            $arr2[$quest] = $arr1['speaker_rate_' . $quest];
            unset($arr1['speaker_rate_' . $quest]);
        }
        //pr($arr2);
        //	pr($arr1);
        $genericId = $this->common_helpers->getGenericId("Speaker Evaluation");
        $arr1['generic_id'] = $genericId;
        $arr1['kol_id'] = $kolId;
        $arr1['created_by'] = $this->loggedUserId;
        $arr1['created_on'] = date('Y-m-d H:i:s');
        //pr($arr1);
        $lastId = $this->speaker_evaluation->saveEvaluation($arr1);
        foreach ($arr2 as $key => $row) {
            $arrRatings = array();
            $arrRatings['parent_question_id'] = $lastId;
            $arrRatings['question_id'] = $key;
            $arrRatings['value'] = $row;
            $this->speaker_evaluation->saveSpeakerRating($arrRatings);
        }

   $formData = $_POST;
        $formData = json_encode($formData);
        $arrLogDetails = array(
           'type' => LOG_SAVE,
            'description' => 'Save Speaker',
            'status' => 'success',
            'transaction_id' => $lastId,
            'transaction_table_id' => SPEAKER_EVALUATIONS,
            'transaction_name' => "Save Speaker",
            'module'=>'Speaker Evaluation',
            'parent_object_id'=>$kolId,
            'user_id'=>'',
            
            'form_data' => $formData
        );
        $this->config->set_item('log_details', $arrLogDetails);

        log_user_activity($arrLogDetails, true);
    }

    function list_surveys() {
        $data['contentPage'] = 'speakers/list_speaker_evaluation';
        //$data['subContentPage']	=	$subContentPage;
        $this->load->view('layouts/client_view', $data);
    }

    function list_speaker_details($kolId = null) {
        $page = (int) $this->input->post('page'); // get the requested page 
        $limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid     	

        $arrDetail = $this->speaker_evaluation->getSpeakerDetail($kolId);
//echo $this->db->last_query();

//			pr($arrInteractionsResults);


        $count = sizeof($arrDetail);
        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        } else {
            $total_pages = 0;
        }
        $data['records'] = $count;
        $data['total'] = $total_pages;
        $data['page'] = $page;
        $data['rows'] = $arrDetail;


        echo json_encode($data);
    }

    function view_micro_detail($id) {
        $formData = $_POST;
        $formData = json_encode($formData);
        $arrLogDetails = array(
            'type' => LOG_VIEW,
            'description' => 'View Speaker',
            'status' => 'success',
            'transaction_id' => $id,
            'transaction_table_id' => SPEAKER_EVALUATIONS,
            'transaction_name' => "View Speaker",
            'form_data' => $formData
        );
        $this->config->set_item('log_details', $arrLogDetails);

        log_user_activity($arrLogDetails, true);
        $data['arrDetail'] = $this->speaker_evaluation->getDetail($id);
      
        
       
        $data['arrDetail']['program_date'] = sql_date_to_app_date($data['arrDetail']['program_date']);
        $data['arrDetail']['created_on'] = sql_date_to_app_date($data['arrDetail']['created_on']);
        $data['ratingDetais'] = $this->speaker_evaluation->getRatingDetail($id);
//         pr( $data['ratingDetais']);
        if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
	/* special ajax here */
             if($data['arrDetail']['old_data']!=1)
               $this->load->view('speakers/micro_view', $data);
           else
               $this->load->view('speakers/micro_view_old', $data);
   
	
       
        }
        else{
          
           if($data['arrDetail']['old_data']!=1)
                $data['contentPage'] = 'speakers/micro_view';
           else
                $data['contentPage'] = 'speakers/micro_view_old';
        $this->load->view('layouts/client_view', $data);
        }
        
    }

    function list_speaker_detail_report() {
//              $data=$_POST;
//           pr($data);exit;
        $data['results'] = $this->speaker_evaluation->getSpeakerFilteredData();
        $data['results_rating'] = $this->speaker_evaluation->getSpeakerRatingFilteredData();

        $data = $this->load->view('speakers/filter_results', $data);
        echo $data;
        // echo json_encode($data);
    }
    
    function send_email_for_export() {
       $config['protocol'] = PROTOCOL;
        $config['smtp_host'] = HOST;
        $config['smtp_port'] = PORT;
        $config['smtp_user'] = USER;
        $config['smtp_pass'] = PASS;
        $config['mailtype'] = 'html';
        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->initialize($config);
        $this->email->clear();
        $this->email->set_newline("\r\n");
        $this->email->from(USER, SENDER);
       // $this->email->to("shrutip@aissel.com");
       
       // $this->email->to("shrutip@aissel.com");
        $loggedInUserName=$this->session->userdata('user_full_name');
        $loggedInUserName = substr($loggedInUserName, 0, strpos($loggedInUserName, ' '));
        $messageBody='Hi  ' .$loggedInUserName . ', <br/><br/> Attached is the export of Speaker Evaluation report data from '.PRODUCT_NAME;
        $loggedInUserEmail=$this->session->userdata('email');
        $this->email->to($loggedInUserEmail);
        $this->email->message($messageBody);
        $this->email->subject(PRODUCT_NAME.":Speaker Evaluation");
       
       
       
        
           // $this->email->message("hjkh");
            $path = $this->export_speaker_report();
        
        
           $this->email->attach($path);
        if ($this->email->send()) {
            $emailData['status'] = 'Excel has been mailed successfully';
//            unlink($path);
            
        } else {
            $emailData['status'] = 'Mail not sent';
        }
//echo $this->email->print_debugger();
        echo $emailData['status'];
       // return $emailData;
    }
         function export_speaker_report(){
        $fileName="Spekaer_Evaluation";
//		error_reporting(E_ALL);
		$startTime = microtime(true);
		ini_set('memory_limit',"-1");
		ini_set("max_execution_time",0);
		$this->load->plugin('php_excel/Classes/PHPExcel.php');
//		$exportOpts		= $this->input->post('export_opts');
		$speakerIds			= $this->input->post('coaching');
               
             
		$arrSpeakerIds 		= explode(',',$speakerIds);
             
               
		// Get PIN
//		$kolArray	=	$this->kol->getKolsIdAndPin();
		// Get the list of Specialties
//		$this->load->model('Specialty');
//		$arrSpecialties	=	$this->Specialty->getAllSpecialties();
//		$exportOpts = array();
//		$exportOpts[] = "professional";
//		$exportOpts[] = "contact";
//		$exportOpts[] = "biography";
//		$exportOpts[] = "education";
//		$exportOpts[] = "affiliation";
//		$exportOpts[] = "event";
//		$exportOpts[] = "publication";
//		$exportOpts[] = "trial";
//		$exportOpts[] = "media";
//		pr($exportOpts);
//		exit;
//		$clientId = $this->session->userdata('client_id');
		    if(IS_IPAD_REQUEST){
                 
            $path = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/kol_personal_documents/" . $fileName . ".xls";
       $objPHPExcel = new PHPExcel($path);
        }
        else{
           $objPHPExcel = new PHPExcel($path);
        }
//		$objPHPExcel = new PHPExcel();
//		$objPHPExcel->setActiveSheetIndex(0);
//		$arrKolIds = array(2016,1619,1976,264,2018);
		$arrExcelData = array();
		
			$arrSpeakerDetails = $this->speaker_evaluation->exportSpeakerReport($arrSpeakerIds);
                         
                      
               
		
		        
//		foreach ($arrKolIds as $kolsId){
//			$arrKolDetails	=	$this->kol->getKolDetailsById($kolId);
//			if(in_array('professional', $exportOpts)){
				//New Worksheet
				$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
//				$objWorksheet = $objPHPExcel->getActiveSheet();
				$objWorksheet->setTitle('Sepaker Report');
				//Add header
//				$objWorksheet->setCellValue('A1', 'User Name')//map to--->response
								$objWorksheet->setCellValue('A1', 'Evaluator')//response
								->setCellValue('B1', 'Evaluator Name')//evaluatroname
								->setCellValue('C1', 'Program Date')//response
                                                                ->setCellValue('D1', 'Number Of Attendees')//response
                                                                ->setCellValue('E1', 'Speaker Detail')//response
                                                                ->setCellValue('F1', 'Speaker Name')//speakername
                                                                ->setCellValue('G1', 'Speaker Background')//response
                                                                ->setCellValue('H1', 'Speaker Background-Other')//speakertext
                                                                ->setCellValue('I1', ' Was this a co-moderated program?')//response
                                                                ->setCellValue('J1', 'Venue')//response
                                                                ->setCellValue('K1', 'City')//city,State
                                                                ->setCellValue('L1', 'State')//city,State
                                                                ->setCellValue('M1', 'Was venue appropriate for a promotional educational presentation (low noise level, private room/area, minimal distractions and modest venue)?')//response
                                                                ->setCellValue('N1', 'Venue Comments')//venue comments
                                                                ->setCellValue('O1', 'Did audio/visual setup work properly?')//response
                                                                ->setCellValue('P1', 'Audio Setup Comments')//Audio Setup Comments
                                                                ->setCellValue('Q1', 'Program Topic')//response
                                                                ->setCellValue('R1', 'Abilify Maintena')//response
                                                                ->setCellValue('S1', 'Rexulti')//response
                                                                ->setCellValue('T1', 'Nuedexta')//response
                                                                ->setCellValue('U1', 'Samsca')//response
                                                                ->setCellValue('V1', 'Disease State')//response
                                                                ->setCellValue('W1', 'Psychu')//response
                                                                      
                                                                ->setCellValue('X1', '  Were the attendees the appropriate audience for the topic(s) presented?')//response
                                                                ->setCellValue('Y1', 'What actions were taken to assure only appropriate individuals were in the audience?')//response
                                                                        
                                                                ->setCellValue('AN1', 'Did the speaker stay within label during the presentation?')//response
                                                                ->setCellValue('AO1', 'Did the speaker minimize or dismiss product safety information?')//response
                                                                ->setCellValue('AP1', 'Was all off label discussion appropriately handled per Otsuka policy including documentation using a MIRF?')//response
                                                                ->setCellValue('AQ1', 'Other Mirf')//other mirf
                                                                ->setCellValue('AR1', 'Were any adverse events reported by any attendee during the event?')//response
                                                                ->setCellValue('AS1', 'Was the adverse event reported as per Otsuka Policy?')//response
                                                                ->setCellValue('AT1', 'Was the speakers articulation of their experience with the product on label?')//response
                                                                
                                                                ->setCellValue('AG1', 'Speaker Articulation Comment')//Speaker Articulation Comment
                                                                ->setCellValue('AH1', 'Was all off label discussion appropriately handled per Otsuka policy including documentation using a MIRF')//response
                                                                ->setCellValue('AI1', 'Other Off Label')//mirf Comment
                                                                ->setCellValue('AJ1', 'Speaker was compliant based on Otsukas Regulatory and Compliance Guidelines:')//response
                                                                ->setCellValue('AK1', 'On a scale of 15(1 = extremely unlikely; 5 = Extremely likely),How likely would you be to recommend this speaker to continue to be utilized by Otsuka?')//response
                                                                ->setCellValue('AL1', 'Recommend speaker for MSL followup visit for support (if any rating 3 or lower on any category, or identified need for greater than quarterly support): ')//rseponse
                                                                ->setCellValue('AM1', 'MSL followup comment')//Msl Followup Comment
                                                               
                                                                ->setCellValue('Z1', 'Speaker Rating-Product / Topic Knowledge')//response
                                                                ->setCellValue('AA1', 'Speaker Rating-Effectiveness of delivery')//response
                                                                ->setCellValue('AB1', 'Speaker Rating-Ability to answer questions')//rseponse
                                                                ->setCellValue('AC1', 'Speaker Rating-Ability to hold the audience engage audience in discussion')//rseponse
                                                                ->setCellValue('AD1', 'Speaker Rating-Ability to engage audience in discussion')//rsponse
                                                                ->setCellValue('AE1', 'Speaker Rating-Provided an impactful presentation')//rsponse
                                                                ->setCellValue('AF1' , 'Speaker Rating-Ability to present in fair and balanced manner')//rseponse
                           
                                        
                                        
                                        ;
//								->setCellValue('E1', 'Topics')
//								->setCellValue('F1', 'Sphere of Influence')
//								->setCellValue('G1', 'Summarize Medical Insight')
//								->setCellValue('H1', 'Describe Relevance to OPDCI')
//								->setCellValue('I1', 'Actions to consider')
//								->setCellValue('J1', 'Recorded By');
//					
//				if($clientId==INTERNAL_CLIENT_ID){
//					$objWorksheet->setCellValue('P1', 'Url');
//				}
				$i	=	2;
				
//					$arrKolDetails	=	$this->kol->getKolDetailsById($kolsId);
                                
                              
					foreach($arrSpeakerDetails as $row){
                                          
//						$objWorksheet->setCellValue('A'.$i, $row['user_name'])
									$objWorksheet->setCellValue('A'.$i, $row['evaluator'])
									->setCellValue('B'.$i, $row['evaluator_name'])
									->setCellValue('C'.$i, $row['program_date'])
									->setCellValue('D'.$i, $row['no_of_attendees'])
									->setCellValue('E'.$i, $row['speaker_detail'])
									->setCellValue('F'.$i, $row['speaker_name'])
									->setCellValue('G'.$i, $row['speaker_background'])
									->setCellValue('H'.$i, $row['speaker_text'])
									->setCellValue('I'.$i, $row['moderated_program'])
                                                        ->setCellValue('J'.$i, $row['venu'])
                                                        ->setCellValue('K'.$i, $row['city'])
                                                        ->setCellValue('L'.$i, $row['state'])
                                                        ->setCellValue('M'.$i, $row['venu_presentation'])
                                                        ->setCellValue('N'.$i, $row['venu_presentation_comments'])
                                                        ->setCellValue('O'.$i, $row['audio_setup'])
                                                        ->setCellValue('P'.$i, $row['audio_setup_comments'])
                                                        ->setCellValue('Q'.$i, $row['program_topic'])
                                                        ->setCellValue('R'.$i, $row['abilify_maintena'])
                                                        ->setCellValue('S'.$i, $row['rexulti'])
                                                        ->setCellValue('T'.$i, $row['nuedexta'])
                                                        ->setCellValue('U'.$i, $row['samsca'])
                                                        ->setCellValue('V'.$i, $row['disease_state'])
                                                        ->setCellValue('W'.$i, $row['psychu'])
                                                        ->setCellValue('X'.$i, $row['topic_presented'])
                                                        ->setCellValue('Y'.$i, $row['action'])
                                                        
                                                        ->setCellValue('AN'.$i, $row['speaker_stay'])
                                                        ->setCellValue('AO'.$i, $row['saftey_info'])
                                                        ->setCellValue('AP'.$i, $row['mirf_other'])
                                                        ->setCellValue('AQ'.$i, $row['mirf'])
                                                        ->setCellValue('AR'.$i, $row['adverse_event'])
                                                        ->setCellValue('AS'.$i, $row['adverse_event_report'])
                                                        ->setCellValue('AT'.$i, $row['speaker_articulation'])
                                                       
                                                        ->setCellValue('AG'.$i, $row['speaker_articulation_comment'])
                                                        ->setCellValue('AH'.$i, $row['mirf_doc'])
                                                        ->setCellValue('AI'.$i, $row['mirf_comment'])
                                                        ->setCellValue('AJ'.$i, $row['guideline'])
                                                        ->setCellValue('AK'.$i, $row['scale'])
                                                        ->setCellValue('AL'.$i, $row['msl_follow_up'])
                                                         
                                                        ->setCellValue('AM'.$i, $row['msl_follow_up_comment'])
                                                         
                                                        ->setCellValue('Z'.$i, $row['q1'])
                                                         ->setCellValue('AA'.$i, $row['q2'])
                                                         ->setCellValue('AB'.$i, $row['q3'])
                                                         ->setCellValue('AC'.$i, $row['q4'])
                                                         ->setCellValue('AD'.$i, $row['q5'])
                                                         ->setCellValue('AE'.$i, $row['q6'])
                                                         ->setCellValue('AF'.$i, $row['q7'])
                                                        
                                                        
                                                        
                                                        ;
                                               
//						if($clientId==INTERNAL_CLIENT_ID){
//							$objWorksheet->setCellValue('P'.$i, $row['url']);
//						}
						$i++;
					}
//				$objPHPExcel->getActiveSheet()->getDefaultColumnDimension()->setWidth(500);
				$objPHPExcel->addSheet($objWorksheet);
                               
//			}
			
			
			
			
			
			
			
			
			

	  // remove first sheet
        
		$styleArray = array(
			'borders' => array(
				'bottom' => array(
					'style' => PHPExcel_Style_Border::BORDER_THICK,
					'color' => array('argb' => '0000000'),
				),
			),
		);
		
		$arrStyles =  array(
                  'font'    => array(
                      'bold'      => true,
                      'italic'    => false
                  ),
                  'borders' => array(
                      'bottom'     => array(
                          'style' => PHPExcel_Style_Border::BORDER_THICK,
                          'color' => array(
                              'rgb' => '000000'
                          )
                      ),
                      'quotePrefix'    => true
                  )
              );
        // remove first sheet
        $objPHPExcel->removeSheetByIndex(0);
        // iterate each sheet and add the style for each sheet
		foreach ($objPHPExcel->getWorksheetIterator() as $sheet){
			$exportOpts = array(strtolower($sheet->getTitle()));
			//if(in_array('professional',$exportOpts)){
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach(range('A','D') as $columnID) {
				    $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
//				     $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
	        	$objPHPExcel->getActiveSheet()->getStyle('A1:D1')->applyFromArray($arrStyles); 
	      //  }
			
			
		}
		$objPHPExcel->setActiveSheetIndex(0);
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		// Redirect output to a client’s web browser (Excel2007)
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment;filename="speaker_report.xlsx"');
		header('Cache-Control: max-age=0');
		// If you're serving to IE 9, then the following may be needed
		header('Cache-Control: max-age=1');
		// If you're serving to IE over SSL, then the following may be needed
		header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
		header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
		header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
		header ('Pragma: public'); // HTTP/1.0
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
                 if(IS_IPAD_REQUEST){
                     $objWriter->save($path);
            return $path;
                 }
                 else
		$objWriter->save('php://output');
		exit;
	}
        
        function import(){
            
            $result = $this->db->query('select * from  speaker_import ');
           
            $data=array();
  


            foreach ($result->result_array() as $values) {
                $kol=explode(" ",$values['speaker_name']);
                pr($kol);
         $resultKolId = $this->db->query('select id from  kols where first_name = "'.$kol['0'].'" AND last_name = "'.$kol['1'].'" ');
         $kols=$resultKolId->row_array();
         $bg=array();
         if($values['academic']!='')
            $bg[]=$values['academic'];
         if($values['private']!='')
            $bg[]=$values['private'];
           if($values['hospital']!='')
               $bg[]=$values['hospital'];
             if($values['community']!='')
                  $bg[]=$values['community'];
              if($values['bgother']!='')
                     $bg[]=$values['bgother'];
          $background=implode(',',$bg);
          $data['kol_id']=$kols['id'];
                $data['evaluator']=$values['eval'];
                $eval=explode(" ",$values['evalname']);
                $evalResult=$this->db->query('select id from  client_users where first_name ="'.$eval['0'].'" AND last_name="'.$eval['1'].'" ');
                 $evalId=$evalResult->row_array();
                 $data['speaker_excel_msl']=$values['evalname'];
                $data['evaluator_name']=$values['evalname'];
                         $data['program_date']=date("Y-m-d", strtotime( $values['dop']));
//                          $data['program_date']=sql_date_to_app_date( $data['program_date']);
//                          echo $data['program_date'];
                         $data['no_of_attendees']=$values['attendees'];
                         $data['speaker_detail'] =$values['speaker_type'];
                         $data['speaker_name']=$values['speaker_name'];
                         $data['speaker_background']=$background;
                         $data['speaker_text']=$values['eval'];
                         $data['moderated_program']=$values['q6'];
                         $data['venu']=$values['q7'];
                         $data['venu_city']=$values['q7citystate'];
                         $data['venu_presentation']=$values['q8'];
                         $data['venu_presentation_comments']=$values['q8comment'];
                         $data['audio_setup']=$values['q9'];
                         $data['audio_setup_comments']=$values['q9comment'];
                            $data['program_topic']=$values['q10'];
                         $data['abilify_maintena']=$values['q11'];
                         $data['rexulti']=$values['q12'];
                         $data['nuedexta']=$values['q13'];
                         $data['samsca']=$values['q14'];
                 $data['disease_state']=$values['q15'];
                         $data['psychu']=$values['q16'];
                         $data['topic_presented']=$values['q17'];
                         $data['action']=$values['q18'];
                         $data['speaker_stay']=$values['q19'];
                         $data['saftey_info']=$values['q20'];
                         $data['mirf_other']=$values['q21'];
                         $data['mirf']=$values['q22'];
                         $data['adverse_event']=$values['q23'];
                         $data['adverse_event_report']=$values['q24'];
                         $data['speaker_articulation']=$values['q25'];
                         $data['speaker_articulation_comment']=$values['q25comment'];
                         $data['mirf_doc']=$values['q26'];
                         $data['mirf_comment']=$values['q26comment'];
                         $data['guideline']=$values['q27'];
                         $data['scale']=$values['q28'];
                         $data['msl_follow_up']=$values['q29'];
                         $data['msl_follow_up_comment']=$values['q29comment'];
                         $data['created_by']=$evalId['id'];
                         $data['created_on']='';
                         $data['generic_id']='';
                         $data['city']='';
                         $data['city_id']='';
                         $data['state']='';
                         $data['state_id']='';
                         $data['country']='';
                         $data['country_id']='';
                         $this->db->insert("speaker_evaluations",$data);
                      
        }
        }
        function importRatings(){
            
             $result = $this->db->query('select * from  speaker_import ');
           
            $data=array();
  
$i=1;

            foreach ($result->result_array() as $values) {
               $data['parent_question_id']=$i;
                         $data['question_id']='1';
                         $data['value']=$values['q19q1'];
                         $this->db->insert("speaker_ratings",$data);  
                           
                            $data['parent_question_id']=$i;
                         $data['question_id']='2';
                         $data['value']=$values['q19q2'];
                         $this->db->insert("speaker_ratings",$data);  
                            $data['parent_question_id']=$i;
                         $data['question_id']='3';
                         $data['value']=$values['q19q3'];
                         $this->db->insert("speaker_ratings",$data);  
                            $data['parent_question_id']=$i;
                         $data['question_id']='4';
                         $data['value']=$values['q19q4'];
                         $this->db->insert("speaker_ratings",$data);  
                            $data['parent_question_id']=$i;
                         $data['question_id']='5';
                         $data['value']=$values['q19q5'];
                         $this->db->insert("speaker_ratings",$data);  
                            $data['parent_question_id']=$i;
                         $data['question_id']='6';
                         $data['value']=$values['q19q6'];
                         $this->db->insert("speaker_ratings",$data);  
                            $data['parent_question_id']=$i;
                         $data['question_id']='7';
                         $data['value']=$values['q19q7'];
                         $this->db->insert("speaker_ratings",$data);  
                         $i++;
            }
        }

}
