<?php
/**
 * Page to select the kol profile portions to delete
 * 
 * @author Ambarish 
 * @since	2.5
 * @created: 24-06-2011
 */
?>
<script type="text/javascript">
	checked=false;
	function selectAll(){
		var aa= document.getElementById('deleteform');
		 if(checked == false){
	           checked = true;
		 }else{
	          checked = false;
		 }
		 
		for (var i =0; i < aa.elements.length; i++){
			aa.elements[i].checked = checked;
		}
	}
	function showNextPage(){
		var values = new Array();
		$.each($("input[name='delete_opts[]']:checked"), function() {
		  values.push($(this).val());
		});
		$.each($("input[name='edu_delete_opts[]']:checked"), function() {
			  values.push($(this).val());
			});
		$.each($("input[name='aff_delete_opts[]']:checked"), function() {
			  values.push($(this).val());
			});
		if(values == ""){
			jAlert("Please select atleast one checkbox to delete");
			return false;	
		}
		$('#deleteform').submit();
	}
	function showBackPage(){
		$("#downloadOrEmail").hide();
		$("#selectionBox").show();
	}
	 	
</script>
<style type="text/css">
	table#deleteTable {
	    width: 100%;
	}
	 #deleteTable label {
	 	font-family: lucida Grande;
		font-size: 12px;
		background-color:#FFFFFF;
		display:inline;
		padding-right:10px;
		text-align:right;
		width:90px;
		line-height: 30px;
	}
	#selectionBox img{
	 margin-left: 23%;
	}
	hr {
    margin: 5px auto;
	}
	input[type="checkbox"] {
    vertical-align: middle;
    margin: 0px 4px 0 0 !important;
}
</style>

<form action="<?php echo base_url().'kols/kol_delete_opts';?>" name="koldeleteForm" method="post" id="deleteform">
	<div id="selectionBox"> 
		<input type="hidden" name="is_from_client_visibility" value="<?php echo $is_from_client_visibility; ?>"/>
		<input type="hidden" name="client_id_from_kol_visibility" value="<?php echo $client_id_from_kol_visibility; ?>"/>
		<input  type="hidden" name="kol_id" id="kolId" value="<?php echo $arrKols?>"></input>
		<img  width="25" alt="Excel" src="<?php echo base_url().'images/delete.png'?>" />&nbsp;<label>Please select what you want to delete?</label>
		<table id="deleteTable" border="0">
			<tr>
				<td>
					<input type="checkbox" name="full_profile" value="full" onclick='selectAll();'/><label>Full Profile</label>
				</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>
					<input type="checkbox" name="delete_opts[]" value="contact" class="deleteOpts"/><label>Contact Info</label>
				</td>
				<td>
					<input type="checkbox" name="delete_opts[]" value="events" class="deleteOpts"/><label>Events</label>
				</td>
				<td>
					<input type="checkbox" name="delete_opts[]" value="trails" class="deleteOpts"/><label>Trails</label>
				</td>
			</tr>
			<tr>
				<td>
					<input type="checkbox" name="delete_opts[]" value="publications" class="deleteOpts"/><label>Publications</label>			
				</td>
				<td>
					<input type="checkbox" name="delete_opts[]" value="dasboard" class="deleteOpts"/><label>Dashboard Data</label>
				</td>
				<td>
					<input type="checkbox" name="delete_opts[]" value="profile" class="deleteOpts"/><label>Profile Level Notes</label>
				</td>
			</tr>
			<tr>
				<td>
					<input type="checkbox" name="delete_opts[]" value="assessments" class="deleteOpts"/><label>Assessments</label>
				</td>
				<td>
					<input type="checkbox" name="delete_opts[]" value="media" class="deleteOpts"/><label>Social media</label>
				</td>
				<td>
					<input type="checkbox" name="delete_opts[]" value="interactions" class="deleteOpts"/><label>Interactions</label>
				</td>
			</tr>
			<tr>
				<td>
					<input type="checkbox" name="delete_opts[]" value="payments" class="deleteOpts"/><label>Payments</label>
				</td>
				<td>
					<input type="checkbox" name="delete_opts[]" value="planning" class="deleteOpts"/><label>Planning</label>
				</td>
				<td>
					<input type="checkbox" name="delete_opts[]" value="contracts" class="deleteOpts"/><label>Contracts</label>
				</td>
			</tr>
			<tr>
				<td>
					<input type="checkbox" name="delete_opts[]" value="lists" class="deleteOpts"/><label>My List</label>
				</td>
				<td>
					<input type="checkbox" name="delete_opts[]" value="surveys" class="deleteOpts"/><label>Surveys</label>
				</td>
				<td>
					<input type="checkbox" name="delete_opts[]" value="identify" class="deleteOpts"/><label>Identify</label>
				</td>
			</tr>
			<tr><td colspan="3"><hr></td></tr>
			<tr>
				<td colspan="3">
					<label>Education</label><input type="hidden" name="delete_opts[]" value="education"/>
					<table id="educationSubBox">
					<tr>
						<td>
							<input type="checkbox" name="edu_delete_opts[]" value="edu_education" id="edudelopts" class="deleteOpts "/><label>Education</label>
							
						</td>
						<td>
							<input type="checkbox" name="edu_delete_opts[]" value="edu_training" id="edudelopts" class="deleteOpts"/><label>Training</label>
						</td>
						<td>
							<input type="checkbox" name="edu_delete_opts[]" value="edu_certifications" id="edudelopts" class="deleteOpts"/><label>Certifications</label>
						</td>
						<td>
							<input type="checkbox" name="edu_delete_opts[]" value="edu_awards" id="edudelopts" class="deleteOpts"/><label>Awards</label>
						</td>
					</tr>
					</table>
				</td>
				
			</tr>
			<tr><td colspan="3"><hr></td></tr>
			<tr>
				<td colspan="3">
					<label>Affiliations</label><input type="hidden" name="delete_opts[]" value="affiliation"/>
					<table id="affiliationSubBox">
					<tr>
						<td>
							<input type="checkbox" name="aff_delete_opts[]" value="aff_association" class="deleteOpts "/><label>Association</label>
							
						</td>
						<td>
							<input type="checkbox" name="aff_delete_opts[]" value="aff_government" class="deleteOpts"/><label>Government</label>
						</td>
						<td>
							<input type="checkbox" name="aff_delete_opts[]" value="aff_industry" class="deleteOpts"/><label>Industry</label>
						</td>
						<td>
							<input type="checkbox" name="aff_delete_opts[]" value="aff_university" class="deleteOpts"/><label>University</label>
						</td>
						<td>
							<input type="checkbox" name="aff_delete_opts[]" value="aff_others" class="deleteOpts"/><label>Others</label>
						</td>
					</tr>
					</table>
				</td>
				
			</tr>
			<tr>
				<td><br/></td>
			</tr>
			<tr>
				<td colspan="3" style="text-align:center;"><input type="button" name="next" value="Delete" id="next" class="btn btn-danger" onclick="showNextPage();"/></td>
			</tr>
		</table>
	</div>
</form>