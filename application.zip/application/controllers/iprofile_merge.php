<?php
/*
 * Controller for merging iProfile operations
 *  
 * @author Ramesh B
 * @package application.controllers
 * @created 14-01-2015
 *  
 */
class Iprofile_Merge extends Controller{
	
	// constructor to initialize the data
	function Iprofile_Merge(){
		parent::Controller();
		$this->load->model('imap');
	}
	
	function merge_users(){
		$arrUsers = $this->iprofile->geAllUsers(9);
		foreach($arrUsers as $user){
			$oldUserId = $user['id'];
			$newUserId = $this->imap->getUserIdByEmail($user['email']);
			if($newUserId){
				//$this->iprofile->updateUserIds($oldUserId,$newUserId);
			}else{
				//$user['client_id'] =12
				$newUserId = $this->imap->insertUser($user);
				pr($oldUserId."-".$newUserId);
			}
			//$this->iprofile->updateUserIds($oldUserId,$newUserId);
		}
	}
	
	function merge_survey_answers(){
		$arrSurveyAnsweres = $this->iprofile->getSurveyAnsweres();
		foreach($arrSurveyAnsweres as $row){
			$newRespId = 0;
			$newNominId = 0;
			$stagingRespId = 0;
			if($row['resp_kol_id'] != 0){
				$mdmid = $this->imap->getKolMDMID($row['resp_kol_id']);
				//pr($row['resp_kol_id']);
				if($mdmid != false && $mdmid != null){
					$respContact = $this->imap->getIcontactByMDMID($mdmid);
					$newRespId = $respContact['id'];
					//pr($respContact);
					//pr($mdmid);
				}else{
					//Insert in to staging contacts and get the staging respondetnt id
					$arrStagingResp = array();
					$stagingRespId = $this->imap->saveStagingIContact($arrStagingResp);
				}
			}
			if($row['kol_id'] != 0){
				$mdmid = $this->imap->getKolMDMID($row['kol_id']);
				//pr($row['kol_id']);
				if($mdmid != false && $mdmid != null){
					//get icontact id for this mdmid
					$nomContact = $this->imap->getIcontactByMDMID($mdmid);
					$newNominId = $nomContact['id'];
					//pr($nomContact);
					//pr($mdmid);
				}else{
					//if no record, then add to staging contacts
					//$arriContactDetails  = array();
					//$arriContactDetails['master_customer_id'] = 
				}
			}else{
			
			}
			
			if($newNominId != 0 && $newRespId != 0){
				echo "Match.......................";
				//Prepare array and insert in to survey answeres
			}
		}
	}
	
	function merge_survey_answers_mdmid(){
		ini_set("max_execution_time",26000);
		$arrSurveys = $this->imap->getSurveys();
		foreach($arrSurveys as $survey){
			$surveyRespondents = $this->iprofile->getSurveyResponses($survey['id']);
			//pr($surveyRespondents);
			foreach($surveyRespondents as $respId => $arrResponses){
				$newRespId = 0;
				$stagingRespId = 0;
				$firstRow = $arrResponses[0];
				if($firstRow['resp_kol_id'] != 0){
					$mdmid = $this->imap->getKolMDMID($firstRow['resp_kol_id']);
					//pr($row['resp_kol_id']);
					if($mdmid != false && $mdmid != null){
						$respContact = $this->imap->getIcontactByMDMID($mdmid);
						$newRespId = $respContact['id'];
						//pr($respContact);
						//pr($mdmid);
					}else{
						//Insert in to staging contacts and get the staging respondetnt id
						$arrStagingResp = array();
						$arrStagingResp['first_name'] = $firstRow['first_name'];
						$arrStagingResp['middle_name'] = $firstRow['middle_name'];
						$arrStagingResp['last_name'] = $firstRow['last_name'];
						$arrStagingResp['organization'] = $firstRow['resp_org'];
						$arrStagingResp['specialty'] = $firstRow['specialty'];
						$arrStagingResp['city'] = $firstRow['respondent_city'];
						$arrStagingResp['state'] = $firstRow['respondent_state'];
						$arrStagingResp['country'] = $firstRow['respondent_country'];
						$arrStagingResp['postal_code'] = $firstRow['respondent_postal'];
						$arrStagingResp['created_by'] = $firstRow['created_by'];
						$arrStagingResp['created_on'] = $firstRow['created_on'];
						$arrStagingResp['survey_id'] = $firstRow['survey_id'];
						$stagingRespId = $this->imap->saveStagingIContact($arrStagingResp);
					}
				}else{
					$firstName = '';
					$middleName = '';
					$lastName = '';
					$name = $firstRow['resp_name'];
					$nameEls = explode(" ",$name);
					$firstName = $nameEls[0];
					if(count($nameEls) == 2){
						$lastName = $nameEls[1];
					}else{
						$middleName = $nameEls[1];
						unset($nameEls[0]);
						unset($nameEls[1]);
						$lastName = implode(" ",$nameEls);
					}
					$arrStagingResp['first_name'] = $firstName;
					$arrStagingResp['middle_name'] = $middleName;
					$arrStagingResp['last_name'] = $lastName;
					$arrStagingResp['organization'] = $firstRow['resp_org'];
					$arrStagingResp['specialty'] = $firstRow['specialty'];
					$arrStagingResp['city'] = $firstRow['respondent_city'];
					$arrStagingResp['state'] = $firstRow['respondent_state'];
					$arrStagingResp['country'] = $firstRow['respondent_country'];
					$arrStagingResp['postal_code'] = $firstRow['respondent_postal'];
					$arrStagingResp['created_by'] = $firstRow['created_by'];
					$arrStagingResp['created_on'] = $firstRow['created_on'];
					$arrStagingResp['survey_id'] = $firstRow['survey_id'];
					$stagingRespId = $this->imap->saveStagingIContact($arrStagingResp);
				}
				
				
				foreach($arrResponses as $resp){
					$newNominId = 0;
					$firstName = '';
					$middleName = '';
					$lastName = '';
					$name = $resp['name'];
					$nameEls = explode(" ",$name);
					$firstName = $nameEls[0];
					if(count($nameEls) == 2){
						$lastName = $nameEls[1];
					}else{
						$middleName = $nameEls[1];
						unset($nameEls[0]);
						unset($nameEls[1]);
						$lastName = implode(" ",$nameEls);
					}
					$arrSurveyDetails = array();
					//if its kol and respondent is also presnet in icontacts
					if($resp['kol_id'] != 0 && $newRespId != 0){
						$mdmid = $this->imap->getKolMDMID($resp['kol_id']);
						//pr($row['kol_id']);
						if($mdmid != false && $mdmid != null){
							//get icontact id for this mdmid
							$nomContact = $this->imap->getIcontactByMDMID($mdmid);
							$newNominId = $nomContact['id'];
							//pr($nomContact);
							//pr($mdmid);
						}
					}
					
					//if its staging repondent , then store everything in to staging
					if($newRespId == 0 || $newNominId == 0){
						$arrNomDetails['first_name'] = $firstName;
						$arrNomDetails['middle_name'] = $middleName;
						$arrNomDetails['last_name'] = $lastName;
						$arrNomDetails['organization'] = $resp['nom_org'];
						$arrNomDetails['specialty'] = $resp['specialty'];
						$arrNomDetails['city'] = $resp['city'];
						$arrNomDetails['state'] = $resp['state'];
						$arrNomDetails['country'] = $resp['country'];
						$arrNomDetails['postal_code'] = $resp['postal'];
						$arrNomDetails['created_by'] = $resp['created_by'];
						$arrNomDetails['created_on'] = $resp['created_on'];
						$arrNomDetails['survey_id'] = $resp['survey_id'];
						$arrNomDetails['staging_respondent_id'] = $stagingRespId;
						$arrNomDetails['survey_question_id'] = $resp['question_id'];
						if($newRespId != 0){
							$arrNomDetails['survey_respondent_id'] = $resp['survey_id'];
							//$arrNomDetails['survey_respondent_address_id'] = $resp['survey_id'];
						}
						if($newNominId != 0){
							$arrNomDetails['survey_influencer_id'] = $resp['survey_id'];
							//$arrNomDetails['survey_influencer_address_id'] = $resp['survey_id'];
						}
						//$arrNomDetails['zeroInfluencers'] = $resp['survey_id'];
						
						//Store to staging iContacts
						$this->imap->saveStagingIContact($arrNomDetails);
						//pr($arrNomDetails);
					}
					
					if($newNominId != 0 && $newRespId != 0){
						//Prepare array and insert in to survey answeres
						$arrSurveyDetails = array();
						$arrSurveyDetails['question_id'] = $resp['question_id'];
						$arrSurveyDetails['created_by'] = $resp['created_by'];
						$arrSurveyDetails['created_on'] = $resp['created_on'];
						$arrSurveyDetails['nominee_id'] = $newNominId;
						$arrSurveyDetails['respondent_id'] = $newRespId;
						$arrSurveyDetails['survey_id'] = $resp['survey_id'];
						$arrSurveyDetails['is_submitted'] = 1;
						//$arrSurveyDetails['nom_address_id'] = $resp['question_id'];
						//$arrSurveyDetails['resp_address_id'] = $resp['question_id'];
						//$arrSurveyDetails['address_id'] = $resp['question_id'];
						//$arrSurveyDetails['zeroInfluencers'] = $resp['question_id'];
						$this->imap->saveSurvey($arrSurveyDetails);
						//pr($arrSurveyDetails);
					}
				}
				
			}
		}
		
	}
	
	
	function merge_survey_answers_npi(){
		$startTime	=	microtime(true);
		//$this->load->database('default',true);
		ini_set("max_execution_time",26000);
		ini_set('memory_limit','-1');
		$arrSurveys = $this->imap->getSurveys();
		//$arrSurveys[] = array('id' => 21);
		//$arrSurveys[] = array('id' => 22);
		foreach($arrSurveys as $survey){
			$surveyRespondents = $this->imap->getSurveyResponsesiProfile($survey['id']);
			//pr($surveyRespondents);
			//exit;
			foreach($surveyRespondents as $respId => $arrResponses){
				//pr($arrResponses);
				//if($respId != 1307 || $respId!= '1307')
					//continue;
				$newRespId = 0;
				$stagingRespId = 0;
				$respContact = array();
				$firstRow = $arrResponses[0];
				if($firstRow['resp_kol_id'] != 0){
					//$npiNum = $firstRow['resp_npi'];
					$npiNum = $this->imap->getKolNPI($firstRow['resp_kol_id']);
					if($npiNum != false && $npiNum != null && $npiNum != '')
						$respContact = $this->imap->getIcontactByNPI($npiNum);
					if($respContact !== false && isset($respContact['id'])){
						$newRespId = $respContact['kol_id'];
						pr('Respondent Present....................');
						//pr($respContact);
						//pr($mdmid);
					}else{
						
						//Insert in to staging contacts and get the staging respondetnt id
						$arrStagingResp = array();
						$firstName = '';
						$middleName = '';
						$lastName = '';
						$name = $firstRow['resp_name'];
						$nameEls = explode(",",$name);
						$nameEls = explode(" ",$nameEls[0]);
						$firstName = $nameEls[0];
						if(count($nameEls) == 2){
							$lastName = $nameEls[1];
						}else{
							$middleName = $nameEls[1];
							unset($nameEls[0]);
							unset($nameEls[1]);
							$lastName = implode(" ",$nameEls);
						}
						$arrStagingResp['first_name'] = $firstName;
						$arrStagingResp['middle_name'] = $middleName;
						$arrStagingResp['last_name'] = $lastName;
						$arrStagingResp['organization'] = $firstRow['resp_org'];
						$arrStagingResp['specialty'] = $firstRow['specialty'];
						$arrStagingResp['city'] = $firstRow['respondent_city'];
						$arrStagingResp['state'] = $firstRow['respondent_state'];
						$arrStagingResp['country'] = $firstRow['respondent_country'];
						$arrStagingResp['postal_code'] = $firstRow['respondent_postal'];
						$arrStagingResp['created_by'] = $firstRow['created_by'];
						$arrStagingResp['created_on'] = $firstRow['created_on'];
						$arrStagingResp['survey_id'] = $firstRow['survey_id'];
						
						$respContact = $this->imap->getIcontactByName($arrStagingResp);
						if($respContact !== false && isset($respContact['id'])){
							$newRespId = $respContact['kol_id'];
							pr('Respondent Present....................');
							//pr($respContact);
							//pr($mdmid);
						}else{
							$stagingRespId = $this->imap->saveStagingIContact($arrStagingResp);
							pr('Respondent Not Present....................saving to staging contacts');
						}
						//pr($arrStagingResp);
						
					}
				}else{
					$firstName = '';
					$middleName = '';
					$lastName = '';
					$name = $firstRow['resp_name'];
					$nameEls = explode(",",$name);
					$nameEls = explode(" ",$nameEls[0]);
					$firstName = $nameEls[0];
					if(count($nameEls) == 2){
						$lastName = $nameEls[1];
					}else{
						$middleName = $nameEls[1];
						unset($nameEls[0]);
						unset($nameEls[1]);
						$lastName = implode(" ",$nameEls);
					}
					$arrStagingResp['first_name'] = $firstName;
					$arrStagingResp['middle_name'] = $middleName;
					$arrStagingResp['last_name'] = $lastName;
					$arrStagingResp['organization'] = $firstRow['resp_org'];
					$arrStagingResp['specialty'] = $firstRow['specialty'];
					$arrStagingResp['city'] = $firstRow['respondent_city'];
					$arrStagingResp['state'] = $firstRow['respondent_state'];
					$arrStagingResp['country'] = $firstRow['respondent_country'];
					$arrStagingResp['postal_code'] = $firstRow['respondent_postal'];
					$arrStagingResp['created_by'] = $firstRow['created_by'];
					$arrStagingResp['created_on'] = $firstRow['created_on'];
					$arrStagingResp['survey_id'] = $firstRow['survey_id'];
					$arrStagingResp['resp_kol_id'] = $firstRow['resp_kol_id'];
					
					$respContact = $this->imap->getIcontactByName($arrStagingResp);
					if($respContact !== false && isset($respContact['id'])){
						$newRespId = $respContact['kol_id'];
						pr('Respondent Present....................');
						//pr($respContact);
						//pr($mdmid);
					}else{
						$stagingRespId = $this->imap->saveStagingIContact($arrStagingResp);
						pr('Respondent Not Present....................saving to staging contacts');
					}
				}
				
				
				foreach($arrResponses as $resp){
					$nomContact = array();
					$newNominId = 0;
					$firstName = '';
					$middleName = '';
					$lastName = '';
					$name = $resp['name'];
					$nameEls = explode(",",$name);
					$nameEls = explode(" ",$nameEls[0]);
					$firstName = $nameEls[0];
					if(count($nameEls) == 2){
						$lastName = $nameEls[1];
					}else{
						$middleName = $nameEls[1];
						unset($nameEls[0]);
						unset($nameEls[1]);
						$lastName = implode(" ",$nameEls);
					}
					$arrSurveyDetails = array();
					//if its kol and respondent is also presnet in icontacts
					if($resp['kol_id'] != 0 && $resp['kol_id'] != $resp['nominee_id'] && $newRespId != 0){
						$npiNum = $resp['nom_npi'];
						if($npiNum != false && $npiNum != null && $npiNum != '')
							$nomContact = $this->imap->getIcontactByNPI($npiNum);
						if($nomContact !== false && isset($nomContact['id'])){
							//get icontact id for this npi
							$newNominId = $nomContact['kol_id'];
							//pr($nomContact);
							pr("		Nominee Present..............");
						}else{
							$arrNomDetails['first_name'] = $firstName;
							$arrNomDetails['middle_name'] = $middleName;
							$arrNomDetails['last_name'] = $lastName;
							$arrNomDetails['organization'] = $resp['nom_org'];
							$arrNomDetails['specialty'] = $resp['specialty'];
							$arrNomDetails['city'] = $resp['city'];
							$arrNomDetails['state'] = $resp['state'];
							$arrNomDetails['country'] = $resp['country'];
							
							$nomContact = $this->imap->getIcontactByName($arrNomDetails);
							if($nomContact !== false && isset($nomContact['id'])){
								//get icontact id for this npi
								$newNominId = $nomContact['kol_id'];
								//pr($nomContact);
								pr("		Nominee Present..............");
							}
						}
					}
					
					//if its staging repondent , then store everything in to staging
					if($newRespId == 0 || $newNominId == 0){
						$arrNomDetails['first_name'] = $firstName;
						$arrNomDetails['middle_name'] = $middleName;
						$arrNomDetails['last_name'] = $lastName;
						$arrNomDetails['organization'] = $resp['nom_org'];
						$arrNomDetails['specialty'] = $resp['specialty'];
						$arrNomDetails['city'] = $resp['city'];
						$arrNomDetails['state'] = $resp['state'];
						$arrNomDetails['country'] = $resp['country'];
						$arrNomDetails['postal_code'] = $resp['postal'];
						$arrNomDetails['created_by'] = $resp['created_by'];
						$arrNomDetails['created_on'] = $resp['created_on'];
						$arrNomDetails['survey_id'] = $resp['survey_id'];
						$arrNomDetails['staging_respondent_id'] = $stagingRespId;
						$arrNomDetails['survey_question_id'] = $resp['question_id'];
						$arrNomDetails['nom_kol_id'] = $resp['kol_id'];
						$arrNomDetails['resp_kol_id'] = $firstRow['resp_kol_id'];
						if($newRespId != 0){
							$arrNomDetails['survey_respondent_id'] = $newRespId;
							$arrNomDetails['survey_respondent_address_id'] = $respContact['id'];
						}
						if($newNominId != 0){
							$arrNomDetails['survey_influencer_id'] = $newNominId;
							$arrNomDetails['survey_influencer_address_id'] = $nomContact['id'];
						}
						//$arrNomDetails['zeroInfluencers'] = $resp['survey_id'];
						pr("		Storing to staging contact as nominee is not present..............");
						//Store to staging iContacts
						$this->imap->saveStagingIContact($arrNomDetails);
						//pr($arrNomDetails);
					}
					
					if($newNominId != 0 && $newRespId != 0){
						//Prepare array and insert in to survey answeres
						$arrSurveyDetails = array();
						$arrSurveyDetails['question_id'] = $resp['question_id'];
						$arrSurveyDetails['created_by'] = $resp['created_by'];
						$arrSurveyDetails['created_on'] = $resp['created_on'];
						$arrSurveyDetails['nominee_id'] = $newNominId;
						$arrSurveyDetails['respondent_id'] = $newRespId;
						$arrSurveyDetails['survey_id'] = $resp['survey_id'];
						$arrSurveyDetails['is_submitted'] = 1;
						$arrSurveyDetails['nom_address_id'] = $nomContact['id'];
						$arrSurveyDetails['resp_address_id'] = $respContact['id'];
						$arrSurveyDetails['nom_kol_id'] = $resp['kol_id'];
						$arrSurveyDetails['resp_kol_id'] = $firstRow['resp_kol_id'];
						//$arrSurveyDetails['address_id'] = $resp['question_id'];
						//$arrSurveyDetails['zeroInfluencers'] = $resp['question_id'];
						$this->imap->saveSurvey($arrSurveyDetails);
						/*pr($resp);
						pr($nomContact);
						pr($arrSurveyDetails);*/
						pr("Survey Response saved.......");
					}
				}
				pr("----------------------------------------------------------------------------------------------");
			}
		}
		
		pr("Total Time Taken ".(microtime(true)-$startTime));
	}
	
	function merge_survey_answers_npi2(){
		$startTime	=	microtime(true);
		//$this->load->database('default',true);
		ini_set("max_execution_time",26000);
		ini_set('memory_limit','-1');
		$arrSurveys = $this->imap->getSurveys();
		//$arrSurveys[] = array('id' => 21);
		//$arrSurveys[] = array('id' => 22);
		foreach($arrSurveys as $survey){
			$surveyRespondents = $this->imap->getSurveyResponsesiProfile($survey['id']);
			//pr($surveyRespondents);
			//exit;
			foreach($surveyRespondents as $respId => $arrResponses){
				//pr($arrResponses);
				//if($respId != 1307 || $respId!= '1307')
					//continue;
				$newRespId = 0;
				$stagingRespId = 0;
				$respContact = array();
				$firstRow = $arrResponses[0];
				if(($firstRow['respondent_npi'] != null && $firstRow['respondent_npi'] != '') || $firstRow['resp_kol_id'] != 0){
					$npiNum = $firstRow['respondent_npi'];
					if(($npiNum == null || $npiNum == '') && $firstRow['resp_kol_id'] != 0)
						$npiNum = $this->imap->getKolNPI($firstRow['resp_kol_id']);
					if($npiNum != false && $npiNum != null && $npiNum != '')
						$respContact = $this->imap->getIcontactByNPI($npiNum);
					if($respContact !== false && isset($respContact['id'])){
						$newRespId = $respContact['kol_id'];
						pr('Respondent Present....................');
						//pr($respContact);
						//pr($mdmid);
					}else{
						
						//Insert in to staging contacts and get the staging respondetnt id
						$arrStagingResp = array();
						$firstName = '';
						$middleName = '';
						$lastName = '';
						$name = $firstRow['resp_name'];
						$nameEls = explode(",",$name);
						$nameEls = explode(" ",$nameEls[0]);
						$firstName = $nameEls[0];
						if(count($nameEls) == 2){
							$lastName = $nameEls[1];
						}else{
							$middleName = $nameEls[1];
							unset($nameEls[0]);
							unset($nameEls[1]);
							$lastName = implode(" ",$nameEls);
						}
						$arrStagingResp['first_name'] = $firstName;
						$arrStagingResp['middle_name'] = $middleName;
						$arrStagingResp['last_name'] = $lastName;
						$arrStagingResp['organization'] = $firstRow['resp_org'];
						$arrStagingResp['specialty'] = $firstRow['specialty'];
						$arrStagingResp['city'] = $firstRow['respondent_city'];
						$arrStagingResp['state'] = $firstRow['respondent_state'];
						$arrStagingResp['country'] = $firstRow['respondent_country'];
						$arrStagingResp['postal_code'] = $firstRow['respondent_postal'];
						$arrStagingResp['created_by'] = $firstRow['created_by'];
						$arrStagingResp['created_on'] = $firstRow['created_on'];
						$arrStagingResp['survey_id'] = $firstRow['survey_id'];
						if($firstRow['resp_kol_id'] != 0)
							$arrStagingResp['resp_kol_id'] = $firstRow['resp_kol_id'];
						
						$respContact = $this->imap->getIcontactByName($arrStagingResp);
						if($respContact !== false && isset($respContact['id'])){
							$newRespId = $respContact['kol_id'];
							pr('Respondent Present....................');
							//pr($respContact);
							//pr($mdmid);
						}else{
							$stagingRespId = $this->imap->saveStagingIContact($arrStagingResp);
							pr('Respondent Not Present....................saving to staging contacts');
						}
						//pr($arrStagingResp);
						
					}
				}else{
					$arrStagingResp = array();
					$firstName = '';
					$middleName = '';
					$lastName = '';
					$name = $firstRow['resp_name'];
					$nameEls = explode(",",$name);
					$nameEls = explode(" ",$nameEls[0]);
					$firstName = $nameEls[0];
					if(count($nameEls) == 2){
						$lastName = $nameEls[1];
					}else{
						$middleName = $nameEls[1];
						unset($nameEls[0]);
						unset($nameEls[1]);
						$lastName = implode(" ",$nameEls);
					}
					$arrStagingResp['first_name'] = $firstName;
					$arrStagingResp['middle_name'] = $middleName;
					$arrStagingResp['last_name'] = $lastName;
					$arrStagingResp['organization'] = $firstRow['resp_org'];
					$arrStagingResp['specialty'] = $firstRow['specialty'];
					$arrStagingResp['city'] = $firstRow['respondent_city'];
					$arrStagingResp['state'] = $firstRow['respondent_state'];
					$arrStagingResp['country'] = $firstRow['respondent_country'];
					$arrStagingResp['postal_code'] = $firstRow['respondent_postal'];
					$arrStagingResp['created_by'] = $firstRow['created_by'];
					$arrStagingResp['created_on'] = $firstRow['created_on'];
					$arrStagingResp['survey_id'] = $firstRow['survey_id'];
					$arrStagingResp['resp_kol_id'] = $firstRow['resp_kol_id'];
					
					$respContact = $this->imap->getIcontactByName($arrStagingResp);
					if($respContact !== false && isset($respContact['id'])){
						$newRespId = $respContact['kol_id'];
						pr('Respondent Present....................');
						//pr($respContact);
						//pr($mdmid);
					}else{
						$stagingRespId = $this->imap->saveStagingIContact($arrStagingResp);
						pr('Respondent Not Present....................saving to staging contacts');
					}
				}
				
				
				foreach($arrResponses as $resp){
					$arrNomDetails = array();
					$nomContact = array();
					$newNominId = 0;
					$firstName = '';
					$middleName = '';
					$lastName = '';
					$name = $resp['name'];
					$nameEls = explode(",",$name);
					$nameEls = explode(" ",$nameEls[0]);
					$firstName = $nameEls[0];
					if(count($nameEls) == 2){
						$lastName = $nameEls[1];
					}else{
						$middleName = $nameEls[1];
						unset($nameEls[0]);
						unset($nameEls[1]);
						$lastName = implode(" ",$nameEls);
					}
					$arrSurveyDetails = array();
					//if its kol and respondent is also presnet in icontacts
					if(( ($resp['influencer_npi'] != null && $resp['influencer_npi'] != '') || ($resp['kol_id'] != 0 && $resp['kol_id'] != $resp['nominee_id'])) && $newRespId != 0){
						$npiNum = $resp['influencer_npi'];
						if($npiNum == null || $npiNum == '')
							$npiNum = $resp['nom_npi'];
						if($npiNum != false && $npiNum != null && $npiNum != '')
							$nomContact = $this->imap->getIcontactByNPI($npiNum);
						if($nomContact !== false && isset($nomContact['id'])){
							//get icontact id for this npi
							$newNominId = $nomContact['kol_id'];
							//pr($nomContact);
							pr("		Nominee Present..............");
						}else{
							$arrNomDetails['first_name'] = $firstName;
							$arrNomDetails['middle_name'] = $middleName;
							$arrNomDetails['last_name'] = $lastName;
							$arrNomDetails['organization'] = $resp['nom_org'];
							$arrNomDetails['specialty'] = $resp['specialty'];
							$arrNomDetails['city'] = $resp['city'];
							$arrNomDetails['state'] = $resp['state'];
							$arrNomDetails['country'] = $resp['country'];
							
							$nomContact = $this->imap->getIcontactByName($arrNomDetails);
							if($nomContact !== false && isset($nomContact['id'])){
								//get icontact id for this npi
								$newNominId = $nomContact['kol_id'];
								//pr($nomContact);
								pr("		Nominee Present..............");
							}
						}
					}
					
					//if its staging repondent , then store everything in to staging
					if($newRespId == 0 || $newNominId == 0){
						$arrNomDetails['first_name'] = $firstName;
						$arrNomDetails['middle_name'] = $middleName;
						$arrNomDetails['last_name'] = $lastName;
						$arrNomDetails['organization'] = $resp['nom_org'];
						$arrNomDetails['specialty'] = $resp['specialty'];
						$arrNomDetails['city'] = $resp['city'];
						$arrNomDetails['state'] = $resp['state'];
						$arrNomDetails['country'] = $resp['country'];
						$arrNomDetails['postal_code'] = $resp['postal'];
						$arrNomDetails['created_by'] = $resp['created_by'];
						$arrNomDetails['created_on'] = $resp['created_on'];
						$arrNomDetails['survey_id'] = $resp['survey_id'];
						$arrNomDetails['staging_respondent_id'] = $stagingRespId;
						$arrNomDetails['survey_question_id'] = $resp['question_id'];
						$arrNomDetails['nom_kol_id'] = $resp['kol_id'];
						$arrNomDetails['resp_kol_id'] = $firstRow['resp_kol_id'];
						if($newRespId != 0){
							$arrNomDetails['survey_respondent_id'] = $newRespId;
							$arrNomDetails['survey_respondent_address_id'] = $respContact['id'];
						}
						if($newNominId != 0){
							$arrNomDetails['survey_influencer_id'] = $newNominId;
							$arrNomDetails['survey_influencer_address_id'] = $nomContact['id'];
						}
						//$arrNomDetails['zeroInfluencers'] = $resp['survey_id'];
						pr("		Storing to staging contact as nominee is not present..............");
						//Store to staging iContacts
						$this->imap->saveStagingIContact($arrNomDetails);
						//pr($arrNomDetails);
					}
					
					if($newNominId != 0 && $newRespId != 0){
						//Prepare array and insert in to survey answeres
						$arrSurveyDetails = array();
						$arrSurveyDetails['question_id'] = $resp['question_id'];
						$arrSurveyDetails['created_by'] = $resp['created_by'];
						$arrSurveyDetails['created_on'] = $resp['created_on'];
						$arrSurveyDetails['nominee_id'] = $newNominId;
						$arrSurveyDetails['respondent_id'] = $newRespId;
						$arrSurveyDetails['survey_id'] = $resp['survey_id'];
						$arrSurveyDetails['is_submitted'] = 1;
						$arrSurveyDetails['nom_address_id'] = $nomContact['id'];
						$arrSurveyDetails['resp_address_id'] = $respContact['id'];
						$arrSurveyDetails['nom_kol_id'] = $resp['kol_id'];
						$arrSurveyDetails['resp_kol_id'] = $firstRow['resp_kol_id'];
						//$arrSurveyDetails['address_id'] = $resp['question_id'];
						//$arrSurveyDetails['zeroInfluencers'] = $resp['question_id'];
						$this->imap->saveSurvey($arrSurveyDetails);
						/*pr($resp);
						pr($nomContact);
						pr($arrSurveyDetails);*/
						pr("Survey Response saved.......");
					}
				}
				pr("----------------------------------------------------------------------------------------------");
			}
		}
		
		pr("Total Time Taken ".(microtime(true)-$startTime));
	}
	
	
	function merge_survey_answers_mdm(){
		$startTime	=	microtime(true);
		//$this->load->database('default',true);
		ini_set("max_execution_time",26000);
		ini_set('memory_limit','-1');
		$arrSurveys = $this->imap->getSurveys();
		//$arrSurveys[] = array('id' => 21);
		//$arrSurveys[] = array('id' => 22);
		foreach($arrSurveys as $survey){
			$surveyRespondents = $this->imap->getSurveyResponsesiProfileAnup($survey['id']);
			//pr($surveyRespondents);
			//exit;
			foreach($surveyRespondents as $respId => $arrResponses){
				//pr($arrResponses);
				//if($respId != 1307 || $respId!= '1307')
					//continue;
				$newRespId = 0;
				$stagingRespId = 0;
				$respContact = array();
				$firstRow = $arrResponses[0];
				if(($firstRow['respondent_mdm'] != null && $firstRow['respondent_mdm'] != '')){
					$mdm = $firstRow['respondent_mdm'];
					if($mdm != false && $mdm != null && $mdm != '')
						$respContact = $this->imap->getIcontactByMDMID($mdm);
					if($respContact !== false && isset($respContact['id'])){
						$newRespId = $respContact['kol_id'];
						pr('Respondent Present....................');
						//pr($respContact);
						//pr($mdmid);
					}else{
						
						//Insert in to staging contacts and get the staging respondetnt id
						$arrStagingResp = array();
						$arrStagingResp['first_name'] = $firstRow['res_fn'];
						$arrStagingResp['middle_name'] = $firstRow['res_mn'];
						$arrStagingResp['last_name'] = $firstRow['res_ln'];
						$arrStagingResp['organization'] = $firstRow['resp_org'];
						$arrStagingResp['specialty'] = $firstRow['specialty'];
						$arrStagingResp['city'] = $firstRow['respondent_city'];
						$arrStagingResp['state'] = $firstRow['respondent_state'];
						$arrStagingResp['country'] = $firstRow['respondent_country'];
						$arrStagingResp['postal_code'] = $firstRow['respondent_postal'];
						$arrStagingResp['created_by'] = $firstRow['created_by'];
						$arrStagingResp['created_on'] = $firstRow['created_on'];
						$arrStagingResp['survey_id'] = $firstRow['survey_id'];
						$arrStagingResp['respondent_mdm'] = $firstRow['respondent_mdm'];
						$arrStagingResp['influencer_mdm'] = $firstRow['influencer_mdm'];
						$arrStagingResp['is_iprofile'] = 1;
						$arrStagingResp['iprofile_answer_id'] = $firstRow['id'];
						if($firstRow['resp_kol_id'] != 0)
							$arrStagingResp['resp_kol_id'] = $firstRow['resp_kol_id'];
						
						
						$stagingRespId = $this->imap->saveStagingIContact($arrStagingResp);
						pr('Respondent Not Present....................saving to staging contacts');
						//pr($arrStagingResp);
						
					}
				}else{
					$arrStagingResp = array();
					$arrStagingResp['first_name'] = $firstRow['res_fn'];
					$arrStagingResp['middle_name'] = $firstRow['res_mn'];
					$arrStagingResp['last_name'] = $firstRow['res_ln'];
					$arrStagingResp['organization'] = $firstRow['resp_org'];
					$arrStagingResp['specialty'] = $firstRow['specialty'];
					$arrStagingResp['city'] = $firstRow['respondent_city'];
					$arrStagingResp['state'] = $firstRow['respondent_state'];
					$arrStagingResp['country'] = $firstRow['respondent_country'];
					$arrStagingResp['postal_code'] = $firstRow['respondent_postal'];
					$arrStagingResp['created_by'] = $firstRow['created_by'];
					$arrStagingResp['created_on'] = $firstRow['created_on'];
					$arrStagingResp['survey_id'] = $firstRow['survey_id'];
					$arrStagingResp['resp_kol_id'] = $firstRow['resp_kol_id'];
					$arrStagingResp['respondent_mdm'] = $firstRow['respondent_mdm'];
					$arrStagingResp['influencer_mdm'] = $firstRow['influencer_mdm'];
					$arrStagingResp['is_iprofile'] = 1;
					$arrStagingResp['iprofile_answer_id'] = $firstRow['id'];
					
					$stagingRespId = $this->imap->saveStagingIContact($arrStagingResp);
					pr('Respondent Not Present....................saving to staging contacts');
				}
				
				
				foreach($arrResponses as $resp){
					$arrNomDetails = array();
					$nomContact = array();
					$newNominId = 0;
					$firstName = '';
					$middleName = '';
					$lastName = '';
					$name = $resp['name'];
					$nameEls = explode(",",$name);
					$nameEls = explode(" ",$nameEls[0]);
					$firstName = $nameEls[0];
					if(count($nameEls) == 2){
						$lastName = $nameEls[1];
					}else{
						$middleName = $nameEls[1];
						unset($nameEls[0]);
						unset($nameEls[1]);
						$lastName = implode(" ",$nameEls);
					}
					$arrSurveyDetails = array();
					//if its kol and respondent is also presnet in icontacts
					if(( ($resp['influencer_mdm'] != null && $resp['influencer_mdm'] != '')) && $newRespId != 0){
						$mdm = $resp['influencer_mdm'];
						if($mdm != false && $mdm != null && $mdm != '')
							$nomContact = $this->imap->getIcontactByMDMID($mdm);
						if($nomContact !== false && isset($nomContact['id'])){
							//get icontact id for this mdm
							$newNominId = $nomContact['kol_id'];
							//pr($nomContact);
							pr("		Nominee Present..............");
						}else{
							$arrNomDetails['first_name'] = $resp['nom_fn'];
							$arrNomDetails['middle_name'] = $resp['nom_mn'];
							$arrNomDetails['last_name'] = $resp['nom_ln'];
							$arrNomDetails['organization'] = $resp['nom_org'];
							$arrNomDetails['specialty'] = $resp['specialty'];
							$arrNomDetails['city'] = $resp['city'];
							$arrNomDetails['state'] = $resp['state'];
							$arrNomDetails['country'] = $resp['country'];

						}
					}
					
					//if its staging repondent , then store everything in to staging
					if($newRespId == 0 || $newNominId == 0){
						$arrNomDetails['first_name'] = $resp['nom_fn'];
						$arrNomDetails['middle_name'] = $resp['nom_mn'];
						$arrNomDetails['last_name'] = $resp['nom_ln'];
						$arrNomDetails['organization'] = $resp['nom_org'];
						$arrNomDetails['specialty'] = $resp['specialty'];
						$arrNomDetails['city'] = $resp['city'];
						$arrNomDetails['state'] = $resp['state'];
						$arrNomDetails['country'] = $resp['country'];
						$arrNomDetails['postal_code'] = $resp['postal'];
						$arrNomDetails['created_by'] = $resp['created_by'];
						$arrNomDetails['created_on'] = $resp['created_on'];
						$arrNomDetails['survey_id'] = $resp['survey_id'];
						$arrNomDetails['staging_respondent_id'] = $stagingRespId;
						$arrNomDetails['survey_question_id'] = $resp['question_id'];
						$arrNomDetails['nom_kol_id'] = $resp['kol_id'];
						$arrNomDetails['resp_kol_id'] = $firstRow['resp_kol_id'];
						if($newRespId != 0){
							$arrNomDetails['survey_respondent_id'] = $newRespId;
							$arrNomDetails['survey_respondent_address_id'] = $respContact['id'];
						}
						if($newNominId != 0){
							$arrNomDetails['survey_influencer_id'] = $newNominId;
							$arrNomDetails['survey_influencer_address_id'] = $nomContact['id'];
						}
						$arrNomDetails['respondent_mdm'] = $resp['respondent_mdm'];
						$arrNomDetails['influencer_mdm'] = $resp['influencer_mdm'];
						$arrNomDetails['is_iprofile'] = 1;
						$arrNomDetails['iprofile_answer_id'] = $resp['id'];
						//$arrNomDetails['zeroInfluencers'] = $resp['survey_id'];
						pr("		Storing to staging contact as nominee is not present..............");
						//Store to staging iContacts
						$this->imap->saveStagingIContact($arrNomDetails);
						//pr($arrNomDetails);
					}
					
					if($newNominId != 0 && $newRespId != 0){
						//Prepare array and insert in to survey answeres
						$arrSurveyDetails = array();
						$arrSurveyDetails['question_id'] = $resp['question_id'];
						$arrSurveyDetails['created_by'] = $resp['created_by'];
						$arrSurveyDetails['created_on'] = $resp['created_on'];
						$arrSurveyDetails['nominee_id'] = $newNominId;
						$arrSurveyDetails['respondent_id'] = $newRespId;
						$arrSurveyDetails['survey_id'] = $resp['survey_id'];
						$arrSurveyDetails['is_submitted'] = 1;
						$arrSurveyDetails['nom_address_id'] = $nomContact['id'];
						$arrSurveyDetails['resp_address_id'] = $respContact['id'];
						$arrSurveyDetails['nom_kol_id'] = $resp['kol_id'];
						$arrSurveyDetails['resp_kol_id'] = $firstRow['resp_kol_id'];
						//$arrSurveyDetails['address_id'] = $resp['question_id'];
						//$arrSurveyDetails['zeroInfluencers'] = $resp['question_id'];
						$arrSurveyDetails['is_iprofile'] = 1;
						$arrSurveyDetails['iprofile_answer_id'] = $resp['id'];
						$this->imap->saveSurvey($arrSurveyDetails);
						/*pr($resp);
						pr($nomContact);
						pr($arrSurveyDetails);*/
						pr("Survey Response saved.......");
					}
				}
				pr("----------------------------------------------------------------------------------------------");
			}
		}
		
		pr("Total Time Taken ".(microtime(true)-$startTime));
	}
	
	function update_kol_ids_to_imap_responses(){
		$startTime	=	microtime(true);
		ini_set("max_execution_time",26000);
		ini_set('memory_limit','-1');
		$arrSurveys = $this->imap->getSurveys();
		$arrSurveys[] = array('id' => 21);
		$arrSurveys[] = array('id' => 22);
		foreach($arrSurveys as $survey){
			$responses = $this->imap->getSurveyResponses($survey['id']);
			foreach($responses as $resp){
				$nomNpiNum = $this->imap->getNPIByAddressId($resp['nom_address_id']);
				$respNPINum = $this->imap->getNPIByAddressId($resp['resp_address_id']);
				$nomKolId = 0;
				$respKolId = 0;
				if(is_int($resp['nom_kol_id']))
					$nomKolId = $resp['nom_kol_id'];
				if(is_int($resp['resp_kol_id']))
					$respKolId = $resp['resp_kol_id'];
				if($nomNpiNum != '' && $nomKolId == 0)
					$nomKolId = $this->imap->getKolIdByNPI($nomNpiNum);
				if($respNPINum != '' && $respKolId == 0)
					$respKolId = $this->imap->getKolIdByNPI($respNPINum);
					
				if($nomKolId == 0){
					$nomMDMID = $this->imap->getMDMIDByAddressId($resp['nom_address_id']);
					$nomKolId = $this->imap->getKolIdByMDMID($nomMDMID);
				}
				if($respKolId == 0){
					$respMDMID = $this->imap->getMDMIDByAddressId($resp['resp_address_id']);
					$respKolId = $this->imap->getKolIdByMDMID($respMDMID);
				}
				$arrDetails = array();
				$arrDetails['id'] = $resp['id'];
				if($nomKolId !=0 || $respKolId != 0){
					if($nomKolId != 0)
						$arrDetails['nom_kol_id'] = $nomKolId;
					if($respKolId != 0)
						$arrDetails['resp_kol_id'] = $respKolId;
					$this->imap->updateSurveyResponse($arrDetails);
				}
			}
		}
		
		pr("Total Time Taken ".(microtime(true)-$startTime));
	}
	
}