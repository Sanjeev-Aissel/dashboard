<?php

/**
 * This is the 'Permissions' Controller class  which controlles the all the request
 * comming for Permission related activites.
 * 
 * @package application.controllers	
 * @author Vinayak B
 * @since  3.5.1
 * @created: 22-12-11
 */
class Permissions extends Controller{

	//Constructore
	function Permissions(){
		parent::Controller();
		$this->load->model('permission');
		$this->load->model('access_object');
		$this->load->model('role');
	}

	/*
	 * To load View page that cintains List Of Permissinons
	 *  
	 * @author Vinayak
 	 * @since  3.5.1
 	 * @created  22-12-11
	 * 
	 */
	function show_permissions(){
		$arrAccessObjectsResults=array();
		$arrAccessObjects = $this->access_object->getAccessObjects();

		foreach($arrAccessObjects as $key=>$value){
			$array=array();	
			$value['allowedTypeDetails'] = $this->role->getUserRoleAndAllowedType($value['id']);
			$arrAccessObjectsResults1[]=$value;
		}
		foreach($arrAccessObjectsResults1 as $key=>$value){
				$arrAccessObjectsResults[$value['category']][]=$value;
		}
	
		$data['arrAccessObjects']=$arrAccessObjectsResults;
		$data['arrRoles']=$this->role->getRoles();
		$data['contentPage']='permissions/show_permissions';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited Show Permissions Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View Show Permissions Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/analyst_view',$data);
		
	}
	
	/*
	 * To Upadte is_allowed type
	 *  
	 * @author Vinayak
 	 * @since  3.5.1
 	 * @created  22-12-11
 	 * @param: $accessObjectId,$roleId,$allowType
	 * @return Json array $data
	 */
	function updateAllowType($accessObjectId,$roleId,$allowType){

		if($allowType==1){
			$data['is_allowed']=0;
		}else{
			$data['is_allowed']=1;
		}
		
		if($this->permission->updateAllowType($accessObjectId,$roleId,$data)){
			$data['updated']=true;
		}else{
			$data['updated']=false;
		}
		echo json_encode($data);
	
	}
	
	function show_not_allowed_page(){
		//$this->load->view('layouts/show_under_maintenance_page');
		$data['contentPage'] 	=	'layouts/show_under_maintenance_page';
		$this->load->view('layouts/client_view', $data);
	}
	
	function updateAllchild($allowType){
		
	if($allowType==1){
			$data['is_allowed']=0;
		}else{
			$data['is_allowed']=1;
		}
		$arr=$this->input->post('id');
		
		foreach($arr as $row){
			$this->db->where('id',$row);
			$this->db->update('access_permissions',$data);
			echo $this->db->last_query();
		}
		

		
	}
}