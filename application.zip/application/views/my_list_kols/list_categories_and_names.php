<?php
/**
 * File to 'List' Categories and its associated list names
 * @author: Vinayak
 * @since :2.0
 * @Created on: 11-4-11
 */

// prepare array of JS files to insert into queue
	$queued_js_scripts = array('my_lists/list_categories_and_names','jquery.treeview','jquery/jquery.validate1.9.min');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
	$listID = 0; $is_private = 0;
// pr($arrListCategoryKols);
	if($arrListCategoryKols){
	   $listID = $arrListCategoryKols[0]['list_id'];
	   if($arrListCategoryKols[0]['is_public']==0){
	       $is_private = 1;
	   }
	}
?>
<script type="text/javascript">
$(document).ready(function(){
	var list_id = parseInt("<?php echo $listID ?>");
	var is_private = parseInt("<?php echo $is_private ?>");
	var subContentPage = "<?php echo $subContentPage ?>";
	if(list_id>0){		
		if(is_private==1 && subContentPage==''){			
			window.location="<?php echo base_url();?>my_list_kols/list_categories_and_names/my_list";
		}
	}else{
		$('#listKolsOfcategory div h3').text("Currently there are no lists available. Please click on manage lists to create one.");
	}
	if(is_private==1 && subContentPage=='public_list'){		
		$('#listKolsOfcategory div h3').text("Currently there are no lists available. Please click on manage lists to create one.");
	}else if(is_private==0 && (subContentPage=='public_list' || subContentPage=='')){		
		displayKOlDetails(list_id);
    	setTimeout(function(){ $('#listNameId_'+list_id).parent().parent().parent().children('.hitarea').click();}, 300);
	}else if(subContentPage=='my_list' || subContentPage==''){				
		$('#listPrivateContainer #myListTree li:first ul li:first a').click();
		var list = $('#listPrivateContainer #myListTree li:first ul li:first a').attr('id'); 		
		setTimeout(function(){ $('#'+list).parent().parent().parent().children('.hitarea ').click();}, 300);
	}	
	
});
</script>

<link rel="stylesheet" href="<?php echo base_url();?>css/jquery.treeview.css" type="text/css" media="screen" />

<style type="text/css">
	/*    Enable Verticle separator between content and side menu list  By Laxman   */
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 144px 50%;
	    background-repeat: repeat-y;
	}
	#listLeftBar {
		-moz-background-clip:border;
		-moz-background-inline-policy:continuous;
		-moz-background-origin:padding;
		background:#FFFFFF url(../../images/blue_grandience_bg.png) repeat scroll 0 0;
	/*	border-right:1px solid #D8DFEA; */
		color:#D8DFEA;
		padding:0;
		float:left;
	}
	
	.rootTree{
		font-size: 16px;
	}

	
	#browser {
	    font-family: Verdana, helvetica, arial, sans-serif;
	    font-size: 68.75%;
	}
	
	
	.treeview {
		font-family:Arial,Helvetica,sans-serif,'Times New Roman';
		text-align:left;
		float:left;
	  }
	
	a.listBgColor {
		color:#38537C;
		margin-top:2px;
	}

	.listBgColor {
		color:#38537C;
		font-size:12px;
		font-weight:normal;
		padding-left:3px;
		display:block;
	}
	
	treeview a.selected {
		background-color:#AAAAAA;
	}
	
	#myListTree .selectedRow{
		font-size:14px;
		font-weight:bold;
	}
	#myListTree,#publicListTree{
		padding-bottom:10px;
		padding-left:10px;
		padding-top:10px;
	}
	
	.textDecorationNone{
		text-decoration: none;
	}
	.textDecoration{
		text-decoration: underline;
	}
		/* added by laxman	*/
	.treeview li.last {
    	background-position: 0 -1759px;
    }
    #deleteKols {
		clear:both;
		float:none !important;
		margin-left:617px;
	}
	#myListTree, #publicListTree {
		 width: 138px;
		 border:1px solid #eeeeee;
	}
	#listPrivateContainer, #listPublicContainer {
		border:0px;
	}
	#listLeftBar {
	/*	border-right: 2px solid #E8E8E8; */
		padding-right:5px;
	}
	#myListTree, #publicListTree {
		 padding-top: 0px;
	}
  
	.treeview li.listName a{
		margin-top:-3px;
	} 
	
	li.lastExpandable span.listBgColor{
		margin-top:-4px;
	}
	a.publiListBgColor {
		color:#38537C;
		margin-top:-2px;
	}
	.publiListBgColor {
		color:#38537C;
		font-size:12px;
		font-weight:normal;
		padding-left:3px;
		display:block;
	}
	#listLeftBar {
		 background:none;
	}
	.rowhover{
		background-color: #d0e5f5;
	}
	#listPrivateContainer h3, #listPublicContainer h3 {
/*	    -moz-background-inline-policy: continuous;
	    background: none repeat scroll 0 0 #2283AE;
	    -moz-border-top-right-radius: 10px;
*/
		background:none;
	    border-top-left-radius:0px;
	    color: #38537C;
	    font-size: 12px;
	    font-weight: bold;
	    margin-bottom: 0;
	    margin-left: -5px;
	    padding: 5px 0 3px 5px;
	    text-align: left;
	}
	#myListTree, #publicListTree {
		border:0px;
	}
	#listContainer{
		padding-left: 6px !important;
/*		position: inherit;*/
	}
/*	#sideBarWrapper{
		position: relative;
		float: left;
	}*/
	.makeSelectedRowBold{
		font-size:60px !important;
		font-weight: bold !important;
		color:#f47620 !important;
	}
	#sideBarContents #secondaryNav ul li a{
		font-size: 11px !important;
	}
	#exportContainer{
	   height:109px;
	}	
</style>
<script type="text/javascript">
function addNewKolProfile(KolId,thisEle){
	
	/*$(".newProfileContent").html("<div class='microViewLoading'>Loading...</div>");
	$("#newKolProfile").dialog("open");
	$(".newProfileContent").load(base_url+'requested_kols/add_client_pre_kol/'+KolId);
	*/
	jConfirm(profileRequestConfirmMessage,"Confirm message",function (r){
		if(r){
			requestProfile(KolId,thisEle);
			return false;
		}else{
			return false;
		}
	});
}

function requestProfile(KolId,thisEle){
	var userRoleId = <?php echo $this->session->userdata('user_role_id')?>;
	if(userRoleId == ROLE_MANAGER || userRoleId == ROLE_ADMIN){
		jAlert("The Profile has been requested for processing. You will get a notification once the requests are processed.");
	}else{
		jAlert("Your <?php echo lang("KOL");?>  Profile request has been submitted to your manager for approval. We will notify you when your request is approved");
	}
	$.ajax({
		url:'<?php echo base_url()?>requested_kols/request_kol_profile/'+KolId,
		type:'post',
		dataType:'json',
		success:function(returnData){
			if(returnData.saved==true){
				$(thisEle).remove();
				//jAlert("The Profile has been requested for processing. You will get a notification once the requests are processed.");
				//window.location = '<?php echo base_url()?>requested_kols/show_client_requested_kols';
				//notRequesetdKOls();
			}else{
				jAlert("Unable to send request for profiling.");
			}
		}
	});
}
function showExportType(){
	if($('input[name=type]:checked').val()=='profile'){
		$("#exportOption").dialog("close");		
		showKolExportBox();
	}else{
		var values = new Array();
		$.each($("input[name='list[]']:checked"), function() {
		  values.push($(this).val());
		});
		window.location	=" <?php echo base_url();?>"+"my_list_kols/export_list/"+values;
		$("#exportOption").dialog("close");		
	}
}
</script>
<div id="container">
	<div id="listContainer">
		<div id="searchTopMenus"></div>
		<!-- Containar for kols detail -->
		<div id="listContainer" class="manageListContainer">
			<div id="listKolsLoading" class="loadingImageContainer" style="display: none;">
				<center><img src="<?php echo base_url()?>images/ajax-loader-round.gif" /></center>
			</div>
			<div id="listKolsOfcategory">			
				<div><h3 style="text-align: center">Currently there are no lists available. Please click on manage lists to create one.</h3></div>
			</div>
		</div>
		<div class="clear">&nbsp;</div>
		<!-- Container for the 'Kol Micro Profile'  box -->	
		<div id="contentHolder" class="callOutTest microView" style="display: none;">
			<div>
				<a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeKolProfile();" class="ui-icon ui-icon-closethick">close</span></a>
				<!--<img class="ui-icon ui-icon-closethick" alt="" src="" onclick="closeKolProfile();"/>
			--></div>
			<div class="profileContent"></div>
		</div>
		<div id="arraouHolder" class="callOutTest" style="display: none;"><div class="arrowMarkIcon"></div></div>
	</div>
	<!-- End of search container -->
</div>
<div id="exportOption" class="microProfileDialogBox" style="display:none;">
	<div id="exportContainer"  class="profileContent">
		<h6 style="text-align:center;margin-bottom: 20px;">Select export type</h6>
		<label><input type="radio" name="type" class="exportType" value="profile" checked="checked"> Profile</label><br/>
		<label><input type="radio" name="type" class="exportType" value="list"> List</label><br/>
		<div style="text-align: center;"><input type="button" name="next" value="Export" id="next" onclick="showExportType();"></div>
	</div>
</div>
<script type="text/javascript">
	var listType = '<?php echo $this->uri->segment(3)?>';
</script>
