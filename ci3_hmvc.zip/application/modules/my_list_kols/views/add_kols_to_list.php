<?php
$autoSearchOptions = "width: 255, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";

echo $html_form; ?>
<span id="responseMessageOfAddkolsToList"></span>
<script type="text/javascript">
var validationRules	=  {
	kol_name: {
		required:true
     }
};
var validationMessages = {
	kol_name: {
		required:"KTL name is required"
	}
};
var KolNameAutoCompleteOptions={
		serviceUrl: '<?php echo base_url();?>helpers/helpers/get_kol_names_for_all_autocomplete',
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
			var selText = $(event).children('.kolName').text();
			var selId = $(event).children('.kolName').attr('name');
			selText=selText.replace(/\&amp;/g,'&');
			$('#kol_name').val(selText);
			$('input[name="kol_id"]').val(selId);
			if(event.length>20){
				if(event.substring(0,21)=="No results found for "){
					return false;
				}
			}
		}		
};
$(document).ready(function(){
	a = $('#kol_name').autocomplete(KolNameAutoCompleteOptions);	
	$("#addKolToListForm").validate({
		rules: validationRules,
		messages: validationMessages
	});
});
</script>
</script>