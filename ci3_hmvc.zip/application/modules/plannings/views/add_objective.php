<?php
/**
 * This is view file to add new objective
 *
 * @package application.views.plannings	
 * @author Vinayak
 * @since  3.1	
 * @created on  11-9-2011
 * 
 */

?>
<style>
	#objectiveForm .error{
		width:205px;
	}
	.microView .ui-dialog-content {
   	 	background-color: #ffffff;
	}
	#objectiveDesc{
    	width: 450px;
	}
	.objectveResultSet label{
		width: 75px;
		float: left;
		text-align: right;
	}
	#saveButton{
	   margin: 0;
	}

</style>
<script type="text/javascript">
	var validationRules	=  {
		name: {
			required:true
		}
		
	};

	var validationMessages = {
		name: {
			required: "Required"
			
		}
	};
	$(function(){
		<?php 
			/** 
		 	** @since  22 Aug 2012
		 	**The following code is used to disable caching in IE
	 		**/
			$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
			$this->output->set_header("Pragma: no-cache"); 
		?>
		$("#objectiveForm").validate({
			debug:false,
			onkeyup:false,
			rules: validationRules,
			messages: validationMessages
		});

	});

</script>
   
 <div class="objectiveMsgBox"></div><div class="errorMsg"></div>
 <div class="formHeader">
		<h5>Objective</h5>
	</div>
<form action="<?php echo base_url()?>plannings/save_objective" id="objectiveForm" name="objectiveForm" >
	<input type="hidden" name="id" id="objectiveId1" value="<?php if($arrObjectives['id']!='') echo $arrObjectives['id'];  ?>" ></input>
	<table class="objectveResultSet">
		<tr>
			<td>
				<label>Name<span class="required">*</span>:</label>
				<input type="text" name="name" id="objectiveName" value="<?php if($arrObjectives['name']!='') echo $arrObjectives['name'];?>" class="required"></input>				
			</td>
		</tr>
		<tr>
			<td>
			<label for="objectiveDesc">Description:</label>
				<textarea rows="" cols="" name="description" id="objectiveDesc"><?php if($arrObjectives['description']!='') echo $arrObjectives['description'];?></textarea>
			</td>
		</tr>
		<tr>
			<td class="alignCenter">
				<input type="button" value="<?php if($arrObjectives['name']!=' ') echo 'Update' ;else echo 'Add';?>" onclick="saveObjective()" name="save" id="saveButton"> </input>
			</td>
		</tr>
	</table>
</form> 

