<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

require_once('phpass-0.1/PasswordHash.php');

define('PHPASS_HASH_STRENGTH', 8);
define('PHPASS_HASH_PORTABLE', false);

/**
 * SimpleLoginSecure Class
 *
 * Makes authentication simple and secure.
 *
 * Simplelogin expects the following database setup. If you are not using 
 * this setup you may need to do some tweaking.
 *   
 * 
 *   CREATE TABLE `users` (
 *     `user_id` int(10) unsigned NOT NULL auto_increment,
 *     `user_email` varchar(255) NOT NULL default '',
 *     `user_pass` varchar(60) NOT NULL default '',
 *     `user_date` datetime NOT NULL default '0000-00-00 00:00:00' COMMENT 'Creation date',
 *     `user_modified` datetime NOT NULL default '0000-00-00 00:00:00',
 *     `user_last_login` datetime NULL default NULL,
 *     PRIMARY KEY  (`user_id`),
 *     UNIQUE KEY `user_email` (`user_email`),
 *   ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
 * 
 * @package   SimpleLoginSecure
 * @version   1.0.1
 * @author    Alex Dunae, Dialect <alex[at]dialect.ca>
 * @copyright Copyright (c) 2008, Alex Dunae
 * @license   http://www.gnu.org/licenses/gpl-3.0.txt
 * @link      http://dialect.ca/code/ci-simple-login-secure/
 */
class SimpleLoginSecure
{
	var $CI;
	var $user_table = 'client_users';

	/**
	 * Create a user account
	 *
	 * @access	public
	 * @param	string
	 * @param	string
	 * @param	bool
	 * @return	bool
	 */
	function create($email = '', $password = '', $auto_login = true, $user_full_name = '', $user_address = '' , $contact = '', $user_role_id = '1') 
	{
		$this->CI =& get_instance();
		
		//Make sure account info was sent
		if($email == '' OR $password == '') {
			return false;
		}
		
		//Check against user table
		$this->CI->db->where('email', $email); 
		$query = $this->CI->db->getwhere($this->user_table);
		
		if ($query->num_rows() > 0) //user_email already exists
			return false;

		//Hash user_pass using phpass
		$hasher = new PasswordHash(PHPASS_HASH_STRENGTH, PHPASS_HASH_PORTABLE);
		$user_pass_hashed = $hasher->HashPassword($password);

		//Insert account into the database
		$data = array(
					'email' => $email,
					'password' => $user_pass_hashed,
					'user_date' => date('c'),
					'modified_on' => date('c'),
					'contact' => $contact,
					'user_role_id' => $user_role_id
				);

		$this->CI->db->set($data); 

		if(!$this->CI->db->insert($this->user_table)){ //There was a problem! 
			return false;
		}
				
		if($auto_login)
			$this->login($email, $password);
		
		return true;
	}

	/**
	 * Login and sets session variables
	 *
	 * @access	public
	 * @param	string
	 * @param	string
	 * @return	bool
	 */
	function login($userName = '', $password = '') 
	{
		$this->CI =& get_instance();

		if($userName == '' OR $password == '')
			return false;


		//Check if already logged in
		if($this->CI->session->userdata('email1') == $userName)
			return true;
		
		//Check against user table
		$this->CI->db->select($this->user_table.'.*, clients.name as client_name');
		$this->CI->db->where('user_name', $userName); 
        $this->CI->db->where('status', ACTIVATED_USER);
		//Check for only iProfile users, i.e 'user_from' column with value 1
		//$this->CI->db->where_in('user_from', array(1,2)); 
		$this->CI->db->join('clients','clients.id='.$this->user_table.'.client_id');
		$query = $this->CI->db->get($this->user_table);
		
		
		
		if ($query->num_rows() > 0) 
		{
			$user_data = $query->row_array(); 
			
			$hasher = new PasswordHash(PHPASS_HASH_STRENGTH, PHPASS_HASH_PORTABLE);

//			if(strcmp($userName,$user_data['user_name'])!=0){	
			if(strcasecmp(strtolower($userName),strtolower($user_data['user_name']))!=0){
				return false;
			}
			if(!$hasher->CheckPassword($password, $user_data['password'])){
				$this->CI->db->where('id', $user_data['id']);
				$this->CI->db->set('failed_attempts', 'failed_attempts+1', FALSE);
				$this->CI->db->update('client_users');
				return false;
			}
			$this->CI->db->where('id', $user_data['id']);
			$this->CI->db->set('failed_attempts', '0', FALSE);
			$this->CI->db->update('client_users');
			//Destroy old session
		//pr( $this->CI->session->userdata);
			$back_url = $this->CI->session->userdata('back_url');
			$this->CI->session->sess_destroy();
			
			
			//Create a fresh, brand new session
			$this->CI->session->sess_create();
			$this->CI->session->set_userdata("back_url",$back_url);
			$this->CI->db->simple_query('UPDATE ' . $this->user_table  . ' SET user_last_login = NOW() WHERE id = ' . $user_data['id']);
			/* $this->CI->db->select('GROUP_CONCAT(user_groups.group_id) AS group_ids,GROUP_CONCAT(groups.group_name) AS group_names');
			$this->CI->db->join('groups','groups.group_id=user_groups.group_id');
			$this->CI->db->where('user_id', $user_data['id']);
			$this->CI->db->group_by('user_id');
			$query = $this->CI->db->getwhere('user_groups');
			$userGroups['group_ids']	= '';
			$userGroups['group_names']	= '';
			if ($query->num_rows() > 0) 
			{
				$userGroups = $query->row_array(); 
			} */
			//get manager name to store in session
			$this->CI->db->select('GROUP_CONCAT(client_users.first_name," ",client_users.last_name) as manager_name',false);
			$this->CI->db->where('client_users.id', $user_data['manager_id']);
			$query2 = $this->CI->db->get('client_users');
			$user_data2 = $query2->row_array();
			//Set session data
			unset($user_data['password']);
// 			$sess_data['manager_name'] = $user_data2['manager_name'];
			$sess_data['user_id'] = $user_data['id'];
// 			$sess_data['user'] = $user_data['email']; // for compatibility with Simplelogin
			$sess_data['logged_in'] = true;
			$sess_data['user_name'] = $user_data['user_name'];
			$sess_data['user_last_login'] = $user_data['user_last_login'];
			$sess_data['user_role_id'] = $user_data['user_role_id'];
			$sess_data['is_analyst'] = $user_data['is_analyst'];
			$sess_data['client_id'] = $user_data['client_id'];
// 			$sess_data['client_name'] = $user_data['client_name'];
			$sess_data['email'] = $user_data['email'];
			$sess_data['user_full_name'] = $user_data['first_name']." ".$user_data['last_name'];
			$sess_data['name_order'] = $user_data['name_order'];
			$sess_data['mem_pic'] = $user_data['mem_pic'];
// 			$sess_data['company_name'] = $user_data['company_name'];
			$sess_data['title'] = $user_data['title'];
			/* $sess_data['group_ids'] = $userGroups['group_ids'];
			$sess_data['group_names'] = $userGroups['group_names']; */
			$sess_data['logged_in_on'] = strtotime(date("Y-m-d"));
//			$sess_data['cooke_consent'] = $user_data['cooke_consent'];
			/* $sess_data['user_from'] = $user_data['user_from'];
			$sess_data['disc'] = 1;
            $sess_data['user_territory'] = $user_data['territory']; */
            //$sess_data['active_status'] = $user_data['status'];
			$this->CI->session->set_userdata($sess_data);
			return true;
			
		} 
		else 
		{
			return false;
		}	

	}

	/**
	 * Logout user
	 *
	 * @access	public
	 * @return	void
	 */
	function logout() {
		$this->CI =& get_instance();		
		$this->CI->session->sess_destroy();
		$destroyVar = $this->CI->session->all_userdata();
		foreach($destroyVar as $key => $val){
			$this->CI->session->unset_userdata($key);
		}
	}

	/**
	 * Delete user
	 *
	 * @access	public
	 * @param integer
	 * @return	bool
	 */
	function delete($id) 
	{
		$this->CI =& get_instance();
		
		if(!is_numeric($id))
			return false;			

		return $this->CI->db->delete($this->user_table, array('user_id' => $id));
	}
	
	function getUserByAPIKey($key){
		$this->CI =& get_instance();

		$this->CI->db->where('api_key', $key); 
		$query = $this->CI->db->get_where($this->user_table);
		//echo "<pre>";pr($this->CI->mongo_db->last_query());echo "</pre>";
		
		if($query->num_rows() <= 0){
			$response['msg'] = 'Invalid User';
			return false;
		}
		return (object)$query->row_array(); 
	}
}
?>
