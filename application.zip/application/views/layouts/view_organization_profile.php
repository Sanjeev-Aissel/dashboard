
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">

<head>
	<meta charset="UTF-8" />
	<title>Key Opinion Leader Management</title>
	
	<!--  Load the BLUEPRINT CSS files -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/ie.css" />
	<!-- Not loading the 'print' right now as it is giving some errors in Firefox with Horizontal Tabs of jQuery -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/screen.css" />
	
	<!-- jQuery CSS for the UI features -->
	<link type="text/css" href="<?php echo base_url()?>css/jquery.ui.all.css" rel="stylesheet" />
	<link type="text/css" href="<?php echo base_url()?>css/jquery.ui.tabs.css" rel="stylesheet" />
	<link type="text/css" href="<?php echo base_url()?>css/jquery.ui.theme.css" rel="stylesheet" />

	<!-- Style for the Horizontal and Vertical Menu -->
	<link type="text/css" href="<?php echo base_url()?>css/demos.css" rel="stylesheet" />

	<!-- jQuery Core File -->
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery-1.4.2.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery-ui-1.8.4.custom.min.js" ></script>	
	
	
	<!-- jQuery files for the UI Core and UI Tabs -->
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.ui.core.js"></script>
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.ui.widget.js"></script>
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.ui.tabs.js"></script>
	
	<!-- Load the JS and CSS files for the Vertical Tabs -->
	<script type="text/javascript" src="<?php echo base_url()?>js/verticaltabs.js"></script> 
	<link rel="stylesheet" href="<?php echo base_url()?>css/verticaltabs.css" />
	
	<!-- Validator Plugin Files -->
	<link type="text/css" href="<?php echo base_url()?>css/validationEngine.jquery.css" rel="Stylesheet" />
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.validationEngine-en.js"></script>
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.validationEngine.js"></script>

	<!-- 2nd Plugin for Validation -->
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery.validate.js"></script>

	<!--  Autocomplete Plugin -->
	<script type="text/javascript" src="<?php echo base_url()?>/js/jquery.autocomplete.js"></script>
	
	<!-- Editor Plugin -->
	<script type="text/javascript" src="<?php echo base_url()?>/js/jquery.cleditor.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url()?>/js/jquery.wysiwyg.js"></script>
	<link rel="stylesheet" href="<?php echo base_url()?>/css/jquery.wysiwyg.css" />
	
	<!-- JQGrid Plugins -->
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/jquery-ui-1.8.2.custom.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.multiselect.css" />			
	<script src="<?php echo base_url()?>js/jquery.layout.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>js/i18n/grid.locale-en.js" type="text/javascript"></script>	
	<script src="<?php echo base_url()?>js/ui.multiselect.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>js/jquery.jqGrid.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>js/jquery.tablednd.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>js/jquery.contextmenu.js" type="text/javascript"></script>

	
	<!-- Stylesheet for the Vertical Tabs -->
	<style type="text/css" title="">
		.ui-tabs-vertical { width: 55em; }
		.ui-tabs-vertical .ui-tabs-nav { padding: .2em .1em .2em .2em; float: left; width: 12em; }
		.ui-tabs-vertical .ui-tabs-nav li { clear: left; width: 100%; border-bottom-width: 1px !important; border-right-width: 0 !important; margin: 0 -1px .2em 0; }
		.ui-tabs-vertical .ui-tabs-nav li a { display:block; }
		.ui-tabs-vertical .ui-tabs-nav li.ui-tabs-selected { padding-bottom: 0; padding-right: .1em; border-right-width: 1px; border-right-width: 1px; }
		.ui-tabs-vertical .ui-tabs-panel { padding: 1em; float: right; width: 40em;}	

	</style>

	<!-- Load the Custom CSS file -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/default_layout.css" />
	<!--[if IE 7]>
		<link type="text/css" href="<?php echo base_url()?>css/default_ie_only.css" rel="stylesheet" />
	<![endif]-->
	<!-- added by laxman   -->
	<!--[if (IE 6)]>
		<link type="text/css" href="<?php echo base_url()?>css/ie6_only.css" rel="stylesheet" />	
	<![endif]-->
	<!--[if IE 7]>
		<link type="text/css" href="<?php echo base_url()?>css/ie7_only.css" rel="stylesheet" />
	<![endif]-->
	<!--[if IE 8]>
		<link type="text/css" href="<?php echo base_url()?>css/ie8_only.css" rel="stylesheet" />
	<![endif]-->

	<style>
	.ui-tabs-vertical { width: 55em; }
	.ui-tabs-vertical .ui-tabs-nav { padding: .2em .1em .2em .2em; float: left; width: 12em; }
	.ui-tabs-vertical .ui-tabs-nav li { clear: left; width: 100%; border-bottom-width: 1px !important; border-right-width: 0 !important; margin: 0 -1px .2em 0; }
	.ui-tabs-vertical .ui-tabs-nav li a { display:block; }
	.ui-tabs-vertical .ui-tabs-nav li.ui-tabs-selected { padding-bottom: 0; padding-right: .1em; border-right-width: 1px; border-right-width: 1px; }
	.ui-tabs-vertical .ui-tabs-panel { 
		float:right;
		padding:1em;
		width:auto;
	}

	.ui-tabs-vertical {
		width:95%;
	}
	.ui-tabs-vertical .ui-tabs-nav {
		float:left;
		padding:0.2em 0.1em 0.2em 0.2em;
		width:20em;
	}

	
	.ui-tabs-vertical .ui-widget-content{
		border:0px;
	}
	.ui-tabs-horizontal { width: 90%; }
	.ui-tabs-horizontal .ui-tabs-nav { margin:0; padding:0.2em 0.2em 0; width:90%;}
	.ui-tabs-horizontal .ui-tabs-nav li {border-bottom:0 none !important;
		float:left;
		list-style-image:none;
		list-style-position:outside;
		list-style-type:none;
		margin:0 0.2em 1px 0;
		padding:0;
		position:relative;
		top:1px;
		white-space:nowrap;
		width:auto;
		clear:none;
	}
	.ui-tabs-horizontal .ui-tabs-nav li a {
		float:left;
		padding:0.5em 1em;
		text-decoration:none;	
	}
	.ui-tabs-horizontal .ui-tabs-nav li.ui-tabs-selected { padding-bottom: 0; padding-right: .1em; border-right-width: 1px; border-right-width: 1px; }
	.ui-tabs-horizontal .ui-helper-clearfix {
		display:block;

	}
	.ui-tabs-vertical{
		width:95%;
	}
	.verticalTabDataWrapper{
		border:0px solid blue;
		width:90%;
	}
	</style>

	
	<script type="text/javascript">

		$(function() {
			$("#verticalTabs").tabs().addClass( "ui-tabs-vertical ui-helper-clearfix" );
			$("#verticalTabs li").removeClass( "ui-corner-top" ).addClass( "ui-corner-left" );
	
			// Add the Custom Class to control View
			$("#verticalTabs div").addClass( "verticalTabDataWrapper" );
	
			// As the CustomClass is getting added to some other un-intentional elements, remove that class from them
			$("#kolShortDetails").removeClass("verticalTabDataWrapper");
			$(".profileImage").removeClass("verticalTabDataWrapper");

	
		});


			
		/**
		* Returns the list of States of the Selected Country ID
		*/
		function getStatesByCountryId(){
			// Show the Loading Image
			$("#loadingStates").show();
			
			var countryId=$('#country_id').val();
			var params = "country_id="+countryId;	
			$("#state_id").html("<option value=''>-- Select State --</option>");
			$("#city_id").html("<option value=''>-- Select City --</option>");
			var states = document.getElementById('state_id');
			$.ajax({
				url: "<?php echo base_url()?>country_helpers/get_states_by_countryid/",
				dataType: "json",
				data: params,
				type: "POST",
				success: function(responseText){					
					$.each(responseText, function(key, value) {					
						var newState = document.createElement('option');
						newState.text = value.state_name;
						newState.value = value.state_id;
						 var prev = states.options[states.selectedIndex];
						 states.add(newState, prev);				
						});
					
                $("#state_id option[value='']").remove();
                $("#state_id").prepend("<option value=''>-- Select State --</option>");
                $("#state_id").val("");
				},
				complete: function(){
					$("#loadingStates").hide();
				}
			});		
		}

		/**
		* Returns the list of Cities of the Selected State
		*/
		function getCitiesByStateId(){
			var stateId=$('#state_id').val();
			$("#city_id").html("<option value=''>-- Select City</option>");	
			var cities = document.getElementById('city_id');
			var params = "state_id="+stateId;	
			
			$.ajax({
				url: "<?php echo base_url()?>country_helpers/get_cities_by_stateid/",
				dataType: "json",
				data: params,
				type: "POST",
				success: function(responseText){					
					$.each(responseText, function(key, value) {	
								
					var newCity = document.createElement('option');
					newCity.text = value.city_name;
					newCity.value = value.city_id;
					 var prev = cities.options[cities.selectedIndex];
					 cities.add(newCity, prev);				
					});		
					$("#city_id option[value='']").remove();
                    $("#city_id").prepend("<option value=''>-- Select City --</option>");
                    $("#city_id").val("");
				}		
			});		
			
		}
	</script>
</head>
<body>
<!-- Start of the WRAPPER div -->
<div id="wrapper" class="span-24">
	<!-- The Sliding Div -->
	<div id="searchableKeywords">
	Searchable Keywords
	</div>
	<!-- End of Sliding Div -->
	
	<!-- Start of HEADER div -->
	<?php echo $this->load->view('elements/kolm_header');?>
	
	<!-- End of HEADER div -->
	
	
	<!--  Star of Content Wrapper Div -->
	<div id="contentWrapper">
		
		<div id="contents">
			
			<!--  Start of TABS div for the Horizontal Navigation -->
			<div id="verticalTabs">
				<ul>
					<li><?php $this->load->view('elements/organization_short_details');?></li>
					
					<li><a href="#about">About</a></li>
					<li><a href="#keyPeople">Key People</a></li>
				<!-- <li><a href="#aditionalContact">Aditional Contacts</a></li>  -->	
					<li><a href="#orgSocialMedia">Social Media</a></li>
					<li><a href="#orgAssociatedPpl">Associated People</a></li>
				</ul>
				
				<?php echo $this->load->view($orgContentPage);?>
				
			</div>
			<!--  End of TABS div for the Horizontal Navigation -->
		
		</div>
		<!-- End of Contents Div -->
				
	</div>
	<!--  End of Content Wrapper Div -->
	
	<div id="footer">
		Copyright 2010
	</div>
	
</div>
<!-- End of the WRAPPER div -->				
</body>
</html>