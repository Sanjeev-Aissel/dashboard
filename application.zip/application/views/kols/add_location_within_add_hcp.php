<?php 
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter1(-1);}";
?>
<style type="text/css">

    input.error {
        background-position: 10px center;
        background-repeat: no-repeat;
    }
    .cancelIcon {
        margin-top: 5px !important;
    }

    label.error {
        padding: 2px 0px !important;
        background: none !important;
        border-color:none !important;
        border: none !important;
    }

    select.error {
        border: 1px solid red !important;
    }

    screen.css  error,.notice,.success {
        border: red;
        margin-bottom: 1em;
        padding: 0.8em;
    }

    #new_staff {
        display: none;
    }

    #new_phone {
        display: none;
    }

    td{
        vertical-align: top;
    }
    .error.postalerror{
    	display: block !important;
    	text-align: left !important;
    	color: green !important;
    }
    .alignRight{
    	vertical-align: top !important;
    }
    .requestedKols 	tr td{
    	padding: 0;
    }
    .requestedKols input[type="text"], .requestedKols select{
    	width: 200px;
    	margin-bottom: 5px;
    }
    #postal_code1{
    	width: 192px;
    }
    #org_type1{
    	width: 207px;
    }
    .microView{width: 700px !important;}
</style>
<script type="text/javascript">
    var staff_count = <?php
if (isset($locationData)) {
    echo count($staffData);
} else {
    echo 0;
}
?>;
    var phone_count = <?php
if (isset($locationData)) {
    echo count($phoneData);
} else {
    echo 0;
}
?>;
 $(document).ready(function () {
     var privatePractice='<?php echo $locationData['private_practice']; ?>';
        if (privatePractice!="") {
             $("#organization1").removeClass("autocompleteInputBox"); //checked
        }
        else {
          $("#organization1").addClass("autocompleteInputBox"); //not checked
        }
    });
      
    var validationRules = {
        address1: {
            required: true
        },
        country_id: {
            required: true
        },
        address_type: {
            required: true
        },
        postal_code: {
            required: true
        },
        organization: {
            required: true
        }
    };
    var validationMessages = {
        address1: {
            required: "Required"
        },
        country_id: {
            required: "Required"
        },
        address_type: {
            required: "Required"
        },
        postal_code: {
            required: "Required"
        },
        organization: {
            required: "Required"
        }
    };
    $('#saveKolLocation').click(function () {
        if (!$("#saveKolLocationForm").validate().form()) {
            return false;
        }
        /*$('.msgBox').removeClass('success');
        $('.msgBox').addClass('notice');
        $('.msgBox').show();
        $('.msgBox').html('Adding Location... <img src="<?php echo base_url() ?>images/ajax_loader_black.gif" />');*/
        
        var tableHtml = '';
    	tableHtml += '<tr>';
    	tableHtml += '<td>'+$("#organization1").val()+'<input type="hidden" name="organization_name[]" value="'+$("#organization1").val()+'"/><input type="hidden" name="organization_institution_id[]" value="'+$("#org_institution_id1").val()+'"/><input type="hidden" name="organization_type[]" value="'+$("#org_type1").val()+'"/></td>';
    	tableHtml += '<td>'+$("#address11").val()+'<input type="hidden" name="organization_address1[]" value="'+$("#address11").val()+'"/><input type="hidden" name="organization_address2[]" value="'+$("#address21").val()+'"/></td>';
    	tableHtml += '<td>'+$("#city_id1 option:selected").text()+'<input type="hidden" name="organization_country[]" value="'+$("#country_id1 option:selected").val()+'"/><input type="hidden" name="organization_city[]" value="'+$("#city_id1 option:selected").val()+'"/></td>';
    	tableHtml += '<td>'+$("#state_id1 option:selected").text()+'<input type="hidden" name="organization_state[]" value="'+$("#state_id1 option:selected").val()+'"/></td>';
    	tableHtml += '<td>'+$("#postal_code1").val()+'<input type="hidden" name="organization_postal_code[]" value="'+$("#postal_code1").val()+'"/></td>';
    	tableHtml += '<td>Physical</td>';
    	tableHtml += '<td><img title="Delete" alt="Delete" class="delete" src="<?php echo base_url();?>images/delete_active.png" onclick="deleteSectionRow(this);"></td>';
    	tableHtml += '</tr>';
    	$("#sectionWrapper tbody tr:last").before(tableHtml);
    	
    	var newLocationOption = '';
    	/* if($("#org_institution_id1").val() != ''){
    		newLocationOption += '<option value="'+$("#org_institution_id1").val()+'">'+$("#organization1").val()+'</option>';
        }else{
        	newLocationOption += '<option value="'+$("#organization1").val()+'">'+$("#organization1").val()+'</option>';
        } */
    	newLocationOption += '<option value="'+$("#organization1").val()+'">'+$("#organization1").val()+'</option>';
    	$("#staff_location").append(newLocationOption);
    	$("#phone_location").append(newLocationOption);
    	$("#micro").dialog("close");
       
    });
    function closeDialog() {
        $("#addLocationForKols").dialog("close");
        window.location = "<?php echo base_url() ?>kols/view/" + $("#kol_id").val() + "/details";
    }

    /**
     * Returns the list of States of the Selected Country ID
     */
    function getStatesByCountryId1() {
    	$("#postal_code1").parent().find("label.error").remove();
        // Show the Loading Image
        $("#loadingStates1").show();
        var countryId = $('#saveKolLocationForm #country_id1').val();
        var params = "country_id=" + countryId;
        $("#saveKolLocationForm #state_id1").html("<option value=''>-- Select --</option>");
        $("#saveKolLocationForm #city_id1").html("<option value=''>-- Select --</option>");
        var states = document.getElementById("saveKolLocationForm").elements.namedItem("state_id");
        $.ajax({
            url: "<?php echo base_url() ?>country_helpers/get_states_by_countryid/",
            dataType: "json",
            data: params,
            type: "POST",
            success: function (responseText) {
                $.each(responseText, function (key, value) {
                    var newState = document.createElement('option');
                    newState.text = value.state_name;
                    newState.value = value.state_id;
                    var prev = states.options[states.selectedIndex];
                    states.add(newState, prev);
                });
                
                $("#saveKolLocationForm #state_id1 option[value='']").remove();
                $("#saveKolLocationForm #state_id1").prepend("<option value=''>-- Select --</option>");
                $("#saveKolLocationForm #state_id1").val("");
            },
            complete: function () {
                $("#loadingStates1").hide();
            }
        });
    }

    /**
     * Returns the list of Cities of the Selected State
     */
    function getCitiesByStateId1() {
    	$("#postal_code1").parent().find("label.error").remove();
        // Show the Loading Image
        $("#loadingCities1").show();
        var stateId = $('#saveKolLocationForm #state_id1').val();
        $("#saveKolLocationForm #city_id1").html("<option value=''>-- Select --</option>");
        var cities = document.getElementById("saveKolLocationForm").elements.namedItem("city_id");
        var params = "state_id=" + stateId;
        if(stateId == ''){
			$("#loadingCities1").hide();
			return false;
		}
        $.ajax({
            url: "<?php echo base_url() ?>country_helpers/get_cities_by_stateid/",
            dataType: "json",
            data: params,
            type: "POST",
            success: function (responseText) {
                $.each(responseText, function (key, value) {

                    var newCity = document.createElement('option');
                    newCity.text = value.city_name;
                    newCity.value = value.city_id;
                    var prev = cities.options[cities.selectedIndex];
                    cities.add(newCity, prev);
                });
                $("#saveKolLocationForm #city_id1 option[value='']").remove();
                    $("#saveKolLocationForm #city_id1").prepend("<option value=''>-- Select --</option>");
                    $("#saveKolLocationForm #city_id1").val("");
            },
            complete: function () {
                $("#loadingCities1").hide();
            }
        });
    }

    function addLocStaff() {
        $("#delete_staff_" + staff_count).show();
        $("#add_staff").remove();

        staff_count++;

        var html = "<tr id='staff_" + staff_count + "'>";
        html += $("#new_staff tr").html();
        html += '<td><img id="add_staff" title="Add Staff" alt="Add Staff" src="<?php echo base_url(); ?>/images/add_active.png" onclick="addLocStaff();">';
        html += '<img class="cancelIcon" id="delete_staff_' + staff_count + '" title="Delete Staff" alt="Delete Staff" src="<?php echo base_url(); ?>/images/delete_active.png" onclick="deleteLocStaff(' + staff_count + ');" style="display:none"></td>';
        html += "</tr>";

        $("#staff_table").append(html);
    }

    function deleteLocStaff(id) {
        $("#staff_" + id).remove();
    }


    function addLocPhone() {
        $("#delete_phone_" + phone_count).show();
        $("#add_phone").remove();

        phone_count++;

        var html = "<tr id='phone_" + phone_count + "'>";
        html += $("#new_phone tr").html();
        html += '<td><img id="add_phone" title="Add Phone" alt="Add Phone" src="<?php echo base_url(); ?>/images/add_active.png" onclick="addLocPhone();">';
        html += '<img class="cancelIcon" id="delete_phone_' + phone_count + '" title="Delete Phone" alt="Delete Phone" src="<?php echo base_url(); ?>/images/delete_active.png" onclick="deleteLocPhone(' + phone_count + ');" style="display:none"></td>';
        html += "</tr>";

        $("#phone_table").append(html);
    }

    function deleteLocPhone(id) {
        $("#phone_" + id).remove();
    }


    $(function () {
        $("#saveKolLocationForm").validate({
            debug: true,
            onkeyup: true,
            rules: validationRules,
            messages: validationMessages
        });
    });
    // Autocomplet Options for the 'Organizer' field 
    var organizationNameAutoCompleteOptions1 = {
        serviceUrl: '<?php echo base_url(); ?>kols/get_organization_names',
<?php echo $autoSearchOptions; ?>,
                onSelect: function (event, ui) {
                    var selText = $(event).children('.organizations').html();
                    var selId = $(event).children('.organizations').attr('name');
                    selText = selText.replace(/\&amp;/g, '&');
                    $('#organization1').val(selText);
//                    $('#org_institution_id1').val(selId);
                    $('#org_institution_id1').val(selId).trigger('change');

                    if (event.length > 20) {
                        if (event.substring(0, 21) == "No results found for ") {
                            $('#organization1').val(trim(split(' ', selText)[4]));
                            return false;
                        } else {
                            //doSearchFilter1( - 1);
                        }
                    } else {
                        //doSearchFilter1( - 1);
                    }
                }
    };
    $(document).ready(function () {
         $('#private_practice1').change(function() {
        if ($(this).prop('checked')) {
             $("#organization1").removeClass("autocompleteInputBox"); //checked
        }
        else {
          $("#organization1").addClass("autocompleteInputBox"); //not checked
        }
    });
         var changeAutoComplete = 0;
         var attr = $("#org_type1").attr('disabled');
       	if (typeof attr !== typeof undefined && attr !== false) {
       		changeAutoComplete = 1;
       	}
        $('#org_institution_id1').change(function () {
            OrgId = $(this).val();
            $.ajax({
                url: '<?php echo base_url() ?>organizations/getOrgDetails/' + OrgId,
                type: 'POST',
                dataType: 'JSON',
                success: function (returnData) {

//                  $('#keyInsightName option').remove();
//                    $('#keyInsightName').append('<option value="select">Select key Insight Name</option>');
                    for (var result in returnData) {
//                     alert(returnData[result].city_id);
                        $("#country_id1").val(returnData[result].country_id);
                        $("#address11").val(returnData[result].address);
                        $("#postal_code1").val(returnData[result].postal_code);
                        $("#state_id1").val(returnData[result].state_id);
                        if(returnData[result].type_id > 0){
    						$("#org_type1").prop('selectedIndex',returnData[result].type_id);	
    						$("#org_type1").prop('disabled', 'disabled');
    						$("#org_type1").css('background-color','#ccc');
    						changeAutoComplete = 1;
                        }else{
    						$("#org_type1").prop('disabled', '');
    						$("#org_type1").css('background-color','#fff');
                        }
                        $("#loadingCities1").show();
                        //var stateId = $('#state_id1').val();
                        var stateId = returnData[result].state_id;
                        $("#city_id1").html("<option value=''>-- Select --</option>");
                        var cities = document.getElementById("saveKolLocationForm").elements.namedItem("city_id");
                        var params = "state_id=" + stateId;
                        $.ajax({
                            url: "<?php echo base_url() ?>country_helpers/get_cities_by_stateid/",
                            dataType: "json",
                            data: params,
                            type: "POST",
                            success: function (responseText) {
                                $.each(responseText, function (key, value) {

                                    var newCity = document.createElement('option');
                                    newCity.text = value.city_name;
                                    newCity.value = value.city_id;
                                    var prev = cities.options[cities.selectedIndex];
                                    cities.add(newCity, prev);
                                });

                                $("#city_id1").val(returnData[result].city_id);
                            },
                            complete: function () {
                                $("#loadingCities1").hide();
                            }
                        });
                        var states = document.getElementById("saveKolLocationForm").elements.namedItem("state_id");
						var countryId = returnData[result].country_id;
                        var params = "country_id=" + countryId;
                        $.ajax({
				            url: "<?php echo base_url() ?>country_helpers/get_states_by_countryid/",
				            dataType: "json",
				            data: params,
				            type: "POST",
				            success: function (responseText) {
				            	$('#state_id1 option').remove();
				               	$.each(responseText, function (key, value) {
				                    var newState = document.createElement('option');
				                    newState.text = value.state_name;
				                    newState.value = value.state_id;
				                    var prev = states.options[states.selectedIndex];
				                    states.add(newState, prev);
				                });
				                $("#saveKolLocationForm #state_id1").prepend("<option value=''>-- Select --</option>");
				                $("#saveKolLocationForm #state_id1").val("");
				            },
				            complete: function () {
				               $("#loadingStates1").hide();
				               $("#state_id1 option[value='"+stateId+"']").attr("selected","selected");
				            }
				        });
						
                    }

                }
            });
            //fire your ajax call  
        })   // Trigger the Autocompleter for 'organizer' field of  Event'

        $("#organization1").keypress(function(){
		    if(changeAutoComplete == 1){
		    	$("#org_type1").prop('disabled', '');
				$("#org_type1").css('background-color','#fff');
				$("#org_institution_id1").val('');
			}
		});
		
        a = $('#organization1').autocomplete(organizationNameAutoCompleteOptions1);

      //------------------- Start of Postal code focusout ----------
        $("#postal_code1").on("focusout",function(){
        	$("#postal_code1").parent().find("label.error").remove();
            var postalEle = $(this);
			var postalCode = $(this).val();
			if(postalCode != ''){
				$("#loadingStates1").show();
				$.ajax({
		            url: '<?php echo base_url() ?>country_helpers/get_zip_code_details/'+postalCode,
		            type: 'post',
		            dataType: 'json',
		            success: function (returnData) {
		            	$(postalEle).parent().find("label.error").remove();
		              if(returnData.status == 1){
						$("#country_id1").val(returnData.details.country_id);

						$("#loadingStates1").show();
				        var countryId = $('#country_id1').val();
				        var params = "country_id=" + countryId;
				        $("#saveKolLocationForm #state_id1").html("<option value=''>-- Select --</option>");
				        $("#city_id1").html("<option value=''>-- Select --</option>");
				        var states = document.getElementById("saveKolLocationForm").elements.namedItem("state_id");
				        $.ajax({
				            url: "<?php echo base_url() ?>country_helpers/get_states_by_countryid/",
				            dataType: "json",
				            data: params,
				            type: "POST",
				            success: function (responseText) {
				                $.each(responseText, function (key, value) {
				                    var newState = document.createElement('option');
				                    newState.text = value.state_name;
				                    newState.value = value.state_id;
				                    var prev = states.options[states.selectedIndex];
				                    states.add(newState, prev);
				                });
				                $("#saveKolLocationForm #state_id1 option[value='']").remove();
				                $("#saveKolLocationForm #state_id1").prepend("<option value=''>-- Select --</option>");
				                $("#saveKolLocationForm #state_id1").val("");
				            },
				            complete: function () {
				                $("#loadingStates1").hide();
				                $("#saveKolLocationForm #state_id1").val(returnData.details.region_id);
								//$("#city_id1").val(returnData.details.city_id);
								var stateId = $('#saveKolLocationForm #state_id1').val();
		                        $("#city_id1").html("<option value=''>-- Select --</option>");
		                        var cities = document.getElementById('city_id');
		                        var params = "state_id=" + stateId;
		                        $("#loadingCities1").show();
								 $.ajax({
		                            url: "<?php echo base_url() ?>country_helpers/get_cities_by_stateid/",
		                            dataType: "json",
		                            data: params,
		                            type: "POST",
		                            success: function (responseText) {
		                                $.each(responseText, function (key, value) {

		                                    var newCity = document.createElement('option');
		                                    newCity.text = value.city_name;
		                                    newCity.value = value.city_id;
		                                    var prev = cities.options[cities.selectedIndex];
		                                    cities.add(newCity, prev);
		                                });

		                                $("#city_id1").val(returnData.details.city_id);
		                            },
		                            complete: function () {
		                                $("#loadingCities1").hide();
		                            }
		                        });				                
				            }
				        });
						
	                        if(returnData.details.city_id == '')
						 		$(postalEle).parent().append('<label for="postal_code" generated="true" class="error postalerror" style="color:green !important">Unable to populate City, State for given Postal Code.</label>');
			          }else{
							$(postalEle).parent().append('<label for="postal_code" generated="true" class="error postalerror" style="color:green !important">Unable to populate City, State for given Postal Code.</label>');
				      }
		            },
		            complete: function () {
                        $("#loadingStates1").hide();
                    }
		        });
			}
        });
		// ------------------- End of Postal code focusout ----------
		
    });

    function changeAutoComplete(){
    	var orgType = $('#org_type1').find(":selected").text();
    	if(orgType == 'Private Practice'){
        	$('#private_practice1').val('1');
			//$('#organization1').removeClass('autocompleteInputBox');
        }else{
        	$('#private_practice1').val('0');
        	//$('#organization1').addClass('autocompleteInputBox');
        }
    }
</script>


<div class="msgBox"></div>

<div id="similarNames">

</div>

<h4 style="border-bottom: 1px solid #bbbbbb;">Location </h4>
<form action="save_kol_location" method="post" id="saveKolLocationForm" name="saveKolLocationForm">
    <?php //pr($locationData); ?>
    <?php
    if (isset($locationData)) {
        ?>
        <input type="hidden" name="id" value="<?php echo $locationData['id']; ?>"/>
        <input type="hidden" name="kol_id" id="kol_id" value="<?php echo $locationData['kol_id']; ?>"/>
        <?php
    } else {
        ?>
        <input type="hidden" name="kol_id"  id="kol_id" value="<?php echo $kolId; ?>"/>
        <?php
    }
    ?>
  <table class="requestedKols">
        <tbody>
            <tr>
                <td style="width: 50%;">
                    <table style="te">
                        
                        <tr>
                            <td class="alignRight"><label for="org_institution_id">Institution<span class="required">*</span>:</label></td>
                            <td>
                                <input type="text" name="organization" class="autocompleteInputBox" id="organization1" placeholder="Enter Organization" title="" 
                                <?php
                                if (isset($locationData) && $locationData['org_institution_name'] != "0") {
                                    echo 'value="' . $locationData['org_institution_name'] . '"';
                                }
                                else{
                                      echo 'value="' . $locationData['private_practice'] . '"';
                                }
                                ?>/>
                                <input type="hidden" name="org_institution_id" id="org_institution_id1" 
                                <?php
                                if (isset($locationData)) {
                                    echo 'value="' . $locationData['org_institution_id'] . '"';
                                } else {
                                    echo 'value=""';
                                }
                                ?>/>
                            </td>
                        </tr>
                        
                         <tr>
                              	<td class="alignRight"><label for = "title">Institution Type :</label></td>
		                        <td>
		                        	<input type="hidden" name="private_practice" id="private_practice1" value="1"/>                      	
		                            <select name = "org_type" id = 'org_type1' onchange="changeAutoComplete();"
			                            <?php 
				                           if (!empty($orgTypeId)){
				                            		echo "disabled";
				                            		echo " style='background-color: #ccc;'";
				                            }		                            
			                            ?>
		                            >
		                                <option value = ""> --Select--</option>
		                                <?php
		                                	foreach ($arrOrganizationTypes as $key => $value) {
		                                ?>
		                                <option value="<?php echo $key; ?>"
		                                <?php 
		                                	if (!empty($orgTypeId) && $orgTypeId == $key){
			                                		echo "selected";
			                                }
		                                ?>
		                                ><?php echo $value; ?></option>
		                                <?php
		                                    }
		                                ?>
		                            </select>
		                        </td>
                                
                            </tr>
                        
                        <tr>
                            <td class="alignRight"><label for="address1">Address Line 1<span class="required">*</span>:</label></td>
                            <td>
                                <input type="text" name="address1" id="address11" 
                                <?php
                                if (isset($locationData)) {
                                    echo "value='" . $locationData['address1'] . "'";
                                } else {
                                    echo "value=''";
                                }
                                ?>
                                       maxlength="50" class="required"></input>
                            </td>
                        </tr>
                        <tr>
                            <td class="alignRight">
                                <label for="address2">Address Line 2 :</label>
                            </td>
                            <td>
                                <input type="text" name="address2" id="address21" 
                                <?php
                                if (isset($locationData)) {
                                    echo "value='" . $locationData['address2'] . "'";
                                } else {
                                    echo "value=''";
                                }
                                ?>
                                       maxlength="50"></input>
                            </td>
                        </tr>
                        <tr>

                            </td>
                        </tr>
                    </table>
                </td>

                <td>
                    <table>
                        
                        <tr>
                            <td class="alignRight">
                                <label for="address_type">Address Type<span class="required">*</span> :</label>
                            </td>
                            <td>
                                <select name="address_type">
                                    <option value="">--Select--</option>
                                    <option value="Billing" 
                                    <?php
                                    if ($locationData['address_type'] == "Billing")
                                        echo "selected";
                                    ?>
                                            >Billing</option>
                                    <option value="Headquarters" 
                                    <?php
                                    if ($locationData['address_type'] == "Headquarters")
                                        echo "selected";
                                    ?>
                                            >Headquarters</option>
                                    <option value="Mailing" 
                                    <?php
                                    if ($locationData['address_type'] == "Mailing")
                                        echo "selected";
                                    ?>
                                            >Mailing</option>
                                    <option value="Pharmacy Operations" 
                                    <?php
                                    if ($locationData['address_type'] == "Pharmacy Operations")
                                        echo "selected";
                                    ?>
                                            >Pharmacy Operations</option>
                                    <option value="Physical" selected="selected"
                                    <?php
                                    if ($locationData['address_type'] == "Physical")
                                        echo "selected";
                                    ?>
                                            >Physical</option>
                                    <option value="Shipping" 
                                    <?php
                                    if ($locationData['address_type'] == "Shipping")
                                        echo "selected";
                                    ?>
                                            >Shipping</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td class="alignRight">
                                <label for="postal_code">Postal Code<span class="required">*</span> :</label>
                            </td>
                            <td>
                                <input type="text" name="postal_code" id="postal_code1" 
                                <?php
                                if (isset($locationData)) {
                                    if ($locationData['postal_code'] != "") {
                                        echo 'value="' . $locationData['postal_code'] . '"';
                                    }
                                }
                                ?>
                                       />
                            </td>
                        </tr>
                        <tr>
                            <td class="alignRight">
                                <label for="country_id">Country<span class="required">*</span> :</label>
                            </td>
                            <td>
                            
                                <select name="country_id" id="country_id1" onchange="getStatesByCountryId1();" class="required">
                                    <!--<option value="">-- Select --</option>-->
                                    <?php foreach ($arrCountries as $country) { ?>
                                        <option value="<?php echo $country['country_id']; ?>" 
                                        <?php
                                        if (isset($locationData)) {
                                            if ($country['country_id'] == $locationData['country_id']) {
                                                echo 'selected';
                                            }
                                        }
                                        ?>

                                        <?php
                                        /*
                                            if ($currentMethod != "edit_ol" && $country['country_id'] == "254")
                                                  echo "selected";
                                        */
                                        ?>
                                                >
                                        <?php echo $country['country_name']; ?>
                                        </option>
<?php } ?>
                                </select>
                                <img id="loadingStates1" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:none"/>
                            </td>
                        </tr>
                        <tr>
                            <td class="alignRight">									
                                <label for="stateId1">State / Province :</label>
                            </td>
                            <td>
                                <select name="state_id" id="state_id1" onchange="getCitiesByStateId1();">		
                                    <option value="">-- Select --</option>
                                    <?php foreach ($arrStates as $state) { ?>
                                        <option value="<?php echo $state['state_id']; ?>" 
                                        <?php
                                        if (isset($locationData)) {
                                            if ($state['state_id'] == $locationData['state_id']) {
                                                echo 'selected';
                                            }
                                        }
                                        ?>>
                                        <?php echo $state['state_name']; ?>
                                        </option>
<?php } ?>
                                </select>
                                <img id="loadingCities1" src="<?php echo base_url() ?>/images/ajax_loader_black.gif" style="display:none"/>
                            </td>
                        </tr>
                        <tr>
                            <td class="alignRight">
                                <label for="city_id">City :</label>
                            </td>
                            <td>
                                <select name="city_id" id="city_id1">
                                    <!--<option value="">Select city</option>-->

                                    <?php
                                    if (isset($locationData)) {
                                        foreach ($arrCities as $city) {
                                            echo '<option value="' . $city['city_id'] . '" ';
                                            if ($city['city_id'] == $locationData['city_id']) {
                                                echo 'selected';
                                            } else {
                                                if ($city['$city'] == 254) {
                                                    echo 'selected';
                                                }
                                            }
                                            echo '>' . $city['city_name'] . '</option>';
                                        }
                                    } else {
                                        ?>
                                        <?php foreach ($arrCities as $city) { ?>
                                            <option value="<?php echo $city['city_id']; ?>"
                                            <?php
                                            if (isset($locationData)) {
                                                if ($state['city_id'] == $locationData['city_id']) {
                                                    echo 'selected';
                                                }
                                            }
                                            ?>><?php echo $city['city_name']; ?>
                                            </option>
                                        <?php
                                        }
                                    }
                                    ?>   
                                </select>
                            </td>
                        </tr>
                 
                    </table>
                </td>
            </tr>

            <!-- End of Personal and Professional Information -->


        </tbody>
    </table>


    <tr>
        <td colspan="2">
            <div class="formButtons">	
                <input type="button" value="Add Location" name="submit" id="saveKolLocation"></input>
            </div>
        </td>
    </tr>
</tbody>
</table>
</form>
