<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts = array('reports/scatr_graph',
								'jquery.treeview',
								//'jquery.validate'
								'jquery/jquery.validate1.9.min');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<!--  -->	
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/jquery.treeview.css" />
	<!--<script type="text/javascript" src="<?php echo base_url();?>js/jquery.treeview.js" ></script>
		--><!-- 2nd Plugin for Validation -->
	<!--<script type="text/javascript" src="<?php echo base_url()?>js/jquery.validate.js"></script>
  -->
 <style type="text/css">
 /* #scatGraph{
  	float: right;
  }
  */
  #browser {
    font-family: Verdana, helvetica, arial, sans-serif;
    font-size: 68.75%;
  }
  /*   */
	.hitarea {
		background:transparent url(<?php echo base_url();?>images/treeview-default.gif) no-repeat scroll -64px -25px;
		cursor:pointer;
		float:left;
		height:16px;
		width:16px;
		margin-left: 0px !important;
	}
	.expandable-hitarea {
		background-position:-80px -3px;
	}
	
	td .secondParent{
		margin-left: 5px;
	}
	
	#scatteredDiagramArea .weightagex,#scatteredDiagramArea .weightagey{
		border:0; 
		color:#f6931f; 
		font-weight:bold;
	}
	
	#scatteredDiagramArea .tweightagex,#scatteredDiagramArea .tweightagey{
		border:0; 
		color:#f6931f; 
		font-weight:bold;
	}
	
	.secondParentName {
		margin-left: 25px;
	}
	
	.endElementName {
		margin-left: 35px;
	}
	

	.treeview li div{
		display: inline;
		width: 10%;
	}
	
	div .selecterContainers {
		float: left;
		width: 45%;
	}
	
	 /**** UI Slider ****/
.sliderContainer{
 	text-align:left;
 	margin-bottom:20px;
	border:0 none;	
 }
 
.sliderContainer .ui-widget-content {
 	width:98%;
	overflow:visible;	
	height:1px;
 }
 
.sliderContainer .ui-widget-header{
 	height:2px;
 }
 
.sliderContainer p{
 	margin:0;
 	padding:0;
 }
 
 .sliderContainer .ui-slider-horizontal .ui-slider-handle{
 	background-image: url(../images/slider_handle.gif);
 	background-repeat: no-repeat;
 	background-color: none;
 	width:11px;
 	height:13px;
 	border:0;
 }
 
.sliderContainer p{
  	font-size:10px;
  	margin-bottom:4px;
}

.sliderContainer p label{
  	font-size:10px;
}

.sliderContainer .tweightagex,.sliderContainer .tweightagey{
	display:inline;
  	width:80px;
	font-size:10px;
}
	
.weightage{
	border:0; 
	color:#f6931f; 
	font-weight:bold;
}
.secondParentName {
    margin-left: 8px;
}

#sgmentationOptions{
	border: 1px dotted;
   /* padding: 2px 0 10px;
    margin-right: 20px;*/
    padding:5px;
}
/*#sgmentationOptions button {
    margin: 0 50px;
}*/
#sgmentationOptions input{
	float: left;
}
input.weightagex, input.weightagey{
	height: 13px;
    margin-bottom: 0;
    margin-top: -11px;
    text-align: center;
    width: 30px;
}
#scatTable{
	margin-bottom: 0px;
}
.c3-circle {
    opacity: 1 !important;
}
  </style>	
<script type="text/javascript" language="javascript">
	var subSliders= new Array;
</script>
<input type="hidden" name="kol_id" value="" id="kolId2"></input>
<div id="scatOpsTreeAndTable" class="scatG treeview">
  <table id="scatTable">
  	<thead>
  		<tr>
  			<th width="160px">Categories</th>
  			<th>X-Axis</th>
  			<th>Y-Axis</th>
  			<th>Exclude</th>
  			<th>X-Sliders<input type="text" id="totalWeightx" class="tweightagex" /></th>
  			<th>Y-Sliders<input type="text" id="totalWeighty" class="tweightagey" /></th>
  		</tr>
  	</thead>
  	<tbody>
  		<tr>
  			<td class="expandable affParent"><div class="hitarea expandable-hitarea" onclick="expandThis('affChaild',this);" id="affParent"><div style="padding-left: 20px; margin-top: -3px;">Affiliations</div></div></td>
  			<td><input type="radio" name="aff" value="x" id="affX" /></td>
  			<td><input type="radio" name="aff" value="y" id="affY" /></td>
  			<td><input type="radio" name="aff" value="e" id="affE" checked="checked" /></td>
  			<td><input type="text" id="affWeightx" class="weightagex" /><div id="affSliderx" class="sliderContainer"><div id="affSliderBarx"></div></div></td>
  			<td><input type="text" id="affWeighty" class="weightagey" /><div id="affSlidery" class="sliderContainer"><div id="affSliderBary"></div></div></td>
  		</tr>
  		<div id="affChailds">
  			<tr class="affChaild  secondParent" style="display:none">
	  			<td class="expandable engParent" align="center"><div class="secondParentName" title="Engagement Types"><div class="hitarea expandable-hitarea" onclick="expandThis('engChaild',this);" id="engParent"></div>Eng Types</div></td>
	  			<td><input type="radio" name="eng" value="x" id="engX" /></td>
	  			<td><input type="radio" name="eng" value="y" id="engY" /></td>
	  			<td><input type="radio" name="eng" value="e" id="engE" checked="checked" /></td>
	  			<td><input type="text" id="engWeightx" class="weightagex" /><div id="engSliderx" class="sliderContainer"><div id="engSliderBarx"></div></div></td>
  				<td><input type="text" id="engWeighty" class="weightagey" /><div id="engSlidery" class="sliderContainer"><div id="engSliderBary"></div></div></td>
  			</tr>
  			<div id="engChailds" >
  				<?php foreach($arrEngagementTypes as $engType){?>
			  		<tr class="engChaild" id="engChaild<?php echo $engType['id'];?>" style="display:none">
			  			<td><div class="endElementName"><?php echo $engType['type'];?></div></td>
			  			<td><input type="radio" name="eng<?php echo $engType['id'];?>" value="x" id="eng<?php echo $engType['id'];?>X" /></td>
			  			<td><input type="radio" name="eng<?php echo $engType['id'];?>" value="y" id="eng<?php echo $engType['id'];?>Y" /></td>
		  				<td><input type="radio" name="eng<?php echo $engType['id'];?>" value="e" id="eng<?php echo $engType['id'];?>E" checked="checked" /></td>
		  				<td><input type="text" id="eng<?php echo $engType['id'];?>Weightx" class="weightagex" /><div id="eng<?php echo $engType['id'];?>Sliderx" class="sliderContainer"><div id="eng<?php echo $engType['id'];?>SliderBarx"></div></div></td>
  						<td><input type="text" id="eng<?php echo $engType['id'];?>Weighty" class="weightagey" /><div id="eng<?php echo $engType['id'];?>Slidery" class="sliderContainer"><div id="eng<?php echo $engType['id'];?>SliderBary"></div></div></td>
  						<script type="text/javascript">
	  						//initializeSlider('eng<?php echo $engType['id'];?>','x');
	  						//initializeSlider('eng<?php echo $engType['id'];?>','y');
	  						//subSliders[] ="eng<?php echo $engType['id'];?>";
  						</script>
  						<?php $subSliders[]= 'eng'.$engType['id'];?>
	  				</tr>
			  	<?php }?>
  			</div>
	  		<tr class="affChaild  secondParent" style="display: none">
	  			<td class="expandable orgParent" align="center"><div class="secondParentName" title="Organization Types"><div class="hitarea expandable-hitarea" onclick="expandThis('orgChaild',this);" id="orgParent"></div>Org Types</div></td>
	  			<td><input type="radio" name="org" value="x" id="orgX" /></td>
	  			<td><input type="radio" name="org" value="y" id="orgY" /></td>
	  			<td><input type="radio" name="org" value="e" id="orgE" checked="checked" /></td>
	  			<td><input type="text" id="orgWeightx" class="weightagex" /><div id="orgSliderx" class="sliderContainer"><div id="orgSliderBarx"></div></div></td>
  				<td><input type="text" id="orgWeighty" class="weightagey" /><div id="orgSlidery" class="sliderContainer"><div id="orgSliderBary"></div></div></td>
	  		</tr>
	  		<div id="orgChailds">
	  			<?php foreach($arrOrganizationTypes as $orgType){?>
			  		<tr class="orgChaild" id="orgChaild<?php echo $orgType['type'];?>" style="display:none">
			  			<td ><div class="endElementName"><?php echo ucwords($orgType['type']);?></div></td>
			  			<td><input type="radio" name="org<?php echo $orgType['type'];?>" value="x" id="org<?php echo $orgType['type'];?>X" /></td>
			  			<td><input type="radio" name="org<?php echo $orgType['type'];?>" value="y" id="org<?php echo $orgType['type'];?>Y" /></td>
		  				<td><input type="radio" name="org<?php echo $orgType['type'];?>" value="e" id="org<?php echo $orgType['type'];?>E" checked="checked" /></td>
		  				<td><input type="text" id="org<?php echo $orgType['type'];?>Weightx" class="weightagex" /><div id="org<?php echo $orgType['type'];?>Sliderx" class="sliderContainer"><div id="org<?php echo $orgType['type'];?>SliderBarx"></div></div></td>
  						<td><input type="text" id="org<?php echo $orgType['type'];?>Weighty" class="weightagey" /><div id="org<?php echo $orgType['type'];?>Slidery" class="sliderContainer"><div id="org<?php echo $orgType['type'];?>SliderBary"></div></div></td>
  						<script type="text/javascript">
	  						//initializeSlider('org<?php echo $orgType['type'];?>','x');
	  						//initializeSlider('org<?php echo $orgType['type'];?>','y');
  						</script>
  						<?php $subSliders[]= 'org'.$orgType['type'];?>
	  				</tr>
			  	<?php }?>
  			</div>
  		</div>
  		<tr>
  			<td class="expandable eventParent"><div class="hitarea expandable-hitarea" onclick="expandThis('eventChaild',this);"  id="eventParent"><div style="padding-left: 20px; margin-top: -3px;">Events</div></div></td>
  			<td><input type="radio" name="event" value="x" id="eventX" /></td>
  			<td><input type="radio" name="event" value="y" id="eventY" /></td>
  			<td><input type="radio" name="event" value="e" id="eventE" checked="checked" /></td>
  			<td><input type="text" id="eventWeightx" class="weightagex" /><div id="eventSliderx" class="sliderContainer"><div id="eventSliderBarx"></div></div></td>
  			<td><input type="text" id="eventWeighty" class="weightagey" /><div id="eventSlidery" class="sliderContainer"><div id="eventSliderBary"></div></div></td>
  		</tr>
  		<div id="eventChailds">
  			<tr class="eventChaild secondParent" style="display: none">
	  			<td class="expandable sesParent" align="center"><div class="secondParentName"><div class="hitarea expandable-hitarea" onclick="expandThis('sesChaild',this);"  id="sesParent"></div>Session Type</div></td>
	  			<td><input type="radio" name="ses" value="x" id="sesX" /></td>
	  			<td><input type="radio" name="ses" value="y" id="sesY" /></td>
	  			<td><input type="radio" name="ses" value="e" id="sesE" checked="checked" /></td>
	  			<td><input type="text" id="sesWeightx" class="weightagex" /><div id="sesSliderx" class="sliderContainer"><div id="sesSliderBarx"></div></div></td>
  				<td><input type="text" id="sesWeighty" class="weightagey" /><div id="sesSlidery" class="sliderContainer"><div id="sesSliderBary"></div></div></td>
  			</tr>
  			<div id="sesChailds">
	  			<?php foreach($arrSessionTypes as $sesType){?>
			  		<tr class="sesChaild" id="sesChaild<?php echo $sesType['id'];?>" style="display:none">
			  			<td ><div class="endElementName"><?php echo $sesType['type'];?></div></td>
			  			<td><input type="radio" name="ses<?php echo $sesType['id'];?>" value="x" id="ses<?php echo $sesType['id'];?>X" /></td>
			  			<td><input type="radio" name="ses<?php echo $sesType['id'];?>" value="y" id="ses<?php echo $sesType['id'];?>Y" /></td>
		  				<td><input type="radio" name="ses<?php echo $sesType['id'];?>" value="e" id="ses<?php echo $sesType['id'];?>E" checked="checked" /></td>
		  				<td><input type="text" id="ses<?php echo $sesType['id'];?>Weightx" class="weightagex" /><div id="ses<?php echo $sesType['id'];?>Sliderx" class="sliderContainer"><div id="ses<?php echo $sesType['id'];?>SliderBarx"></div></div></td>
  						<td><input type="text" id="ses<?php echo $sesType['id'];?>Weighty" class="weightagey" /><div id="ses<?php echo $sesType['id'];?>Slidery" class="sliderContainer"><div id="ses<?php echo $sesType['id'];?>SliderBary"></div></div></td>
  						<script type="text/javascript">
	  						//initializeSlider('ses<?php echo $sesType['id'];?>','x');
	  						//initializeSlider('ses<?php echo $sesType['id'];?>','y');
  						</script>
  						<?php $subSliders[]= 'ses'.$sesType['id'];?>
	  				</tr>
			  	<?php }?>
  			</div>
	  		<tr class="eventChaild secondParent" style="display: none">
	  			<td class="expandable rolParent" align="center"><div class="secondParentName"><div class="hitarea expandable-hitarea" onclick="expandThis('rolChaild',this);"  id="rolParent"></div>Roles</div></td>
	  			<td><input type="radio" name="rol" value="x" id="rolX" /></td>
	  			<td><input type="radio" name="rol" value="y" id="rolY" /></td>
	  			<td><input type="radio" name="rol" value="e" id="rolE" checked="checked" /></td>
	  			<td><input type="text" id="rolWeightx" class="weightagex" /><div id="rolSliderx" class="sliderContainer"><div id="rolSliderBarx"></div></div></td>
  				<td><input type="text" id="rolWeighty" class="weightagey" /><div id="rolSlidery" class="sliderContainer"><div id="rolSliderBary"></div></div></td>
	  		</tr>
	  		<div id="rolChailds">
	  			<?php foreach($arrRoles as $role){
	  				$roleName=str_replace(' ','-',str_replace(',','_',$role['role']));
	  			?>
			  		<tr class="rolChaild" id="rolChaild<?php echo $roleName;?>" style="display:none">
			  			<td ><div class="endElementName"><?php echo $role['role'];?></div></td>
			  			<td><input type="radio" name="rol<?php echo $roleName;?>" value="x" id="rol<?php echo $roleName;?>X" /></td>
			  			<td><input type="radio" name="rol<?php echo $roleName;?>" value="y" id="rol<?php echo $roleName;?>Y" /></td>
		  				<td><input type="radio" name="rol<?php echo $roleName;?>" value="e" id="rol<?php echo $roleName;?>E" checked="checked" /></td>
		  				<td><input type="text" id="rol<?php echo $roleName;?>Weightx" class="weightagex" /><div id="rol<?php echo $roleName;?>Sliderx" class="sliderContainer"><div id="rol<?php echo $roleName;?>SliderBarx"></div></div></td>
  						<td><input type="text" id="rol<?php echo $roleName;?>Weighty" class="weightagey" /><div id="rol<?php echo $roleName;?>Slidery" class="sliderContainer"><div id="rol<?php echo $roleName;?>SliderBary"></div></div></td>
  						<script type="text/javascript">
	  						//initializeSlider('rol<?php echo $roleName;?>','x');
	  						//initializeSlider('rol<?php echo $roleName;?>','y');
  						</script>
  						<?php $subSliders[]= 'rol'.$roleName;?>
	  				</tr>
			  	<?php }?>
  			</div>
  		</div>
  		<tr>
  			<td class="expandable"><div class="hitarea expandable-hitarea" onclick="expandThis('pubChaild',this);"  id="pubParent"><div style="padding-left: 20px; margin-top: -3px;">Publications</div></div></td>
  			<td><input type="radio" name="pub" value="x" id="pubX" /></td>
  			<td><input type="radio" name="pub" value="y" id="pubY" /></td>
  			<td><input type="radio" name="pub" value="e" id="pubE" checked="checked" /></td>
  			<td><input type="text" id="pubWeightx" class="weightagex" /><div id="pubSliderx" class="sliderContainer"><div id="pubSliderBarx"></div></div></td>
  			<td><input type="text" id="pubWeighty" class="weightagey" /><div id="pubSlidery" class="sliderContainer"><div id="pubSliderBary"></div></div></td>
  		</tr>
  		<div id="pubChailds">
  			<tr class="pubChaild secondParent" style="display: none">
	  			<td align="center"><div class="secondParentName">First Auth</div></td>
	  			<td><input type="radio" name="pub1" value="x" id="pub1X" /></td>
	  			<td><input type="radio" name="pub1" value="y" id="pub1Y" /></td>
	  			<td><input type="radio" name="pub1" value="e" id="pub1E" checked="checked" /></td>
	  			<td><input type="text" id="pub1Weightx" class="weightagex" /><div id="pub1Sliderx" class="sliderContainer"><div id="pub1SliderBarx"></div></div></td>
  				<td><input type="text" id="pub1Weighty" class="weightagey" /><div id="pub1Slidery" class="sliderContainer"><div id="pub1SliderBary"></div></div></td>
  			</tr>
	  		<tr class="pubChaild secondParent" style="display: none">
	  			<td align="center"><div class="secondParentName">Single Auth</div></td>
	  			<td><input type="radio" name="pub2" value="x" id="pub2X" /></td>
	  			<td><input type="radio" name="pub2" value="y" id="pub2Y" /></td>
	  			<td><input type="radio" name="pub2" value="e" id="pub2E" checked="checked" /></td>
	  			<td><input type="text" id="pub2Weightx" class="weightagex" /><div id="pub2Sliderx" class="sliderContainer"><div id="pub2SliderBarx"></div></div></td>
  				<td><input type="text" id="pub2Weighty" class="weightagey" /><div id="pub2Slidery" class="sliderContainer"><div id="pub2SliderBary"></div></div></td>
  			</tr>
  			<tr class="pubChaild" style="display: none">
	  			<td align="center"><div class="secondParentName">Middle Auth</div></td>
	  			<td><input type="radio" name="pub3" value="x" id="pub3X" /></td>
	  			<td><input type="radio" name="pub3" value="y" id="pub3Y" /></td>
	  			<td><input type="radio" name="pub3" value="e" id="pub3E" checked="checked" /></td>
	  			<td><input type="text" id="pub3Weightx" class="weightagex" /><div id="pub3Sliderx" class="sliderContainer"><div id="pub3SliderBarx"></div></div></td>
  				<td><input type="text" id="pub3Weighty" class="weightagey" /><div id="pub3Slidery" class="sliderContainer"><div id="pub3SliderBary"></div></div></td>
  			</tr>
  			<tr class="pubChaild" style="display: none">
	  			<td align="center"><div class="secondParentName">Last Auth</div></td>
	  			<td><input type="radio" name="pub4" value="x" id="pub4X" /></td>
	  			<td><input type="radio" name="pub4" value="y" id="pub4Y" /></td>
	  			<td><input type="radio" name="pub4" value="e" id="pub4E" checked="checked" /></td>
	  			<td><input type="text" id="pub4Weightx" class="weightagex" /><div id="pub4Sliderx" class="sliderContainer"><div id="pub4SliderBarx"></div></div></td>
  				<td><input type="text" id="pub4Weighty" class="weightagey" /><div id="pub4Slidery" class="sliderContainer"><div id="pub4SliderBary"></div></div></td>
  			</tr>
  		</div>
  		<?php if(HIDE_CLINICAL_TRIALS){?>
  		<tr>
  			<td >Trials</td>
  			<td><input type="radio" name="trial" value="x" id="trialX" /></td>
  			<td><input type="radio" name="trial" value="y" id="trialY" /></td>
  			<td><input type="radio" name="trial" value="e" id="trialE" checked="checked" /></td>
  			<td><input type="text" id="trialWeightx" class="weightagex" /><div id="trialSliderx" class="sliderContainer"><div id="trialSliderBarx"></div></div></td>
  			<td><input type="text" id="trialWeighty" class="weightagey" /><div id="trialSlidery" class="sliderContainer"><div id="trialSliderBary"></div></div></td>
  		</tr>
  		<?php } ?>
  		<tr>
  			<td colspan="6"><center>
  				<input type="button" name="drow_graph" value="Apply" id="drowGraph"  onclick="validateAndDrawGraph();"/>
	 			<input type="button" value="Reset" onclick="resetAllWeights()" />
	 			</center>
  			</td>
  		</tr>
  		<tr>
  			<td colspan="6"><center>
  				<div id="sgmentationOptions" style="display: none;">
					<button onclick="displayModelBox()">Create List</button>
					<button onclick="window.open('<?php echo base_url()?>reports/generate_segmentation_xls');">Export to Excel</button>
					<button onclick="window.open('<?php echo base_url()?>reports/scatr_graph_html_data');">Preview</button>
				</div>
				</center>
  			</td>
  		</tr>
  	</tbody>
  </table>
</div>


<div id="chart" class="scatG"></div>
<!-- div id="scatGraph" class="scatG"></div -->

<script type="text/javascript" language="javascript">
<?php
	$arrCount=count($subSliders);
	for($i=0;$i<$arrCount; $i++){
		echo "subSliders[$i]='".$subSliders[$i]."';\n"; // prepare to initialise sub sliders
	}
?>
</script>