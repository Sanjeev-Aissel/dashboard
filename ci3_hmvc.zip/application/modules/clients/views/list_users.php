<script src="<?php echo base_url().MODULES_ASSETS;?>clients/js/client.js"></script>
<link  href="<?php echo base_url().MODULES_ASSETS;?>clients/css/client.css" rel="stylesheet">
<div style="margin:10px 0px;">
	<p style="display: inline">Select Client:</p>
	<select name="client_id" id="client_id" class="form-control required" onchange="list_users_grid();" style="width:12%;display: inline">
			<?php foreach($arrClients as $client){	?>
			<option value="<?php echo $client['id'];?>">
					<?php echo $client['name'];?>
				</option>
			<?php }?>
	</select>
	<div class="pull-right">
		<a class="btn btn-default" href="<?php echo base_url();?>clients/clients/add_user">Add-User</a>
	</div>
</div>
<div id="gridUsersListing" class="gridWrapper">
	<div id="gridUsersListingPagintaion"></div>
	<table id="gridUsersListingResultSet"></table>
</div>
<div id="userContainer" class="microViewLoading">
	<div class="addUserContent"></div>
</div>
<script>
$(document).ready(function(){
	var userProfileDialogOpts = {
			title: "Add/Edit Client User",
			modal: true,
			autoOpen: false,
			height: 400,
			width: 600,
			dialogClass: "microView",
			open: function() {
				//display correct dialog content
			},
			close:function(){
			}
	};
	$("#userContainer").dialog(userProfileDialogOpts);
	list_users_grid();
});
</script>