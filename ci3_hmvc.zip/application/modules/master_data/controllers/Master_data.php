<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @Description : Controller function manipulate to Master data details from analyst app
 * @Author : Sanjeev K
 * @Since : HMVC Kolm 1.0
 * @Package : application.controllers
 * @Created : 07-04-2018
 * @Refactored : 08-04-2018
 */
class Master_data extends CI_Controller {
	// Constructor
	private $arrPageTypes = array (
			1 => 'Specialties',
			2 => 'Organization_Types',
			3 => 'Engagement_Types',
			4 => 'Event_Topics',
			5 => 'Event_Org_Types',
			6 => 'Event_Roles' 
	);
	public function __construct()
	{
		parent::__construct();
		$this->load->model ( 'master_data_model' );
		$this->load->model('specialities/speciality');
		$this->load->model ( 'kols/kol' );
		$this->load->model ( 'helpers/common_helper' );
		$this->load->model ( 'helpers/country_helper' );
		//$this->load->model ( 'Engagement_type' );
		//$this->load->model ( "Event_helper" );
		$this->load->model ( "organizations/organization" );
		$this->loggedUserId = $this->session->userdata ( 'user_id' );
	}
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : manage_titles
	 * @Params : none
	 * @Action : Calls 'Manage Titles UI'
	 */
	function manage_titles() {
		$data ['contentPage'] = 'master_data/manage_titles';
		$this->load->view ( 'layouts/analyst_view', $data );
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : list_titles()
	 * @Params : none
	 * @Action : Returns data related to 'titles' to jQgrid
	 */
	function list_titles() {
		$page = $_REQUEST ['page'];
		$limit = $_REQUEST ['rows'];
		$sidx = $_REQUEST ['sidx'];
		$sord = $_REQUEST ['sord'];
		if (! $sidx)
			$sidx = 1;
		$filterData = $_REQUEST ['filters'];
		$arrFilter = array ();
		$arrFilter = json_decode ( stripslashes ( $filterData ) );
		$field = 'field';
		$data = 'data';
		$searchString = $this->common_helpers->search_nested_arrays ( $arrFilter, $data );
		$searchField = $this->common_helpers->search_nested_arrays ( $arrFilter, $field );
		$whereResultArray = array ();
		foreach ( $searchField as $key => $val ) {
			$whereResultArray [$val] = $searchString [$key];
		}
		$count = $this->master_data_model->getTitles ( $limit, $start, true, $sidx, $sord, $whereResultArray );
		$total_pages = $count > 0 ? ceil ( $count / $limit ) : 0;
		if ($page > $total_pages)
			$page = $total_pages;
		$start = $limit * $page - $limit;
		if ($start < 0)
			$start = 0;
		$data = array ();
		$arrTitleResult = array ();
		if ($arrTitleResult = $this->master_data_model->getTitles ( $limit, $start, false, $sidx, $sord, $whereResultArray )) {
			$arrTitleDetail = array ();
			foreach ( $arrTitleResult->result_array () as $row ) {
				$row ['id'] = $row ['id'];
				$row ['title'] = $row ['title'];
				$row ['abbr'] = $row ['abbr'];
				$row ['client_id'] = $row ['client_id'];
				$row ['is_active'] = $row ['is_active'];
				$actions = '<div class="actionIcon editIcon"><a onclick="editTitle(' . $row ['id'] . ');" href="#" title="Edit">&nbsp;</a></div><div class="actionIcon deleteIcon"><a onclick="deleteTitle(' . $row ['id'] . ');" href="#" title="Delete">&nbsp;</a></div>';
				$row ['action'] = $actions;
				$arrTitleDetail [] = $row;
			}
			$data ['records'] = $count;
			$data ['total'] = $total_pages;
			$data ['page'] = $page;
			$data ['rows'] = $arrTitleDetail;
		}
		ob_start ( 'ob_gzhandler' );
		echo json_encode ( $data );
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : get_title_by_id()
	 * @Params : id => Titles Entity (By POST)
	 * @Action : Returns data related to 'titles' where id matches
	 */
	function get_title_by_id() {
		$id = $this->input->post ( 'id' );
		echo json_encode ( $this->master_data_model->getTitleDetailsById ( $id )->result_array () );
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : getClientIds()
	 * @Params : titleId => Titles Entity
	 * @Action : Returns only Client Ids (Comma Seperated)
	 */
	function getClientIds($titleId) {
		$arrResultSet = $this->master_data_model->getArrClientIds ( $titleId )->result_array ();
		return $arrResultSet [0] ['client_ids'];
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : getClientIdsToAJAX()
	 * @Params : titleId (By POST)
	 * @Action : Returns only Client Ids to AJAX Call (Comma Seperated)
	 */
	function getClientIdsToAJAX() {
		$titleId = $this->input->post ( 'titleId' );
		echo $this->getClientIds ( $titleId );
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : getClientDetails()
	 * @Params : id => Clients Entity (Optional By POST)
	 * @Action : Returns 'clients' details to AJAX Call (If 'id' matches : matched records, else : all records )
	 */
	function getClientDetails() {
		$id = $this->input->post ( 'id' );
		$resData = $this->master_data_model->getClientDetails ( $id );
		foreach ( $resData as $row ) {
			$clientRec ['id'] = $row ['id'];
			$clientRec ['name'] = $row ['name'];
			$arrClientRecs [] = $clientRec;
		}
		echo json_encode ( $arrClientRecs );
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : smartMergeTitle()
	 * @Params : id, title, abbrevation, status, clientIds (By POST)
	 * @Action : Insert / Update 'titles' and associate / deassociate clientIds
	 */
	function smartMergeTitle() {
		$id = $this->input->post ( 'id' );
		$title = $this->input->post ( 'title' );
		$abbrevation = $this->input->post ( 'abbrevation' );
		$status = $this->input->post ( 'status' );
		$clientIds = $this->input->post ( 'clientIds' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$data = array (
				'id' => $id,
				'title' => $title,
				'abbr' => $abbrevation,
				'is_active' => $status 
		);
		$respVal = $this->master_data_model->smartMergeTitle ( $data );
		if ($respVal) {
			$email = RECEIVER;
			$subject = "Notification about the creation of the new Title";
			$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Title was added by “' . $this->loggedUserId . '”
                            		
                            Title: ”' . $data ['title'] . '”
                            		
                            		
                           Regards,
                            		
                           Aissel Support Team';
			
			$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
		}
		// Add log activity
		$requestStatus = FAILURE;
		if ($respVal) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'add',
				'description' => 'Add New Title',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $respVal,
				'transaction_table_id' => TITLES,
				'transaction_name' => "New Title",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData,
				'parent_object_id' => $respVal 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		if ($respVal <= 0) {
			$respMsg = "Failed to Save";
		} else {
			$childStatus = $this->process_title_client_mappings ( $respVal, $clientIds );
			// Add log activity
			$requestStatus = FAILURE;
			if ($childStatus) {
				$requestStatus = SUCCESS;
			}
			$formData = $_POST;
			$formData = json_encode ( $formData );
			$arrLogDetails = array (
					'module' => 'Master Data',
					'type' => 'add',
					'description' => 'Adding associated clients to a particular title',
					'status' => $requestStatus,
					'file_name' => 'master_data_controller',
					'transaction_id' => $respVal,
					'transaction_table_id' => TITLE_CLIENT_MAPPING,
					'transaction_name' => "Add associated clients to title",
					'client_id' => $client_id,
					'user_id' => $userId,
					'form_data' => $formData,
					'parent_object_id' => $respVal 
			);
			$this->config->set_item ( 'log_details', $arrLogDetails );
			log_user_activity ( null, true );
			$respMsg = $childStatus ? "Saved Successfully" : "Failed to Process the Client Associations";
		}
		echo $respMsg;
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : process_title_client_mappings()
	 * @Params : titleID, clientIds
	 * @Action : associate / deassociate clientIds to titleId
	 */
	function process_title_client_mappings($titleId, $clientIds) {
		$arrDBClientIds = explode ( ",", $this->getClientIds ( $titleId ) );
		$arrOldClientIds = array_filter ( $arrDBClientIds, function ($value) {
			return $value !== '';
		} );
		$arrUIClientIds = explode ( ",", $clientIds );
		$arrNewClientIds = array_filter ( $arrUIClientIds, function ($value) {
			return $value !== '';
		} );
		$arrIntersect = array_intersect ( $arrOldClientIds, $arrNewClientIds );
		$toBeInserted = array_diff ( $arrNewClientIds, $arrIntersect );
		$toBeRemoved = array_diff ( $arrOldClientIds, $arrIntersect );
		$toBeProcessed = sizeof ( $toBeInserted ) + sizeof ( $toBeRemoved );
		$insertCount = 0;
		foreach ( $toBeInserted as $rec ) {
			$currTimeStamp = Date ( "Y-m-d H:i:s" );
			$data = array (
					'title_id' => $titleId,
					'client_id' => $rec,
					'created_by' => $this->session->userdata ( 'user_id' ),
					'created_on' => $currTimeStamp 
			);
			$insStatus = $this->master_data_model->saveTitleClientMappings ( $data );
			$insertCount += $insStatus ? 1 : 0;
		}
		$deleteCount = 0;
		foreach ( $toBeRemoved as $rec ) {
			$data = array (
					'title_id' => $titleId,
					'client_id' => $rec 
			);
			$remStatus = $this->master_data_model->deleteTitleClientMappings ( $data );
			$deleteCount += $remStatus ? 1 : 0;
		}
		$processed = $insertCount + $deleteCount;
		return $toBeProcessed == $processed ? true : false;
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : deleteTitle()
	 * @Params : id => Titles Entity (By POST)
	 * @Action : Deletes from 'titles' where id matches
	 */
	function deleteTitle() {
		$id = $this->input->post ( 'id' );
		$status = $this->master_data_model->deleteTitle ( $id );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'delete',
				'description' => 'deleting the title',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $id,
				'transaction_table_id' => TITLES,
				'transaction_name' => 'delete title',
				'client_id' => $client_id,
				'user_id' => $userId,
				'parent_object_id' => $id 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $status ? "Deleted Successfully" : "Failed to Delete";
	}
	
	// @Author: Kumaresha B
	function list_specialties() {
		$data ['contentPage'] = 'master_data/list_specialties';
		$this->load->view ( 'layouts/analyst_view', $data );
	}
	function load_grid_specialties() {
		ini_set ( 'memory_limit', '-1' );
		$page = $_REQUEST ['page'];
		$limit = $_REQUEST ['rows'];
		$sidx = $_REQUEST ['sidx'];
		$sord = $_REQUEST ['sord'];
		if (! $sidx)
			$sidx = 1;
		$filterData = $_REQUEST ['filters'];
		$arrFilter = array ();
		$arrFilter = json_decode ( stripslashes ( $filterData ) );
		$field = 'field';
		$data = 'data';
		$searchString = $this->common_helpers->search_nested_arrays ( $arrFilter, $data );
		$searchField = $this->common_helpers->search_nested_arrays ( $arrFilter, $field );
		$whereResultArray = array ();
		foreach ( $searchField as $key => $val ) {
			$whereResultArray [$val] = $searchString [$key];
		}
		$searchResults = array ();
		$arrSpecialties = $this->specialty->getAllSpecialties ();
		$count = sizeof ( $arrSpecialties );
		if ($count > 0) {
			$total_pages = ceil ( $count / $limit );
		} else {
			$total_pages = 0;
		}
		if ($page > $total_pages)
			$page = $total_pages;
		$start = $limit * $page - $limit;
		if ($start < 0)
			$start = 0;
		$arrSpecialtyData = $this->master_data_model->getSpecialtyDetails ( $limit, $start, $sidx, $sord );
		// pr($arrSpecialtyData);exit;
		foreach ( $arrSpecialtyData as $row ) {
			$arrSpecDetails [] = array (
					'id' => $row ['id'],
					'specialty' => $row ['specialty'],
					'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editSpecialties('" . $row ['id'] . "','" . addslashes ( $row ['specialty'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon'><a href='#' onclick=\"addSpecialtiesClients('" . $row ['id'] . "');\" title='Associate Clients'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedSpecialties('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
			);
		}
		$data = array ();
		$data ['records'] = $count;
		$data ['total'] = $total_pages;
		$data ['page'] = $page;
		$data ['rows'] = $arrSpecDetails;
		ob_start ( 'ob_gzhandler' );
		echo json_encode ( $data );
	}
	function edit_specialty() {
		$this->load->view ( 'master_data/add_specialty', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to add specialty',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => SPECIALTIES,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	function add_specialty_clients($specId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$arrSelected = $this->master_data_model->getSpecClients ( $specId );
		$data ['arrClients'] = $arrClients;
		$data ['arrSelected'] = $arrSelected;
		foreach ( $data ['arrSelected'] as $row ) {
			$arr [] = $row ["client_id"];
		}
		$data ['arrSelected'] = $arr;
		$this->load->view ( 'master_data/add_specialties_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to specialty',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => SPECIALTY_CLIENT_ASSOCIATION,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	function add_product_clients($proId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$arrSelected = $this->master_data_model->getProductClients ( $proId );
		// pr($arrSelected);exit;
		$data ['arrClients'] = $arrClients;
		$data ['arrSelected'] = $arrSelected;
		foreach ( $data ['arrSelected'] as $row ) {
			$arr [] = $row ["client_id"];
		}
		$data ['arrSelected'] = $arr;
		$this->load->view ( 'master_data/add_specialties_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to products',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PRODUCTS_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	function add_phonetype_clients($phoneId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$arrSelected = $this->master_data_model->getPhoneTypeClients ( $phoneId );
		// pr($arrSelected);exit;
		$data ['arrClients'] = $arrClients;
		$data ['arrSelected'] = $arrSelected;
		foreach ( $data ['arrSelected'] as $row ) {
			$arr [] = $row ["client_id"];
		}
		$data ['arrSelected'] = $arr;
		$this->load->view ( 'master_data/add_specialties_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to phone type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PHONE_TYPE_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	function add_emailtype_clients($emailId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$arrSelected = $this->master_data_model->getEmailTypeClients ( $emailId );
		// pr($arrSelected);exit;
		$data ['arrClients'] = $arrClients;
		$data ['arrSelected'] = $arrSelected;
		foreach ( $data ['arrSelected'] as $row ) {
			$arr [] = $row ["client_id"];
		}
		$data ['arrSelected'] = $arr;
		$this->load->view ( 'master_data/add_specialties_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to email type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => EMAILS_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	function add_discussiontype_clients($disId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$arrSelected = $this->master_data_model->getDiscussionTypeClients ( $disId );
		// pr($arrSelected);exit;
		$data ['arrClients'] = $arrClients;
		$data ['arrSelected'] = $arrSelected;
		foreach ( $data ['arrSelected'] as $row ) {
			$arr [] = $row ["client_id"];
		}
		$data ['arrSelected'] = $arr;
		$this->load->view ( 'master_data/add_specialties_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to discussion type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => INTERACTION_TYPES_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	function add_topics_clients($topicId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$arrSelected = $this->master_data_model->getTopicClients ( $topicId );
		// pr($arrSelected);exit;
		$data ['arrClients'] = $arrClients;
		$data ['arrSelected'] = $arrSelected;
		foreach ( $data ['arrSelected'] as $row ) {
			$arr [] = $row ["client_id"];
		}
		$data ['arrSelected'] = $arr;
		$this->load->view ( 'master_data/add_specialties_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to interactions topics',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => INTERACTIONS_TOPICS_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	function add_modes_clients($modeId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$arrSelected = $this->master_data_model->getModeClients ( $modeId );
		// pr($arrSelected);exit;
		$data ['arrClients'] = $arrClients;
		$data ['arrSelected'] = $arrSelected;
		foreach ( $data ['arrSelected'] as $row ) {
			$arr [] = $row ["client_id"];
		}
		$data ['arrSelected'] = $arr;
		$this->load->view ( 'master_data/add_specialties_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to interactions modes',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => INTERACTIONS_MODES_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	function add_locationtype_clients($locationTypeId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$arrSelected = $this->master_data_model->getLocationTypeClients ( $locationTypeId );
		// pr($arrSelected);exit;
		$data ['arrClients'] = $arrClients;
		$data ['arrSelected'] = $arrSelected;
		foreach ( $data ['arrSelected'] as $row ) {
			$arr [] = $row ["client_id"];
		}
		$data ['arrSelected'] = $arr;
		$this->load->view ( 'master_data/add_specialties_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to interaction location type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => INTERACTION_LOCATION_TYPES_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	function add_requestedby_clients($requestedById) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$arrSelected = $this->master_data_model->getRequestedByClients ( $requestedById );
		// pr($arrSelected);exit;
		$data ['arrClients'] = $arrClients;
		$data ['arrSelected'] = $arrSelected;
		foreach ( $data ['arrSelected'] as $row ) {
			$arr [] = $row ["client_id"];
		}
		$data ['arrSelected'] = $arr;
		$this->load->view ( 'master_data/add_specialties_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to payments requested by',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PAYMENTS_REQUESTED_BY_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	function add_paidby_clients($paidById) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$arrSelected = $this->master_data_model->getPaidByClients ( $paidById );
		// pr($arrSelected);exit;
		$data ['arrClients'] = $arrClients;
		$data ['arrSelected'] = $arrSelected;
		foreach ( $data ['arrSelected'] as $row ) {
			$arr [] = $row ["client_id"];
		}
		$data ['arrSelected'] = $arr;
		$this->load->view ( 'master_data/add_specialties_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to payments paid by',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PAYMENTS_PAID_BY_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	function add_paymenttype_clients($paymentTypeId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$arrSelected = $this->master_data_model->getPaymentTypeClients ( $paymentTypeId );
		// pr($arrSelected);exit;
		$data ['arrClients'] = $arrClients;
		$data ['arrSelected'] = $arrSelected;
		foreach ( $data ['arrSelected'] as $row ) {
			$arr [] = $row ["client_id"];
		}
		$data ['arrSelected'] = $arr;
		$this->load->view ( 'master_data/add_specialties_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to payment type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PAYMENT_TYPES_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	function add_paymentcurrency_clients($paymentCurId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$arrSelected = $this->master_data_model->getPaymentCurrencyClients ( $paymentCurId );
		// pr($arrSelected);exit;
		$data ['arrClients'] = $arrClients;
		$data ['arrSelected'] = $arrSelected;
		foreach ( $data ['arrSelected'] as $row ) {
			$arr [] = $row ["client_id"];
		}
		$data ['arrSelected'] = $arr;
		$this->load->view ( 'master_data/add_specialties_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to payment currency',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PAYMENTS_CURRENCY_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	function save_client_specialty($table) {
		$specialty = $this->input->post ( 'specialty' );
		$client_ids = $this->input->post ( 'id' );
		$client_idp = explode ( ",", $client_ids );
		$this->master_data_model->deleteClientSpecialty ( $specialty, $table );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		switch ($table) {
			case 'specialty_client_association' :
				$i = 0;
				$successCount = 0;
				while ( $client_idp [$i] != null ) {
					$data = array (
							'specialty_id' => $specialty,
							'client_id' => $client_idp [$i ++] 
					);
					$status = $this->master_data_model->saveClientSpecialty ($table ,$data);
					if ($status) {
						$successCount ++;
					}
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding associated clients to a particular specialty',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $specialty,
						'transaction_table_id' => SPECIALTY_CLIENT_ASSOCIATION,
						'transaction_name' => "Add associated clients to specialty",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $specialty 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				break;
			case 'products_client_visibility' :
				$i = 0;
				$successCount = 0;
				while ( $client_idp [$i] != null ) {
					$data = array (
							'products_id' => $specialty,
							'client_id' => $client_idp [$i ++] 
					);
					$status = $this->master_data_model->saveClientSpecialty ($table ,$data);
					if ($status) {
						$successCount ++;
					}
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding associated clients to a particular product',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $specialty,
						'transaction_table_id' => PRODUCTS_CLIENT_VISIBILITY,
						'transaction_name' => "Add associated clients to product",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $specialty 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				break;
			case 'phone_type_client_visibility' :
				$i = 0;
				$successCount = 0;
				while ( $client_idp [$i] != null ) {
					$data = array (
							'phone_type_id' => $specialty,
							'client_id' => $client_idp [$i ++] 
					);
					$status = $this->master_data_model->saveClientSpecialty ($table ,$data);
					if ($status) {
						$successCount ++;
					}
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding associated clients to a particular phone type',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $specialty,
						'transaction_table_id' => PHONE_TYPE_CLIENT_VISIBILITY,
						'transaction_name' => "Add associated clients to phone type",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $specialty 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				break;
			case 'emails_client_visibility' :
				$i = 0;
				$successCount = 0;
				while ( $client_idp [$i] != null ) {
					$data = array (
							'emails_id' => $specialty,
							'client_id' => $client_idp [$i ++] 
					);
					$status = $this->master_data_model->saveClientSpecialty ($table ,$data);
					if ($status) {
						$successCount ++;
					}
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding associated clients to a particular email type',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $specialty,
						'transaction_table_id' => EMAILS_CLIENT_VISIBILITY,
						'transaction_name' => "Add associated clients to email type",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $specialty 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				break;
			case 'interaction_types_client_visibility' :
				$i = 0;
				$successCount = 0;
				while ( $client_idp [$i] != null ) {
					$data = array (
							'interaction_types_id' => $specialty,
							'client_id' => $client_idp [$i ++] 
					);
					$status = $this->master_data_model->saveClientSpecialty ($table ,$data);
					if ($status) {
						$successCount ++;
					}
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding associated clients to a particular interaction type',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $specialty,
						'transaction_table_id' => INTERACTION_TYPES_CLIENT_VISIBILITY,
						'transaction_name' => "Add associated clients to interaction type",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $specialty 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				break;
			case 'interactions_topics_client_visibility' :
				$i = 0;
				$successCount = 0;
				while ( $client_idp [$i] != null ) {
					$data = array (
							'interactions_topics_id' => $specialty,
							'client_id' => $client_idp [$i ++] 
					);
					$status = $this->master_data_model->saveClientSpecialty ($table ,$data);
					if ($status) {
						$successCount ++;
					}
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding associated clients to a particular interaction topics',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $specialty,
						'transaction_table_id' => INTERACTIONS_TOPICS_CLIENT_VISIBILITY,
						'transaction_name' => "Add associated clients to interaction topics",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $specialty 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				break;
			case 'interactions_modes_client_visibility' :
				$i = 0;
				$successCount = 0;
				while ( $client_idp [$i] != null ) {
					$data = array (
							'interactions_modes_id' => $specialty,
							'client_id' => $client_idp [$i ++] 
					);
					$status = $this->master_data_model->saveClientSpecialty ($table ,$data);
					if ($status) {
						$successCount ++;
					}
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding associated clients to a particular interactions modes',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $specialty,
						'transaction_table_id' => INTERACTIONS_MODES_CLIENT_VISIBILITY,
						'transaction_name' => "Add associated clients to interactions modes",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $specialty 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				break;
			case 'interaction_location_types_client_visibility' :
				$i = 0;
				$successCount = 0;
				while ( $client_idp [$i] != null ) {
					$data = array (
							'interaction_location_types_id' => $specialty,
							'client_id' => $client_idp [$i ++] 
					);
					$status = $this->master_data_model->saveClientSpecialty ($table ,$data);
					if ($status) {
						$successCount ++;
					}
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding associated clients to a particular interaction location types',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $specialty,
						'transaction_table_id' => INTERACTION_LOCATION_TYPES_CLIENT_VISIBILITY,
						'transaction_name' => "Add associated clients to interaction location types",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $specialty 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				break;
			case 'payments_requested_by_client_visibility' :
				$i = 0;
				$successCount = 0;
				while ( $client_idp [$i] != null ) {
					$data = array (
							'requested_by_id' => $specialty,
							'client_id' => $client_idp [$i ++] 
					);
					$status = $this->master_data_model->saveClientSpecialty ($table ,$data);
					if ($status) {
						$successCount ++;
					}
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding associated clients to a particular payments requested by',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $specialty,
						'transaction_table_id' => PAYMENTS_REQUESTED_BY_CLIENT_VISIBILITY,
						'transaction_name' => "Add associated clients to payments requested by",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $specialty 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				break;
			case 'payments_paid_by_client_visibility' :
				$i = 0;
				$successCount = 0;
				while ( $client_idp [$i] != null ) {
					$data = array (
							'paid_by_id' => $specialty,
							'client_id' => $client_idp [$i ++] 
					);
					$status = $this->master_data_model->saveClientSpecialty ($table ,$data);
					if ($status) {
						$successCount ++;
					}
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding associated clients to a particular payments paid by',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $specialty,
						'transaction_table_id' => PAYMENTS_PAID_BY_CLIENT_VISIBILITY,
						'transaction_name' => "Add associated clients to payments paid by",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $specialty 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				break;
			case 'payment_types_client_visibility' :
				$i = 0;
				$successCount = 0;
				while ( $client_idp [$i] != null ) {
					$data = array (
							'payment_type' => $specialty,
							'client_id' => $client_idp [$i ++] 
					);
					$status = $this->master_data_model->saveClientSpecialty ($table ,$data);
					if ($status) {
						$successCount ++;
					}
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding associated clients to a particular payment types',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $specialty,
						'transaction_table_id' => PAYMENT_TYPES_CLIENT_VISIBILITY,
						'transaction_name' => "Add associated clients to payment types",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $specialty 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				break;
			case 'payments_currency_client_visibility' :
				$i = 0;
				$successCount = 0;
				while ( $client_idp [$i] != null ) {
					$data = array (
							'currency_name' => $specialty,
							'client_id' => $client_idp [$i ++] 
					);
					$status = $this->master_data_model->saveClientSpecialty ($table ,$data);
					if ($status) {
						$successCount ++;
					}
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding associated clients to a particular payments currency',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $specialty,
						'transaction_table_id' => PAYMENTS_CURRENCY_CLIENT_VISIBILITY,
						'transaction_name' => "Add associated clients to payments currency",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $specialty 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				break;
		}
		echo $i == $successCount ? "Saved Successfully" : "Saving Failed";
	}
	
	/**
	 *
	 * @author : Soumya R S
	 *         @Created on 27-07-2017
	 *        
	 */
	
	// to load the view page with country,State and city jqgrids
	function list_region() {
		$data ['arrCountries'] = $this->country_helper->listCountries ();
		$data ['contentPage'] = 'master_data/list_regions';
		$data ['showNavBar'] = false;
		$this->load->view ( ANALYST_HEADER, $data );
	}
	
	// loads contents to the jqgrid of country listing
	function country_jqgrid() {
		$field = 'field';
		$data = 'data';
		$responce = array ();
		$page = isset ( $_POST ['page'] ) ? $_POST ['page'] : 1;
		$limit = isset ( $_POST ['rows'] ) ? $_POST ['rows'] : 10; // get how many rows we want to have into the grid
		$sidx = isset ( $_POST ['sidx'] ) ? $_POST ['sidx'] : 'name'; // get index row - i.e. user click to sort
		$sord = isset ( $_POST ['sord'] ) ? $_POST ['sord'] : ''; // get the direction
		$filterData = isset ( $_POST ['filters'] ) ? $_POST ['filters'] : '';
		$arrFilter = array ();
		$arrFilter = json_decode ( stripslashes ( $filterData ) );
		$start = $limit * $page - $limit;
		$start = ($start < 0) ? 0 : $start;
		$searchString = $this->common_helpers->search_nested_arrays ( $arrFilter, $data );
		$searchField = $this->common_helpers->search_nested_arrays ( $arrFilter, $field );
		$whereResultArray = array ();
		foreach ( $searchField as $key => $val ) {
			$whereResultArray [$val] = $searchString [$key];
		}
		if (! $sidx)
			$sidx = 1;
		$count = $this->master_data_model->getCountriesList ( $start, $limit, $sidx, $sord, $whereResultArray, true );
		$total_count = $count;
		if ($total_count > 0) {
			$total_pages = ceil ( $total_count / $limit );
		} else {
			$total_pages = 0;
		}
		if ($page > $total_pages)
			$page = $total_pages;
		$query = $this->master_data_model->getCountriesList ( $start, $limit, $sidx, $sord, $whereResultArray );
		$responce ['page'] = $page;
		$responce ['total'] = $total_pages;
		$responce ['records'] = $count;
		$responce ['rows'] = array ();
		$i = 0;
		foreach ( $query as $row ) {
			$row->action = '<div class="actionIcon editIcon"><a onclick="openCountryForm(' . $row->CountryId . ')"  title="Edit">&nbsp;</a></div><div class="actionIcon deleteIcon" style="float:left"><a onclick="deleteCountry(' . $row->CountryId . ')"  title="delete">&nbsp;</a></div>';
			$responce ['rows'] [$i] ['id'] = $row->CountryId;
			$responce ['rows'] [$i] ['cell'] = array (
					$row->CountryId,
					$row->Country,
					$row->Capital,
					$row->NationalitySingular,
					$row->NationalityPlural,
					$row->Currency,
					$row->action 
			);
			$i ++;
		}
		echo json_encode ( $responce );
	}
	
// loads contents to the jqgrid of State listing
    function states_jqgrid($q, $id) {
        $field = 'field';
        $data = 'data';
        $responce = array ();
        $examp = $q; // query number
        $page = isset ( $_POST ['page'] ) ? $_POST ['page'] : 1;
        $limit = isset ( $_POST ['rows'] ) ? $_POST ['rows'] : 10; // get how many rows we want to have into the grid
        $sidx = isset ( $_POST ['sidx'] ) ? $_POST ['sidx'] : 'name'; // get index row - i.e. user click to sort
        $sord = isset ( $_POST ['sord'] ) ? $_POST ['sord'] : ''; // get the direction
        $filterData = isset ( $_POST ['filters'] ) ? $_POST ['filters'] : '';
        $arrFilter = array ();
        $arrFilter = json_decode ( stripslashes ( $filterData ) );
        $searchString = $this->common_helpers->search_nested_arrays ( $arrFilter, $data );
        $searchField = $this->common_helpers->search_nested_arrays ( $arrFilter, $field );
        $whereResultArray = array ();
        foreach ( $searchField as $key => $val ) {
            $whereResultArray [$val] = $searchString [$key];
        }
        if (! $sidx)
            $sidx = 1;
        if ($examp == 1) {
            $count = $this->master_data_model->getStatesList ( $start, $limit, $sidx, $sord, $id, $whereResultArray, true );            
            if ($count > 0) {
                $total_pages = ceil ( $count / $limit );
            } else {
                $total_pages = 0;
            }
            if ($page > $total_pages)
                $page = $total_pages;
            $start = $limit * $page - $limit; // do not put $limit*($page - 1)
            if ($start < 0)
                $start = 0;
            $query = $this->master_data_model->getStatesList ( $start, $limit, $sidx, $sord, $id, $whereResultArray );
            $responce ['page'] = $page;
            $responce ['total'] = $total_pages;
            $responce ['records'] = $count;
            $responce ['rows'] = array ();
            $i = 0;
            foreach ( $query as $row ) {
                $row->action = '<div class="actionIcon editIcon"><a onclick="openStateForm(' . $row->RegionID . ')"  title="Edit">&nbsp;</a></div><div class="actionIcon deleteIcon" style="float:left"><a onclick="deleteSstate(' . $row->RegionID . ')"  title="delete">&nbsp;</a></div>';
                $responce ['rows'] [$i] ['id'] = $row->RegionID;
                $responce ['rows'] [$i] ['cell'] = array (
                        $row->RegionID,
                        $row->Region,
                        $row->Code,
                        $row->action 
                );
                $i ++;
            }
        }
        echo json_encode ( $responce );
    }
	
	// loads contents to the jqgrid of City
	function cities_jqgrid($q, $id) {
		$field = 'field';
		$data = 'data';
		$responce = array ();
		$examp = $q; // query number
		$page = isset ( $_POST ['page'] ) ? $_POST ['page'] : 1;
		$limit = isset ( $_POST ['rows'] ) ? $_POST ['rows'] : 10; // get how many rows we want to have into the grid
		$sidx = isset ( $_POST ['sidx'] ) ? $_POST ['sidx'] : 'name'; // get index row - i.e. user click to sort
		$sord = isset ( $_POST ['sord'] ) ? $_POST ['sord'] : ''; // get the direction
		$filterData = isset ( $_POST ['filters'] ) ? $_POST ['filters'] : '';
		$arrFilter = array ();
		$arrFilter = json_decode ( stripslashes ( $filterData ) );
		$searchString = $this->common_helpers->search_nested_arrays ( $arrFilter, $data );
		$searchField = $this->common_helpers->search_nested_arrays ( $arrFilter, $field );
		$whereResultArray = array ();
		foreach ( $searchField as $key => $val ) {
			$whereResultArray [$val] = $searchString [$key];
		}
		if (! $sidx) {
			$sidx = 1;
		}
		if ($examp == 1) {
			$count = $this->master_data_model->getCitiesList ( $start, $limit, $sidx, $sord, $id, $whereResultArray, true );
			if ($count > 0) {
				$total_pages = ceil ( $count / $limit );
			} else {
				$total_pages = 0;
			}
			if ($page > $total_pages)
				$page = $total_pages;
			$start = $limit * $page - $limit; // do not put $limit*($page - 1)
			if ($start < 0)
				$start = 0;
			$query = $this->master_data_model->getCitiesList ( $start, $limit, $sidx, $sord, $id, $whereResultArray );
			$responce ['page'] = $page;
			$responce ['total'] = $total_pages;
			$responce ['records'] = $count;
			$responce ['rows'] = array ();
			$i = 0;
			foreach ( $query as $row ) {
				$row->action = '<div class="actionIcon editIcon"><a onclick="openCityForm(' . $row->CityId . ')"  title="Edit">&nbsp;</a></div><div class="actionIcon deleteIcon" style="float:left"><a onclick="deleteCity(' . $row->CityId . ')"  title="delete">&nbsp;</a></div>';
				$responce ['rows'] [$i] ['id'] = $row->CityId;
				$responce ['rows'] [$i] ['cell'] = array (
						$row->CityId,
						$row->City,
						$row->Latitude,
						$row->Longitude,
						$row->TimeZone,
						$row->Code,
						$row->action 
				);
				$i ++;
			}
		}
		echo json_encode ( $responce );
	}
	
	// Loads add_country view page (with details of selected country,if it is edit operation)
	function get_country_by_countryid($id = null) {
		$table = 'countries';
		$column_name = 'CountryId';
		$data ['Countrydetails'] = $this->master_data_model->getDetailsById ( $table, $column_name, $id );
		$data ['arrCountry'] = $this->country_helper->listCountries ();
		$this->load->view ( 'master_data/add_country', $data );
	}
	
	// Loads add_state view page (with details of selected state,if it is edit operation)
	function get_state_by_stateid($id = null) {
		$table = 'regions';
		$column_name = 'RegionID';
		$data ['Statedetails'] = $this->master_data_model->getDetailsById ( $table, $column_name, $id );
		$data ['arrCountry'] = $this->country_helper->listCountries ();
		$this->load->view ( 'master_data/add_state', $data );
	}
	
	// Loads add_city view page(with details of selected city,if it is edit operation)
	function get_city_by_cityid($id = null) {
		$table = 'cities';
		$column_name = 'CityId';
		$data ['Citydetails'] = $this->master_data_model->getDetailsById ( $table, $column_name, $id );
		$arrcitydetails = array ();
		foreach ( $data ['Citydetails'] as $key => $value )
			$arrcitydetails [$key] = $value;
		$data ['arrStates'] = $this->country_helper->getStatesByCountryId ( $arrcitydetails ['CountryID'] );
		$data ['arrCountry'] = $this->country_helper->listCountries ();
		$this->load->view ( 'master_data/add_city', $data );
	}
	
	// for adding/updating coutry details.
	function save_country() {
		$arrCountry ['CountryId'] = $this->input->post ( 'CountryId' );
		$arrCountry ['Country'] = $this->input->post ( 'Country' );
		$arrCountry ['Capital'] = $this->input->post ( 'Capital' );
		$arrCountry ['GlobalRegion'] = $this->input->post ( 'GlobalRegion' );
		$arrCountry ['NationalitySingular'] = $this->input->post ( 'NationalitySingular' );
		$arrCountry ['NationalityPlural'] = $this->input->post ( 'NationalityPlural' );
		$arrCountry ['Currency'] = $this->input->post ( 'Currency' );
		$arrCountry ['CurrencyCode'] = $this->input->post ( 'CurrencyCode' );
		$arrCountry ['Population'] = $this->input->post ( 'Population' );
		$table = 'countries';
		$column_name = 'CountryId';
		$column_value = $arrCountry ['CountryId'];
		if ($arrCountry ['CountryId'] > 0) {
			$data ['saved'] = $this->master_data_model->update ( $table, $column_name, $column_value, $arrCountry );
			$data ['msg'] = $data ['saved'] ? "Updated Successfully" : "Sorry! Update unsuccessfull";
		} else {
			$data ['saved'] = $this->master_data_model->checkCountryIfExistElseAdd ( $arrCountry );
			$data ['msg'] = $data ['saved'] ? "Inserted Successfully" : "Sorry! Data is Already Present in Database";
		}
		echo json_encode ( $data );
	}
	
	// updates state details into db after editing.
	function save_state() {
		$arrCountry ['RegionID'] = $this->input->post ( 'RegionID' );
		$arrCountry ['CountryID'] = $this->input->post ( 'CountryID' );
		$arrCountry ['Region'] = $this->input->post ( 'Region' );
		$arrCountry ['Code'] = $this->input->post ( 'Code' );
		$table = 'regions';
		$column_name = 'RegionID';
		$column_value = $arrCountry ['RegionID'];
		if ($arrCountry ['RegionID'] > 0) {
			$data ['saved'] = $this->master_data_model->update ( $table, $column_name, $column_value, $arrCountry );
			$data ['msg'] = $data ['saved'] ? "Updated Successfully" : "Sorry! Update unsuccessfull";
		} else {
			$data ['saved'] = $this->master_data_model->checkStateIfExistElseAdd ( $arrCountry ['Region'], $arrCountry ['CountryID'], $arrCountry ['Code'] );
			$data ['msg'] = $data ['saved'] ? "Inserted Successfully" : "Sorry! Data is Already Present in Database";
		}
		echo json_encode ( $data );
	}
	
	// updates city details into db after editing.
	function save_city() {
		$arrCountry ['CityId'] = $this->input->post ( 'CityId' );
		$arrCountry ['City'] = $this->input->post ( 'City' );
		$arrCountry ['CountryID'] = $this->input->post ( 'CountryID' );
		$arrCountry ['RegionID'] = $this->input->post ( 'state_id' );
		$arrCountry ['Latitude'] = $this->input->post ( 'Latitude' );
		$arrCountry ['Longitude'] = $this->input->post ( 'Longitude' );
		$arrCountry ['TimeZone'] = $this->input->post ( 'TimeZone' );
		$arrCountry ['Code'] = $this->input->post ( 'Code' );
		$table = 'cities';
		$column_name = 'CityId';
		$column_value = $arrCountry ['CityId'];
		if ($arrCountry ['CityId'] > 0) {
			$data ['saved'] = $this->master_data_model->update ( $table, $column_name, $column_value, $arrCountry );
			$data ['msg'] = $data ['saved'] ? "Updated Successfully" : "Sorry! Update unsuccessfull";
		} else {
			$data ['saved'] = $this->master_data_model->addCity ( $arrCountry );
			$data ['msg'] = $data ['saved'] ? "Inserted Successfully" : "Sorry! Data is Already Present in Database";
		}
		echo json_encode ( $data );
	}
	
	// deletes a selected country by its countryId
	function delete_country_by_countryid($id) {
		$arraydetails ['column_name'] = 'CountryId';
		$arraydetails ['column_value'] = $id;
		$arraydetails ['table_name'] = 'countries';
		$data ['status'] = $this->master_data_model->delete ( $arraydetails ) ? 1 : 0;
		echo json_encode ( $data );
	}
	
	// deletes a selected state by its regionId
	function delete_state_by_stateid($id) {
		$arraydetails ['column_name'] = 'RegionID';
		$arraydetails ['column_value'] = $id;
		$arraydetails ['table_name'] = 'regions';
		$data ['status'] = $this->master_data_model->delete ( $arraydetails ) ? 1 : 0;
		echo json_encode ( $data );
	}
	
	// deletes a selected city by its cityId
	function delete_city_by_cityid($id) {
		$arraydetails ['column_name'] = 'CityId';
		$arraydetails ['column_value'] = $id;
		$arraydetails ['table_name'] = 'cities';
		$data ['status'] = $this->master_data_model->delete ( $arraydetails ) ? 1 : 0;
		echo json_encode ( $data );
	}
	// @Author: Kumaresh B
	function list_organization_types() {
		$data ['contentPage'] = 'master_data/list_organization_tyes';
		$this->load->view ( 'layouts/analyst_view', $data );
	}
	// loads the content to jqGrid of Organization_Type
	function load_grid_orgtypes() {
		ini_set ( 'memory_limit', '-1' );
		$page = $_REQUEST ['page']; // get the requested page
		$limit = $_REQUEST ['rows']; // get how many rows we want
		$sidx = $_REQUEST ['sidx']; // get index row - i.e. user click to sort
		$sord = $_REQUEST ['sord']; // get the direction
		if (! $sidx)
			$sidx = 1;
		$filterData = $_REQUEST ['filters'];
		$arrFilter = array ();
		$arrFilter = json_decode ( stripslashes ( $filterData ) );
		$field = 'field';
		$op = 'op';
		$data = 'data';
		$groupOp = 'groupOp';
		$searchString = $this->common_helpers->search_nested_arrays ( $arrFilter, $data );
		$searchField = $this->common_helpers->search_nested_arrays ( $arrFilter, $field );
		$whereResultArray = array ();
		foreach ( $searchField as $key => $val ) {
			$whereResultArray [$val] = $searchString [$key];
		}
		$searchGroupOperator = $searchGroupOperator [0];
		$searchResults = array ();
		
		$arrOrg = $this->master_data_model->getAllOrganizationTypes ();
		// pr($arrOrg);
		// exit;
		$count = sizeof ( $arrOrg );
		// pr($count);
		// exit;
		if ($count > 0) {
			$total_pages = ceil ( $count / $limit );
		} else {
			$total_pages = 0;
		}
		// pr($total_pages);
		// exit;
		if ($page > $total_pages)
			$page = $total_pages;
		$start = $limit * $page - $limit; // do not put $limit*($page - 1)
		                                  // pr($page);
		                                  // exit;
		if ($start < 0)
			$start = 0;
		// pr($start);
		// exit;
		$arrOrgTypes = $this->master_data_model->getAllOrganizationTypes ( $limit, $start, $sidx, $sord );
		foreach ( $arrOrgTypes as $row ) {
			$arrOrgTypesDetails [] = array (
					'id' => $row ['id'],
					'type' => $row ['type'],
					'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editOrgTypes('" . $row ['id'] . "','" . addslashes ( $row ['type'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedOrgTypes('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
			);
		}
		
		$data = array ();
		$data ['records'] = $count;
		$data ['total'] = $total_pages;
		$data ['page'] = $page;
		$data ['rows'] = $arrOrgTypesDetails;
		ob_start ( 'ob_gzhandler' );
		echo json_encode ( $data );
	}
	// loads the contents to the jqGrid of Engagement Types
	function load_grid_engtypes() {
		ini_set ( 'memory_limit', '-1' );
		$page = $_REQUEST ['page']; // get the requested page
		$limit = $_REQUEST ['rows']; // get how many rows we want
		$sidx = $_REQUEST ['sidx']; // get index row - i.e. user click to sort
		$sord = $_REQUEST ['sord']; // get the direction
		if (! $sidx)
			$sidx = 1;
		$filterData = $_REQUEST ['filters'];
		$arrFilter = array ();
		$arrFilter = json_decode ( stripslashes ( $filterData ) );
		$field = 'field';
		$op = 'op';
		$data = 'data';
		$groupOp = 'groupOp';
		$searchString = $this->common_helpers->search_nested_arrays ( $arrFilter, $data );
		$searchField = $this->common_helpers->search_nested_arrays ( $arrFilter, $field );
		$whereResultArray = array ();
		foreach ( $searchField as $key => $val ) {
			$whereResultArray [$val] = $searchString [$key];
		}
		$searchGroupOperator = $searchGroupOperator [0];
		$searchResults = array ();
		
		$arrEngagementTypes = $this->master_data_model->getAllEngagementTypes ();
		// pr($arrEngagementTypes);
		// exit;
		$count = sizeof ( $arrEngagementTypes );
		// pr($count);
		// exit;
		if ($count > 0) {
			$total_pages = ceil ( $count / $limit );
		} else {
			$total_pages = 0;
		}
		// pr($total_pages);
		// exit;
		if ($page > $total_pages)
			$page = $total_pages;
		$start = $limit * $page - $limit; // do not put $limit*($page - 1)
		                                  // pr($page);
		                                  // exit;
		if ($start < 0)
			$start = 0;
		// pr($start);
		// exit;
		$arrEngTypes = $this->master_data_model->getAllEngagementTypes ( $limit, $start, $sidx, $sord );
		foreach ( $arrEngTypes as $row ) {
			$arrEngTypesDetails [] = array (
					'id' => $row ['id'],
					'engagement_type' => $row ['engagement_type'],
					'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editEngType('" . $row ['id'] . "','" . addslashes ( $row ['engagement_type'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedEngType('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
			);
		}
		
		$data = array ();
		$data ['records'] = $count;
		$data ['total'] = $total_pages;
		$data ['page'] = $page;
		$data ['rows'] = $arrEngTypesDetails;
		ob_start ( 'ob_gzhandler' );
		echo json_encode ( $data );
	}
	function edit_organization_type() {
		$this->load->view ( 'master_data/add_organization_type', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to add organization type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => ORGANIZATION_TYPES,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	function list_engagement_types() {
		$data ['contentPage'] = 'master_data/list_engagement_types';
		$this->load->view ( 'layouts/analyst_view', $data );
	}
	function edit_engagement_type() {
		$this->load->view ( 'master_data/add_engagement_type', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to add engagement type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => ENGAGEMENT_TYPES,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// opens the merge specialty modal box
	function merge_specialty_modal_box($specialtyId) {
		$arrSpecialties = $this->master_data_model->getSpecialtyDetails ();
		$data ['arrSpecialties'] = $arrSpecialties;
		$data ['arrSpec'] = $specialtyId;
		$this->load->view ( 'master_data/merge_specialty', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to merge specialty',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => SPECIALTIES,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// merge specialties
	function merge_specialty() {
		$old_specialty_id = $this->input->post ( 'specialty' );
		$new_specialty_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrData = array ();
		$old_specialty_ids = explode ( ',', $old_specialty_id );
		foreach ( $old_specialty_ids as $key => $row ) {
			$arrData ["specialty_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMerging ( $data );
		$status = $this->master_data_model->mergeSpecialty ( $data, $new_specialty_id );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'Merge',
				'description' => 'duplicate specialties were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_specialty_id,
				'transaction_table_id' => SPECIALTIES,
				'transaction_name' => "meging specialties",
				'miscellaneous1' => "The specialty ids " . $old_specialty_id . " replaced with  " . $new_specialty_id . " in the tables specified in miscellaneous2",
				'miscellaneous2' => " kols, specialty_client_association,kol_sub_specialty,organizations,interactions_other_attendees,interactions_attendees,event_topics,coachings,additional_contacts ",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	function add_miltiple_specialty_clients($arrSpecId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$data ['arrClients'] = $arrClients;
		if ($arrSpecId == null) {
			echo "Select Atleast One Specialty";
			exit ();
		} else {
			$data ['arrSpecId'] = $arrSpecId;
		}
		$this->load->view ( 'master_data/add_multiple_specialty_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to specialty',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => SPECIALTY_CLIENT_ASSOCIATION,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
	}
	function add_miltiple_product_clients($arrSpecId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$data ['arrClients'] = $arrClients;
		if ($arrSpecId == null) {
			echo "Select Atleast One Product";
			exit ();
		} else {
			$data ['arrSpecId'] = $arrSpecId;
		}
		$this->load->view ( 'master_data/add_multiple_product_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to products',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PRODUCTS_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
	}
	function add_miltiple_email_clients($arrSpecId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$data ['arrClients'] = $arrClients;
		if ($arrSpecId == null) {
			echo "Select Atleast One Email Type";
			exit ();
		} else {
			$data ['arrSpecId'] = $arrSpecId;
		}
		$this->load->view ( 'master_data/add_multiple_email_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to email type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => EMAILS_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
	}
	function add_miltiple_phone_clients($arrSpecId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$data ['arrClients'] = $arrClients;
		if ($arrSpecId == null) {
			echo "Select Atleast One Phone Type";
			exit ();
		} else {
			$data ['arrSpecId'] = $arrSpecId;
		}
		$this->load->view ( 'master_data/add_multiple_phone_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to phone type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PHONE_TYPE_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
	}
	function add_miltiple_discussion_clients($arrSpecId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$data ['arrClients'] = $arrClients;
		if ($arrSpecId == null) {
			echo "Select Atleast One Interaction Types";
			exit ();
		} else {
			$data ['arrSpecId'] = $arrSpecId;
		}
		$this->load->view ( 'master_data/add_multiple_inttype_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to discussion type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => INTERACTION_TYPES_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
	}
	function add_miltiple_topic_clients($arrSpecId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$data ['arrClients'] = $arrClients;
		if ($arrSpecId == null) {
			echo "Select Atleast One Interaction Topics";
			exit ();
		} else {
			$data ['arrSpecId'] = $arrSpecId;
		}
		$this->load->view ( 'master_data/add_multiple_inttopic_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to interactions topics',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => INTERACTIONS_TOPICS_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
	}
	function add_miltiple_mode_clients($arrSpecId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$data ['arrClients'] = $arrClients;
		if ($arrSpecId == null) {
			echo "Select Atleast One Interaction Modes";
			exit ();
		} else {
			$data ['arrSpecId'] = $arrSpecId;
		}
		$this->load->view ( 'master_data/add_multiple_modes_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to interactions modes',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => INTERACTIONS_MODES_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
	}
	function add_miltiple_location_clients($arrSpecId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$data ['arrClients'] = $arrClients;
		if ($arrSpecId == null) {
			echo "Select Atleast One Interaction Location";
			exit ();
		} else {
			$data ['arrSpecId'] = $arrSpecId;
		}
		$this->load->view ( 'master_data/add_multiple_locations_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to interaction location type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => INTERACTION_LOCATION_TYPES_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
	}
	function add_miltiple_requestedby_clients($arrSpecId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$data ['arrClients'] = $arrClients;
		if ($arrSpecId == null) {
			echo "Select Atleast One Payment Requested By";
			exit ();
		} else {
			$data ['arrSpecId'] = $arrSpecId;
		}
		$this->load->view ( 'master_data/add_multiple_requested_by_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to payments requested by',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PAYMENTS_REQUESTED_BY_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
	}
	function add_miltiple_paidby_clients($arrSpecId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$data ['arrClients'] = $arrClients;
		if ($arrSpecId == null) {
			echo "Select Atleast One Payment Paid By";
			exit ();
		} else {
			$data ['arrSpecId'] = $arrSpecId;
		}
		$this->load->view ( 'master_data/add_multiple_paid_by_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to payments paid by',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PAYMENTS_PAID_BY_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
	}
	function add_miltiple_type_clients($arrSpecId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$data ['arrClients'] = $arrClients;
		if ($arrSpecId == null) {
			echo "Select Atleast One Payment Type";
			exit ();
		} else {
			$data ['arrSpecId'] = $arrSpecId;
		}
		$this->load->view ( 'master_data/add_multiple_payment_type_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to payment type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PAYMENT_TYPES_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
	}
	function add_miltiple_currency_clients($arrSpecId) {
		$arrClients = $this->master_data_model->getClientDetails ();
		$data ['arrClients'] = $arrClients;
		if ($arrSpecId == null) {
			echo "Select Atleast One Payment Currency";
			exit ();
		} else {
			$data ['arrSpecId'] = $arrSpecId;
		}
		$this->load->view ( 'master_data/add_multiple_payment_currency_clients', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to associate clients to payment currency',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PAYMENTS_CURRENCY_CLIENT_VISIBILITY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
	}
	// save multiple clients
	function save_multiple_clients($table) {
		$specialty_ids = $this->input->post ( 'specialty' );
		$client_ids = $this->input->post ( 'id' );
		$specialty_ids = explode ( ',', $specialty_ids );
		$client_ids = explode ( ',', $client_ids );
		switch ($table) {
			case 'specialty_client_association' :
				$arrData = array ();
				foreach ( $specialty_ids as $key => $row ) {
					foreach ( $client_ids as $key => $value ) {
						$arrData ["specialty_id"] = $row;
						$arrData ["client_id"] = $value;
						$data [] = $arrData;
					}
				}
				break;
			case 'products_client_visibility' :
				$arrData = array ();
				foreach ( $specialty_ids as $key => $row ) {
					foreach ( $client_ids as $key => $value ) {
						$arrData ["products_id"] = $row;
						$arrData ["client_id"] = $value;
						$data [] = $arrData;
					}
				}
				break;
			case 'emails_client_visibility' :
				$arrData = array ();
				foreach ( $specialty_ids as $key => $row ) {
					foreach ( $client_ids as $key => $value ) {
						$arrData ["emails_id"] = $row;
						$arrData ["client_id"] = $value;
						$data [] = $arrData;
					}
				}
				break;
			case 'phone_type_client_visibility' :
				$arrData = array ();
				foreach ( $specialty_ids as $key => $row ) {
					foreach ( $client_ids as $key => $value ) {
						$arrData ["phone_type_id"] = $row;
						$arrData ["client_id"] = $value;
						$data [] = $arrData;
					}
				}
				break;
			case 'interaction_types_client_visibility' :
				$arrData = array ();
				foreach ( $specialty_ids as $key => $row ) {
					foreach ( $client_ids as $key => $value ) {
						$arrData ["interaction_types_id"] = $row;
						$arrData ["client_id"] = $value;
						$data [] = $arrData;
					}
				}
				break;
			case 'interactions_topics_client_visibility' :
				$arrData = array ();
				foreach ( $specialty_ids as $key => $row ) {
					foreach ( $client_ids as $key => $value ) {
						$arrData ["interactions_topics_id"] = $row;
						$arrData ["client_id"] = $value;
						$data [] = $arrData;
					}
				}
				break;
			case 'interactions_modes_client_visibility' :
				$arrData = array ();
				foreach ( $specialty_ids as $key => $row ) {
					foreach ( $client_ids as $key => $value ) {
						$arrData ["interactions_modes_id"] = $row;
						$arrData ["client_id"] = $value;
						$data [] = $arrData;
					}
				}
				break;
			case 'interaction_location_types_client_visibility' :
				$arrData = array ();
				foreach ( $specialty_ids as $key => $row ) {
					foreach ( $client_ids as $key => $value ) {
						$arrData ["interaction_location_types_id"] = $row;
						$arrData ["client_id"] = $value;
						$data [] = $arrData;
					}
				}
				break;
			case 'payments_requested_by_client_visibility' :
				$arrData = array ();
				foreach ( $specialty_ids as $key => $row ) {
					foreach ( $client_ids as $key => $value ) {
						$arrData ["requested_by_id"] = $row;
						$arrData ["client_id"] = $value;
						$data [] = $arrData;
					}
				}
				break;
			case 'payments_paid_by_client_visibility' :
				$arrData = array ();
				foreach ( $specialty_ids as $key => $row ) {
					foreach ( $client_ids as $key => $value ) {
						$arrData ["paid_by_id"] = $row;
						$arrData ["client_id"] = $value;
						$data [] = $arrData;
					}
				}
				break;
			case 'payment_types_client_visibility' :
				$arrData = array ();
				foreach ( $specialty_ids as $key => $row ) {
					foreach ( $client_ids as $key => $value ) {
						$arrData ["payment_type"] = $row;
						$arrData ["client_id"] = $value;
						$data [] = $arrData;
					}
				}
				break;
			case 'payments_currency_client_visibility' :
				$arrData = array ();
				foreach ( $specialty_ids as $key => $row ) {
					foreach ( $client_ids as $key => $value ) {
						$arrData ["currency_name"] = $row;
						$arrData ["client_id"] = $value;
						$data [] = $arrData;
					}
				}
				break;
		}
		$status = $this->master_data_model->saveMultipleClients ( $data, $table );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$tables = strtoupper ( $table );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$arrLogDetails = array (
				'type' => ADD_RECORD,
				'description' => 'associating multiple clients to ' . $table . ' data',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $specialty_ids,
				'transaction_table_id' => constant ( $tables ),
				'transaction_name' => "associating multiple clients to " . $table,
				'client_id' => $client_id,
				'user_id' => $userId,
				'parent_object_id' => $specialty_ids 
		);
		// pr($arrLogDetails);exit;
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $statusMsg = $status ? "Saved Successfully" : "Saved Failed";
	}
	
	// @Author:Kumar
	function list_event_topics() {
		$data ['contentPage'] = 'master_data/list_event_topics';
		$this->load->view ( 'layouts/analyst_view', $data );
	}
	// loads the contents to the jqGrid of event_topics
	function load_grid_event_topics() {
		ini_set ( 'memory_limit', '-1' );
		$page = $_REQUEST ['page']; // get the requested page
		$limit = $_REQUEST ['rows']; // get how many rows we want
		$sidx = $_REQUEST ['sidx']; // get index row - i.e. user click to sort
		$sord = $_REQUEST ['sord']; // get the direction
		if (! $sidx)
			$sidx = 1;
		$filterData = $_REQUEST ['filters'];
		$arrFilter = array ();
		$arrFilter = json_decode ( stripslashes ( $filterData ) );
		$field = 'field';
		$op = 'op';
		$data = 'data';
		$groupOp = 'groupOp';
		$searchString = $this->common_helpers->search_nested_arrays ( $arrFilter, $data );
		$searchField = $this->common_helpers->search_nested_arrays ( $arrFilter, $field );
		$whereResultArray = array ();
		foreach ( $searchField as $key => $val ) {
			$whereResultArray [$val] = $searchString [$key];
		}
		$searchGroupOperator = $searchGroupOperator [0];
		$searchResults = array ();
		
		$arrEvent = $this->master_data_model->getAllEventTopics ();
		// pr($arrEvent);
		// exit;
		$count = sizeof ( $arrEvent );
		// pr($count);
		// exit;
		if ($count > 0) {
			$total_pages = ceil ( $count / $limit );
		} else {
			$total_pages = 0;
		}
		// pr($total_pages);
		// exit;
		if ($page > $total_pages)
			$page = $total_pages;
		$start = $limit * $page - $limit; // do not put $limit*($page - 1)
		                                  // pr($page);
		                                  // exit;
		if ($start < 0)
			$start = 0;
		// pr($start);
		// exit;
		$arrEventTopics = $this->master_data_model->getAllEventTopics ( $limit, $start, $sidx, $sord );
		foreach ( $arrEventTopics as $row ) {
			$arrEventTopics1 [] = array (
					'id' => $row ['id'],
					'name' => $row ['name'],
					'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editEventTopic('" . $row ['id'] . "','" . addslashes ( $row ['name'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedEventTopics('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
			);
		}
		// pr($arrEventTopics1);exit;
		$data = array ();
		$data ['records'] = $count;
		$data ['total'] = $total_pages;
		$data ['page'] = $page;
		$data ['rows'] = $arrEventTopics1;
		ob_start ( 'ob_gzhandler' );
		echo json_encode ( $data );
	}
	function edit_event_topics() {
		$this->load->view ( 'master_data/add_event_topics', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to add event topics',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => EVENT_TOPICS,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// @Author:Kumar
	function list_event_organizer_types() {
		$data ['contentPage'] = 'master_data/list_event_organizer_types';
		$this->load->view ( 'layouts/analyst_view', $data );
	}
	// loads the contents to the jqGrid of event_organizer_types
	function load_grid_event_organizer_types() {
		ini_set ( 'memory_limit', '-1' );
		$page = $_REQUEST ['page']; // get the requested page
		$limit = $_REQUEST ['rows']; // get how many rows we want
		$sidx = $_REQUEST ['sidx']; // get index row - i.e. user click to sort
		$sord = $_REQUEST ['sord']; // get the direction
		if (! $sidx)
			$sidx = 1;
		$filterData = $_REQUEST ['filters'];
		$arrFilter = array ();
		$arrFilter = json_decode ( stripslashes ( $filterData ) );
		$field = 'field';
		$op = 'op';
		$data = 'data';
		$groupOp = 'groupOp';
		$searchString = $this->common_helpers->search_nested_arrays ( $arrFilter, $data );
		$searchField = $this->common_helpers->search_nested_arrays ( $arrFilter, $field );
		$whereResultArray = array ();
		foreach ( $searchField as $key => $val ) {
			$whereResultArray [$val] = $searchString [$key];
		}
		$searchGroupOperator = $searchGroupOperator [0];
		$searchResults = array ();
		
		$arrEventOrgTypes = $this->master_data_model->getAllEventOrganizerTypes ();
		// pr($arrEventOrgTypes);
		// exit;
		$count = sizeof ( $arrEventOrgTypes );
		// pr($count);
		// exit;
		if ($count > 0) {
			$total_pages = ceil ( $count / $limit );
		} else {
			$total_pages = 0;
		}
		// pr($total_pages);
		// exit;
		if ($page > $total_pages)
			$page = $total_pages;
		$start = $limit * $page - $limit; // do not put $limit*($page - 1)
		                                  // pr($page);
		                                  // exit;
		if ($start < 0)
			$start = 0;
		// pr($start);
		// exit;
		$arrEventOrganizerTypes = $this->master_data_model->getAllEventOrganizerTypes ( $limit, $start, $sidx, $sord );
		foreach ( $arrEventOrganizerTypes as $row ) {
			$arrEventOrganizerTypes1 [] = array (
					'id' => $row ['id'],
					'type' => $row ['type'],
					'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editEventOrgType('" . $row ['id'] . "','" . addslashes ( $row ['type'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedEventOrgTypes('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
			);
		}
		// pr($arrEventOrganizerTypes1);exit;
		$data = array ();
		$data ['records'] = $count;
		$data ['total'] = $total_pages;
		$data ['page'] = $page;
		$data ['rows'] = $arrEventOrganizerTypes1;
		ob_start ( 'ob_gzhandler' );
		echo json_encode ( $data );
	}
	function edit_event_organizer_types() {
		$this->load->view ( 'master_data/add_event_organizer_types', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to add event organizer types',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => EVENT_ORGANIZER_TYPES,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// @Author:Kumar
	function list_event_roles() {
		$data ['contentPage'] = 'master_data/list_event_roles';
		$this->load->view ( 'layouts/analyst_view', $data );
	}
	// loads the contents to the jqGrid of event_roles
	function load_grid_event_roles() {
		ini_set ( 'memory_limit', '-1' );
		$page = $_REQUEST ['page']; // get the requested page
		$limit = $_REQUEST ['rows']; // get how many rows we want
		$sidx = $_REQUEST ['sidx']; // get index row - i.e. user click to sort
		$sord = $_REQUEST ['sord']; // get the direction
		if (! $sidx)
			$sidx = 1;
		$filterData = $_REQUEST ['filters'];
		$arrFilter = array ();
		$arrFilter = json_decode ( stripslashes ( $filterData ) );
		$field = 'field';
		$op = 'op';
		$data = 'data';
		$groupOp = 'groupOp';
		$searchString = $this->common_helpers->search_nested_arrays ( $arrFilter, $data );
		$searchField = $this->common_helpers->search_nested_arrays ( $arrFilter, $field );
		$whereResultArray = array ();
		foreach ( $searchField as $key => $val ) {
			$whereResultArray [$val] = $searchString [$key];
		}
		$searchGroupOperator = $searchGroupOperator [0];
		$searchResults = array ();
		
		$arrEvtRoles = $this->master_data_model->getAllEventRoles ();
		// pr($arrEvtRoles);
		// exit;
		$count = sizeof ( $arrEvtRoles );
		// pr($count);
		// exit;
		if ($count > 0) {
			$total_pages = ceil ( $count / $limit );
		} else {
			$total_pages = 0;
		}
		// pr($total_pages);
		// exit;
		if ($page > $total_pages)
			$page = $total_pages;
		$start = $limit * $page - $limit; // do not put $limit*($page - 1)
		                                  // pr($page);
		                                  // exit;
		if ($start < 0)
			$start = 0;
		// pr($start);
		// exit;
		$arrEventRoles = $this->master_data_model->getAllEventRoles ( $limit, $start, $sidx, $sord );
		foreach ( $arrEventRoles as $row ) {
			$arrEventRoles1 [] = array (
					'id' => $row ['id'],
					'role' => $row ['role'],
					'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editEventRole('" . $row ['id'] . "','" . addslashes ( $row ['role'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedEventRole('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
			);
		}
		// pr($arrEventRoles1);exit;
		$data = array ();
		$data ['records'] = $count;
		$data ['total'] = $total_pages;
		$data ['page'] = $page;
		$data ['rows'] = $arrEventRoles1;
		ob_start ( 'ob_gzhandler' );
		echo json_encode ( $data );
	}
	function edit_event_role() {
		$this->load->view ( 'master_data/add_event_role', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to add event role',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => EVENT_ROLES,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// block user
	function block_user() {
		$id = $this->input->post ( 'user_id' );
		// pr ( $ids );
		// exit ();
		$status = $this->master_data_model->blockUser ( $id );
		echo json_encode ( $status );
	}
	// unblock user
	function un_block_user() {
		$id = $this->input->post ( 'user_id' );
		// pr ( $id );
		// exit ();
		$status = $this->master_data_model->unBlockUser ( $id );
		echo json_encode ( $status );
	}
	// To view different pages
	function view_types($page = 'Specialties') {
		$data ['arrTypes'] = $page;
		$data ['contentPage'] = 'master_data/view_type';
		//pr($data);exit;
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	// loading different page types such as Specialties,Organization_Types etc in single grid
	function load_grid_types() {
		// echo "hi";exit;
		// error_reporting(E_ALL);
		ini_set ( 'memory_limit', "-1" );
		ini_set ( "max_execution_time", 0 );
		$arrData = array ();
		$arrData ['type'] = $this->input->post ( 'type' );
		// alert($arrData['type']);
		// pr($arrData['type']);exit;
		$arrResult = $this->master_data_model->loadTypes ( $arrData, $limit, $start, $sidx, $sord );
// 		echo $this->db->last_query();exit;
		if ($arrData ['type'] == "Specialties") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'specialty' => $row ['specialty'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editSpecialties('" . $row ['id'] . "','" . addslashes ( $row ['specialty'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon'><a href='#' onclick=\"addSpecialtiesClients('" . $row ['id'] . "');\" title='Associate Clients'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedSpecialties('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		} else if ($arrData ['type'] == "Organization_Types") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'type' => $row ['type'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editOrgTypes('" . $row ['id'] . "','" . addslashes ( $row ['type'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedOrgTypes('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		} else if ($arrData ['type'] == "Engagement_Types") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'engagement_type' => $row ['engagement_type'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editEngType('" . $row ['id'] . "','" . addslashes ( $row ['engagement_type'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedEngType('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		} else if ($arrData ['type'] == "Event_Topics") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'name' => $row ['name'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editEventTopic('" . $row ['id'] . "','" . addslashes ( $row ['name'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedEventTopics('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		} else if ($arrData ['type'] == "Event_Org_Types") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'type' => $row ['type'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editEventOrgType('" . $row ['id'] . "','" . addslashes ( $row ['type'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedEventOrgTypes('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		} else if ($arrData ['type'] == "Event_Roles") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'role' => $row ['role'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editEventRole('" . $row ['id'] . "','" . addslashes ( $row ['role'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedEventRole('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		} else if ($arrData ['type'] == "Titles") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'title' => $row ['title'],
						'abbr' => $row ['abbr'],
						'client_id' => $row ['client_id'],
						'is_active' => $row ['is_active'],
						'keys_merged' => $row ['keys_merged'],
						'action' => '<div class="actionIcon editIcon"><a onclick="editTitle(' . $row ['id'] . ');" href="#" title="Edit">&nbsp;</a></div><div class="actionIcon deleteIcon"><a onclick="deleteTitle(' . $row ['id'] . ');" href="#" title="Delete">&nbsp;</a></div>' 
				);
			}
		} else if ($arrData ['type'] == "Phone_Type") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'name' => $row ['name'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editPhoneType('" . $row ['id'] . "','" . addslashes ( $row ['name'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon'><a href='#' onclick=\"addPhoneTypeClients('" . $row ['id'] . "');\" title='Associate Clients'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedPhoneType('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		} else if ($arrData ['type'] == "Product") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'name' => $row ['name'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editProduct('" . $row ['id'] . "','" . addslashes ( $row ['name'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon'><a href='#' onclick=\"addProductsClients('" . $row ['id'] . "');\" title='Associate Clients'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedProduct('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		} else if ($arrData ['type'] == "Email_Type") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'type' => $row ['type'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editEmailType('" . $row ['id'] . "','" . addslashes ( $row ['type'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon'><a href='#' onclick=\"addEmailTypeClients('" . $row ['id'] . "');\" title='Associate Clients'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedEmailType('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		} else if ($arrData ['type'] == "Discussion_Type") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'name' => $row ['name'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editDiscussionType('" . $row ['id'] . "','" . addslashes ( $row ['name'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon'><a href='#' onclick=\"addDiscussionTypeClients('" . $row ['id'] . "');\" title='Associate Clients'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedDiscussionType('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		} else if ($arrData ['type'] == "Topics") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'name' => $row ['name'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editTopics('" . $row ['id'] . "','" . addslashes ( $row ['name'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon'><a href='#' onclick=\"addTopicsClients('" . $row ['id'] . "');\" title='Associate Clients'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedTopic('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		} else if ($arrData ['type'] == "Interaction_Type") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'name' => $row ['name'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editInteractionType('" . $row ['id'] . "','" . addslashes ( $row ['name'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon'><a href='#' onclick=\"addModesClients('" . $row ['id'] . "');\" title='Associate Clients'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedInteractionType('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		} else if ($arrData ['type'] == "Interaction_Location") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'name' => $row ['name'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editInteractionLocation('" . $row ['id'] . "','" . addslashes ( $row ['name'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon'><a href='#' onclick=\"addLocationTypeClients('" . $row ['id'] . "');\" title='Associate Clients'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedInteractionLocation('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		} else if ($arrData ['type'] == "Requested_By") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'requested_by' => $row ['requested_by'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editRequestedBy('" . $row ['id'] . "','" . addslashes ( $row ['requested_by'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon'><a href='#' onclick=\"addRequestedByClients('" . $row ['id'] . "');\" title='Associate Clients'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedRequestedBy('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		} else if ($arrData ['type'] == "Paid_By") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'paid_by' => $row ['paid_by'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editPaidBy('" . $row ['id'] . "','" . addslashes ( $row ['paid_by'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon'><a href='#' onclick=\"addPaidByClients('" . $row ['id'] . "');\" title='Associate Clients'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedPaidBy('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		} else if ($arrData ['type'] == "Payment_Type") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'name' => $row ['name'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editPaymentType('" . $row ['id'] . "','" . addslashes ( $row ['name'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon'><a href='#' onclick=\"addPaymentTypeByClients('" . $row ['id'] . "');\" title='Associate Clients'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedPaymentType('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		} else if ($arrData ['type'] == "Payment_Currency") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'currency_name' => $row ['currency_name'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editPaymentCurrency('" . $row ['id'] . "','" . addslashes ( $row ['currency_name'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon'><a href='#' onclick=\"addPaymentCurrencyByClients('" . $row ['id'] . "');\" title='Associate Clients'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedPaymentCurrency('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		} else if ($arrData ['type'] == "conf_event_types") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'event_type' => $row ['event_type'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editEventType('" . $row ['id'] . "','" . addslashes ( $row ['event_type'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedEventType('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		} else if ($arrData ['type'] == "event_sponsor_types") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'type' => $row ['type'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editSponsorTypes('" . $row ['id'] . "','" . addslashes ( $row ['type'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedSponsorTypes('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		} else if ($arrData ['type'] == "conf_session_types") {
			foreach ( $arrResult as $row ) {
				$arrSpecDetails [] = array (
						'id' => $row ['id'],
						'session_type' => $row ['session_type'],
						'keys_merged' => $row ['keys_merged'],
						'action' => "<div class='actionIcon editIcon'><a href='#' onclick=\"editSessionTypes('" . $row ['id'] . "','" . addslashes ( $row ['session_type'] ) . "');\" title='Edit'>&nbsp;</a></div><div class='actionIcon deleteIcon'><a href='#' onclick=\"deleteSelectedSessionTypes('" . $row ['id'] . "');\" title='delete'>&nbsp;</a></div>" 
				);
			}
		}
		// pr($arrSpecDetails);exit;
		// ob_start ( 'ob_gzhandler' );
		echo json_encode ( $arrSpecDetails );
	}
	// opens the merge organization type modal box
	function merge_orgtype_modal_box($orgtypeIds) {
		$arrOrgTypes = $this->master_data_model->getAllOrganizationTypes ();
		$data ['arrOrgTypes'] = $arrOrgTypes;
		$data ['arrOrg'] = $orgtypeIds;
		// pr($orgtypeIds);exit;
		$this->load->view ( 'master_data/merge_organization_type', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to merge organization type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => ORGANIZATION_TYPES,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// merge organization types
	function merge_orgtype() {
		$old_orgtype_id = $this->input->post ( 'orgtype' );
		$new_orgtype_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		// pr($new_orgtype_id);exit;
		$arrData = array ();
		$old_orgtype_ids = explode ( ',', $old_orgtype_id );
		foreach ( $old_orgtype_ids as $key => $row ) {
			$arrData ["orgtype_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergeOrgTypes ( $data );
		$status = $this->master_data_model->mergeOrgTypes ( $data, $new_orgtype_id );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'Merge',
				'description' => 'duplicate organization types were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_orgtype_id,
				'transaction_table_id' => ORGANIZATION_TYPES,
				'transaction_name' => "meging organization types",
				'miscellaneous1' => "The organization type ids " . $old_orgtype_id . " replaced with  " . $new_orgtype_id . " in the tables specified in miscellaneous2",
				'miscellaneous2' => " organizations",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	
	// opens the merge engagement type modal box
	function merge_engtype_modal_box($engtypeIds) {
		$arrEngTypes = $this->master_data_model->getAllEngagementTypes ();
		$data ['arrEngTypes'] = $arrEngTypes;
		$data ['arrEng'] = $engtypeIds;
		// pr($engtypeIds);exit;
		$this->load->view ( 'master_data/merge_engagement_type', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to merge engagement type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => ENGAGEMENT_TYPES,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// merge engagement types
	function merge_engtype() {
		$old_engtype_id = $this->input->post ( 'engtype' );
		$new_engtype_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		// pr($old_engtype_id);exit;
		$arrData = array ();
		$old_engtype_ids = explode ( ',', $old_engtype_id );
		foreach ( $old_engtype_ids as $key => $row ) {
			$arrData ["engtype_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergeEngTypes ( $data );
		$status = $this->master_data_model->mergeEngTypes ( $data, $new_engtype_id );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'Merge',
				'description' => 'duplicate engagement types were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_engtype_id,
				'transaction_table_id' => ENGAGEMENT_TYPES,
				'transaction_name' => "meging engagement types",
				'miscellaneous1' => "The engagement type ids " . $old_engtype_id . " replaced with  " . $new_engtype_id . " in the tables specified in miscellaneous2",
				'miscellaneous2' => " kol_memberships",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	
	// opens the merge event topic modal box
	function merge_eventtopic_modal_box($eventtopicIds) {
		$arrEventTopics = $this->master_data_model->getAllEventTopics ();
		$data ['arrEventTopics'] = $arrEventTopics;
		$data ['arrEvent'] = $eventtopicIds;
		// pr($eventtopicIds);exit;
		$this->load->view ( 'master_data/merge_event_topic', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to merge event topics',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => EVENT_TOPICS,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// merge event topics
	function merge_event_topic() {
		$old_eventtopic_id = $this->input->post ( 'eventtopic' );
		$new_eventtopic_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		// pr($old_eventtopic_id);exit;
		$arrData = array ();
		$old_eventtopic_ids = explode ( ',', $old_eventtopic_id );
		foreach ( $old_eventtopic_ids as $key => $row ) {
			$arrData ["eventtopic_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergeEventTopics ( $data );
		$status = $this->master_data_model->mergeEventTopics ( $data, $new_eventtopic_id );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'Merge',
				'description' => 'duplicate event topics were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_eventtopic_id,
				'transaction_table_id' => EVENT_TOPICS,
				'transaction_name' => "meging event topics",
				'miscellaneous1' => "The event topic ids " . $old_eventtopic_id . " replaced with  " . $new_eventtopic_id . " in the tables specified in miscellaneous2",
				'miscellaneous2' => " kol_events",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	
	// opens the merge event organizer type modal box
	function merge_eventorganizer_modal_box($eventorgtypeIds) {
		$arrEventOrgTypes = $this->master_data_model->getAllEventOrganizerTypes ();
		$data ['arrEventOrgTypes'] = $arrEventOrgTypes;
		$data ['arrEventOrg'] = $eventorgtypeIds;
		// pr($eventorgtypeIds);exit;
		$this->load->view ( 'master_data/merge_event_organizer_type', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to merge event organizer type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => EVENT_ORGANIZER_TYPES,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// merge event organizer type
	function merge_event_organizer_type() {
		$old_eventorgtype_id = $this->input->post ( 'eventorgtype' );
		$new_eventorgtype_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		// pr($old_eventtopic_id);exit;
		$arrData = array ();
		$old_eventorgtype_ids = explode ( ',', $old_eventorgtype_id );
		foreach ( $old_eventorgtype_ids as $key => $row ) {
			$arrData ["eventorgtype_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergeEventOrganizerTypes ( $data );
		$status = $this->master_data_model->mergeEventOrganizerTypes ( $data, $new_eventorgtype_id );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'Merge',
				'description' => 'duplicate event organizer types were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_eventorgtype_id,
				'transaction_table_id' => EVENT_ORGANIZER_TYPES,
				'transaction_name' => "meging event organizer types",
				'miscellaneous1' => "The event organizer type ids " . $old_eventorgtype_id . " replaced with  " . $new_eventorgtype_id . " in the tables specified in miscellaneous2",
				'miscellaneous2' => " kol_events",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	
	// opens the merge event role modal box
	function merge_eventrole_modal_box($eventroleIds) {
		$arrEventRoles = $this->master_data_model->getAllEventRoles ();
		$data ['arrEventRoles'] = $arrEventRoles;
		$data ['arrEventRole'] = $eventroleIds;
		// pr($eventroleIds);exit;
		$this->load->view ( 'master_data/merge_event_role', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to merge event role',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => EVENT_ROLES,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// merge event role
	function merge_event_roles() {
		$old_eventrole_id = $this->input->post ( 'eventrole' );
		$new_eventrole_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		// pr($old_eventrole_id);exit;
		$arrData = array ();
		$old_eventrole_ids = explode ( ',', $old_eventrole_id );
		foreach ( $old_eventrole_ids as $key => $row ) {
			$arrData ["eventrole_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergeEventRoles ( $data );
		$status = $this->master_data_model->mergeEventRoles ( $data, $new_eventrole_id );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'Merge',
				'description' => 'duplicate event roles were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_eventrole_id,
				'transaction_table_id' => EVENT_ROLES,
				'transaction_name' => "meging event roles",
				'miscellaneous1' => "The event role ids " . $old_eventrole_id . " replaced with  " . $new_eventrole_id . " in the tables specified in miscellaneous2",
				'miscellaneous2' => " key_peoples",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	// opens the merge title modal box
	function merge_title_modal_box($titleIds) {
		$arrTitles = $this->master_data_model->getAllTitles ();
		// pr($arrTitles);exit;
		$data ['arrTitles'] = $arrTitles;
		$data ['arrTitle'] = $titleIds;
		// pr($titleIds);exit;
		$this->load->view ( 'master_data/merge_title', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to merge titles',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => TITLES,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// merge title
	function merge_titles() {
		$old_title_id = $this->input->post ( 'title' );
		$new_title_id = $this->input->post ( 'id' );
		// pr($old_title_id);exit;
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrData = array ();
		$old_title_ids = explode ( ',', $old_title_id );
		foreach ( $old_title_ids as $key => $row ) {
			$arrData ["title_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergeTitles ( $data );
		$status = $this->master_data_model->mergeTitles ( $data, $new_title_id );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'Merge',
				'description' => 'duplicate titles were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_title_id,
				'transaction_table_id' => TITLES,
				'transaction_name' => "meging titles",
				'miscellaneous1' => "The title ids " . $old_title_id . " replaced with  " . $new_title_id . " in the tables specified in miscellaneous2",
				'miscellaneous2' => " kol_locations, title_client_mappings ",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	// -------product modal box----
	function edit_product() {
		$this->load->view ( 'master_data/add_prodct', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to add product',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PRODUCTS,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// opens the merge product modal box
	function merge_product_modal_box($productIds) {
		$arrProducts = $this->master_data_model->getAllProducts ();
		// pr($arrProducts);exit;
		$data ['arrProducts'] = $arrProducts;
		$data ['arrProduct'] = $productIds;
		// pr($productIds);exit;
		$this->load->view ( 'master_data/merge_product', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to merge products',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PRODUCTS,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// merge product
	function merge_product() {
		$old_product_id = $this->input->post ( 'product' );
		$new_product_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		// pr($old_product_id);exit;
		$arrData = array ();
		$old_product_ids = explode ( ',', $old_product_id );
		foreach ( $old_product_ids as $key => $row ) {
			$arrData ["product_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergeProducts ( $data );
		$status = $this->master_data_model->mergeProducts ( $data, $new_product_id );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'Merge',
				'description' => 'duplicate products were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_product_id,
				'transaction_table_id' => PRODUCTS,
				'transaction_name' => "meging products",
				'miscellaneous1' => "The product ids " . $old_product_id . " replaced with  " . $new_product_id . " in the tables specified in miscellaneous2",
				'miscellaneous2' => " ol_speaker_product,kol_products,topics_by_prod_type$,interaction_type_by_product,interaction_topics_by_type,interaction_sub_topics_association,interactions_discussion_topic_mapped_data,interactions_topic_mapped_data,interaction_topic_mapping,products_client_visibility",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	
	// -------phone type modal box----
	function edit_phone_type() {
		$this->load->view ( 'master_data/add_phone_type', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to add phone type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PHONE_TYPE,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// opens the merge phone type modal box
	function merge_phonetype_modal_box($phonetypeIds) {
		// echo "hi";exit;
		$arrPhoneTypes = $this->master_data_model->getAllPhoneType ();
		// pr($arrPhoneTypes);exit;
		$data ['arrPhoneTypes'] = $arrPhoneTypes;
		$data ['arrPhoneType'] = $phonetypeIds;
		// pr($phonetypeIds);exit;
		$this->load->view ( 'master_data/merge_phone_types', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to merge phone type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PHONE_TYPE,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// merge phone type
	function merge_phone_type() {
		$old_phonetype_id = $this->input->post ( 'phonetype' );
		$new_phonetype_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		// pr($old_phonetype_id);exit;
		$arrData = array ();
		$old_phonetype_ids = explode ( ',', $old_phonetype_id );
		foreach ( $old_phonetype_ids as $key => $row ) {
			$arrData ["phonetype_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergePhoneTypes ( $data );
		$status = $this->master_data_model->mergePhoneTypes ( $data, $new_phonetype_id );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'Merge',
				'description' => 'duplicate phone types were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_phonetype_id,
				'transaction_table_id' => PHONE_TYPE,
				'transaction_name' => "meging phone types",
				'miscellaneous1' => "The phone type ids " . $old_phonetype_id . " replaced with  " . $new_phonetype_id . " in the tables specified in miscellaneous2",
				'miscellaneous2' => " staffs,phone_type_client_visibility",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	// -------email type modal box----
	function edit_email_type() {
		$this->load->view ( 'master_data/add_email_type', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to add email type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => EMAILS,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// opens the merge email type modal box
	function merge_emailtype_modal_box($emailTypeIds) {
		// echo "hi";exit;
		$arrEmailTypes = $this->master_data_model->getAllEmails ();
		// pr($arrEmailTypes);exit;
		$data ['arrEmailTypes'] = $arrEmailTypes;
		$data ['arrEmailType'] = $emailTypeIds;
		// pr($emailTypeIds);exit;
		$this->load->view ( 'master_data/merge_email_types', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to merge email type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => EMAILS,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// merge email type
	function merge_email_type() {
		$old_emailType_id = $this->input->post ( 'emailType' );
		$new_emailType_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		// pr($new_emailType_id);exit;
		$arrData = array ();
		$old_emailType_ids = explode ( ',', $old_emailType_id );
		foreach ( $old_emailType_ids as $key => $row ) {
			$arrData ["emailtype_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergeEmailTypes ( $data );
		$status = $this->master_data_model->mergeEmailTypes ( $data, $new_emailType_id );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'Merge',
				'description' => 'duplicate email types were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_emailType_id,
				'transaction_table_id' => EMAILS,
				'transaction_name' => "meging email types",
				'miscellaneous1' => "The email type ids " . $old_emailType_id . " replaced with  " . $new_emailType_id . " in the tables specified in miscellaneous2",
				'miscellaneous2' => " contact_restrictions,emails_client_visibility",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	// -------discussion type modal box----
	function edit_discussion_type() {
		$this->load->view ( 'master_data/add_discussion_type', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to add discussion type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => INTERACTION_TYPES,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// opens the merge discussion type modal box
	function merge_discussion_type_modal_box($discussionTypeIds) {
		// echo "hi";exit;
		$arrDiscussionTypes = $this->master_data_model->getAllDiscussionTypes ();
		// pr($arrDiscussionTypes);exit;
		$data ['arrDiscussionTypes'] = $arrDiscussionTypes;
		$data ['arrDiscussionType'] = $discussionTypeIds;
		// pr($discussionTypeIds);exit;
		$this->load->view ( 'master_data/merge_discussion_types', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to merge discussion type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => INTERACTION_TYPES,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// merge discussion type
	function merge_discussion_type() {
		$old_discussionType_id = $this->input->post ( 'discussionType' );
		$new_discussionType_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		// pr($old_discussionType_id);exit;
		$arrData = array ();
		$old_discussionType_ids = explode ( ',', $old_discussionType_id );
		foreach ( $old_discussionType_ids as $key => $row ) {
			$arrData ["discussion_type_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergeDiscussionTypes ( $data );
		$status = $this->master_data_model->mergeDiscussionTypes ( $data, $new_discussionType_id );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'Merge',
				'description' => 'duplicate discussion types were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_discussionType_id,
				'transaction_table_id' => INTERACTION_TYPES,
				'transaction_name' => "meging discussion types",
				'miscellaneous1' => "The discussion type ids " . $old_discussionType_id . " replaced with  " . $new_discussionType_id . " in the tables specified in miscellaneous2",
				'miscellaneous2' => " interaction_sub_topics_association,topics_by_prod_type$,interaction_topics_by_type,interaction_topic_mapping,interaction_type_by_product,interactions_discussion_topic_mapped_data,interaction_types_client_visibility",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	// -------topic modal box----
	function edit_topics() {
		$this->load->view ( 'master_data/add_topic', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to add topics',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => INTERACTIONS_TOPICS,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// opens the merge interactions topic modal box
	function merge_topics_modal_box($topicIds) {
		$arrtopics = $this->master_data_model->getAllInteractionsTopics ();
		// pr($arrtopics);exit;
		$data ['arrtopics'] = $arrtopics;
		$data ['arrtopic'] = $topicIds;
		// pr($topicIds);exit;
		$this->load->view ( 'master_data/merge_topics', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to merge interaction topics',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => INTERACTIONS_TOPICS,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// merge interactions topic
	function merge_topics() {
		$old_topic_id = $this->input->post ( 'topic' );
		$new_topic_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		// pr($old_topic_id);exit;
		$arrData = array ();
		$old_topic_ids = explode ( ',', $old_topic_id );
		foreach ( $old_topic_ids as $key => $row ) {
			$arrData ["topic_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergeTopics ( $data );
		$status = $this->master_data_model->mergeTopics ( $data, $new_topic_id );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'Merge',
				'description' => 'duplicate discussion topics were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_topic_id,
				'transaction_table_id' => INTERACTIONS_TOPICS,
				'transaction_name' => "meging discussion topics",
				'miscellaneous1' => "The discussion topic ids " . $old_topic_id . " replaced with  " . $new_topic_id . " in the tables specified in miscellaneous2",
				'miscellaneous2' => " interactions_about,interactions_discussion_topic_mapped_data,interactions_topic_mapped_data,interaction_sub_topics_association,interaction_topics_by_type,interaction_topic_mapping,topics_by_prod_type$,interactions_topics_client_visibility",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	// -------interaction type modal box----
	function edit_interaction_type() {
		$this->load->view ( 'master_data/add_interaction_type', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to add interaction type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => INTERACTIONS_MODES,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// opens the merge interactions type modal box
	function merge_interaction_type_modal_box($interactionTypeIds) {
		$arrinteractionTypes = $this->master_data_model->getAllInteractionsTypes ();
		// pr($arrinteractionTypes);exit;
		$data ['arrinteractionTypes'] = $arrinteractionTypes;
		$data ['arrinteractionType'] = $interactionTypeIds;
		// pr($interactionTypeIds);exit;
		$this->load->view ( 'master_data/merge_interaction_types', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to merge interaction type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => INTERACTIONS_MODES,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// merge interactions type
	function merge_interaction_type() {
		$old_interactionType_id = $this->input->post ( 'interactionType' );
		$new_interactionType_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		// pr($old_interactionType_id);exit;
		$arrData = array ();
		$old_interactionType_ids = explode ( ',', $old_interactionType_id );
		foreach ( $old_interactionType_ids as $key => $row ) {
			$arrData ["interactin_type_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergeInteractionTypes ( $data );
		$status = $this->master_data_model->mergeInteractionTypes ( $data, $new_interactionType_id );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'Merge',
				'description' => 'duplicate interaction types were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_interactionType_id,
				'transaction_table_id' => INTERACTIONS_MODES,
				'transaction_name' => "meging interaction types",
				'miscellaneous1' => "The interaction type ids " . $old_interactionType_id . " replaced with  " . $new_interactionType_id . " in the tables specified in miscellaneous2",
				'miscellaneous2' => "interactions,interactions_modes_client_visibility ",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	// -------interaction location modal box----
	function edit_interaction_location() {
		$this->load->view ( 'master_data/add_interaction_location', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to add interaction location',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => INTERACTION_LOCATION_TYPES,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// opens the merge interactions location modal box
	function merge_interaction_location_modal_box($interactionLocationIds) {
		$arrinteractionLocations = $this->master_data_model->getAllInteractionLocations ();
		// pr($arrinteractionLocations);exit;
		$data ['arrinteractionLocations'] = $arrinteractionLocations;
		$data ['arrinteractionLocation'] = $interactionLocationIds;
		// pr($interactionLocationIds);exit;
		$this->load->view ( 'master_data/merge_interaction_location', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to merge interaction location type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => INTERACTION_LOCATION_TYPES,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// merge interactions location
	function merge_interaction_location() {
		$old_interactionLocation_id = $this->input->post ( 'interactionLocation' );
		$new_interactionLocation_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		// pr($old_interactionLocation_id);exit;
		$arrData = array ();
		$old_interactionLocation_ids = explode ( ',', $old_interactionLocation_id );
		foreach ( $old_interactionLocation_ids as $key => $row ) {
			$arrData ["interactin_location_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergeInteractionLocation ( $data );
		$status = $this->master_data_model->mergeInteractionLocation ( $data, $new_interactionLocation_id );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'Merge',
				'description' => 'duplicate interaction location types were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_interactionLocation_id,
				'transaction_table_id' => INTERACTION_LOCATION_TYPES,
				'transaction_name' => "meging interaction location types",
				'miscellaneous1' => "The interaction location type ids " . $old_interactionLocation_id . " replaced with  " . $new_interactionLocation_id . " in the tables specified in miscellaneous2",
				'miscellaneous2' => "interactions,interaction_location_types_client_visibility",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	// -------payment requested by modal box----
	function edit_requested_by() {
		$this->load->view ( 'master_data/add_requested_by', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to add requested by',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PAYMENTS_REQUESTED_BY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// opens the merge payment requested by modal box
	function merge_requested_by_modal_box($requestedByIds) {
		$arrrequestedBys = $this->master_data_model->getAllPaymentRequestedBy ();
		// pr($arrrequestedBys);exit;
		$data ['arrrequestedBys'] = $arrrequestedBys;
		$data ['arrrequestedBy'] = $requestedByIds;
		// pr($requestedByIds);exit;
		$this->load->view ( 'master_data/merge_payment_requested_by', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to merge payments requested by',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PAYMENTS_REQUESTED_BY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// merge payment requested by
	function merge_requested_by() {
		$old_requestedBy_id = $this->input->post ( 'requestedBy' );
		$new_requestedBy_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		// pr($old_requestedBy_id);exit;
		$arrData = array ();
		$old_requestedBy_ids = explode ( ',', $old_requestedBy_id );
		foreach ( $old_requestedBy_ids as $key => $row ) {
			$arrData ["requested_by_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergePaymentRequestedBy ( $data );
		$status = $this->master_data_model->mergePaymentRequestedBy ( $data, $new_requestedBy_id );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'Merge',
				'description' => 'duplicate payments requested by were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_requestedBy_id,
				'transaction_table_id' => PAYMENTS_REQUESTED_BY,
				'transaction_name' => "meging payments requested by",
				'miscellaneous1' => "The payments requested by ids " . $old_requestedBy_id . " replaced with  " . $new_requestedBy_id . " in the tables specified in miscellaneous2",
				'miscellaneous2' => "payments,payments_requested_by_client_visibility",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	// -------payment paid by modal box----
	function edit_paid_by() {
		$this->load->view ( 'master_data/add_paid_by', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to add paid by',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PAYMENTS_PAID_BY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// opens the merge payment paidby modal box
	function merge_paid_by_modal_box($paidByIds) {
		$arrpaidBys = $this->master_data_model->getAllPaymentPaidBy ();
		// pr($arrpaidBys);exit;
		$data ['arrpaidBys'] = $arrpaidBys;
		$data ['arrpaidBy'] = $paidByIds;
		// pr($paidByIds);exit;
		$this->load->view ( 'master_data/merge_payment_paid_by', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to merge payments paid by',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PAYMENTS_PAID_BY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// merge payment paid by
	function merge_paid_by() {
		$old_paidBy_id = $this->input->post ( 'paidBy' );
		$new_paidBy_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		// pr($new_paidBy_id);exit;
		$arrData = array ();
		$old_paidBy_ids = explode ( ',', $old_paidBy_id );
		foreach ( $old_paidBy_ids as $key => $row ) {
			$arrData ["paid_by_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergePaymentPaidBy ( $data );
		$status = $this->master_data_model->mergePaymentPaidBy ( $data, $new_paidBy_id );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'Merge',
				'description' => 'duplicate payments paid by were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_paidBy_id,
				'transaction_table_id' => PAYMENTS_PAID_BY,
				'transaction_name' => "meging payments paid by",
				'miscellaneous1' => "The payments paid by ids " . $old_paidBy_id . " replaced with  " . $new_paidBy_id . " in the tables specified in miscellaneous2",
				'miscellaneous2' => "payments,payments_paid_by_client_visibility",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	// -------payment currency modal box----
	function edit_payment_currency() {
		$this->load->view ( 'master_data/add_payment_currency', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to add payment currency',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PAYMENTS_CURRENCY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// opens the merge payment currency modal box
	function merge_payment_currency_modal_box($currencyIds) {
		$arrCurrency = $this->master_data_model->getAllPaymentCurrency ();
		// pr($arrCurrency);exit;
		$data ['arrCurrencys'] = $arrCurrency;
		$data ['arrCurrency'] = $currencyIds;
		// pr($typeIds);exit;
		$this->load->view ( 'master_data/merge_payment_currency', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to merge payment currency',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PAYMENTS_CURRENCY,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// merge payment currency
	function merge_payment_currency() {
		$old_currency_id = $this->input->post ( 'currency' );
		$new_currency_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		// pr($old_currency_id);exit;
		$arrData = array ();
		$old_currency_ids = explode ( ',', $old_currency_id );
		foreach ( $old_currency_ids as $key => $row ) {
			$arrData ["currency_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergePaymentCurrency ( $data );
		$status = $this->master_data_model->mergePaymentCurrency ( $data, $new_currency_id );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'Merge',
				'description' => 'duplicate payment currency were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_currency_id,
				'transaction_table_id' => PAYMENTS_CURRENCY,
				'transaction_name' => "meging payment currency",
				'miscellaneous1' => "The payment currency ids " . $old_currency_id . " replaced with  " . $new_currency_id . " in the tables specified in miscellaneous2",
				'miscellaneous2' => "payment_split,payments_currency_client_visibility",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	//----------Event type----------
	function edit_event_types() {
		$this->load->view ( 'master_data/add_event_type', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited add event type Page",
				'status' => STATUS_SUCCESS,
				'client_id' => $client_id,
				'user_id' => $userId,
				'transaction_name' => "View add event type Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
	}
	// opens the merge event type modal box
	function merge_event_type_modal_box($eventIds) {
		$arrEventTypes = $this->master_data_model->getAllEventTypes();
		$data ['arrEventTypes'] = $arrEventTypes;
		$data ['arrEventType'] = $eventIds;
		$this->load->view ( 'master_data/merge_event_type', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'type' => VIEW_RECORD,
				'description' => 'Visited merge event type Page',
				'status' => STATUS_SUCCESS,
				'file_name' => 'master_data_controller',
				'transaction_name' => "View merge event type Page",
				'transaction_table_id' => CONF_EVENT_TYPES,
				'client_id' => $client_id,
				'user_id' => $userId
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
	}
	// merge event type
	function merge_event_type() {
		$old_eventType_id = $this->input->post ( 'eventType' );
		$new_eventType_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrData = array ();
		$old_eventType_ids = explode ( ',', $old_eventType_id);
		foreach ( $old_eventType_ids as $key => $row ) {
			$arrData ["event_type_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergeEventTypes( $data );
		$status = $this->master_data_model->mergeEventTypes( $data, $new_eventType_id);
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'type' => ADD_RECORD,
				'description' => 'duplicate event types were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_eventType_id,
				'transaction_table_id' => CONF_EVENT_TYPES,
				'transaction_name' => "meging event types",
				'miscellaneous1' => "The event types ids " . $old_eventType_id. " replaced with  " . $new_eventType_id. " in the tables specified in miscellaneous2",
				'miscellaneous2' => "kol_events",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	//-----Sponsor type-------------------
	function edit_sponsor_types() {
		$this->load->view ( 'master_data/add_sponsor_type', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited add sponsor type Page",
				'status' => STATUS_SUCCESS,
				'client_id' => $client_id,
				'user_id' => $userId,
				'transaction_name' => "View add sponsor type Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
	}
	// opens the merge sponsor type modal box
	function merge_sponsor_type_modal_box($sponsorIds) {
		$arrSponsorTypes = $this->master_data_model->getAllSponsorTypes();
		$data ['arrSponsorTypes'] = $arrSponsorTypes;
		$data ['arrSponsorType'] = $sponsorIds;
		$this->load->view ( 'master_data/merge_sponsor_type', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'type' => VIEW_RECORD,
				'description' => 'Visited merge sponsor type Page',
				'status' => STATUS_SUCCESS,
				'file_name' => 'master_data_controller',
				'transaction_name' => "View merge sponsor type Page",
				'transaction_table_id' => EVENT_SPONSOR_TYPES,
				'client_id' => $client_id,
				'user_id' => $userId
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
	}
	// merge sponsor type
	function merge_sponsor_type() {
		$old_sponsorType_id = $this->input->post ( 'sponsorType' );
		$new_sponsorType_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrData = array ();
		$old_sponsorType_ids = explode ( ',', $old_sponsorType_id);
		foreach ( $old_sponsorType_ids as $key => $row ) {
			$arrData ["sponsor_type_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergeSponsorTypes( $data );
		$status = $this->master_data_model->mergeSponsorTypes( $data, $new_sponsorType_id);
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'type' => ADD_RECORD,
				'description' => 'duplicate sponsor types were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_sponsorType_id,
				'transaction_table_id' => EVENT_SPONSOR_TYPES,
				'transaction_name' => "meging sponsor types",
				'miscellaneous1' => "The sponsor types ids " . $old_sponsorType_id. " replaced with  " . $new_sponsorType_id. " in the tables specified in miscellaneous2",
				'miscellaneous2' => "kol_events",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	//-------session type ------------
	function edit_session_types() {
		$this->load->view ( 'master_data/add_session_type', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited add session type Page",
				'status' => STATUS_SUCCESS,
				'client_id' => $client_id,
				'user_id' => $userId,
				'transaction_name' => "View add session type Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
	}
	// opens the merge session type modal box
	function merge_session_type_modal_box($sessionIds) {
		$arrSessionTypes = $this->master_data_model->getAllSessionTypes();
		$data ['arrSessionTypes'] = $arrSessionTypes;
		$data ['arrSessionType'] = $sessionIds;
		$this->load->view ( 'master_data/merge_session_type', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'type' => VIEW_RECORD,
				'description' => 'Visited merge session type Page',
				'status' => STATUS_SUCCESS,
				'file_name' => 'master_data_controller',
				'transaction_name' => "View merge session type Page",
				'transaction_table_id' => CONF_SESSION_TYPES,
				'client_id' => $client_id,
				'user_id' => $userId
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
	}
	// merge session type
	function merge_session_type() {
		$old_sessionType_id = $this->input->post ( 'sessionType' );
		$new_sessionType_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrData = array ();
		$old_sessionType_ids = explode ( ',', $old_sessionType_id);
		foreach ( $old_sessionType_ids as $key => $row ) {
			$arrData ["session_type_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergeSessionTypes( $data );
		$status = $this->master_data_model->mergeSessionTypes( $data, $new_sessionType_id);
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'type' => ADD_RECORD,
				'description' => 'duplicate session types were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_sessionType_id,
				'transaction_table_id' => CONF_SESSION_TYPES,
				'transaction_name' => "meging session types",
				'miscellaneous1' => "The session types ids " . $old_sessionType_id. " replaced with  " . $new_sessionType_id. " in the tables specified in miscellaneous2",
				'miscellaneous2' => "kol_events",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	// -------payment type modal box----
	function edit_payment_type() {
		$this->load->view ( 'master_data/add_payment_type', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to add payment type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PAYMENT_TYPES,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// opens the merge payment type modal box
	function merge_type_modal_box($typeIds) {
		$arrTypes = $this->master_data_model->getAllPaymentType ();
		// pr($arrTypes);exit;
		$data ['arrTypes'] = $arrTypes;
		$data ['arrType'] = $typeIds;
		// pr($typeIds);exit;
		$this->load->view ( 'master_data/merge_payment_type', $data );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'open',
				'description' => 'Open modal box to merge payment type',
				'status' => 'success',
				'file_name' => 'master_data_controller',
				'transaction_name' => "Open modal box",
				'transaction_table_id' => PAYMENT_TYPES,
				'client_id' => $client_id,
				'user_id' => $userId 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
	}
	// merge payment type by
	function merge_payment_type() {
		$old_paymentType_id = $this->input->post ( 'paymentType' );
		$new_paymentType_id = $this->input->post ( 'id' );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		// pr($old_paymentType_id);exit;
		$arrData = array ();
		$old_paymentType_ids = explode ( ',', $old_paymentType_id );
		foreach ( $old_paymentType_ids as $key => $row ) {
			$arrData ["type_id"] = $row;
			$data [] = $arrData;
		}
		$this->master_data_model->setMergePaymentType ( $data );
		$status = $this->master_data_model->mergePaymentType ( $data, $new_paymentType_id );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$formData = $_POST;
		$formData = json_encode ( $formData );
		$arrLogDetails = array (
				'module' => 'Master Data',
				'type' => 'Merge',
				'description' => 'duplicate payment type were merged',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $old_paymentType_id,
				'transaction_table_id' => PAYMENT_TYPES,
				'transaction_name' => "meging payment type",
				'miscellaneous1' => "The payment type ids " . $old_paymentType_id . " replaced with  " . $new_paymentType_id . " in the tables specified in miscellaneous2",
				'miscellaneous2' => "payments,payment_split,payment_types_client_visibility",
				'client_id' => $client_id,
				'user_id' => $userId,
				'form_data' => $formData 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $statusMsg = $status ? "Merged Successfully" : "Merging Failed";
	}
	// save data
	function save_master_data($page) {
		// $type = 'specialties';
		// pr($page);exit;
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		switch ($page) {
			case 'specialties' :
				$specialty = $this->input->post ( 'specialty' );
				$id = $this->input->post ( 'id' );
				$data = array (
						'id' => $id,
						'specialty' => $specialty,
						'client_id' => $client_id 
				);
				$isExistingRec = $this->master_data_model->checkSpecialty ( $specialty );
				if ($isExistingRec) {
					$statusMsg = "Speciality already exists";
				} else {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Speciality";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Speciality was added by “' . $this->loggedUserId . '”
                            		
                            Speciality: ”' . $data ['specialty'] . '”
                            		
                            		
                           Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding New specialty',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => SPECIALTIES,
						'transaction_name' => "Add New specialty",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				echo $statusMsg;
				
				break;
			case 'organization_types' :
				$type = $this->input->post ( 'orgType' );
				$id = $this->input->post ( 'id' );
				$data = array (
						'id' => $id,
						'type' => $type 
				);
				$isExistingRec = $this->master_data_model->checkOrgType ( $type );
				if (! $isExistingRec) {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Organization Type";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Organization Type was added by “' . $this->loggedUserId . '”
                            		
                            Organization Type: ”' . $data ['type'] . '”
                            		
                            		
                           Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				} else {
					$statusMsg = "Organization_Type already exists";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding New Organization Type',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => ORGANIZATION_TYPES,
						'transaction_name' => "Add New Organization Type",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				echo $statusMsg;
				break;
			case 'engagement_types' :
				$type = $this->input->post ( 'engType' );
				$id = $this->input->post ( 'id' );
				$data = array (
						'id' => $id,
						'engagement_type' => $type 
				);
				$isExistingRec = $this->master_data_model->checkEngType ( $type );
				if (! $isExistingRec) {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Engagement Type";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Engagement Type was added by “' . $this->loggedUserId . '”
                            		
                            Engagement Type: ”' . $data ['engagement_type'] . '”
                            		
                            		
                           Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				} else {
					$statusMsg = "Engagement_Type already exists";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding New Engagement Type',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => ENGAGEMENT_TYPES,
						'transaction_name' => "Add New Engagement Type",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				echo $statusMsg;
				break;
			case 'event_topics' :
				$topic = $this->input->post ( 'topic' );
				$id = $this->input->post ( 'id' );
				$data = array (
						'id' => $id,
						'name' => $topic 
				);
				$isExistingRec = $this->master_data_model->checkEventTopics ( $topic );
				if (! $isExistingRec) {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Event Topic";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Event Topic was added by “' . $this->loggedUserId . '”
                            		
                            Event Topic: ”' . $data ['name'] . '”
                            		
                            		
                           Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				} else {
					$statusMsg = "Event_Topic already exists";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding New Event Topic',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => EVENT_TOPICS,
						'transaction_name' => "Add New Event Topic",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				echo $statusMsg;
				break;
			case 'event_organizer_types' :
				$type = $this->input->post ( 'eventOrgType' );
				$id = $this->input->post ( 'id' );
				$data = array (
						'id' => $id,
						'type' => $type 
				);
				$isExistingRec = $this->master_data_model->checkEventOrgTypes ( $type );
				if (! $isExistingRec) {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Event Organizer Type";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Event Organizer Type was added by “' . $this->loggedUserId . '”
                            		
                            Event Organizer Type: ”' . $data ['type'] . '”
                            		
                            		
                           Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				} else {
					$statusMsg = "Event_Organizer_Type already exists";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding New Event Organizer Type',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => EVENT_ORGANIZER_TYPES,
						'transaction_name' => "Add New Event Organizer Type",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				echo $statusMsg;
				break;
			case 'event_roles' :
				$role = $this->input->post ( 'role' );
				$id = $this->input->post ( 'id' );
				$data = array (
						'id' => $id,
						'role' => $role 
				);
				$isExistingRec = $this->master_data_model->checkEventRole ( $role );
				if (! $isExistingRec) {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Event Role";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Event Role was added by “' . $this->loggedUserId . '”
                            		
                            Event Role: ”' . $data ['role'] . '”
                            		
                            		
                           Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				} else {
					$statusMsg = "Event_Role already exists";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding New Event Role',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => EVENT_ROLES,
						'transaction_name' => "Add New Event Role",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				echo $statusMsg;
				break;
			case 'products' :
				$product = $this->input->post ( 'product' );
				$id = $this->input->post ( 'id' );
				$cId = $this->loggedUserId;
				$data = array (
						'id' => $id,
						'name' => $product,
						'created_by' => $cId 
				);
				$isExistingRec = $this->master_data_model->checkProduct ( $product );
				if (! $isExistingRec) {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Product";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Product was added by “' . $this->loggedUserId . '”
                            		
                            Product : ”' . $data ['name'] . '”
                            		
                            		
                           Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				} else {
					$statusMsg = "Product already exists";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding New Product',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => PRODUCTS,
						'transaction_name' => "Add New Product",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				echo $statusMsg;
				break;
			case 'phone_type' :
				$phoneType = $this->input->post ( 'phoneType' );
				$id = $this->input->post ( 'id' );
				$data = array (
						'id' => $id,
						'name' => $phoneType 
				);
				$isExistingRec = $this->master_data_model->checkPhoneType ( $phoneType );
				if (! $isExistingRec) {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Phone Type";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Phone Type was added by “' . $this->loggedUserId . '”
                            		
                            Phone Type : ”' . $data ['name'] . '”
                            		
                            		
                           Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				} else {
					$statusMsg = "Phone Type already exists";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding New Phone Type',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => PHONE_TYPE,
						'transaction_name' => "Add New Phone Type",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				echo $statusMsg;
				break;
			case 'emails' :
				$emailType = $this->input->post ( 'emailType' );
				$id = $this->input->post ( 'id' );
				$data = array (
						'id' => $id,
						'type' => $emailType 
				);
				$isExistingRec = $this->master_data_model->checkEmailType ( $emailType );
				if (! $isExistingRec) {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Email Type";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Email Type was added by “' . $this->loggedUserId . '”
                            		
                            Email Type : ”' . $data ['type'] . '”
                            		
                            		
                           Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				} else {
					$statusMsg = "Email Type already exists";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding New Email Type',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => EMAILS,
						'transaction_name' => "Add New Email Type",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				echo $statusMsg;
				break;
			case 'interaction_types' :
				$discussionType = $this->input->post ( 'discussionType' );
				$id = $this->input->post ( 'id' );
				$data = array (
						'id' => $id,
						'name' => $discussionType,
						'created_by' => $this->loggedUserId 
				);
				$isExistingRec = $this->master_data_model->checkDiscussionType ( $discussionType );
				if (! $isExistingRec) {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Discussion Type";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Discussion Type was added by “' . $this->loggedUserId . '”
                            		
                            Discussion Type : ”' . $data ['name'] . '”
                            		
                            		
                           Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				} else {
					$statusMsg = "Discussion Type already exists";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding New Discussion Type',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => INTERACTION_TYPES,
						'transaction_name' => "Add New Discussion Type",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				echo $statusMsg;
				break;
			case 'interactions_topics' :
				$topic = $this->input->post ( 'topic' );
				$id = $this->input->post ( 'id' );
				$data = array (
						'id' => $id,
						'name' => $topic,
						'created_by' => $this->loggedUserId 
				);
				$isExistingRec = $this->master_data_model->checkTopic ( $topic );
				if (! $isExistingRec) {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Topic";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Topic was added by “' . $this->loggedUserId . '”
                            		
                            Topic : ”' . $data ['name'] . '”
                            		
                            		
                           Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				} else {
					$statusMsg = "Topic already exists";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding New Interaction Topic',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => INTERACTIONS_TOPICS,
						'transaction_name' => "Add New Interaction Topic",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				echo $statusMsg;
				break;
			case 'interactions_modes' :
				$interactionType = $this->input->post ( 'interactionType' );
				$id = $this->input->post ( 'id' );
				$data = array (
						'id' => $id,
						'name' => $interactionType,
						'created_by' => $this->loggedUserId 
				);
				$isExistingRec = $this->master_data_model->checkInteractionType ( $interactionType );
				if (! $isExistingRec) {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Interaction Type";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Interaction Type was added by “' . $this->loggedUserId . '”
                            		
                            Interaction Type : ”' . $data ['name'] . '”
                            		
                            		
                           Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				} else {
					$statusMsg = "Interaction Type already exists";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding New Interaction Type',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => INTERACTIONS_MODES,
						'transaction_name' => "Add New Interaction Type",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				echo $statusMsg;
				break;
			case 'interaction_location_types' :
				$interactionLocation = $this->input->post ( 'interactionLocation' );
				$id = $this->input->post ( 'id' );
				$data = array (
						'id' => $id,
						'name' => $interactionLocation,
						'created_by' => $this->loggedUserId 
				);
				$isExistingRec = $this->master_data_model->checkInteractionLocation ( $interactionLocation);
				if (! $isExistingRec) {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Interaction Location";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Interaction Location was added by “' . $this->loggedUserId . '”
                            		
                            Interaction Location : ”' . $data['name'] . '”
                            		
                            		
                           	Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				} else {
					$statusMsg = "Interaction Location already exists";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding New Interaction Location',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => INTERACTION_LOCATION_TYPES,
						'transaction_name' => "Add New Interaction Location",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				echo $statusMsg;
				break;
			case 'payments_requested_by' :
				$requestedBy = $this->input->post ( 'requestedBy' );
				$id = $this->input->post ( 'id' );
				$data = array (
						'id' => $id,
						'requested_by' => $requestedBy 
				);
				$isExistingRec = $this->master_data_model->checkRequestedBy ( $requestedBy );
				if (! $isExistingRec) {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Payment Requested By";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Payment Requested By was added by “' . $this->loggedUserId . '”
                            		
                            Requested By : ”' . $data ['requested_by'] . '”
                            		
                            		
                           	Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				} else {
					$statusMsg = "Requested By already exists";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding New Requested By',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => PAYMENTS_REQUESTED_BY,
						'transaction_name' => "Add New Requested By",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				echo $statusMsg;
				break;
			case 'payments_paid_by' :
				$paidBy = $this->input->post ( 'paidBy' );
				$id = $this->input->post ( 'id' );
				$data = array (
						'id' => $id,
						'paid_by' => $paidBy 
				);
				$isExistingRec = $this->master_data_model->checkPaidBy ( $paidBy );
				if (! $isExistingRec) {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Payment Paid By";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Payment Paid By was added by “' . $this->loggedUserId . '”
                            		
                            Payment Paid By : ”' . $data ['paid_by'] . '”
                            		
                            		
                           	Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				} else {
					$statusMsg = "Paid By already exists";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding New Paid By',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => PAYMENTS_PAID_BY,
						'transaction_name' => "Add New Paid By",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				echo $statusMsg;
				break;
			case 'payment_types' :
				$paymentType = $this->input->post ( 'paymentType' );
				$id = $this->input->post ( 'id' );
				$clientId = $this->session->userdata ( 'client_id' );
				$data = array (
						'id' => $id,
						'name' => $paymentType,
						'created_by' => $this->loggedUserId,
						'client_id' => $clientId 
				);
				$isExistingRec = $this->master_data_model->checkPaymentType ( $paymentType );
				if (! $isExistingRec) {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Payment Type";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Payment Type was added by “' . $this->loggedUserId . '”
                            		
                            Payment Type : ”' . $data ['name'] . '”
                            		
                            		
                           	Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				} else {
					$statusMsg = "Payment Type already exists";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding New Payment Type',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => PAYMENT_TYPES,
						'transaction_name' => "Add New Payment Type",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				echo $statusMsg;
				break;
			case 'payments_currency' :
				$paymentCurrency = $this->input->post ( 'paymentCurrency' );
				$currencySymbol = $this->input->post ( 'currencySymbol' );
				$id = $this->input->post ( 'id' );
				// pr($currencySymbol);exit;
				$data = array (
						'id' => $id,
						'currency_name' => $paymentCurrency,
						'currency_symbol' => $currencySymbol 
				);
				$isExistingRec = $this->master_data_model->checkPaymentCurrency ( $paymentCurrency );
				if (! $isExistingRec) {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Payment Currency";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Payment Currency was added by “' . $this->loggedUserId . '”
                            		
                            Payment Currency Name: ”' . $data ['currency_name'] . '”
                            		
                            		
                           	Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				} else {
					$statusMsg = "Payment Currency already exists";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => 'add',
						'description' => 'Adding New Payment Currency',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => PAYMENTS_CURRENCY,
						'transaction_name' => "Add New Payment Currency",
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status 
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				log_user_activity ( null, true );
				echo $statusMsg;
				break;
			case 'conf_event_types' :
				$eventType = $this->input->post ( 'eventType' );
				$id = $this->input->post ( 'id' );
				$clientId = $this->session->userdata ( 'client_id' );
				$data = array (
						'id' => $id,
						'event_type' => $eventType
				);
				$isExistingRec = $this->master_data_model->checkEventType ( $eventType);
				if (! $isExistingRec) {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Event Type";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Event Type was added by “' . $this->loggedUserId . '”
                            		
                            Event Type : ”' . $data ['event_type'] . '”
                            		
                            		
                           	Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				} else {
					$statusMsg = "Event Type already exists";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'module' => 'Master Data',
						'type' => ADD_RECORD,
						'description' => 'Adding New Event Type',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => CONF_EVENT_TYPES,
						'transaction_name' => 'Adding New Event Type',
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				echo $statusMsg;
				break;
			case 'event_sponsor_types' :
				$sponsorType = $this->input->post ( 'sponsorType' );
				$id = $this->input->post ( 'id' );
				$clientId = $this->session->userdata ( 'client_id' );
				$data = array (
						'id' => $id,
						'type' => $sponsorType
				);
				$isExistingRec = $this->master_data_model->checkSponsorType($sponsorType);
				if (! $isExistingRec) {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Sponsor Type";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Sponsor Type was added by “' . $this->loggedUserId . '”
                            		
                            Sponsor Type : ”' . $data ['type'] . '”
                            		
                            		
                           	Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				} else {
					$statusMsg = "Sponsor Type already exists";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'type' => ADD_RECORD,
						'description' => 'Adding New Sponsor Type',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => EVENT_SPONSOR_TYPES,
						'transaction_name' => 'Adding New Sponsor Type',
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				echo $statusMsg;
				break;
			case 'conf_session_types' :
				$sessionType = $this->input->post ( 'sessionType' );
				$id = $this->input->post ( 'id' );
				$clientId = $this->session->userdata ( 'client_id' );
				$data = array (
						'id' => $id,
						'session_type' => $sessionType
				);
				$isExistingRec = $this->master_data_model->checkSessionType($sessionType);
				if (! $isExistingRec) {
					$status = $this->master_data_model->saveMasterData ( $page, $data );
					if ($status) {
						$email = RECEIVER;
						$subject = "Notification about the creation of the new Session Type";
						$content = 'Hi ' . "" . ' <br/>
                            This email is to notify you that the new Session Type was added by “' . $this->loggedUserId . '”
                            		
                            Session Type : ”' . $data ['session_type'] . '”
                            		
                            		
                           	Regards,
                            		
                           Aissel Support Team';
						
						$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
					}
					$statusMsg = $status ? "Saved Successfully" : "Saving Failed";
				} else {
					$statusMsg = "Session Type already exists";
				}
				// Add log activity
				$requestStatus = FAILURE;
				if ($status) {
					$requestStatus = SUCCESS;
				}
				$formData = $_POST;
				$formData = json_encode ( $formData );
				$arrLogDetails = array (
						'type' => ADD_RECORD,
						'description' => 'Adding New Session Type',
						'status' => $requestStatus,
						'file_name' => 'master_data_controller',
						'transaction_id' => $status,
						'transaction_table_id' => CONF_SESSION_TYPES,
						'transaction_name' => 'Adding New Session Type',
						'client_id' => $client_id,
						'user_id' => $userId,
						'form_data' => $formData,
						'parent_object_id' => $status
				);
				$this->config->set_item ( 'log_details', $arrLogDetails );
				echo $statusMsg;
				break;
		}
	}
	// delete data
	function delete_master_data($page) {
		$id = $this->input->post ( 'id' );
		$status = $this->master_data_model->deleteMasterData ( $page, $id );
		$pages = strtoupper ( $page );
		$client_id = $this->session->userdata ( 'client_id' );
		$userId = $this->session->userdata ( 'user_id' );
		// Add log activity
		$requestStatus = FAILURE;
		if ($status) {
			$requestStatus = SUCCESS;
		}
		$arrLogDetails = array (
				'type' => DELET_RECORD,
				'description' => 'deleting ' . $page . ' data',
				'status' => $requestStatus,
				'file_name' => 'master_data_controller',
				'transaction_id' => $id,
				'transaction_table_id' => constant ( $pages ),
				'transaction_name' => "delete " . $page,
				'client_id' => $client_id,
				'user_id' => $userId,
				'parent_object_id' => $id 
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		echo $status ? "Deleted Successfully" : "Deletion Failed";
	}
	// check the associated master data
	function check_master_association($table) {
		$id = $this->input->post ( 'id' );
		$isExistingRec = $this->master_data_model->checkAssociation ( $id, $table );
		if ($isExistingRec) {
			$statusMsg = $isExistingRec;
		} else {
			$statusMsg = 0;
		}
		echo $statusMsg;
	}
	function upload_zip_file() {
		// $path_info = pathinfo($_FILES["overview_import"]['name']);
		$ids = $this->input->post('clientIds');
		$data["clientIds"] = implode(",",$ids);
		//pr($data["clientIds"]);exit;
		$dest = $_SERVER ['DOCUMENT_ROOT'] . "/" . $this->config->item ( 'app_folder_path' ) . "documents/imports/master_imports/uploaded/" . $_FILES ["master_import"] ['name'];
		move_uploaded_file ( $_FILES ["master_import"] ['tmp_name'], $dest );
		$name = substr ( $_FILES ["master_import"] ['name'], 0, - 4 );
		$this->load->library ( 'unzip' );
		$this->unzip->extract ( $dest, $_SERVER ['DOCUMENT_ROOT'] . "/" . $this->config->item ( 'app_folder_path' ) . "documents/imports/master_imports/uploaded/" );
		
		$arrUHFiles = array ();
		$payerPath = $_SERVER ['DOCUMENT_ROOT'] . "/" . $this->config->item ( 'app_folder_path' ) . "documents/imports/master_imports/uploaded/";
		if ($handle = opendir ( $payerPath )) {
			/* This is the correct way to loop over the directory. */
			
			$chk = substr ( $entry, - 4 );
			if ($chk != '.zip') {
				if (is_dir ( $_SERVER ['DOCUMENT_ROOT'] . "/" . $this->config->item ( 'app_folder_path' ) . "documents/imports/master_imports/uploaded/" . $name )) {
					if ($handle1 = opendir ( $_SERVER ['DOCUMENT_ROOT'] . "/" . $this->config->item ( 'app_folder_path' ) . "documents/imports/master_imports/uploaded/" . $name )) {
						
						while ( false !== ($entry1 = readdir ( $handle1 )) ) {
							echo $entry1;
							if ($entry1 != '.' && $entry1 != '..' && $entry1 != '.svn') {
								$arrUHFiles [$name] [] = $entry1;
							}
						}
					}
				}
			}
		}
		//$data ['clientIds'] = $id;
		$data ['arrMasters'] = $arrUHFiles;
		$data ['contentPage'] = 'master_data/list_master_import_files';
		$this->load->view ( 'layouts/analyst_view', $data );
	}
	function delete_files() {
		$uploadedPath = $_SERVER ['DOCUMENT_ROOT'] . "/" . $this->config->item ( 'app_folder_path' ) . "documents/imports/master_imports/uploaded/";
		$arrFiles = $this->input->post ( 'files' );
		$arrFolders = $this->input->post ( 'folders' );
		// pr($arrFiles);
		foreach ( $arrFiles as $row ) {
			$pos = strpos ( $row, '&' );
			$folderNAme = substr ( $row, 0, $pos );
			$files [$folderNAme] [] = substr ( $row, $pos + 1 );
		}
		
		foreach ( $files as $folder => $fileNames ) {
			
			foreach ( $fileNames as $fileName ) {
				unlink ( $uploadedPath . $folder . "/" . $fileName );
			}
		}
		
		foreach ( $arrFolders as $folderName ) {
			rmdir ( $uploadedPath . $folderName );
			
			unlink ( $uploadedPath . $folderName . ".zip" );
		}
	}
	//importing master data values
	function import_multiple_master_data() {
		$initialTime = microtime ( true );
		// ini_set("max_execution_time", 7200);
		ini_set ( 'memory_limit', "-1" );
		ini_set ( "max_execution_time", 0 );
		// Load the plugin
		$clientIds = $this->input->post ( 'clientIds' );
		$clients = explode(",", $clientIds);
		//pr($clients);exit;
		$files = $this->input->post ( 'files' );
		$arrFiles = array ();
		foreach ( $files as $row ) {
			$row = str_replace ( ';', '', $row );
			$pos = strpos ( $row, '&' );
			$folderNAme = substr ( $row, 0, $pos );
			$arrFiles [$folderNAme] [] = substr ( $row, $pos + 1 );
		}
		
		$this->load->plugin ( 'excelReader/reader2' );
		$currentMethod = $this->input->post ( 'methodName' );
		$userId = $this->session->userdata ( 'user_id' );
		$clientId = $this->session->userdata ( 'client_id' );
		$arrSpecialitys = $this->specialty->getAllSpecialties ();
		$arrEventRoles = $this->Event_helper->getEventRoles ();
		$arrEventTypes = $this->Event_helper->getEventTypes();
		$arrEventOrganizerTypes = $this->Event_helper->getOrganizerTypes ();
		$arrOrganizationTypes = $this->Organization->getAllOrganizationTypes ();
		
		foreach ( $arrFiles as $folder => $filename ) {
			$folderLocation = $_SERVER ['DOCUMENT_ROOT'] . "/" . $this->config->item ( 'app_folder_path' ) . "documents/imports/master_imports/uploaded/" . $folder;
			foreach ( $filename as $file1 ) {
				$arrImportStatusMsg [$file1] = array ();
				$uploadedFile = $folderLocation . "/" . $file1;
				
				$reader = new Spreadsheet_Excel_Reader ( $uploadedFile, true, 'utf-8' );
				// Dump the EXCEL data for debugging
				// Prepare the data required fileds
				// To Read the sheet name and its index
				
				foreach ( $reader->boundsheets as $k => $sheet ) {
					// pr ( $sheet ['name'] );exit ();
					switch ($sheet ['name']) {
						case "specialty" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "Specialty") {
								$arrImportStatusMsg [$file1] ['specialty'] ['incorrect_format'] = 'specialty Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$arrMasterDataDetails ['specialty'] = array_search ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ), $arrSpecialitys );
								if (! $arrMasterDataDetails ['specialty']) {
									$sep = array (
											"specialty" => trim ( $reader->sheets [$k] ["cells"] [$row] [1] ),
											"client_id" => INTERNAL_CLIENT_ID,
											"all" => 1 
									);
									$sep_id = $this->kol->saveSpecialty ( $sep ); // save specialty if not exists
									if ($sep_id) {
										$email = RECEIVER;
										$subject = "Notification about the creation of the new Speciality";
										$content = 'Hi ' . "" . ' <br/>
					                            This email is to notify you that the new Speciality was added by “' . $this->loggedUserId . '”
					                            		
					                            Speciality: ”' . $sep ['specialty'] . '”
					                            		
					                            		
					                           Regards,
					                            		
					                           Aissel Support Team';
										
										$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
										// Add log activity
										$requestStatus = FAILURE;
										if ($sep_id) {
											$requestStatus = SUCCESS;
										}
										$formData = $_POST;
										$formData = json_encode ( $formData );
										$arrLogDetails = array (
												'module' => 'Master Data',
												'type' => 'add',
												'description' => 'Adding  a particular specialty',
												'status' => $requestStatus,
												'file_name' => 'master_data_controller',
												'transaction_id' => $sep_id,
												'transaction_table_id' => SPECIALTIES,
												'transaction_name' => "Add  specialty",
												'client_id' => $clientId,
												'user_id' => $userId,
												'form_data' => $formData,
												'parent_object_id' => $sep_id 
										);
										$this->config->set_item ( 'log_details', $arrLogDetails );
										log_user_activity ( null, true );
									}
									$i = 0;
									$successCount = 0;
									$table = 'specialty_client_association';
									while ( $clients [$i] != null ) {
										$data = array (
												'specialty_id' => $sep_id,
												'client_id' => $clients [$i ++] 
										);
										$status = $this->master_data_model->saveClientSpecialty ($table, $data);
										if ($status) {
											$successCount ++;
										}
									}
									// Add log activity
									$requestStatus = FAILURE;
									if ($status) {
										$requestStatus = SUCCESS;
									}
									$formData = $_POST;
									$formData = json_encode ( $formData );
									$arrLogDetails = array (
											'module' => 'Master Data',
											'type' => 'add',
											'description' => 'Adding associated clients to a particular specialty',
											'status' => $requestStatus,
											'file_name' => 'master_data_controller',
											'transaction_id' => $sep_id,
											'transaction_table_id' => SPECIALTY_CLIENT_ASSOCIATION,
											'transaction_name' => "Add associated clients to specialty",
											'client_id' => $clientId,
											'user_id' => $userId,
											'form_data' => $formData,
											'parent_object_id' => $sep_id 
									);
									$this->config->set_item ( 'log_details', $arrLogDetails );
									log_user_activity ( null, true );
									$arrMasterDataDetails ['specialty'] = $sep_id;
								}
							}
							break;
						case "titles" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "Title") {
								$arrImportStatusMsg [$file1] ['title'] ['incorrect_format'] = 'title Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$arrMasterDataDetails ['title'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
								if (! empty ( $arrMasterDataDetails ['title'] )) {
									$titleId = $this->kol->saveTitle ( $arrMasterDataDetails ['title'] ); // save title if not exists / if exsits get id
									                                                                  // pr($titleId);exit;
									if ($titleId) {
										$email = RECEIVER;
										$subject = "Notification about the creation of the new Title";
										$content = 'Hi ' . "" . ' <br/>
					                            This email is to notify you that the new Title was added by “' . $this->loggedUserId . '”
					                            		
					                            Title: ”' . $arrMasterDataDetails ['title'] . '”
					                            		
					                            		
					                           Regards,
					                            		
					                           Aissel Support Team';
										
										$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
										// Add log activity
										$requestStatus = FAILURE;
										if ($titleId) {
											$requestStatus = SUCCESS;
										}
										$formData = $_POST;
										$formData = json_encode ( $formData );
										$arrLogDetails = array (
												'module' => 'Master Data',
												'type' => 'add',
												'description' => 'Adding  a particular title',
												'status' => $requestStatus,
												'file_name' => 'master_data_controller',
												'transaction_id' => $titleId,
												'transaction_table_id' => TITLES,
												'transaction_name' => "Add title",
												'client_id' => $clientId,
												'user_id' => $userId,
												'form_data' => $formData,
												'parent_object_id' => $titleId 
										);
										$this->config->set_item ( 'log_details', $arrLogDetails );
										log_user_activity ( null, true );
									}
									$i = 0;
									$successCount = 0;
									$table = 'title_client_mappings';
									while ( $clients [$i] != null ) {
										$data = array (
												'title_id' => $titleId,
												'client_id' => $clients [$i ++] 
										);
										$status = $this->master_data_model->saveClientSpecialty ($table, $data);
										if ($status) {
											$successCount ++;
										}
									}
									// Add log activity
									$requestStatus = FAILURE;
									if ($status) {
										$requestStatus = SUCCESS;
									}
									$formData = $_POST;
									$formData = json_encode ( $formData );
									$arrLogDetails = array (
											'module' => 'Master Data',
											'type' => 'add',
											'description' => 'Adding associated clients to a particular title',
											'status' => $requestStatus,
											'file_name' => 'master_data_controller',
											'transaction_id' => $titleId,
											'transaction_table_id' => TITLE_CLIENT_MAPPING,
											'transaction_name' => "Add associated clients to title",
											'client_id' => $clientId,
											'user_id' => $userId,
											'form_data' => $formData,
											'parent_object_id' => $titleId 
									);
									$this->config->set_item ( 'log_details', $arrLogDetails );
									log_user_activity ( null, true );
								}
							}
							break;
						case "engagement_types" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "EngagementType") {
								$arrImportStatusMsg [$file1] ['engagement_type'] ['incorrect_format'] = 'engagement type Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$this->load->model ( 'Engagement_type' );
								$engagement = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
								$engagementId = $this->Engagement_type->getEngagementId ( $engagement );
								// pr($engagementId);exit;
								if (! $engagementId) {
									$arrEngagementType ['engagement_type'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
									if ($this->db->insert ( 'engagement_types', $arrEngagementType )) {
										$engagementType = $this->db->insert_id ();
										if ($engagementType) {
											$email = RECEIVER;
											$subject = "Notification about the creation of the new Engagement Type";
											$content = 'Hi ' . "" . ' <br/>
					                            This email is to notify you that the new Engagement Type was added by “' . $this->loggedUserId . '”
					                            		
					                            Engagement Type: ”' . $arrEngagementType ['engagement_type'] . '”
					                            		
					                            		
					                           Regards,
					                            		
					                           Aissel Support Team';
											
											$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
										}
									} else {
										$engagementType = "";
									}
								}
								if ($engagementId) {
									$arrMasterDataDetails ['engagement_id'] = $engagementId;
								}
								// Add log activity
								$requestStatus = FAILURE;
								if ($engagementType) {
									$requestStatus = SUCCESS;
								}
								$formData = $_POST;
								$formData = json_encode ( $formData );
								$arrLogDetails = array (
										'module' => 'Master Data',
										'type' => 'add',
										'description' => 'Adding engagement type',
										'status' => $requestStatus,
										'file_name' => 'master_data_controller',
										'transaction_id' => $engagementId,
										'transaction_table_id' => ENGAGEMENT_TYPES,
										'transaction_name' => "Add engagement type",
										'client_id' => $clientId,
										'user_id' => $userId,
										'form_data' => $formData,
										'parent_object_id' => $engagementId 
								);
								$this->config->set_item ( 'log_details', $arrLogDetails );
								log_user_activity ( null, true );
							}
							break;
						case "event_roles" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "EventRole") {
								$arrImportStatusMsg [$file1] ['event_role'] ['incorrect_format'] = 'event role Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$eventRole = array_search ( ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) ), $arrEventRoles );
								if (! $eventRole) {
									$arrEventRole ['role'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
									if ($this->db->insert ( 'event_roles', $arrEventRole )) {
										$eventRole = $this->db->insert_id ();
										if ($eventRole) {
											$email = RECEIVER;
											$subject = "Notification about the creation of the new Event Role";
											$content = 'Hi ' . "" . ' <br/>
					                            This email is to notify you that the new Event Role was added by “' . $this->loggedUserId . '”
					                            		
					                            Event Role: ”' . $arrEventRole ['role'] . '”
					                            		
					                            		
					                           Regards,
					                            		
					                           Aissel Support Team';
											
											$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
										}
									} else {
										$eventRole = "";
									}
								}
								$arrMasterDataDetails ['role'] = $eventRole;
								// Add log activity
								$requestStatus = FAILURE;
								if ($eventRole) {
									$requestStatus = SUCCESS;
								}
								$formData = $_POST;
								$formData = json_encode ( $formData );
								$arrLogDetails = array (
										'module' => 'Master Data',
										'type' => 'add',
										'description' => 'Adding event role',
										'status' => $requestStatus,
										'file_name' => 'master_data_controller',
										'transaction_id' => $eventRole,
										'transaction_table_id' => EVENT_ROLES,
										'transaction_name' => "Add event role",
										'client_id' => $clientId,
										'user_id' => $userId,
										'form_data' => $formData,
										'parent_object_id' => $eventRole 
								);
								$this->config->set_item ( 'log_details', $arrLogDetails );
								log_user_activity ( null, true );
							}
							break;
						case "event_topics" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "EventTopic") {
								$arrImportStatusMsg [$file1] ['event_topic'] ['incorrect_format'] = 'event topic Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$topic = '';
								$topicId = '';
								$topic = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
								if ($topic != '') {
									$topicId = $this->kol->getTopicId ( $topic );
									if ($topicId == 0) {
										$arrEventTopic ['name'] = $topic;
										if ($this->db->insert ( 'event_topics', $arrEventTopic )) {
											$topicId = $this->db->insert_id ();
											if ($topicId) {
												$email = RECEIVER;
												$subject = "Notification about the creation of the new Event Topic";
												$content = 'Hi ' . "" . ' <br/>
					                            This email is to notify you that the new Event Topic was added by “' . $this->loggedUserId . '”
					                            		
					                            Event Topic: ”' . $arrEventTopic ['name'] . '”
					                            		
					                            		
						                           Regards,
					                            		
						                           Aissel Support Team';
												
												$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
											}
										}
									}
								}
								$arrMasterDataDetails ['topic'] = $topicId;
								// Add log activity
								$requestStatus = FAILURE;
								if ($topicId) {
									$requestStatus = SUCCESS;
								}
								$formData = $_POST;
								$formData = json_encode ( $formData );
								$arrLogDetails = array (
										'module' => 'Master Data',
										'type' => 'add',
										'description' => 'Adding event topic',
										'status' => $requestStatus,
										'file_name' => 'master_data_controller',
										'transaction_id' => $topicId,
										'transaction_table_id' => EVENT_TOPICS,
										'transaction_name' => "Add event topic",
										'client_id' => $clientId,
										'user_id' => $userId,
										'form_data' => $formData,
										'parent_object_id' => $topicId 
								);
								$this->config->set_item ( 'log_details', $arrLogDetails );
								log_user_activity ( null, true );
							}
							break;
						case "event_organizer_types" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "Type") {
								$arrImportStatusMsg [$file1] ['event_organizer_types'] ['incorrect_format'] = 'event organizer types Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$oranizerType = array_search ( ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) ), $arrEventOrganizerTypes );
								if (! $oranizerType) {
									$arrOrganizerType ['type'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
									if ($this->db->insert ( 'event_organizer_types', $arrOrganizerType )) {
										$oranizerType = $this->db->insert_id ();
										if ($oranizerType) {
											$email = RECEIVER;
											$subject = "Notification about the creation of the new Event Organizer Type";
											$content = 'Hi ' . "" . ' <br/>
					                            This email is to notify you that the new Event Organizer Type was added by “' . $this->loggedUserId . '”
					                            		
					                            Event Organizer Type: ”' . $arrOrganizerType ['type'] . '”
					                            		
					                            		
					                           Regards,
					                            		
					                           Aissel Support Team';
											
											$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
										}
									} else {
										$oranizerType = "";
									}
								}
								
								$arrMasterDataDetails ['organizer_type'] = $oranizerType;
								// Add log activity
								$requestStatus = FAILURE;
								if ($oranizerType) {
									$requestStatus = SUCCESS;
								}
								$formData = $_POST;
								$formData = json_encode ( $formData );
								$arrLogDetails = array (
										'module' => 'Master Data',
										'type' => 'add',
										'description' => 'Adding event organizer type',
										'status' => $requestStatus,
										'file_name' => 'master_data_controller',
										'transaction_id' => $oranizerType,
										'transaction_table_id' => EVENT_ORGANIZER_TYPES,
										'transaction_name' => "Add event organizer type",
										'client_id' => $clientId,
										'user_id' => $userId,
										'form_data' => $formData,
										'parent_object_id' => $oranizerType 
								);
								$this->config->set_item ( 'log_details', $arrLogDetails );
								log_user_activity ( null, true );
							}
							break;
						case "organization_types" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "OrgType") {
								$arrImportStatusMsg [$file1] ['organization_type'] ['incorrect_format'] = 'organization type Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$orgType = array_search ( ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) ), $arrOrganizationTypes );
								if (! $orgType) {
									$arrOrganizationType ['type'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
									if ($this->db->insert ( 'organization_types', $arrOrganizationType )) {
										$oranizationType = $this->db->insert_id ();
										if ($oranizationType) {
											$email = RECEIVER;
											$subject = "Notification about the creation of the new Organization Type";
											$content = 'Hi ' . "" . ' <br/>
					                            This email is to notify you that the new Organization Type was added by “' . $this->loggedUserId . '”
					                            		
					                            Organization Type: ”' . $arrOrganizationType ['type'] . '”
					                            		
					                            		
					                           Regards,
					                            		
					                           Aissel Support Team';
											
											$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
										}
									} else {
										$oranizationType = "";
									}
								}
								
								$arrMasterDataDetails ['organization_type'] = $oranizationType;
								// Add log activity
								$requestStatus = FAILURE;
								if ($oranizationType) {
									$requestStatus = SUCCESS;
								}
								$formData = $_POST;
								$formData = json_encode ( $formData );
								$arrLogDetails = array (
										'module' => 'Master Data',
										'type' => 'add',
										'description' => 'Adding organiztion type',
										'status' => $requestStatus,
										'file_name' => 'master_data_controller',
										'transaction_id' => $oranizationType,
										'transaction_table_id' => ORGANIZATION_TYPES,
										'transaction_name' => "Add organiztion type",
										'client_id' => $clientId,
										'user_id' => $userId,
										'form_data' => $formData,
										'parent_object_id' => $oranizationType 
								);
								$this->config->set_item ( 'log_details', $arrLogDetails );
								log_user_activity ( null, true );
							}
							break;
						case "products" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "ProductName") {
								$arrImportStatusMsg [$file1] ['product'] ['incorrect_format'] = 'product Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$product = array_search ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
								//pr($product);exit;
								$isExistingRec = $this->master_data_model->checkProduct (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ));
								//pr($isExistingRec);exit;
								if (!$isExistingRec) {
									$arrproduct ['name'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
									if ($this->db->insert ( 'products', $arrproduct )) {
										$pro_id = $this->db->insert_id ();
										if ($pro_id) {
											$email = RECEIVER;
											$subject = "Notification about the creation of the new Product";
											$content = 'Hi ' . "" . ' <br/>
                           						 This email is to notify you that the new Product was added by “' . $this->loggedUserId . '”
                            		
                           						 Product : ”' . $arrproduct ['name'] . '”
                            		
                            		
                        						  Regards,
                            		
                       							   Aissel Support Team';
											
											$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
											// Add log activity
											$requestStatus = FAILURE;
											if ($pro_id) {
												$requestStatus = SUCCESS;
											}
											$formData = $_POST;
											$formData = json_encode ( $formData );
											$arrLogDetails = array (
													'module' => 'Master Data',
													'type' => 'add',
													'description' => 'Adding  a particular product',
													'status' => $requestStatus,
													'file_name' => 'master_data_controller',
													'transaction_id' => $pro_id,
													'transaction_table_id' => PRODUCTS,
													'transaction_name' => "Add  product",
													'client_id' => $clientId,
													'user_id' => $userId,
													'form_data' => $formData,
													'parent_object_id' => $pro_id 
											);
											$this->config->set_item ( 'log_details', $arrLogDetails );
											log_user_activity ( null, true );
										}
									}
									$i = 0;
									$successCount = 0;
									$table = 'products_client_visibility';
									while ( $clients [$i] != null ) {
										$data = array (
												'products_id' => $pro_id,
												'client_id' => $clients [$i ++] 
										);
										$status = $this->master_data_model->saveClientSpecialty ($table, $data);
										if ($status) {
											$successCount ++;
										}
									}
									// Add log activity
									$requestStatus = FAILURE;
									if ($status) {
										$requestStatus = SUCCESS;
									}
									$formData = $_POST;
									$formData = json_encode ( $formData );
									$arrLogDetails = array (
											'module' => 'Master Data',
											'type' => 'add',
											'description' => 'Adding associated clients to a particular product',
											'status' => $requestStatus,
											'file_name' => 'master_data_controller',
											'transaction_id' => $pro_id,
											'transaction_table_id' => PRODUCTS_CLIENT_VISIBILITY,
											'transaction_name' => "Add associated clients to product",
											'client_id' => $clientId,
											'user_id' => $userId,
											'form_data' => $formData,
											'parent_object_id' => $pro_id 
									);
									$this->config->set_item ( 'log_details', $arrLogDetails );
									log_user_activity ( null, true );
									$arrMasterDataDetails ['product'] = $pro_id;
								}
							}
							break;
						case "phone_type" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "PhoneType") {
								$arrImportStatusMsg [$file1] ['phone_type'] ['incorrect_format'] = 'phone type Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$phone = array_search ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
								//pr($phone);exit;
								$isExistingRec = $this->master_data_model->checkPhoneType ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ));
								if (!$isExistingRec) {
									$arrphone ['name'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
									if ($this->db->insert ( 'phone_type', $arrphone )) {
										$phone_id = $this->db->insert_id ();
										if ($phone_id) {
											$email = RECEIVER;
											$subject = "Notification about the creation of the new Phone Type";
											$content = 'Hi ' . "" . ' <br/>
                           						 This email is to notify you that the new Phone Type was added by “' . $this->loggedUserId . '”
                           						 		
                           						 Phone Type : ”' . $arrphone ['name'] . '”
                           						 		
                           						 		
                        						  Regards,
                           						 		
                       							   Aissel Support Team';
											
											$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
											// Add log activity
											$requestStatus = FAILURE;
											if ($phone_id) {
												$requestStatus = SUCCESS;
											}
											$formData = $_POST;
											$formData = json_encode ( $formData );
											$arrLogDetails = array (
													'module' => 'Master Data',
													'type' => 'add',
													'description' => 'Adding  a particular phone type',
													'status' => $requestStatus,
													'file_name' => 'master_data_controller',
													'transaction_id' => $phone_id,
													'transaction_table_id' => PHONE_TYPE,
													'transaction_name' => "Add  phone type",
													'client_id' => $clientId,
													'user_id' => $userId,
													'form_data' => $formData,
													'parent_object_id' => $phone_id 
											);
											$this->config->set_item ( 'log_details', $arrLogDetails );
											log_user_activity ( null, true );
										}
									}
									$i = 0;
									$successCount = 0;
									$table = 'phone_type_client_visibility';
									while ( $clients [$i] != null ) {
										$data = array (
												'phone_type_id' => $phone_id,
												'client_id' => $clients [$i ++] 
										);
										$status = $this->master_data_model->saveClientSpecialty ($table, $data);
										if ($status) {
											$successCount ++;
										}
									}
									// Add log activity
									$requestStatus = FAILURE;
									if ($status) {
										$requestStatus = SUCCESS;
									}
									$formData = $_POST;
									$formData = json_encode ( $formData );
									$arrLogDetails = array (
											'module' => 'Master Data',
											'type' => 'add',
											'description' => 'Adding associated clients to a particular phone type',
											'status' => $requestStatus,
											'file_name' => 'master_data_controller',
											'transaction_id' => $phone_id,
											'transaction_table_id' => PHONE_TYPE_CLIENT_VISIBILITY,
											'transaction_name' => "Add associated clients to phone type",
											'client_id' => $clientId,
											'user_id' => $userId,
											'form_data' => $formData,
											'parent_object_id' => $phone_id 
									);
									$this->config->set_item ( 'log_details', $arrLogDetails );
									log_user_activity ( null, true );
									$arrMasterDataDetails ['phone_type'] = $pro_id;
								}
							}
							break;
						case "email_type" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "EmailType") {
								$arrImportStatusMsg [$file1] ['email_type'] ['incorrect_format'] = 'email type Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$email = array_search ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
								$isExistingRec = $this->master_data_model->checkEmailType(trim ( $reader->sheets [$k] ["cells"] [$row] [1] ));
								if (!$isExistingRec) {
									$arremail ['type'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
									if ($this->db->insert ( 'emails', $arremail)) {
										$email_id = $this->db->insert_id ();
										if ($email_id) {
											$email = RECEIVER;
											$subject = "Notification about the creation of the new Email Type";
											$content = 'Hi ' . "" . ' <br/>
                           						 This email is to notify you that the new Email Type was added by “' . $this->loggedUserId . '”
                           						 		
                           						 Email Type : ”' . $arremail ['type']. '”
                           						 		
                           						 		
                        						  Regards,
                           						 		
                       							   Aissel Support Team';
											
											$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
											// Add log activity
											$requestStatus = FAILURE;
											if ($email_id) {
												$requestStatus = SUCCESS;
											}
											$formData = $_POST;
											$formData = json_encode ( $formData );
											$arrLogDetails = array (
													'module' => 'Master Data',
													'type' => 'add',
													'description' => 'Adding  a particular email type',
													'status' => $requestStatus,
													'file_name' => 'master_data_controller',
													'transaction_id' => $email_id,
													'transaction_table_id' => EMAILS,
													'transaction_name' => "Add  email type",
													'client_id' => $clientId,
													'user_id' => $userId,
													'form_data' => $formData,
													'parent_object_id' => $email_id
											);
											$this->config->set_item ( 'log_details', $arrLogDetails );
											log_user_activity ( null, true );
										}
									}
									$i = 0;
									$successCount = 0;
									$table = 'emails_client_visibility';
									while ( $clients [$i] != null ) {
										$data = array (
												'emails_id' => $email_id,
												'client_id' => $clients [$i ++]
										);
										$status = $this->master_data_model->saveClientSpecialty ($table, $data);
										if ($status) {
											$successCount ++;
										}
									}
									// Add log activity
									$requestStatus = FAILURE;
									if ($status) {
										$requestStatus = SUCCESS;
									}
									$formData = $_POST;
									$formData = json_encode ( $formData );
									$arrLogDetails = array (
											'module' => 'Master Data',
											'type' => 'add',
											'description' => 'Adding associated clients to a particular email type',
											'status' => $requestStatus,
											'file_name' => 'master_data_controller',
											'transaction_id' => $email_id,
											'transaction_table_id' => EMAILS_CLIENT_VISIBILITY,
											'transaction_name' => "Add associated clients to email type",
											'client_id' => $clientId,
											'user_id' => $userId,
											'form_data' => $formData,
											'parent_object_id' => $email_id
									);
									$this->config->set_item ( 'log_details', $arrLogDetails );
									log_user_activity ( null, true );
									$arrMasterDataDetails ['email_type'] = $email_id;
								}
							}
							break;
						case "discussion_types" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "Name") {
								$arrImportStatusMsg [$file1] ['discussion_type'] ['incorrect_format'] = 'discussion type Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$discussionType = array_search ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
								$isExistingRec = $this->master_data_model->checkDiscussionType(trim ( $reader->sheets [$k] ["cells"] [$row] [1] ));
								if (!$isExistingRec) {
									$arrdis ['name'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
									if ($this->db->insert ( 'interaction_types', $arrdis)) {
										$discussion_id = $this->db->insert_id ();
										if ($discussion_id) {
											$email = RECEIVER;
											$subject = "Notification about the creation of the new Discussion Type";
											$content = 'Hi ' . "" . ' <br/>
                           						 This email is to notify you that the new Discussion Type was added by “' . $this->loggedUserId . '”
                           						 		
                           						 Discussion Type : ”' . $arrdis['name']. '”
                           						 		
                           						 		
                        						  Regards,
                           						 		
                       							   Aissel Support Team';
											
											$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
											// Add log activity
											$requestStatus = FAILURE;
											if ($status) {
												$requestStatus = SUCCESS;
											}
											$formData = $_POST;
											$formData = json_encode ( $formData );
											$arrLogDetails = array (
													'module' => 'Master Data',
													'type' => 'add',
													'description' => 'Adding  a particular discussion type',
													'status' => $requestStatus,
													'file_name' => 'master_data_controller',
													'transaction_id' => $discussion_id,
													'transaction_table_id' => INTERACTION_TYPES,
													'transaction_name' => "Add  discussion type",
													'client_id' => $clientId,
													'user_id' => $userId,
													'form_data' => $formData,
													'parent_object_id' => $discussion_id
											);
											$this->config->set_item ( 'log_details', $arrLogDetails );
											log_user_activity ( null, true );
										}
									}
									$i = 0;
									$successCount = 0;
									$table = 'interaction_types_client_visibility';
									while ( $clients [$i] != null ) {
										$data = array (
												'interaction_types_id' => $discussion_id,
												'client_id' => $clients [$i ++]
										);
										$status = $this->master_data_model->saveClientSpecialty ($table, $data);
										if ($status) {
											$successCount ++;
										}
									}
									// Add log activity
									$requestStatus = FAILURE;
									if ($discussion_id) {
										$requestStatus = SUCCESS;
									}
									$formData = $_POST;
									$formData = json_encode ( $formData );
									$arrLogDetails = array (
											'module' => 'Master Data',
											'type' => 'add',
											'description' => 'Adding associated clients to a particular discussion type',
											'status' => $requestStatus,
											'file_name' => 'master_data_controller',
											'transaction_id' => $discussion_id,
											'transaction_table_id' => EMAILS_CLIENT_VISIBILITY,
											'transaction_name' => "Add associated clients to discussion type",
											'client_id' => $clientId,
											'user_id' => $userId,
											'form_data' => $formData,
											'parent_object_id' => $discussion_id
									);
									$this->config->set_item ( 'log_details', $arrLogDetails );
									log_user_activity ( null, true );
									$arrMasterDataDetails ['discussion_type'] = $discussion_id;
								}
							}
							break;
						case "topics" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "Name") {
								$arrImportStatusMsg [$file1] ['topics'] ['incorrect_format'] = 'interaction topic Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$topics= array_search ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
								$isExistingRec = $this->master_data_model->checkTopic(trim ( $reader->sheets [$k] ["cells"] [$row] [1] ));
								if (!$isExistingRec) {
									$arrtopics ['name'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
									if ($this->db->insert ('interactions_topics', $arrtopics)) {
										$topic_id = $this->db->insert_id ();
										if ($topic_id) {
											$email = RECEIVER;
											$subject = "Notification about the creation of the new Interactions Topics";
											$content = 'Hi ' . "" . ' <br/>
                           						 This email is to notify you that the new Interactions Topics was added by “' . $this->loggedUserId . '”
                           						 		
                           						 Interactions Topics : ”' . $arrtopics ['name']. '”
                           						 		
                           						 		
                        						  Regards,
                           						 		
                       							   Aissel Support Team';
											
											$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
											// Add log activity
											$requestStatus = FAILURE;
											if ($topic_id) {
												$requestStatus = SUCCESS;
											}
											$formData = $_POST;
											$formData = json_encode ( $formData );
											$arrLogDetails = array (
													'module' => 'Master Data',
													'type' => 'add',
													'description' => 'Adding  a particular Interactions Topics',
													'status' => $requestStatus,
													'file_name' => 'master_data_controller',
													'transaction_id' => $topic_id,
													'transaction_table_id' => INTERACTIONS_TOPICS,
													'transaction_name' => "Add  Interactions Topics",
													'client_id' => $clientId,
													'user_id' => $userId,
													'form_data' => $formData,
													'parent_object_id' => $topic_id
											);
											$this->config->set_item ( 'log_details', $arrLogDetails );
											log_user_activity ( null, true );
										}
									}
									$i = 0;
									$successCount = 0;
									$table = 'interactions_topics_client_visibility';
									while ( $clients [$i] != null ) {
										$data = array (
												'interactions_topics_id' => $topic_id,
												'client_id' => $clients [$i ++]
										);
										$status = $this->master_data_model->saveClientSpecialty ($table, $data);
										if ($status) {
											$successCount ++;
										}
									}
									// Add log activity
									$requestStatus = FAILURE;
									if ($status) {
										$requestStatus = SUCCESS;
									}
									$formData = $_POST;
									$formData = json_encode ( $formData );
									$arrLogDetails = array (
											'module' => 'Master Data',
											'type' => 'add',
											'description' => 'Adding associated clients to a particular Interactions Topics',
											'status' => $requestStatus,
											'file_name' => 'master_data_controller',
											'transaction_id' => $topic_id,
											'transaction_table_id' => INTERACTIONS_TOPICS_CLIENT_VISIBILITY,
											'transaction_name' => "Add associated clients to Interactions Topics",
											'client_id' => $clientId,
											'user_id' => $userId,
											'form_data' => $formData,
											'parent_object_id' => $topic_id
									);
									$this->config->set_item ( 'log_details', $arrLogDetails );
									log_user_activity ( null, true );
									$arrMasterDataDetails ['interactions_topics'] = $topic_id;
								}
							}
							break;
						case "interaction_type" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "Name") {
								$arrImportStatusMsg [$file1] ['interaction_type'] ['incorrect_format'] = 'interaction type Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$intType = array_search ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
								$isExistingRec = $this->master_data_model->checkInteractionType(trim ( $reader->sheets [$k] ["cells"] [$row] [1] ));
								if (!$isExistingRec) {
									$arrmodes ['name'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
									if ($this->db->insert ('interactions_modes', $arrmodes)) {
										$mode_id = $this->db->insert_id ();
										if ($mode_id) {
											$email = RECEIVER;
											$subject = "Notification about the creation of the new Interaction Type";
											$content = 'Hi ' . "" . ' <br/>
                           						 This email is to notify you that the new Interaction Type was added by “' . $this->loggedUserId . '”
                           						 		
                           						 Interaction Type : ”' . $arrmodes['name']. '”
                           						 		
                           						 		
                        						  Regards,
                           						 		
                       							   Aissel Support Team';
											
											$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
											// Add log activity
											$requestStatus = FAILURE;
											if ($mode_id) {
												$requestStatus = SUCCESS;
											}
											$formData = $_POST;
											$formData = json_encode ( $formData );
											$arrLogDetails = array (
													'module' => 'Master Data',
													'type' => 'add',
													'description' => 'Adding  a particular Interaction Type',
													'status' => $requestStatus,
													'file_name' => 'master_data_controller',
													'transaction_id' => $mode_id,
													'transaction_table_id' => INTERACTIONS_MODES,
													'transaction_name' => "Add  Interaction Type",
													'client_id' => $clientId,
													'user_id' => $userId,
													'form_data' => $formData,
													'parent_object_id' => $mode_id
											);
											$this->config->set_item ( 'log_details', $arrLogDetails );
											log_user_activity ( null, true );
										}
									}
									$i = 0;
									$successCount = 0;
									$table = 'interactions_modes_client_visibility';
									while ( $clients [$i] != null ) {
										$data = array (
												'interactions_modes_id' => $mode_id,
												'client_id' => $clients [$i ++]
										);
										$status = $this->master_data_model->saveClientSpecialty ($table, $data);
										if ($status) {
											$successCount ++;
										}
									}
									// Add log activity
									$requestStatus = FAILURE;
									if ($status) {
										$requestStatus = SUCCESS;
									}
									$formData = $_POST;
									$formData = json_encode ( $formData );
									$arrLogDetails = array (
											'module' => 'Master Data',
											'type' => 'add',
											'description' => 'Adding associated clients to a particular Interaction Type',
											'status' => $requestStatus,
											'file_name' => 'master_data_controller',
											'transaction_id' => $mode_id,
											'transaction_table_id' => INTERACTIONS_MODES_CLIENT_VISIBILITY,
											'transaction_name' => "Add associated clients to Interaction Type",
											'client_id' => $clientId,
											'user_id' => $userId,
											'form_data' => $formData,
											'parent_object_id' => $mode_id
									);
									$this->config->set_item ( 'log_details', $arrLogDetails );
									log_user_activity ( null, true );
									$arrMasterDataDetails ['interaction_type'] = $mode_id;
								}
							}
							break;
						case "interaction_location" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "Name") {
								$arrImportStatusMsg [$file1] ['interaction_location_type'] ['incorrect_format'] = 'interaction location type Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$intLocType = array_search ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
								$isExistingRec = $this->master_data_model->checkInteractionLocation(trim ( $reader->sheets [$k] ["cells"] [$row] [1] ));
								if (!$isExistingRec) {
									$arrLoc ['name'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
									if ($this->db->insert ('interaction_location_types', $arrLoc)) {
										$loc_id = $this->db->insert_id ();
										if ($loc_id) {
											$email = RECEIVER;
											$subject = "Notification about the creation of the new Interaction Location Type";
											$content = 'Hi ' . "" . ' <br/>
                           						 This email is to notify you that the new Interaction Location Type was added by “' . $this->loggedUserId . '”
                           						 		
                           						 Interaction Location Type : ”' . $arrLoc['name']. '”
                           						 		
                           						 		
                        						  Regards,
                           						 		
                       							   Aissel Support Team';
											
											$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
											// Add log activity
											$requestStatus = FAILURE;
											if ($loc_id) {
												$requestStatus = SUCCESS;
											}
											$formData = $_POST;
											$formData = json_encode ( $formData );
											$arrLogDetails = array (
													'module' => 'Master Data',
													'type' => 'add',
													'description' => 'Adding  a particular Interaction Location Type',
													'status' => $requestStatus,
													'file_name' => 'master_data_controller',
													'transaction_id' => $loc_id,
													'transaction_table_id' => INTERACTION_LOCATION_TYPES,
													'transaction_name' => "Add  Interaction Location Type",
													'client_id' => $clientId,
													'user_id' => $userId,
													'form_data' => $formData,
													'parent_object_id' => $loc_id
											);
											$this->config->set_item ( 'log_details', $arrLogDetails );
											log_user_activity ( null, true );
										}
									}
									$i = 0;
									$successCount = 0;
									$table = 'interaction_location_types_client_visibility';
									while ( $clients [$i] != null ) {
										$data = array (
												'interaction_location_types_id' => $loc_id,
												'client_id' => $clients [$i ++]
										);
										$status = $this->master_data_model->saveClientSpecialty ($table, $data);
										if ($status) {
											$successCount ++;
										}
									}
									// Add log activity
									$requestStatus = FAILURE;
									if ($status) {
										$requestStatus = SUCCESS;
									}
									$formData = $_POST;
									$formData = json_encode ( $formData );
									$arrLogDetails = array (
											'module' => 'Master Data',
											'type' => 'add',
											'description' => 'Adding associated clients to a particular Interaction Location Type',
											'status' => $requestStatus,
											'file_name' => 'master_data_controller',
											'transaction_id' => $loc_id,
											'transaction_table_id' => INTERACTION_LOCATION_TYPES_CLIENT_VISIBILITY,
											'transaction_name' => "Add associated clients to Interaction Location Type",
											'client_id' => $clientId,
											'user_id' => $userId,
											'form_data' => $formData,
											'parent_object_id' => $loc_id
									);
									$this->config->set_item ( 'log_details', $arrLogDetails );
									log_user_activity ( null, true );
									$arrMasterDataDetails ['interaction_location_type'] = $loc_id;
								}
							}
							break;
						case "payments_requested_by" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "RequestedBy") {
								$arrImportStatusMsg [$file1] ['requested _by'] ['incorrect_format'] = 'requested by Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$requestedBy= array_search ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
								$isExistingRec = $this->master_data_model->checkRequestedBy(trim ( $reader->sheets [$k] ["cells"] [$row] [1] ));
								if (!$isExistingRec) {
									$arrReqBy ['requested_by'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
									if ($this->db->insert ('payments_requested_by', $arrReqBy)) {
										$requestedBy_id = $this->db->insert_id ();
										if ($requestedBy_id) {
											$email = RECEIVER;
											$subject = "Notification about the creation of the new Payments Requested By";
											$content = 'Hi ' . "" . ' <br/>
                           						 This email is to notify you that the new Payments Requested By was added by “' . $this->loggedUserId . '”
                           						 		
                           						 Requested By : ”' . $arrReqBy['requested_by']. '”
                           						 		
                           						 		
                        						  Regards,
                           						 		
                       							   Aissel Support Team';
											
											$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
											// Add log activity
											$requestStatus = FAILURE;
											if ($requestedBy_id) {
												$requestStatus = SUCCESS;
											}
											$formData = $_POST;
											$formData = json_encode ( $formData );
											$arrLogDetails = array (
													'module' => 'Master Data',
													'type' => 'add',
													'description' => 'Adding  a particular Payments Requested By',
													'status' => $requestStatus,
													'file_name' => 'master_data_controller',
													'transaction_id' => $requestedBy_id,
													'transaction_table_id' => PAYMENTS_REQUESTED_BY,
													'transaction_name' => "Add  Payments Requested By",
													'client_id' => $clientId,
													'user_id' => $userId,
													'form_data' => $formData,
													'parent_object_id' => $requestedBy_id
											);
											$this->config->set_item ( 'log_details', $arrLogDetails );
											log_user_activity ( null, true );
										}
									}
									$i = 0;
									$successCount = 0;
									$table = 'payments_requested_by_client_visibility';
									while ( $clients [$i] != null ) {
										$data = array (
												'requested_by_id' => $requestedBy_id,
												'client_id' => $clients [$i ++]
										);
										$status = $this->master_data_model->saveClientSpecialty ($table, $data);
										if ($status) {
											$successCount ++;
										}
									}
									// Add log activity
									$requestStatus = FAILURE;
									if ($status) {
										$requestStatus = SUCCESS;
									}
									$formData = $_POST;
									$formData = json_encode ( $formData );
									$arrLogDetails = array (
											'module' => 'Master Data',
											'type' => 'add',
											'description' => 'Adding associated clients to a particular Payments Requested By',
											'status' => $requestStatus,
											'file_name' => 'master_data_controller',
											'transaction_id' => $requestedBy_id,
											'transaction_table_id' => PAYMENTS_REQUESTED_BY_CLIENT_VISIBILITY,
											'transaction_name' => "Add associated clients to Payments Requested By",
											'client_id' => $clientId,
											'user_id' => $userId,
											'form_data' => $formData,
											'parent_object_id' => $requestedBy_id
									);
									$this->config->set_item ( 'log_details', $arrLogDetails );
									log_user_activity ( null, true );
									$arrMasterDataDetails ['requested_by'] = $requestedBy_id;
								}
							}
							break;
						case "payments_paid_by" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "PaidBy") {
								$arrImportStatusMsg [$file1] ['paid _by'] ['incorrect_format'] = 'paid by Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$paidBy= array_search ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
								$isExistingRec = $this->master_data_model->checkPaidBy(trim ( $reader->sheets [$k] ["cells"] [$row] [1] ));
								if (!$isExistingRec) {
									$arrPaidBy ['paid_by'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
									if ($this->db->insert ('payments_paid_by', $arrPaidBy)) {
										$paidBy_id = $this->db->insert_id ();
										if ($paidBy_id) {
											$email = RECEIVER;
											$subject = "Notification about the creation of the new Payments Paid By";
											$content = 'Hi ' . "" . ' <br/>
                           						 This email is to notify you that the new Payments Paid By was added by “' . $this->loggedUserId . '”
                           						 		
                           						 Paid By : ”' . $arrPaidBy['paid_by']. '”
                           						 		
                           						 		
                        						  Regards,
                           						 		
                       							   Aissel Support Team';
											
											$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
											// Add log activity
											$requestStatus = FAILURE;
											if ($paidBy_id) {
												$requestStatus = SUCCESS;
											}
											$formData = $_POST;
											$formData = json_encode ( $formData );
											$arrLogDetails = array (
													'module' => 'Master Data',
													'type' => 'add',
													'description' => 'Adding  a particular Payments Paid By',
													'status' => $requestStatus,
													'file_name' => 'master_data_controller',
													'transaction_id' => $paidBy_id,
													'transaction_table_id' => PAYMENTS_PAID_BY,
													'transaction_name' => "Add  Payments Paid By",
													'client_id' => $clientId,
													'user_id' => $userId,
													'form_data' => $formData,
													'parent_object_id' => $paidBy_id
											);
											$this->config->set_item ( 'log_details', $arrLogDetails );
											log_user_activity ( null, true );
										}
									}
									$i = 0;
									$successCount = 0;
									$table = 'payments_paid_by_client_visibility';
									while ( $clients [$i] != null ) {
										$data = array (
												'paid_by_id' => $paidBy_id,
												'client_id' => $clients [$i ++]
										);
										$status = $this->master_data_model->saveClientSpecialty ($table, $data);
										if ($status) {
											$successCount ++;
										}
									}
									// Add log activity
									$requestStatus = FAILURE;
									if ($status) {
										$requestStatus = SUCCESS;
									}
									$formData = $_POST;
									$formData = json_encode ( $formData );
									$arrLogDetails = array (
											'module' => 'Master Data',
											'type' => 'add',
											'description' => 'Adding associated clients to a particular Payments Paid By',
											'status' => $requestStatus,
											'file_name' => 'master_data_controller',
											'transaction_id' => $paidBy_id,
											'transaction_table_id' => PAYMENTS_PAID_BY_CLIENT_VISIBILITY,
											'transaction_name' => "Add associated clients to Payments Paid By",
											'client_id' => $clientId,
											'user_id' => $userId,
											'form_data' => $formData,
											'parent_object_id' => $paidBy_id
									);
									$this->config->set_item ( 'log_details', $arrLogDetails );
									log_user_activity ( null, true );
									$arrMasterDataDetails ['paid_by'] = $paidBy_id;
								}
							}
							break;
						case "payment_types" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "Name") {
								$arrImportStatusMsg [$file1] ['payment_type'] ['incorrect_format'] = 'payment type Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$paymentType = array_search ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
								$isExistingRec = $this->master_data_model->checkPaymentType(trim ( $reader->sheets [$k] ["cells"] [$row] [1] ));
								if (!$isExistingRec) {
									$arrpaymentType['name'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
									if ($this->db->insert ('payment_types', $arrpaymentType)) {
										$paymentType_id = $this->db->insert_id ();
										if ($paymentType_id) {
											$email = RECEIVER;
											$subject = "Notification about the creation of the new Payment Type";
											$content = 'Hi ' . "" . ' <br/>
                           						 This email is to notify you that the new Payment Type was added by “' . $this->loggedUserId . '”
                           						 		
                           						 Payment Type : ”' . $arrpaymentType['name']. '”
                           						 		
                           						 		
                        						  Regards,
                           						 		
                       							   Aissel Support Team';
											
											$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
											// Add log activity
											$requestStatus = FAILURE;
											if ($paymentType_id) {
												$requestStatus = SUCCESS;
											}
											$formData = $_POST;
											$formData = json_encode ( $formData );
											$arrLogDetails = array (
													'type' => 'add',
													'description' => 'Adding  a particular Payment Type',
													'status' => $requestStatus,
													'file_name' => 'master_data_controller',
													'transaction_id' => $paymentType_id,
													'transaction_table_id' => PAYMENT_TYPES,
													'transaction_name' => "Add  Payment Type",
													'client_id' => $clientId,
													'user_id' => $userId,
													'form_data' => $formData,
													'parent_object_id' => $paymentType_id
											);
											$this->config->set_item ( 'log_details', $arrLogDetails );
											log_user_activity ( null, true );
										}
									}
									$i = 0;
									$successCount = 0;
									$table = 'payment_types_client_visibility';
									while ( $clients [$i]!= null ) {
										$data = array (
												'payment_type' => $paymentType_id,
												'client_id' => $clients [$i ++]
										);
										$status = $this->master_data_model->saveClientSpecialty ($table, $data);
										if ($status) {
											$successCount ++;
										}
									}
									// Add log activity
									$requestStatus = FAILURE;
									if ($status) {
										$requestStatus = SUCCESS;
									}
									$formData = $_POST;
									$formData = json_encode ( $formData );
									$arrLogDetails = array (
											'module' => 'Master Data',
											'type' => 'add',
											'description' => 'Adding associated clients to a particular Payment Type',
											'status' => $requestStatus,
											'file_name' => 'master_data_controller',
											'transaction_id' => $paymentType_id,
											'transaction_table_id' => PAYMENT_TYPES_CLIENT_VISIBILITY,
											'transaction_name' => "Add associated clients to Payment Type",
											'client_id' => $clientId,
											'user_id' => $userId,
											'form_data' => $formData,
											'parent_object_id' => $paymentType_id
									);
									$this->config->set_item ( 'log_details', $arrLogDetails );
									log_user_activity ( null, true );
									$arrMasterDataDetails ['payment_type'] = $paymentType_id;
								}
							}
							break;
						case "payments_currency" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "CurrencyName") {
								$arrImportStatusMsg [$file1] ['payment_currency'] ['incorrect_format'] = 'payment currency Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$paymentCurrency = array_search ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
								$isExistingRec = $this->master_data_model->checkPaymentCurrency(trim ( $reader->sheets [$k] ["cells"] [$row] [1] ));
								if (!$isExistingRec) {
									$arrpaymentCurrency['currency_name'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
									if ($this->db->insert ('payments_currency', $arrpaymentCurrency)) {
										//pr($this->db->last_query());exit;
										$paymentCurrency_id = $this->db->insert_id ();
										if ($paymentCurrency_id) {
											$email = RECEIVER;
											$subject = "Notification about the creation of the new Payment Currency";
											$content = 'Hi ' . "" . ' <br/>
                           						 This email is to notify you that the new Payment Currency was added by “' . $this->loggedUserId . '”
                           						 		
                           						 Payment Currency : ”' . $arrpaymentCurrency['currency_name']. '”
                           						 		
                           						 		
                        						  Regards,
                           						 		
                       							   Aissel Support Team';
											
											$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
											// Add log activity
											$requestStatus = FAILURE;
											if ($paymentCurrency_id) {
												$requestStatus = SUCCESS;
											}
											$formData = $_POST;
											$formData = json_encode ( $formData );
											$arrLogDetails = array (
													'module' => 'Master Data',
													'type' => 'add',
													'description' => 'Adding  a particular Payment Currency',
													'status' => $requestStatus,
													'file_name' => 'master_data_controller',
													'transaction_id' => $paymentCurrency_id,
													'transaction_table_id' => PAYMENTS_CURRENCY,
													'transaction_name' => "Add  Payment Currency",
													'client_id' => $clientId,
													'user_id' => $userId,
													'form_data' => $formData,
													'parent_object_id' => $paymentCurrency_id
											);
											$this->config->set_item ( 'log_details', $arrLogDetails );
											log_user_activity ( null, true );
										}
									}
									$i = 0;
									$successCount = 0;
									$table = 'payments_currency_client_visibility';
									while ( $clients [$i] != null ) {
										$data = array (
												'currency_name' => $paymentCurrency_id,
												'client_id' => $clients [$i ++]
										);
										$status = $this->master_data_model->saveClientSpecialty ($table, $data);
										if ($status) {
											$successCount ++;
										}
									}
									// Add log activity
									$requestStatus = FAILURE;
									if ($status) {
										$requestStatus = SUCCESS;
									}
									$formData = $_POST;
									$formData = json_encode ( $formData );
									$arrLogDetails = array (
											'module' => 'Master Data',
											'type' => 'add',
											'description' => 'Adding associated clients to a particular Payment Currency',
											'status' => $requestStatus,
											'file_name' => 'master_data_controller',
											'transaction_id' => $paymentCurrency_id,
											'transaction_table_id' => PAYMENTS_CURRENCY_CLIENT_VISIBILITY,
											'transaction_name' => "Add associated clients to Payment Currency",
											'client_id' => $clientId,
											'user_id' => $userId,
											'form_data' => $formData,
											'parent_object_id' => $paymentCurrency_id
									);
									$this->config->set_item ( 'log_details', $arrLogDetails );
									log_user_activity ( null, true );
									$arrMasterDataDetails ['payment_currency'] = $paymentCurrency_id;
								}
							}
							break;
						case "cities" :
							$row = 1;
							if (trim($reader->sheets[$k]["cells"][$row][1]) != "Country" ||
									trim($reader->sheets[$k]["cells"][$row][2]) != "State" ||
									trim($reader->sheets[$k]["cells"][$row][3]) != "City") {
								$arrImportStatusMsg [$file1] ['states'] ['incorrect_format'] = 'states Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$country['Country'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ));
								//pr($country['Country']);exit;
								$state['Region'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [2] ));
								$city['City'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [3] ));
								$isExistingCountry = $this->master_data_model->checkCountry(trim ( $reader->sheets [$k] ["cells"] [$row] [1] ));
								$isExistingState = $this->master_data_model->checkState(trim ( $reader->sheets [$k] ["cells"] [$row] [2] ));
								$isExistingCity = $this->master_data_model->checkCity(trim ( $reader->sheets [$k] ["cells"] [$row] [3] ));
								if(!$isExistingCountry){
								if ($this->db->insert ('countries', $country)) {
									//echo $this->db->last_query();
									$country_id = $this->db->insert_id ();
									if ($country_id) {
										$email = RECEIVER;
										$subject = "Notification about the creation of the new country";
										$content = 'Hi ' . "" . ' <br/>
                           						 This email is to notify you that the new country was added by “' . $this->loggedUserId . '”
                           						 		
                           						 Country : ”' . $country['Country']. '”
                           						 		
                           						 		
                        						  Regards,
                           						 		
                       							   Aissel Support Team';
										
										$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
										// Add log activity
										$requestStatus = FAILURE;
										if ($country_id) {
											$requestStatus = SUCCESS;
										}
										$formData = $_POST;
										$formData = json_encode ( $formData );
										$arrLogDetails = array (
												'module' => 'Master Data',
												'type' => 'add',
												'description' => 'Adding  a particular Country',
												'status' => $requestStatus,
												'file_name' => 'master_data_controller',
												'transaction_id' => $country_id,
												'transaction_table_id' => COUNTRIES,
												'transaction_name' => "Add Country",
												'client_id' => $clientId,
												'user_id' => $userId,
												'form_data' => $formData,
												'parent_object_id' => $country_id
										);
										$this->config->set_item ( 'log_details', $arrLogDetails );
										log_user_activity ( null, true );
									}
								}
								}
								if(!$isExistingState){
								if ($this->db->insert ('regions', $state)) {
									$state_id = $this->db->insert_id ();
									if ($state_id) {
										$email = RECEIVER;
										$subject = "Notification about the creation of the new state";
										$content = 'Hi ' . "" . ' <br/>
                           						 This email is to notify you that the new state was added by “' . $this->loggedUserId . '”
                           						 		
                           						 State : ”' . $state['Region']. '”
                           						 		
                           						 		
                        						  Regards,
                           						 		
                       							   Aissel Support Team';
										
										$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
										// Add log activity
										$requestStatus = FAILURE;
										if ($state_id) {
											$requestStatus = SUCCESS;
										}
										$formData = $_POST;
										$formData = json_encode ( $formData );
										$arrLogDetails = array (
												'module' => 'Master Data',
												'type' => 'add',
												'description' => 'Adding  a particular State',
												'status' => $requestStatus,
												'file_name' => 'master_data_controller',
												'transaction_id' => $state_id,
												'transaction_table_id' => REGIONS,
												'transaction_name' => "Add State",
												'client_id' => $clientId,
												'user_id' => $userId,
												'form_data' => $formData,
												'parent_object_id' => $state_id
										);
										$this->config->set_item ( 'log_details', $arrLogDetails );
										log_user_activity ( null, true );
									}
								}
								}
								if(!$isExistingCity){
								if ($this->db->insert ('cities', $city)) {
									$city_id = $this->db->insert_id ();
									if ($city_id) {
										$email = RECEIVER;
										$subject = "Notification about the creation of the new city";
										$content = 'Hi ' . "" . ' <br/>
                           						 This email is to notify you that the new city was added by “' . $this->loggedUserId . '”
                           						 		
                           						 City : ”' . $city['City']. '”
                           						 		
                           						 		
                        						  Regards,
                           						 		
                       							   Aissel Support Team';
										
										$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
										// Add log activity
										$requestStatus = FAILURE;
										if ($city_id) {
											$requestStatus = SUCCESS;
										}
										$formData = $_POST;
										$formData = json_encode ( $formData );
										$arrLogDetails = array (
												'module' => 'Master Data',
												'type' => 'add',
												'description' => 'Adding  a particular city',
												'status' => $requestStatus,
												'file_name' => 'master_data_controller',
												'transaction_id' => $city_id,
												'transaction_table_id' => REGIONS,
												'transaction_name' => "Add city",
												'client_id' => $clientId,
												'user_id' => $userId,
												'form_data' => $formData,
												'parent_object_id' => $city_id
										);
										$this->config->set_item ( 'log_details', $arrLogDetails );
										log_user_activity ( null, true );
									}
								}
								}
							}
							break;
						case "event_type" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "EventType") {
								$arrImportStatusMsg [$file1] ['event_type'] ['incorrect_format'] = 'event type Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$eventType = array_search ( ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) ), $arrEventTypes);
								if (! $eventType) {
									$arrEventType['event_type'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
									if ($this->db->insert ( 'conf_event_types', $arrEventType)) {
										$eventType = $this->db->insert_id ();
										if ($eventType) {
											$email = RECEIVER;
											$subject = "Notification about the creation of the new Event Type";
											$content = 'Hi ' . "" . ' <br/>
					                            This email is to notify you that the new Event Type was added by “' . $this->loggedUserId . '”
					                            		
					                            Event Type: ”' . $arrEventType ['event_type'] . '”
					                            		
					                            		
					                           Regards,
					                            		
					                           Aissel Support Team';
											
											$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
										}
									} else {
										$eventType = "";
									}
								}
								$arrMasterDataDetails ['event_type'] = $eventType;
								// Add log activity
								$requestStatus = FAILURE;
								if ($eventType) {
									$requestStatus = SUCCESS;
								}
								$formData = $_POST;
								$formData = json_encode ( $formData );
								$arrLogDetails = array (
										'type' => ADD_RECORD,
										'description' => 'Adding event type',
										'status' => $requestStatus,
										'file_name' => 'master_data_controller',
										'transaction_id' => $eventType,
										'transaction_table_id' => CONF_EVENT_TYPES,
										'transaction_name' => "Add event type",
										'client_id' => $clientId,
										'user_id' => $userId,
										'form_data' => $formData,
										'parent_object_id' => $eventType
								);
								$this->config->set_item ( 'log_details', $arrLogDetails );
								log_user_activity ( null, true );
							}
							break;
						case "sponsor_type" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "SponsorType") {
								$arrImportStatusMsg [$file1] ['sponsor_type'] ['incorrect_format'] = 'sponsor type Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$sponsorType = array_search ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
								$isExistingRec = $this->master_data_model->checkSponsorType(trim ( $reader->sheets [$k] ["cells"] [$row] [1] ));
								if (!$isExistingRec) {
									$arrsponsorType['type'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
									if ($this->db->insert ('event_sponsor_types', $arrsponsorType)) {
										$sponsorType_id = $this->db->insert_id ();
										if ($sponsorType_id) {
											$email = RECEIVER;
											$subject = "Notification about the creation of the new Sponsor Type";
											$content = 'Hi ' . "" . ' <br/>
                           						 This email is to notify you that the new Sponsor Type was added by “' . $this->loggedUserId . '”
                           						 		
                           						 Sponsor Type : ”' . $arrsponsorType['type']. '”
                           						 		
                           						 		
                        						  Regards,
                           						 		
                       							   Aissel Support Team';
											
											$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
											// Add log activity
											$requestStatus = FAILURE;
											if ($sponsorType_id) {
												$requestStatus = SUCCESS;
											}
											$formData = $_POST;
											$formData = json_encode ( $formData );
											$arrLogDetails = array (
													'type' => ADD_RECORD,
													'description' => 'Adding  a particular Sponsor Type',
													'status' => $requestStatus,
													'file_name' => 'master_data_controller',
													'transaction_id' => $sponsorType_id,
													'transaction_table_id' => EVENT_SPONSOR_TYPES,
													'transaction_name' => "Add  Sponsor Type",
													'client_id' => $clientId,
													'user_id' => $userId,
													'form_data' => $formData,
													'parent_object_id' => $sponsorType_id
											);
											$this->config->set_item ( 'log_details', $arrLogDetails );
											log_user_activity ( null, true );
										}
									}
									$arrMasterDataDetails ['type'] = $sponsorType_id;
								}
							}
							break;
						case "session_type" :
							$row = 1;
							if (trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) != "SessionType") {
								$arrImportStatusMsg [$file1] ['session_type'] ['incorrect_format'] = 'session type Header format is incorrect';
								break;
							}
							for($row = 2; $row <= count ( $reader->sheets [$k] ["cells"] ); $row ++) {
								$arrMasterDataDetails = array ();
								$sessionType = array_search ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
								$isExistingRec = $this->master_data_model->checkSessionType(trim ( $reader->sheets [$k] ["cells"] [$row] [1] ));
								if (!$isExistingRec) {
									$arrsessionType['session_type'] = ucwords ( trim ( $reader->sheets [$k] ["cells"] [$row] [1] ) );
									if ($this->db->insert ('conf_session_types', $arrsessionType)) {
										$sessionType_id = $this->db->insert_id ();
										if ($sessionType_id) {
											$email = RECEIVER;
											$subject = "Notification about the creation of the new Session Type";
											$content = 'Hi ' . "" . ' <br/>
                           						 This email is to notify you that the new Session Type was added by “' . $this->loggedUserId . '”
                           						 		
                           						 Session Type : ”' . $arrsessionType['session_type']. '”
                           						 		
                           						 		
                        						  Regards,
                           						 		
                       							   Aissel Support Team';
											
											$emailStatus = $this->common_helpers->send_email_notification_expiree ( $subject, $content, $email );
											// Add log activity
											$requestStatus = FAILURE;
											if ($sessionType_id) {
												$requestStatus = SUCCESS;
											}
											$formData = $_POST;
											$formData = json_encode ( $formData );
											$arrLogDetails = array (
													'type' => ADD_RECORD,
													'description' => 'Adding  a particular Session Type',
													'status' => $requestStatus,
													'file_name' => 'master_data_controller',
													'transaction_id' => $sessionType_id,
													'transaction_table_id' => EVENT_SPONSOR_TYPES,
													'transaction_name' => "Add  Session Type",
													'client_id' => $clientId,
													'user_id' => $userId,
													'form_data' => $formData,
													'parent_object_id' => $sessionType_id
											);
											$this->config->set_item ( 'log_details', $arrLogDetails );
											log_user_activity ( null, true );
										}
									}
									$arrMasterDataDetails ['session_type'] = $sessionType_id;
								}
							}
							break;
					}
				}
			}
		}
		// Add log activity
		$arrLogDetails = array (
				'type' => 'Import Script',
				'description' => 'Importing required master data details',
				'status' => SUCCESS,
				'file_name' => 'master_data_controller',
				'transaction_name' => "Importing Master Data",
				'client_id' => $clientId,
				'user_id' => $userId
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		redirect("master_data_controller/view_types");
	}
	function import_page() {
		$arrClients = $this->master_data_model->getClientDetails ();
		$data ['arrClients'] = $arrClients;
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited import master data Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View import master data Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$data ['contentPage'] = 'master_data/import_masterdata';
		$this->load->view ( 'layouts/analyst_view', $data );
	}
	function export_page() {
		$arrClients = $this->master_data_model->getClientDetails ();
		$data ['arrClients'] = $arrClients;
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited export master data Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View export master data Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view ('master_data/export_masterdata', $data );
	}
	//exporting master data values
	function export_multiple_master_data() {
		$startTime = microtime(true);
		ini_set('memory_limit', "-1");
		ini_set("max_execution_time", 0);
		$this->load->plugin('php_excel/classes/PHPExcel.php');
		$ids = $this->input->post('clientIds');
		$categories = $this->input->post('export_opts');
		$userId = $this->session->userdata ( 'user_id' );
		$clientId = $this->session->userdata ( 'client_id' );
		$arrStyles = array (
				'font' => array (
						'bold' => true,
						'italic' => false 
				),
				'borders' => array (
						'bottom' => array (
								'style' => PHPExcel_Style_Border::BORDER_THICK,
								'color' => array (
										'rgb' => '000000' 
								) 
						),
						'quotePrefix' => true 
				) 
		);
		$objPHPExcel = new PHPExcel();
		$arrExcelData = array();
		foreach ($categories as $catNames) {
			$arrCategoryDetails[$catNames] = $this->master_data_model->getCategoryDetailsByName($catNames,$ids);
		}
		//pr($arrCategoryDetails);exit;
		// title information section
		if (in_array('titles', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('titles');
			//Add header
			$objWorksheet->setCellValue('A1', 'Title');
			
			$i = 2;
			foreach ($arrCategoryDetails['titles'] as $titlesrow) {
				$objWorksheet->setCellValue('A' . $i,$titlesrow['title']);
				
				$i++;
			}
		$objPHPExcel->addSheet($objWorksheet);
		}
		//interactions topics information section
		if (in_array('interactions_topics', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('topics');
			//Add header
			$objWorksheet->setCellValue('A1', 'Name');
			
			$i = 2;
			foreach ($arrCategoryDetails['interactions_topics'] as $topicrow) {
				$objWorksheet->setCellValue('A' . $i,$topicrow['name']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		//products information section
		if (in_array('products', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('products');
			//Add header
			$objWorksheet->setCellValue('A1', 'ProductName');
			$i = 2;
			foreach ($arrCategoryDetails['products'] as $productsrow) {
				$objWorksheet->setCellValue('A' . $i,$productsrow['name']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		//email type information section
		if (in_array('emails', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('email_type');
			//Add header
			$objWorksheet->setCellValue('A1', 'EmailType');
			$i = 2;
			foreach ($arrCategoryDetails['emails'] as $emailsrow) {
				$objWorksheet->setCellValue('A' . $i,$emailsrow['type']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		//phone type information section
		if (in_array('phone_type', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('phone_type');
			//Add header
			$objWorksheet->setCellValue('A1', 'PhoneType');
			$i = 2;
			foreach ($arrCategoryDetails['phone_type'] as $phonetyperow) {
				$objWorksheet->setCellValue('A' . $i,$phonetyperow['name']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		//specialty information section
		if (in_array('specialties', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('specialty');
			//Add header
			$objWorksheet->setCellValue('A1', 'Specialty');
			$i = 2;
			foreach ($arrCategoryDetails['specialties'] as $specrow) {
				$objWorksheet->setCellValue('A' . $i,$specrow['specialty']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		//event roles information section
		if (in_array('event_roles', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('event_roles');
			//Add header
			$objWorksheet->setCellValue('A1', 'EventRole');
			$i = 2;
			foreach ($arrCategoryDetails['event_roles'] as $eventrolesrow) {
				$objWorksheet->setCellValue('A' . $i,$eventrolesrow['role']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		//event topics information section
		if (in_array('event_topics', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('event_topics');
			//Add header
			$objWorksheet->setCellValue('A1', 'EventTopic');
			$i = 2;
			foreach ($arrCategoryDetails['event_topics'] as $eventtopicsrow) {
				$objWorksheet->setCellValue('A' . $i,$eventtopicsrow['name']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		//event organizer types information section
		if (in_array('event_organizer_types', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('event_organizer_types');
			//Add header
			$objWorksheet->setCellValue('A1', 'Type');
			$i = 2;
			foreach ($arrCategoryDetails['event_organizer_types'] as $eventorganizertypesrow) {
				$objWorksheet->setCellValue('A' . $i,$eventorganizertypesrow['type']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		//discussion types information section
		if (in_array('interaction_types', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('discussion_types');
			//Add header
			$objWorksheet->setCellValue('A1', 'Name');
			$i = 2;
			foreach ($arrCategoryDetails['interaction_types'] as $interactiontypesrow) {
				$objWorksheet->setCellValue('A' . $i,$interactiontypesrow['name']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		//interaction types information section
		if (in_array('interactions_modes', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('interaction_type');
			//Add header
			$objWorksheet->setCellValue('A1', 'Name');
			$i = 2;
			foreach ($arrCategoryDetails['interactions_modes'] as $interactionsmodesrow) {
				$objWorksheet->setCellValue('A' . $i,$interactionsmodesrow['name']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		//interaction location types information section
		if (in_array('interaction_location_types', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('interaction_location');
			//Add header
			$objWorksheet->setCellValue('A1', 'Name');
			$i = 2;
			foreach ($arrCategoryDetails['interaction_location_types'] as $interactionlocationtypesrow) {
				$objWorksheet->setCellValue('A' . $i,$interactionlocationtypesrow['name']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		//engagement types information section
		if (in_array('engagement_types', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('engagement_types');
			//Add header
			$objWorksheet->setCellValue('A1', 'EngagementType');
			$i = 2;
			foreach ($arrCategoryDetails['engagement_types'] as $engagementtypesrow) {
				$objWorksheet->setCellValue('A' . $i,$engagementtypesrow['engagement_type']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		//organization types information section
		if (in_array('organization_types', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('organization_types');
			//Add header
			$objWorksheet->setCellValue('A1', 'OrgType');
			$i = 2;
			foreach ($arrCategoryDetails['organization_types'] as $organizationtypesrow) {
				$objWorksheet->setCellValue('A' . $i,$organizationtypesrow['type']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		//payments requested by information section
		if (in_array('payments_requested_by', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('payments_requested_by');
			//Add header
			$objWorksheet->setCellValue('A1', 'RequestedBy');
			$i = 2;
			foreach ($arrCategoryDetails['payments_requested_by'] as $paymentsrequestedbyrow) {
				$objWorksheet->setCellValue('A' . $i,$paymentsrequestedbyrow['requested_by']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		//payments paid by information section
		if (in_array('payments_paid_by', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('payments_paid_by');
			//Add header
			$objWorksheet->setCellValue('A1', 'PaidBy');
			$i = 2;
			foreach ($arrCategoryDetails['payments_paid_by'] as $paymentspaidbyrow) {
				$objWorksheet->setCellValue('A' . $i,$paymentspaidbyrow['paid_by']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		//payment types information section
		if (in_array('payment_types', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('payment_types');
			//Add header
			$objWorksheet->setCellValue('A1', 'Name');
			$i = 2;
			foreach ($arrCategoryDetails['payment_types'] as $paymenttypesrow) {
				$objWorksheet->setCellValue('A' . $i,$paymenttypesrow['name']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		//payments currency information section
		if (in_array('payments_currency', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('payments_currency');
			//Add header
			$objWorksheet->setCellValue('A1', 'CurrencyName');
			$i = 2;
			foreach ($arrCategoryDetails['payments_currency'] as $paymentscurrencyrow) {
				$objWorksheet->setCellValue('A' . $i,$paymentscurrencyrow['currency_name']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		//country,state,city  information section
		if (in_array('cities', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('cities');
			//Add header
			$objWorksheet->setCellValue('A1', 'Country')
						->setCellValue('B1', 'State')
						->setCellValue('C1', 'City');
			$i = 2;
			foreach ($arrCategoryDetails['cities'] as $citiesrow) {
				$objWorksheet->setCellValue('A' . $i,$citiesrow['Country'])
				->setCellValue('B' . $i,$citiesrow['Region'])
				->setCellValue('C' . $i,$citiesrow['City']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		if (in_array('event_type', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('event_type');
			//Add header
			$objWorksheet->setCellValue('A1', 'EventType');
			
			$i = 2;
			foreach ($arrCategoryDetails['event_type'] as $eventTyperow) {
				$objWorksheet->setCellValue('A' . $i,$eventTyperow['event_type']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		if (in_array('sponsor_type', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('sponsor_type');
			//Add header
			$objWorksheet->setCellValue('A1', 'SponsorType');
			
			$i = 2;
			foreach ($arrCategoryDetails['sponsor_type'] as $regionsrow) {
				$objWorksheet->setCellValue('A' . $i,$regionsrow['type']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		if (in_array('session_type', $categories)) {
			//New Worksheet
			$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
			$objWorksheet->setTitle('session_type');
			//Add header
			$objWorksheet->setCellValue('A1', 'SessionType');
			
			$i = 2;
			foreach ($arrCategoryDetails['session_type'] as $regionsrow) {
				$objWorksheet->setCellValue('A' . $i,$regionsrow['session_type']);
				
				$i++;
			}
			$objPHPExcel->addSheet($objWorksheet);
		}
		$styleArray = array (
				'borders' => array (
						'bottom' => array (
								'style' => PHPExcel_Style_Border::BORDER_THICK,
								'color' => array (
										'argb' => '0000000' 
								) 
						) 
				) 
		);
		
		$arrStyles = array (
				'font' => array (
						'bold' => true,
						'italic' => false 
				),
				'borders' => array (
						'bottom' => array (
								'style' => PHPExcel_Style_Border::BORDER_THICK,
								'color' => array (
										'rgb' => '000000' 
								) 
						),
						'quotePrefix' => true 
				) 
		);
		// remove first sheet
		$objPHPExcel->removeSheetByIndex(0);
		//iterate each sheet and add the style for each sheet
		foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
			$categories = array(strtolower($sheet->getTitle()));
			if (in_array('titles', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('interactions_topics', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('products', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('emails', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('phone_type', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('specialties', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('event_roles', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('event_topics', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('event_organizer_types', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('interaction_types', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('interactions_modes', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('interaction_location_types', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('engagement_types', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('organization_types', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('payments_requested_by', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('payments_paid_by', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('payment_types', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('payments_currency', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('cities', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'C') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:C1')->applyFromArray($arrStyles);
			}
			if (in_array('event_type', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('sponsor_type', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
			if (in_array('session_type', $categories)) {
				$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
				foreach (range('A', 'A') as $columnID) {
					$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
				}
				$objPHPExcel->getActiveSheet()->getStyle('A1:A1')->applyFromArray($arrStyles);
			}
		}
		$objPHPExcel->setActiveSheetIndex(0);
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');		
		// Add log activity
		$arrLogDetails = array (
				'type' => 'Export Script',
				'description' => 'Exporting required master data details',
				'status' => SUCCESS,
				'file_name' => 'master_data_controller',
				'transaction_name' => "Exporting Master Data",
				'client_id' => $clientId,
				'user_id' => $userId
		);
		$this->config->set_item ( 'log_details', $arrLogDetails );
		log_user_activity ( null, true );
		// Redirect output to a client’s web browser (Excel2007)
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment;filename="master_data.xls"');
		header('Cache-Control: max-age=0');
		// If you're serving to IE 9, then the following may be needed
		header('Cache-Control: max-age=1');
		
		// If you're serving to IE over SSL, then the following may be needed
		header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
		header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
		header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
		header('Pragma: public'); // HTTP/1.0
		
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		ob_end_clean();
		ob_start();
		$objWriter->save('php://output');
		exit;
	}	

}

?>
