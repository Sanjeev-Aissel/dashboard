<?php
/**
 * Controller for Chat operations
 * @package application.controllers	
 * @author Vinayak Malladad
 * @since 3.10
 * @created May 9,2012
 * 
 */


class chat extends controller{

	/*
	 *  constructor of chat class
	 *  @author Vinayak Malladad
	 *  @since 1.5
	 *  @created on 28-2-2011
	 */
	function chat(){
		parent::Controller();
	}
	
	/*
	 *  Display 'Client users ' view page
	 *  @author Vinayak Malladad
	 *  @since 1.5
	 *  @created on 28-2-2011
	 */	
	function index(){
		$data['userId']   = (int)$this->session->userdata['user_id'];
		$data['clientId'] = (int)$this->session->userdata['client_id'];
		$data['contentPage'] 	=	'chat/index';
		$this->load->view('layouts/client_view', $data);
	}
}