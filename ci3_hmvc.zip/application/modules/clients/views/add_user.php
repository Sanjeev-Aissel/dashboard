<script src="<?php echo base_url().MODULES_ASSETS;?>clients/js/client.js"></script>
<link  href="<?php echo base_url().MODULES_ASSETS;?>clients/css/client.css" rel="stylesheet">
<script type="text/javascript">
	var old_manager_id='<?php echo $arrUsers['manager_id'];?>';
	var old_role_id='<?php echo $arrUsers['user_role_id'];?>';
	var validationRules	=  {
			first_name: {
				required:true
			},
			last_name: {
				required:true
			},
			title: {
				required:true
			},
			company_name: {
				required:true
			},
			phone: {
				required:true
			},
			email: {
				required:true
			},
			country_id: {
				required:true
			},
			password: {
				required:true
			},
			confirm_password: {
				required:true
			},
			user_name: {
				required:true
			},
			profile_pic: {
				 accept: "jpg,jpeg,png,gif"
		    }
		};
		var validationMessages = {
				first_name: {
					required: "Required field cannot be left blank"
				},
				last_name: {
					required: "Required field cannot be left blank"
				},
				user_name: {
					required: "Required field cannot be left blank"
				},				
				title: {
					required: "Required field cannot be left blank"
				},
				country_id: {
					required: "Required field cannot be left blank"
				},
				password: {
					required: "Required field cannot be left blank"
				},
				confirm_password: {
					required: "Required field cannot be left blank"
				},
				title: {
					required: "Required field cannot be left blank"
				},
				company_name: {
					required: "Required field cannot be left blank"
				},
				phone: {
					required: "Required field cannot be left blank"
				},
				email: {
					required: "Required field cannot be left blank"
				},
				profile_pic: {
					accept: "Invalid file type"
				}
		};
		$(document).ready(function(){
			$("#saveUser").validate({
				debug:true,
				//onkeyup:true,
				rules: validationRules,
				messages: validationMessages
			});
			getManagersAndRoles();
		});
</script>
<h1 class="page_title"><?php if($arrUsers==null) echo "Add User"; else echo "Update User";?></h1>
<div class="container">
<form action=""   method="post" name="saveUser" id="saveUser" class="validateForm" enctype="multipart/form-data">
		<input type="hidden" name="user_id" id="user_id" value="<?php if($arrUsers!=null) echo $arrUsers['id'];?>"/>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Client:</label>
				<div class="col-sm-3">
					<select name="client_id" class="required form-control" id="client_id" onchange="getManagersAndRoles();">
							<option value="0">--- Select ---</option>
							<?php foreach ($arrClients as $clients){?>
								<option value="<?php echo $clients['id']?>" <?php if($arrUsers['client_id']==$clients['id']){?> selected="selected"<?php }?>>
									<?php echo $clients['name']?>
								</option>
							<?php }?>
						</select>
		    	</div>
		    	<label class="col-sm-3 col-form-label">Role:</label>
				<div class="col-sm-3">
				<select name="user_role_id" class="required form-control" id="user_role_id">
						<option value="0">-- Select --</option>
					</select>
		    	</div>
		</div>
		<div class="form-group row">
			<label class="col-sm-3 col-form-label">Manager:</label>
			<div class="col-sm-3">
			 <select name="manager_id" id="manager_id" class="form-control" <?php if($arrUsers['user_role_id'] !=2) echo 'class="required "'; ?>>
			</select>
	    	</div>
			<label class="col-sm-3 col-form-label">Mark As Manager:</label>
			<div class="col-sm-3">
				<input type="radio" name="mark_as_mgr" value="0" checked="checked" /> No
				<input type="radio" name="mark_as_mgr" value="1"   <?php if($arrUsers['is_manager']=='1'){?>checked="checked"<?php }?>/> Yes
	    	</div>		    	
		</div> 
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">First Name:</label>
				<div class="col-sm-3">
					<input type="text" name="first_name" id="first_name" value="<?php if($arrUsers!=null) echo $arrUsers['first_name'];?>" class="required form-control"/>
		    	</div>
		    	<label class="col-sm-3 col-form-label">Last Name:</label>
				<div class="col-sm-3">
					<input type="text" name="last_name" id="last_name" value="<?php if($arrUsers!=null) echo $arrUsers['last_name'];?>" class="required form-control"/>
		    	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Email:</label>
				<div class="col-sm-3">
					<input type="text" name="email" id="email" value="<?php if($arrUsers!=null) echo $arrUsers['email'];?>" class="email form-control"/>
		    	</div>
		    	<label class="col-sm-3 col-form-label">Contact:</label>
				<div class="col-sm-3">
		    	 <input type="text" name="contact" id="contact" value="<?php if($arrUsers!=null) echo $arrUsers['contact'];?>" onkeyup="allowNumericOnly(this)" class="form-control"/>
		    	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Title:</label>
				<div class="col-sm-3">
					<input type="text" name="title" id="title" value="<?php if($arrUsers!=null) echo $arrUsers['title'];?>" class="required form-control"/>
		    	</div>
		    	<label class="col-sm-3 col-form-label">Company Name:</label>
				<div class="col-sm-3">
					<input type="text" name="company_name" id="company_name" value="<?php if($arrUsers!=null) echo $arrUsers['company_name'];?>" class="required form-control"/>
		    	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Country:</label>
				<div class="col-sm-3">
					<select name="country_id" id="country_id"  class="required form-control" onchange="getStatesByCountryId();">
						<option value="0">-- Select --</option>
						<?php foreach( $arrCountry as $country ){ ?>
							<option value="<?php echo $country['country_id']?>" <?php if($arrUsers['country_id']==$country['country_id']){?> selected="selected"<?php }?>>
							<?php echo $country['country_name']?>
							</option>
						<?php }?>
					</select>
		    	</div>
		    	<label class="col-sm-3 col-form-label">State:</label>
				<div class="col-sm-3">
					<select name="state_id" id="state_id"  class="form-control" onchange="getCitiesByStateId();">
						<option value='0'>-- Select State --</option>
						<?php foreach($arrStates as $state ){ ?>
							<option value="<?php echo $state['state_id']?>" <?php if($arrUsers['state_id']==$state['state_id']){?> selected="selected"<?php }?>>
							<?php echo $state['state_name']?>
							</option>
						<?php }?>
					</select>
		    	</div>	
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">City:</label>
				<div class="col-sm-3">
					<select name="city_id" id="city_id"  class="form-control">
						<option value='0'>-- Select City --</option>
						<?php foreach($arrCities as $city ){ ?>
							<option value="<?php echo $city['city_id']?>" <?php if($arrUsers['city_id']==$city['city_id']){?> selected="selected"<?php }?>>
							<?php echo $city['city_name']?>
							</option>
						<?php }?>
					</select>
		    	</div>
		    	<label class="col-sm-3 col-form-label">Postal-Code:</label>
				<div class="col-sm-3">
					<input type="text" name="postal_code" id="postal_code" value="<?php if($arrUsers!=null) echo $arrUsers['postal_code'];?>" class="form-control"/>
		    	</div>	
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Address:</label>
				<div class="col-sm-9">
					<input type="text" name="address" id="address" value="<?php if($arrUsers!=null) echo $arrUsers['address'];?>" class="form-control"/>
		    	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Profile-Picture<br><span style="font-size: 11px">(Recommended size: 100x50)</span>:</label>
				<div class="col-sm-9">
				<input type="file" name="profile_pic" id="profile_pic" class="form-control" style="width:40%;display: inline;"/>
				<?php 
				if($arrUsers['profile_pic']!=null){
					$clientLogo = $arrUsers['profile_pic'];
						echo '<input type="hidden" name="old_profile_pic" value="'.$clientLogo.'"/>';
						echo '<img src="'.base_url().'images/user_profile_pictures/'.$clientLogo.'" style="height: 100px;"/>';
					}
 				?>
			    </div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Username:</label>
				<div class="col-sm-9">
					<input type="text" name="user_name" id="user_name" value="<?php if($arrUsers!=null) echo $arrUsers['user_name'];?>" class="required form-control"/>
		    	<div id="Username_duplicate_error"></div>
		    	</div>
		</div>
		<?php if($this->session->userdata('client_id')==INTERNAL_CLIENT_ID){?>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Password:</label>
				<div class="col-sm-9">
					<input type="password" name="password" id="password" value="" class="required form-control"/>
			    	<br> <input type="checkbox" name="show_password" onclick="showPassword()">Show Password<br>
			    	 <div id="msg"></div>
		    	</div>
		</div>
		<?php }?>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Is Test-user?:</label>
				<div class="col-sm-9">
					<input type="radio" name="is_test_user" value="0" checked="checked" /> No
					<input type="radio" name="is_test_user" value="1"  <?php if($arrUsers['is_test_user']=='1'){?>checked="checked"<?php }?> /> Yes
		    	</div>
		</div>
		<div class="form-group row">
			<label class="col-sm-3"></label>
				<div class="col-sm-9">
				<div class="clientUserMsgBox"></div>
   		  	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label"></label>
		   		<div class="col-sm-9">
		   			<input type="button" value="Save" name="submit" onclick="saveUserDetail();" class="btn btn-primary">
               <a type="button" class="btn btn-primary" href="<?php echo base_url();?>clients/clients/list_users">Cancel</a>
                </div>
		</div>
		</form>
	</div>