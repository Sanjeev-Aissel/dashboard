<?php
/**
 * File to 'view' all Reports for client view  
 *
 * @author: Ambarish N
 * @created on: 15-01-11
 */
if($reportSection == 'user_analytics' || $reportSection == 'ktl_analytics' || $reportSection == 'summary'){
	$newly_added_report = true;
	$profile_type = array('Basic', 'Full Profile', 'User Added', 'Legacy');
	$month_list = array('01'=>"January", '02'=>"February", '03'=>"March", '04'=>"April", '05'=>"May", '06'=>"June", '07'=>"July", '08'=>"August",
			'09'=>"September", '10'=>"October", '11'=>"November",'12'=>"December");
}
$autoSearchOptions = "width: 160, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
$arrmonthList = array();
?>
<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array(
	                        'jqgridExportToExcel'   
							);
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<!--  Charting plugins -->
	<!-- 
	<script src="<?php echo base_url()?>js/exporting.js" type="text/javascript"></script>
	 -->
<!--  Autocomplete Plugin -->
	<!--<script type="text/javascript" src="<?php echo base_url()?>js/jquery.autocomplete.js"></script>
	
--><!--  Jquery UI plugins --><!--
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery/jquery-ui-1.8.16.slider.js" ></script>	
	
<script type="text/javascript" src="<?php echo base_url();?>/js/kol.publications.chart.js"></script>

	-->
<script type="text/javascript">
</script>	
<script language="javascript" type="text/javascript" src="<?php echo base_url()?>js/chosen.jquery.js"></script>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/refinedByFilter.css" />
<style type="text/css">
/*		
	#meshTermsChart {
		width: 400px;
	}
	#substancesChart{
		width: 500px;
	}
	#pubJournalsChart{
		width: 600px;
	}
	
*/  #asmtScoreReport .asmtScoreCategoryBar .progress{
	   width: 550px !important;
	}
    #pubsChart,#totalOrganizationChart,#kolsByCountryChart,#kolsBySpecialtyChart,#kolsByEventTypeChart,#kolsPubChart {
		text-align:center;
	}   
	
	#kolsActivitiesChart{
	/*	margin-left:265px; 
		position: absolute;*/
		min-width: 600px;
		min-height: 420px;
		text-align: center;
	}
	#kolsActivitiesChart .highcharts-container{
		margin:auto;
	}
	#gbox_listKolsByActivityReportResultSet{
		margin:auto;
	}
	#eventsByTimeline{
	/*	position: absolute !important;*/
		min-width: 700px;
		min-height: 420px;
		text-align:center;
	}
	#eventsByTimeline .highcharts-container{
		margin: auto;
	} 
	 
	.pieCharts div{
		margin: auto;
	}
	.filterBar{
	   cursor: pointer;
	}
	
	#contents{
		text-align:center;
	}
	
	#eventsByActivityContainer fieldset {
		width:98%;
		padding:2px;
	/*	margin-left:360px; */ 
	}
	
	#eventsByActivityContainer fieldset legend{
		margin: 0 46%;
	}
	#searchLeftBar{
		display: inline;
		float: left;
	}
	
	#timeLineSliderContainer{
		display: block;
		padding-top: 25px;
	}
	
	#kolId{
		width:150px;
	}
	/*
	#scatTable{
		width:auto;
	}*/
	.span-4 {
		width:170px;
	}
	#searchFiltersElements ul{
		padding-left: 1px;
		margin-right: 0px;
		padding-left: 5px;
	}
	#searchFiltersElements ul li{
		font-size: 12px;
		list-style: none;
		color:#000000;
		font-style: normal;
		font-family: inherit;
	}
	
	#searchLeftBar li.category{
		border-top:1px dotted #999999;
		overflow:visible;
		position:relative;
	/*	margin-right: 10px;*/
	}
	
	#searchLeftBar li#categoryCountry{
		border-top:0px dotted #999999;
		margin-top:0;
		padding-top:0;
	}
	
	#searchLeftBar label.facet-toggle {
		background:transparent url("<?php echo base_url();?>images/sprite_facetsearch_v7.png") no-repeat scroll 0 -61px;
		cursor:pointer;
		display:block;
		font-size:85%;
		height:11px;
		position:absolute;
		right:0;
		text-indent:-99999px;
		top:10px !important;
		width:11px;
	}
	
	#searchLeftBar label.facet-toggle:hover {
		background-position: 0px -76px;
	}
	
	#searchLeftBar label.collapsed{
		background-position:-20px -61px;
	}
	
	#searchFiltersElements ul li.allIndicator{
		font-weight: bold;
	}
	
	#searchFiltersElements ul li.allIndicator label{
		padding-left:4px;
		font-weight: bold;
	}
	
	#searchFiltersElements  input[type="checkbox"] {
		margin-left: -18px;
	}
	#categoriesContainer ul li label{
		margin-left: -6px;
		font-family:inherit;
		font-size:11px;
		font-style:normal;
		font-weight: normal;
	}
	#resetBttnContainer{
		text-align: right;
		vertical-align: middle;
		font-style: normal;
		color: #000099;
	}
	.highcharts-axis text{
		fill:#000000 !important;
		color:#000000;
	}
	
	th.ui-th-column div{
        white-space:normal !important;
        height:auto !important;
        padding:1px;
    }
    #lui_kolsProfileScore{
    	width:0;
    }
/*    #profileScoreGridContainer{
    	margin-left:133px;
    	width:800px;
    }

    .gridWrapper{
    	overflow: scroll !important;
    }
  */
    .myclass td{
    	color:blue !important;
    }
    
	 .professionalExp1{
	 	color:#2222BB;
	 }
	 .researchColumn1{
	 	color:#DD2222;
	 }
	 
	 .eventsColumn1{
	 	color:brown;
	 }
	
	 #profileScoreGridContainer label.facet-toggle {
	    background: url("<?php echo base_url()?>images/kolm-sprite-image.png") no-repeat scroll -8px -91px transparent;
	}
	 #profileScoreGridContainer label.collapsed {
	    background-position: -28px -91px;
	}
	
	 #profileScoreGridContainer label.facet-toggle {
	    cursor: pointer;
	    display: block;
	    font-size: 85%;
	    height: 11px;
	    position: relative;
	    right: 0;
	    text-indent: -99999px;
	    top: 14px;
	    width: 11px;
	    margin-left: 19px;
	}
	#profileScoreGridContainer label{
		font-weight:normal;
	}
	
/*	#eventsByActivityContainer #gridContainer{
		overflow: auto !important;
	}
*/ 
	#refinedByContainer{
		border:0px;
	}
	#kolsActivitiesChart, #gridContainer{
		width: 850px !important;
	}
	#drilldownPage, #gridContainer{
		width: 850px !important;
	}	
	#drilldownPage, #publicationsListingContainer{
		width: 850px !important;
	}
	.scrollable_div{
		width: 1150px;
	    height: auto;
	    border: 1px solid #eee;
	    overflow-x: scroll;
	    overflow-y: hidden;
	    white-space: nowrap;
	}
		
	div#specialtyForProfileScore_chzn {
    /* margin-top: 0px; */
    vertical-align: middle;
	}
	#left{
		width: 855px;
		float: left;
		display: inline;
	}
	#right{
		width: 300px;
		float: right;
		display: inline;
		border: 1px solid #ccc;
	}
	.right-form{
		margin-bottom: 0;
	}
	.right-form tr td{
		padding: 10px 15px;
    	border-bottom: 1px solid #ccc;
	}
	.right-form h3{
		color: #2b9af3;
		font-size: 12px;
    	font-weight: bold;
    	margin: 0;
	}
	.right-form .funnelIcon{
		margin: 0;
	}
	#resetBttn {
    	margin: 0;
	}
	<?php if($newly_added_report == true){ ?>
	#container{
		margin-top:-29px;
	}	
	#kol-name{
		width:97%;
	}
	.gridWrapper .ui-widget-content{
		margin-top:1px !important;
			}
	.gridWrapper {
		overflow: visible;
		width: 100%;
		}
	#container{
		margin-top:-30px;
	}	
	.right-form{
		margin-bottom: 0;
	}
	.right-form tr td{
		padding: 10px 15px;
    	border-bottom: 1px solid #ccc;
	}
	.right-form h3{
		color: #2b9af3;
		font-size: 12px;
    	font-weight: bold;
    	margin: 0;
	}
	.right-form .funnelIcon{
		margin: 0;
	}
	#resetBttn {
    	margin: 0;
	}
	.ui-th-column, .ui-jqgrid .ui-jqgrid-htable th.ui-th-column{
		white-space: pre-line;
	}
	.gridWrapper .ui-jqgrid .ui-jqgrid-htable th div{
		height: 35px;
	}
	#analyticsFilterForm select{
			/* width:142px; */
			width: 100%;
		}
	#analyticsFilterForm input{
			/* width:142px; */
			/* width: 100%; */
		}	
	p#submitButton{
	    	text-align: center;
	    	width: 100%;
	    }
	.btnDone.ui-state-default.ui-corner-all {
	    background: #2b9af3 none repeat scroll 0 0 !important;
	    height: 25px;
	}
	.ui-daterangepicker li{
    	text-align: left;
    }
	.ui-daterangepicker ul{
		width: 175px !important;
	}
	.ui-daterangepicker button.btnDone{
		font-size: 12px !important;
		color:#FFF !important;
		padding-bottom: 22px;
		background: -moz-linear-gradient(center top , #5689DB 0%, #4D7BD6 100%) repeat scroll 0 0 transparent !important;
	    background: -webkit-gradient(linear,left top,left bottom,color-stop(0%,#5689DB),color-stop(100%,#4D7BD6)) !important;
		background: -webkit-linear-gradient(top,#5689DB 0%,#4D7BD6 100%) !important;
		background: -o-linear-gradient(top,#5689DB 0%,#4D7BD6 100%) !important;
		background: -ms-linear-gradient(top,#5689DB 0%,#4D7BD6 100%) !important;
		filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#5689db,endColorstr=#4d7bd6,GradientType=0) !important;
		background: linear-gradient(top,#5689DB 0%,#4D7BD6 100%) !important;
	}
	input[type="button"], input[type="submit"], input[type="reset"], button, a.blueButton {
    line-height: 19px;
    min-width: 90px;
	}
	.chzn-container-multi .chzn-choices .search-field input {
    padding-left: 4px !important;
	}
	p {
	    margin: 0 !important; 
	}
	div#filtersContainer {
	    min-height: 550px;
	}
	.title-bar-actions {
    margin-right: 15px;
    margin-top: -6px;
    float: right;
	}
	#griduserAnalyticsContainer .ui-jqgrid-bdiv{
           max-height: 267px !important;   
           /* overflow-x:hidden;     */     
    }    
    <?php if($reportSection == 'user_analytics'){ ?>
    #JQBlistuserAnalyticsDetails_login_count, #JQBlistuserAnalyticsDetails_kol_access, #JQBlistuserAnalyticsDetails_num_payments
, #JQBlistuserAnalyticsDetails_num_interactions, #JQBlistuserAnalyticsDetails_num_contracts, #JQBlistuserAnalyticsDetails_num_plans{
	background: #dde7f5 !important;
	}
	tr.ui-jqgrid-labels th {
    padding: 2px !important;
	}
	tr.ui-jqgrid-labels {
    background: #f1f1f1;
	}	
	.frozen-bdiv.ui-jqgrid-bdiv {
    z-index: 11;
    background: #fff !important;
	}
	<?php }
	if($reportSection == 'ktl_analytics'){ ?>
	 .frozen-div.ui-state-default.ui-jqgrid-hdiv {
		    background: #fff;
		    padding-top: 12px;
   			 line-height: 6px;
   			 height: 46px !important;
   			 overflow-y:hidden;
		}
	div#gridktlAnalyticsContainer {
    /* overflow-x: scroll;*/
    width: 100%;
    	}
    #gridktlAnalyticsContainer .ui-jqgrid-bdiv{
      max-height: 267px !important;
    }	
    div#griduserAnalyticsContainer{
    display: none;
    }	
    .frozen-bdiv.ui-jqgrid-bdiv{
    z-index:11;
    background: #fff !important;
	}
	.ui-widget-content .jqgrow ui-row-ltr{
	z-index:10;
	}
	<?php }
	if($reportSection == 'summary'){ ?>
	.individualRegion{
	    width: 190px;
	    border: 1px solid #ccc;
	    text-align: center;
	    padding: 10px 0px 10px 0px;
	    float: left;
	    margin: 0px 10px 5px 10px;
	    background: #e8ebef;
		}
	.individualUser{
    width: 190px;
    border: 1px solid #86b2d6; /*#ccc;*/
    text-align: center;
    padding: 10px 0px 10px 0px;
    float: left;
    margin: 0px 10px 5px 10px;
    background: #dde7f5;
	}	
	.regionselected{
	    border: 1px solid #328300 !important;
	    background: rgba(91, 140, 3, 0.33)  !important;
		}
	#JQBlistsummaryReportDetails_accessed_ktls,.ui-state-hover
	,#JQBlistsummaryReportDetails_total_users,#JQBlistsummaryReportDetails_active_users,#JQBlistsummaryReportDetails_inactive_users,#JQBlistsummaryReportDetails_registration,#JQBlistsummaryReportDetails_accessed_system {
	    background: #dde7f5 !important;
	}	
	#JQBlistsummaryReportDetails_crawled,.ui-state-hover
	,#JQBlistsummaryReportDetails_requested,#JQBlistsummaryReportDetails_updated,#JQBlistsummaryReportDetails_ktl_accessed {
	    background: #fcd48d !important;
	}	
	div#gridktlAnalyticsContainer,div#griduserAnalyticsContainer,div#analyticsDrillDownContainer {
		display: none;
		}
	th.ui-state-default.ui-th-column-header.ui-th-ltr {
    text-align: center;
	}
	tr.ui-search-toolbar {
    display: none;
	}		
	
	
<?php } ?>
}
<?php }?>
</style>
	<?php if($newly_added_report == true){ ?>
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url();?>css/StyleCalender.css" />
	<link rel="stylesheet" href="<?php echo base_url();?>css/ui.daterangepicker.css" type="text/css" />
	<link href='<?php echo base_url();?>css/fullcalendar.css' rel='stylesheet' />
	<link href='<?php echo base_url();?>css/fullcalendar.print.css' rel='stylesheet' media='print' />
	<script src='<?php echo base_url();?>js/moment.min.js'></script>
	<script src='<?php echo base_url();?>js/fullcalendar.min.js'></script>
	<?php } ?>
	<script type="text/javascript">
	var arrExcludeColumnsInExcelExport = new Array('id',' '); 
	var t = 0;
	var arrExcludeHeaderColumnsInExcelExport = new Array('Id','Pos','<label class="professionalExp">Clinical Practice<label>','<label class="professionalExp">Teaching<br />Experience</label>','<label class="professionalExp">Society<br />Exec<br />Comitte</label>','<label class="professionalExp">Society<br /> Board <br />Memberships</label>','<label class="professionalExp">Guidelines<br />Count</label>','<label class="professionalExp">Government<br /> Agency<br /> Affiliations</label>','<label class="researchColumn">Researcher <br /> Status</label>','<label class="researchColumn">Clinical<br /> Trials</label>','<label class="eventsColumn">Executive<br />Committee</label>','<label class="eventsColumn">Speaking<br />Engagements</label>','<label class="eventsColumn">Faculty<br />at<br />Events</label>','<label class="eventsColumn">Panelist <br />at<br />Events</label>');
	var activityTitle = "<?php echo lang("Reports.ActivityTitle");?>";
	var kolNameHeader = "<?php echo lang("track.KOLName");?>";
	var eventsHeader = "<?php echo lang("Mykols.Events");?>";
	var affiliationsHeader = "<?php echo lang("Mykols.Affiliations");?>";
	var publicationsHeader = "<?php echo lang("Mykols.Publications");?>";
	var trialsHeader = "<?php echo lang("MyLists.Trials");?>";
	var totalHeader = "<?php echo lang("MyLists.Total");?>";
	var section = "overAllReport";
	var ie ='';
	jqgridIds	= new Array('kolsProfileScore','listKolsByActivityReportResultSet');
	jqgridMinWidth	= 881;
	jqgridMaxWidth	= 1181;
	if(isiPad===true){
		jqgridMinWidth	= jqgridWidthForiPad;
	}
	
$(document).ready(function(){
	<?php 
    		$u_agent = $_SERVER['HTTP_USER_AGENT']; 
			if(preg_match('/MSIE/i',$u_agent)){
			
			
    	?>
    	ie = true;	
        <?php }?>
	
	<?php if(isset($specialty)){
	?>
	var specialtyId = '<?php echo $specialty ?>';
	var kolIdForProfileScore = '<?php echo $kolIdForProfileScore ?>';
	showKolsIndividualCounts(specialtyId,kolIdForProfileScore);
	<?php }?>

	
});
	var reportSection='<?php echo $reportSection;?>';
	var options, a;
	
	// Autocomplet Options for the 'role' field 
  	var SpecialtyNameAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>kols/get_specialty_names',
			onSelect : function(event, ui) {specialtyBox('form')}, 
			<?php echo $autoSearchOptions;?>
		};	

	// Autocomplet Options for the 'country' field
	var countryNameAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>country_helpers/get_country_names',
			onSelect : function(event, ui) {countryBox('form')},
			<?php echo $autoSearchOptions;?>
		};	
	// Autocomplet Options for the 'state' field
	var stateNameAutoCompleteOptions = {
			serviceUrl: '<?php echo base_url();?>country_helpers/get_state_names',
			onSelect : function(event, ui) {stateBox('form')},
			<?php echo $autoSearchOptions;?>
		};
	$(document).ready(function(){
		var addKolsCustomFilters={
			title: "Add Custom Filters",
			modal: true,
			autoOpen: false,
			width: 400,
			height: 400,
			position: ['center', modalBoxTopPosition],
			dialogClass: "microView",
			draggable:false,
			open: function(){
	
			}
		};
		$( "#addKolsCustomFilters" ).dialog(addKolsCustomFilters);	
	});
	
	$(document).ready(function(){
		$("#chartType").chosen({disable_search_threshold: 10});
		$("#specialtyForProfileScore").chosen();
	});
	function getSavedFilters(){
		$("#addKolsCustomFilters .profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$('#addKolsCustomFilters').dialog("open");
		$('#addKolsCustomFiltersContainer').load(base_url+'kols/get_saved_filters/');
	}
	var sfId = '';
	<?php if($arrFilterById['id'] != ''){?>
		sfId = parseInt(<?php echo $arrFilterById['id'];?>);
	<?php }?>
	$(document).ready(function(){
			<?php if($arrFilterById['id'] != ''){?>
				var sfId = parseInt(<?php echo $arrFilterById['id'];?>);
			<?php }?>
			
		});
	function displaySelectedChart1(){
			if(sfId != ''){
				activeCustmFilters(sfId);
			}else{
				displaySelectedChart(); 
			}
		}
		
	function showProfessioalColumns(thisEle){
		var cls = $(thisEle).attr('class');
		var id  =  $(thisEle).attr('id');
		
			if(id=="professional"){	
				if(cls=='facet-toggle collapsed'){
						//jQuery("#kolsProfileScore").jqGrid('hideCol',["amount","tax"]); 
						jQuery("#kolsProfileScore").jqGrid('showCol',["practiseCount","teachingCount","socialComitteCount","socialBoardCount","guidelineCount","governmentCount"]); 
						$(thisEle).removeClass('collapsed');
						$(thisEle).addClass('expanded');
						t = t+1;
						arrRemoveElements = new Array('<label class="professionalExp">Clinical Practice<label>','<label class="professionalExp">Teaching<br />Experience</label>','<label class="professionalExp">Society<br />Exec<br />Comitte</label>','<label class="professionalExp">Society<br /> Board <br />Memberships</label>','<label class="professionalExp">Guidelines<br />Count</label>','<label class="professionalExp">Government<br /> Agency<br /> Affiliations</label>');
						arrExcludeHeaderColumnsInExcelExport = arrExcludeHeaderColumnsInExcelExport.filter( function( el ) {
							  return arrRemoveElements.indexOf( el ) < 0;
							} );
				}else{
						jQuery("#kolsProfileScore").jqGrid('hideCol',["practiseCount","teachingCount","socialComitteCount","socialBoardCount","guidelineCount","governmentCount"]);
						$(thisEle).removeClass('expanded');
						$(thisEle).addClass('collapsed');
						t = t-1;
						arrExcludeHeaderColumnsInExcelExport.push('<label class="professionalExp">Clinical Practice<label>','<label class="professionalExp">Teaching<br />Experience</label>','<label class="professionalExp">Society<br />Exec<br />Comitte</label>','<label class="professionalExp">Society<br /> Board <br />Memberships</label>','<label class="professionalExp">Guidelines<br />Count</label>','<label class="professionalExp">Government<br /> Agency<br /> Affiliations</label>');
				}
			}
			
			if(id=="research"){
				if(cls=='facet-toggle collapsed'){
					jQuery("#kolsProfileScore").jqGrid('showCol',["authPosCount","trialCount"]); 
					$(thisEle).removeClass('collapsed');
					$(thisEle).addClass('expanded');
					t = t+1;

					arrRemoveElements = new Array('<label class="researchColumn">Researcher <br /> Status</label>','<label class="researchColumn">Clinical<br /> Trials</label>');
					arrExcludeHeaderColumnsInExcelExport = arrExcludeHeaderColumnsInExcelExport.filter( function( el ) {
						  return arrRemoveElements.indexOf( el ) < 0;
						} );
				}else{
					$(thisEle).removeClass('expanded');
					$(thisEle).addClass('collapsed');
					jQuery("#kolsProfileScore").jqGrid('hideCol',["authPosCount","trialCount"]);
					t = t-1;
					arrExcludeHeaderColumnsInExcelExport.push('<label class="researchColumn">Researcher <br /> Status</label>','<label class="researchColumn">Clinical<br /> Trials</label>');
				}
			}
			
			if(id=="eventCol"){
				if(cls=='facet-toggle collapsed'){
					jQuery("#kolsProfileScore").jqGrid('showCol',["executiveCount","speakingCount","facultyCount","panelistCount"]); 
					$(thisEle).removeClass('collapsed');
					$(thisEle).addClass('expanded');
					t = t+1;
					arrRemoveElements = new Array('<label class="eventsColumn">Executive<br />Committee</label>','<label class="eventsColumn">Speaking<br />Engagements</label>','<label class="eventsColumn">Faculty<br />at<br />Events</label>','<label class="eventsColumn">Panelist <br />at<br />Events</label>');
					arrExcludeHeaderColumnsInExcelExport = arrExcludeHeaderColumnsInExcelExport.filter( function( el ) {
						  return arrRemoveElements.indexOf( el ) < 0;
						} );
				}else{
					$(thisEle).removeClass('expanded');
					$(thisEle).addClass('collapsed');
					jQuery("#kolsProfileScore").jqGrid('hideCol',["executiveCount","speakingCount","facultyCount","panelistCount"]); 
					t = t-1;
					arrExcludeHeaderColumnsInExcelExport.push('<label class="eventsColumn">Executive<br />Committee</label>','<label class="eventsColumn">Speaking<br />Engagements</label>','<label class="eventsColumn">Faculty<br />at<br />Events</label>','<label class="eventsColumn">Panelist <br />at<br />Events</label>');
				}
			}
			if(t == 3){
				arrExcludeHeaderColumnsInExcelExport = new Array('Id','Pos');	
			}
			if(t == 0){
				arrExcludeHeaderColumnsInExcelExport = new Array('Id','Pos','<label class="professionalExp">Clinical Practice<label>','<label class="professionalExp">Teaching<br />Experience</label>','<label class="professionalExp">Society<br />Exec<br />Comitte</label>','<label class="professionalExp">Society<br /> Board <br />Memberships</label>','<label class="professionalExp">Guidelines<br />Count</label>','<label class="professionalExp">Government<br /> Agency<br /> Affiliations</label>','<label class="researchColumn">Researcher <br /> Status</label>','<label class="researchColumn">Clinical<br /> Trials</label>','<label class="eventsColumn">Executive<br />Committee</label>','<label class="eventsColumn">Speaking<br />Engagements</label>','<label class="eventsColumn">Faculty<br />at<br />Events</label>','<label class="eventsColumn">Panelist <br />at<br />Events</label>','Total');
			}
			
			
		// get the header row which contains
        headerRow = jQuery("#kolsProfileScore").closest("div.ui-jqgrid-view")
            .find("table.ui-jqgrid-htable>thead>tr.ui-jqgrid-labels");
    
        // increase the height of the resizing span
        resizeSpanHeight = 'height: ' + headerRow.height() + 'px !important; cursor: col-resize;';
        headerRow.find("span.ui-jqgrid-resize").each(function () {
            this.style.cssText = resizeSpanHeight;
        });
    
        // set position of the dive with the column header text to the middle
        rowHight = headerRow.height();
        headerRow.find("div.ui-jqgrid-sortable").each(function () {
            var ts = $(this);
            ts.css('top', (rowHight - ts.outerHeight()) / 2 + 'px');
        });
	}
<?php if($newly_added_report == true){ ?>
	var kolNameAutoCompleteOptions = {
		<?php 
		if(KOL_CONSENT){?>
		serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete/0/1',
		<?php }else{ ?>
		serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete',
		<?php }?>
		<?php echo $autoSearchOptions;?>,
		onSelect : function(event, ui) {
			var kolId = $(event).children('.id1').html();
			var selText = $(event).children('.kolName').html();
			selText=selText.replace(/\&amp;/g,'&');
			$('#kol-name').val(selText);
			$('#kol-id').val(kolId);
		}
	}
	$(document).ready(function(){
			a= $('#kol-name').autocomplete(kolNameAutoCompleteOptions);
			<?php if($reportSection != 'summary'){?>
					$('#startDate, #endDate').daterangepicker();
					$('#startDate').val(monthFirstDate);
					var cdate = get_currentdate();
			        $('#endDate').val(cdate);
			<?php } ?>
	        $('#manager_id').chosen({
	            placeholder_text: "Click to Select Manager",
	            allow_single_deselect: true
	        });
	        $('#division_id').chosen({
	            placeholder_text: "Click to Select Division",
	            allow_single_deselect: true
	        });
	        $('#profile_type').chosen({
	            placeholder_text: "Click to Select Profile Type",
	            allow_single_deselect: true
	        });
	        $('#request_by').chosen({
	            placeholder_text: "Click to Select Requested User",
	            allow_single_deselect: true
	        });
	        $('#approve_by').chosen({
	            placeholder_text: "Click to Select Approved/Rejected User",
	            allow_single_deselect: true
	        });
	        $('#month_type').chosen({
	        	placeholder_text: "Click to Select Month(s)",
	            allow_single_deselect: true
	        });
	        $('#year_type').chosen({
	            allow_single_deselect: true
	        });
	        $("#kol-name").blur(function(){
				if($(this).val() == '')
					$("#kol-id").val('');
			});

	        <?php if($reportSection =='user_analytics'){ ?>
			user_analytics_report();
			<?php } ?>
			<?php if($reportSection =='ktl_analytics'){ ?> 
			ktl_analytics_report();
			<?php } ?>
			<?php if($reportSection =='summary'){ ?> 
			summary_report();
			<?php } ?>
	});
	function get_currentdate(){
		var today = new Date();
		var dd = today.getDate();
		var mm = today.getMonth()+1; //January is 0!
		var yyyy = today.getFullYear();
		if(dd<10) {
		    dd='0'+dd
		} 
		if(mm<10) {
		    mm='0'+mm
		} 
		today = mm+'/'+dd+'/'+yyyy;
		return today;
	}
	function appendActiveFunction(reportSection){
		switch(reportSection){
		case 'user_analytics':
			user_analytics_report();
			break;
		case 'ktl_analytics':
			ktl_analytics_report();
			break;
		case 'summary':
			summary_report();
			break;
			}
		}
	function generateAnalyticsReport(){
		resetDrillDownGrid();
		appendActiveFunction(reportSection);
		var globalRegion = $('#division_id').val();
		if(globalRegion != null && globalRegion != ''){
		var clas = $('#regionWiseCount').children().removeClass('regionselected');
			if(globalRegion != '' && globalRegion!=null){
				for(i=0; i < globalRegion.length; i++){
					var id = globalRegion[i].replace(/[^a-z0-9\s]/gi, '').replace(/[_\s]/g, '');
						$("#"+id).addClass('regionselected');
					}
				}
			}
		}
	function showHideSidebar(){
		var widthLeft = $("#left").width();
			if(widthLeft == 855){
				$("#left").css('width','1171px');
				$("#showHideSidebar").text("Show Sidebar");
			}else{
				$("#left").css('width','855px');
				$("#showHideSidebar").text("Hide Sidebar");
			}
			$("#right").toggle();
			appendActiveFunction(reportSection);
		}
	function formReset(){
		document.getElementById("analyticsFilterForm").reset();
			$('#regionWiseCount').children().addClass('regionselected');
			$("#kol-name").val('');
			$("#kol-id").val('');
			$('select').trigger('liszt:updated');
			$('#startDate').val(monthFirstDate);
			resetDrillDownGrid();
			// $('#endDate').val(todayDate);
         	var cdate = get_currentdate();
         	$('#endDate').val(cdate);
         	appendActiveFunction(reportSection);
    	}	
	function getKolsAccessed(user_id,user_name){
		ktl_accessed_user_analytics_report(user_id,user_name);
		}
	function getUsersAccessed(kol_id,kol_name){
		user_accessed_ktl_analytics_report(kol_id, kol_name);
		}
<?php } ?>	
	 </script>
<!-- JQGrid Plugins -->
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
	
<style>/*    Enable Verticle separator between content and side menu list  By Laxman   */
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
	.refinedBySideBar{
		position: absolute; 
		right: 0px;
		z-index: 100;
	}
	#chartType{
		margin:0px;
	}
	#chartType_chzn{
		vertical-align: top;
	}
<?php 
	if($reportSection == 'segmentation'){
		echo '#chartSelect{display:none;}';
		//echo '.expandRightSideBar{margin-left: -7px !important;}';
	}else{
		echo '#chartSelect{display:block;}';
	}
	if($reportSection == 'activity'){
		echo '#timeLineSliderContainer{display:none;}';
	}
	if($reportSection == 'rating'){
		echo '#dashboardTable{display:none;}';
	}
	if($newly_added_report == true){
		echo '#dashboardTable{display:none;}';
	}
?>
</style>
<div id="container">
<?php if($newly_added_report == true){ ?>
	<div style="width: 100%; text-align: right;margin-bottom: 5px;">
		<a href="#" class="blueButton" id="showHideSidebar" onclick="showHideSidebar();">Hide Sidebar</a>
	</div>
<?php } ?>	
	<div class="kolCharts">
		<!--<div id="searchLeftBar" class="span-5 last">
				<?php //echo $this->load->view($filterPage);?>
		</div>
			-->
		<!--<div class="rightBar rightRefinedByFilter">
			<div id="rightSideBarSliderShow" class="collapseRightSideBar tooltip-demo tooltop-left" style="display: none;"><a href="#" class="tooltipLink" rel='tooltip' title="Show Refine By">&nbsp;</a></div>
			<?php //echo $this->load->view($filterPage);?>
		</div>
		-->
		
		<div id="chartSelect">
			
			<?php
			if($reportSection != 'rating' && $newly_added_report != true){?>
			<label>Chart Type</label>
			<select name="chart_type" id="chartType" onchange="displaySelectedChart1()" style="width: 190px;">
			
				
				<?php 
					if($reportSection == 'events'):
						?>
						<option value="Events By Timeline">Events By Timeline</option>
						<!-- Removed as per the bug id 0000680: CR - Reports Changes
						<option value="Events By Session Type">Events By Session Type</option>
						<option value="Events By Role">Events By Role</option>
						-->
						<option value="Kols By EventType" selected="selected">Events By Type</option>
						<?php 
					endif;

					if($reportSection == 'affiliations'):
						?>
						<option value="Affiliations By Org Type" selected="selected">Affiliations By Org Type</option>
						<!-- Removed as per the bug id 0000680: CR - Reports Changes
						<option value="Affiliations By Eng Type">Affiliations By Eng Type</option>
						-->
						<?php 
					endif;

					if($reportSection == 'publications'):
						?>
						<option value="Publications By Year" selected="selected">Publications By Year</option>
						<option value="Publications By Keywords">Publications By Keywords</option>
						<option value="Publications By Substances">Publications By Substances</option>
						<option value="Publications By Journals">Publications By Journals</option>
						<option value="Publications By Type">Publications By Type</option>
						<?php 
					endif;

					if($reportSection == 'segmentation'):
						?>
						<option value="Scattered  Diagram" selected="selected">Scatter Diagram</option>
						<?php 
					endif;
					
					if($reportSection == 'activity'):
						?>
						<option value="Kols By Activity" selected="selected"><?php echo lang('Reports.KolsByActivity');?></option>
						<option value="Kols By Country" ><?php echo lang('Reports.KolsByCountry');?></option>
						<option value="Kols By Speciality"><?php echo lang('Reports.KolsBySpecialty');?></option>
						<option value="Kols By Publications"><?php echo lang('Reports.KolsByPublications');?></option>
						<?php 
					endif;						
				?>

			</select>
			<?php }elseif($reportSection == 'rating'){?>
				<label>Specialty</label>
				<select name="specialtyForProfileScore"  onchange="showKolsIndividualCounts(this.value,'')" id="specialtyForProfileScore">
					<option value="" >Select</option>
						<?php foreach($kolSpecialties as $key=>$value){
									if(isset($specialty)){
										if($specialty==$key){?>
											<option value="<?php echo $key?>" selected="selected"><?php echo $value?></option>
										<?php }else{?>
												<option value="<?php echo $key?>"><?php echo $value?></option>
									<?php 	}
									
									}
										
										else{?>		
										
						
						
					<option value="<?php echo $key?>"><?php echo $value?></option>
					<?php } }?>
				</select>
			<?php } ?>
		</div>
		
		
		<div id="chartsContainer">
		<table id="dashboardTable" class="tableSections">
			<tr class="tableHeader">
				<th id="chartTitleContainer"></th>
			</tr>
			<tr>
				<td>
			<div class="pieCharts">
				<div id="kolsByCountryChartLoaderContainer">
					<div id="kolsByCountryChart"></div>
				</div>
				<div id="kolsBySpecialtyChartLoaderContainer">
					<div id="kolsBySpecialtyChart">
					
					</div>
				</div>
				
				<div id="kolsByEventTypeChartLoaderContainer">
					<div id="kolsByEventTypeChart">
					</div>
				</div>
				<div id="kolsPubChartLoaderContainer">
					<div id="kolsPubChart">
					
					</div>
				</div>
				<div id="primaryOrgChart">
					<div id="totalOrgChartLoaderConatiner">
						<div id="totalOrganizationChart">
						
						</div>
					</div>
					<div id="affChartByEngTypeLoaderConatiner">
						<div id="affiliationsChartByEngType">
						
						</div>
					</div>
				</div>
				<div id="primaryEngChart">
					<div id="totalEngagementChartLoaderConatiner">
						<div id="totalEngagementChart">
						
						</div>
					</div>
					
					<div id="affChartByOrgTypeLoaderConatiner">
						<div id="affiliationsChartByOrgType">
						
						</div>
					</div>
				</div>
								
				<div>
					<div id="eventsChartBySessionTypeLoaderContainer">
						<div id="eventsChartBySessionType">
						
						</div>
					</div>
					<div id="roleChartBySessionTypeLoaderContainer">
						<div id="roleChartBySessionType">
						
						</div>
					</div>
				</div>
				<div id="events2">
					<div id="eventsChartByRoleLoaderContainer">
						<div id="eventsChartByRole">
						
						</div>
					</div>
					<div id="sessionChartByRoleLoaderContainer">
						<div id="sessionChartByRole">
						
						</div>
					</div>
				</div>
			</div>
			<div id="drilldownPage" ></div>
			<div id="eventsByActivityContainer"  style="display: none;">
				<div>
					<form action="" id="activityFilterForm" name="activityFilterForm" method="post">
						<fieldset style="margin-bottom:1px;">
							<legend>Weightage</legend>
							<label>Events: </label>
							<select id="evnetWeight" name="event_weight">
								<?php for($i=0;$i<=1;$i++){?>
									<option value="<?php echo $i;?>" <?php if($i==1) echo "SELECTED";?>>
										<?php echo $i;?>
									</option>
								<?php }?>
							</select>
						
						
							<label>Affiliations: </label>
							<select id="affWeight" name="aff_weight">
								<?php for($i=0;$i<=1;$i++){?>
									<option value="<?php echo $i;?>" <?php if($i==1) echo "SELECTED";?>>
										<?php echo $i;?>
									</option>
								<?php }?>
							</select>
						
						
							<label>Publications: </label>
							<select id="pubWeight" name="pub_weight">
								<?php for($i=0;$i<=1;$i++){?>
									<option value="<?php echo $i;?>" <?php if($i==1) echo "SELECTED";?>>
										<?php echo $i;?>
									</option>
								<?php }?>
							</select>
						
						<?php if(HIDE_CLINICAL_TRIALS){?>
							<label>Trials: </label>
							<select id="trialWeight" name="trial_weight">
								<?php for($i=0;$i<=1;$i++){?>
									<option value="<?php echo $i;?>" <?php if($i==1) echo "SELECTED";?>>
										<?php echo $i;?>
									</option>
								<?php }?>
							</select>
						<?php } ?>	
							<input type="button" value="Filter" id="filterActivity" name="filterActivity" onclick="displaySelectedChart(true)" />
						</fieldset>
					</form>
				</div>
				<div id="kolsActivitiesChart">
				
				</div>
				<div style="position: relative;z-index: 999;float: right;margin-right: 25px;margin-top: -2px;">
					<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="exportExcel('#listKolsByActivityReportResultSet','ktls_by_activity_report','','no_excludes');">
						<a href="#" rel="tooltip" data-original-title="Export <?php echo lang("KOL");?> By Activity Report into Excel format">&nbsp;</a>
					</div>
				</div>
				<div class="gridWrapper" id="gridContainer">
					<div id="listKolsByActivityReportPage"></div>
					<table id="listKolsByActivityReportResultSet"></table>
				</div>
			</div>
			<div>
				<div id="eventsByTimelineLoadContainer">
					<div id="eventsByTimeline">
					
					</div>
				</div>
			</div>
			<!--<div id="kolsPubChartLoaderContainer">
				<div id="kolsPubChart">
				
				</div>
			</div>
			-->
			<div class="pieCharts">
				<div>
					<div id="pubsChart">
					
					</div>
				</div>
				<div>
					<div id="meshTermsChart">
					
					</div>
				</div>
				<div>
					<div id="substancesChart">
					
					</div>
				</div>
				<div>
					<div id="pubJournalsChart">
					
					</div>
				</div>
					<div>
					<div id="pubTypeChart">
					
					</div>
				</div>
				<div>
					<div id="scatteredDiagramArea" style="display: none;">
						<?php if($reportSection=='segmentation')$this->load->view('reports/scatr_graph',$scatData);?>
					</div>
				</div>
			</div>
			</td>
				</tr>
			</table>
			<?php if($reportSection == 'rating'){?>
				<div id="excelBtnHolder" style="float: right;display: none;margin-right: 15px;margin-bottom: 5px;">
					<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="exportExcel('#kolsProfileScore','ktls_profile_score');">
						<a href="#" rel="tooltip" data-original-title="Export Profile Score into Excel format">&nbsp;</a>
					</div>
				</div>
				<div id="profileScoreGridWrapper">
							
				</div>
				<!-- End of Container for List Maodel box  -->
			<?php }?>
			<!-- New Analytics Report start portion -->
			<?php if($newly_added_report == true){ ?>
			<div id="left">
				<div class="gridWrapper" id="griduserAnalyticsContainer">
                                	<div id="listuserAnalyticsDetailsPage"></div>
                                	<table id="JQBlistuserAnalyticsDetails"></table>
            	</div>
            	<div class="gridWrapper" id="gridktlAnalyticsContainer">
                                	<div id="listktlAnalyticsDetailsPage"></div>
                                	<table id="JQBlistktlAnalyticsDetails"></table>
            	</div>
            	<div id="analyticsDrillDownContainer">
            		<div class="gridWrapper" id="gridKtlAccessUserAnalyticsContainer">
                                	<div id="listKtlAccessUserAnalyticsDetailsPage"></div>
                                	<table id="JQBlistKtlAccessUserAnalyticsDetails"></table>
            		</div>
            		<div class="gridWrapper" id="gridUserAccessKtlAnalyticsContainer">
                                	<div id="listUserAccessKtlAnalyticsDetailsPage"></div>
                                	<table id="JQBlistUserAccessKtlAnalyticsDetails"></table>
            		</div>
            	</div>
            	<?php if($reportSection == 'summary'){ ?>
					<div id="summaryReport">
						<div id="userWiseCount">
						<?php 
						foreach($arrPowerUsersCountGlobalRegion[0] as $key=>$value){
							if($value>0){
							?>
							<div class="individualUser">
								<h6 class="regionName"><?php echo str_replace('_', ' ', $key); ?></h6>
								<span class="regionCount"><?php echo $value; ?> User(s)</span>
							</div>
							<?php 
							}
						}?>
						</div>
						<div id="regionWiseCount">
							<?php 
							foreach($arrUserCountGlobalRegion as $row){
								if($row['GlobalRegion']!= NULL){
							?>
							<div class="individualRegion regionselected" id="<?php echo  preg_replace('/[^A-Za-z0-9\-]/', '', $row['GlobalRegion']); ?>">
								<h6 class="regionName"><?php echo $row['GlobalRegion']; ?></h6>
								<span class="regionCount"><?php echo $row['totalUser']; ?> User(s)</span>
							</div>
							<?php 
								}
							}?>
						</div>	
						<div style="clear:both;margin-bottom: 5px;"></div>
						<div class="gridWrapper" id="gridsummaryReportContainer">
									<div id="listsummaryReportDetailsPage"></div>
                                	<table id="JQBlistsummaryReportDetails"></table>
						</div>
					</div>
				<?php } ?>
				
			</div>
			<div id="right">
			<div id="filtersContainer">
				<form action="<?php echo base_url()?>reports/export_reports_details" method='post' id="export">
					<input type="hidden" name="filters" id="excel-filters" />
					<input type="hidden" name="filters1" id="excel-filters1" />
					<input type="hidden" name="report_type" id="excel-report-for" />
				</form>
		<form action="" name="analyticsFilterForm" id="analyticsFilterForm">
			<table class="table right-form">
				<tr>
					<td>
						<h3 style="width: 100px;float: left; display: inline;"><div class="funnelIcon sprite_iconSet"></div>Refine By</h3>
						<h3 style="width: 60px;float: right; display: inline;cursor: pointer;" onclick="formReset();"><div id="resetBttn" class="sprite_iconSet"><a href="#" class="tooltipLink" rel="tooltip" data-original-title="Reset Filters">&nbsp;</a></div>Reset</h3>
					</td>
				</tr>
				<tr>
					<td>
						<p id="submitButton">
							<input type="button" value="Apply Filters" onclick="generateAnalyticsReport();"/>
						</p>
					</td>
				</tr>
				<?php
				if($reportSection != 'summary'){
				?>
				<tr>
					<td>
						<label for=monthlyreport style="display: inline;">From </label><input type="text" name="start_date" id="startDate" style="width: 34%;">
						<label for=monthlyreport style="display: inline;">To </label><input type="text" name="end_date" id="endDate"  style="width: 34%;"/>
					</td>
				</tr>
				<?php
				}
				switch($reportSection){
					case 'user_analytics':
				?>
				<tr>
					<td>
						<p>
							<label for="manager">Division</label>
								<select class="" name="division_id[]" id="division_id" class="chosenMultipleSelect" multiple="multiple">
									<!-- option value="">Select</option>  -->
	                               	<?php foreach($arrDivision as $value){ 
	                               		if($value['GlobalRegion']!=null || !empty($value['GlobalRegion'])){
	                               		?>
	                               		<option value="<?php echo $value['GlobalRegion'];?>"><?php echo $value['GlobalRegion']; ?></option>
	                               	<?php }
										} ?>
	                            </select>
						</p>
					</td>
				</tr>
				
				<tr>
					<td>
						<p>
							<label for="manager">Manager</label>
								<select class="" name="manager_id[]" id="manager_id" class="chosenMultipleSelect" multiple="multiple">
									<!-- option value="">Select</option>  -->
	                               	<?php foreach($arrManager as $value){ ?>
	                               		<option value="<?php echo $value['id']; ?>"><?php echo $value['first_name'].' '.$value['last_name']; ?></option>
	                               	<?php }?>
	                            </select>
						</p>
					</td>
				</tr>
				<?php        
				    break;    
				    case 'ktl_analytics':
				?>
				<tr>
					<td>
						<p>
							<label for="manager">Profiles Requested for Web crawling </label><input type="checkbox" name="requested_ktl" id="requestedKtl" style="float:right;" /> 
						</p>
					</td>
				</tr>
				<tr>
					<td>
					<p>
						<label for="kol-name">KTL Name</label>
						<input type="text" name="kol_name" id="kol-name" class="autocompleteInputBox" placeholder="Enter KTL"/>
						<input type="hidden" name="kol_id" id="kol-id"></input>
					</p>
					</td>
				</tr>
				<tr>
					<td>
						<p>
							<label for="manager">KTL Division</label>
								<select class="" name="division_id[]" id="division_id" class="chosenMultipleSelect" multiple="multiple">
									<!-- option value="">Select</option>  -->
	                               	<?php foreach($arrDivision as $value){ 
	                               		if($value['GlobalRegion']!=null || !empty($value['GlobalRegion'])){
	                               		?>
	                               		<option value="<?php echo $value['GlobalRegion'];?>"><?php echo $value['GlobalRegion']; ?></option>
	                               	<?php }
										} ?>
	                            </select>
						</p>
					</td>
				</tr>
				<tr>
					<td>
						<p>
							<label for="manager">Profile Type</label>
								<select class="" name="profile_type[]" id="profile_type" class="chosenMultipleSelect" multiple="multiple">
									<!-- option value="">Select</option>  -->
	                               		<?php 
	                               		foreach($profile_type as $value){ 
			                               		?>
			                               		<option value="<?php echo $value;?>"><?php echo $value; ?></option>
			                               	<?php } ?>

	                            </select>
						</p>
					</td>
				</tr>
				<tr>
					<td>
						<p>
							<label for="manager">Requested By</label>
								<select class="" name="request_by[]" id="request_by" class="chosenMultipleSelect" multiple="multiple">
									<!-- option value="">Select</option>  -->
	                               <?php foreach($arrRequestedByUsers as $value){ ?>
	                               		<option value="<?php echo $value['id']; ?>"><?php echo $value['first_name'].' '.$value['last_name']; ?></option>
	                               	<?php }?>
	                            </select>
						</p>
					</td>
				</tr>
				
				<tr>
					<td>
						<p>
							<label for="manager">Approved By / Rejected By</label>
								<select class="" name="approve_by[]" id="approve_by" class="chosenMultipleSelect" multiple="multiple">
									<!-- option value="">Select</option>  -->
	                               	<?php foreach($arrApprovedByUsers as $value){ ?>
	                               		<option value="<?php echo $value['id']; ?>"><?php echo $value['first_name'].' '.$value['last_name']; ?></option>
	                               	<?php }?>
	                            </select>
						</p>
					</td>
				</tr>
				<?php
				    break;				    
				    case 'summary':
				?>
				<tr>
					<td>
						<p>
							<label for="manager">Division</label>
								<select class="" name="division_id[]" id="division_id" class="chosenMultipleSelect" multiple="multiple">
									<!-- option value="">Select</option>  -->
	                               	<?php foreach($arrDivision as $value){ 
	                               		if($value['GlobalRegion']!=null || !empty($value['GlobalRegion'])){
	                               		?>
	                               		<option value="<?php echo $value['GlobalRegion'];?>"><?php echo $value['GlobalRegion']; ?></option>
	                               	<?php }
										} ?>
	                            </select>
						</p>
					</td>
				</tr>
				<tr>
					<td>
						<p>
							<label for="manager">Year</label>
								<select class="" name="year_type[]" id="year_type" class="chosenMultipleSelect">
									<option value=""></option>
	                               <?php 
	                               
	                               for($i = '2017';$i<='2017';$i++){ ?>
	                               		<option value="<?php echo $i; ?>" <?php if(date("Y") == $i){ echo 'selected'; }?>><?php echo $i; ?></option>
	                               	<?php }  ?>
	                            </select>
						</p>
					</td>
				</tr>
				<tr>
					<td>
						<p>
							<label for="manager">Month</label>
								<select class="" name="month_type[]" id="month_type" class="chosenMultipleSelect" multiple="multiple">
									<option value=""></option>
	                               		<?php 
	                               		foreach($month_list as $key => $val){ 
			                               		?>
			                               		<option value="<?php echo $key;?>"><?php echo $val; ?></option>
			                               	<?php } ?>

	                            </select>
						</p>
					</td>
				</tr>
				<?php break; } ?>
			</table>
		</form>
		</div>
			</div>
			<?php } ?>
			<!-- New Analytics Report end portion -->
		</div>
		<?php /* if($reportSection != 'rating'){?>
		<div id="refinedByWrapper" class="refinedBySideBar">
			<div id="refinedByContainer">
				<div id="rightSideBarSlider" class="expandRightSideBar tooltip-demo tooltop-left"><a href="#" class="tooltipLink" rel='tooltip' title="Show Refine By">&nbsp;</a></div>
				<div id="searchLeftBar" style="display: none;">
					<?php //echo $this->load->view($filterPage);?>
				</div>
			</div>
		</div>
		<?php }*/?>
	</div>
	
	<!-- Container for List Maodel box  -->
	<div id="categoryModalBox">
		<div class="addListContent" ></div>
	</div>
	
	<!-- Container to add Custom filters -->
	<div id="addKolsCustomFilters1"></div>
	<div id="addKolsCustomFilters" class="addCustomFilters">
		<div id="addKolsCustomFiltersContainer" class="profileContent"></div>
	</div>
</div>
	<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts = array('reports/view_reports',
	'i18n/grid.locale-en','jquery.jqGrid.min.onlyforreports',
							//	'highcharts 2.1.0',
							//	'highchartsTheme',
								'highcharts2_2_2/highcharts3.0.5',
								'highcharts2_2_2/modules/exporting3.0.5',
								'jquery.autocomplete',								
								'jquery/jquery-ui-1.8.16.slider',
								'jquery/jquery.ui.touch-punch.min',
								'kol.publications.chart');
	// add the JS files into queue i.e Append to the existing queue
	if($newly_added_report == true && $reportSection != 'summary'){
		array_push($queued_js_scripts,
				'jquery/jquery-ui-1.8.16.datepicket',
				'jquery/date',
				'jquery/daterangepicker.jQuery'
		);
	}
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
	
?>
<!-- Load c3.css -->
    <link href="<?php echo base_url();?>c3js/c3.css" rel="stylesheet" type="text/css">
    
    <!-- Load d3.js and c3.js -->
    <script src="<?php echo base_url();?>c3js/d3.v3.min.js" charset="utf-8"></script>
    <script src="<?php echo base_url();?>c3js/c3.min.js"></script>    