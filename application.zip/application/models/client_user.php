<?php
/**
 * Model for Client users operations
 * 
 * @package application.models
 * @author Vinayak Malladad
 * @since 1.5
 * @created on  01-03-11
 */

class Client_User extends model{
	
	function Client_User(){
		parent::model();
	}

	/**
	 *  Insert Client details into DB
	 *	@author Vinayak Malladad
	 *	@since 1.5
	 *	@created_on 28-2-2011
	 *	@param $arrClient
	 *  @return true/false
	 */
	function saveClient($arrClient){
		if($this->db->insert('clients',$arrClient)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}

	/*
	 * 	Get 'Client' name details from 'clients' Table
	 *	@author Vinayak Malladad
	 *	@since 1.5
	 *	@created_on 28-2-2011
	 *	@return $arrClients
	 */
	function getClients($clientId){
		$arrClientResults = $this->db->get('clients');
        if($clientId!=INTERNAL_CLIENT_ID)
           $this->db->where('id',$clientId);
		foreach($arrClientResults->result_array() as $row){
			$arrClients[] = $row;
		}
		return $arrClients;
	}

	/**
	 * 	Edit Client details
	 * 	@param $clientId
 	 *	@author Vinayak Malladad
	 *	@since 1.5
	 *	@created_on 28-2-2011
	 * 	@return array - $arrClients 
	 */  
	function editClient($clientId){
		$arrClients = array();
		$this->db->where('id',$clientId);
		$arrClientResult = $this->db->get('clients');
		foreach($arrClientResult->result_array() as $row){
			$arrClients = $row;
		}
		return 	$arrClients;	
	}

	/**
	 * 	Update the Client detail for passed array $arrClient
	 *	@author Vinayak Malladad
	 *	@since 1.5
	 *	@created_on 28-2-2011
	 * 	@param  $arrClient 
	 *	@return true/false
	 * 	
	 */        
	function updateClient($arrClient){
	   
		$id = $arrClient['id'];
		$this->db->where('id',$id);
		if($arrClient = $this->db->update('clients',$arrClient))
			return true;
		else
			return false;
	} //End of Update

	/**
	 * Delete Client details
	 * @author Vinayak Malladad
	 * @since 1.5
	 * @created_on 28-2-2011
	 * @param integer $id 
	 * @return true
	 */     
	function deleteClient($id){
		$this->db->where('id',$id);
		$query = $this->db->delete('clients');
		//Add Log activity
		$arrLogDetails = array(
				'type' => DELET_RECORD,
				'description' => 'Delete Client Details',
				'status' => STATUS_SUCCESS,
				'transaction_id' =>  $id,
				'transaction_table_id' => CLIENTS,
				'transaction_name' => "Delete Client",
				'parent_object_id' =>  $id
		);
		$this->config->set_item('log_details', $arrLogDetails);
		return true;
	}

	/**
	 *  Insert Client Users details into DB
	 *	@author Vinayak Malladad
	 *	@since 1.5
	 *	@created_on 28-2-2011
	 *	@param $arrUser
	 *  @return true/false
	 */	
	function saveUser($arrUser){
		if($this->db->insert('client_users',$arrUser)){
			return $this->db->insert_id();
		}else{
			return false ;
		}
	}

	/*
	 * 	Get 'User' details from 'client_users' Table
	 *	@author Vinayak Malladad
	 *	@since 1.5
	 *	@created_on 28-2-2011
	 *	@return $arrUsers
	 */	
	function getUsers($clientId=0,$disableGroupCheck=false){
		$arrStatus	= array('Activated','Deactivated','Deleted');
		$arrUsers = array();
		$userGroupIds = getGroupDetails();
		$group_ids = explode(',',  $userGroupIds['group_ids']);
// 		$group_ids = explode(',', $this->session->userdata('group_ids'));
//		if($clientId>0)
		if($clientId>0 && $clientId!=INTERNAL_CLIENT_ID){
			$this->db->where('client_id',$clientId);
			$this->db->where_in('client_users.status',array(ACTIVATED_USER));
		}
		if($clientId!=INTERNAL_CLIENT_ID){
		    $this->db->where("client_users.client_id",$clientId);
		}
		if($this->session->userdata('user_role_id')==ROLE_USER || $this->session->userdata('user_role_id')==ROLE_READONLY_USER){
		    $userId	= $this->session->userdata('user_id');
		    $this->db->where("client_users.id",$userId);
		}
		$this->db->select('client_users.*,clients.name');
		$this->db->join('clients','clients.id=client_users.client_id','left');
		if(!$disableGroupCheck){
			if($this->session->userdata('user_role_id')==ROLE_MANAGER){
			    $this->db->join('user_groups','user_groups.user_id = client_users.id');
			    $this->db->where_in("user_groups.group_id",$group_ids);
			    $this->db->group_by('client_users.id');
			}
		}
		$this->db->order_by('first_name,last_name');		
		$arrUsersResults = $this->db->get('client_users');
		//echo $this->db->last_query();
		foreach($arrUsersResults->result_array() as $row){
				switch($row['user_role_id']){
					case 0: $row['user_role_name']="Read-Only User";
					break;
					case 1:	$row['user_role_name']="User";
					break;
					case 2: $row['user_role_name']="Manager";
					break;
					case 3:	$row['user_role_name']="Admin";
					break;
				}
			$row['status']	= $arrStatus[$row['status']];
			$arrUsers[] = $row;
		}
		return $arrUsers;
	}
	
	
	function getUsersForMedintel($clientId=0,$disableGroupCheck=false){
	    $userId	= $this->session->userdata('user_id');
	    $this->db->select('client_users.*,clients.name');
	    $this->db->join('clients','clients.id=client_users.client_id','left');
	    $this->db->where("client_id = $clientId"); 	    
	    $arrUsersResults = $this->db->get('client_users');
	    //pr($this->db->last_query());exit;
	    return $arrUsersResults->result_array();
	}
	
	/*
	 * 	Get 'User' details from 'client_users' Table
	 *	@author Laxman K
	 *	@since KOLM CORE v6.0.9
	 *	@created_on 05-06-2014
	 *	@return $arrUsers
	 */
	
	function getUsersList($limit=null,$startFrom=null,$doCount=null,$sidx = '',$sord = '',$where = ''){
		
		$clientId	= $this->session->userdata('client_id');
		$arrStatus	= array('Activated','Deactivated','Deleted');
		$arrUsers = array();
		$this->db->join('clients','clients.id=client_users.client_id','left');
		$this->db->join('client_users as responsible_users','responsible_users.id = client_users.status_modified_by','left');
		
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where('client_id',$clientId);
		}
		if(isset($where['user_ids'])){
			$this->db->where_in('client_users.id',$where['user_ids']);
		}
		if(isset($where['user_full_name'])){
			$this->db->like("CONCAT_WS(' ',client_users.first_name,client_users.last_name)",$where['user_full_name']);
		}
		if(isset($where['email'])){
			$this->db->like('client_users.email',$where['email']);
		}
		if(isset($where['client'])){
			$this->db->like('clients.name',$where['client']);
		}
		if(isset($where['company_name'])){
			$this->db->like('client_users.company_name',$where['company_name']);
		}
		if(isset($where['contact'])){
			$this->db->like('client_users.contact',$where['contact']);
		}
		if(isset($where['status'])){
			$status	= 0;
			$pattern = '/^'.$where['status'].'/i';
			if(preg_match($pattern, "Activated")) {
				$status	= 0;
			}else if(preg_match($pattern, "Deactivated")) {
				$status	= 1;
			}else if(preg_match($pattern, "Deleted")) {
				$status	= 2;
			}
			$this->db->where('client_users.status',$status);
		}

		if($doCount){
			$this->db->select('client_users.id');
			$count=$this->db->count_all_results('client_users');
			return $count;
		} else {
			$this->db->select('client_users.*,clients.name,responsible_users.first_name as resp_first_name,responsible_users.last_name as resp_last_name');
			if($sidx!='' && $sord!=''){
				switch($sidx){
					case 'user_full_name' :$this->db->order_by("client_users.first_name",$sord);
					break;
					case 'email' :$this->db->order_by("client_users.email",$sord);
					break;
					case 'client' :$this->db->order_by("clients.name",$sord);
					break;
					case 'company_name' :$this->db->order_by("client_users.company_name",$sord);
					break;
					case 'status' :$this->db->order_by("client_users.status",$sord);
					break;
					case 'contact' :$this->db->order_by("client_users.contact",$sord);
					break;
				}
				//$this->db->order_by($sidx,$sord);
			}
			$this->db->order_by('client_users.first_name,client_users.last_name');
			$arrUsersResults	=	$this->db->get('client_users',$limit,$startFrom);
			foreach($arrUsersResults->result_array() as $row){
				$updateStatusTo	= 0;
				$iconClass	= 'iconForOn';
				$tooltip	= '';
				switch($row['status']){
					case 0:$updateStatusTo	= 1;$iconClass	= 'iconForOff';$tooltip	= 'Deactivate User';
					break;
					case 1:$updateStatusTo	= 2;$iconClass	= 'deleteIcon';$tooltip	= 'Delete User';
					break;
					//case 2:$updateStatusTo	= 0;$iconClass	= 'iconForOn';$tooltip	= 'Activate';
					//	break;
				}
				$row['user_role']	= 'User';
				switch($row['user_role_id']){
					case 2:$row['user_role']	= 'Manager';
					break;
				}
				$row['client'] = $row['name'];
				$row['action']	= '';
				
				if($row['status']!=2){
					$row['action']	= "<div class='actionIcon'><a href='#' onclick='editClientUser(".$row['id']."); return false;' title='Edit User'>&nbsp;</a></div>";
					
					if($clientId==INTERNAL_CLIENT_ID && $this->session->userdata('user_role_id') == ROLE_MANAGER){
						if($row['status']==1){
							$row['action']	.= "<div class='actionIcon iconForOn'><a href='#' onclick='updateStatus(".$row['id'].",0,".$row['user_role_id']."); return false;' title='Activate User'>&nbsp;</a></div>";
						}
						$row['action']	.= "<div class='actionIcon ".$iconClass."'><a href='#' onclick='updateStatus(".$row['id'].",".$updateStatusTo.",".$row['user_role_id']."); return false;' title='".$tooltip."'>&nbsp;</a></div>";
					}
				}
				
				$row['user_full_name']	= $row['first_name']." ".$row['last_name'];
				$row['updated_by']	= $row['resp_first_name']." ".$row['resp_last_name'];
				$row['status']	= $arrStatus[$row['status']];
				if($row['find_experts'] == 1)
					$row['find_experts'] = 'Yes';
					else
						$row['find_experts'] = 'No';
						$arrUsers[] = $row;
			}
			return $arrUsers;
		}
	
	}
	/**
	 * 	Edit User details
	 * 	@param $clientId
 	 *	@author Vinayak Malladad
	 *	@since 1.5
	 *	@created_on 28-2-2011
	 * 	@return array - $arrUsers 
	 */  
	function editUser($userId){
		$arrUsers = array();
		$this->db->where('id',$userId);
		$arrUserResult = $this->db->get('client_users');
		foreach($arrUserResult->result_array() as $row){
			$arrUsers = $row;
		}
		return 	$arrUsers;	
	}


	/**
	 * 	Update the User detail for passed array $arrUser
	 *	@author Vinayak Malladad
	 *	@since 1.5
	 *	@created_on 28-2-2011
	 * 	@param  $arrUser 
	 *	@return true/false
	 * 	
	 */         
	function updateUser($arrUser){
	   
		$id = $arrUser['id'];
		$this->db->where('id',$id);
		if($arrUser = $this->db->update('client_users',$arrUser))
			return true;
		else
			return false;
	} //End of Update

	/**
	 * Delete User details
	 * @author Vinayak Malladad
	 * @since 1.5
	 * @created_on 28-2-2011
	 * @param integer $id
	 * @return true
	 */
	function disableUser($id){
		$this->db->where('id',$id);
		$arrUser['status']	= 1; // set status to 1 as disable
		$arrUser['disabled_by']	=   $this->session->userdata('user_id');
		$arrUser['disabled_on']	=	date('Y-m-d H:i:s');
		//$query = $this->db->delete('client_users');
		if($arrUser = $this->db->update('client_users',$arrUser))
			return true;
		else
			return false;
	}
	
	/**
	 * Delete User details
	 * @author Vinayak Malladad
	 * @since 1.5
	 * @created_on 28-2-2011
	 * @param integer $id 
	 * @return true
	 */     	
	function deleteUser($id){
		$this->db->where('id',$id);
		$arrUser['status']	= 2; // set status to 2 as deleted
		$arrUser['deleted_by']	=   $this->session->userdata('user_id');
		$arrUser['deleted_on']	=	date('Y-m-d H:i:s');
		//$query = $this->db->delete('client_users');
		if($arrUser = $this->db->update('client_users',$arrUser))
		{
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
					'description' => 'Delete Client Users',
					'status' => STATUS_SUCCESS,
					'transaction_id' =>  $id,
					'transaction_table_id' => CLIENT_USERS,
					'transaction_name' => "Delete Client Users",
					'parent_object_id' =>  $id
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return true;
		}
		else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
					'description' => 'Delete Client Users',
					'status' => STATUS_FAIL,
					'transaction_id' =>  $id,
					'transaction_table_id' => CLIENT_USERS,
					'transaction_name' => "Delete Client Users",
					'parent_object_id' =>  $id
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return false;
		}
	}
	
	/*
	 *	To Show Clients Drop Down
	 *  @author Vinayak Malladad
	 *  @since 1.5.1
	 *  @created on 12-2-2011
	 *  @param 
	 * 
	 */
	function getKolsByClient($id){
		$arrKOl =array();
		$arrKolResult =$this->db->query("
							select kols.first_name,kols.middle_name,kols.last_name,clients_kols.*,clients.name
							from clients_kols
							left join kols on kols.id = clients_kols.kol_id
							left join clients on clients_kols.client_id = clients.id
							where client_id=$id");
		//$arrUserResult = $this->db->get('clients_kols');
		foreach($arrKolResult->result_array() as $row){
			$arrKOl []= $row;
		}
		return 	$arrKOl;	
		//return $arrKol;
	}	
	
	/*
	 *  To Show All kols in  Drop Down
	 *  @author Vinayak Malladad
	 *  @since 1.5.1
	 *  @created on 12-2-2011
	 *  @param 
	 */	
	function getAllClientsKols($id){
		$arrKOl =array();
		$arrKolResult =$this->db->query("
										SELECT kols.first_name,kols.middle_name,kols.last_name,kols.id 
										FROM kols
										WHERE kols.id NOT IN(SELECT  kol_id FROM
														clients_kols
														WHERE client_id=$id)");
		
		foreach($arrKolResult->result_array() as $row){
			$arrKOl []= $row;
		}
		return 	$arrKOl;	
		//return $arrKol;
	}

	
	function saveClientsKols($deleteKol,$addKols,$clientId){
		$this->db->where('client_id',$clientId);
		$this->db->where_in('kol_id',$deleteKol);
		$this->db->delete('clients_kols');
		
		foreach($addKols as $row){
			$arrKol = array();	
			$arrKol['client_id']=$clientId;
			$arrKol['kol_id']= $row;
			$this->db->insert('clients_kols',$arrKol);
		}
		return true;
	}
	
	
	/*
	 * Get Client Users Detail
	 * @author Vinayak Mallaldad
	 * @since 1.5.1
	 * @created on 13/3/2011
	 * $return array
	 */
	function getUserdetail($id){
		$arrUser = array();
		$this->db->where('id',$id);
		$arrUserResult = $this->db->get('client_users');
		foreach($arrUserResult->result_array() as $row){
				$arrUser = $row;
		}
		return $arrUser;
	}

	function getAvilableKols($id){
		$arrKol=array();
		$arrKolResult=$this->db->query("select kol_id from clients_kols where client_id=$id");
		foreach($arrKolResult->result_array()as $row){
			$arrKol[]=$row['kol_id'];
		}
		return($arrKol);
	}
	
	/*
	 * Get the Client Name by passing id
	 * @author Vinayak
	 * @since 2.9
	 * @created 11-8-2011 
	 */
    function getClientName($clientId){
    	$clientName='';
    	$this->db->select('name');
    	$this->db->where('id',$clientId);
    	$result = $this->db->get('clients');
    	foreach($result->result_array() as $row){
    		$clientName=$row['name'];
    	}
    	return $clientName;
    }
    
	/*
	 * To save the User details
	 *  @author Vinayak Malladad
	 *  @since 3.2
	 *  @created on 8-10-2011
	 *  @param  $arrUserDetails
	 *  @return boolean
	 * 
	 */
    function saveUserRegistrationDetails($arrUserDetails){
    	if($this->db->insert('client_users',$arrUserDetails)){
    		return true;
    	}else{
    		return false;
    	}    
    	
    }
    
    function getUserNameById($userId){
    	$this->db->select('user_name,first_name,last_name');
    	$this->db->where('id',$userId);
    	$resultSet = $this->db->get('client_users');
    
    	$data = $resultSet->row();
    	return $data->first_name.' '.$data->last_name;
    	
    }
    
    function getClientUsers($clientId){
    	$userName=array();
    	$userGroupIds = getGroupDetails();
    	$group_ids = $userGroupIds['group_ids'];
//     	$group_ids = $this->session->userdata('group_ids');
    	$clientId = $this->session->userdata('client_id');
    	$this->db->select('client_users.first_name,client_users.id,client_users.last_name');
    	$this->db->where('client_id',$clientId);    	
    	$this->db->where('client_users.user_role_id !=',ROLE_READONLY_USER);
    	$this->db->where_in('user_from', array(1,2));
    	$this->db->order_by('first_name','asc');   	
    	if(($this->session->userdata('user_role_id')==ROLE_MANAGER || $this->session->userdata('user_role_id')==ROLE_USER)&& $clientId!=INTERNAL_CLIENT_ID){
    	    $this->db->join('user_groups','user_groups.user_id = client_users.id');
    	    $this->db->where("(user_groups.group_id in ($group_ids) OR client_users.user_role_id=0 OR client_users.user_role_id=3)");
    	    $this->db->group_by('client_users.id');
    	}
    	$result = $this->db->get('client_users');
     	//pr($this->db->last_query());exit;
    	foreach($result->result_array() as $row){
    		$userName[$row['id']] = $row['first_name']." ".$row['last_name'];
    	}
    	return $userName;
    }
    
	function getClientManagers($clientId){
    	$userName=array();
    	$this->db->select('first_name,id,last_name');
    	$this->db->where('client_id',$clientId);
    	$this->db->where_in('user_role_id',array(ROLE_MANAGER,ROLE_ADMIN));
    	//$this->db->where('status',0); // exclude deleted and deactivated managers
    	$this->db->where_in('client_users.status',array(ACTIVATED_USER));
    	$this->db->order_by('first_name','asc');
    	$result = $this->db->get('client_users');
    	foreach($result->result_array() as $row){
    		$userName[$row['id']] = $row['first_name']." ".$row['last_name'];
    	}
    	return $userName;
    }
    
    function getManagerId($userId){
    	$managerId = $userId;
    	$this->db->select('manager_id');
    	$this->db->where('id',$userId);
    	$results = $this->db->get('client_users');
    	if($results->num_rows() > 0){
    		$row = $results->row_array();
    		$managerId = $row['manager_id'];
    	}
    	return $managerId;
    }
    
    function getUserManagerEmailId($userId){
    	$emaiId = $userId;
    	$arrUserIds	= array();
    	if(!is_array($userId)){
    		$arrUserIds[]	= $userId;
    	}
    	$this->db->select('managers.email');
    	$this->db->where_in('client_users.id',$arrUserIds);
    	$this->db->where_in('client_users.status',array(ACTIVATED_USER));
    	$this->db->join('client_users as managers','managers.id = client_users.manager_id');
    	$results = $this->db->get('client_users');
    	if($results->num_rows() > 0){
    		$row = $results->row_array();
    		$emaiId = $row['email'];
    	}
    	return $emaiId;
    }
    
	function getUserEmailIdById($arrUserIds=array()){
		$clientId	= $this->session->userdata('client_id');
    	if(!is_array($arrUserIds)){
    		$arrUserIds[]	= $arrUserIds;
    	}
    	$this->db->select('client_users.email');
    	$this->db->where_in('client_users.id',$arrUserIds);
    	$this->db->where_in('client_users.status',array(ACTIVATED_USER));
    	$this->db->where("(client_users.client_id = $clientId OR client_users.client_id = ".INTERNAL_CLIENT_ID.")");
    	$results = $this->db->get('client_users');
    	foreach($results->result_array() as $row){
            $arrUsers[] = $row['email'];
        }
        return $arrUsers;
    }
    
    function getAlignedUsersToManager($managerId,$isAllSet=false){
        
       $arrUsers = array();
        
        if(!$isAllSet){
            $this->db->where('manager_id',$managerId);
        }
        else
            $this->db->where('client_users.client_id',$this->session->userdata('client_id')); 
        $this->db->where_in('user_from',array(1,2));
        $this->db->select('client_users.*,clients.name');
        $this->db->join('clients','clients.id=client_users.client_id','left');
        $this->db->order_by('first_name,last_name');
        $arrUsersResults = $this->db->get('client_users');
        foreach($arrUsersResults->result_array() as $row){
            $arrUsers[] = $row;
        }
        return $arrUsers;
       
    }
   
   
   
   function getUserIdByName($Fname,$Lname){
//       $name=$Fname;
    	$this->db->select('user_name,id');
    	$this->db->where('first_name',$Fname);
        $this->db->where('last_name',$Lname);
    	$resultSet = $this->db->get('client_users');
    
    	$data = $resultSet->row();
    	return $data->id;
    	
    }
    
     function getClientUsersMSL($clientId){
    	$userName=array();
        $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
    	$this->db->select('first_name,id,last_name');
    	$this->db->where('client_id',$clientId);
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2, 3));
        }
        if ($userRole == ROLE_USER) {
            $this->db->where('client_users.id', $userId);
        }
        if (($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office") {
            $this->db->where_in('client_users.id', $userIds);
        }
//    	$this->db->where_in('user_from', array(1,2));
    	$this->db->order_by('first_name','asc');
    	$result = $this->db->get('client_users');
    	foreach($result->result_array() as $row){
                $row['username']        = $row['first_name'].' '.$row['last_name'];
                $userName[]=$row;
    	}
    	return $userName;
    }
    
    function changeUsersClient($data){
    	$this->db->where_in("id",$data['users_ids']);
    	$this->db->set("client_id",$data["client_id"]);
		if($this->db->update("client_users"))
	    	return true;
	    else
	    	return false;
	}
	function savePassword($details){
		$this->db->insert("password_analytics",$details);
		//echo $this->db->last_query();
	}
	function getUserCurrentPassword($id){
		$this->db->select('password');
		$this->db->where('id',$id);
		$arrUsere = $this->db->get('client_users');
		foreach($arrUsere->result_array() as $row){
    		$retUsers[] = $row;
    	}
    	return $retUsers;
	}
	function getUserRecentPassword($id){
		$this->db->select('password');
		$this->db->where('user_id',$id);
				$this->db->order_by('id','desc');
		$this->db->limit(RESTRICT_NO_OF_PASSWORDS_TO_REUSE);
		$arrUsere = $this->db->get('password_analytics');
		foreach($arrUsere->result_array() as $row){
			
    		$retUsers[] = $row;
    	}
    	return $retUsers;
	}
	/* 
	 * new function added 
	 * 04-10-2016
	 */
	function updateUserStatus($userId,$status,$managerId=0){
		
		$arrUser['status']	= $status;
		if($status==2){	
			//Add Log activity
		    if(is_array($userId)){
    	        foreach($userId as $row){
        			$arrLogDetails = array(
        					'type' => DELET_RECORD,
        					'description' => 'Delete Client Users',
        					'status' => STATUS_SUCCESS,
        			         'transaction_id' =>  $row,
        					'transaction_table_id' => CLIENT_USERS,
        					'transaction_name' => "Delete Client Users",
        			        'parent_object_id' =>  $row
        			);
        			$this->config->set_item('log_details', $arrLogDetails);
    		    }
		    }else{
		        $arrLogDetails = array(
		            'type' => DELET_RECORD,
		            'description' => 'Delete Client Users',
		            'status' => STATUS_SUCCESS,
		            'transaction_id' =>  $userId,
		            'transaction_table_id' => CLIENT_USERS,
		            'transaction_name' => "Delete Client Users",
		            'parent_object_id' =>  $userId
		        );
		        $this->config->set_item('log_details', $arrLogDetails);
		    }
// 			log_user_activity(null,true);
			$arrUser['deleted_by']	=   $this->session->userdata('user_id');
			$arrUser['deleted_on']	=	date('Y-m-d H:i:s');
		}else{
			//$this->db->where('status!=',2,false);
			$this->db->where_in('client_users.status',array(ACTIVATED_USER,DEACTIVATED_USER));
		}
		if(is_array($userId)){
		    			$remove = array('undefined');
		    			$userId = array_diff($userId, $remove);
		    $this->db->where_in('id',$userId);
		}else{
		    $this->db->where('id',$userId);
		}
		$arrUser['status_modified_by']	=   $this->session->userdata('user_id');
		$arrUser['status_modified_on']	=	date('Y-m-d H:i:s');
		if($arrUser = $this->db->update('client_users',$arrUser)){
			if(($status==DEACTIVATED_USER) && $managerId!=0){
				return $this->realignManager($userId,$managerId);
				//echo $this->db->last_query();
			}			
			return true;
		}else
			return false;		
	}
	
	function listManagers($selectedUsers=''){
	    $arrManagers=array();
	    if(!empty($selectedUsers) && !is_array($selectedUsers)){
	        $arrData	= $this->getUserdetail($selectedUsers);
	        $clientId	= $arrData['client_id'];
	    }else{
	        $clientId	= $this->session->userdata('client_id');
	    }
	    $this->db->select('client_users.first_name,client_users.id,client_users.last_name,clients.name as client_name');
	    if($clientId!=INTERNAL_CLIENT_ID){
	        $this->db->where('client_id',$clientId);
	    }
	    $this->db->where('user_role_id',ROLE_MANAGER);
	    //$this->db->where('status!=',2,false); // exclude deleted managers
	    $this->db->where_in('client_users.status',array(ACTIVATED_USER));
	    $this->db->join('clients','clients.id=client_users.client_id','left');
	    $this->db->order_by('client_name,first_name');
	    $result = $this->db->get('client_users');
	    foreach($result->result_array() as $row){
	        $arrManagers[$row['id']] = $row;
	    }
	    return $arrManagers;
	}
	
	function deleteUserById($id){
	    $this->db->where('id',$id);
	    if($this->db->delete('client_users'))
	        return true;
	        else
	            return false;
	}
	
	function getUserEmailIds(){
		 
		$results = $this->db->get('demo_emails');
		//echo $this->db->last_query();
		foreach($results->result_array() as $row){
			$userEmails[]=$row['email'];
		}
		//pr($userEmails)
		return $userEmails;
	}
	
	function getDeactivatedUsers(){
		$this->db->select("client_users.id as clientUserId, interactions.id as interactionId, interactions.created_on");
		$this->db->join("(select max(interactions.id) as interactionId, interactions.created_by from interactions group by interactions.created_by) as tempTable", "tempTable.created_by = client_users.id", "join");
		$this->db->join("interactions", "interactions.id = tempTable.interactionId", "left");
		$this->db->where("client_users.status > 0");
		$query = $this->db->get("client_users");
		return $query->result_array();
	}
	
	function updateCreatedDateDeactiveUsers($clientUserId, $createdDate){
		$arrModifiedDate = array(
				"status_modified_on"=>$createdDate
		);
		$this->db->where('id',$clientUserId);
		if($arrModified = $this->db->update('client_users',$arrModifiedDate))
			return true;
			else
			return false;
	}
	// block the user
	function blockUser($id) {
		$this->db->where_in ( "id", $id );
		$this->db->set ( "client_users.failed_attempts", 9 );
		if ($this->db->update ( "client_users" ))
			return true;
			else
				return false;
	}
	// unblock the user
	function unBlockUser($id) {
		$this->db->where_in ( "id", $id );
		$this->db->set ( "client_users.failed_attempts", 0 );
		if ($this->db->update ( "client_users" ))
			return true;
			else
				return false;
	}
    function updateCookeStatus(){
        $data = array(
            'cooke_consent' => 1
        );
        $this->db->where('id',$this->session->userdata('user_id'));
        if($arrClient = $this->db->update('client_users',$data)){
            $this->session->unset_userdata('cooke_consent');
            return true;
        }else{
            return false;
        }
    }
    function getLanguages(){
        $this->db->select('*');
        $this->db->order_by('lang_name','asc');
        $results = $this->db->get('privacy_policy_lang');
        return $results->result_array();
    }
}

