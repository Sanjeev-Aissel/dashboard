<style type="text/css">
   	.container{
   	margin-top:30px;
   	}
   	.center{
    display: flex;
    justify-content: center;
    align-items: center;
   	background-color:#fbf9ee;
   	border: 1px solid #ccc;
   	border-radius:4px;
   	padding:20px;
	}
	.align-center{
		text-align: center;
		margin-top:20px;
	}
	label{
		margin-right: 5px;
	    margin-left: 3px;
	    vertical-align: middle;
	}
	.page-title{
		text-align: center;
		font-size:18px;
	}
    </style>
    <script>

	function changeAction(){

		var value =$('input[name="university"]:checked').val();		
		if(value=='uni'){
			var action = '<?php echo base_url();?>imports/import_org_profiles_otsuka_xls';
		}else{
			var action = '<?php echo base_url();?>imports/import_payer_org_profiles';
		}
		//$('#orgImportForm').attr('action',action);
		$('#orgImportForm').submit();
		return false;
	}
	

</script>
<div class="container">
    <div class="row">
    	<h1 class="page-title">Organizations Import</h1>
        <div id="kolImportContainer" class="col-md-8 col-md-offset-2 center">
				<form action="<?php echo base_url();?>imports/upload_zip_file" name="org_import_form" id="orgImportForm" method="post" enctype="multipart/form-data">
				<div class="form-group">
				<input type="radio" name="university" id="university" checked="checked" value="uni"><label>University/Hospitals</label>
				<input type="radio" name="university" id="payor" value="payor"><label>Payor</label>
				</div>
                  <div class="form-group">
                    <label for="file">Select a file to upload</label>
                    <input type="file" name="overview_import" id="overviewImport" class="form-control">
                    <p class="help-block pull-right" >Only '.xls' files is allowed.</p>
                  </div>
                  <input type="button" value="Upload" onclick="changeAction()" class="btn btn-sm btn-danger" value="Upload">
                </form>
				<div id="importInstructions">
					
				</div>
		</div>
    </div>
    <div class="row align-center">
    <a href="<?php echo base_url()?>organizations/list_uploaded_files/uni" style="text-decoration: none;"><button class="btn btn-sm btn-primary" >List Uploaded University Files</button></a>
	<a href="<?php echo base_url()?>organizations/list_uploaded_files/payer" style="text-decoration: none;"><button class="btn btn-sm btn-primary" >List Uploaded Payer Files</button></a>

	</div>
</div>
<!--/container-->