<?php
/*
 * Page to show survey network map
 *  
 * @Author		: Ramesh B
 * @since 		: KOLM v5.5 Otsuka 1.0.11
 * Created on	: 15-05-2013
 *  
 */
?>
<?php
	//jit.forecedirected&rgraph_mix
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array('jquery.autocomplete',
							'chosen.jquery',
							'highcharts2_2_2/highcharts3.0.5',
							'highcharts2_2_2/modules/exporting3.0.5',
							'surveys/view_report',
							'jquery/jquery.validate1.9.min'
							);
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
	
	$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {getOrganizationInfluenceData();}";
?>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet">
<!--[if (IE)]>
	<script language="javascript" type="text/javascript" src="<?php echo base_url()?>js/excanvas.js"></script>
<![endif]-->
<script type="text/javascript">
var baseUrl='<?php echo base_url();?>';
var rdGraphObj;
var fdGraphObj;
var fd;
var currentJson;
var currentView='view2';
var isMicroviewLoading = false;

var labelType, useGradients, nativeTextSupport, animate;

$(document).ready(function(){

	$('.chosenSelect').chosen({allow_single_deselect: true});
	$('.chosenMultipleSelect').chosen({
		allow_single_deselect: true
	});
	$("#survey_chzn").live('click',function(){
		moveFromCurrentStep(4);
	});
	$("#PDQnomineeType_chzn").live('click',function(){
		hideHint(5);
	});
	$("#PDQnomineeSpecialty_chzn").live('click',function(){
		hideHint(5);
	});
	$("#PDQnomineeState_chzn").live('click',function(){
		hideHint(5);
	});
	$("#survey").chosen().change(function() {
		loadOptions();
	});
});

function loadOptions(){
	var surveyId	= $('#survey').val();
	var chartType	= $('#chartType').val();
	if(surveyId!=0){
		load_custom_query_options(surveyId);
	}else{
		$("#preQuery .chosenSelect").val('').trigger('liszt:updated');$("#customQuery .chosenSelect").val('').trigger('liszt:updated');
	}
}

function loadSurveyNetMap(){
	animateMicroviewBoxHide();
	$("#map-log").html("");
	$('#mapContainer').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
	var actionUrl='';
	actionUrl=baseUrl+'surveys/get_survey_influence_data_old/';
	//Ajax request to load influence map json data
	var surveyId	= $('#survey').val();
	var data	= $('#preQuery').serialize();
	data		+= '&survey_id='+surveyId;
	$("#map-log").removeClass("ie8-error");
	$.ajax({
		type: "post",
		dataType:"json",
		data:data,
		url: actionUrl,
		success: function(json){
			currentJson=json;
			rdGraphObj=null;
			$("#view2Infovis").html('');
			if(isIE8 == 1){
				if(json.length != 0 && json.length <= 150)
					surveysView(json,'view2Infovis','#FFFFFF');
				else{
					$("#map-log").show();
					if(json.length == 0)
						$("#map-log").html("No Connections Found");
					else{
						$("#map-log").html("Unfortunately your current browser i.e. Internet Explorer 8 [IE8] cannot render this influence map for the volume of data.<br> Request you to use other browsers like Chrome, Firefox or the latest version of Internet Explorer or Filter the output using refine by.");
						$("#map-log").addClass("ie8-error");
					}
				}
			}else{
				if(json.length != 0)
					surveysView(json,'view2Infovis','#FFFFFF');
				else{
					$("#map-log").show();
					$("#map-log").html("No Connections Found");
				}					
			}
		},
		complete: function(){
			//hide loading image
			$('.loadingIndicator').hide();
			$('#mapContainer').unblock();
			moveFromCurrentStep(5);
			showHint(5);
		}
	});
}


</script>

<style>
	select.chosenSelect, select.chosenMultipleSelect{
		width:200px;
	}
	.chzn-container{
		font-size: 12px !important;;
		margin-bottom: 3px;
		width:150px;
	}
	#filterOptions td, #filterOptions th{
		padding-bottom: 10px !important;
	}
	#preDefinedQuery .chzn-container{
		margin-right: 10px;
    	width: 150px !important;
	}
	#filterOptions label{
		vertical-align: super;
	}
	#preDefinedQuery{
		border-top: 1px solid #E9E9E9;
	    margin-top: 3px;
	    padding-top: 3px;
	}
	#preDefinedQuery button{
		vertical-align: super;
	}
	#mapContainer{
		border-top: 1px solid #E9E9E9;
	}
	#filterOptions{
		 position: relative;
	}
	#tooltip-survey{
		 left: 260px;
	    position: absolute;
	    top: 6px;
	}
	#tooltip-reload{
		 position: absolute;
	    right: 30px;
	    top: 46px;
	}
	.tooltip.in {
	    opacity: 1.00 !important;
	}
</style>
<div id="container">
<div>
	<?php $helpLink = "<a class='help-link' href='".getSSOUrl($this->session->userdata('user_full_name'), $this->session->userdata('email'))."&redirect_to=/support/solutions/folders/210925' target='_new'>View Additional Help</a>"; ?>
	<div id="filterOptions">
		<label>Survey : </label>
		<select id="survey" name="survey" class="chosenSelect">
			<option value="0">Select Survey</option>
			<?php foreach($arrCompletedSurveys as $key=>$arrRow){
				echo '<option value="'.$arrRow['id'].'">'.$arrRow['name'].'</option>';
			}?>
		</select>
		<span id="tooltip-survey" class="map-info tooltop-bottom"><a href="#" class="tooltipLink" rel='tooltip' data-original-title="<span class='tttext'>Select the survey first for which you want to generate the influence map.<?php echo $helpLink;?></span>">&nbsp;</a></span>
			<div id="preDefinedQuery">
				<table>
					<tr>
						<td>
							<form action="#" onsubmit="return false;" name="preQuery" id="preQuery">
								<div>
								<label>Top </label>
								<select id="PDQnomineeType" name="nominee_type" class="chosenSelect nominee_type" data-placeholder="Select Type">
									<option value=""></option>
									<?php 
										foreach($arrTypes as $id=>$name){
											echo '<option value="'.$id.'">'.$name.'</option>';
										}
									?>
								</select>
								<label>Influencers of  </label>
								<select id="PDQnomineeSpecialty" name="nominee_specialty" class="chosenSelect nominee_specialty" data-placeholder="Select Therapeutic Area">
									<option value=""></option>
								</select>
								<label>in the state of </label>
								<select id="PDQnomineeState" name="nominee_state[]" class="chosenSelect nominee_state" data-placeholder="Select State">
									<option value=""></option>
								</select>
								<input onclick="loadSurveyNetMap(); return false;" type="button" value="Go" style='vertical-align:top;' />
								<!-- button onclick="loadSurveyNetMap(); return false;" style="height: 23px; vertical-align: top;">Go</button-->
								<span class="map-info tooltop-bottom helpToolTip" style="vertical-align: super;"><a href="#" class="tooltipLink" rel='tooltip' data-original-title="<span class='tttext'>You can generate the map based on influencer type, therapeutic area and/or the state. You can select one or all of the 3 options. Not selecting any option from the drop down will consider all results by default.<br>Each dot is an individual. Click on any name to highlight connections & click again to unselect.<br> <b>Respondent</b> – individuals who have nominated others; indicated by arrows pointing towards them.<br> <b>Influencer</b> – Individuals who have been nominated by others; indicated by arrows pointing away. <br>E.g. A ----------- >B  = A influences B.<br><br><b>Red dot</b> = no profile present, new name. <br><b>Blue dot</b> = profile present, existing KOL
								<?php echo $helpLink;?></span>">&nbsp;</a></span>
								</div>
							</form>
						</td>
					</tr>
				</table>
			</div>
	</div>
	<div id="surveyNetworkMap">
		<?php $this->load->view('surveys/network_map_element');?>
	</div> 
</div>
<div id="newKolProfile" class="microProfileDialogBox">
	<div class="newProfileContent profileContent"></div>
</div>
</div>
<style>
#contentWrapper.span-23 {
    background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
    background-position: 135px 50%;
    background-repeat: repeat-y;
}
</style>