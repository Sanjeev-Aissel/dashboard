<style type="text/css">

    input.error {
        background-position: 10px center;
        background-repeat: no-repeat;
    }

    label.error {
        padding: 2px 0px !important;
        color: red !important;
        background: none !important;
        border-color:none !important;
        border: none !important;
    }

    select.error {
        border: 1px solid red !important;
    }

    screen.css  error,.notice,.success {
        border: red;
        margin-bottom: 1em;
        padding: 0.8em;
    }

    #new_staff {
        display: none;
    }

    #new_phone {
        display: none;
    }
</style>



<div class="msgBox"></div>

<div id="similarNames">

</div>


    <h4 style="border-bottom: 1px solid #bbbbbb;">Location </h4>
    <table class="requestedKols">
        <tbody>
        	<tr>
        		<td>
        			<table>
                                    <tr>
			                <td class="alignRight">
			                    <label >Location ID :</label>
			                </td>
			                <td>
			                    <?php  echo $locationData['generic_id']?>
			                  
			                </td>
			            </tr>
        				<!--<tr>
			                <td class="alignRight">
			                    <label for="isPrimary">Primary Address :</label>
			                </td>
			                <td>
			                    
			                    <?php // pr($locationData); exit();
			                    if (isset($locationData)) {
			                        if ($locationData['is_primary'] == "1"){
			                            echo "Yes";
			                    } else 
                                                 echo "No";
                                            }
			                    ?>
			                </td>
			            </tr>  -->
        				<tr>
			                <td class="alignRight"><label for="org_institution_id">Organization :</label></td>
			                <td>
			                    <?php
			                        echo $locationData['org_institution_name'];
			                    ?> 
			                    <!--<input type="hidden" name="org_institution_id" id="org_institution_id" value="" />-->
			                </td>
			            </tr>
			            <tr>
			                <td class="alignRight"><label for="address1">Address Line 1<span class=""></span>:</label></td>
			                <td>
			                    <?php
			                        echo $locationData['address1'];
			                    ?>
			                </td>
			            </tr>
			            <tr>
			                <td class="alignRight">
			                    <label for="address2">Address Line 2 :</label>
			                </td>
			                <td>
			                    <?php
			                        echo $locationData['address2'];
			                    ?>
			                </td>
			            </tr>
<!--			            <tr>
			                <td class="alignRight">
			                    <label for="address3">Address Line 3 :</label>
			                </td>
			                <td>
			                    <?php
			                        echo $locationData['address3'];
			                    ?>
			                </td>
			            </tr>
			            <tr>
			                <td class="alignRight">
			                    <label for="validation_status">Validation Status :</label>
			                </td>
			                <td> <?php
			                        echo $locationData['validation_status'];
			                        ?>
			                </td>
			            </tr>-->
        			</table>
        		</td>
        		<td>
        			<table>
        				<!-- <tr>
			                <td class="alignRight">
			                    <label for="address_type">Address Type<span class=""></span> :</label>
			                </td>
			                <td>
			                        <?php
			                        echo $locationData['address_type'];
			                        ?>
			                </td>
			            </tr> -->
			            <tr>
			                <td class="alignRight">
			                    <label for="country_id">Country<span class=""></span> :</label>
			                </td>
			                <td>
                                              <?php
                                               if(count($country_id) != 0)
			                        echo $country_id;
			                        ?>
			                     </td>
			            </tr>
			            <tr>
			                <td class="alignRight">									
			                    <label for="stateId1">State / Province :</label>
			                </td>
			                <td><?php
			                	if(count($state_id) != 0)
			                        echo $state_id;
			                        ?>
			                    </td>
			            </tr>
			            <tr>
			                <td class="alignRight">
			                    <label for="city_id">City<span class=""></span> :</label>
			                </td>
			                <td><?php
                                        if(count($city_id) != 0)
			                        echo $city_id;
			                        ?>
			                </td>
			            </tr>
			            <tr>
			                <td class="alignRight">
			                    <label for="postal_code">Postal Code<span class=""></span> :</label>
			                </td>
			                <td>
			                    <?php
			                            echo $locationData['postal_code'];
			                    ?>
			                </td>
			            </tr>
<!--			            <tr>
			                <td class="alignRight">
			                    <label for="phone_type">Phone Type :</label>
			                </td>
			                <td> <?php
			                            echo $locationData['phone_type'];
			                    ?>
			                </td>
			            </tr>
			            <tr>
			                <td class="alignRight">
			                    <label for="phone_number">Phone Number :</label>
			                </td>
			                <td> <?php
			                            echo $locationData['phone_number'];
			                    ?>
			                   
			                </td>
			            </tr>-->
        			</table>
        		</td>
        	</tr>
            
            

            <!-- End of Personal and Professional Information -->


        </tbody>
    </table>

	<h4 style="border-bottom: 1px solid #bbbbbb;">Staffs </h4>
    <table id="staff_table">
        <tbody>
            <?php
            if (isset($locationData)) {
                if (count($staffData) > 0) {
                    $i = 0;
                    foreach ($staffData as $staff) {
                        ?>
                        <tr id='staff_<?php echo $i; ?>'>
                            <td>
                                <label for="staff_title">Title :</label>
                                <?php
                                    echo $staff['staff_title'];
                                    ?>
                            </td>
                            <td>
                                <label for="name">Name :</label>
                                 <?php
                                    echo $staff['name'];
                                    ?>
                                
                            </td>
                            <td>
                                <label for="staff_phone">Phone :</label> 
                                    <?php
                                    echo $staff['phone_number'];
                                    ?>
                               
                            </td>
                            <td>
                                <!--<img id="delete_staff_<?php echo $i; ?>" title="Delete Staff" alt="Delete Staff" src="<?php echo base_url(); ?>/images/delete.png" onclick="deleteStaff(<?php echo $i; ?>);">-->
                            </td>
                        </tr>
                        <?php
                        $i++;
                    }
                }
            }  ?>
            </tr>

        </tbody>
    </table>


	<h4 style="border-bottom: 1px solid #bbbbbb;">Phones </h4>
    <table  id="phone_table">
        <tbody>
            <?php
//            pr($phoneData);
            if (isset($locationData)) {
                if (count($phoneData) > 0) {
                    $i = 0;
                    foreach ($phoneData as $phone) {
                        ?>
                        <tr id='phone_<?php echo $i; ?>'>
                            <td>
                                <label for="phone_type">Phone Type :</label>
                                    <?php
                                    echo $phone['phone_type'];
                                    ?>
                            </td>
                            <td>
                                <label for="phone_number">Phone Number :</label>
                                    <?php
                                echo $phone['number'];
                                ?>
                            </td>
                            <td>
                                <!--<img id="delete_phone_<?php echo $i; ?>" title="Delete Phone" alt="Delete Phone" src="<?php echo base_url(); ?>/images/delete.png" onclick="deletePhone(<?php echo $i; ?>);">-->
                            </td>
                        </tr>
                        <?php
                        $i++;
                    }
                }
            } ?>
              
        </tbody>
    </table>

</tbody>
</table>

<table><tr>
        <th width="100"><?php echo CREATED_BY;?>:</th><td><?php echo $result?></td>
        <th width="100"><?php echo CREATED_ON;?>:</th><td><?php echo sql_date_to_app_date($locationData['created_on'])?></td>
    </tr></table>