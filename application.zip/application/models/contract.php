<?php

/**
 * Model for Contract operations
 * 
 * @package application.models
 * @author Vinayak Malladad
 * @since 3.4
 * @created on  24-11-2011
 */

class Contract extends model{
	
	function Contract(){
		parent::model();
	}
	
	/**
	 * Get all Contract details
	 * @author Vinayak
	 * @created 24-11-2011
	 * @since	3.4
	 * @return $arrContracts
	 */
	function listContracts($kolId='',$contractType,$limit=0){
	    $userGroupName = getGroupDetails();
	    $clientId = $this->session->userdata('client_id');
	    $userId = $this->session->userdata('user_id');
	    $userRoleId = $this->session->userdata('user_role_id');
	    if ($clientId != INTERNAL_CLIENT_ID) {
	        $this->db->where("contracts.client_id",$clientId);
	    }
	    /*if($userRoleId==ROLE_USER){
	     $this->db->where("contracts.created_by",$userId);
	     }*/
	    $this->db->select('contracts.*,client_users.client_id,CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name',false);
	    $this->db->join('client_users', 'client_users.id = contracts.created_by', 'left');
	    if(ORGS_CONTRACT){
	        if($contractType=='kol'){
	            if($clientId != INTERNAL_CLIENT_ID){
	                $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = contracts.kol_id', 'left');
	                $this->db->where('kols_client_visibility.client_id', $clientId);
	            }
	        }
	        if($contractType=='track'){
	            $this->db->join('organizations', 'contracts.org_id = organizations.id ', 'left');
	            $this->db->join('kols', 'kols.id = contracts.kol_id', 'left');
	            if($clientId != INTERNAL_CLIENT_ID){
	                //$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = contracts.kol_id', 'left');
	                if(is_numeric($kolId)==''){
	                    if($this->session->userdata('user_role_id')==ROLE_MANAGER || $this->session->userdata('user_role_id')==ROLE_USER){
	                        //$group_names = explode(',', $this->session->userdata('group_names'));
	                        $group_names = "'".str_replace(',',"','", $userGroupName['group_names'])."'";
	                        $this->db->join ( 'countries', 'countries.CountryId = kols.country_id', 'left' );
	                        $this->db->join ( 'countries as org_country', 'org_country.CountryId = organizations.country_id', 'left' );
	                        $this->db->where("(countries.GlobalRegion in (".$group_names.") or contracts.org_id > 0)" ,'',false);
	                        $this->db->where("(org_country.GlobalRegion in (".$group_names.") or contracts.kol_id > 0)" ,'',false);
	                    }
	                }
	            }
	            if($clientId !== INTERNAL_CLIENT_ID){
	                $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = contracts.kol_id', 'left');
	                $this->db->where("((contracts.kol_id != 0 AND kols_client_visibility.client_id = '".$clientId."') OR contracts.org_id != 0)",'',false);
	            }else{
	                $this->db->where("(contracts.kol_id != 0 OR contracts.org_id != 0)",'',false);
	            }
	        }
	    }else{
	        if($clientId != INTERNAL_CLIENT_ID){
	            $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = contracts.kol_id', 'left');
	            $this->db->where('kols_client_visibility.client_id', $clientId);
	            
	            if(is_numeric($kolId)==''){
	                if($this->session->userdata('user_role_id')==ROLE_MANAGER || $this->session->userdata('user_role_id')==ROLE_USER){
	                    $group_names = explode(',',  $userGroupName['group_names']);
// 	                    $group_names = explode(',', $this->session->userdata('group_names'));
	                    $this->db->join('kols', 'kols.id = contracts.kol_id', 'left');
	                    $this->db->join ( 'countries', 'countries.CountryId = kols.country_id', 'left' );
	                    $this->db->where_in ( 'countries.GlobalRegion', $group_names);
	                }
	            }
	        }
	    }
	    $this->db->group_by('contracts.id');
	    $this->db->order_by('contracts.end_date','desc');
	    if($limit>0){
	        $this->db->limit($limit);
	    }
	    if(ORGS_CONTRACT){
	        if(is_numeric($kolId)!=''){
	            if($contractType=='kol'){
	                $this->db->where('contracts.kol_id',$kolId);
	            }else{
	                $this->db->where('contracts.org_id',$kolId);
	            }
	        }
	    }else{
	        if(is_numeric($kolId)!=''){
	            $this->db->where('contracts.kol_id',$kolId);
	        }else{
	            $this->db->where("contracts.kol_id !=",0);
	        }
	    }
	    
	    /* $NewDate=Date('Y-m-d', strtotime("+6 days"));
	     if($NewDate!=''){
	     $this->db->where('contracts.end_date',$NewDate);
	     // echo "FDDDD";exit;
	     }
	     //pr($NewDate);exit; */
	    $arrResultSet = $this->db->get('contracts');
// 	    echo $this->db->last_query();exit;
	    foreach($arrResultSet->result_array() as $row){
	        
	        $arrContracts[]=$row;
	    }
	    return $arrContracts;
	}
	
	/**
	 * Insret contract details
	 * @author Vinayak
	 * @created 24-11-2011
	 * @since	3.4
	 * @return true/false
	 */
	function saveContract($arrContracts){
	    $userId = $this->session->userdata('user_id');
	    $clientId = $this->session->userdata('client_id');
	    $userId = $this->session->userdata('user_id');
	    $dataType = 'User Added';
	    if($clientId == INTERNAL_CLIENT_ID){
	        $dataType = 'Aissel Analyst';
	    }
        $date = date("Y-m-d H:i:s");
        $arrContracts['client_id']  = $clientId;
        $arrContracts['created_by']  = $userId;
        $arrContracts['created_on']  = $date;
        $arrContracts['modified_by']  = $userId;
        $arrContracts['modified_on']  = $date;
        $arrContracts['data_type_indicator']  = $dataType;
		if($this->db->insert('contracts',$arrContracts)){
			
			return $this->db->insert_id();
		}else{
			return false;
		}
	}

	/**
	 * Get contract details ny id
	 * @author Vinayak
	 * @created 24-11-2011
	 * @since	3.4
	 * @return true/false
	 */
	function getContractDetailsById($contractId){
		$this->db->where('id',$contractId);
		$arrContractsResult = $this->db->get('contracts');
		$arrContracts = array();
		foreach($arrContractsResult->result_array() as $row){
			$arrContracts=$row;
		}
		return $arrContracts;
	}
	
	/**
	 * update contract details
	 * @author Vinayak
	 * @created 24-11-2011
	 * @since	3.4
	 * @return true/false
	 */
	function updateContract($arrContract){
	    $userId = $this->session->userdata('user_id');
	    $date = date("Y-m-d H:i:s");
	    $arrContracts['modified_by']  = $userId;
	    $arrContracts['modified_on']  = $date;
		$this->db->where('id',$arrContract['id']);
		if($this->db->update('contracts',$arrContract)){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * Delete contract details
	 * @author Vinayak
	 * @created 24-11-2011
	 * @since	3.4
	 * @return true/false
	 */
	function deteleteContract($contractId){
	    $this->db->select('kol_id,org_id');
	    $this->db->where('id',$contractId);
	    $queryRes = $this->db->get('contracts');
	    $row = $queryRes->row();
	    if (isset($row))
	    {
	        if($row->kol_id > 0){
	            $transactionName = 'Delete Contract';
	            $kol_org_type = 'Kol';
	            $kols_or_org_id = $row->kol_id;
	            $parentObjectId = $row->kol_id;
	        }else{
	            $transactionName = 'Delete Org Contract';
	            $kol_org_type = 'Organization';
	            $kols_or_org_id=$row->org_id;
	            $parentObjectId = $row->org_id;
	        }
	    }
		$this->db->where('id',$contractId);
		if($this->db->delete('contracts')){
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
			        'description' => $transactionName,
					'status' => STATUS_SUCCESS,
			        'kols_or_org_type' => $kol_org_type,
			        'kols_or_org_id' => $kols_or_org_id,
					'transaction_id' => $contractId,
					'transaction_table_id' => CONTRACTS,
			        'transaction_name' => $transactionName,
			        'parent_object_id' =>  $kols_or_org_id
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return true;
		}else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
			        'description' => $transactionName,
					'status' => STATUS_FAIL,
    			    'kols_or_org_type' => $kol_org_type,
    			    'kols_or_org_id' => $kols_or_org_id,
					'transaction_id' => $contractId,
					'transaction_table_id' => CONTRACTS,
			        'transaction_name' => $transactionName,
			        'parent_object_id' =>  $kols_or_org_id
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return false;
		}
		
	
	}

	function deleteContractsByKolId($clientId,$kolId){
	    if($clientId!=0)
	        $this->db->where('client_id',$clientId);
	        $this->db->where('kol_id',$kolId);
	        if($query=$this->db->delete('contracts')){
	            return true;
	        }else{
	            return false;
	        }
	}
	function getAllKolsName1(){
	    $arrkols=array();
	    $this->db->select('id,first_name,middle_name,last_name');
	    //$status = COMPLETED;
	   // $this->db->where('status',"$status");
	    $arrResult = $this->db->get('kols');
	    foreach($arrResult->result_array() as $row){
	        if($row['middle_name']!=''){
	            //			$arrkols[$row['id']] = $row[FIRST_ORDER]." ".$row[SECOND_ORDER]." ".$row[THIRD_ORDER];
	            $arrkols[$row['id']] = nf($row['first_name'],$row['middle_name'],$row['last_name']);
	        }else{
	            //				$arrkols[$row['id']] = $row[FIRST_ORDER]." ".$row[SECOND_ORDER];
	            $arrkols[$row['id']] = nf($row['first_name'],$row['middle_name'],$row['last_name']);
	        }
	    }
	    return $arrkols;
	}
	function getAllOrgName1(){
	    $arrkols=array();
	    $this->db->select('id,name');
	    //$status = COMPLETED;
	    // $this->db->where('status',"$status");
	    $arrResult = $this->db->get('organizations');
	    foreach($arrResult->result_array() as $row){
	            $arrkols[$row['id']] = nf($row['name']);
	    }
	    return $arrkols;
	}
	function getTotalContractsOfKol($kolId){
	    $client_id = $this->session->userdata('client_id');
	    $user_id = $this->session->userdata('user_id');
	    $this->db->select("id");
	    $this->db->from("contracts");
	    $this->db->where("kol_id",$kolId);
	    if($client_id!=INTERNAL_CLIENT_ID){
	        $this->db->where("client_id",$client_id);
// 	        $this->db->where("created_by",$user_id);
	    }
	    $get = $this->db->get();
	    return $get->num_rows();
	}
	function listContractsEmail($NewDate){
	    $this->db->select('contracts.id as cont_id,contracts.kol_name,client_users.email,client_users.first_name,client_users.id,contracts.created_by');
	    $this->db->join('client_users','client_users.id = contracts.created_by','left');
	    $this->db->where('contracts.end_date',$NewDate);
	    $arrResultEmail = $this->db->get('contracts');
	    foreach($arrResultEmail->result_array() as $row){
	        $arrEmailContracts[] = $row;
	    }
	    return $arrEmailContracts;
	}
			
    function getManagerEmail($userId){  
		$this->db->select('managers.email,managers.id');
		$this->db->where('client_users.id',$userId);
		$this->db->where_in('client_users.status',array(ACTIVATED_USER));
		$this->db->join('client_users as managers','managers.id = client_users.manager_id');
		$results = $this->db->get('client_users');
// 		pr($this->db->last_query());
		$query = $results->result_array();
		return $query;
	}
	
	function getAssignedUsersForType($id, $type){
	    $client_id = $this->session->userdata('client_id');
	    $arrUsersDetails = array();
	    if($type == 'Kol'){
	        $this->db->select("user_kols.user_id, client_users.email");
	        $this->db->select("CONCAT(kols.last_name, '\, ', kols.first_name,' ', kols.middle_name) AS typename", FALSE);
	        $this->db->join('client_users', 'client_users.id = user_kols.user_id', 'left');
	        $this->db->join('kols', 'kols.id = user_kols.kol_id', 'left');
	        $this->db->where('user_kols.kol_id', $id);
	        if($client_id !== INTERNAL_CLIENT_ID){
	            $this->db->where('client_users.client_id', $client_id);
	        }
	        $query = $this->db->get('user_kols');
	    }else{
	        $this->db->select("user_orgs.user_id, client_users.email");
	        $this->db->select("organizations.name as typename");
	        $this->db->join('client_users', 'client_users.id = user_orgs.user_id', 'left');
	        $this->db->join('organizations', 'organizations.id = user_orgs.org_id', 'left');
	        $this->db->where('user_orgs.org_id', $id);
	        if($client_id !== INTERNAL_CLIENT_ID){
	            $this->db->where('client_users.client_id', $client_id);
	        }
	        $query = $this->db->get('user_orgs');
	    }
	    $result = $query->result();
	    foreach($result as $row){
	        $typeName = $row->typename;
	        $userEmails[] =  $row->email;
	    }
	    $arrUsersDetails['type_name'] = $typeName;
	    $arrUsersDetails['user_details'] = $userEmails;
	    
	    return $arrUsersDetails;
	}

}