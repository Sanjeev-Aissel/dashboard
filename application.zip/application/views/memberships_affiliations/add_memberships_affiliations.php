<?php
/**
* Description:File to create 'add'view for Memberships and Affiliations module
* 
* @package application.views.memberships_affiliations
* @author Vinayak
* @created :Dec 9, 2010
* 
*/
$autoSearchOptions = "width: 255, delimiter: /(,|;)\s*/, deferRequestBy: 300, noCache: true, minChars: 3";

function listRecordsPerPage($maxRecords=100,$increament=10){
	$rowList="";
 	for($i=10;$i<=$maxRecords;$i+=$increament){
 		$rowList.=$i.",";
 	}
 	$rowList=substr($rowList,0,-1);
 	return $rowList;
}
?>
<style>
#contentWrapper.span-24 {
    background-image: url("../../images/verticlesep.jpg");
    background-position: 168px 50%;
    background-repeat: repeat-y;
}
.analystForm textarea.analystNotes {
    width: 92%;
}

#uniName{
    width: 550px;
}
</style>
	<script type="text/javascript">
		/*
		* To Initiate the 'Ternary Navigation
		* @since 2.	
		* @created on 14-5-2011
		*
		*/
		$(function() {
			// Initiate the 'Ternary Navigation
			$("#affiliationTernaryNav").tabs().addClass("ui-tabs-vertical ui-helper-clearfix" );
	
			// Remove the Surrounding Border
			$("#affiliationTernaryNav" ).removeClass("ui-widget-content");
	
			// Remove the Round Corner
			$("#affiliationTernaryNav ul").removeClass("ui-corner-all ui-widget-header");
			
			$("#affiliationTernaryNav li").removeClass( "ui-corner-top" );
	
			// Add the Custom Class to control View
			$("#affiliationTernaryNav > div").addClass( "span-18 last" );
		});

		
			function validate(endDate,id,buttinId){
			
				var startDate=$("#"+id+"StartDate").val();
				if(endDate!=''){	
					if(startDate>endDate){
						$(".msgBox").show();
						disableButton(buttinId);
					}else{
						$(".msgBox").hide();
						enableButton(buttinId);
					}
		
				}
			}
				var options, a;
			// Autocomplet Options for the  Name' field of 'University / Hospital' ,'Assocition','Industry','Gvt','Others'
			// Autocomplet Options for the 'Institute Name' field searches From the lookuptable
		  	var uniInstituteNameAutoCompleteOptions = {
					serviceUrl: '<?php echo base_url();?>kols/get_institute_names',<?php echo $autoSearchOptions;?>
					
				};	
            //End of Autocomplet Options for the 'University / Hospital' ,'Assocition','Industry','Gvt','Others'

			// Autocomplet Options for the  'Role field of 'Government'
			var govRoleAutoCompleteOptions = {
  				serviceUrl: '<?php echo base_url();?>kols/get_membership_roles/government',<?php echo $autoSearchOptions;?>
  				
  			};

			// Autocomplet Options for the  'Role field of 'others'
			var othRoleAutoCompleteOptions = {
		      	serviceUrl: '<?php echo base_url();?>kols/get_membership_roles/others',<?php echo $autoSearchOptions;?>
		      	
			};
			// End of others
   		 
		var validationRules	=  {
				name: {
					required:true,
					//instituteName:"<?php echo base_url();?>kols/get_institute_id/"
							// remote: {
					      //  url: "<?php echo base_url();?>kols/get_institute_id/",
					      ////  type: "post",
					       // data: {
					        //	instituteName: function() {
					          //  return $("#username").val();
					         // }
					       // }*/
					//}
				},
				start_date: {
					fullYear: true
				},
				end_date: {
					fullYear: true
				},
				eduUrl1: {
					url: true
				},
				eduUrl2: {
					url: true
				},
				engagement_id:{
					required:true
				},
				type:{
					required:true
				},
				role:{
					required:true
					}
			};

			var validationMessages = {
				name: {
					required: "Required",
					instituteName: "Not Exists"					
				},
				start_date: "Only full year is allowed. Ex: 2010",
				end_date: "Only full year is allowed. Ex: 2010",
				url: "Please enter a valid URL address",
				engagement_id:"Required",
				type:"Required",
				
				role:"Required",
				
				
			};

			function disableButton(buttonId){
				$("#"+buttonId).attr("disabled", "disabled");
			}

			function enableButton(buttonId){
				$("#"+buttonId).removeAttr("disabled");
			}	
			
			// For the Vertical Tabs
		$(document).ready(function(){
			$('.instNotFound').hide();
			//Remove all the 'AutoCompleteContainer' divs' created automatically. If not, too many will get created
			$('div[id^="AutocompleteContainter_"]').remove();
			
			// Trigger the Autocompleter for 'University / Hospital' Details'
	    	// Trigger the Autocompleter for 'University Name' field searches From the lookuptable
	    	a = $('#uniName').autocomplete(uniInstituteNameAutoCompleteOptions);
	    	
			//Autocomplet Options for the Association'
			// Trigger the Autocompleter for 'Association Name' field searches From the lookuptable
			a = $('#assocName').autocomplete(uniInstituteNameAutoCompleteOptions);
			
			//Start of Autocomplet Options for the industry'
			// Trigger the Autocompleter for 'Guideline Name' field searches From the lookuptable
			a = $('#indName').autocomplete(uniInstituteNameAutoCompleteOptions);
			
			//Start of Autocomplet Options for the Government'
			// Trigger the Autocompleter for 'Government Name' field searches From the lookuptable
			a = $('#govName').autocomplete(uniInstituteNameAutoCompleteOptions);
			
			a = $('#govRole').autocomplete(govRoleAutoCompleteOptions);
			//End of Autocomplet Options for the Government
		
			//Start of Autocomplet Options for the Others'
			// Trigger the Autocompleter for 'Others Name' field searches From the lookuptable
			a = $('#othName').autocomplete(uniInstituteNameAutoCompleteOptions);

			a = $('#othRole').autocomplete(othRoleAutoCompleteOptions);
			//End of Autocomplet Options for the Others
			
			
			/**
			* Validate the text for 'Numeric Only'
			*/
			function allowNumericOnly(src) {
				if(!src.value.match(/^\d*$/)) {
					src.value=src.value.replace(/[^0-9]/g,'');  
				}
			}
	
			
	
			var institutionProfileDialogOpts = {
					title: "Create Institution Profile",
					modal: true,
					autoOpen: false,
					height: 300,
					width: 600,
					dialogClass:'microView',
					open: function() {
						//display correct dialog content
					}
			};


			//	'University / Hospital dialog box'
			//variable name1 is used to store an university/hospital name
			//replace function is used in order to consider a space
			$("#institutionProfile").dialog(institutionProfileDialogOpts);
			
			$(".InstitutionProfileLink").click(
					function (){
						var data = {};
						$("#institutionProfile").dialog("open");
						var sel=$('#affiliationTernaryNav').tabs('option','selected');
						if(sel==0)
						{
							var name=$("#uniName").val();
							var name1=name.replace(/\s/g,'%20');
						}
						if(sel==1)
						{
							var name=$("#assocName").val();
							var name1=name.replace(/\s/g,'%20');
						}
						if(sel==2)
						{
							var name=$("#indName").val();
							var name1=name.replace(/\s/g,'%20');
						}
						if(sel==3)
						{
							var name=$("#govName").val();
							var name1=name.replace(/\s/g,'%20');
						}
						if(sel==4)
						{
							var name=$("#othName").val();
							var name1=name.replace(/\s/g,'%20');
						}
						//$("#instituteName").val(name1);
						$("#institutionProfileContainer").load('<?php echo base_url()?>kols/add_institution/'+name1);
						return false;
			});


			/**
			* Save the 'University / Hospital'details
			*/
			$("#saveUniversity").click(function(){
					// Disable the SAVE Button
					disableButton("saveUniversity");
	
					//$("#universityForm").validate().resetForm();

					if(!$("#universityForm").validate().form()){
						enableButton("saveUniversity");
						return false;
					}
					// Check if the Institute Name is present in Master table or not
					instituteName	=	$("#uniName").val(); 

					// URL to get the Institute ID, if Name is present
					urlAction = '<?php echo base_url();?>kols/get_institute_id_else_save/';
					var data1 ={};
					data1['name']= instituteName;
					// Variable to hold the Institute Id
					instituteId	= '';
					$.post(urlAction,data1,
							function(returnData){
								if(returnData){
									instituteId	= returnData;
									$("#uniNameNotFound").hide();
									saveUniversityDetails(instituteId);
								}else{
									enableButton("saveUniversity");
									$("#uniNameNotFound").show();
	
									// Set the user entered name in the 'Add New Institute' form
									//$("#instituteName").val(instituteName);
									return false;
								}
							}, 
							"json");
				//- End of checking the Intitute Name in Master Table
			});	

			/**
			* Save the 'Association' details
			*/
			$("#saveAssociation").click(function(){
					// Disable the SAVE Button
					disableButton("saveAssociation");
	
					$("#associationForm").validate().resetForm();

					if(!$("#associationForm").validate().form()){
						enableButton("saveAssociation");
						return false;
					}
				
					// Check if the Institute Name is present in Master table or not
					instituteName	=	$("#assocName").val(); 
					// URL to get the Institute ID, if Name is present
					urlAction = '<?php echo base_url();?>kols/get_institute_id/'+instituteName;
	
					// Variable to hold the Institute Id
					instituteId	= '';
					$.post(urlAction,'',
							function(returnData){
								if(returnData){
									instituteId	= returnData;
									$("#assocNameNotFound").hide();
									saveAssociationDetails(instituteId);
								}else{
									enableButton("saveAssociation");
									$("#assocNameNotFound").show();
	
									// Set the user entered name in the 'Add New Institute' form
									$("#instituteName").val(instituteName);
									return false;
								}
							}, 
							"json");
					//- End of checking the Intitute Name in Master Table
			});	
			
			/**
			* Save the 'Industry' details
			*/
			$("#saveIndustry").click(function(){

				// Disable the SAVE Button
				disableButton("saveIndustry");

				$("#industryForm").validate().resetForm();


				if(!$("#industryForm").validate().form()){
					enableButton("saveIndustry");
					return false;
				}
				
				// Check if the Institute Name is present in Master table or not
				instituteName	=	$("#indName").val(); 
				// URL to get the Institute ID, if Name is present
				urlAction = '<?php echo base_url();?>kols/get_institute_id/'+instituteName;

				// Variable to hold the Institute Id
				instituteId	= '';
				$.post(urlAction,'',
						function(returnData){
							if(returnData){
								instituteId	= returnData;
								$("#indNameNotFound").hide();
								saveIndustryDetails(instituteId);
							}else{
								enableButton("saveIndustry");

								$("#indNameNotFound").show();

								// Set the user entered name in the 'Add New Institute' form
								$("#instituteName").val(instituteName);
								return false;
							}
						}, 
						"json");
				//- End of checking the Intitute Name in Master Table
			});			 

			/**
			* Save the 'Government Agency' details
			*/
			$("#saveGovernment").click(function(){
			
					// Disable the SAVE Button
					disableButton("saveGovernment");

					$("#governmentForm").validate().resetForm();

					if(!$("#governmentForm").validate().form()){
						enableButton("saveGovernment");
						return false;
					}
	
					// Check if the Institute Name is present in Master table or not
					instituteName	=	$("#govName").val(); 
					// URL to get the Institute ID, if Name is present
					urlAction = '<?php echo base_url();?>kols/get_institute_id/'+instituteName;
	
					// Variable to hold the Institute Id
					instituteId	= '';
					$.post(urlAction,'',
							function(returnData){
								if(returnData){
									instituteId	= returnData;
									$("#govNameNotFound").hide();
									saveGovernmentDetails(instituteId);
								}else{
									enableButton("saveGovernment");

									$("#govNameNotFound").show();
	
									// Set the user entered name in the 'Add New Institute' form
									$("#instituteName").val(instituteName);
									return false;
								}
							}, 
							"json");
					//- End of checking the Intitute Name in Master Table
			});			 
			
			/**
			* Save the 'Others' details
			*/
			$("#saveOthers").click(function(){

					// Disable the SAVE Button
					disableButton("saveOthers");

					$("#othersForm").validate().resetForm();

					if(!$("#othersForm").validate().form()){
						enableButton("saveOthers");
						return false;
					}
		
					// Check if the Institute Name is present in Master table or not
					instituteName	=	$("#othName").val(); 
				
					// URL to get the Institute ID, if Name is present
					urlAction = '<?php echo base_url();?>kols/get_institute_id/'+instituteName;
	
					// Variable to hold the Institute Id
					instituteId	= '';
					$.post(urlAction,'',
							function(returnData){
								if(returnData){
									instituteId	= returnData;
									$("#othNameNotFound").hide();
									saveOthersDetails(instituteId);
								}else{
									enableButton("saveOthers");

									$("#othNameNotFound").show();
	
									// Set the user entered name in the 'Add New Institute' form
									$("#instituteName").val(instituteName);
									return false;
								}
							}, 
							"json");
						//- End of checking the Intitute Name in Master Table
			});			 

			$("#universityForm").validate({
				debug:true,
				onkeyup:true,
				rules: validationRules,
				messages: validationMessages
			});

			$("#associationForm").validate({
				onkeyup:true,
				rules: validationRules,
				messages: validationMessages
			});

			$("#industryForm").validate({
				onkeyup:true,
				rules: validationRules,
				messages: validationMessages
			});

			$("#governmentForm").validate({
				onkeyup:true,
				rules: validationRules,
				messages: validationMessages
			});

			$("#othersForm").validate({
				onkeyup:true,
				rules: validationRules,
				messages: validationMessages
			});
		});
		

//-------------Start of "saving functions"-------------------
		/**
		 *  Common method for save
		 * 
		 */
		function saveAffiliationDetails(idType,formId,gridId,btnId,instituteId){
			
			//If Institute Id is present then perform save or update
			id = $("#"+idType+"Id").val();
			if(id == ''){
				formAction = '<?php echo base_url();?>kols/save_membership';
			}else{
				formAction = '<?php echo base_url();?>kols/update_membership';
			}				

			$.post(formAction, $("#"+formId).serialize(),
				function(returnData){
				
					if(returnData.saved == true){
						// Clear the existing form details
						$("#"+idType+"Name").val("");
						$("#"+idType+"Engagement").val("");
						$("#"+idType+"Department").val("");
						$("#"+idType+"Role").val("");
						$("#"+idType+"StartDate").val("");
						$("#"+idType+"EndDate").val("");
						$("#"+idType+"Url1").val("");
						$("#"+idType+"Url2").val("");
						$("#"+idType+"Notes").val("");
						$("#type").val("");

						$("tr.ui-state-highlight").removeClass('ui-state-highlight');
						if(id == ''){									
							var datarow = {
											id:returnData.lastInsertId,
											institute_id:returnData.data.institute_id,
											engagement_id:returnData.data.engagement_id,
											type:returnData.data.type,
											department:returnData.data.department,
											role:returnData.data.role,
											start_date:returnData.data.start_date,
											end_date:returnData.data.end_date,
											url1:returnData.data.url1,
											url2:returnData.data.url2,
											notes:returnData.data.notes
										}; 
							var su=jQuery("#"+gridId).jqGrid('addRowData',returnData.lastInsertId,datarow); 
							
						}else{
								//jQuery("#JQBlistUniversityResultSet").trigger("reloadGrid");
								jQuery("#"+gridId).jqGrid('setRowData',returnData.data.id,{
																			id:returnData.lastInsertId,
																			institute_id:returnData.data.institute_id,
																			engagement_id:returnData.data.engagement_id,
																			type:returnData.data.type,
																			department:returnData.data.department,
																			role:returnData.data.role,
																			start_date:returnData.data.start_date,
																			end_date:returnData.data.end_date,
																			url1:returnData.data.url1,
																			url2:returnData.data.url2,
																			notes:returnData.data.notes
																		}); 
								$("tr#"+returnData.data.id).addClass('ui-state-highlight');
							}
						
						// If we are updating
						 
						if(id != ''){
							// Modify the text of 'Button' from 'Update' to 'Add'
							$("#"+btnId).val("Add");

							// Re-Set the Hidden Eduction Id value
							$("#"+idType+"Id").val("");									
							}
						$("div."+idType+"MsgBox").fadeOut(1500);
						$(".msgBox").hide();	
						enableButton(btnId);
					}else{
						enableButton(btnId);
							// Display Error Message
				     }
			},"json");
		}		
		
		/**
		* Save the 'University / Hospital'details
		*/
		function saveUniversityDetails(instituteId){
			$("#uniNameId").val(instituteId);
			
			$('div.uniMsgBox').removeClass('success');
			$('div.uniMsgBox').addClass('notice');
			$('div.uniMsgBox').show();
			$('div.uniMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');

			saveAffiliationDetails('uni','universityForm','JQBlistUniversityResultSet','saveUniversity',instituteId);
		}

		/**
		* Save the 'Association'details
		*/
		function saveAssociationDetails(instituteId){
			$("#assocNameId").val(instituteId);
			
			$('div.assocMsgBox').removeClass('success');
			$('div.assocMsgBox').addClass('notice');
			$('div.assocMsgBox').show();
			$('div.assocMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');

			saveAffiliationDetails('assoc','associationForm','JQBlistAssociationResultSet','saveAssociation',instituteId);
		}

		/**
		* Save the 'Industry'details
		*/
		function saveIndustryDetails(instituteId){
			$("#indNameId").val(instituteId);
			
			$('div.indMsgBox').removeClass('success');
			$('div.indMsgBox').addClass('notice');
			$('div.indMsgBox').show();
			$('div.indMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
			
			saveAffiliationDetails('ind','industryForm','JQBlistIndustryResultSet','saveIndustry',instituteId);
		}

		/**
		* Save the 'Government'details
		*/
		function saveGovernmentDetails(instituteId){
			$("#govNameId").val(instituteId);
			
			$('div.govMsgBox').removeClass('success');
			$('div.govMsgBox').addClass('notice');
			$('div.govMsgBox').show();
			$('div.govMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
			
			saveAffiliationDetails('gov','governmentForm','JQBlistGovernmentResultSet','saveGovernment',instituteId);
		}	

		/**
		* Save the 'others'details
		*/
		function saveOthersDetails(instituteId){
			$("#othNameId").val(instituteId);
			
			$('div.othMsgBox').removeClass('success');
			$('div.othMsgBox').addClass('notice');
			$('div.othMsgBox').show();
			$('div.othMsgBox').html('Saving the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');

			saveAffiliationDetails('oth','othersForm','JQBlistOthersResultSet','saveOthers',instituteId);		
		}
//-------------End of "saving functions"-------------------

//----------------- Start of Edit and Delete methods--------------
		/**
		 *  Common method for "Edit"
		 * 
		 */	
		function editAffiliation(idType,gridId,btnId,id){
			var rd=jQuery("#"+gridId).jqGrid('getRowData',id); 
			
			//Getting the engagement ID
			engagementName =''; 
			var engamentId ='';
			engagementName   =  rd.engagement_id;
			
			var data = {};
			data['engagementName'] = engagementName;
			method = '<?php echo base_url();?>kols/get_engagement_id';

			$.post(method,data,function(returnData){
				engamentId=returnData;
				// Get the values from TR - Table Row, which is under editing
				name 		= rd.institute_id;

				department	= rd.department;
				role		= rd.role;
				type =rd.type;
				start_date	= rd.start_date;
				end_date	= rd.end_date;
				url1		= $(rd.url1).attr("href");
				url2		= $(rd.url2).attr("href");
				notes		= rd.notes;
				
				// Add the values to the form
				$("#"+idType+"Name").val(name);
				$("#"+idType+"Engagement").val(engamentId);
				$("#type").val(type);
				$("#"+idType+"Department").val(department);
				$("#"+idType+"Role").val(role);
				$("#"+idType+"StartDate").val(start_date);
				$("#"+idType+"EndDate").val(end_date);
				$("#"+idType+"Url1").val(url1);
				$("#"+idType+"Url2").val(url2);
				$("#"+idType+"Notes").val(notes);
				// Modify the text of 'Button' from 'Add' to 'Update'
				$("#"+btnId).val("Update");

				// Set the Hidden Eduction Id value
				$("#"+idType+"Id").val(id);
				
	

				// Remove the row from the Table
				$("tr").removeClass('ui-state-highlight');
				$("tr#"+id).addClass('ui-state-highlight');
			},"json");
		}

		/**
		* Edit the 'University( Details'
		*/
		function editUniversity(id){
			editAffiliation('uni','JQBlistUniversityResultSet','saveUniversity',id);
		}		

		/**
		* Deleteting the 'University Details'
		*/  
		function deleteUniversity(id){								
			var formAction = '<?php echo base_url();?>kols/delete_membership/'+id;
			jQuery("#JQBlistUniversityResultSet").jqGrid('delGridRow',id,{reloadAfterSubmit:false,url:formAction});    			
		}	
	      
		/**
		* Edit the 'Association Details'
		*/
		function editAssociation(id){
			editAffiliation('assoc','JQBlistAssociationResultSet','saveAssociation',id);
		}

		/**
		* Deleteting the 'Association Details'
		*/  
		function deleteAssociation(id){								
			var formAction = '<?php echo base_url();?>kols/delete_membership/'+id;
			jQuery("#JQBlistAssociationResultSet").jqGrid('delGridRow',id,{reloadAfterSubmit:false,url:formAction});    		
		}	

		/**
		* Edit the 'Industry' Details'
		*/	 
		function editIndustry(id){
			editAffiliation('ind','JQBlistIndustryResultSet','saveGovernment',id);
		}

		/**
		* Deleteting the 'Industry Details'
		*/  
		function deleteIndustry(id){								
                
			var formAction = '<?php echo base_url();?>kols/delete_membership/'+id;
			jQuery("#JQBlistIndustryResultSet").jqGrid('delGridRow',id,{reloadAfterSubmit:false,url:formAction});    
		}	
		
		/**
		* Edit the 'Government Details'
		*/	 
		function editGovernment(id){
			editAffiliation('gov','JQBlistGovernmentResultSet','saveIndustry',id);
		}
		
		/**
		* Deleteting the 'Government Details'
		*/  
		function deleteGovernment(id){								
                
			var formAction = '<?php echo base_url();?>kols/delete_membership/'+id;
			jQuery("#JQBlistGovernmentResultSet").jqGrid('delGridRow',id,{reloadAfterSubmit:false,url:formAction});    
		}

		/**
		* Edit the others details
		*/   
		function editOthers(id){
			editAffiliation('oth','JQBlistOthersResultSet','saveOthers',id);
		}

		/**
		* Deleteting the 'Others Details'
		*/  
		function deleteOthers(id){								

			var formAction = '<?php echo base_url();?>kols/delete_membership/'+id;
			jQuery("#JQBlistOthersResultSet").jqGrid('delGridRow',id,{reloadAfterSubmit:false,url:formAction});    			
		}	
//-----------------End of Edit and Delete methods--------------
		
//-----------------Start of "Jqgrid methods"-------------------		
 		
 		
		 		var uniColSettings = [				{name:'id',index:'id', hidden:true},
				   		{name:'institute_id',index:'institute_id', width:250,editable:true},
				   		{name:'engagement_id',index:'engagement_id',width:110,editable:true},
				   		{name:'type',index:'type',width:110,editable:true},
				   		{name:'department',index:'department',width:110,editable:true},
				   		{name:'role',index:'role',width:110,editable:true},
				   		{name:'start_date',index:'start_date',width:50,resizable:true,editable:true},
				   		{name:'end_date',index:'end_date',resizable:true,width:50,editable:true},
				   		{name:'url1',index:'url1',resizable:true,width:50,editable:true,search:false},
				   		{name:'url2',index:'url2',resizable:true,width:50,editable:true,search:false},
				   		{name:'notes',index:'notes',resizable:true,width:100,editable:true,search:false},
				   		{name:'act',resizable:true,search:false,width:75}];
		
		 		var commonJQGridConfiguration = {
						datatype: "json",
					   	rowNum:10,
					   	rownumbers: true,
					   	autowidth: false, 
					   	loadonce:true,
					   	ignoreCase:true,
					   	hiddengrid:false,
					   	height: "auto",	
					   	width:"95%",
					   	resizable:true,   
					   	mtype: "POST",
					    viewrecords: true,
					    sortorder: "desc",
					   	rowList:paginationValues,
					    jsonReader: { repeatitems : false, id: "0" },
					    multiselect: true
				}; 

		 	

				function universityTab(){
					/*
					*JqGrid for University table
					*/
					var kolId = $('#kolId').val();
					var UniversityGridConfiguration = {
					   	url:'<?php echo base_url();?>kols/list_memberships/all/'+kolId,
					   	colNames:['Id','Name','EngagementType','Org','Dept/Committee', 'Title', 'Start','End','Url1','Url2','Notes','Action'],
					   	colModel:uniColSettings,
					   	pager: '#listUniversityPager',
					   	sortname: 'id',
					    gridComplete: function(){ 
						    var ids = jQuery("#JQBlistUniversityResultSet").jqGrid('getDataIDs'); 
						    	for(var i=0;i < ids.length;i++){ 
							    	var cl = ids[i];				    	
							    	be = "<a href='#' onclick=\"editUniversity('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png'></a>";
							    	be += "&nbsp; | &nbsp;";
							    	be += "<a href='#' onclick=\"deleteUniversity('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png'></a>";
			
							    	jQuery("#JQBlistUniversityResultSet").jqGrid('setRowData',ids[i],{act:be}); 
							    	} 
						    	jQuery("#JQBlistUniversityResultSet").jqGrid('navGrid','hideCol',"id"); 
						    	}, 
					    caption:"University Details"		    
					};
			
					$.extend(UniversityGridConfiguration, commonJQGridConfiguration);
			
					jQuery("#JQBlistUniversityResultSet").jqGrid(UniversityGridConfiguration);
			
					jQuery("#JQBlistUniversityResultSet").jqGrid('navGrid','#listUniversityPager',{edit:false,add:false,del:false,search:false,refresh:false});	
					//Toolbar search bar below the Table Headers
					jQuery("#JQBlistUniversityResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
					//Toolbar search bar above the Table Headers
					//jQuery("#t_JQBlistUniversityResultSet").height(25).jqGrid('filterGrid',"JQBlistUniversityResultSet",{gridModel:true,gridToolbar:true});
					
					jQuery("#JQBlistUniversityResultSet").jqGrid('navGrid','#presize',{edit:false,add:false,del:false});
					jQuery("#JQBlistUniversityResultSet").jqGrid('gridResize',{minWidth:550,maxWidth:2000,minHeight:80, maxHeight:350});

					// Delete selected row(s)
					jQuery("#JQBlistUniversityResultSet").jqGrid('navButtonAdd',"#listUniversityPager",{caption:"Delete",buttonicon:"ui-icon-trash",title:"Delete Select Row(s)",
						onClickButton:function (){
							var selectedAffs	= $(this).getGridParam('selarrrow');
							if(selectedAffs.length>0){
								deleteSelectedAffiliations(selectedAffs);
							}else{
								jAlert('Please select atleast one Affiliations');
							}
						}
					}); 
					//Toggle Toolbar Search 
					//Toggle Toolbar Search 
					jQuery("#JQBlistUniversityResultSet").jqGrid('navButtonAdd',"#listUniversityPager",{caption:"Search",title:"Toggle Search",
						onClickButton:function(){ 			
							if(jQuery(".ui-search-toolbar").css("display")=="none") {
								jQuery(".ui-search-toolbar").css("display","");
							} else {
								jQuery(".ui-search-toolbar").css("display","none");
							}
							
						} 
					}); 
				
				}

				function deleteSelectedAffiliations(affIds){
					jConfirm("Are you sure you want to delete selected Affiliation's?","Please confirm",function(r){
						if(r){
//							alert($.type(affIds));
							var data = {};
							data['ids'] = affIds;
							$.ajax({
								url:'<?php echo base_url()?>kols/delete_selected_affiliations',
								type:'post',
								data:data,
								dataType:"json",
								success:function(returnMsg){
									if(returnMsg.status)
										$('a[href="#universityTabId"]').trigger('click');
									}
							});
							}else{
									return false;
								}
					});
					} 

				function associationTab(){
					/*
					*JqGrid for Association table
					*/
					var kolId = $('#kolId').val();
					var AssociationGridConfiguration = {
					   	url:'<?php echo base_url();?>kols/list_memberships/association/'+kolId,
					   	colNames:['Id','Name','EngagementType','Dept/Committee', 'Title', 'Start','End','Url1','Url2','Notes','Action'],
					   	colModel:uniColSettings,   			
					   	pager: '#listAssociationPager',
					   	sortname: 'id',
					    gridComplete: function(){ 
						    var ids = jQuery("#JQBlistAssociationResultSet").jqGrid('getDataIDs'); 
						    	for(var i=0;i < ids.length;i++){ 
							    	var cl = ids[i];				    	
							    	be = "<a href='#' onclick=\"editAssociation('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png'></a>";
							    	be += "&nbsp; | &nbsp;";
							    	be += "<a href='#' onclick=\"deleteAssociation('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png'></a>";
			
							    	jQuery("#JQBlistAssociationResultSet").jqGrid('setRowData',ids[i],{act:be}); 
							    	} 
						    	jQuery("#JQBlistAssociationResultSet").jqGrid('navGrid','hideCol',"id"); 
						    	}, 
					    editurl:"<?php echo base_url();?>kols/update_education_detail",		   
					    caption:"Association Details"		    
					};
					$.extend(AssociationGridConfiguration, commonJQGridConfiguration);
			
					jQuery("#JQBlistAssociationResultSet").jqGrid(AssociationGridConfiguration);
			
			
					jQuery("#JQBlistAssociationResultSet").jqGrid('navGrid','#listAssociationPager',{edit:false,add:false,del:false,search:false,refresh:false});	
					//Toolbar search bar below the Table Headers
					jQuery("#JQBlistAssociationResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
					//Toolbar search bar above the Table Headers
					//jQuery("#t_JQBlistAssociationResultSet").height(25).jqGrid('filterGrid',"JQBlistAssociationResultSet",{gridModel:true,gridToolbar:true});
					
					jQuery("#JQBlistAssociationResultSet").jqGrid('navGrid','#presize',{edit:false,add:false,del:false});
					jQuery("#JQBlistAssociationResultSet").jqGrid('gridResize',{minWidth:550,maxWidth:2000,minHeight:80, maxHeight:350});
					
					//Toggle Toolbar Search 
					jQuery("#JQBlistAssociationResultSet").jqGrid('navButtonAdd',"#listAssociationPager",{caption:"Search",title:"Toggle Search",
						onClickButton:function(){ 			
							if(jQuery(".ui-search-toolbar").css("display")=="none") {
								jQuery(".ui-search-toolbar").css("display","");
							} else {
								jQuery(".ui-search-toolbar").css("display","none");
							}
							
						} 
					}); 
				}
	
				function industryTab(){			
					/*
					*JqGrid for Industry table
					*/
					var kolId = $('#kolId').val();
					var IndustryGridConfiguration = {
					   	url:'<?php echo base_url();?>kols/list_memberships/industry/'+kolId,
					   	colNames:['Id','Name','Engagement Type','Dept/Committee', 'Title', 'Start','End','Url1','Url2','Notes','Action'],
						colModel:uniColSettings,   
					   	pager: '#listIndustryPager',
					   	sortname: 'id',
					    gridComplete: function(){ 
						    var ids = jQuery("#JQBlistIndustryResultSet").jqGrid('getDataIDs'); 
						    	for(var i=0;i < ids.length;i++){ 
							    	var cl = ids[i];				    	
							    	be = "<a href='#' onclick=\"editIndustry('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png'></a>";
							    	be += "&nbsp; | &nbsp;";
							    	be += "<a href='#' onclick=\"deleteIndustry('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png'></a>";
			
							    	jQuery("#JQBlistIndustryResultSet").jqGrid('setRowData',ids[i],{act:be}); 
							    	} 
						    	jQuery("#JQBlistIndustryResultSet").jqGrid('navGrid','hideCol',"id"); 
						    	}, 
				    	loadComplete: function() {
				    	    $("option[value=100000000]").text('All');
				    			},    	
					    editurl:"<?php echo base_url();?>kols/update_education_detail",		   
					    caption:"Industry Details"		    
					};
					$.extend(IndustryGridConfiguration, commonJQGridConfiguration);
			
					jQuery("#JQBlistIndustryResultSet").jqGrid(IndustryGridConfiguration);
			
					jQuery("#JQBlistIndustryResultSet").jqGrid('navGrid','#listIndustryPager',{edit:false,add:false,del:false,search:false,refresh:false});	
					//Toolbar search bar below the Table Headers
					jQuery("#JQBlistIndustryResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
					//Toolbar search bar above the Table Headers
					//jQuery("#t_JQBlistIndustryResultSet").height(25).jqGrid('filterGrid',"JQBlistIndustryResultSet",{gridModel:true,gridToolbar:true});
					
					jQuery("#JQBlistIndustryResultSet").jqGrid('navGrid','#presize',{edit:false,add:false,del:false});
					jQuery("#JQBlistIndustryResultSet").jqGrid('gridResize',{minWidth:550,maxWidth:2000,minHeight:80, maxHeight:350});
					
					//Toggle Toolbar Search 
					jQuery("#JQBlistIndustryResultSet").jqGrid('navButtonAdd',"#listIndustryPager",{caption:"Search",title:"Toggle Search",
						onClickButton:function(){ 			
							if(jQuery(".ui-search-toolbar").css("display")=="none") {
								jQuery(".ui-search-toolbar").css("display","");
							} else {
								jQuery(".ui-search-toolbar").css("display","none");
							}
							
						} 
					}); 
				}

				function governmentTab(){
					/*
					*JqGrid for Government table
					*/
					var kolId = $('#kolId').val();
					var GovernmentGridConfiguration = {
					   	url:'<?php echo base_url();?>kols/list_memberships/government/'+kolId,
					   	colNames:['Id','Name','EngagementType','Dept/Committee', 'Title', 'Start','End','Url1','Url2','Notes','Action'],
						colModel:uniColSettings,   
					   	pager: '#listGovernmentPager',
					   	sortname: 'id',
					    gridComplete: function(){ 
						    var ids = jQuery("#JQBlistGovernmentResultSet").jqGrid('getDataIDs'); 
						    	for(var i=0;i < ids.length;i++){ 
							    	var cl = ids[i];				    	
							    	be = "<a href='#' onclick=\"editGovernment('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png'></a>";
							    	be += "&nbsp; | &nbsp;";
							    	be += "<a href='#' onclick=\"deleteGovernment('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png'></a>";
			
							    	jQuery("#JQBlistGovernmentResultSet").jqGrid('setRowData',ids[i],{act:be}); 
							    	} 
						    	jQuery("#JQBlistGovernmentResultSet").jqGrid('navGrid','hideCol',"id"); 
						    	}, 
				    	loadComplete: function() {
				    	    $("option[value=100000000]").text('All');
				    			},   	
					  
					    editurl:"<?php echo base_url();?>kols/update_education_detail",		   
					    caption:"Government Details"		    
					};
					$.extend(GovernmentGridConfiguration, commonJQGridConfiguration);
			
					jQuery("#JQBlistGovernmentResultSet").jqGrid(GovernmentGridConfiguration);
			
					jQuery("#JQBlistGovernmentResultSet").jqGrid('navGrid','#listGovernmentPager',{edit:false,add:false,del:false,search:false,refresh:false});	
					//Toolbar search bar below the Table Headers
					jQuery("#JQBlistGovernmentResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
					//Toolbar search bar above the Table Headers
					//jQuery("#t_JQBlistGovernmentResultSet").height(25).jqGrid('filterGrid',"JQBlistGovernmentResultSet",{gridModel:true,gridToolbar:true});
					
					jQuery("#JQBlistGovernmentResultSet").jqGrid('navGrid','#presize',{edit:false,add:false,del:false});
					jQuery("#JQBlistGovernmentResultSet").jqGrid('gridResize',{minWidth:550,maxWidth:2000,minHeight:80, maxHeight:350});
					
					//Toggle Toolbar Search 
					jQuery("#JQBlistGovernmentResultSet").jqGrid('navButtonAdd',"#listGovernmentPager",{caption:"Search",title:"Toggle Search",
						onClickButton:function(){ 			
							if(jQuery(".ui-search-toolbar").css("display")=="none") {
								jQuery(".ui-search-toolbar").css("display","");
							} else {
								jQuery(".ui-search-toolbar").css("display","none");
							}
							
						} 
					}); 
				}
				//Grid resize 
				//jQuery("#JQBlistGovernmentResultSet").jqGrid('gridResize',{minWidth:200,maxWidth:800,minHeight:50, maxHeight:350});
				
				
				
				function othersTab(){
					/*
					*JqGrid for Others table
					*/
					var kolId = $('#kolId').val();
					var OthersGridConfiguration = {
					   	url:'<?php echo base_url();?>kols/list_memberships/others/'+kolId,
					   	colNames:['Id','Name','EngagementType','Dept/Committee', 'Title', 'Start','End','Url1','Url2','Notes','Action'],
						colModel:uniColSettings,   
					   	pager: '#listOthersPager',
					   	sortname: 'id',
					    gridComplete: function(){ 
						    var ids = jQuery("#JQBlistOthersResultSet").jqGrid('getDataIDs'); 
						    	for(var i=0;i < ids.length;i++){ 
							    	var cl = ids[i];				    	
							    	be = "<a href='#' onclick=\"editOthers('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png'></a>";
							    	be += "&nbsp; | &nbsp;";
							    	be += "<a href='#' onclick=\"deleteOthers('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png'></a>";
			
							    	jQuery("#JQBlistOthersResultSet").jqGrid('setRowData',ids[i],{act:be}); 
							    	} 
						    	jQuery("#JQBlistOthersResultSet").jqGrid('navGrid','hideCol',"id"); 
						    	},
				    	loadComplete: function() {
				    	    $("option[value=100000000]").text('All');
				    			},    	 
					    jsonReader: { repeatitems : false, id: "0" }, 
					    editurl:"<?php echo base_url();?>kols/update_education_detail",		   
					    caption:"Others Details"		    
					};
					$.extend(OthersGridConfiguration, commonJQGridConfiguration);
			
					jQuery("#JQBlistOthersResultSet").jqGrid(OthersGridConfiguration);
			
					jQuery("#JQBlistOthersResultSet").jqGrid('navGrid','#listOthersPager',{edit:false,add:false,del:false,search:false,refresh:false});	
					//Toolbar search bar below the Table Headers
					jQuery("#JQBlistOthersResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
					//Toolbar search bar above the Table Headers
					//jQuery("#t_JQBlistOthersResultSet").height(25).jqGrid('filterGrid',"JQBlistOthersResultSet",{gridModel:true,gridToolbar:true});
					
					jQuery("#JQBlistOthersResultSet").jqGrid('navGrid','#presize',{edit:false,add:false,del:false});
					jQuery("#JQBlistOthersResultSet").jqGrid('gridResize',{minWidth:750,maxWidth:2000,minHeight:80, maxHeight:350});
					
					//Toggle Toolbar Search 
					jQuery("#JQBlistOthersResultSet").jqGrid('navButtonAdd',"#listOthersPager",{caption:"Search",title:"Toggle Search",
						onClickButton:function(){ 			
							if(jQuery(".ui-search-toolbar").css("display")=="none") {
								jQuery(".ui-search-toolbar").css("display","");
							} else {
								jQuery(".ui-search-toolbar").css("display","none");
							}
							
						} 
					}); 
				}
	 		
		//Grid resize 
		//jQuery("#JQBlistOthersResultSet").jqGrid('gridResize',{minWidth:200,maxWidth:800,minHeight:50, maxHeight:350});
//-----------------End of "Jqgrid methods"-------------------						
			
		function getStatesByCountryId(){
			var countryId=$('#country_id').val();		
			var params = "country_id="+countryId;	
			$("#state_id").html("<option value=''>select state</option>");
			$("#city_id").html("<option value=''>select city</option>");
			var states = document.getElementById('state_id');
			$.ajax({
				url: "<?php echo base_url()?>/country_helpers/get_states_by_countryid/",
				dataType: "json",
				data: params,
				type: "POST",
				success: function(responseText){					
					$.each(responseText, function(key, value) {					
						var newState = document.createElement('option');
						newState.text = value.state_name;
						newState.value = value.state_id;
						 var prev = states.options[states.selectedIndex];
						 states.add(newState, prev);				
						});
                                                
                $("#state_id option[value='']").remove();
                $("#state_id").prepend("<option value=''>-- Select State --</option>");
                $("#state_id").val("");
				}		
			});		
			
		}

		function getCitiesByStateId(){
			
			var stateId=$('#state_id').val();
			$("#city_id").html("<option value=''>select city</option>");	
			var cities = document.getElementById('city_id');
			var params = "state_id="+stateId;	
			
			$.ajax({
				url: "<?php echo base_url()?>/country_helpers/get_cities_by_stateid/",
				dataType: "json",
				data: params,
				type: "POST",
				success: function(responseText){					
					$.each(responseText, function(key, value) {	
								
					var newCity = document.createElement('option');
					newCity.text = value.city_name;
					newCity.value = value.city_id;
					 var prev = cities.options[cities.selectedIndex];
					 cities.add(newCity, prev);				
					});
                                        $("#city_id option[value='']").remove();
                    $("#city_id").prepend("<option value=''>-- Select City --</option>");
                    $("#city_id").val("");
				}		
			});		
			
		}

			/*
			* To Load Selected Tab
			* @created on 18-5-2011
			* @author Kunal
			* @since 2.2
			*/
			$(document).ready(function(){				
				$('.ternaryNav li a').click(function(){
					loadSelectedTab();
				});
				universityTab();
				});

			/*
			* To Load Selected Tab
			* @created on 18-5-2011
			* @author Kunal
			* @since 2.2
			*/
			function loadSelectedTab(){
				var sel=$('#affiliationTernaryNav').tabs('option','selected');
				switch(sel){
					case 0: $("#universityGridContainer").html("");
							
							// Append the required div and table
							$("#universityGridContainer").html('<table id="JQBlistUniversityResultSet"></table><div id="listUniversityPager"></div>');

							universityTab();
							break;
					
					case 1: $("#associationGridContainer").html("");
							
							// Append the required div and table
							$("#associationGridContainer").html('<table id="JQBlistAssociationResultSet"></table><div id="listAssociationPager"></div>');

							associationTab();
							break;
					
					case 2: $("#industryGridContainer").html("");
							
							// Append the required div and table
							$("#industryGridContainer").html('<table id="JQBlistIndustryResultSet"></table><div id="listIndustryPager"></div>');

							industryTab();
							break;
									
					case 3: $("#governmentGridContainer").html("");
							
							// Append the required div and table
							$("#governmentGridContainer").html('<table id="JQBlistGovernmentResultSet"></table><div id="listGovernmentPager"></div>');

							governmentTab();
							break;	
							
					case 4: $("#otherGridContainer").html("");
					
							// Append the required div and table
							$("#otherGridContainer").html('<table id="JQBlistOthersResultSet"></table><div id="listOthersPager"></div>');

							othersTab();
							break;	
				}
			}
</script>
				
				<div id="affiliationTernaryNav" class="affiliationTernaryNav verticalTabDataWrapper">
					<div class="leftBar">
						<?php $this->load->view('elements/kol_short_details');?>
						<p style="margin:0px;" id="uploadImageLink">Upload Image</p>
						
						<ul class="span-4 ternaryNav" >
							<li><a href="#universityTabId">Organization Type</a></li>
							
						</ul>
					</div>
					
					
			
				<div id="editMembership"  class="span-19 last" style="margin-left: 20px;">
				<!-- Start of University / Hospital Form-->
				<div id="universityTabId">
					
					<div class="msgBoxContainer"><div class="uniMsgBox"></div></div>
				
					<form action="save_membership" method="post" id="universityForm" name="universityForm" class="validateForm">
				    
				    	<input type="hidden" name="id" id="uniId" value=""></input>
				    	<input type="hidden" name="kol_id" id="kolId" value="<?php echo $arrKol['id']?>"></input>
				    	<table class="analystForm" id="universityTbl">
							<tr>
								<td colspan="2">		
								 	<p>
								 		<label for="uniName">Name: <span class="required">*</span> </label> 
								 		<input type="hidden" name="institute_id" id="uniNameId"></input>
								 		<input type="text" name="name" id="uniName" class="required" value=""></input>
								 	</p>
								 	<div id="uniNameNotFound" class="instNotFound">Sorry! The institute name is not found in our database. <a href="#" class="InstitutionProfileLink">Click here</a> to add this institute</div>
								</td>
								
							</tr>
							<tr>
								<td>		
								 	<p>
								 		<label for="orgName">Org Type: <span class="required">*</span> </label> 
								 		
								 		<select name="type" id="type" class="required">
									
											<option value="">--- Select ---</option>
												<option value="association">Association</option>
												<option value="government">Government</option>
												<option value="industry">Industry</option>
												<option value="university">University</option>
												<option value="others">Others</option>
												
										</select>
								 	</p>
								</td>
								<td>
									<p>
										<label for="uniEngagement">Engagement Type:<span class="required">*</span> </label> 
										<select name="engagement_id" id="uniEngagement" style="width: 255px;" class="required">
											<option value="">--- Select ---</option>
												<?php 
												foreach($arrEngagementTypes as $key => $value){
												if($key == $arrMembership['engagement_id'])
													echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
												else
													echo '<option value="'.$key.'">'.$value.'</option>';
												}
												?>
										</select>
									</p>
								</td>
								
							</tr>
							<tr>
								<td>		
							 		<p>
							 			<label for="uniDepartment">Dept/Committee:<span class="required">*</span></label>
								        <input type="text" name="department" id="uniDepartment" value="" class="required"></input>
									</p>
								 </td>	
								 <td>			
								 	<p>
								 		<label for="uniRole">Title:<span class="required">*</span></label>
						        		<input type="text" name="role" id="uniRole" class="required" value=""></input>
					        		</p>
								</td>
					  		</tr>
					  		<tr>
					  			<td>			
						  			<p>
						  				<label for="uniStartDate">Start:</label>
						        		<input type="text" name="start_date" id="uniStartDate" value="" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear"></input>
					        		</p>
				        		</td>
				        		<td>
						   			<p>
						   				<label for="uniEndDate">End:</label>
						        		<input type="text" name="end_date" id="uniEndDate" value="" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear" onmouseout="validate(this.value,'uni','saveUniversity')"></input>
					        		</p>
					        		<div class="msgBox instNotFound">Invalid Year.End Year Should be Greater than Start Year</div>
							 	</td> 
						 	</tr>
						 	<tr>
						 		<td>    		
									<p>
										<label for="uniUrl1">URL1:</label>
										<input type="text" name="url1" id="uniUrl1" value="" class="url"></input>
									</p>
								</td>
								<td>
							   	 	<p>
					   	 				<label for="uniUrl2">URL2:</label>
										<input type="text" name="url2" id="uniUrl2" value="" class="url"></input>
									</p>
								</td>
							</tr>
							<tr>				
						    	<td colspan="2">
							    	<p>
							    		<label for="uniNotes">Notes:</label>
										<textarea rows="2" cols="60"  name="notes" id="uniNotes" class="analystNotes"></textarea>
									</p>
								</td>
								<td>
								
								</td>
							</tr>
							<tr>
								<td colspan="2">				        		  
									<div class="formButtons"">   
										<input type="button" value="Add" name="submit" id="saveUniversity">
							         </div>
								</td>
								<td>
								
								</td>									
							</tr>
						</table>					         
					</form>
					     
					<!-- Start of JQGrid based Table to list University / Hospital Results -->
					<div class="gridWrapper" id="universityGridContainer">
						<table id="JQBlistUniversityResultSet"></table>
						<div id="listUniversityPager"></div>
					</div>
					
					<!-- End of Listing University / Hospital Results--> 	
				</div>
				<!-- End of University / Hospital Form-->   
					  
				<!-- Start of Association Form
				<div id="associationTabId">
				    
				   	<div class="msgBoxContainer"><div class="assocMsgBox"></div></div>
			    	<h1>Association</h1>
					<form action="save_membership" method="post" id="associationForm" class="validateForm" name="associationForm">  
						<input type="hidden" name="type" value="association"></input>
						<input type="hidden" name="id" id="assocId" value=""></input>
						<input type="hidden" name="kol_id" id="kolId" value="<?php echo $arrKol['id']?>"></input>
						
						<table class="analystForm" id="associationTbl">         
							<tr>
								<td>          
								    <p>
							    		<label for="assocName">Name: <span class="required">*</span></label> 
								 		<input type="hidden" name="institute_id" id="assocNameId"></input>
								 		<input type="text" name="name" id="assocName" class="required" value=""></input>
		
							 		</p>
								 		<div id="assocNameNotFound" class="instNotFound">Sorry! The institute name is not found in our database. <a href="#" class="InstitutionProfileLink">Click here</a> to add this institute</div>		
						 		</td>
					 			<td>	
						 			<p>
										<label for="assocEngagement">Engagement Type:</label> 
										<select name="engagement_id" id="assocEngagement"  style="width: 255px;">
											<option value="0">--- Select ---</option>
												<?php 
												foreach($arrEngagementTypes as $key => $value){
												if($key == $arrMembership['engagement_id'])
													echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
												else
													echo '<option value="'.$key.'">'.$value.'</option>';
												}
												?>
										</select>
									</p>
								</td>
							</tr>
							<tr>
								<td>
						 			<p>
						 				<label for="assocDepartment">Dept/Committee:</label> 
						 				<input type="text" name="department" id="assocDepartment" value=""></input>
					 				</p>
						        </td>
						        <td> 
						          	<p>
						          		<label for="assocRole">Title:</label> 
						 				<input type="text" name="role" id="assocRole" value=""></input>
					 				</p>
						 		</td>
					 		</tr>
					 		<tr>
					 			<td>		
						 			<p>
						 				<label for="assocStartDate">Start:</label> 
						 				<input type="text" name="start_date" id="assocStartDate" value="" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear"></input>
					 				</p>
						 		</td>
						 		<td>		
						 			<p>
						 				<label for="assocEndDate">End:</label> 
						 				<input type="text" name="end_date" id="assocEndDate" value="" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear" onmouseout="validate(this.value,'assoc','saveAssociation')"></input>
					 				</p>
					 				<div class="msgBox instNotFound">Invalid Year.End Year Should be Greater than Start Year</div>
						 		</td>
					 		</tr>
							<tr>
								<td>			 			
						 			<p>
						 				<label for="assocUrl1">URL1:</label>
										<input type="text" name="url1" id="assocUrl1" value="" class="url"></input>
									</p>
								</td>
								<td>											   
							   	 	<p>
										<label for="assocUrl2">URL2:</label>
										<input type="text" name="url2" id="assocUrl2" value="" class="url"></input>
									</p>
								</td>
							</tr>
							<tr>
								<td colspan="2">		
							    	<p>
										<label for="assocNotes">Notes:</label>
										<textarea rows="2" cols="30"  name="notes" id="assocNotes" class="analystNotes"></textarea>
									</p>
								</td>
							</tr>
							<tr>
								<td colspan="2">				
						 			<div class="formButtons">	
						 		        <input type="button" value="Add" name="submit" id="saveAssociation">
						 		    </div>
					 		  	</td> 
				 		  	</tr>
			 		  	 </table>
					</form>
	
				Start of JQGrid based Table to list Association Results 
					<div class="gridWrapper" id="associationGridContainer">
						<table id="JQBlistAssociationResultSet"></table>
						<div id="listAssociationPager"></div>
					</div>
					
			 End of Table to Association Results 
					
  				</div> 
 			End of Association Form--> 
  
				
				
				
				<!-- Start of Industry form
				<div id="industryTabId">
					
					<div class="msgBoxContainer"><div class="indMsgBox"></div></div>
					<h1>Industry</h1>
					<form action="save_membership" method="post" id="industryForm" class="validateForm" name="industryForm"> 
						<input type="hidden" name="type" value="industry"></input>
						<input type="hidden" name="id" id="indId" value=""></input>
						<input type="hidden" name="kol_id" id="kolId" value="<?php echo $arrKol['id']?>"></input>
						
						<table class="analystForm" id="industryTbl">		
							<tr>
								<td>	     
									<p>
										<label for="indName">Name: <span class="required">*</span></label> 
										<input type="hidden" name="institute_id" id="indNameId"></input>
										<input type="text" name="name" id="indName" value="" class="required"></input>
									</p>
									 <div id="indNameNotFound" class="instNotFound">Sorry! The institute name is not found in our database. <a href="#" class="InstitutionProfileLink">Click here</a> to add this institute</div>
								</td>
								<td>
									<p>
										<label for="indEngagement">Engagement Type:</label> 
										<select name="engagement_id" id="indEngagement" style="width: 255px;">
											<option value="0">--- Select ---</option>
												<?php 
												foreach($arrEngagementTypes as $key => $value){
												if($key == $arrMembership['engagement_id'])
													echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
												else
													echo '<option value="'.$key.'">'.$value.'</option>';
												}
												?>
										</select>
									</p>
								</td>
							</tr>
							<tr>
								<td>         
									<p>
										<label for="indRole">Title/Role / Purpose:</label> 
										<input type="text" name="role" id="indRole" value=""></input>
									</p>
								</td>		
							 	<td>	
							 		<p>
							 			<label for="indDepartment">Dept/Committee:</label>
								        <input type="text" name="department" id="indDepartment" value="" class=""></input>
									</p>
								 </td>	
							</tr>
							<tr>
								<td>
									<p>
										<label for="indStartDate">Start:</label> 
										<input type="text" name="start_date" id="indStartDate" value="" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear"></input>
									</p>
								</td>	
								<td>
									<p>
										<label for="indEndDate">End:</label> 
										<input type="text" name="end_date" id="indEndDate" value="" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear" onmouseout="validate(this.value,'ind','saveIndustry')"></input>
									</p>  
									<div class="msgBox instNotFound">Invalid Year.End Year Should be Greater than Start Year</div>
								</td> 
							</tr>
							<tr>
								<td> 
									<p>
										<label for="indUrl1">URL1:</label>
										<input type="text" name="url1" id="indUrl1" value="" class="url"></input>
									</p>
								</td>
								<td>													   
									<p>
										<label for="indUrl2">URL2:</label>
										<input type="text" name="url2" id="indUrl2" value="" class="url"></input>
									</p>
								</td>
							</tr>
							<tr>
								<td colspan="2">			
									<p>
										<label for="indNotes">Notes:</label>
										<textarea rows="2" cols="60" name="notes" id="indNotes" class="analystNotes"></textarea>
									</p>
								</td>
								<td>
								</td>
							</tr>
							<tr>
								<td colspan="2"> 
									<div class="formButtons">	
										<input type="button" value="Add" name="submit" id="saveIndustry">
									</div>
								</td>	
								<td>
								</td>
							</tr>
						</table>
					</form>
 
					
					<!-- Start of JQGrid based Table to list industry Results
					<div class="gridWrapper" id="industryGridContainer">
						<table id="JQBlistIndustryResultSet"></table>
						<div id="listIndustryPager"></div>
					</div>
					End of Table industry Agenc
		 		
				</div>		
		               End of industry Agency--> 
				
				
				<!-- Start of  Government Agency form	
				<div id="governmentTabId">
					
					<div class="msgBoxContainer"><div class="govMsgBox"></div></div>
					<h1>Government Agency</h1>
					<form action="save_membership" method="post" id="governmentForm" class="validateForm" name="governmentForm">  
						<input type="hidden" name="type" value="government"></input>
						<input type="hidden" name="id" id="govId" value=""></input>
						<input type="hidden" name="kol_id" id="kolId" value="<?php echo $arrKol['id']?>"></input>
						
						<table class="analystForm" id=governmentTbl">	 
							<tr>
								<td>	     
									<p>
										<label for="govName">Name: <span class="required">*</span></label> 
										<input type="hidden" name="institute_id" id="govNameId"></input>
										<input type="text" name="name" id="govName" value="" class="required"></input>
									</p>
									 <div id="govNameNotFound" class="instNotFound">Sorry! The institute name is not found in our database. <a href="#" class="InstitutionProfileLink">Click here</a> to add this institute</div>
								</td>
								<td>	
									<p>
										<label for="govEngagement">Engagement Type:</label> 
										<select name="engagement_id" id="govEngagement"  style="width: 255px;">
											<option value="0">--- Select ---</option>
												<?php 
												foreach($arrEngagementTypes as $key => $value){
												if($key == $arrMembership['engagement_id'])
													echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
												else
													echo '<option value="'.$key.'">'.$value.'</option>';
												}
												?>
										</select>
									</p>
								</td>
							</tr>
							<tr>
								<td>	
									<p>
										<label for="govDepartment">Dept/Committee:</label> 
										<input type="text" name="department" id="govDepartment" value=""></input>
									</p>
								</td>
								<td>	         
									<p>
										<label for="govRole">Title:</label> 
										<input type="text" name="role" id="govRole" value=""></input>
									</p>
								</td>
							</tr>
							<tr>
								<td>	 
									<p>
										<label for="govStartDate">Start:</label> 
										<input type="text" name="start_date" id="govStartDate" value="" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear"></input>
									</p>
								</td>
								<td>	 
									<p>
										<label for="govEndDate">End:</label> 
										<input type="text" name="end_date" id="govEndDate" value="" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear" onmouseout="validate(this.value,'gov','saveGovernment')"></input>
									</p>  
									<div class="msgBox instNotFound">Invalid Year.End Year Should be Greater than Start Year</div>
								</td>
							</tr>
							<tr>
								<td>	 
									<p>
										<label for="govUrl1">URL1:</label>
										<input type="text" name="url1" id="govUrl1" value="" class="url"></input>
									</p>
								</td>
								<td>														   
									<p>
										<label for="govUrl2">URL2:</label>
										<input type="text" name="url2" id="govUrl2" value="" class="url"></input>
									</p>
								</td>
							</tr>
							<tr>
								<td colspan="2">			
									<p>
										<label for="govNotes">Notes:</label>
										<textarea rows="2" cols="60" name="notes" id="govNotes" class="analystNotes"></textarea>
									</p>
								</td>
							</tr>
							<tr>
								<td colspan="2">	 
									<div class="formButtons">	
										<input type="button" value="Add" name="submit" id="saveGovernment">
									</div>
								</td>
							</tr>	
						</table>
					</form>
 
					
			
					<div class="gridWrapper" id="governmentGridContainer">
						<table id="JQBlistGovernmentResultSet"></table>
						<div id="listGovernmentPager"></div>
					</div>
					
				
				</div>		
                End of Government Agency--> 
 
				
										
				<!-- Start of  Others Form	 	
				<div id="othersTabId">	
					<div class="msgBoxContainer"><div class="othMsgBox"></div></div>
					<h1>Others</h1>
					<form action="save_membership" method="post" id="othersForm" class="validateForm" name="othersForm">  
						<input type="hidden" name="type" value="others"></input>	
						<input type="hidden" name="id" id="othId" value=""></input>
						<input type="hidden" name="kol_id" id="kolId" value="<?php echo $arrKol['id']?>"></input>
						
						<table class="analystForm" id="othersTbl">
							<tr>
								<td>		 		 	
									<p>	
										<label for="othName">Name: <span class="required">*</span></label> 
										<input type="hidden" name="institute_id" id="othNameId"></input>
										<input type="text" name="name" id="othName" value="" class="required"></input>
									</p>
									<div id="othNameNotFound" class="instNotFound">Sorry! The institute name is not found in our database. <a href="#" class="InstitutionProfileLink">Click here</a> to add this institute</div> 				
								</td>
								<td>	
									<p>
										<label for="othEngagement">Engagement Type:</label> 
										<select name="engagement_id" id="othEngagement"  style="width: 255px;">
											<option value="0">--- Select ---</option>
												<?php 
												foreach($arrEngagementTypes as $key => $value){
												if($key == $arrMembership['engagement_id'])
													echo '<option value="'.$key.'" selected="selected">'.$value.'</option>';
												else
													echo '<option value="'.$key.'">'.$value.'</option>';
												}
												?>
										</select>
									</p>
								</td>
							</tr>
							<tr>
								<td>	
									<p>
										<label for="othDepartment">Dept/Committee:</label> 
										<input type="text" name="department" id="othDepartment" value=""></input>
									</p>
								</td>
								<td>	         
									<p>
										<label for="othRole">Title:</label> 
										<input type="text" name="role" id="othRole" value=""></input>
									</p>
								</td>
							</tr>
							<tr>
								<td>	 				
									<p>
										<label for="othStartDate">Start:</label> 
										<input type="text" name="start_date" id="othStartDate" value="" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear"></input>
									</p>
								</td>
								<td>
									<p>
										<label for="othEndDate">End:</label> 
										<input type="text" name="end_date" id="othEndDate" value="" maxlength="4" onkeyup="allowNumericOnly(this)" class="fullYear" onmouseout="validate(this.value,'oth','saveOthers')"></input>
									</p>   
									<div class="msgBox instNotFound">Invalid Year.End Year Should be Greater than Start Year</div>
								</td>
							</tr>
							<tr>
								<td>	
									<p>
										<label for="othUrl1">URL1:</label>
										<input type="text" name="url1" id="othUrl1" value="" class="url"></input>
									</p>
								</td>
								<td>															   
									<p>
										<label for="othUrl2">URL 2:</label>
										<input type="text" name="url2" id="othUrl2" value="" class="url"></input>
									</p>
								</td>
							</tr>
							<tr>
								<td colspan="2">
									<p>
										<label for="othNotes">Notes:</label>
										<textarea rows="2" cols="60" name="notes" id="othNotes" class="analystNotes"></textarea>
									</p>		 						
								</td>	
							</tr>
							<tr>
								<td colspan="2">	 	
									<div class="formButtons">	
										<input type="button" value="Add" name="submit" id="saveOthers">
									</div>	
								</td>
							</tr>
						</table> 
					</form>

					<div class="gridWrapper" id="otherGridContainer">
						<table id="JQBlistOthersResultSet"></table>
						<div id="listOthersPager"></div>
					</div>		
					   	
					   
				</div>
					 End of Others form--> 
		</div>
		<div id="institutionProfile">
			<div id="institutionProfileContainer"></div>
		
		</div>
     
 </div>
<!-- End of Container for the Vertical Tabs -->

	               