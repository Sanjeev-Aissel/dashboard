<link href="<?php echo base_url().ASSETS;?>/c3js/c3.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url().ASSETS;?>/c3js/c3.min.js"></script>
<script src="<?php echo base_url().ASSETS;?>/c3js/d3.c3.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	affiliationEngChart();
});
function affiliationEngChart(){
	var kolName=new Array();
	var data={};
	var kolValues=948;
	kolName.push(kolValues);
	data['kol_id'] 		=kolName;
	data['orgType'] 	='';
	$.ajax({
		type:"post",
		url: base_url+'kols/kols/chart_for_engagement_post/1',
		dataType: 'json',
		data:data,
		success: function(returnData) {
			var totalEvents = 0;
			$.each(returnData,function(key, value){
				totalEvents = totalEvents + value[1];
			});
			getEngagementOptions(returnData,totalEvents);
		},
		complete:function(){
// 			$('#engagementChart').unblock();
		}
	});
}
function getEngagementOptions(returnData,totalEvents){			
	var chart = c3.generate({
    	bindto: '#engagementChart',
	    data: {
	        // iris data from R
	        columns: returnData,
	        type : 'pie',
	        onclick: function (value, ratio, id) { 
	        	showOrganizationChart(value.name);
            }
	    },	    
	    size: {
	    	  width: 400
	    },
	    color: {
	    	  pattern: chartColors
    	},
	    legend: {
      	  position: 'right'
	    },
	    pie: {
	        label: {
	            format: function (value, ratio, id) {
	                return d3.format(".0%")(ratio);
	            }
	        }
	    },
	    tooltip: {
	        format: {	            
	            value: function (value, ratio, id) {           
	            	return value+' ('+d3.format('.0%')(ratio)+')';
	            }	            
	        }
	    },
	    legend: {
	        show: false
	    }
	});
    var data=new Array();
	$.each(returnData, function(i, item) {
	   data.push(item[0]);
	});
    d3.select('#engagementChart').insert('div', '.chart').attr('class', 'legend').selectAll('h5')
    .data(data)
    .enter().append('h5')
    .attr('data-id', function (id) { return id; })
    .html(function (id) { return id; })
    .each(function (id) {
        d3.select(this).style('background-color', chart.color(id));
    })
    .on('mouseover', function (id) {
        chart.focus(id);
    })
    .on('mouseout', function (id) {
        chart.revert();
    })
    .on('click', function (id) {
        chart.toggle(id);
    });
}
function showOrganizationChart(engType){
	var data={};
	var kolName=new Array();;
	var kolValues=948;
	kolName.push(kolValues);
	data['kol_id'] 		=kolName;
	data['engType']	= engType;
	$.ajax({
		type:"post",
		url: base_url+'kols/kols/chart_for_organization_post/1',
		dataType: 'json',
		data:data,
		success: function(returnData) {
				var totalAffiliations = 0;
				$.each(returnData,function(key, value){
				totalAffiliations = totalAffiliations + value[1];
			});
		getAffiliationsByOrgTypeOptions(returnData,totalAffiliations);
		}
	});
}
function getAffiliationsByOrgTypeOptions(returnData,totalAffiliations){			
	var chart = c3.generate({
    	bindto: '#affiliationsChartByOrgType',
	    data: {
	        // iris data from R
	        columns: returnData,
	        type : 'pie'	       
	    },	    
	    size: {
	    	  width: 400
	    },
	    color: {
	    	  pattern: chartColors
    	},
	    legend: {
      	  position: 'right'
	    },
	    pie: {
	        label: {
	            format: function (value, ratio, id) {
	                return d3.format(".0%")(ratio);
	            	//return value+'-'+d3.format('%')(ratio)
	            }
	        }
	    },
	    tooltip: {
	        format: {	            
	            value: function (value, ratio, id) {           
	            	return value+' ('+d3.format('.0%')(ratio)+')';
	            }	            
	        }
	    },
	    legend: {
	        show: false
	    }
	});
    var data=new Array();
	$.each(returnData, function(i, item) {
	   data.push(item[0]);
	});
    d3.select('#affiliationsChartByOrgType').insert('div', '.chart').attr('class', 'legend').selectAll('h5')
    .data(data)
    .enter().append('h5')
    .attr('data-id', function (id) { return id; })
    .html(function (id) { return id; })
    .each(function (id) {
        d3.select(this).style('background-color', chart.color(id));
    })
    .on('mouseover', function (id) {
        chart.focus(id);
    })
    .on('mouseout', function (id) {
        chart.revert();
    })
    .on('click', function (id) {
        chart.toggle(id);
    });
}
</script>
<div class="pubChartContainer">
	<table class="table">
		<tr class="tableHeader">
			<th width="50%">Affiliations By Engagement Type</th>
			<th width="50%">Affiliations By Organization Type</th>
		</tr>
		<tr>
			<td class="firstColumn">
				<div class="pieCharts">
					<div id="engagementChart"></div>
				</div>
			</td>
			<td class="secondColumn">
				<div class="pieCharts">
					<div id="affiliationsChartByOrgType"><div class="chartHighlightText">Click on Engagement Type</div></div>
				</div>
			</td>
		</tr>
	</table>
</div>