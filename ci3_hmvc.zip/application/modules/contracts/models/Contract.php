<?php
class Contract extends CI_Model {
	function listContracts($kolId='',$contractType,$limit=0){
		$clientId = $this->session->userdata('client_id');
		$userId = $this->session->userdata('user_id');
		$userRoleId = $this->session->userdata('user_role_id');
		if ($clientId != INTERNAL_CLIENT_ID) {
			$this->db->where("contracts.client_id",$clientId);
		}
		$this->db->select('contracts.*,client_users.client_id,CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name',false);
		$this->db->join('client_users', 'client_users.id = contracts.created_by', 'left');
		if(ORGS_CONTRACT){
			if($contractType=='kol'){
				if($clientId != INTERNAL_CLIENT_ID){
					$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = contracts.kol_id', 'left');
					$this->db->where('kols_client_visibility.client_id', $clientId);
				}
			}
			if($contractType=='track'){
				$this->db->join('organizations', 'contracts.org_id = organizations.id ', 'left');
				$this->db->join('kols', 'kols.id = contracts.kol_id', 'left');
				if($clientId != INTERNAL_CLIENT_ID){
					if(is_numeric($kolId)==''){
						if($this->session->userdata('user_role_id')==ROLE_MANAGER || $this->session->userdata('user_role_id')==ROLE_USER){
							$group_names = "'".str_replace(',',"','", $this->session->userdata('group_names'))."'";
							$this->db->join ( 'countries', 'countries.CountryId = kols.country_id', 'left' );
							$this->db->join ( 'countries as org_country', 'org_country.CountryId = organizations.country_id', 'left' );
							$this->db->where("(countries.GlobalRegion in (".$group_names.") or contracts.org_id > 0)" ,'',false);
							$this->db->where("(org_country.GlobalRegion in (".$group_names.") or contracts.kol_id > 0)" ,'',false);
						}
					}
				}
				if($clientId !== INTERNAL_CLIENT_ID){
					$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = contracts.kol_id', 'left');
					$this->db->where("((contracts.kol_id != 0 AND kols_client_visibility.client_id = '".$clientId."') OR contracts.org_id != 0)",'',false);
				}else{
					$this->db->where("(contracts.kol_id != 0 OR contracts.org_id != 0)",'',false);
				}
			}
		}else{
			if($clientId != INTERNAL_CLIENT_ID){
				$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = contracts.kol_id', 'left');
				$this->db->where('kols_client_visibility.client_id', $clientId);
				if(is_numeric($kolId)==''){
					if($this->session->userdata('user_role_id')==ROLE_MANAGER || $this->session->userdata('user_role_id')==ROLE_USER){
						$group_names = explode(',', $this->session->userdata('group_names'));
						$this->db->join('kols', 'kols.id = contracts.kol_id', 'left');
						$this->db->join ( 'countries', 'countries.CountryId = kols.country_id', 'left' );
						$this->db->where_in ( 'countries.GlobalRegion', $group_names);
					}
				}
			}
		}
		$this->db->order_by('contracts.end_date','desc');
		if($limit>0){
			$this->db->limit($limit);
		}
		if(ORGS_CONTRACT){
			if(is_numeric($kolId)!=''){
				if($contractType=='kol'){
					$this->db->where('contracts.kol_id',$kolId);
				}else{
					$this->db->where('contracts.org_id',$kolId);
				}
			}
		}else{
			if(is_numeric($kolId)!=''){
				$this->db->where('contracts.kol_id',$kolId);
			}else{
				$this->db->where("contracts.kol_id !=",0);
			}
		}
		$arrResultSet = $this->db->get('contracts');
		foreach($arrResultSet->result_array() as $row){
			$arrContracts[]=$row;
		}
		return $arrContracts;
	}
	function deteleteContract($contractId){
		$this->db->where('id',$contractId);
		if($this->db->delete('contracts')){
			return true;
		}else{
			return false;
		}
	}
	function getContractDetailsById($contractId){
		$this->db->where('id',$contractId);
		$arrContractsResult = $this->db->get('contracts');
		$arrContracts = array();
		foreach($arrContractsResult->result_array() as $row){
			$arrContracts=$row;
		}
		return $arrContracts;
	}
	function getAllKolsName1(){
		$clientId = $this->session->userdata('client_id');
		$arrkols=array();
		$this->db->select('kols_client_visibility.id,kols.first_name,kols.middle_name,kols.last_name');
		$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
		//$status = COMPLETED;
		$this->db->where('kols_client_visibility.client_id',$clientId);
		$arrResult = $this->db->get('kols');
		foreach($arrResult->result_array() as $row){
			if($row['middle_name']!=''){
				//			$arrkols[$row['id']] = $row[FIRST_ORDER]." ".$row[SECOND_ORDER]." ".$row[THIRD_ORDER];
				$arrkols[$row['id']] = nf($row['first_name'],$row['middle_name'],$row['last_name']);
			}else{
				//				$arrkols[$row['id']] = $row[FIRST_ORDER]." ".$row[SECOND_ORDER];
				$arrkols[$row['id']] = nf($row['first_name'],$row['middle_name'],$row['last_name']);
			}
		}
		return $arrkols;
	}
	function getAllOrgName1(){
		$arrkols=array();
		$this->db->select('id,name');
		//$status = COMPLETED;
		// $this->db->where('status',"$status");
		$arrResult = $this->db->get('organizations');
		foreach($arrResult->result_array() as $row){
			$arrkols[$row['id']] = nf($row['name']);
		}
		return $arrkols;
	}
	function saveContract($arrContracts){
// 		pr($arrContracts);exit;
		$userId = $this->session->userdata('user_id');
		$clientId = $this->session->userdata('client_id');
		$userId = $this->session->userdata('user_id');
		$dataType = 'User Added';
		if($clientId == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		$date = date("Y-m-d H:i:s");
		$arrContracts['org_id']  = ($arrContracts['org_id']=='')?0:$arrContracts['org_id'];
		$arrContracts['client_id']  = $clientId;
		$arrContracts['created_by']  = $userId;
		$arrContracts['created_on']  = $date;
		$arrContracts['modified_by']  = $userId;
		$arrContracts['modified_on']  = $date;
		$arrContracts['data_type_indicator']  = $dataType;
		if($this->db->insert('contracts',$arrContracts)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	function getAssignedUsersForType($id, $type){
		$client_id = $this->session->userdata('client_id');
		$arrUsersDetails = array();
		if($type == 'Kol'){
			$this->db->select("user_kols.user_id, client_users.email");
			$this->db->select("CONCAT(kols.last_name, '\, ', kols.first_name,' ', kols.middle_name) AS typename", FALSE);
			$this->db->join('client_users', 'client_users.id = user_kols.user_id', 'left');
			$this->db->join('kols', 'kols.id = user_kols.kol_id', 'left');
			$this->db->where('user_kols.kol_id', $id);
			if($client_id !== INTERNAL_CLIENT_ID){
				$this->db->where('client_users.client_id', $client_id);
			}
			$query = $this->db->get('user_kols');
		}else{
			$this->db->select("user_orgs.user_id, client_users.email");
			$this->db->select("organizations.name as typename");
			$this->db->join('client_users', 'client_users.id = user_orgs.user_id', 'left');
			$this->db->join('organizations', 'organizations.id = user_orgs.org_id', 'left');
			$this->db->where('user_orgs.org_id', $id);
			if($client_id !== INTERNAL_CLIENT_ID){
				$this->db->where('client_users.client_id', $client_id);
			}
			$query = $this->db->get('user_orgs');
		}
		$result = $query->result();
		foreach($result as $row){
			$typeName = $row->typename;
			$userEmails[] =  $row->email;
		}
		$arrUsersDetails['type_name'] = $typeName;
		$arrUsersDetails['user_details'] = $userEmails;
		return $arrUsersDetails;
	}
	function updateContract($arrContract){
		$userId = $this->session->userdata('user_id');
		$date = date("Y-m-d H:i:s");
		$arrContracts['modified_by']  = $userId;
		$arrContracts['modified_on']  = $date;
		$this->db->where('id',$arrContract['id']);
		if($this->db->update('contracts',$arrContract)){
			return true;
		}else{
			return false;
		}
	}
}
?>