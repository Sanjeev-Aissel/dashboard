<?php
/**
 * File to 'view' Organization details
 *
 * @author: Ambarish
 * @created on: 22-12-10
 */
?>
<script type="text/javascript">
<!--

//-->
var isOptIn = <?php echo KOL_CONSENT;?>;
</script>
<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array(	'organizations/view_organization',
								'chosen.jquery',
								'i18n/grid.locale-en',
								'jquery.jqGrid.min',
								'jquery/jquery.validate1.9.min'
							 );
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet">
<!-- JQGrid Plugins -->
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
	<!--<script src="<?php echo base_url()?>js/i18n/grid.locale-en.js" type="text/javascript"></script>	
	<script src="<?php echo base_url()?>js/jquery.jqGrid.min.js" type="text/javascript"></script>
	
	-->
<style type="text/css">
		.title{
			font-size: 13px;
			font-weight: bold;
			text-transform: uppercase;
		}
		.gridWrapper{
			width:100%;
		}
		div.toggleBtnWrapper{
			text-align:right;	
		}
		.analystForm label {
			float: none;
		}
		
		#addressInfo{
			text-align:left;
		}
		
		#addressInfo{
			border:1px solid #ccc;
			width:33%;
			padding:6px;
			margin:0px 10px 10px 0;
		/*	background-image: url("../../images/blue_grandience_bg.png");
			background-repeat: repeat-x;
		*/
		}
		
		#addressBio{
			text-align:left;
		}

		#addressInfo .orgName{
			color:#333333;
			font-size:15px;
			font-weight:bold;
		}
		
		#addressInfo .speciality{
			font-size: 10pt;
		}
		
		#addressInfo p{
			padding:0;
			margin:0;
			color:#333333;
		}
		
		#addressInfo p.addrHeading{
			text-transform: uppercase;
			font-weight: bold;
			margin-top:12px;
			color:#333333;
		}
				
		#companyDetails{
			border:0px solid red;
			height:auto;
			text-align: justify;
		}
		
		#companyDetails h1,.note h1{
			text-transform: uppercase;
			font-weight: bold;
			font-size: 13px;
			border-bottom:1px solid black;
			padding-bottom:5px;
		}
	
		
		#addressInfo p{
			padding:0;
			margin:0;
			letter-spacing: 1px;
		}
		
		#mediaLinks a, #about a{
			text-decoration:none;
			text-align:left;
			color: #000099;
		}
		#mediaLinks a p{
			text-decoration:none;
			text-align:left;
			color: #000099;
			width: 780px;
			word-wrap: break-word;
		}
		#about a{
			text-decoration: underline;
		}
		#companybackground{
			margin-left: 410px;
			border: 1px solid #cccccc;
		    border-radius: 3px;
		    margin-bottom: 10px;
		    padding: 10px 10px 0;
		}
		
		#medicalService{
		 margin-bottom: 13px;
		}
		.listResultSet td{
			text-align: center;
		}
		.note h1{
			text-transform: uppercase;
			font-weight: bold;
			font-size: 13px;
			border-bottom:1px solid black;
			padding-bottom:5px;
		}
		
		.align{
			text-align:right;
		}
		
		.profileData{
			float: left;
		/*	width:801px;*/
			margin-bottom: 13px;
		}
		
		.action{
			position: absolute;
			right: 0px;
			top:5px;
		}
		
		.profileData p{
			margin:0;	
			font-weight:bold;
		}
		.notes p{
			padding-top:19px;
		}
		
		.action:hover .edit{
		display:block;
		}
		
/*		.profileData p:hover{
			background-color: #F1F1F1;
		}
	*/	
		.profileContainer{
			position:relative;		
		}
		
/*		.line{
		border-bottom: 1px solid gray;
		padding-bottom: 5px;
		margin-top:10px;
		margin-bottom:10px
		}
	*/	
		.notes:hover{
			cursor:pointer;
		}
		
		.updateButton{
/*		left: 660px;
		position: relative;*/
			float: right;
		}
		.borderBottom{
			border:1px solid #fff;
			border-bottom: 1px solid #DDDDDD;
			padding: 5px;
			padding-bottom: 12px;
			margin-bottom: 12px;
			padding-top: 0px;
			padding-left: 0px;
			float: left;
			width: 99%;
		}
		
		
		span.timestamp{
			display: block;
			font-weight: normal;
			font-size: 11px;
		}
		.borderMe{
			border: 1px solid #bbb;
		}
		.profileData{
		    border: 1px solid #fff;
		    border-top:0px;
		    border-left:0px;
		    padding: 5px;
		}
		.textAreaContainer{
		   padding: 5px;
		}
		.borderMe .profileData{
		    border-top:0px;
		    border-left:0px;
		    display: inline;
		}
		.align_left{
			text-align: left !important;
		}
		table tr .error{
			padding: 0px !important;
		}
		.formHeader{
			text-align: center;
		}
		.formHeader label{
			color: #111138 !important;
		}
		#searchResultsContainer table td, #searchResultsContainer table th, table.listResultSet th, table.listResultSet td{
			padding: 4px 2px 4px 3px;
		}
		#searchResultsContainer table th, table.listResultSet th{
			color: #111111;
			font-size: 11px;
			letter-spacing: 0.4px; 
		}
		#factsData tr th{
			line-height: 12px !important;
		}
		odd{
			background-color: #EEEEEE;
		}
		even{
			background-color: white;
		}
		.listResultSet tr:HOVER {
			background-color: #D0E5F5 !important;
		}
		.payer{
			 border-bottom: 0px  !important;
			 padding-bottom: 0px !important;	
		}
		
		#factsData,#enrollmentTable,#formularyTable,#diseaseManagement,#collaborationRating,#facts{
		 	border-top:1px solid black;
		}
		
		#location{
			margin-top: 13px;
		}
		.addLink{
			float: right;
		}
		.editTextarea {
		    margin-left: 0 !important;
		    margin-top: 0 !important;
		    width: 94% !important;
		}
		div.saveIcon {
		    background: rgba(0, 0, 0, 0) url("<?php echo base_url();?>images/save_active.png") no-repeat scroll 0 0 / 20px auto;
		}
		div.saveIcon:HOVER{
			/*background: url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat scroll -220px -30px transparent;*/
			background: url("<?php echo base_url();?>images/save_inactive.png") no-repeat scroll 0px 0px / 20px auto;
			
		}
		div.cancelIcon {
		    background: rgba(0, 0, 0, 0) url("<?php echo base_url();?>images/delete_active.png") no-repeat scroll 0 0 / 20px auto;
		    margin-left: 5px;
		}
		div.cancelIcon:HOVER{
			background: url("<?php echo base_url();?>images/delete_inactive.png") no-repeat scroll 0px 0px / 20px auto;
		}
		.show_more {
		    height: 25px;
		    line-height: 25px;
		    text-align: center;
		}
		.show_more:HOVER {
		    background: #d3dfed;
		}
		.show_more a {
		    color: blue !important;
		    display: block;
		    width: 100%;
		    text-decoration: underline !important;
		}
		#user-notes h4 {           
            font-size: 100%;
            font-weight: bold;
            margin-top: 20px;
            margin-right: 5px;
            padding: 6px;
            background: #ececec none repeat scroll 0 0;            
            box-shadow: 0 0 4px #d1d1d1 inset;
            color: #111111;
        }
        .dataTypeIndicator a{
            margin-left: 4px;
        }
        #allInteractionGridContainer .dataTypeIndicator a{
            margin-left: 0px !important;
        }
	</style>
	<script type="text/javascript">
	var sessionUserRoleId = '<?php echo $this->session->userdata('user_role_id');?>';
	var contantUserRoleId = '<?php echo ROLE_READONLY_USER;?>';
	var product ="<?php echo lang('Overview.Product')?>";
	var orgId = '<?php echo $arrOrganization['id'];?>';
	var subContentPage	= '<?php echo $subContentPage;?>';
	<?php $userId = $this->session->userdata('user_id');?> 
	<?php $clientId = $this->session->userdata('client_id');?> 
	
	<?php $userRoleId = $this->session->userdata('user_role_id');?>
	<?php if($arrOrganization['type_id']!=PAYOR){?>
	var modalHeight = 430;  
	<?php }else{?>
	var modalHeight = 510;
	<?php }?>
	$(document).ready(function() {
		$('.listResultSet tr:even').css('background-color','#EEEEEE');
		 var addEnrollOrgPayers = {
				 title: "Add Organizations Payer",
				 modal: true,
				 autoOpen: false,
				 width: 415,
				 draggable:false,
				 dialogClass: "microView",
				 open: function() {
				 //display correct dialog content
			 }
		 };
			 $("#addEnrollOrgPayers").dialog(addEnrollOrgPayers);
		 var addFormularyOrgPayers = {
				 title: "Add Organizations Payer",
				 modal: true,
				 autoOpen: false,
				 width: 393,
				 draggable:false,
				 dialogClass: "microView",
				 open: function() {
				 //display correct dialog content
			 }
		 };
			 $("#addFormularyOrgPayers").dialog(addFormularyOrgPayers);

		 var addDmOrgPayers = {
				 title: "Add Organizations Payer",
				 modal: true,
				 autoOpen: false,
				 width: 484,
				 height: 'auto',
				 draggable:false,
				 dialogClass: "microView",
				 open: function() {
				 //display correct dialog content
			 }
		 };
			 $("#addDmOrgPayers").dialog(addDmOrgPayers);

		 var addCollabRatingOrgPayers = {
				 title: "Add Organizations Payer",
				 modal: true,
				 autoOpen: false,
				 width: 500,
				 height: 'auto',
				 draggable:false,
				 dialogClass: "microView",
				 open: function() {
				 //display correct dialog content
			 }
		 };
			 $("#addCollabRatingOrgPayers").dialog(addCollabRatingOrgPayers);
			 
		 var editBasicInfo = {
				 title: "Edit Organizations Profile",
				 modal: true,
				 autoOpen: false,
				 width: 1000,
				 height: 700,
				 draggable:false,
				 dialogClass: "microView",
				 open: function() {
				 //display correct dialog content
			 }
		 };
			 $("#editBasicInfo").dialog(editBasicInfo);

//			 var editAffPart = {
//					 title: "Edit Affiliates and Partners",
//					 modal: true,
//					 autoOpen: false,
//					 width: 700,
//					 height: 500,
//					 draggable:false,
//					 dialogClass: "microView",
//					 open: function() {
//					 //display correct dialog content
//				 }
//					};
//			$("#editAffiliatesAndPartners").dialog(editAffPart);
			
//			 var editOrgFacts = {
//					 title: "Edit Affiliates and Partners",
//					 modal: true,
//					 autoOpen: false,
//					 width: 700,
//					 height: 500,
//					 draggable:false,
//					 dialogClass: "microView",
//					 open: function() {
//					 //display correct dialog content
//				 }
//					};
//			$("#editAffPart").dialog(editOrgFacts);
			 var editOrgFacts = {
					 title: "Edit Affiliates and Partners",
					 modal: true,
					 autoOpen: false,
					 width: 550,
					 height: modalHeight,
					 draggable:false,
					 dialogClass: "microView",
					 open: function() {
					 //display correct dialog content
				 }
					};
			$("#editOrgFacts").dialog(editOrgFacts);
		});
	
		function addOrgPayersData(orgPayerType){
			switch (orgPayerType) {
				case 'enrollment':	
					$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
					$('#addEnrollOrgPayers').dialog("open");
					$('#orgPayerContainer1').load(base_url+'organizations/add_enrollment/'+orgId);
					break;
				case 'formulary':
					$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
					$('#addFormularyOrgPayers').dialog("open");
					$('#orgPayerContainer2').load(base_url+'organizations/add_formulary/'+orgId);	
					break;
				case 'disease_management':
					$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
					$('#addDmOrgPayers').dialog("open");
					$('#orgPayerContainer3').load(base_url+'organizations/add_disease_management/'+orgId);
					break;
				case 'collaboration_rating':
					$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
					$('#addCollabRatingOrgPayers').dialog("open");
					$('#orgPayerContainer4').load(base_url+'organizations/add_collaboration_rating/'+orgId);
					break;
				default: break;
			}
			return false;
		}
		
		function editOrgPayersData(orgPayerType,id){
			switch (orgPayerType) {
				case 'enrollment':	
					$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
					$('#addEnrollOrgPayers').dialog("open");
					$('#orgPayerContainer1').load(base_url+'organizations/edit_enrollment/'+orgId+'/'+id);
					break;
				case 'formulary':
					$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
					$('#addFormularyOrgPayers').dialog("open");
					$('#orgPayerContainer2').load(base_url+'organizations/edit_formulary/'+orgId+'/'+id);
					break;
				case 'disease_management':
					$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
					$('#addDmOrgPayers').dialog("open");
					$('#orgPayerContainer3').load(base_url+'organizations/edit_disease_management/'+orgId+'/'+id);
					break;
				case 'collaboration_rating':
					$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
					$('#addCollabRatingOrgPayers').dialog("open");
					$('#orgPayerContainer4').load(base_url+'organizations/edit_collaboration_rating/'+orgId);
					break;		
				default: break;
			}
			$('html, body').animate({
				//scrollTop: $(".ui-widget-content").offset().top
			});
			return false;
		}

		function deleteOrgPayesData(orgPayerType,id){
			switch (orgPayerType) {
			case 'enrollment':
				jConfirm("Are sure want to delete?", 'Please Confirm',function(r){
					if(r){
						$.ajax({
							url:base_url+'organizations/delete_enroll_detail/'+id,
							dataType: 'json',
							success: function(returnData){
								if(returnData.status == "true"){
									$('#enrollmentTable tr#'+id).remove();
									tableRow();
								}else{
									jAlert("Error in deleting");
									}
						}
						});
					}
			});
						
			break;
			case 'formulary':
				jConfirm("Are sure want to delete?", 'Please Confirm',function(r){
					if(r){
					$.ajax({
						url:base_url+'organizations/delete_formulary_detail/'+id,
						dataType: 'json',
						success: function(returnData){
							if(returnData.status == "true"){
								$('#formularyTable tr#'+id).remove();
								tableRow();
							}else{
								jAlert("Error in deleting");
								}
					}
					});
				}
				});	
				break;
			case 'disease_management':
				jConfirm("Are sure want to delete?", 'Please Confirm',function(r){
					if(r){
					$.ajax({
						url:base_url+'organizations/delete_disease_management_detail/'+id,
						dataType: 'json',
						success: function(returnData){
							if(returnData.status == "true"){
								$('#diseaseManagement tr#'+id).remove();
								tableRow();
							}else{
								jAlert("Error in deleting");
								}
					}
					});
				}	
				});
				break;		
			default:
				;
			break;
		}
		}
	 function tableRow() {
		 $('.listResultSet tr').css('background-color','white');
		 $('.listResultSet tr').each(function(){
			    if ($(this).index()%2<1)
			        $(this).css('background-color','#EEEEEE');
			});
		 }

	function editBasicInfo(id){
			$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
			$('#editBasicInfo').dialog("open");
			$('#edit1').load(base_url+'organizations/edit_basic_info/'+orgId);
		}

	function editFacts(){
			$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
			$('#editOrgFacts').dialog("open");
			$("#editOrgFacts1").load(base_url+'organizations/edit_facts/'+orgId);
		}
	function addFacts(){
			$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
			$('#editOrgFacts').dialog("open");
			$("#editOrgFacts1").load(base_url+'organizations/add_facts/'+orgId);
		}	
	function editPayerFacts(){
			$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
			$('#editOrgFacts').dialog("open");
			$("#editOrgFacts1").load(base_url+'organizations/edit_payer_facts/'+orgId);
		}
	function addPayerFacts(){
			$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
			$('#editOrgFacts').dialog("open");
			$("#editOrgFacts1").load(base_url+'organizations/add_payer_facts/'+orgId);
		}
	function editAffAndPartners(){
			$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
			$('#editAffiliatesAndPartners').dialog("open");
			$("#editAffAndPartners").load(base_url+'organizations/edit_affiliations_and_partners/'+orgId);
		}
	function editAffPartners(){
		window.location.href = '<?php echo base_url()?>organizations/view_sub_organizations/<?php echo $arrOrganization['id']?>/all';
		}

	function addNewKolProfile(KolId,thisEle){
		/*$(".newProfileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#newKolProfile").dialog("open");
		$(".newProfileContent").load(base_url+'requested_kols/add_client_pre_kol/'+KolId);
		*/
		jConfirm(profileRequestConfirmMessage,"Confirm message",function (r){
			if(r){
				requestProfile(KolId,thisEle);
				return false;
			}else{
				return false;
			}
		});
	}

	function requestProfile(KolId,thisEle){
		var userRoleId = <?php echo $this->session->userdata('user_role_id')?>;
		if(userRoleId == ROLE_MANAGER || userRoleId == ROLE_ADMIN){
			jAlert("The Profile has been requested for processing. You will get a notification once the requests are processed.");
		}else{
			jAlert("Your <?php echo lang("KOL");?>  Profile request has been submitted to your manager for approval. We will notify you when your request is approved");
		}
		$.ajax({
			url:'<?php echo base_url()?>requested_kols/request_kol_profile/'+KolId,
			type:'post',
			dataType:'json',
			success:function(returnData){
				if(returnData.saved==true){
// 					$(thisEle).remove();
					$('.requestKolId'+KolId).attr('onclick','').unbind('click');
					$('.requestKolId'+KolId).removeAttr('data-original-title');
					$('.requestKolId'+KolId).css('pointer-events','none');
					$('.requestKolId'+KolId).css('cursor','default');
					$('.requestKolId'+KolId).css('text-decoration','none');
					$('.requestKolId'+KolId).css('background','#bbbbbb none repeat scroll 0 0');
					$('.requestKolId'+KolId).css('border','1px solid #bbbbbb');
					$('.requestKolId'+KolId).text('Requested');
					
				}else{
					jAlert("Unable to send request for profiling.");
				}
			}
		});
	}
	</script>
		<?php 
			$clientId = $this->session->userdata("client_id");
		?>
		<div id="orgOverviewTernaryNav" class="span-20 last">
			<!--<ul class="span-3 append-1 ternaryNav" >
				<?php $this->load->view('elements/organization_short_details_client_view');?>
				<li><a href="#about">About</a></li>                  
				<li><a href="#keyPeople">Key People</a></li>                  
				<li><a href="#orgSocialMedia">Social Media</a></li>
			</ul>	
			-->
			<?php 
				switch($subContentPage){
						
					
					
					case 'medical_services':
			?>
								<div id="medicalService">
									<!-- Start of JQGrid based Table to list Key People Results -->
									<div class="gridWrapper" id="medicalContainer">
										<table id="medicalResultSet"></table>
										<div id="medicalPage"></div>
									</div>
								</div>
								<!-- End of keyPeople Div -->
			<?php 
							break;
							
						case 'key_people':
			?>
								
								<!-- End of keyPeople Div -->
			<?php 
							break;
						case 'associated_people':
			?>
			
			<?php 
							break;
						case 'details': $this->load->view("organizations/view_org_details");
			?>
								
			<?php 
							break;
						case 'social_media': $this->load->view("organizations/social_media");
							break;
						default:
			?><?php //pr($arrOrganization);?>
								<!-- div class="tooltip-demo tooltop-bottom" style="float: right; display: inline; position: relative;">
									<a style="text-decoration: none;color: white;padding: 1px 3px!important;" rel="tooltip"  href="<?php echo base_url()?>organizations/view_interactions/<?php echo $arrOrganization['id']; ?>" class="blueButton" data-original-title="Interactions">Interactions</a>
								</div-->
								<?php if($clientId == INTERNAL_CLIENT_ID){?>
									<!-- <div class="addLink">
										<label class="link"  onclick="editBasicInfo(<?php echo $arrOrganization['id']?>); return false;"><div class="actionIcon editIcon"></div>Edit Basic Info</label>
									</div> -->
<!--									<div style="float: right;" onclick="editBasicInfo(<?php echo $arrOrganization['id']?>); return false;" class="actionIcon editIcon tooltip-demo tooltop-top">-->
<!--										<a rel="tooltip" class="tooltipLink" href="#" data-original-title="Edit"></a>-->
<!--									</div>-->
									<?php }?>
								<div id="about" class="clear">
									<div id="addressInfo" class="span-6">
											<?php if($this->common_helpers->isActionAllowed('org','edit',array('org_id' => $arrOrganization['id'],'created_by' => $arrOrganization['created_by']))){ ?>
													<div class="tooltip-demo tooltop-bottom" style="float: right;">
						                            	<a class="blueButton" style="text-decoration: none;"  href="<?php echo base_url();?>organizations/add_org/<?php echo $arrOrganization['id'];?>" class="tooltipLink" rel="tooltip" data-original-title="Edit Organization">Edit Organization</a>
						                            </div>
											<?php }?>
											<p class="orgName"><?php echo $arrOrganization['name']; ?></p>
											<?php /*?><p class="addrHeading"><?php echo lang("Mykols.NPINUMBER");?></p>
											<?php echo $arrOrganization['npi_num'];?><?php */?>
											<p class="addrHeading"><?php echo lang("Overview.Address");?></p>
																	
												<?php 
													if($arrOrganization['address'] != '')
														echo "<p>".$arrOrganization['address'].",</p>";
												?><p><?php 		
															if(!empty($arrOrganization['city_name']))
																echo $arrOrganization['city_name'] . ", ";
															if($arrOrganization['country_name']=='United States')
																	echo $arrOrganization['state_code'][0]['state_code']. " ". $arrOrganization['postal_code'];
																else if($arrOrganization['state_name']!='' && $arrOrganization['postal_code']!='')
																	echo $arrOrganization['state_name']. " ". $arrOrganization['postal_code'];
																else
																	echo $arrOrganization['state_name'];
												?></p><?php
															if(!empty($arrOrganization['country_name']))
																echo "<p>".$arrOrganization['country_name']."</p>";
												?>
											
											<?php 
												if(!empty($arrOrganization['phone']) && sizeof($arrOrganization['phone'])>10){
													$arrOrganization['phone']	= (($arrOrganization['phone'][0]=="+")?'':'+').$arrOrganization['phone'];
												}
												if(!empty($arrOrganization['fax']) && sizeof($arrOrganization['fax'])>10){
													$arrOrganization['fax']		= (($arrOrganization['fax'][0]=="+")?'':'+').$arrOrganization['fax'];
												}
											?>
											<p class="addrHeading"><?php echo lang("Overview.Phone");?></p>
											<?php if (strcmp($arrOrganization['phone'],"0")) { ?>
											<?php  echo '<a class="linkClickToCall" href="callto:'.$arrOrganization['phone'].'" >'.$arrOrganization['phone'].'</a>'; } ?>
										
											<p class="addrHeading"><?php echo lang("Overview.Fax");?></p>
											<?php if (strcmp($arrOrganization['fax'],"0")) { ?>
											<?php echo '<a class="linkClickToCall" href="callto:'.$arrOrganization['fax'].'" >'.$arrOrganization['fax'].'</a>'; } ?>
											<p class="addrHeading">Email</p>
											<?php if (strcmp($arrOrganization['email'],"0")) { ?>
											<?php echo '<a class="linkClickToCall" href="mailto:'.$arrOrganization['email'].'" >'.$arrOrganization['email'].'</a>'; } ?>
					<?php /*?>
											<p class="addrHeading"><?php echo lang("Overview.CompanyHQ");?></p>
											<?php echo $arrOrganization['headquarters'];?>
											<?php if($arrOrganization['type_id']==PAYOR){?>
												<p class="addrHeading"><?php echo lang("Overview.KeyRegionalOffices");?></p>
												<p><?php echo $arrOrganization['key_reginal_offices'];?></p>
											<?php }?>
											<p class="addrHeading"><?php echo lang("Overview.Website");?></p>
<?php if (strcmp($arrOrganization['website'],"0")) { ?>
											<a class="webURL" href="<?php echo $arrOrganization['website'];?>" target="_new"><?php echo $arrOrganization['website']; } ?></a>
					
											<p class="addrHeading"><?php echo lang("Overview.Founded");?></p>
											<?php echo $arrOrganization['founded'];?><?php */?>
									</div>
										
								
									<div id="companyDetails">
									<?php //if($arrOrganization['profile_type'] != BASIC){?>	
										<div id="companybackground">
										<h1><?php echo lang("Organizations.CompanyBackground");?></h1>
										
										<p>
											<?php echo $arrOrganization['background'];?>
										</p>
										</div>
										<!--<h1 class="clear"><?php echo lang("Organizations.MissionVisionValues");?></h1>
										<p>
											<?php echo $arrOrganization['mission_vision'];?>
										</p>
										
										<?php if($arrOrganization['type_id']!=PAYOR){?>
										
											<h1 class="clear"><?php echo lang("Organizations.MEDICALSERVICES");?></h1>
											<?php if(!empty($medicalDetails)){?>
												<p>
													<?php echo $medicalDetails; ?>
												</p>
										<?php }}?>
										
										<?php if($arrOrganization['type_id']==PAYOR){?>
											<h1 class="clear"><?php echo lang("Organizations.KEYPRODUCTS");?></h1>
											<p>
												<?php echo $arrOrganization['key_products']; ?>
											</p>
										<?php }?>
										<?php if($arrOrganization['type_id']==PAYOR){?>
											<h1 class="clear"><?php echo lang("Organizations.MERGERSandACQUISITIONS");?></h1>
											<p>
												<?php echo $arrOrganization['mergers']; ?>
											</p>
										<?php }?>
										
										<?php if($arrOrganization['type_id']==PAYOR){?>
											<h1 class="clear"><?php echo lang("Organizations.TOPCLIENTS");?></h1>
											<p>
												<?php echo $arrOrganization['clients']; ?>
											</p>
										<?php }?>
										-->
									</div>
									<!-- End of companyDetails Div -->
                                                                        <div style="display:none;">
										
										<div>
                                                                                <div class="addLink">
                                                                                        <label class="link"  onclick="addLocation(<?php echo $arrOrganization['id'];?>);"><div class=""></div>Add Location</label>
                                                                                </div>
                                                                                <h1 class="title payer" >Location</h1>
										<div id="location">
									
                                                                                </div>
									</div>
								</div>
									<?php //}?>
								</div>	
								
								
								<?php //if($arrOrganization['type_id']!=PAYOR && $arrOrganization['profile_type']!=BASIC){?>
								<div style="margin-top: 15px;">
										
										<div>
										<?php /* if($clientId == INTERNAL_CLIENT_ID){?>
											<?php if(sizeof($arrStatFacts)>0){?>
												<div class="addLink">
													<label class="link"  onclick="editFacts('nonPayer');return false;"><div class="actionIcon editIconWithButton"></div>Edit Facts</label>
												</div>
											<?php }else{?>
												<div class="addLink">
<!--													<label class="link"  onclick="addFacts('nonPayer');return false;"><div class="actionIcon addIcon"></div>Add Facts</label>-->
														<a class="NewBlueButton NewAddIcon" onclick="addFacts('nonPayer');return false;">Add Facts</a>
												</div>
											<?php }?>
										<?php } */?>
                                        <?php /*?><h1 class="title payer" ><?php echo lang("Organizations.FACTS");?></h1><?php */?>
										<table class="listResultSet" id="facts" style="border: none !important;">
											<?php /*?><tbody>
												<tr class="headerBg">
													<th width="16%"><?php echo lang("Organizations.Beds");?></th>
													<th width="16%"><?php echo lang("Organizations.Inpatients");?></th>
													<th width="16%"><?php echo lang("Organizations.Births");?></th>
													<th width="16%"><?php echo lang("Organizations.Outpatients");?></th>
													<th><?php echo lang("Organizations.EmergencyDepartment");?></th>
													<th><?php echo lang("Organizations.Surgeries");?></th>
													
												</tr>
												
												<?php 
													$j =1;
													foreach($arrStatFacts as $detail){?>
												<tr>
													<td><?php echo $detail['no_of_beds']; ?></td>
													<td><?php echo $detail['inpatient']; ?></td>
													<td><?php echo $detail['births']; ?></td>
													<td><?php echo $detail['outpatient']; ?></td>
													<td><?php echo $detail['emergency_department']; ?></td>
													<td><?php echo $detail['no_of_surgeries']; ?></td>
												</tr>
												<?php $j++;}?>
											</tbody><?php */?>
										</table>
									</div>
								</div>
								<?php //}?>
								<!-- Payer Starts -->
								
							<?php /*if($arrOrganization['type_id']==PAYOR  && $arrOrganization['profile_type']!=BASIC){?>
								<!-- Container for organization stats -->
								<div>
									
										<div>
										<?php if($clientId == INTERNAL_CLIENT_ID){?>
											<?php if(sizeof($arrFacts)>0){?>
												<div class="addLink">
													<label class="link" onclick="editPayerFacts('payer');return false;"><div class="actionIcon editIconWithButton"></div>Edit Facts</label>
												</div>
											<?php }else{?>
												<div class="addLink">
<!--													<label class="link" onclick="addPayerFacts('payer');return false;"><div class="actionIcon editIcon"></div>Add Facts</label>-->
													<a class="NewBlueButton NewAddIcon" onclick="addPayerFacts('payer');return false;">Add Facts</a>
												</div>
											<?php }?>
										<?php }?>
										<h1 class="title payer" style="border-bottom: 1px solid black;padding-bottom: 5px;"><?php echo lang("Organizations.FACTS");?></h1>
										<table class="listResultSet" id="factsData">
											<tbody>
												<tr class="headerBg">
<!--													<th width="13%">Company Name</th>-->
													<th width="8%"><?php echo lang("Organizations.Hospitals");?></th>
													<th width="2%"><?php echo lang("Organizations.Physicians");?></th>
													<th width="7%"><?php echo lang("Organizations.PhysiciansEmployed");?></th>
													<th width="9%"><?php echo lang("Organizations.PhysiciansAffiliated");?></th>
													<th width="13%"><?php echo lang("Organizations.PharmacyBenefitManagement");?></th>
													<th width="14%"><?php echo lang("Organizations.SpecialtyPharmacy");?></th>
													<th width="8%"><?php echo lang("Organizations.NCQAStatus");?></th>
													<th width="8%"><?php echo lang("Organizations.MedicareRating");?></th>
													<th width="10%"><?php echo lang("Organizations.ClaimsAndEMRData");?></th>
													<th width="8%"><?php echo lang("Organizations.DataProcessing");?></th>
												</tr>
												
												<?php 
//													$j =1;
												if(isset($arrFacts)){	
													foreach($arrFacts as $detail){?>
												<tr>
													<td class="align_left"><?php echo $detail['no_of_hospitals']; ?></td>
													<td class="align_left"><?php echo $detail['no_of_physicians']; ?></td>
													<td class="align_left"><?php echo $detail['physicians_employed']; ?></td>
													<td class="align_left"><?php echo $detail['no_of_affiliated']; ?></td>
													<td class="align_left"><?php echo $detail['benefit_management']; ?></td>
													<td class="align_left"><?php echo $detail['specialty_pharmacy']; ?></td>
													<td class="align_left"><?php echo $detail['ncqa_status']; ?></td>
													<td class="align_left"><?php echo $detail['start_rating']; ?></td>
													<td class="align_left"><?php echo $detail['cliam_and_emr']; ?>&nbsp;</td>
													<td class="align_left"><?php echo $detail['data_processing']; ?>&nbsp;</td>
												</tr>
												<?php //$j++;
													}}?>
											</tbody>
										</table>
									</div>
								</div>
								<div>
									
									<div>
									<?php //if($clientId == INTERNAL_CLIENT_ID){?>
										<div class="addLink">
											<a class="NewBlueButton NewAddIcon"  id="addEnrollmentForHint" onclick="addOrgPayersData('enrollment');return false;" href="#">Add Enrollments</a>
<!--											<label class="link" id="addEnrollmentForHint" onclick="addOrgPayersData('enrollment');return false;"><div class="actionIcon addIcon"></div>Add Enrollments</label>-->
										</div>
									<?php //}?>
										<h1 class="title payer" style=" border-bottom: 1px solid black;padding-bottom: 5px;"><?php echo lang("Organizations.ENROLLMENT");?></h1>
										
										<table class="listResultSet" id="enrollmentTable">
											<tbody>
												<tr class="headerBg">
<!--													<th width="16%">Company Name</th>-->
													<th width="16%"><?php echo lang("Organizations.EnrollmentType");?></th>
													<?php $arrYear = array_reverse($years); foreach ($arrYear as $row){?>
														<th width="12%"><?php echo $row;?></th>
													<?php }?>
													<th style="width: 5%;width: 5.2%\9"><?php echo lang("Overview.Action"); ?></th>
												</tr>
												
												<?php 
													//$j =1;
												if(isset($arrEnroll)){
//													pr($arrEnroll);	
													foreach($arrEnroll as $detail){?>
												<tr id="<?php echo $detail['id']?>">
													<td class="align_left"><?php echo $detail['type']; ?></td>
													<td><?php echo $detail[$arrYear[0]]; ?></td>
													<td><?php echo $detail[$arrYear[1]]; ?></td>
													<td><?php echo $detail[$arrYear[2]]; ?></td>
													<td><?php echo $detail[$arrYear[3]]; ?></td>
													<td><?php echo $detail[$arrYear[4]]; ?></td>
													<td>
														<?php if($clientId == INTERNAL_CLIENT_ID){?>
															<div onclick="editOrgPayersData('enrollment','<?php echo $detail['id'];?>'); return false;" class="actionIcon editIcon tooltip-demo tooltop-left">
																<a rel="tooltip" class="tooltipLink" href="#" data-original-title="Edit"></a>
															</div>
															<div onclick="deleteOrgPayesData('enrollment','<?php echo $detail['id'];?>'); return false;" class="actionIcon deleteIcon tooltip-demo tooltop-left">
																<a rel="tooltip" class="tooltipLink" href="#" data-original-title="Delete"></a>
															</div>
														<?php }elseif(($detail['created_by']==$userId || $userRoleId==ROLE_MANAGER || $userRoleId==ROLE_ADMIN) && $detail['client_id'] == $clientId){?>
															<div onclick="editOrgPayersData('enrollment','<?php echo $detail['id'];?>'); return false;" class="actionIcon editIcon tooltip-demo tooltop-left">
																<a rel="tooltip" class="tooltipLink" href="#" data-original-title="Edit"></a>
															</div>
															<div onclick="deleteOrgPayesData('enrollment','<?php echo $detail['id'];?>'); return false;" class="actionIcon deleteIcon tooltip-demo tooltop-left">
																<a rel="tooltip" class="tooltipLink" href="#" data-original-title="Delete"></a>
															</div>
														<?php }?>
													</td>
												</tr>
												<?php //$j++;
													}}?>
											</tbody>
										</table>
									</div>
								</div>
								<div>
									<?php //if($clientId == INTERNAL_CLIENT_ID){?>
									<div class="addLink">
										<a class="NewBlueButton NewAddIcon"  id="addFormularyForHint" onclick="addOrgPayersData('formulary');return false;" href="#">Add Formulary</a>
<!--										<label class="link" id="addFormularyForHint" onclick="addOrgPayersData('formulary');return false;"><div class="actionIcon addIcon"></div>Add Formulary</label>-->
									</div>
									<?php //}?>
									<div>
										<h1 class="title payer" style=" border-bottom: 1px solid black;padding-bottom: 5px;"><?php echo lang("Organizations.FORMULARY");?></h1>
										
										<table class="listResultSet" id="formularyTable">
											<tbody>
												<tr class="headerBg">
<!--													<th width="16%">Company Name</th>-->
													<th width="16%"><?php echo lang("Organizations.DrugName");?></th>
													<th width="15%"><?php echo lang("Organizations.DrugTier");?></th>
													<th width="15%"><?php echo lang("Organizations.PACriteria");?></th>
													<th style="width: 0.8%;width: 3%\9;"><?php echo lang("Overview.Action"); ?></th>
												</tr>
												
												<?php 
													//$j =1;
//													pr($this->session->userdata);
												if(isset($arrFormularies)){
													foreach($arrFormularies as $detail){?>
												<tr id="<?php echo $detail['id']?>">
													<td class="align_left"><?php echo $detail['drug_name']; ?></td>
													<td class="align_left"><?php echo $detail['drugTier']; ?></td>
													<td class="align_left"><?php echo $detail['drugCriteria']; ?></td>
													<td>
														<?php if($clientId == INTERNAL_CLIENT_ID){?>
															<div onclick="editOrgPayersData('formulary','<?php echo $detail['id'];?>'); return false;" class="actionIcon editIcon tooltip-demo tooltop-left">
																<a rel="tooltip" class="tooltipLink" href="#" data-original-title="Edit"></a>
															</div>
															<div onclick="deleteOrgPayesData('formulary','<?php echo $detail['id'];?>'); return false;" class="actionIcon deleteIcon tooltip-demo tooltop-left">
																<a rel="tooltip" class="tooltipLink" href="#" data-original-title="Delete"></a>
															</div>
														<?php }elseif(($detail['created_by']==$userId || $userRoleId==ROLE_MANAGER || $userRoleId==ROLE_ADMIN) && $detail['client_id'] == $clientId){?>
															<div onclick="editOrgPayersData('formulary','<?php echo $detail['id'];?>'); return false;" class="actionIcon editIcon tooltip-demo tooltop-left">
																<a rel="tooltip" class="tooltipLink" href="#" data-original-title="Edit"></a>
															</div>
															<div onclick="deleteOrgPayesData('formulary','<?php echo $detail['id'];?>'); return false;" class="actionIcon deleteIcon tooltip-demo tooltop-left">
																<a rel="tooltip" class="tooltipLink" href="#" data-original-title="Delete"></a>
															</div>
														<?php }?>
													</td>
												</tr>
												<?php  //$j++;
													}}?>
											</tbody>
										</table>
									</div>
								</div>
								<div>
									
									<div>
										<?php //if($clientId == INTERNAL_CLIENT_ID){?>
										<div class="addLink">
											<a class="NewBlueButton NewAddIcon"  id="addDiseaseManagementForHint" onclick="addOrgPayersData('disease_management');return false;" href="#">Add Disease Management</a>
<!--											<label class="link" id="addDiseaseManagementForHint" onclick="addOrgPayersData('disease_management');return false;"><div class="actionIcon addIcon"></div>Add Disease Management</label>-->
										</div>
										<?php //}?>
										<h1 class="title payer" style=" border-bottom: 1px solid black;padding-bottom: 5px;"><?php echo lang("Organizations.DISEASEMANAGEMENT");?></h1>
										
										<table class="listResultSet" id="diseaseManagement">
											<tbody>
												<tr class="headerBg">
<!--													<th width="13%">Company Name</th>-->
													<th width="12%"><?php echo lang("Organizations.DiseaseName");?></th>
													<th width="16%"><?php echo lang("Organizations.DiseaseManagementPlatform");?></th>
													<th width="12%"><?php echo lang("Organizations.Identification");?></th>
													<th width="12%"><?php echo lang("Organizations.Intervention");?></th>
													<th width="11%"><?php echo lang("Organizations.Measurment");?></th>
													<th style="width: 2.3%;width: 4.5%\9;"><?php echo lang("Overview.Action"); ?></th>
												</tr>
												
												<?php 
													//$j =1;
												if(isset($arrDiseseMngmt)){
//													pr($arrDiseseMngmt);
													foreach($arrDiseseMngmt as $detail){?>
												<tr id="<?php echo $detail['id'];?>">
													<td class="align_left"><?php echo $detail['disease_name']; ?></td>
													<td class="align_left"><?php echo $detail['dmPlatform']; ?></td>
													<td class="align_left"><?php echo $detail['identification']; ?></td>
													<td class="align_left"><?php echo $detail['intervention']; ?></td>
													<td class="align_left"><?php echo $detail['measurement']; ?></td>
													<td>
														<?php if($clientId == INTERNAL_CLIENT_ID){?>
														<div onclick="editOrgPayersData('disease_management','<?php echo $detail['id'];?>'); return false;" class="actionIcon editIcon tooltip-demo tooltop-left">
															<a rel="tooltip" class="tooltipLink" href="#" data-original-title="Edit"></a>
														</div>
														<div onclick="deleteOrgPayesData('disease_management','<?php echo $detail['id'];?>'); return false;" class="actionIcon deleteIcon tooltip-demo tooltop-left">
															<a rel="tooltip" class="tooltipLink" href="#" data-original-title="Delete"></a>
														</div>
														<?php }elseif(($detail['created_by']==$userId || $userRoleId==ROLE_MANAGER || $userRoleId==ROLE_ADMIN) && $detail['client_id'] == $clientId){?>
														<div onclick="editOrgPayersData('disease_management','<?php echo $detail['id'];?>'); return false;" class="actionIcon editIcon tooltip-demo tooltop-left">
															<a rel="tooltip" class="tooltipLink" href="#" data-original-title="Edit"></a>
														</div>
														<div onclick="deleteOrgPayesData('disease_management','<?php echo $detail['id'];?>'); return false;" class="actionIcon deleteIcon tooltip-demo tooltop-left">
															<a rel="tooltip" class="tooltipLink" href="#" data-original-title="Delete"></a>
														</div>
														<?php }?>
													</td>
												</tr>
												<?php //$j++;
													}}?>
											</tbody>
										</table>
									</div>
								</div>
								<div>
									
										<div>
											<?php //if($clientId == INTERNAL_CLIENT_ID){?>
											<div class="addLink">
												<a class="NewBlueButton NewAddIcon"  id="addCollaborationForHint" onclick="editOrgPayersData('collaboration_rating');return false;" href="#">Add Collaboration Rating</a>
<!--												<label class="link" id="addCollaborationForHint" onclick="editOrgPayersData('collaboration_rating');return false;"><div class="actionIcon addIcon"></div>Add Collaboration Rating</label>-->
											</div>
											<?php //}?>
										</div>
										<h1 class="title payer" style=" border-bottom: 1px solid black;padding-bottom: 5px;"><?php echo lang("Organizations.CollaborationRating");?></h1>
										
										<table class="listResultSet" id="collaborationRating">
											<tbody>
												<tr class="headerBg">
													<th width="10%"><?php echo lang("Organizations.Category");?></th>
													<th width="16%"><?php echo lang("Organizations.Rating");?></th>
												</tr>
												
												<?php 
												if(isset($arrCollabCategory)){
													foreach($arrCollabCategory as $key=>$detail){?>
												<tr>
													<td class="align_left"><?php echo $detail['category']; ?></td>
													<td id="<?php echo $key;?>" class="align_left"><?php echo $detail['ratings']; ?>&nbsp;</td>
												</tr>
												<?php 
													}
												} ?>
											</tbody>
										</table>
									</div>
								<!-- Payer Ends -->
								<?php } */?>
								
								
								<?php //if($arrOrganization['type_id']!=PAYOR  && $arrOrganization['profile_type']!=BASIC){?>
									<?php /*if($clientId == INTERNAL_CLIENT_ID){?>
										<div class="addLink" style="padding-bottom: 5px;">
<!--											<a class="actionIcon editIconWithButton"  onclick="editAffPartners();" href="#">Edit Affiliates and Partners</a>-->
												<label onclick="editAffPartners();" class="link"><div class="actionIcon editIconWithButton"></div>Edit Affiliates and Partners</label>
										</div>
										<?php } */?>
									<!--  <h1 class="title" style=" border-bottom: 1px solid black;padding-bottom: 10px;"><?php echo lang("Organizations.AFFILIATESandPARTNERSHIPS");?></h1>
									<div id="influence-map-stats-container">
								
									</div>-->
									<!--  List Affilates details -->
									<div id="notes-container">
    									<div id="user-notes" class="bio_border">
        									<h4>User Notes</h4>		
        										<ul>
        											<?php foreach($arrNotes as $note){?>
        											<input type="hidden" name="orginal_doc_name" id="orginal_file_<?php echo $note['id'];?>" value="<?php echo $note['orginal_doc_name'] ?>" data-docname="<?php echo $note['document_name']?>"/>
        											<li id="<?php echo $note['id'];?>">
        												<div id="container-<?php echo $note['id'];?>">
        													<?php if(strlen($note['note']) >= 400){?>
        														<span class="<?php echo $note['id'];?> halftext"><?php echo substr($note['note'],0,400)."...";?></span>
        														<span class="<?php echo $note['id'];?> fulltext a"><?php echo $note['note'];?></span>
        													<?php }else{?>
        														<span class="<?php echo $note['id'];?>"><?php echo $note['note'];?></span>
        													<?php }?>
        													<?php if($this->common_helpers->isActionAllowed("user_notes","edit",array("created_by"=>$note['created_by']))){?>
        													<div class="notes-actions">
        														<?php if($note['orginal_doc_name']!=''){ ?>
        															<div class="actionIcon downloadIcon tooltip-demo tooltop-left"><a href="<?php echo base_url(); ?>organizations/note_document_download/<?php echo $note['id'];?>" class="tooltipLink" rel="tooltip"></a>Download file</div>
        														<?php } ?>
        														<div class="actionIcon editIcon tooltip-demo tooltop-left" onclick="editNote(<?php echo $note['id'];?>); return false;"><a data-original-title="Edit" href="#" class="tooltipLink" rel="tooltip"></a></div>&nbsp;&nbsp;
        														<div class="actionIcon deleteIcon tooltip-demo tooltop-left" onclick="deleteNote(<?php echo $note['id'];?>); return false;"><a href="#" class="tooltipLink" rel="tooltip" title="Delete"></a></div>
        													</div>
        													<?php }?>
        												</div>
        												<?php if($note['orginal_doc_name']!=''){ ?>
        													<div class="notes-details">Uploaded document: <gg id="uploadedFile_<?php echo $note['id']; ?>"><?php echo $note['document_name']?></gg></div>
        												<?php } ?>
        												<?php if($note['modified_by'] > 0 && $note['modified_by'] != ''){?>
        													<div class="notes-details">Modified by: <?php if($note['modif_id']!=INTERNAL_CLIENT_ID) echo $note['modified_by_first_name']." ".$note['modified_by_last_name']; else echo 'Aissel Analyst';?>, <?php echo date('d M Y, h:i A', strtotime($note['modified_on']));?></div>
        												<?php }else{?>												
        													<div class="notes-details">Posted by: <?php if($note['post_id']!=INTERNAL_CLIENT_ID) echo $note['first_name']." ".$note['last_name']; else echo 'Aissel Analyst';?>, <?php echo date('d M Y, h:i A', strtotime($note['created_on']));?></div>
        												<?php }?>
        											</li>
        											<?php }?>
        										</ul>
        									<form id="saveNote" method="post" action="#" >
            									<!-- a class="actionIcon addIcon" id="add-notes" href="#" onclick="$('#add-notes-area').fadeToggle('slow');return false;"><span></span>Add Note</a  -->
            									<div id="add-notes-area" >
            										<h5 style="margin-bottom: 0">Add Note</h5>
            										<textarea onKeyDown="limitText(this,'notesCountDown',200);" onKeyUp="limitText(this,'notesCountDown',200);" rows="3" cols="700" id="user-note" name="user_note" placeholder="Enter notes..."></textarea>
            										<div>You have <span id="notesCountDown">200</span> characters left. <font size="1">(Maximum characters: 200)</font></div>
            										<br>
            										<div class="subnotes" style="display: none;">
            											<label style="margin-left: 0 !important">Attach File: </label><input type="text" name="fileName" id="file_name" value="" placeholder="Enter file name"/>
                                    					<!-- label for="contractRate" style="margin-left: 0 !important">Upload Doc:</label -->
                                    					<input type="file" name="note_file" id="noteFile" value=""></input>
                										<button type="submit" id="saveBtn">Save</button>        										
            										</div>
            									</div>
            								</form>
    									</div>
									</div>
									<div class="clear" style="margin-bottom: 10px;">
										<div class="gridWrapper" id="allAffilatesGridContainer">
											<table id="JQBlistAllAffilatesResultSet"></table>
											<div id="listAllAffilatesPager"></div>
										</div>		
									<!-- End of Table to listOthers -->
									</div>
									
									<!--  List Key_People details -->
									<div class="clear" style="margin-bottom: 10px;">
										<div class="gridWrapper" id="allKeyPeopleGridContainer">
											<table id="JQBlistAllKeyPeopleResultSet"></table>
											<div id="listAllKeyPeoplePager"></div>
										</div>		
									<!-- End of Table to listOthers -->
									</div>
									
									
									<!--  List Interaction details -->
									<div class="clear" style="margin-bottom: 10px;">
										<div class="gridWrapper" id="allInteractionGridContainer">
											<table id="JQBlistAllInteractionResultSet"></table>
											<div id="listAllInteractionPager"></div>
										</div>		
									<!-- End of Table to listOthers -->
									</div>
								<?php //}?>                         
								<!-- End of keyPeople Div -->
								
								<!-- End of about Div -->
			<?php 
							break;
				}
			?>
			
		</div>
		
		<!-- Enable Verticle separator between content and side menu list  By Laxman  -->
		<style>
			#contentWrapper.span-23 {
				background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
			    background-position: 135px 50%;
			    background-repeat: repeat-y;
			}
			.ui-tabs-vertical .ui-tabs-nav {
				margin-left: 0px;
			}
			
			a {
    color: #0254EB
}
a:visited {
   # color: #0254EB
}
a.morelink {
    text-decoration:none;
    outline: none;
    cursor:pointer;
}
.morecontent span {
    display: none;
}
.comment {
    width: 400px;
    background-color: #f0f0f0;
    margin: 10px;
}
		</style>
		<div id="addEnrollOrgPayers" class="microProfileDialogBox">
 			<div id="orgPayerContainer1" class="profileContent"></div>
 		</div>
 		<div id="addFormularyOrgPayers" class="microProfileDialogBox">
 			<div id="orgPayerContainer2" class="profileContent"></div>
 		</div>
 		<div id="addDmOrgPayers" class="microProfileDialogBox">
 			<div id="orgPayerContainer3" class="profileContent"></div>
 		</div>
 		<div id="addCollabRatingOrgPayers" class="microProfileDialogBox">
 			<div id="orgPayerContainer4" class="profileContent"></div>
 		</div>
 		<div id="addNewOrg" class="microProfileDialogBox">
			<div class="addNewOrgProfileContent profileContent"></div>
		</div>
 
<!-- Edit org modal boxes -->
		<div id="editBasicInfo" class="microProfileDialogBox">
 			<div id="edit1" class="profileContent"></div>
 		</div>
<!-- 		<div id="editAffiliatesAndPartners" class="microProfileDialogBox">-->
<!-- 			<div id="editAffAndPartners" class="profileContent"></div>-->
<!-- 		</div>-->
 		<div id="editOrgFacts" class="microProfileDialogBox">
 			<div id="editOrgFacts1" class="profileContent"></div>
 		</div>
<!-- 		<div id="editPayerFacts" class="microProfileDialogBox">-->
<!-- 			<div id="editPayerFacts1" class="profileContent"></div>-->
<!-- 		</div>-->
                                             <div>	
						<div id="addLocationForOrg" class="microProfileDialogBox">
							<div class="profileContent" id="addLocationForOrgContent"></div>
						</div>
						<div>	
						<div id="addPhoneForKols" class="microProfileDialogBox">
							<div class="profileContent" id="addPhoneForKolsContent"></div>
						</div>
					</div>
					<div>	
						<div id="addStaffForKols" class="microProfileDialogBox">
							<div class="profileContent" id="addStaffForKolsContent"></div>
						</div>
					</div>
					</div>
					<div id="newKolProfile" class="microProfileDialogBox">
                		<div class="newProfileContent profileContent"></div>
                	</div>
                	<div id="contentHolder" class="callOutTest microView" style="display: none;">
		<div>
			<a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeKolProfile();" class="ui-icon ui-icon-closethick">close</span></a>
			<!--<img class="ui-icon ui-icon-closethick" alt="" src="" onclick="closeKolProfile();" />
		--></div>
		<div class="profileContent"></div>
	</div>
	<div id="arraouHolder" class="callOutTest" style="display: none;"><div class="arrowMarkIcon"></div></div>