<div class="eventsMsgBox"></div>
<form>
	<div align="center">
		<caption><h4>Add/Edit Session Type</h4></caption>
	</div>
	<table class="anaylystForm eventTbl ">

		<br />
		<tr>
			<td><div align="center">
					<span id="responseMessage"></span>
				</div>
				<p>
					<input type="hidden" id="hiddenId" readonly>
				
				<div align="center">
				<label>Session Type:</label><input type="text" name="type" id="type"
						align="center" />
				</div>
				</p></td>
		</tr>
		<tr>
			<td>
				<div class="formButton" align="center">
					<input type="button" value="Save" name="submit"
						onclick="saveSessionTypes();"></input> <input type="button"
						value="Cancel" name="submit" onclick="closeModal();"></input>
				</div>
			</td>
		</tr>
	</table>
	<!-- End of Table -->
</form>
<!-- End of User Form -->

