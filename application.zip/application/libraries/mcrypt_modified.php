<?php

	define("IV", "fedcba9876543210");

    /**
     * @param string $str
     * @param bool $isBinary whether to encrypt as binary or not. Default is: false
     * @return string Encrypted data
     */
    function myencrypt($str, $privateKey, $isBinary = false)
    {
        $iv = IV;
        $str = $isBinary ? $str : utf8_decode($str);

        $td = mcrypt_module_open('rijndael-128', ' ', 'cbc', $iv);

        mcrypt_generic_init($td, $privateKey, $iv);
        $encrypted = mcrypt_generic($td, $str);

        mcrypt_generic_deinit($td);
        mcrypt_module_close($td);

        return $isBinary ? $encrypted : bin2hex($encrypted);
    }

    /**
     * @param string $code
     * @param bool $isBinary whether to decrypt as binary or not. Default is: false
     * @return string Decrypted data
     */
    function mydecrypt($code, $privateKey, $isBinary = false)
    {
        $code = $isBinary ? $code : hex2bin($code);
        $iv = IV;

        $td = mcrypt_module_open('rijndael-128', ' ', 'cbc', $iv);

        mcrypt_generic_init($td, $privateKey, $iv);
        $decrypted = mdecrypt_generic($td, $code);

        mcrypt_generic_deinit($td);
        mcrypt_module_close($td);

        return $isBinary ? trim($decrypted) : utf8_encode(trim($decrypted));
    }

    function hex2bin($hexdata)
    {
        $bindata = '';

        for ($i = 0; $i < strlen($hexdata); $i += 2) {
            $bindata .= chr(hexdec(substr($hexdata, $i, 2)));
        }

        return $bindata;
    }
    
    function isChecksumValid($cheksum,$privateKey){
		$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		//echo $cheksum."<br>";
		$decryptString = mydecrypt($cheksum,$privateKey);
		//echo "<br> Actual String : ".$actual_link."<br>";
		//echo "<br> Decrypt String : ".$decryptString."<br>";
		if(trim($decryptString) == trim($actual_link)){
			return true;
		}else{
			return false;
		}
	}
