<?php
/**
 * This class method to retrieve the stored jsons for diferent refference entties
 * 
 * @package application.models
 * @author Ramesh B
 * @since 5.0
 * @created 21-08-12
 */

class Json_store extends Model{
	
	function Json_store(){
		parent::Model();
		$this->load->model('common_helpers');
	}
	
	function insertJsonToStore($rowData){
		$this->db->insert("json_store",$rowData);
	}
	
	function getJsonByParamFromStore($referenceId,$filter = null){
		$client_id = $this->session->userdata("client_id");
	    $filterValues  = array();
	    if(!is_array($filter)){
	        $filterValues[]    = $filter;
	    }
		$this->db->select("json_data");
		$this->db->where('ref_id',$referenceId);
		if($filter != null){
			$this->db->where_in('filter',$filter);
		}
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->where('client_id',$client_id);
		}else{
		    $this->db->where('client_id', INTERNAL_CLIENT_ID);
		}
		$results = $this->db->get("json_store");
		if($results->num_rows() > 0){
			return $results->row_array();
		}else{
			return false;
		}
	}
	
	function clearStore(){
		
	}
	
	function deleteFromStore($referenceId, $filter = null){
		$this->db->where('ref_id',$referenceId);
		if($filter != null)
			$this->db->where('filter',$filter);
		if($this->db->delete('json_store'))
			return true;
		else
			return false;
	}
	function deleteFromStoreByClientId($referenceId, $analystSelectedClientId){
		$this->db->where('ref_id',$referenceId);
		$this->db->where('client_id',$analystSelectedClientId);
			if($this->db->delete('json_store'))
				return true;
				else
					return false;
	}
	function deleteFromStoreByKolId($kolId){	    
            $filter = 'kol_id:'.$kolId;	    
	        $this->db->where('filter',$filter);
	        if($this->db->delete('json_store'))
	            return true;
            else
                return false;
	}
	
}