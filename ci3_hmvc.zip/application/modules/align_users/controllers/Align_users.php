<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class align_users extends MX_Controller{
	function __construct()
	{
		parent::__construct();
		$this->load->model('align_user');
		$this->load->model('helpers/common_helper');
	}
	function edit_align_users($kolId,$type){
		$client_id = $this->session->userdata('client_id');
		$user_id   = $this->session->userdata('user_id');
		$data['userId']	= $user_id;
		$data['arrUsers']	= $this->align_user->listUsers($client_id);
		$data['assignedUsers'] = $this->align_user->getAssignedUsers($kolId);
		$data['arrKols']	= $kolId;
		$data['type'] = $type;
		$this->load->view('align_kols_within_view',$data);
		
	}
	function save_kol_alignment_within_profile(){
		$data['status']=false;
		$data['message']='Error in Updating the data.Please try again.';
		$kolId		= $this->input->post('kol_id');
		$kolIds		= array($kolId);
		$arrUsers	= $this->input->post('users');
		$role	= $this->session->userdata('role_type');
		$this->align_user->deleteKolAlignment($kolIds,$arrUsers,$role);
// 		echo $this->db->last_query();
		if($this->align_user->saveKolAlignment($kolIds,$arrUsers)){
			$data['status']=true;
			$data['message']='Saved sucessfully';
		}
// 		echo $this->db->last_query();
		echo json_encode($data);
	}
	function list_assigned_users($kolId = null) {
		$page = (int) $this->input->post('page'); // get the requested page
		$limit = (int) $this->input->post('rows'); // get how many rows we want to have into the grid
		
		$responce = array();
		$assignedUsers = array();
		$assignedUsers = $this->align_user->getAssignedUsers1($kolId);
		foreach ($assignedUsers as $row) {
			$responce->rows[$i]['id']=$row['id'];
			$row['kol_id'] = $kolId;
			if(ROLE_USER && $this->session->userdata('user_id') == $row['user_id']){
				$row['eAllowed'] = true;
				$row['dAllowed'] = true;
			}
			$responce[] = $row;
		}
		$total_pages	= 0;
		$data	= array();
		$count = sizeof($responce);
		if ($count > 0) {
			$total_pages = ceil($count / $limit);
		} else {
			$total_pages = 0;
		}
		$data['records'] = $count;
		$data['total'] = $total_pages;
		$data['page'] = $page;
		$data['rows'] = $responce;
		echo json_encode($data);
	}
	function delete_assign($id = null,$kolId) {
		//delete Assigned User id
		$data = $this->common_helper->deleteEntityByWhereCondition('user_kols',array('id'=>$id));
		echo json_encode($data);
	}
	function add_update_assign_client($kolId = null,$type,$id=null) {
		$client_id = $this->session->userdata('client_id');
		if($type=='edit'){
			$tableName = 'user_kols';
			$this->load->model('kols/kol');
			$getSavedDetails= $this->kol->getAdditionalDetails($tableName,$id);
		}
		$arrResult= $this->align_user->listUsers($client_id);
		$arrClientUsers['']='---Select---';
		foreach ($arrResult as $row){
			$arrClientUsers[$row['id']]=$row['first_name'].' '.$row['last_name'];
		}
		$arrResult= $this->align_user->getAllClientsType();
		$arrClientsType['']='---Select---';
		foreach ($arrResult as $row){
			$arrClientsType[$row['id']]=$row['name'];
		}
		
		$hidden_fields=array('kol_id'=>$kolId,'id'=>$id);
		$form_inputs_details[]=array('type'=>'select',   'label'=>array('label_name'=>'User','required'=>1),'name'=>'client','data'=>array('id'=>'client','class'=>'required form-control'),'options'=>$arrClientUsers,'selected'=>$getSavedDetails['user_id']);
		$form_inputs_details[]=array('type'=>'select',   'label'=>array('label_name'=>'Type','required'=>1),'name'=>'client_type','data'=>array('id'=>'client_type','class'=>'required form-control'),'options'=>$arrClientsType,'selected'=>$getSavedDetails['type']);
		$form_details=array('form_inputs_details'=>$form_inputs_details,
				'hidden_ids'=>$hidden_fields,
				'form_id'=>'saveKolAssignClientForm',
				'submit_function'=>'save_assigned_client_form();',
				'cancel_function'=>'close_dialog();'
		);
		$data['html_form']=get_html_form($form_details);///cals helper function to get html content
		$this->load->view('add_update_assign_user',$data);
	}
	function save_client_assign(){
		$data= $this->align_user->insertOrUpdateAssignClient($_POST);
		echo json_encode($data);
	}
	function align_kols($kols=0){
		$client_id = $this->session->userdata('client_id');
		$user_id   = $this->session->userdata('user_id');
		$data['userId']	= $user_id;
		$data['arrUsers']	= $this->align_user->listUsers($client_id);
		$data['arrKols']	= $kols;
		$this->load->view('align_kols',$data);
	}
	function save_kol_alignment(){
		$kolIds		= explode(',',$this->input->post('kol_id'));
		$arrUsers	= $this->input->post('users');
		$this->align_user->saveKolAlignment($kolIds,$arrUsers);
	}
	function remove_kol_alignment(){
		$arrUserId   = array($this->session->userdata('user_id'));
		$kolIds		= explode(',',$this->input->post('kol_id'));
		$this->align_user->deleteKolAlignment($kolIds,$arrUserId);
	}
}
?>