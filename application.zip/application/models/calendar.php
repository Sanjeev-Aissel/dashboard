<?php
/**
 * Model for handling the calendar operations
 * 
 * @package application.models	
 * @author Ramesh B
 * @since
 * @created on 14-05-11
 */

class Calendar extends Model{

	/* Constructor */
	function Calendar(){
		parent::Model();
	}
	
	/**
	 * Saves the calendar event into database and returns the last insert row id
	 * @author 	Ramesh B
	 * @since	
	 * @return Integer
	 * @created 14-05-2011
	 */
	function addEvent($arrEventDetails){
		if($this->db->insert('calendar_events',$arrEventDetails)){
			return $this->db->insert_id();
		}else{
			return 0;
		}
	}
	/**
	 * Retries all the Calendar events with in the given range of time for given ClientID/UserID
	 * @author 	Ramesh B
	 * @since	
	 * @return Array of Objects
	 * @created 14-05-2011
	 */
	function getAllEvents($startTime,$endTime,$clientId,$userId){
		$arrEvents=array();
		$this->db->where("starttime between '$startTime' and '$endTime'");
		if($userId!=0)
			$this->db->where('created_by',$userId);
		$this->db->where('client_id',$clientId);
		$results=$this->db->get('calendar_events');
		foreach($results->result() as $row){
			$arrEvents[]=$row;
		}
		return $arrEvents;
	}
	
	/**
	 * Retries Calendar event matching the givent calendar event Id
	 * @author 	Ramesh B
	 * @since	
	 * @return Object
	 * @created 14-05-2011
	 */
	function getEvent($id){
		$this->db->where('id',$id);
		$results=$this->db->get('calendar_events');
		$row=$results->row();
		return $row;
	}
	
	/**
	 * Updates the Calendar event matching the givent calendar event Id
	 * @author 	Ramesh B
	 * @since	
	 * @return Boolean
	 * @created 14-05-2011
	 */
	function updateEvent($arrEventDetails){
		$this->db->where('id',$arrEventDetails['id']);
		if($this->db->update('calendar_events',$arrEventDetails)){
			return true;
		} else {
			return false;
		}
	}
	

	/**
	 * Deletes the Calendar event matching the givent calendar event Id
	 * @author 	Ramesh B
	 * @since	
	 * @return Boolean
	 * @created 14-05-2011
	 */
	function deleteEvent($id){
		$this->db->where('id',$id);
		if($this->db->delete('calendar_events')){
			return true;
		}else{
			return false;
		}
	}
}