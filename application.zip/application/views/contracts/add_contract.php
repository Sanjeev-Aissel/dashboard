<?php
/**
 * This is HTML page to add Contract details
 * 
 * @author Vinayak
 * @created 24-11-2011
 * @since  3.4	
 */
$conrractKolAutoCompleteOptions = "width: 160, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
?>
<style type="text/css">

	.analystForm input[type="submit"]{
		margin-left: 219px;
		width: 50px;
	}

	.analystForm textarea {
	    margin-left: -1px;
	    margin-top: 3px;
	    width: 286px;
	   
	}
	.mandatoryFields{
		color:red;
	}
	#contractForm label.error{
		padding:0 0 0 128px;
	}
	#contractFile{
		width:300px;
	}
</style>

<script type="text/javascript">
var contract_type = '<?php echo $contract_type;?>';
var specType = '';
var contractKolAutoCompleteOptions = '';
<?php if(ORGS_CONTRACT){?>
var serviceUrl ='';
        if(contract_type=='track'){
        	var contractKolAutoCompleteOptions = {
        			<?php 
        	        if(KOL_CONSENT){?>
        			serviceUrl: '<?php echo base_url();?>contracts/get_all_kol_org_names_for_autocomplete/1/1',
        			<?php }else { ?>
        			serviceUrl: '<?php echo base_url();?>contracts/get_all_kol_org_names_for_autocomplete/1',
        			<?php } ?>
        			<?php echo $conrractKolAutoCompleteOptions;?>,
        			onSelect: function(event, ui) { 
        				var kolId = $(event).children('.id1').html();
        				var selText = $(event).children('.organizations').html();
        				selText=selText.replace(/\&amp;/g,'&');
        				specType = $(event).children('.organizations').attr('type');
        				$('#kolName').val(selText);
        				if(specType=='kol'){
        					$('#orgId').val('');
        					$('#kolId').val(kolId);
        				}else{
        					$('#kolId').val('');
        					$('#orgId').val(kolId);
        				}
        			 },
        		};
        }
<?php }else{ ?>
var serviceUrl ='';
    var contractKolAutoCompleteOptions = {    	    
    		<?php 
            if(KOL_CONSENT){?>
    		serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete/1/1',
    		<?php }else { ?>
    		serviceUrl: '<?php echo base_url();?>kols/get_kol_names_for_all_autocomplete/1',
    		<?php } ?>
    		<?php echo $conrractKolAutoCompleteOptions;?>,
    		onSelect: function(event, ui) { 
    			var kolId = $(event).children('.id1').html();
    			var selText = $(event).children('.kolName').html();
    			selText=selText.replace(/\&amp;/g,'&');
    			$('#kolName').val(selText);
    			$('#kolId').val(kolId);
    		 },
    	};
<?php }?>
	function validateEventForm(){

		
		//validate the plans 
		if(!$("#contractForm").validate().form()){
			return false;
		}else{
			
			var kolName = $('#kolName').val();
			<?php if(ORGS_CONTRACT){?>
        			if(contract_type=='kol'){
            			kolName = $.trim(kolName);
            			if(kolName.indexOf(' ')>=1){
            				$("#contractForm").submit();
            				$('#contractForm').removeAttr('action',null);
            			}else if(kolName.indexOf(',')>=1){
            				$("#contractForm").submit();
            				$('#contractForm').removeAttr('action',null);
            			}else{
            				status='False';
            				jAlert('Single word <?php echo lang('KOL'); ?> not allowed, please enter first and last name');
            				return false;
            			}
        			}else{
        				$("#contractForm").submit();
        				$('#contractForm').removeAttr('action',null);
        			}
			<?php }else{ ?>
        			kolName = $.trim(kolName);
        			if(kolName.indexOf(' ')>=1){
        				$("#contractForm").submit();
        				$('#contractForm').removeAttr('action',null);
        			}else if(kolName.indexOf(',')>=1){
        				$("#contractForm").submit();
        				$('#contractForm').removeAttr('action',null);
        			}else{
        				status='False';
        				jAlert('Single word <?php echo lang('KOL'); ?> not allowed, please enter first and last name');
        				return false;
        			}
			<?php } ?>
			//return true;
			//Serialize the form data
			//return true;
		}
	}


	$(document).ready(function(){
	/** 
	 ** @since  22 Aug 2012
	 **The following code is used to disable caching in IE
	 **/
		<?php 
			$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
			$this->output->set_header("Pragma: no-cache"); 
		?>
		/*$('#startDate').datepicker({
			dateFormat: 'mm/dd/yy'
		});
		$('#endDate').datepicker({
			dateFormat: 'mm/dd/yy'
		});*/
		 $("#startDate").datepicker({
			 dateFormat: 'mm/dd/yy',
		      onSelect: function(selected) {
		        $("#endDate").datepicker("option","minDate", selected);
		        $("#startDate").removeClass("error");
				$("#startDate").next().remove();
		      }
		  });

		  $("#endDate").datepicker({
			  dateFormat: 'mm/dd/yy',
		      onSelect: function(selected) {
		        $("#startDate").datepicker("option","maxDate", selected);
		        $("#endDate").removeClass("error");
				$("#endDate").next().remove();
		      }
		  }); 
		<?php 
			if($arrContract!=null){
				if($arrContract['contract_file']!=''){	
		?>
					$('#file_upload').hide();
		<?php	 
				}
			}
		?>

		var contractKolAutoComplete	= $('#kolName').autocomplete(contractKolAutoCompleteOptions);
		$('.map-info.tooltop-bottom').tooltip({
	     	selector: "a[rel=tooltip]",
	    	placement:'bottom',
	    	delay:tooltipDelay
	    });
	});

		function deleteFile(fileName,contractId){
	
			$.ajax({

				url:'<?php echo base_url();?>contracts/delete_file/'+fileName+'/'+contractId,
				dataType:'json',
				success:function(returnData){
						if(returnData.saved==true){
							$('#file_upload').show();
							$('#deleteLink').hide();
						}
				}
				

			})

		}

</script>

<div>
	<div class="formHeader">
		<h5>Contract</h5>
	</div>
<form action="<?php echo base_url()?>contracts/<?php if($arrContract==null) echo 'save_contract'; else if($arrContract!=null) echo 'update_contract';?>/<?php echo $kolId; ?>/<?php echo $contract_type;?>"  enctype="multipart/form-data" method="post" id="contractForm" name="contractForm" class="niceform validateForm clientForm" > 
	<div class="msgBoxContainer"><div class="paymentMsgBox"></div></div>

		<input type="hidden" name="id" id="contractName" value="<?php if($arrContract!=null) echo $arrContract['id']; else echo '';?>"></input>
	<!-- Table for Payment -->
	<table class="analystForm" id="contractTbl">
		<tr>
			<td>
				<p>
					<label for="contractRate">Contract Name:<span class="mandatoryFields">*</span></label>
					<input type="text" name="contract_name" id="contractName" value="<?php if($arrContract!=null) echo $arrContract['contract_name']; else echo '';?>" class="required"></input>
				</p>
			</td>
		</tr>
		<tr>
			<td>
				<p>
				<?php if(ORGS_CONTRACT){?>
					<?php if($contract_type=='kol'){?>
    					<label for="kolName">KTL:<span class="mandatoryFields">*</span></label>
    					<input type="text" name="kol_name" id="kolName" value="<?php if($arrContract!=null) echo $arrContract['kol_name']; else echo '';if(isset($kol_name)) echo $kol_name;?>" class="required autocompleteInputBox" <?php if(isset($kol_name) || isset($kolId)){?> readonly="readonly" <?php }?>></input>
    					<!-- <span id="tooltip-about-name-format" class="map-info tooltop-bottom"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Enter KOL name in the format of First_name Middle_name Last_name</span>">&nbsp;</a></span> -->
    					<input type="hidden" name="kol_id" id="kolId" value="<?php if($arrContract!=null) echo $arrContract['kol_id']; else {echo '';if(isset($kolId)) echo $kolId;} ?>">
					<?php }elseif ($contract_type=='track') {?>
    					<label for="OrgName">KTL / Org Name:<span class="mandatoryFields">*</span></label>
    					<input type="text" name="kol_name" id="kolName" value="<?php if($arrContract!=null) echo $arrContract['kol_name']; else echo '';if(isset($kol_name)) echo $kol_name;?>" class="required autocompleteInputBox" <?php if(isset($kol_name) || isset($kolId)){?> readonly="readonly" <?php }?>></input>
    					<!-- <span id="tooltip-about-name-format" class="map-info tooltop-bottom"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Enter KOL name in the format of First_name Middle_name Last_name</span>">&nbsp;</a></span> -->
    					<input type="hidden" name="org_id" id="orgId" value="<?php if($arrContract!=null) echo $arrContract['org_id']; else {echo '';if(isset($kolId)) echo $kolId;} ?>">
    					<input type="hidden" name="kol_id" id="kolId" value="<?php if($arrContract!=null) echo $arrContract['kol_id']; else {echo '';if(isset($kolId)) echo $kolId;} ?>">
					<?php }else{?>
						<label for="OrgName">Organization Name:<span class="mandatoryFields">*</span></label>
    					<input type="text" name="kol_name" id="kolName" value="<?php if($arrContract!=null) echo $arrContract['kol_name']; else echo '';if(isset($kol_name)) echo $kol_name;?>" class="required autocompleteInputBox" <?php if(isset($kol_name) || isset($kolId)){?> readonly="readonly" <?php }?>></input>
    					<!-- <span id="tooltip-about-name-format" class="map-info tooltop-bottom"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Enter KOL name in the format of First_name Middle_name Last_name</span>">&nbsp;</a></span> -->
    					<input type="hidden" name="org_id" id="orgId" value="<?php if($arrContract!=null) echo $arrContract['org_id']; else {echo '';if(isset($kolId)) echo $kolId;} ?>">
					<?php }?>
				<?php }else{?>
						<label for="kolName">KTL:<span class="mandatoryFields">*</span></label>
    					<input type="text" name="kol_name" id="kolName" value="<?php if($arrContract!=null) echo $arrContract['kol_name']; else echo '';if(isset($kol_name)) echo $kol_name;?>" class="required autocompleteInputBox" <?php if(isset($kol_name) || isset($kolId)){?> readonly="readonly" <?php }?>></input>
    					<!-- <span id="tooltip-about-name-format" class="map-info tooltop-bottom"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Enter KOL name in the format of First_name Middle_name Last_name</span>">&nbsp;</a></span> -->
    					<input type="hidden" name="kol_id" id="kolId" value="<?php if($arrContract!=null) echo $arrContract['kol_id']; else {echo '';if(isset($kolId)) echo $kolId;} ?>">
				<?php }?>
				</p>
			</td>
		</tr>
		<tr>
			<td>
				<p>
					<label for="startDate">Start Date:<span class="mandatoryFields">*</span></label>
					<input type="text" readonly="readonly" name="start_date" id="startDate" value="<?php if($arrContract!=null) echo $arrContract['start_date']; else echo '';?>" class="required"></input>
				</p>
			</td>
		</tr>
		<tr>
			<td>
				<p>
					<label for="endDate">End Date:<span class="mandatoryFields">*</span></label>
					<input type="text" readonly="readonly" name="end_date" id="endDate" value="<?php if($arrContract!=null) echo $arrContract['end_date']; else echo '';?>" class="required"></input>
				</p>
			</td>
		</tr>
		
		
		<tr>
			<td>
				<p>
					<label for="contractRate">Description:<span class="mandatoryFields">*</span></label>
					<textarea rows="1" cols="1" name="contract_description" id="contractDesc" class="required"><?php if($arrContract!=null) echo $arrContract['contract_description'];?></textarea>
			
				</p>
			</td>
		</tr>
		
		<tr id="file_upload">
			<td>
				<p>
					<label for="contractRate">Upload Doc:</label>
					<input type="file" name="contract_file" id="contractFile" value="" size="40" accept=".pdf,.JPG,.PNG,.pdf,.PDF,.xlr,.xls,xlsx,.ppt,.pptx,.txt,.gif,.jpg,.jpeg,.png,.doc,.docx"></input>
				</p>
			</td>
		</tr>
		<?php if($arrContract!=null){
				if($arrContract['contract_file']!=''){
			?>
		<tr>
			<td>
				<p>
				<label id="deleteLink"><a href="#" onclick="deleteFile('<?php echo $arrContract['contract_file'];?>','<?php echo $arrContract['id']?>')">
					<img src="<?php echo base_url()?>images/file-download.png" /> Remove File
				</a></label>
				</p>
			</td>
		</tr>
		<?php }}?>
		<tr>
			<td class="alignCenter">
				<p>
				<?php if(isset($kolId)){?>
					<input type="hidden" name="withInProfile" value="true">
				<?php } ?>	
					<input type="button" name="submit1" value="Save" id="saveContract" onclick="validateEventForm();"></input>
				</p>
			</td>
		</tr>
					
	</table>		
	<!-- End of Payment table -->
</form>


</div>