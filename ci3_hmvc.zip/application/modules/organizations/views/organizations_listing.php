<script type="text/javascript">
		<?php
			// prepare array of JS files to insert into queue
			$queued_js_scripts =array('modules/organizations/js/org_results');
			// add the JS files into queue i.e Append to the existing queue
			$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
		?>
</script>
<style>
div.defaultProfileIcon {
   background: rgba(0, 0, 0, 0) url(<?php echo base_url(); ?>assets/images/organisation_inactive.svg) no-repeat scroll 0 0 / 40px 40px;
   height: 40px;
   width: 100%;
/*     margin-top: 20%; */
}
.displayBlock{
display:block;
font-size:12px;
}
#filtersApplied{
   display: block;
    display: inline-block;
    font-weight: normal;
    /* float: left; */
    margin-left: 10px;
    background-color: #FED;
    border: 1px solid #bcbcbc;
    /* border-color: #D86; */
    padding: 1px 10px;
    -webkit-border-radius: 2px;
    -moz-border-radius: 2px;
    border-radius: 2px;
    margin-top: 0px;
    font-size: 11px;
    text-transform: none;
    padding: 5px 10px;
}
#orgsListing table td, #orgsListing table th, table.listResultSet th, table.listResultSet td {
    padding: 6px 2px 6px 3px;
}
.countKolMsgContainer {
    float: right;
    font-size: 14px;
    padding: 5px;
    vertical-align: middle;
}
.oddRow {
    background-color: #eee;
}
#orgsListing table tr{
border-bottom:1px solid #ccc;
}
#orgsListing table tr th:hover{
background:none !important;
}
.row_padding {
    padding: 5px 0px;
    border-bottom: 1px solid #ccc;
}
#resetBttnContainer {
    margin-top: -18px;
    padding-bottom: 10px;
    color: #2b9af3 !important;
    margin-top: 0px;
    padding-bottom: 0;
    float: right;
    padding-right: 2px;
}
.custom-btn{
    padding: 3px 10px !important;
    font-size: 12px !important;
    border-radius: 2px !important;
    background: #2b9af3 none repeat scroll 0 0;
    border: 1px solid #2b9af3;
    color:white;
}
.custom-btn:hover{
    background: #ffffff none repeat scroll 0 0;
    border: 1px solid #2b9af3;
    color:#2b9af3;
}
ul.pageRightOptions li {
    float: left;
    height: 25px;
    line-height: 25px;
    list-style: outside none none;
    padding: 2px 3px;
    min-width: 25px;
}
ul.pageRightOptions {
    float: right;
    list-style: outside none none;
    margin: 0;
    padding: 0;
}
#resetBttnContainer {
    text-align: right;
    vertical-align: middle;
    font-style: normal;
    color: #000099;
}
#resetBttnContainer {
    margin-top: -18px;
    padding-bottom: 10px;
    color: #2b9af3 !important;
    margin-top: 0px;
    padding-bottom: 0;
    float: right;
    padding-right: 2px;
}
#addFilters1 {
    display: inline;
    cursor: pointer;
    background: url(http://localhost/colgate_hills/images/save_active.png) no-repeat scroll 0 0 / 15px auto;
    padding-right: 16px;
}
#filtersApplied label{
	margin-bottom:0px !important;
}
#noOfRecordsPerPage {
    vertical-align: middle;
}
</style>
<script>
function saveFiltersLayout(){
	$(".modal-body").load('http://localhost/hmvc/organizations/add_org_saved_filters');
}
</script>
<div id="orgsListing">
	<table class="table table-hover">
		<tbody>
			<tr>
				<th width="2%;">
				<div class="displayBlock">
						<input type="checkbox">
					</div>
				</th>
				<th colspan="3">
					Select All
					<div id="filtersApplied">
					<?php 
									if(!empty($filtersApplied)){
										//echo '<div id="filtersApplied" class="tooltip-demo tooltop-bottom">';
										echo '<span class="filterSections"><strong>Results Refined By:</strong> <label id="profTypeText" style="font-weight: normal !important;">&nbsp;</label> '.$filtersApplied.'</span> | ';
										echo '<div id="resetBttnContainer"><a href="#" onclick="resetFilters();">Reset Filters</a><label class="tooltip-demo tooltop-bottom" id="resetBttn" onclick="resetFilters();"><a href="#" class="tooltipLink" rel="tooltip" title="Reset Filters">&nbsp;</a></label></div>';
										echo '<div id="addFilters" onclick="saveFiltersLayout();" style="display: -webkit-inline-box;color: #000099;"><a href="#" rel="tooltip" title="Save all active filter selections"><div id="addFilters1" ></div></a>&nbsp;<a href="#" data-toggle="modal" data-target="#myModal">Save Filters</a></div>&nbsp;&nbsp;';
										//echo '</div>';
										
									}else if(!empty($savedQueryFilterApplied)){
										//echo '<div id="filtersApplied" class="tooltip-demo tooltop-bottom">';
										echo '<span class="filterSections"><strong>Results Refined By:</strong> <label id="profTypeText" style="font-weight: normal !important;">&nbsp;</label> '.$savedQueryFilterApplied.'</span> | <div style="display: inline;color: #000099;">'.$savedFilterName.'</div>';
										echo '<div id="resetBttnContainer"><a href="#" onclick="resetFilters();">Reset Filters</a><label class="tooltip-demo tooltop-bottom" id="resetBttn" onclick="resetFilters();"><a href="#" class="tooltipLink" rel="tooltip" title="Reset Filters">&nbsp;</a></label></div>';
										echo '&nbsp;&nbsp;';
										//echo '</div>';
									}
									
								?>
					</div>
					<div class="countKolMsgContainer">
									<label id="countMsg"><div id="countMsg">Showing 1 to 10 of <?php echo $orgsCount; ?> </div></label>								
								</div>
				</th>
			</tr>
			<tbody style="font-weight: 100">
			<?php /* Start foreach loop for organization listing */
			$evenOrOddRow	= true;
			foreach($arrOrganiations as $org){
				if($evenOrOddRow){
					$evenOrOddRow	= false;
				}else{
					$evenOrOddRow	= true;
				}
			?>
			<tr class="<?php echo ($evenOrOddRow)?'evenRow':'oddRow';?>">
				<td width="2%;">
					<label><input type="checkbox"></label>
				</td>
				<td width="5%;"><div class="defaultProfileIcon"></div></td>
				<td width="100%;">
					<div class="displayBlock">
							<a></a>
						</div>
						<div class="displayBlock"><a href="<?php echo base_url();?>organizations/view/<?php echo $org['id'];?>"><b><?php echo $org['name']?></b></a></div>
			        	<div class="displayBlock">City,State,,country</div>
			        	<div class="displayBlock"><?php echo $org['type']?></div>
				</td>
				<td width="40%;">
				<ul class="pageRightOptions" style="width:120px;">
				<li>
					 <button type="button" class="btn custom-btn btn-info" style="float: right;">Request</button>
			    </li>          
			    <li>            
			    <?php if(($GLOBALS['permissions'][$module_id]['delete'])==1){?>
			                <span class="glyphicon glyphicon-remove-circle"></span>
			                <?php }?>
			                <?php if(($GLOBALS['permissions'][$module_id]['edit'])==1){?>
			                <span class="glyphicon glyphicon-edit"></span>
			                <?php }?>
			                
			                <!-- <span class="glyphicon glyphicon-edit"></span> -->
							<div style="float: right;"><a href="<?php echo base_url();?>organizations/add_org/<?php echo $org['id'];?>" class="tooltipLink" rel="tooltip" data-original-title="Edit"><span class="glyphicon glyphicon-edit"></span> </a></div>
				</li></td>
			</tr>
			<?php }
			/* End foreach loop */ ?>
			<tr class="searchPagination" style="background-color: white;">
			<td colspan="<?php echo ($viewType=='list')?'7':'4';?>">
				<?php 
				if($viewType=='list'){?>
					 <select id="noOfRecordsPerPage" name="noOfRecordsPerPage" onchange="updateRecordsPerPage('list')">
					<?php 
				}else{?>
				 <select id="noOfRecordsPerPage" name="noOfRecordsPerPage" onchange="updateRecordsPerPage('main')">	
				<?php
				} 
				$arrPaginationValues	= explode(',',PAGINATION_VALUES);
				foreach($arrPaginationValues as $key =>$value){
					if($value==$this->ajax_pagination->per_page){
						echo '<option value="'.$value.'" selected="selected">'.$value.'</option>';
					}else{
						echo '<option value="'.$value.'" >'.$value.'</option>';
					}
				}
				echo '</select> Records Per Page ';
			?>
			<?php
				$config['first_link'] = 'First';
				$config['div'] = 'searchResultsContainer'; //Div tag id
				$urlPrfix="";
				if(1 === 1)//$searchType=='simple')
					$urlPrfix="filter_search_organizations";
				$config['base_url'] = base_url()."organizations/".$urlPrfix;
				$config['total_rows'] = $orgsCount;
				$config['per_page'] = $this->ajax_pagination->per_page;
				$config['postVar'] = 'page';
				
				$this->ajax_pagination->initialize($config);
				print $this->ajax_pagination->create_links();
			?>		
			</td>
		</tr>
		</tbody>
		</tbody>
		
	</table>
</div>

<!-- 
<div class="displayBlock">
						<input type="checkbox">Select All
					</div>
<div>
						Refined By:&nbsp;<a href="#" onclick="return false;"
							rel="tooltip" data-original-title="All Organizations">View Type</a>&nbsp;|&nbsp;
						<span class="glyphicon glyphicon-refresh" title="Reset Filters"></span>
						Reset Filter
					</div>

 -->
 
 <!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body"></div>
    </div>

  </div>
</div>
 