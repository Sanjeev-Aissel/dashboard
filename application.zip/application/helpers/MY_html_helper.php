<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Extending the HTML Helpers
 *
 *
 * @package		application.helpers
 * @author		Vinod S.T.
 * @since		Version 1.0
 */

// ------------------------------------------------------------------------


/**
 * Pr
 *
 * Prints the ARRAY in the Human Readable format by printing withint the PRE tags
 *
 * @access	public
 * @param	array
 * @return	none
 */
if ( ! function_exists('pr'))
{
	function pr($data)
	{
		echo '<pre>';	print_r($data);		echo '</pre>';
	}
}


// ------------------------------------------------------------------------

if ( ! function_exists('nf'))
{
	function nf($first_name,$middle_name,$last_name)
	{
		// get the superobject
		$CI =& get_instance();
		
		// call the session library
		$nameOrder = $CI->session->userdata('name_order');//$_SESSION['name_order'];
		switch($nameOrder){
			case 1: return $first_name." ".$last_name;
				break;
			case 2: 
				if($last_name == '')
					return $first_name;
				else
					return $last_name.", ".$first_name;
				break;
			case 3: return $first_name." ".$middle_name." ".$last_name;
				break; 
		}
	}
}


if ( ! function_exists('userLogData'))
{
	function userLogData()
	{
		// get the superobject
		$CI =& get_instance();
		
			$arrLogs = array();
			$arrLogs['user_id'] = $CI->session->userdata('user_id');
			$arrLogs['created_on'] = date("Y-m-d H:i:s");
			$arrLogs['agent'] = $_SERVER['HTTP_USER_AGENT'];
			$arrLogs['ip_address'] = $_SERVER['ip_address'];
			return $arrLogs;
	}
}

if(! function_exists('email_config_initializer'))
{
	function email_config_initializer($email_for){
		switch($email_for){
			case 'optinout':
				$config['protocol']  = OPTINOUT_PROTOCOL;
				$config['smtp_host'] = OPTINOUT_HOST;
				$config['smtp_port'] = OPTINOUT_PORT;
				$config['smtp_user'] = OPTINOUT_USER;
				$config['smtp_pass'] = OPTINOUT_PASS;
				$config['mailtype']	 = 'html';
				$config['newline'] = "\r\n";
				$config['crlf'] = "\n";
				$config['charset'] = 'utf-8';
				return $config;
			break;
			case 'profile_request':
				$config['protocol']  = PROFILE_REQUEST_PROTOCOL;
				$config['smtp_host'] = PROFILE_REQUEST_HOST;
				$config['smtp_port'] = PROFILE_REQUEST_PORT;
				$config['smtp_user'] = PROFILE_REQUEST_USER;
				$config['smtp_pass'] = PROFILE_REQUEST_PASS;
				$config['mailtype']	 = 'html';
				return $config;
			break;
			case 'alerts':
				$config['protocol']  = PROTOCOL;
				$config['smtp_host'] = HOST;
				$config['smtp_port'] = PORT;
				$config['smtp_user'] = USER;
				$config['smtp_pass'] = PASS;
				$config['mailtype']	 = 'html';
				return $config;
			break;
			case 'support':
			    $config['protocol']  = SUPPORT_PROTOCOL;
			    $config['smtp_host'] = SUPPORT_HOST;
			    $config['smtp_port'] = SUPPORT_PORT;
			    $config['smtp_user'] = SUPPORT_USER;
			    $config['smtp_pass'] = SUPPORT_PASS;
			    $config['mailtype']	 = 'html';
			    return $config;
			    break;
			case 'notification':
			    $config['protocol']  = NOTIFICATION_PROTOCOL;
			    $config['smtp_host'] = NOTIFICATION_HOST;
			    $config['smtp_port'] = NOTIFICATION_PORT;
			    $config['smtp_user'] = NOTIFICATION_USER;
			    $config['smtp_pass'] = NOTIFICATION_PASS;
			    $config['mailtype']	 = 'html';
			    return $config;
			    break;
		}
	}	
}