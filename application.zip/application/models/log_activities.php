<?php
	/**
 		* @Description : This is Model for 'Log Activities'
		* @Author : Sanjeev K, Kishan Ravindra (00001111)
		* @Since : 3.6
		* @Package : application.models
		* @Created : 30-09-2016
		* @Refactored : 01-08-2017
	**/
class Log_activities extends Model{
	
	//Constructor
	function Log_activities(){
		parent::Model();
		$this->load->model('common_helpers');
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : getLogActivities()
	 * @Action : returns records of 'Log Activities' Entity
	 */
	function getLogActivities($limit = null, $startFrom = null, $doCount = null, $sidx = '', $sord = '', $where = ''){
		$startDate = $where['startDate'];
		$endDate = $where['endDate'];
		$this->db->select('log_activities.id as log_id,log_activities.url,log_activities.module, log_activities.controller, log_activities.ip_address, log_activities.created_on, log_activities.created_by, log_activities.status, log_activities.browser, log_activities.os, ip_address_location.cityName, ip_address_location.regionName, ip_address_location.countryName, client_users.first_name, client_users.last_name, client_users.email,clients.name as client_name');
		$this->db->select('log_activities.miscellaneous2,log_activities.miscellaneous1,log_activities.kols_or_org_type,log_activities.kols_or_org_id,log_activities.transaction_id,log_activities.transaction_name,log_activities.description as log_description,log_activities.type as action');
		$this->db->select('CASE WHEN client_users.user_role_id = 1 THEN "User" WHEN client_users.user_role_id = 2 THEN "Manager" WHEN client_users.user_role_id = 3 THEN "Admin" ELSE "Read Only User" END AS user_role',false);
		$this->db->join("ip_address_location","ip_address_location.ipAddress = log_activities.ip_address","left");
		$this->db->join('client_users', 'client_users.id = log_activities.created_by', 'left');
		$this->db->join('clients', 'clients.id = client_users.client_id', 'left');
		$this->db->where('log_activities.module !=', 'client_user_log_activities');
		if($startDate!=0 && $endDate!=0){
			if($startDate == $endDate){
				$whereClause = "(log_activities.created_on LIKE '".$startDate."%')";
			} else {
				$whereClause = "(log_activities.created_on  BETWEEN '".$startDate."' AND '".$endDate."')";
			}
			$this->db->where($whereClause);
		}
		if(!$this->common_helpers->isDataNull($where['clientId'])){
			$this->db->where("(client_users.client_id = ".$where['clientId'].")");
		}
		
		if(!$this->common_helpers->isDataNull($where['username'])){
		    $this->db->like("concat(client_users.first_name,' ',client_users.last_name)", $where['username']);
		}
		if(!$this->common_helpers->isDataNull($where['log_id'])){
		    $this->db->where("(log_activities.id LIKE '%".$where['log_id']."%')");
		}
		if(!$this->common_helpers->isDataNull($where['user_role'])){
		    switch($where['user_role']){
		        case 'User': $roleId = 1;
		        case 'Manager': $roleId = 2;
		        case 'Admin': $roleId = 3;
		        case 'Read Only User': $roleId = 0;
		        
		    }
		    $this->db->where("(client_users.user_role_id LIKE '%".$roleId."%')");
		}
		if(!$this->common_helpers->isDataNull($where['email'])){
			$this->db->where("(client_users.email LIKE '%".$where['email']."%')");
		}
		if(!$this->common_helpers->isDataNull($where['client_name'])){
		    $this->db->where("(clients.name LIKE '%".$where['client_name']."%')");
		}
		if(!$this->common_helpers->isDataNull($where['action'])){
		    $this->db->where("(log_activities.type LIKE '%".$where['action']."%')");
		}
		if(!$this->common_helpers->isDataNull($where['kols_or_org_type'])){
		    $this->db->where("(log_activities.kols_or_org_type LIKE '%".$where['kols_or_org_type']."%')");
		}
		if(!$this->common_helpers->isDataNull($where['kols_or_org_id'])){
		    $this->db->where("(log_activities.kols_or_org_id LIKE '%".$where['kols_or_org_id']."%')");
		}
		if(!$this->common_helpers->isDataNull($where['transaction_id'])){
		    $this->db->where("(log_activities.transaction_id LIKE '%".$where['transaction_id']."%')");
		}
		if(!$this->common_helpers->isDataNull($where['created_on'])){
			$this->db->where("(log_activities.created_on LIKE '%".$where['created_on']."%')");
		}
		if(!$this->common_helpers->isDataNull($where['os'])){
			$this->db->where("(log_activities.os LIKE '%".$where['os']."%')");
		}
		if(!$this->common_helpers->isDataNull($where['browser'])){
			$this->db->where("(log_activities.browser LIKE '%".$where['browser']."%')");
		}
		if(!$this->common_helpers->isDataNull($where['status'])){
			$this->db->where("(log_activities.status LIKE '%".$where['status']."%')");
		}
		if(!$this->common_helpers->isDataNull($where['cityName'])){
			$this->db->where("(ip_address_location.cityName LIKE '%".$where['cityName']."%')");
		}
		if(!$this->common_helpers->isDataNull($where['regionName'])){
			$this->db->where("(ip_address_location.regionName LIKE '%".$where['regionName']."%')");
		}
		if(!$this->common_helpers->isDataNull($where['countryName'])){
			$this->db->where("(ip_address_location.countryName LIKE '%".$where['countryName']."%')");
		}
		if(!$this->common_helpers->isDataNull($where['miscellaneous2'])){
		    $this->db->where("(log_activities.miscellaneous2 LIKE '%".$where['miscellaneous2']."%')");
		}
		if(!$this->common_helpers->isDataNull($where['log_description'])){
		    $this->db->where("(log_activities.description LIKE '%".$where['log_description']."%')");
		}
		if(!$this->common_helpers->isDataNull($where['transaction_name'])){
		    $this->db->where("(log_activities.transaction_name LIKE '%".$where['transaction_name']."%')");
		}
				
		if($doCount){
			$this->db->distinct();
			$count=$this->db->count_all_results('log_activities');
			return $count;
		} else {
			if(!$this->common_helpers->isDataNull($sidx) && !$this->common_helpers->isDataNull($sord)){
				switch($sidx){
				    case 'username' : $this->db->order_by("concat(client_users.first_name,' ',client_users.last_name)",$sord);
					break;
					case 'log_id' : $this->db->order_by("log_activities.id",$sord);
					break;
					case 'user_role' : $this->db->order_by("client_users.user_role_id",$sord);
					break;
					case 'email' : $this->db->order_by("client_users.email",$sord);
					break;
					case 'client_name' : $this->db->order_by("clients.name",$sord);
					break;
					case 'action' : $this->db->order_by("log_activities.type",$sord);
					break;
					case 'kols_or_org_type' : $this->db->order_by("log_activities.kols_or_org_type",$sord);
					break;
					case 'kols_or_org_id' : $this->db->order_by("log_activities.kols_or_org_id",$sord);
					break;
					case 'transaction_id' : $this->db->order_by("log_activities.transaction_id",$sord);
					break;
					case 'created_on' : $this->db->order_by("log_activities.created_on",$sord);
					break;
					case 'os' : $this->db->order_by("log_activities.os",$sord);
					break;
					case 'browser' : $this->db->order_by("log_activities.browser",$sord);
					break;
					case 'status' : $this->db->order_by("log_activities.status",$sord);
					break;
					case 'cityName' : $this->db->order_by("ip_address_location.cityName",$sord);
					break;
					case 'regionName' : $this->db->order_by("ip_address_location.regionName",$sord);
					break;
					case 'countryName' : $this->db->order_by("ip_address_location.countryName",$sord);
					break;
					case 'transaction_name' : $this->db->order_by("log_activities.url",$sord);
					break;
					case 'log_description' : $this->db->order_by("log_activities.description",$sord);
					break;
					case 'miscellaneous2' : $this->db->order_by("log_activities.miscellaneous2",$sord);
					break;
				}
			}
			$this->db->order_by('log_activities.id', 'DESC');
			$arrLogDetails = $this->db->get('log_activities',$limit,$startFrom);
			return $arrLogDetails;
		}
	}
}