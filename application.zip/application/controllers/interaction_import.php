<?php
/**
 * This is Controller is for Call Plans Uploading 
 *
 * @author Vinod R H
 * @since
 * @package application.controllers
 * @created on 26-06-2017
 */
//error_reporting(E_ALL);
class Interaction_import extends Controller{
	
	function Interaction_import(){
		parent::Controller();
		$this->load->model("import_interaction");
		$this->load->library('form_validation');
		$this->load->library('upload');
		$this->load->model('interaction');
	}
	
	function add($type=''){
		//form exection and upload script
		if(isset($_POST['interaction_upload'])){
			$error = array();
			
			//print_r($_FILES);exit;
			$this->form_validation->set_rules('afile', 'Document', 'callback_file_selected');
			
			if ($this->form_validation->run() == FALSE) {
				$this->load->view('interaction_import/home');
			}else{
				$file_type = explode('.', $_FILES["afile"]['name']);
					if($file_type[1]=='xls'){
						$folder_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/interactions/";
						$file_info = $_FILES["afile"]['name'];
						$file_target_path = $folder_path.$file_info;
						//echo $file_target_path;exit;
							if(move_uploaded_file($_FILES['afile']['tmp_name'],$file_target_path)){
								$data['result'] = $this->_upload($file_info,$type);
								//echo 'Info'.$result;
								//exit;
								$this->load->view('interaction_import/home', $data);
							}else{
								$data['error'] = 'Failed to upload file!';
								$this->load->view('interaction_import/home', $data);
							}
					}else{
						$data['error'] = 'File formate should be .xls extension!';
						$this->load->view('interaction_import/home', $data);
						
					}
			}
			
				
		}else{
			$this->load->view('interaction_import/home');
		}
	}
	
	function file_selected(){
		$this->form_validation->set_message('file_selected', 'Please select file.');
		if (empty($_FILES['afile']['name'])) {
			return false;
		}else{
			return true;
		}
	}
	
	function _upload($file_info,$type=''){
		//error_reporting(E_ALL);
		ini_set("max_execution_time",7200);
		ini_set('memory_limit', '-1');
		$this->load->plugin("excelreader/reader2");
		//Uploaded file path
		$folder_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/interactions/";
		$file_path = $file_info;
		$file = $folder_path.$file_path;
		$clientId = 17;
		$reader	=	new Spreadsheet_Excel_Reader($file, true, 'utf-8');
		$info = 'interaction processing started<br />';
		foreach ($reader->boundsheets as $k=>$sheet){
			$info .= 'sheet name '.$sheet['name'].' processing started<br />';
				if (strcasecmp(trim($sheet['name']),'Interaction Details')==0) {
						$row = 1;
						if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"Interaction #")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Interaction Date")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Interaction Category")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"interaction_mode_id")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Added By")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Brand")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"Topic")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][8]),"Notes")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][9]),"Objective_ID")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][10]),"Objective Name")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][11]),"Description")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][12]),"Plan Name")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][13]),"Start Date")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][14]),"End Date")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][15]),"Description")!=0||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][16]),"Status")!=0){
									$info .= 'Interaction header formate is incorrect <br />';
						}else{
							$info .= 'Interaction header formate is correct <br />';
							for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
								$userName = trim($reader->sheets[$k]["cells"][$row][5]);
								$userId = $this->import_interaction->getUserDetails($userName); //Check user is exit else add and get user id
								
										$interStartDate=date_create(trim($reader->sheets[$k]["cells"][$row][2]));
										
										$objIdAssociate = '';
										$planIdAssociate = '';
										if(!empty(trim($reader->sheets[$k]["cells"][$row][9]))){
											
											//Objective Details Check
											$arrObjDetails = array();
											$arrObjDetails['unique_id'] = trim($reader->sheets[$k]["cells"][$row][9]);
											$arrObjDetails['name'] = trim($reader->sheets[$k]["cells"][$row][10]);
											$arrObjDetails['description'] = trim($reader->sheets[$k]["cells"][$row][11]);
											$arrObjDetails['client_id'] = $clientId;
											$arrObjDetails['created_by']=$userId;
											$arrObjDetails['created_on']		=	date('Y-m-d H:i:s');
											$objId = $this->import_interaction->getObjectiveId($arrObjDetails);
											$objIdAssociate = $objId;
										}
										//Plan Details Check
										if(!empty(trim($reader->sheets[$k]["cells"][$row][12]))){
											$arrPlanDetails = array();
											$arrPlanDetails['plan_name'] = trim($reader->sheets[$k]["cells"][$row][12]);
											$arrPlanDetails['plan_description'] = trim($reader->sheets[$k]["cells"][$row][15]);
											$startDate=date_create(trim($reader->sheets[$k]["cells"][$row][13]));
											$arrPlanDetails['plan_start'] = date_format($startDate,"Y-m-d");
											$endDate=date_create(trim($reader->sheets[$k]["cells"][$row][14]));
											$arrPlanDetails['plan_end'] = date_format($endDate,"Y-m-d");
											$arrPlanDetails['client_id'] = $clientId;
											$arrPlanDetails['created_by']=$userId;
											$arrPlanDetails['created_at']		=	date('Y-m-d H:i:s');
											$planId = $this->import_interaction->getPlanId($arrPlanDetails);
											$planIdAssociate = $planId;
										}
										
										//plan Objective association
										if(!empty($objIdAssociate) && !empty($planIdAssociate)){
											$arrPlanObjAssociate = array();
											$arrPlanObjAssociate['plan_id'] = $planIdAssociate;
											$arrPlanObjAssociate['objective_id'] = $objIdAssociate;
											$arrPlanObjAssociate['created_at'] = date('Y-m-d H:i:s');
											$planAssoId = $this->import_interaction->savePlanObjective($arrPlanObjAssociate);
										}
											
										$arrInteractionDetails = array();
										$arrInteractionDetails['generic_id']= trim($reader->sheets[$k]["cells"][$row][1]);
										$arrInteractionDetails['created_by']=$userId;
										$arrInteractionDetails['client_id']=$clientId;
										$arrInteractionDetails['date'] = date_format($interStartDate,"Y-m-d");
										$arrInteractionDetails['mode']=trim($reader->sheets[$k]["cells"][$row][4]);
										$arrInteractionDetails['location']='Other';
										$arrInteractionDetails['notes']=trim($reader->sheets[$k]["cells"][$row][8]);
										$arrInteractionDetails['created_by']=$userId;
										$arrInteractionDetails['created_on']=date('Y-m-d H:i:s');
										$arrInteractionDetails['grouping']=trim($reader->sheets[$k]["cells"][$row][3]);
										$arrInteractionDetails['location_type']= 0;
										$arrInteractionDetails['employee_id'] = $userId;
										$arrInteractionDetails['is_org_interaction']= 0;
										$arrInteractionDetails['plan_name']= 1;
										$arrInteractionDetails['plan_name']= $planIdAssociate;
										$interactionId = $this->import_interaction->saveInteraction($arrInteractionDetails);
										
				// 						$arrInterTypes = $this->import_interaction->getInteractionTypes();
										//array_search()
							
						}
					}
				}else if (strcasecmp(trim($sheet['name']),'Associated KTLs')==0) {
					$row = 1;
					if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"KTL PIN")!=0 ||
							strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Interaction #")!=0 ||
							strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"kol_id")!=0 ||
							strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"region")!=0
							){
								$info .= 'Interaction header formate is incorrect <br />';
					}else{
						$info .= 'Interaction header formate is correct <br />';
						$associated	= 0;
						$skipped	= 0;
						for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
							$kolPIN	= trim($reader->sheets[$k]["cells"][$row][1]);
							$kolRegion	= trim($reader->sheets[$k]["cells"][$row][4]);
							$kolId	= trim($reader->sheets[$k]["cells"][$row][3]);
							$genericId	= trim($reader->sheets[$k]["cells"][$row][2]);
							$interactionId = $this->import_interaction->getInteractionIdByGenericId($genericId);
							//echo $this->db->last_query();exit;
							//echo $kolId.'-'.$interactionId.'-'.$genericId.'<br />';
							if($kolId>0 && $interactionId>0){
								$arrAttendees	= array();
								$arrAttendees['interaction_id']	= $interactionId;
								$arrAttendees['kol_id']	= $kolId;
								if($this->interaction->saveInteractionAttendis($arrAttendees)){
									$associated++;
								}else{
									$skipped++;
								}
							}else{
								$skipped++;
							}
						}
						$info .= 'KTLs associated ='.$associated.' <br />';
						$info .= 'KTLs not associated ='.$skipped.' <br />';
					}
				}else if (strcasecmp(trim($sheet['name']),'Topics')==0) {
					$row = 1;
					if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"Interaction #")!=0 ||
							strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Brand")!=0 ||
							strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Topic")!=0
							){
								$info .= 'Interaction header formate is incorrect <br />';
					}else{
						$info .= 'Interaction header formate is correct <br />';
						$associated	= 0;
						$skipped	= 0;
						$arrInterTypes = $this->import_interaction->getInteractionTypes();
						//pr($arrInterTypes);
						for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
							$genericId	= trim($reader->sheets[$k]["cells"][$row][1]);
							$interactionId = $this->import_interaction->getInteractionIdByGenericId($genericId);
							$brandId	= trim($reader->sheets[$k]["cells"][$row][2]);
							$topics	= trim($reader->sheets[$k]["cells"][$row][3]);
							$arrTopics	= explode(';',$topics);
							foreach($arrTopics as $topicsIndex=>$topicsValue){
								$topicsValue	= str_replace(' / ','/',$topicsValue);
								//echo $genericId.'-'.$interactionId.'-'.$brandId.'-'.$topicsValue.'<br />';
								$typeValue	= '';
								$topicValue	= '';
								$typeValueId	= '';
								$topicValueId	= '';
								foreach($arrInterTypes as $arrInterTypesKey=>$arrInterTypesValue){
									//echo $arrInterTypesValue.'<br />';
									$arrTypeTopics	= explode($arrInterTypesValue,$topicsValue);
									if(sizeof($arrTypeTopics)>1){
										$typeValue	= $arrInterTypesValue;
										$typeValueId	= $arrInterTypesKey;
										$topicValue	= trim($arrTypeTopics[1],"/");
										$topicValueId	= $this->import_interaction->saveTopic($topicValue);
									}
								}
								//echo $typeValueId.' - Type:'.$typeValue.'- topic:'.$topicValue.'<br />';
								if($interactionId>0 && $typeValueId>0){
									$arrInteractionTopicAssociation	= array();
									$arrInteractionTopicAssociation['interaction_id']	= $interactionId;
									$arrInteractionTopicAssociation['product_id']	= $brandId;
									$arrInteractionTopicAssociation['interaction_type']	= $typeValueId;
									$arrInteractionTopicAssociation['topic_id']	= $topicValueId;
									$this->interaction->saveInteractionTopicDetail($arrInteractionTopicAssociation);
								}
							}
						}
					}
				}else{
					$info .= 'sheet name '.$sheet['name'].' mismatched<br />';
				}
			$info .= 'sheet name '.$sheet['name'].' processing completed<br />';
		} //loop
		$info .= 'interaction processing completed<br />';
		return $info;
	}
	
}
