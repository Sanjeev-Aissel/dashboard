<?php
class interaction extends CI_Model {
	function getAllGroupings($clientId,$type='kol') {
		$arrModes = array();
		$this->db->select('interaction_grouping_client_association.id,interaction_grouping.name,interaction_grouping_client_association.client_id');
		$this->db->join('interaction_grouping_client_association','interaction_grouping.id = interaction_grouping_client_association.interaction_grouping_id','left');
		$this->db->where('interaction_grouping_client_association.client_id',$clientId);
		if($type=='org'){
			$this->db->where('interaction_grouping.org_active',1);
		}
		$arrModeResults = $this->db->get('interaction_grouping');
		foreach ($arrModeResults->result_array() as $row) {
			$arrModes[] = $row;
		}
		return $arrModes;
	}
	function getAllModesOfClient($clientId,$orgType) {
		$arrModes = array();
		$this->db->select('interactions_modes_client_association.id,interactions_modes.name,interactions_modes_client_association.client_id');
		$this->db->join('interactions_modes_client_association','interactions_modes.id = interactions_modes_client_association.interactions_modes_id','left');
		$this->db->where('interactions_modes_client_association.client_id',$clientId);
		if(!empty($orgType)){
			$this->db->where('interactions_modes.org_active',1);
		}
		$arrModeResults = $this->db->get('interactions_modes');
		foreach ($arrModeResults->result_array() as $row) {
			$arrModes[$row['id']] = $row;
		}
		return $arrModes;
	}
	function getDiscussionTypeByProductIds($arrProducts){
		if(!HILLS_SPECIFIC){
			$arrProductId = array();
			foreach ($arrProducts as $arrProduct){
				$arrProductId[] = $arrProduct['id'];
			}
			$whereIn =  implode(",",$arrProductId);
		}
		$this->db->select('distinct(interaction_type_by_product.type_id),interaction_types.name');
		$this->db->join('interaction_types','interaction_types.id = interaction_type_by_product.type_id','left');
		if(!HILLS_SPECIFIC){
			$this->db->where_in('interaction_type_by_product.product_id',$whereIn);
		}
		$query = $this->db->get('interaction_type_by_product');
		foreach ($query->result_array() as $row) {
			$arrResult[] = $row;
		}
		return $arrResult;
	}
	function getTopicsByDiscussionTypesAndProductIds($arrProducts,$arrDiscussionTypes){
		$arrProductId = array();
		$arrDiscussionTypeId = array();
		foreach ($arrProducts as $arrProduct){
			$arrProductId[] = $arrProduct['id'];
		}
		$whereInProduct =  implode(",",$arrProductId);
		
		foreach ($arrDiscussionTypes as $arrDiscussionType){
			$arrDiscussionTypeId[] = $arrDiscussionType['type_id'];
		}
		$whereInDiscussionType =  implode(",",$arrDiscussionTypeId);
		
		
		$arrTopics = array();
		$this->db->select("distinct(interaction_topics.id),interaction_topics.name");
		$this->db->join('interaction_topics', 'interaction_topics.id=interaction_topics_by_type.topic_id', 'left');
		$this->db->where_in('interaction_topics_by_type.product_id ', $whereInProduct);
		//$this->db->where_in('interaction_topics_by_type.type_id ', $whereInDiscussionType);
		$this->db->where('interaction_topics.status ', 1);
		$this->db->order_by("interaction_topics.name");
		$arrResults = $this->db->get('interaction_topics_by_type');
		foreach ($arrResults->result_array() as $row) {
			//check if the topic is 'Other' and add it last in the list
			if($row['name'] != 'Other'){
				$arrTopics1[] = $row;
			}else{
				$arrTopics2[] = $row;
			}
		}
		if(!empty($arrTopics2)){
			$arrTopics = array_merge($arrTopics1,$arrTopics2);
		}else{
			$arrTopics = $arrTopics1;
		}
		//print $this->db->last_query();
		return $arrTopics;
	}
	
	function getKolInteractions($clientId, $kolId, $userId, $arrFilters, $limit, $startFrom, $doCount = null, $sidx = '', $sord = '', $where = '',$ipad=false) {
		$client_id = $this->session->userdata('client_id');
		if ((!empty($arrFilters['manager_id'])) && (isset($arrFilters['manager_id'])) && ($arrFilters['manager_id']!='null')){
			$users=$this->common_helper->getManagerAlignedUsers($arrFilters['manager_id']);
		}	
			$arrInteractionDetails = array();
			//		if($kolId!=null && $kolId!=-1)
				//			$this->db->where('interactions.kol_id',$kolId);
			$isAttendiesJoined = false;
			if ($kolId != null && $kolId != -1 && $kolId != 0) {
				$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
				$isAttendiesJoined = true;
				if (isset($arrFilters['interactionFor']) && ($arrFilters['interactionFor'] == 'org')){
					$this->db->where('interactions_attendees.org_id', $kolId);
				}else{
					$this->db->where('interactions_attendees.kol_id', $kolId);
				}
			}
			//Security: within profile - all, track-user: his interactions, track-manager: all interactions
			if ($userId != 0 && ($kolId == null || $kolId == 0 || $kolId == -1)){
				$this->db->where('interactions.created_by', $userId);
			}else{
				
			}
// 			if ($clientId != INTERNAL_CLIENT_ID){
				$this->db->where('interactions.client_id', $clientId);
// 			}
			//		$this->db->select("interactions.*,interactions_modes.name as mode_name,interactions_topics.name as topic_name,interactions_brands.name as brand_name,kols.salutation,kols.last_name,kols.middle_name,kols.first_name,interactions_roles.name as role_name,interactions_categories.name as category_name,specialties.specialty as area_name,objectives.name as objective_name");
			//$this->db->select("interactions.*,interactions_modes.name as mode_name,client_users.first_name,client_users.last_name,cities.city,regions.region,interaction_mirf.id as mirf_id ");
			$nameFormatOrder = $this->common_helper->get_name_format_order_simple('kols');
			$nameOrderFormat = $this->common_helper->get_name_format('kols.first_name', 'kols.middle_name', 'kols.last_name');
			$this->db->select("interactions.id,interactions.client_id,interactions.data_type_indicator,interactions.date,interactions.created_by,interactions.quality_interaction,interactions.save_later,interactions.generic_id,interactions_modes.name as mode_name,client_users.first_name,client_users.last_name,cities.city,states.name as region,interactions_attendees.kol_id,kols.salutation,kols_client_visibility.unique_id,kols.first_name as kol_first_name,kols.middle_name as kol_middle_name,kols.last_name as kol_last_name,concat($nameFormatOrder) as kol_full_name,kols.deleted_by as kol_deleted,products.name as product,interaction_types.name AS type,interaction_topics.name AS topic,organizations.id as org_id,organizations.name as org_name,interactions_modes.name as mode_name, interaction_grouping.name as grouping_name, interaction_location_types.name as interaction_location_type_name,interactions.mirf_case_num,emp.first_name as emp_first_name,emp.last_name as emp_last_name,specialties.specialty AS specialty,interactions.created_on,kols.mdm_id as mdm_id,interactions.employee_id,interactions.total_attendies",false);
			if($nameFormatOrder!=''){
			$this->db->select("case WHEN organizations.id is null THEN concat($nameFormatOrder) else organizations.name END as kol_org_name",false);
			}else{
				$this->db->select("organizations.name END as kol_org_name");
			}
			$this->db->join('interactions_modes_client_association', 'interactions.mode = interactions_modes_client_association.id', 'left');
			$this->db->join('interactions_modes','interactions_modes.id = interactions_modes_client_association.interactions_modes_id','left');
			
			$this->db->join('client_users', 'client_users.id = interactions.created_by', 'left');
			$this->db->join('client_users as emp', 'emp.id = interactions.employee_id', 'left');
			$this->db->join('cities', 'cities.CityId = interactions.city_id', 'left');
			$this->db->join('states', 'states.id = interactions.state_id', 'left');
			if ($kolId == null || $kolId == 0 || $kolId == -1){
				if ($clientId != INTERNAL_CLIENT_ID){
					if($this->session->userdata('user_role_id')==ROLE_MANAGER){
						$group_names = explode(',', $this->session->userdata('group_names'));
						$this->db->join ( 'countries', 'countries.CountryId = interactions.country_id', 'left' );
						$this->db->where_in ( 'countries.GlobalRegion', $group_names);
					}
				}
			}
			//       $this->db->join('interactions_modes', 'interactions.mode = interactions_modes.id', 'left');
			$this->db->join('interaction_grouping_client_association', 'interactions.grouping = interaction_grouping_client_association.id', 'left');
			$this->db->join('interaction_grouping', 'interaction_grouping_client_association.interaction_grouping_id = interaction_grouping.id', 'left');
			$this->db->join('interaction_location_types_client_association', 'interaction_location_types_client_association.id = interactions.location_category', 'left');
			$this->db->join('interaction_location_types', 'interaction_location_types.id = interaction_location_types_client_association.interaction_location_type_id', 'left');
			$this->db->where("client_users.id IS NOT NULL");
			if($client_id !== INTERNAL_CLIENT_ID){
				$this->db->where("((kols.id IS NOT NULL AND kols_client_visibility.client_id = '".$clientId."') OR organizations.id IS NOT NULL)",'',false);
			}else{
				$this->db->where("(kols.id IS NOT NULL OR organizations.id IS NOT NULL)",'',false);
			}
			if ($kolId != null && $kolId != -1) {
				if ($arrFilters['end_date'] != null && $arrFilters['start_date'] != null) {
					$this->db->where("interactions.date BETWEEN '" . $arrFilters['start_date'] . "' AND '" . $arrFilters['end_date'] . "'");
				} else if ($startDate != null) {
					$this->db->like('interactions.date', $startDate);
				}
			} else {
				
				if ($arrFilters['end_date'] != null && $arrFilters['start_date'] != null) {
						$this->db->where("interactions.date BETWEEN '" . $arrFilters['start_date'] . "' AND '" . $arrFilters['end_date'] . "'");
				}else if ($startDate != null) {
					$this->db->like('interactions.date', $startDate);
				}
			}
			//Joins added to get attendies
			if ($isAttendiesJoined == false) {
				$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
				$isAttendiesJoined = true;
			}
			$this->db->join('kols_client_visibility', 'interactions_attendees.kol_id = kols_client_visibility.id ', 'left');
			$this->db->join('kols', 'kols_client_visibility.kol_id = kols.id ', 'left');
			$this->db->join('organizations', 'interactions_attendees.org_id = organizations.id ', 'left');
			$isJoined = false;
			
			
			if ($arrFilters['objective_id'] != '' && $arrFilters['objective_id'] != 0 && !empty(array_filter($arrFilters['objective_id']))) {
				$this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id=interactions.id', 'left');
				$this->db->where_in('interactions_discussion_topic_mapped_data.interaction_type', $arrFilters['objective_id']);
				$isJoined = true;
			}
			
			if ($arrFilters['product_id'] != '' && $arrFilters['product_id'] != 0) {
				if ($isJoined == false) {
					$this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id=interactions.id', 'left');
					$isJoined = true;
				}
				$this->db->where_in('interactions_discussion_topic_mapped_data.product_id', $arrFilters['product_id']);
			}
			
			if ($arrFilters['topic_id'] != '' && $arrFilters['topic_id'] != 0 && !empty(array_filter($arrFilters['topic_id']))) {
				if ($isJoined == false) {
					$this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id=interactions.id', 'left');
					$isJoined = true;
				}
				$this->db->where_in('interactions_discussion_topic_mapped_data.topic_id', $arrFilters['topic_id']);
			}
			
			if ($arrFilters['org_id'] != '' && $arrFilters['org_id'] != 0) {
				$this->db->where('interactions_attendees.org_id', $arrFilters['org_id']);
			}
			
			if ($arrFilters['subtopic_id'] != '' && $arrFilters['subtopic_id'] != 0) {
				if ($isJoined == false) {
					$this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id=interactions.id', 'left');
					$isJoined = true;
				}
				$this->db->where('interactions_discussion_topic_mapped_data.sub_topic_id', $arrFilters['subtopic_id']);
			}
			
			//To get primary topic details
			if ($isJoined == false) {
				$this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id=interactions.id', 'left');
			}
			$this->db->join('products', 'interactions_discussion_topic_mapped_data.product_id = products.id', 'left');
			$this->db->join('interaction_types', 'interactions_discussion_topic_mapped_data.interaction_type = interaction_types.id', 'left');
			$this->db->join('interaction_topics', 'interactions_discussion_topic_mapped_data.topic_id = interaction_topics.id', 'left');
			
			if ($arrFilters['mode'] != '' && $arrFilters['mode'] != 0) {
				$this->db->where_in('mode', $arrFilters['mode']);
			}
			
			if ($arrFilters['grouping'] != '' && $arrFilters['grouping'] != 0) {
				$this->db->where_in('grouping', $arrFilters['grouping']);
			}
			if (array_filter($arrFilters['user_id']) != '' && array_filter($arrFilters['user_id']) != 0) {
				$this->db->where_in('interactions.created_by', $arrFilters['user_id']);
			}
			//	$this->db->where('org_id',$orgId);
			/* if($startDate!=0 && $endDate!=0){
			 $wherBetween="(YEAR(interactions.date) BETWEEN '$startDate' AND '$endDate' OR YEAR(interactions.date)='0')";
			 $this->db->where($wherBetween);
			 } */
			if ($limit != 'all' && $limit != 0) {
				$this->db->limit($limit, $startFrom);
				//$this->db->limit(1000);
			}
			
			if(!isset($where['is_export']) && $where['is_export'] != true){
				$this->db->group_by('interactions.id');
			}else{
				//         	$this->db->group_by('interactions_discussion_topic_mapped_data.id');
				$this->db->group_by('interactions.id');
			}
// 			$this->db->join('interaction_mirf', 'interaction_mirf.interaction_id=interactions.id', 'left');
			$this->db->join('specialty_client_association', 'specialty_client_association.id = kols.specialty', 'left');
			$this->db->join('specialties', 'specialties.id = specialty_client_association.specialty_id', 'left');
			
			if (isset($where['kol_name'])) {
				$this->db->where("(case WHEN organizations.id is null THEN concat(kols.first_name,' ',CASE WHEN kols.middle_name IS NOT NULL || kols.middle_name!= '' THEN kols.middle_name ELSE '' END,' ',CASE WHEN kols.last_name IS NOT NULL || kols.last_name!= '' THEN kols.last_name ELSE '' END) like '%".$where['kol_name']."%' else organizations.name like '%".$where['kol_name']."%' END)",'',false);
				//$this->db->or_like("organizations.name",$where['kol_name']);
				// $this->db->where("(kols.first_name LIKE '%" . $where['kol_name'] . "%' or kols.middle_name LIKE '%" . $where['kol_name'] . "%' or kols.last_name LIKE '%" . $where['kol_name'] . "%' or organizations.name LIKE '%" . $where['kol_name'] . "%')");
			}
			
			if (isset($where['date'])) {
				/* $dateLength = strlen($where['date']);
				 if($dateLength == 10){
				 $newDate = date("Y-d-m", strtotime($where['date']));
				 $this->db->like("interactions.date", $newDate);
				 }else{
				 $this->db->like("interactions.date", $where['date']);
				 } */
				$this->db->like("DATE_FORMAT(interactions.date,'%m/%d/%Y')", $where['date']);
			}
			
			if (isset($where['recorded_by'])) {
				$this->db->like("concat(client_users.first_name,' ',client_users.last_name)",$where['recorded_by']);
				//             $this->db->where("(client_users.first_name LIKE '%" . $where['recorded_by'] . "%' or client_users.last_name LIKE '%" . $where['recorded_by'] . "%')");
			}
			if (isset($where['recorded_by_name'])) {
				$this->db->like("concat(client_users.first_name,' ',client_users.last_name)",$where['recorded_by_name']);
				//             $this->db->where("(client_users.first_name LIKE '%" . $where['recorded_by'] . "%' or client_users.last_name LIKE '%" . $where['recorded_by'] . "%')");
			}
			if (isset($where['mode_name'])) {
				$this->db->like("interactions_modes.name", $where['mode_name']);
			}
			
			if (isset($where['objective_name'])) {
				$this->db->like("interaction_types.name", $where['objective_name']);
			}
			
			if (isset($where['product_name'])) {
				$this->db->like("products.name", $where['product_name']);
			}
			
			if (isset($where['quality_interaction'])) {
				if ($where['quality_interaction'][0] == "N" || $where['quality_interaction'][0] == "n")
					$this->db->like("interactions.quality_interaction", 0);
					else if ($where['quality_interaction'][0] == "Y" || $where['quality_interaction'][0] == "y")
						$this->db->like("interactions.quality_interaction", 1);
			}
			
			if (isset($where['generic_id'])) {
				$this->db->like("interactions.generic_id", $where['generic_id']);
			}
			
// 			if (isset($where['mirf'])) {
// 				if ($where['mirf'][0] == "A" || $where['mirf'][0] == "a")
// 					$this->db->where("interaction_mirf.id IS NULL");
// 					else if ($where['mirf'][0] == "E" || $where['mirf'][0] == "e" || $where['mirf'][0] == "V" || $where['mirf'][0] == "v")
// 						$this->db->where("interaction_mirf.id IS NOT NULL");
// 			}
			
			if (isset($where['emp_name'])) {
				$empName = $where['emp_name'];
				$this->db->like("CONCAT(emp.first_name,' ',emp.last_name)",$empName);
			}
			
			if(isset($where['is_export']) && $where['is_export'] == true){
				$sidx = 'date';
				$sord = 'DESC';
			}
			
			if (!empty(array_filter($arrFilters['manager_id']))) {
				if(sizeof($users)==0)
					$users=array(-1);
				$this->db->where_in("interactions.created_by", $users);
			}
			if(!empty($arrFilters['plan_id'])){
				$this->db->where("interactions.plan_name", $arrFilters['plan_id']);
			}
			if ($sidx != '' && $sord != '') {
				switch ($sidx) {
					case 'kol_name' : $this->db->order_by("kol_org_name", $sord);
					break;
					case 'date' :$this->db->order_by("interactions.date", $sord);
					break;
					case 'recorded_by' :$this->db->order_by("concat(client_users.first_name,' ',client_users.last_name)", $sord);
					break;
					case 'recorded_by_name' :$this->db->order_by("concat(client_users.first_name,' ',client_users.last_name)", $sord);
					break;
					case 'mode_name' :$this->db->order_by("interactions_modes.name", $sord);
					break;
					case 'objective_name' :$this->db->order_by("interaction_types.name", $sord);
					break;
					case 'product_name' :$this->db->order_by("products.name", $sord);
					break;
					case 'quality_interaction' :$this->db->order_by("interactions.quality_interaction", $sord);
					break;
// 					case 'mirf' :$this->db->order_by("interaction_mirf.id", $sord);
// 					break;
					case 'generic_id' :$this->db->order_by("SUBSTR(interactions.generic_id FROM 1 FOR 2), SUBSTR(interactions.generic_id FROM 3)", $sord);
					break;
				}
				//$this->db->order_by($sidx,$sord);
			} else {
				$this->db->order_by('interactions.date', 'desc');
			}
// // 			if($client_id !== INTERNAL_CLIENT_ID){
// 				$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
// // 			}
			$interactionDetailsResult = $this->db->get('interactions');
// 			echo $this->db->last_query();exit;
			if ($limit != 'all') {
				$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
				foreach ($interactionDetailsResult->result_array() as $row) {
					if ($row['org_id'] != null && $row['org_id'] != '') {
						$row['orgInteractionAction'] = $row['org_id'];
						if (IS_IPAD_REQUEST || $ipad)
							$row['kol_name'] = '<a href="' . base_url() . IPAD_URL_SEGMENT . '/organizations/organizations/view/' . $row['org_id'] . '">' . $row['org_name'] . '</a>';
							else
								$row['kol_name'] = '<a  href="' . base_url() . 'organizations/organizations/view/' . $row['org_id'] . '">' . $row['org_name'] . '</a>';
					}else {
						$row['orgInteractionAction'] = 0;
						if (IS_IPAD_REQUEST || $ipad) {
							if($row['kol_deleted'] == 0 || $row['kol_deleted'] == null){
								$row['kol_name'] = '<a href="' . base_url() . 'kols/kols/view/' . $row['unique_id'] . '">' . $arrSalutations[$row['salutation']] . ' ' . $this->common_helper->get_name_format($row['kol_first_name'], $row['kol_middle_name'], $row['kol_last_name']) . '</a>'; //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER].'</a>';
							}else{
								$row['kol_name'] = $arrSalutations[$row['salutation']] . ' ' . $this->common_helper->get_name_format($row['kol_first_name'], $row['kol_middle_name'], $row['kol_last_name']);
							}
						} else {
							if($row['kol_deleted'] == 0 || $row['kol_deleted'] == null){
								$row['kol_name'] = '<a target="_NEW" href="' . base_url() . 'kols/kols/view/' . $row['unique_id'] . '">' . $arrSalutations[$row['salutation']] . ' ' . $this->common_helper->get_name_format($row['kol_first_name'], $row['kol_middle_name'], $row['kol_last_name']) . '</a>'; //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER].'</a>';
							}else{
								$row['kol_name'] = $arrSalutations[$row['salutation']] . ' ' . $this->common_helper->get_name_format($row['kol_first_name'], $row['kol_middle_name'], $row['kol_last_name']);
							}
						}
					}
					$row['kol_id'] = $kolId;
					$arrInteractionDetails[] = $row;
				}
				return $arrInteractionDetails;
			} else {
				return $interactionDetailsResult->num_rows();
			}
	}
	
	function interacionByTopic($arrFilters) {
		$client_id = $this->session->userdata('client_id');
		$userId = $this->session->userdata('user_id');
		
		$this->db->select('interaction_topics.name,COUNT(DISTINCT interactions_discussion_topic_mapped_data.interaction_id) as count');
		$this->db->join('interaction_topics', 'interaction_topics.id=interactions_discussion_topic_mapped_data.topic_id', 'inner');
		$this->db->join('interactions', 'interactions.id=interactions_discussion_topic_mapped_data.interaction_id', 'inner');
		
		if ($arrFilters['start_date'] != '') {
			$this->db->where("((interactions.date between '" . $arrFilters['start_date'] . "'  and  '" . $arrFilters['end_date'] . "'))");
		}
		
		if (!empty(array_filter($arrFilters['mode']))) {
			$this->db->where_in('interactions.mode', $arrFilters['mode']);
		}
		
		if (!empty(array_filter($arrFilters['grouping']))) {
			$this->db->where_in('interactions.grouping', $arrFilters['grouping']);
		}
		if (!empty(array_filter($arrFilters['topic_id']))) {
			$this->db->where_in('interactions_discussion_topic_mapped_data.topic_id', $arrFilters['topic_id']);
		}
		
		if (!empty(array_filter($arrFilters['objective_id']))) {
			$this->db->where_in('interactions_discussion_topic_mapped_data.interaction_type', $arrFilters['objective_id']);
		}
		
		if (!empty(array_filter($arrFilters['product_id']))) {
			$this->db->where_in('interactions_discussion_topic_mapped_data.product_id', $arrFilters['product_id']);
		}
		if ($arrFilters['kol_id'] != null && $arrFilters['kol_id'] != -1 && $arrFilters['kol_id'] != 0) {
			$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
			$isAttendiesJoined = true;
			if (isset($arrFilters['interaction_for']) && ($arrFilters['interaction_for'] == 'org')){
				$this->db->where('interactions_attendees.org_id', $arrFilters['kol_id']);
			}else{
				$this->db->where('interactions_attendees.kol_id', $arrFilters['kol_id']);
			}
		}
		if ($arrFilters['kol_id'] == null || $arrFilters['kol_id'] == -1 || $arrFilters['kol_id'] == 0) {
			if ($client_id != INTERNAL_CLIENT_ID){
				if($this->session->userdata('user_role_id')==ROLE_MANAGER){
					$group_names = explode(',', $this->session->userdata('group_names'));
					$this->db->join ( 'countries', 'countries.CountryId = interactions.country_id', 'left' );
					$this->db->where_in ( 'countries.GlobalRegion', $group_names);
				}
			}
		}
		
		if ($isAttendiesJoined == false) {
			$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
			$isAttendiesJoined = true;
		}
		// 		if (!empty(array_filter($arrFilters['user_id']))) {
		//             $this->db->where_in('interactions.created_by', $arrFilters['user_id']);
		//         }
		
		//Security: within profile - all, track-user: his interactions, track-manager: all interactions
		if (!empty(array_filter($arrFilters['user_id']))) {
			$this->db->where_in('interactions.created_by', $arrFilters['user_id']);
		}
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->where('interactions.client_id', $client_id);
		}
		$this->db->join('client_users', 'client_users.id = interactions.created_by', 'left');
		$this->db->where("client_users.id IS NOT NULL");
		$this->db->join('kols_client_visibility','interactions_attendees.kol_id = kols_client_visibility.id ', 'left');
		$this->db->join('kols','kols_client_visibility.kol_id = kols.id', 'left');
		$this->db->join('organizations', 'interactions_attendees.org_id = organizations.id ', 'left');
		$this->db->group_by('topic_id');
		$result = $this->db->get('interactions_discussion_topic_mapped_data');
// 		echo $this->db->last_query();
		foreach ($result->result_array() as $row) {
			$arrResult[] = $row;
		}
		return $arrResult;
	}
	
	function interacionByChannel($arrFilters) {
		$client_id = $this->session->userdata('client_id');
		$userId = $this->session->userdata('user_id');
		
		$topicJoin = false;
		$this->db->select('interactions_modes.name,COUNT(DISTINCT interactions.id) AS count');
		$this->db->join('interactions_modes_client_association', 'interactions.mode = interactions_modes_client_association.id', 'left');
		$this->db->join('interactions_modes','interactions_modes.id = interactions_modes_client_association.interactions_modes_id','left');
		
		if ($arrFilters['start_date'] != '') {
			$this->db->where("((interactions.date between  '" . $arrFilters['start_date'] . "'  and  '" . $arrFilters['end_date'] . "'))");
		}
		if (!empty(array_filter($arrFilters['mode']))) {
			$this->db->where_in('interactions.mode', $arrFilters['mode']);
		}
		
		if (!empty(array_filter($arrFilters['grouping']))) {
			$this->db->where_in('interactions.grouping', $arrFilters['grouping']);
		}
		
		if (!empty(array_filter($arrFilters['topic_id']))) {
			$this->db->join('interactions_discussion_topic_mapped_data', 'interactions.id=interactions_discussion_topic_mapped_data.interaction_id', 'inner');
			$this->db->where_in('interactions_discussion_topic_mapped_data.topic_id', $arrFilters['topic_id']);
			$topicJoin = true;
		}
		
		if (!empty(array_filter($arrFilters['objective_id']))) {
			if ($topicJoin == false) {
				$this->db->join('interactions_discussion_topic_mapped_data', 'interactions.id=interactions_discussion_topic_mapped_data.interaction_id', 'inner');
				$topicJoin = true;
			}
			
			$this->db->where_in('interactions_discussion_topic_mapped_data.interaction_type', $arrFilters['objective_id']);
		}
		
		if (!empty(array_filter($arrFilters['product_id']))) {
			if ($topicJoin == false) {
				$this->db->join('interactions_discussion_topic_mapped_data', 'interactions.id=interactions_discussion_topic_mapped_data.interaction_id', 'inner');
				$topicJoin = true;
			}
			$this->db->where_in('interactions_discussion_topic_mapped_data.product_id', $arrFilters['product_id']);
		}
		
		if ($arrFilters['kol_id'] != null && $arrFilters['kol_id'] != -1 && $arrFilters['kol_id'] != 0) {
			$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
			$isAttendiesJoined = true;
			if (isset($arrFilters['interaction_for']) && ($arrFilters['interaction_for'] == 'org')){
				$this->db->where('interactions_attendees.org_id', $arrFilters['kol_id']);
			}else{
				$this->db->where('interactions_attendees.kol_id', $arrFilters['kol_id']);
			}
		}
		if ($arrFilters['kol_id'] == null || $arrFilters['kol_id'] == -1 || $arrFilters['kol_id'] == 0) {
			if ($client_id != INTERNAL_CLIENT_ID){
				if($this->session->userdata('user_role_id')==ROLE_MANAGER){
					$group_names = explode(',', $this->session->userdata('group_names'));
					$this->db->join ( 'countries', 'countries.CountryId = interactions.country_id', 'left' );
					$this->db->where_in ( 'countries.GlobalRegion', $group_names);
				}
			}
		}
		if (!empty(array_filter($arrFilters['user_id']))) {
			$this->db->where_in('interactions.created_by', $arrFilters['user_id']);
		}
		if ($isAttendiesJoined == false) {
			$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
			$isAttendiesJoined = true;
		}
		$this->db->where('interactions.client_id', $client_id);
		$this->db->join('client_users', 'client_users.id = interactions.created_by', 'left');
		$this->db->where("client_users.id IS NOT NULL");
		$this->db->join('kols_client_visibility','interactions_attendees.kol_id = kols_client_visibility.id ', 'left');
		$this->db->join('kols','kols_client_visibility.kol_id = kols.id', 'left');
		$this->db->join('organizations', 'interactions_attendees.org_id = organizations.id ', 'left');
		$this->db->group_by('mode');
		$result = $this->db->get('interactions');
// 		        pr($this->db->last_query());exit;
		foreach ($result->result_array() as $row) {
			$arrResult[] = $row;
		}
		return $arrResult;
	}
	
	function interactionByMonth($arrFilters) {
		$client_id = $this->session->userdata('client_id');
		$userId = $this->session->userdata('user_id');
		
		$topicJoin = false;
		if (!isset($arrFilters['get_count']))
			$this->db->select('products.name,COUNT(DISTINCT interactions.id) AS count,MONTH(DATE) as month,YEAR(DATE) AS year, CONCAT(MONTH(DATE),"",YEAR(DATE)) AS month_year', false);
			else
				$this->db->select("COUNT(DISTINCT interactions.id) AS COUNT");
				$this->db->join('interactions_discussion_topic_mapped_data', 'interactions.id=interactions_discussion_topic_mapped_data.interaction_id', 'inner');
				$this->db->join('products', 'interactions_discussion_topic_mapped_data.product_id=products.id', 'left');
				if ($arrFilters['start_date'] != '') {
					
					$this->db->where("((interactions.date between  '" . $arrFilters['start_date'] . "'  and  '" . $arrFilters['end_date'] . "'))");
				}
				
				if (!empty(array_filter($arrFilters['mode']))) {
					$this->db->where_in('interactions.mode', $arrFilters['mode']);
				}
				
				if (!empty(array_filter($arrFilters['grouping']))) {
					$this->db->where_in('interactions.grouping', $arrFilters['grouping']);
				}
				if (!empty(array_filter($arrFilters['topic_id']))) {
					$this->db->where_in('interactions_discussion_topic_mapped_data.topic_id', $arrFilters['topic_id']);
				}
				
				if (!empty(array_filter($arrFilters['objective_id']))) {
					$this->db->where_in('interactions_discussion_topic_mapped_data.interaction_type', $arrFilters['objective_id']);
				}
				
				if (!empty(array_filter($arrFilters['product_id']))) {
					$this->db->where_in('interactions_discussion_topic_mapped_data.product_id', $arrFilters['product_id']);
				}
				
				if ($arrFilters['kol_id'] != null && $arrFilters['kol_id'] != -1 && $arrFilters['kol_id'] != 0) {
					$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
					$isAttendiesJoined = true;
					if (isset($arrFilters['interaction_for']) && ($arrFilters['interaction_for'] == 'org')){
						$this->db->where('interactions_attendees.org_id', $arrFilters['kol_id']);
					}else{
						$this->db->where('interactions_attendees.kol_id', $arrFilters['kol_id']);
					}
				}
				if ($arrFilters['kol_id'] == null || $arrFilters['kol_id'] == -1 || $arrFilters['kol_id'] == 0) {
					if ($client_id != INTERNAL_CLIENT_ID){
						if($this->session->userdata('user_role_id')==ROLE_MANAGER){
							$group_names = explode(',', $this->session->userdata('group_names'));
							$this->db->join ( 'countries', 'countries.CountryId = interactions.country_id', 'left' );
							$this->db->where_in ( 'countries.GlobalRegion', $group_names);
						}
					}
				}
				//         if (!empty(array_filter($arrFilters['user_id']))) {
				//             $this->db->where_in('interactions.created_by', $arrFilters['user_id']);
				//         }
				
				//Security: within profile - all, track-user: his interactions, track-manager: all interactions
				if (!empty(array_filter($arrFilters['user_id']))) {
					$this->db->where_in('interactions.created_by', $arrFilters['user_id']);
				}
					$this->db->where('interactions.client_id',$client_id);
				if (!isset($arrFilters['get_count'])) {
					$this->db->group_by('interactions_discussion_topic_mapped_data.product_id,MONTH(DATE),YEAR(DATE)');
					$this->db->order_by('YEAR(DATE),MONTH(DATE)');
				}
				if ($isAttendiesJoined == false) {
					$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
					$isAttendiesJoined = true;
				}
				
				$this->db->join('client_users', 'client_users.id = interactions.created_by', 'left');
				$this->db->where("client_users.id IS NOT NULL");
				$this->db->join('kols_client_visibility','interactions_attendees.kol_id = kols_client_visibility.id ', 'left');
				$this->db->join('kols','kols_client_visibility.kol_id = kols.id', 'left');
				$this->db->join('organizations', 'interactions_attendees.org_id = organizations.id ', 'left');
				$result = $this->db->get('interactions');
				//         echo $this->db->last_query();exit;
				foreach ($result->result_array() as $row) {
					$arr1[] = $row;
					//$arrYear[]=$row['month'];
					$arrYear[] = $row['month_year'];
				}
				$arrResult[0] = $arr1;
				$arrResult[1] = $arrYear;
				return $arrResult;
	}
	
	function interacionByEmployee($arrFilters) {
		$client_id = $this->session->userdata('client_id');
		$userId = $this->session->userdata('user_id');
		$topicJoin = false;
		$this->db->select('concat(client_users.first_name," ",client_users.last_name) AS username,COUNT(DISTINCT interactions.id) AS count', false);
		$this->db->join('interactions_modes_client_association', 'interactions.mode = interactions_modes_client_association.id', 'left');
		$this->db->join('interactions_modes','interactions_modes.id = interactions_modes_client_association.interactions_modes_id','left');
		$this->db->join('client_users', 'interactions.created_by=client_users.id', 'left');
		
		if ($arrFilters['start_date'] != '') {
			$this->db->where("((interactions.date between  '" . $arrFilters['start_date'] . "'  and  '" . $arrFilters['end_date'] . "'))");
		}
		if (!empty(array_filter($arrFilters['mode']))) {
			$this->db->where_in('interactions.mode', $arrFilters['mode']);
		}
		
		if (!empty(array_filter($arrFilters['grouping']))) {
			$this->db->where_in('interactions.grouping', $arrFilters['grouping']);
		}
		
		if (!empty(array_filter($arrFilters['topic_id']))) {
			$this->db->join('interactions_discussion_topic_mapped_data', 'interactions.id=interactions_discussion_topic_mapped_data.interaction_id', 'inner');
			$this->db->where_in('interactions_discussion_topic_mapped_data.topic_id', $arrFilters['topic_id']);
			$topicJoin = true;
		}
		
		if (!empty(array_filter($arrFilters['objective_id']))) {
			if ($topicJoin == false) {
				$this->db->join('interactions_discussion_topic_mapped_data', 'interactions.id=interactions_discussion_topic_mapped_data.interaction_id', 'inner');
				$topicJoin = true;
			}
			$this->db->where_in('interactions_discussion_topic_mapped_data.interaction_type', $arrFilters['objective_id']);
		}
		
		if (!empty(array_filter($arrFilters['product_id']))) {
			if ($topicJoin == false) {
				$this->db->join('interactions_discussion_topic_mapped_data', 'interactions.id=interactions_discussion_topic_mapped_data.interaction_id', 'inner');
				$topicJoin = true;
			}
			$this->db->where_in('interactions_discussion_topic_mapped_data.product_id', $arrFilters['product_id']);
		}
		
		if ($arrFilters['kol_id'] != null && $arrFilters['kol_id'] != -1 && $arrFilters['kol_id'] != 0) {
			$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
			$isAttendiesJoined = true;
			if (isset($arrFilters['interaction_for']) && ($arrFilters['interaction_for'] == 'org')){
				$this->db->where('interactions_attendees.org_id', $arrFilters['kol_id']);
			}else{
				$this->db->where('interactions_attendees.kol_id', $arrFilters['kol_id']);
			}
		}
		if ($arrFilters['kol_id'] == null || $arrFilters['kol_id'] == -1 || $arrFilters['kol_id'] == 0) {
			if ($client_id != INTERNAL_CLIENT_ID){
				if($this->session->userdata('user_role_id')==ROLE_MANAGER){
					$group_names = explode(',', $this->session->userdata('group_names'));
					$this->db->join ( 'countries', 'countries.CountryId = interactions.country_id', 'left' );
					$this->db->where_in ( 'countries.GlobalRegion', $group_names);
				}
			}
		}
		//         if (!empty(array_filter($arrFilters['user_id']))) {
		//             $this->db->where_in('interactions.created_by', $arrFilters['user_id']);
		//         }
		
		//Security: within profile - all, track-user: his interactions, track-manager: all interactions
		if (!empty(array_filter($arrFilters['user_id']))) {
			$this->db->where_in('interactions.created_by', $arrFilters['user_id']);
		}
		
		$this->db->where('interactions.client_id', $client_id);
		$this->db->group_by('interactions.created_by');
		
		if ($isAttendiesJoined == false) {
			$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
			$isAttendiesJoined = true;
		}
		
		$this->db->where("client_users.id IS NOT NULL");
		$this->db->join('kols_client_visibility','interactions_attendees.kol_id = kols_client_visibility.id ', 'left');
		$this->db->join('kols','kols_client_visibility.kol_id = kols.id', 'left');
		$this->db->join('organizations', 'interactions_attendees.org_id = organizations.id ', 'left');
		$result = $this->db->get('interactions');
		//         echo $this->db->last_query();
		foreach ($result->result_array() as $row) {
			$arrResult[] = $row;
		}
		return $arrResult;
	}
	function getModeNumericReportData($arrFilters, $type) {
		$client_id 		= $this->session->userdata('client_id');
		$userId 		= $this->session->userdata('user_id');
		$clientId	= $client_id;
		$sd = $arrFilters['sd'];
		$ed = $arrFilters['ed'];
		if(is_array($arrFilters['sd'])){
			$sd = $arrFilters['sd'][0];
			$ed = $arrFilters['ed'][0];
		}
		$currentYear = date("Y");
		$arrModeResults = array();
		$select = array('COUNT(DISTINCT CASE WHEN DATE BETWEEN  "' . $sd . '" AND "' . $ed . '" THEN interactions.id  END) AS gp',
				'COUNT(DISTINCT CASE WHEN CONCAT(MONTH(DATE), "-", YEAR(DATE)) IN ( "1-' . $currentYear . '","2-' . $currentYear . '","3-' . $currentYear . '" ) THEN interactions.id END) AS q1',
				'COUNT(DISTINCT CASE WHEN CONCAT(MONTH(DATE), "-", YEAR(DATE)) IN ( "4-' . $currentYear . '","5-' . $currentYear . '","6-' . $currentYear . '" ) THEN interactions.id END) AS q2',
				'COUNT(DISTINCT CASE WHEN CONCAT(MONTH(DATE), "-", YEAR(DATE)) IN ( "7-' . $currentYear . '","8-' . $currentYear . '","9-' . $currentYear . '" ) THEN interactions.id END) AS q3',
				'COUNT(DISTINCT CASE WHEN CONCAT(MONTH(DATE), "-", YEAR(DATE)) IN ( "10-' . $currentYear . '","11-' . $currentYear . '","12-' . $currentYear . '" ) THEN interactions.id END) AS q4',
				'COUNT(DISTINCT CASE WHEN DATE BETWEEN "' . $currentYear . '-01-01" AND CURDATE() THEN interactions.id END) AS ytd'
		);
		if (!empty(array_filter($arrFilters['type'])) || !empty(array_filter($arrFilters['product'])) || !empty(array_filter($arrFilters['topic'])) || $type == 'type' || $type == 'product' || $type == 'topic' || $type == 'subtopic')
			$this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id = interactions.id', 'left');
		if (!empty(array_filter($arrFilters['mode'])))
			$this->db->where_in('interactions.mode', $arrFilters['mode']);
		if (!empty(array_filter($arrFilters['grouping'])))
			$this->db->where_in('interactions.grouping', $arrFilters['grouping']);
		if (!empty(array_filter($arrFilters['type'])))
			$this->db->where_in('interactions_discussion_topic_mapped_data.interaction_type', $arrFilters['type']);
		if (!empty(array_filter($arrFilters['product'])))
			$this->db->where_in('interactions_discussion_topic_mapped_data.product_id', $arrFilters['product']);
		if (!empty(array_filter($arrFilters['topic'])))
			$this->db->where_in('interactions_discussion_topic_mapped_data.topic_id', $arrFilters['topic']);
		if ($arrFilters['subtopic'] != '')
			$this->db->where('interactions_discussion_topic_mapped_data.sub_topic_id', $arrFilters['subtopic']);
		
		if ($type == 'mode') {
			$select[] = 'interactions_modes.name as name';
			$select[] = 'interactions_modes_client_association.id as id';
			$this->db->join('interactions_modes_client_association', 'interactions.mode = interactions_modes_client_association.id', 'left');
			$this->db->join('interactions_modes','interactions_modes.id = interactions_modes_client_association.interactions_modes_id','left');
			$this->db->where('interactions_modes.name !=', 'NULL');
			$this->db->group_by('interactions.mode WITH ROLLUP',false);
		}
		if ($type == 'grouping') {
			$select[] = 'interaction_grouping.name as name';
			$select[] = 'interaction_grouping_client_association.id as id';
			$this->db->join('interaction_grouping_client_association', 'interactions.grouping = interaction_grouping_client_association.id', 'left');
			$this->db->join('interaction_grouping', 'interaction_grouping_client_association.interaction_grouping_id = interaction_grouping.id', 'left');
			$this->db->where('interaction_grouping.name !=', 'NULL');
			$this->db->group_by('interactions.grouping WITH ROLLUP',false);
		}
		if ($type == 'type') {
			$select[] = 'interaction_types.name as name';
			$select[] = 'interaction_types.id as id';
			$this->db->join('interaction_types', 'interaction_types.id = interactions_discussion_topic_mapped_data.interaction_type', 'left');
			$this->db->where('interaction_types.name !=', 'NULL');
			$this->db->group_by("interactions_discussion_topic_mapped_data.interaction_type WITH ROLLUP",false);
		}
		if ($type == 'product') {
			$select[] = 'products.name as name';
			$select[] = 'products.id as id';
			$this->db->join('products', 'products.id = interactions_discussion_topic_mapped_data.product_id', 'left');
			$this->db->where('products.name !=', 'NULL');
			$this->db->group_by('interactions_discussion_topic_mapped_data.product_id WITH ROLLUP',false);
		}
		if ($type == 'topic') {
			$select[] = 'interaction_topics.name as name';
			$select[] = 'interaction_topics.id as id';
			$this->db->join('interaction_topics', 'interaction_topics.id = interactions_discussion_topic_mapped_data.topic_id', 'left');
			$this->db->where('interaction_topics.name !=', 'NULL');
			$this->db->group_by('interactions_discussion_topic_mapped_data.topic_id WITH ROLLUP',false);
		}
		$kolId = $arrFilters['kol_id'];
		if(is_array($arrFilters['kol_id'])){
			$kolId = $arrFilters['kol_id'][0];
		}
		if ($kolId != null && $kolId != -1 && $kolId != 0) {
			$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
			$isAttendiesJoined = true;
			if (isset($arrFilters['interaction_for']) && ($arrFilters['interaction_for'] == 'org')){
				$this->db->where('interactions_attendees.org_id', $kolId);
			}else{
				$this->db->where('interactions_attendees.kol_id', $kolId);
			}
		}
		
		if ($kolId == null || $kolId == -1 || $kolId == 0 || $kolId =='') {
			if ($client_id != INTERNAL_CLIENT_ID){
				if($this->session->userdata('role_type')==ROLE_MANAGER){
					$group_names = explode(',', $this->session->userdata('group_names'));
					$this->db->join ( 'countries', 'countries.CountryId = interactions.country_id', 'left' );
					$this->db->where_in ( 'countries.GlobalRegion', $group_names);
				}
			}
		}
		if (!empty(array_filter($arrFilters['user_id']))) {
			$this->db->where_in('interactions.created_by', $arrFilters['user_id']);
		}
		$this->db->where('interactions.client_id', $client_id);
		
		if ($isAttendiesJoined == false) {
			$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
			$isAttendiesJoined = true;
		}
		$this->db->select($select);
		$this->db->join('client_users', 'client_users.id = interactions.created_by', 'left');
		$this->db->where("client_users.id IS NOT NULL");
		$this->db->join('kols_client_visibility','interactions_attendees.kol_id = kols_client_visibility.id ', 'left');
		$this->db->join('kols','kols_client_visibility.kol_id = kols.id', 'left');
		$this->db->join('organizations', 'interactions_attendees.org_id = organizations.id ', 'left');
		$results = $this->db->get('interactions');
// 		echo $this->db->last_query();exit;
		foreach ($results->result_array() as $row) {
			$arrModeResults[] = $row;
		}
		return $arrModeResults;
	}
	function getAllTypesOfClient() {
		$arrModes = array();
		$this->db->where('status', 1);
		$arrModeResults = $this->db->get('interaction_types');
		foreach ($arrModeResults->result_array() as $row) {
			$arrModes[$row['id']] = $row;
		}
		return $arrModes;
	}
	function getInteractionDetails($interactionId) {
		$interactionDetails = array();
		$this->db->where('interactions.id', $interactionId);
		$this->db->select("client_users.first_name as emp_fname,client_users.last_name as emp_lname,interactions.*,interactions_modes.name as mode_name, states.name as state, cities.city as city,interaction_grouping.name as group_name, countries.country, interaction_location_types.name as location_category_name,CONCAT(created_users.first_name,' ',created_users.last_name) as created_by_name", false);
		$this->db->join('interactions_modes_client_association', 'interactions.mode = interactions_modes_client_association.id', 'left');
		$this->db->join('interactions_modes','interactions_modes.id = interactions_modes_client_association.interactions_modes_id','left');
		$this->db->join('states', 'states.id = interactions.state_id', 'left');
		$this->db->join('cities', 'cityId = interactions.city_id', 'left');
		$this->db->join('countries', 'countries.CountryId = interactions.country_id', 'left');
		$this->db->join('client_users', 'interactions.employee_id = client_users.id', 'left');
		$this->db->join('client_users as created_users', 'interactions.created_by = created_users.id', 'left');
		$this->db->join('interaction_grouping_client_association', 'interactions.grouping = interaction_grouping_client_association.id', 'left');
		$this->db->join('interaction_grouping', 'interaction_grouping_client_association.interaction_grouping_id = interaction_grouping.id', 'left');
		$this->db->join('interaction_location_types_client_association', 'interaction_location_types_client_association.id = interactions.location_category', 'left');
		$this->db->join('interaction_location_types', 'interaction_location_types.id = interaction_location_types_client_association.interaction_location_type_id', 'left');
		$interactionDetailsResult = $this->db->get('interactions');
		foreach ($interactionDetailsResult->result_array() as $row) {
			$arrInteractionAttendees = $this->getInteractionAttendees($row['id']);
			$arrInteractionAboutTopics = $this->getInteractionAboutTopics($row['id']);
			$row['attendees'] = $arrInteractionAttendees;
			$row['aboutTopics'] = $arrInteractionAboutTopics;
			$interactionDetails = $row;
		}
		return $interactionDetails;
	}
	function getInteractionAttendees($interactionID, $kolId = null, $interactionFor = 'kol',$ipad=false) {
		$arrInteractionDetails = array();
		$arrInteractionDetails['kol_names'] = array();
		$arrInteractionDetails['kol_ids'] = array();
		$arrInteractionDetails['specialties'] = array();
		$arrInteractionDetails['title'] = array();
		$arrInteractionDetails['department'] = array();
		$arrInteractionDetails['categories'] = array();
		$arrInteractionDetails['roles'] = array();
		$arrInteractionDetails['kol_name_for_export'] = array();
		$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$this->db->select("kols.profile_image,kols_client_visibility.id,kols_client_visibility.unique_id,kols.salutation,kols.status,kols.deleted_by as kol_deleted,kols.last_name,kols.middle_name,kols.first_name,kols.division,specialties.specialty,interactions_attendees.note,organizations.id as org_id,organizations.name as org_name, interactions_attendees.status as interaction_status,key_peoples.first_name as key_fn,key_peoples.middle_name as key_mn,key_peoples.last_name as key_ln,key_peoples.title as key_title,key_peoples.department,titles.title");
		$this->db->where('interaction_id', $interactionID);
		$this->db->join('kols_client_visibility','interactions_attendees.kol_id = kols_client_visibility.id ', 'left');
		$this->db->join('kols','kols_client_visibility.kol_id = kols.id', 'left');
		$this->db->join('organizations', 'interactions_attendees.org_id = organizations.id', 'left');
		$this->db->join('key_peoples', 'interactions_attendees.key_id = key_peoples.id', 'left');
		$this->db->join('titles', 'kols.title = titles.id', 'left');
		$this->db->join('specialties', 'kols.specialty = specialties.id', 'left');
//		$this->db->join('interactions_roles', 'interactions_attendees.role_id = interactions_roles.id', 'left');
// 		$this->db->join('interactions_categories', 'interactions_attendees.category_id = interactions_categories.id', 'left');
		if ($kolId != null && $kolId != -1) {
			/* if($interactionFor == 'org')
			 $this->db->where('interactions_attendees.org_id',$kolId);
			 else
			 $this->db->where('interactions_attendees.kol_id',$kolId); */
		}
		//$this->db->order_by('interactions_attendees.kol_id');
		$interactionDetailsResult = $this->db->get('interactions_attendees');
		// echo $this->db->last_query();exit;
		foreach ($interactionDetailsResult->result_array() as $row) {
			$microview = '';
			$extraSegmentIf = "";
				if ($row['org_id'] != null && $row['org_id'] != '') {
						if($row['kol_deleted']==0 || $row['kol_deleted']==null){
							if($row['id']!=''){
								$arrInteractionDetails['kol_names'][] = '<a href="' . base_url() . 'kols/kols/view/' . $row['unique_id'] . '">' . $arrSalutations[$row['salutation']] . ' ' . $this->common_helper->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']) . '</a>';
							}else{
								$arrInteractionDetails['kol_names'][] = $this->common_helper->get_name_format($row['key_fn'], $row['key_mn'], $row['key_ln']);
							}
						}else{
							$arrInteractionDetails['kol_names'][] = $this->common_helper->get_name_format($row['key_fn'], $row['key_mn'], $row['key_ln']);
						}
					$microview = '<div class="tooltip-demo tooltop-right microViewIcon Male" style="float:left;" onclick="showMicroProfile(' . $row['id'] . ',this); return false;"><a class="tooltipLink" rel="tooltip" href="#" data-original-title="Profile Snapshot"> </a></div>';
				}else {
					if (true) {
						if($row['kol_deleted']==0 || $row['kol_deleted']==null){
								$arrInteractionDetails['kol_names'][] = '<a target="_NEW" href="' . base_url() . 'kols/kols/view/' . $row['unique_id'] . '">' . $arrSalutations[$row['salutation']] . ' ' . $this->common_helper->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']) . '</a>'; //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER].'</a>';
						}else {
							$arrInteractionDetails['kol_names'][] = $this->common_helper->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']); //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER];
						}
						$microview = '<div class="tooltip-demo tooltop-right microViewIcon Male" style="float:left;" onclick="showMicroProfile(' . $row['id'] . ',this); return false;"><a class="tooltipLink" rel="tooltip" href="#" data-original-title="Profile Snapshot"> </a></div>';
					} elseif ($row['status'] == New1 || $row['status'] == APPROVED) {
						if($row['kol_deleted']==0 || $row['kol_deleted']==null){
							$arrInteractionDetails['kol_names'][] = '<a target="_NEW" href="' . base_url() . $extraSegmentIf . 'kols/requested_kols/show_client_requested_kols">' . $arrSalutations[$row['salutation']] . ' ' . $this->common_helper->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']) . '</a>'; //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER].'</a>';
						}else {
							$arrInteractionDetails['kol_names'][] = $this->common_helper->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']); //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER];
						}
					} elseif ($row['status'] == 'rejected') {
						if($row['kol_deleted']==0 || $row['kol_deleted']==null){
							$arrInteractionDetails['kol_names'][] = '<a target="_NEW" href="' . base_url() . $extraSegmentIf . 'kols/requested_kols/show_non_profiled_kols">' . $arrSalutations[$row['salutation']] . ' ' . $this->common_helper->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']) . '</a>'; //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER].'</a>';
						}else {
							$arrInteractionDetails['kol_names'][] = $this->common_helper->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']); //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER];
						}
					} else {
						if($row['kol_deleted']==0 || $row['kol_deleted']==null){
							$arrInteractionDetails['kol_names'][] = $arrSalutations[$row['salutation']] . ' ' . $this->common_helper->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']); //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER];
						}else {
							$arrInteractionDetails['kol_names'][] = $this->common_helper->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']); //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER];
						}
					}
				}
				$arrInteractionDetails['kol_images'][] = $row['profile_image'];
				$arrInteractionDetails['microview'][] = $microview;
				$arrInteractionDetails['specialties'][] = $row['specialty'];
				if($row['id']>0){
					$arrInteractionDetails['department'][] = $row['division'];
					$arrInteractionDetails['title'][] = $row['title'];
				}else{
					$arrInteractionDetails['department'][] = $row['department'];
					$arrInteractionDetails['title'][] = $row['key_title'];
				}
				$arrInteractionDetails['interaction_status'][] = $row['interaction_status'];
				$arrInteractionDetails['categories'][] = $row['category_name'];
				$arrInteractionDetails['roles'][] = $row['role_name'];
				$arrInteractionDetails['note'][] = $row['note'];
				if ($row['org_id'] != null && $row['org_id'] != '') {
					$arrInteractionDetails['last_interaction'][] = $this->interaction->getOrgLastInteractionById($row['org_id']);
					//   pr($arrInteractionDetails['last_interaction']);
				} else {
					$arrInteractionDetails['last_interaction'][] = $this->interaction->getKolLastInteractionById($row['id']);
				}
				if ($row['org_id'] != null && $row['org_id'] != '') {
					$arrInteractionDetails['org_id'] = $row['org_id'];
					$arrInteractionDetails['org_name'] = $row['org_name'];
					$arrInteractionDetails['kol_name_for_export'][] = $row['org_name'];
					$microview = '<div class="tooltip-demo tooltop-right microViewIcon Male" style="float:left;" onclick="showMicroProfile(' . $row['id'] . ',this); return false;"><a class="tooltipLink" rel="tooltip" href="#" data-original-title="Profile Snapshot"> </a></div>';
				} else {
					$arrInteractionDetails['kol_name_for_export'][] = $arrSalutations[$row['salutation']] . ' ' . $this->common_helper->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']); //$arrSalutations[$row['salutation']]." ".$row[FIRST_ORDER].' '.$row[SECOND_ORDER].' '.$row[THIRD_ORDER];
				}
				
				
				
				$arrInteractionDetails['kol_ids'][] = $row['id'];
		}
		return $arrInteractionDetails;
	}
	function getOrgLastInteractionById($kolId) {
		$clientId = $this->session->userdata('client_id');
		$this->db->select("interactions.date");
		$this->db->join("interactions_attendees", "interactions_attendees.interaction_id = interactions.id", "left");
		$this->db->where('interactions.client_id', $clientId);
		$this->db->where("interactions_attendees.org_id", $kolId);
		$this->db->order_by("created_on", "desc");
		$arrRetData = $this->db->get("interactions");
		$retValue = '';
		foreach ($arrRetData->result_array() as $row) {
			$last_interaction = $row['date'];
			break;
		}
		// echo $this->db->last_query();
		if ($last_interaction != '')
			$retValue = date("m/d/Y", strtotime($last_interaction));
		return $retValue;
	}
	function getKolLastInteractionById($kolId) {
		$clientId = $this->session->userdata('client_id');
		$this->db->select("interactions.date");
		$this->db->join("interactions_attendees", "interactions_attendees.interaction_id = interactions.id", "left");
		$this->db->where('interactions.client_id', $clientId);
		$this->db->where("interactions_attendees.kol_id", $kolId);
		$this->db->order_by("interactions.date", "desc");
		$arrRetData = $this->db->get("interactions");
		$retValue = '';
		foreach ($arrRetData->result_array() as $row) {
			$last_interaction = $row['date'];
			break;
		}
		if ($last_interaction != '')
			$retValue = date("m/d/Y", strtotime($last_interaction));
			return $retValue;
	}
	
	function getInteractionAboutTopics($interactionID, $kolId = null) {
		$arrInteractionDetails = array();
		$this->db->select("interaction_topics.id as topic_id,interaction_topics.name as topic_name,products.name as product_name,products.id as product_id,interaction_types.name as objective_name,interaction_types.id as objective_id");
		$this->db->where('interactions_discussion_topic_mapped_data.interaction_id', $interactionID);
		
		$this->db->join('interaction_topics', 'interactions_discussion_topic_mapped_data.topic_id = interaction_topics.id', 'left');
		$this->db->join('interaction_types', 'interaction_types.id = interactions_discussion_topic_mapped_data.interaction_type', 'left');
		$this->db->join('products', 'products.id = interactions_discussion_topic_mapped_data.product_id', 'left');
		if ($kolId != null && $kolId != -1) {
			$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions_discussion_topic_mapped_data.interaction_id', 'left');
			$this->db->where('interactions_attendees.kol_id', $kolId);
		}
		$this->db->order_by("interactions_discussion_topic_mapped_data.id",'asc');
		$interactionDetailsResult = $this->db->get('interactions_discussion_topic_mapped_data');
		foreach ($interactionDetailsResult->result_array() as $row) {
			$arrInteractionDetails['topic_names'][] = $row['topic_name'];
			$arrInteractionDetails['topic_ids'][] = $row['topic_id'];//cross_patform
			$arrInteractionDetails['objective_names'][] = $row['objective_name'];
			$arrInteractionDetails['objective_ids'][] = $row['objective_id'];//cross_patform
			$arrInteractionDetails['product_names'][] = $row['product_name'];
			$arrInteractionDetails['product_ids'][] = $row['product_id'];//cross_patform
		}
		return $arrInteractionDetails;
	}
	function getTypeByProduct($id) {
		$arrReturnData = array();
		$this->db->select("interaction_types.id,interaction_types.name");
		$this->db->join('interaction_types', 'interaction_types.id=interaction_type_by_product.type_id', 'left');
		$this->db->where('product_id', $id);
		$this->db->where('interaction_type_by_product.status', 1);
		$this->db->order_by('name', 'ASC');
		$arrResultSet = $this->db->get('interaction_type_by_product');
		$noProdRow = array();
		foreach ($arrResultSet->result_array() as $row) {
			$arrReturnData[$row['id']] = $row;
		}
		return $arrReturnData;
	}
	function getTopicByType($typeId, $productId) {
		$arrTopics = array();
		$this->db->distinct("interaction_topics.name");
		$this->db->select("interaction_topics.id,interaction_topics.name");
		$this->db->join('interaction_topics', 'interaction_topics.id=interaction_topics_by_type.topic_id', 'left');
		$this->db->where('interaction_topics_by_type.product_id ', $productId);
		$this->db->where('interaction_topics_by_type.type_id ', $typeId);
		$this->db->where('interaction_topics.status ', 1);
		$this->db->order_by("interaction_topics.name");
		$this->db->order_by("interaction_topics.id");
		$arrResults = $this->db->get('interaction_topics_by_type');
// 		echo $this->db->last_query();
		foreach ($arrResults->result_array() as $row) {
			if($row['name'] != 'Other'){
				$arrTopics1[] = $row;
			}else{
				$arrTopics2[] = $row;
			}
		}
		if(!empty($arrTopics2)){
			$arrTopics = array_merge($arrTopics1,$arrTopics2);
		}else{
			$arrTopics = $arrTopics1;
		}
		return $arrTopics;
	}
	function getInteractionDiscussionTopics($id) {
		$this->db->select('interactions_discussion_topic_mapped_data.*');
		$this->db->where('interaction_id', $id);
		$arrTopicsResult = $this->db->get('interactions_discussion_topic_mapped_data');
		foreach ($arrTopicsResult->result_array() as $row) {
			$arrTopics[] = $row;
		}
		return $arrTopics;
	}
	function getInteractionLocationTypes() {
		$clientId=$this->session->userdata('client_id');
		$arrInteractionLocationTypes = array();
		$this->db->select('interaction_location_types_client_association.id,interaction_location_types.name');
		$this->db->join('interaction_location_types_client_association','interaction_location_types.id = interaction_location_types_client_association.interaction_location_type_id', 'left');
		$this->db->where('interaction_location_types_client_association.client_id',$clientId);
		$this->db->where('interaction_location_types.is_active', 1);
		$this->db->order_by('interaction_location_types.id', 'ASC');
		$result = $this->db->get('interaction_location_types');
		foreach ($result->result_array() as $row) {
			$arrInteractionLocationTypes[] = $row;
		}
		return $arrInteractionLocationTypes;
	}
	function getPlanNames($kol_id){
		$clientId   = $this->session->userdata('client_id');
		$this->db->select('plan_details.*');
		$this->db->join('plan_profiles','plan_profiles.plan_id=plan_details.id','left');
		$this->db->join('kols','kols.id=plan_profiles.kol_id','left');
		$this->db->where('plan_profiles.kol_id',$kol_id);
		$arrResult = $this->db->get('plan_details');
		foreach($arrResult->result_array() as $row){
			$name[$row['id']]=$row['plan_name'];
		}
		return $name;
	}
	function getInteractionDocs($interactionId, $docId = null) {
		$client_id = $this->session->userdata('client_id');
		$arrDocs = array();
		if ($docId != null)
			$this->db->where('interaction_docs.id', $docId);
		
		if ($interactionId != null)
			$this->db->where('interaction_docs.interaction_id', $interactionId);
		$this->db->select('interaction_docs.*');
		$this->db->select('interactions.country_id as country');
		$this->db->join ('interactions', 'interactions.id = interaction_docs.interaction_id', 'left' );
		$arrDocsResults = $this->db->get('interaction_docs');
		foreach ($arrDocsResults->result_array() as $row) {
			$row['download'] = $this->common_helper->isActionAllowed('interaction_doc_download', 'download', $row);
			$arrDocs[] = $row;
		}
// 		echo $this->db->last_query();
		return $arrDocs;
	}
	function deleteDocuments($documentId) {
		$fileName = "";
		$this->db->where('id', $documentId);
		$this->db->select('doc_path');
		$result = $this->db->get('interaction_docs');
		$data = $result->row();
		$fileName = $data->doc_path;
		$this->db->where('id', $documentId);
		if ($this->db->delete('interaction_docs'))
			return $fileName;
		else
			return false;
	}
	function getOtherAttendisDataById($interactionId) {
		$this->db->select("interactions_other_attendees.*, specialties.specialty");
		$this->db->join("specialties", "specialties.id = interactions_other_attendees.specialty_id", "left");
		$this->db->where("interactions_other_attendees.interaction_id", $interactionId);
		$arrData = $this->db->get("interactions_other_attendees");
		$arrRetData = array();
		foreach ($arrData->result_array() as $row) {
			$arrRetData[] = $row;
		}
		return $arrRetData;
	}
	
	function getInteractionAttendis($id) {
		$arrAttendis = array();
		$this->db->select('interactions_attendees.*,kols.first_name,kols.middle_name,kols.last_name,specialties.specialty,interactions_attendees.status,organizations.name as org_name,organizations.status as org_status,titles.title,key_peoples.first_name as key_fn,key_peoples.middle_name as key_mn,key_peoples.last_name as key_ln,key_peoples.title as key_title');
// 		$this->db->join('kols', 'kols.id=interactions_attendees.kol_id', 'left');
		$this->db->join('kols_client_visibility', 'kols_client_visibility.id=interactions_attendees.kol_id', 'left');
		$this->db->join('kols', 'kols_client_visibility.kol_id = kols.id', 'left');		
		$this->db->join('organizations', 'organizations.id=interactions_attendees.org_id', 'left');
		$this->db->join('key_peoples', 'key_peoples.id=interactions_attendees.key_id', 'left');
		
		$this->db->join('specialty_client_association','specialty_client_association.id = kols.specialty','left');
		$this->db->join('specialties','specialties.id = specialty_client_association.specialty_id','left');
		
		$this->db->join('titles', 'kols.title = titles.id', 'left');
		$this->db->where('interaction_id', $id);
		$arrResults = $this->db->get('interactions_attendees');
		foreach ($arrResults->result_array() as $row) {
			if($row['org_id'] != null && $row['org_id'] != '') {
				if ($row['kol_id']!=''){
					$row['attType'] = 'kol_type';
				}else{
					$row['attType'] = 'key_type';
				}
			}
			$arrAttendis[] = $row;
		}
		return $arrAttendis;
	}
	function getAllKolNamesForAutocomplete($kolName,$restrictByRegion=0,$restrictOptInVisbility=0) {
		$kolName = str_replace ( ",", " ", $kolName );
		$kolName = preg_replace ( '!\s+!', ' ', $kolName );
		$kolName = $this->db->escape_like_str ( $kolName );
		$client_id = $this->session->userdata('client_id');
		$arrKols = array ();
		$this->db->select ( "kols.id,kols.unique_id,first_name,middle_name,last_name,organizations.name as name,kols.status,kols.do_not_call_flag,states.name as state,cities.city as city,kol_locations.private_practice" );
		// $this->db->select("kols.id,first_name,middle_name,last_name");
		$this->db->join ( 'organizations', 'kols.org_id=organizations.id', 'left' );
		$this->db->join ( 'states', 'states.id = kols.state_id', 'left' );
		$this->db->join ( 'cities', 'cities.cityID = kols.city_id', 'left' );
		$this->db->join ( 'kol_locations', 'kols.id = kol_locations.kol_id', 'left' );
		if(INTERNAL_CLIENT_ID != $client_id){
			if($restrictByRegion){
				if($this->session->userdata('user_role_id') == ROLE_USER || $this->session->userdata('user_role_id') == ROLE_MANAGER){
					$group_names = explode(',', $this->session->userdata('group_names'));
					$this->db->join ( 'countries', 'countries.CountryId=kols.country_id', 'left' );
					$this->db->where_in( 'countries.GlobalRegion', $group_names);
				}
			}
		}
		if(INTERNAL_CLIENT_ID != $client_id){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$likeNameFormatOrder	= 'first_name,middle_name,last_name';
		//$this->db->like("concat_ws(' ',$likeNameFormatOrder)", $kolName);
		$this->db->where('replace(concat(coalesce(kols.first_name,"")," ",coalesce(kols.middle_name,"")," ",coalesce(kols.last_name,"")),"  "," ") like "%'.$kolName.'%"', '',false);
		// $this->db->where_in('kols.status',array(COMPLETED,PRENEW));
		$this->db->where ( 'kols.customer_status', "ACTV" );
		if(KOL_CONSENT && $restrictOptInVisbility==1){
			$this->db->where('(kols.opt_in_out_status is NULL OR kols.opt_in_out_status = 0 OR kols.opt_in_out_status =4)','',false);
		}
		$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		$this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
		$nameFormat = $this->session->userdata('name_order');
		if ($nameFormat == 1 || $nameFormat == 3)
			$this->db->order_by("first_name",'asc');
		else if ($nameFormat == 2)
			$this->db->order_by("last_name",'asc');
		$arrKolsResult = $this->db->get ( 'kols' );
		// echo $this->db->last_query();
		// exit;
		$arrCompletedKols = array ();
		$arrMyCustomers = array ();
		foreach ( $arrKolsResult->result_array () as $row ) {
			$arrMyCustomers [$row ['unique_id']] [] = str_replace ( '  ', ' ', $this->common_helper->get_name_format ( $row ['first_name'], $row ['middle_name'], $row ['last_name'] ) );
			
			if (! empty ( $row ['name'] ))
				$arrMyCustomers [$row ['unique_id']] [] = $row ['name'];
			else
				$arrMyCustomers [$row ['unique_id']] [] = $row ['private_practice'];
			$arrMyCustomers [$row ['unique_id']] [] = $row ['state'];
			$arrMyCustomers [$row ['unique_id']] [] = $row ['city'];
			$arrMyCustomers [$row ['unique_id']] [] = $row ['id'];
			if ($row ['do_not_call_flag'] == 1)
				$arrMyCustomers [$row ['unique_id']] ['do_not_call_flag'] = "Do Not Call";
			else
				$arrMyCustomers [$row ['unique_id']] ['do_not_call_flag'] = "";
		}
		$arrKols ['kols'] = $arrCompletedKols;
		$arrKols ['customers'] = $arrMyCustomers;
		return $arrKols;
	}
	function getAllKeyPeoplesForAutocomplete($keyName,$organizationId) {
		$kolName = str_replace ( ",", " ", $keyName );
		$kolName = preg_replace ( '!\s+!', ' ', $keyName );
		$kolName = $this->db->escape_like_str ( $keyName );
		$this->db->select(array('key_peoples.*','key_people_roles.role','client_users.client_id'));
		$this->db->join('key_people_roles','key_people_roles.id = key_peoples.role_id', 'left');
		$this->db->join('organizations','organizations.id = key_peoples.org_id', 'left');
		$this->db->join('client_users','client_users.id = key_peoples.created_by', 'left');
		//$this->db->like("concat_ws(' ',$likeNameFormatOrder)", $kolName);
		$this->db->where('replace(concat(coalesce(key_peoples.first_name,"")," ",coalesce(key_peoples.middle_name,"")," ",coalesce(key_peoples.last_name,"")),"  "," ") like "%'.$keyName.'%"', '',false);
		$this->db->where('key_peoples.org_id', $organizationId);
		//     	$this->db->like("concat(key_peoples.first_name,key_peoples.middle_name,key_peoples.last_name)", $keyName);
		$nameFormat = $this->session->userdata('name_order');
		if ($nameFormat == 1 || $nameFormat == 3)
			$this->db->order_by("key_peoples.first_name",'asc');
		else if ($nameFormat == 2)
			$this->db->order_by("key_peoples.last_name",'asc');
		$arrKeyPeopleDetailsResult = $this->db->get ('key_peoples');
// 		echo $this->db->last_query();
		return $arrKeyPeopleDetailsResult->result_array();
	}
	function getKepPeopleTitle($keyId){
		$arrKeyDetails = array();
		$this->db->where('id',$keyId);
		$query = $this->db->get('key_peoples');
		foreach ($query->result_array() as $row) {
			$arrKeyDetails[] = $row;
		}
		return $arrKeyDetails;
	}
	function addUpdateEvent($calendar_event_id=null){
		$current_date	= date("Y-m-d H:i:s");
		$user_id		=$this->session->userdata('user_id');
		
		if($calendar_event_id==null){
			$arrEventDetails['created_on']=$current_date;
			$arrEventDetails['created_by']=$user_id;
			if($this->db->insert('calendar_events',$arrEventDetails)){
				return $this->db->insert_id();
			}
		}else{
			$arrEventDetails['Modified_on']=$current_date;
			$arrEventDetails['modified_by']=$user_id;
			$this->db->where('id',$calendar_event_id);
			if($this->db->update('calendar_events',$arrEventDetails)){
				return $calendar_event_id;
			}
		}
		return 0;
	}
	function addUpdateInteraction($arrInteractionDetails){
		$current_date	= date("Y-m-d H:i:s");
		$user_id		=$this->session->userdata('user_id');
		
		if($arrInteractionDetails['id']==null){
			$arrInteractionDetails['created_on']=$current_date;
			$arrInteractionDetails['created_by']=$user_id;
			if($this->db->insert('interactions',$arrInteractionDetails)){
				return $this->db->insert_id();
			}
		}else{
			$arrInteractionDetails['Modified_on']=$current_date;
			$arrInteractionDetails['modified_by']=$user_id;
			$this->db->where('id',$arrInteractionDetails['id']);
			if($this->db->update('interactions',$arrInteractionDetails)){
				return $arrInteractionDetails['id'];
			}
		}
		return 0;
	}
	function saveOtherAttendis($arrOtherAttendisDetails) {
		$details['interaction_id']=$arrOtherAttendisDetails['interaction_id'];
		foreach ($arrOtherAttendisDetails['non_profiled_kol'] as $key=>$attendees_name){
			$details['name']=$attendees_name;
			$details['specialty_id']=$arrOtherAttendisDetails['non_profifled_specialty'][$key];
			$details['comments']=$arrOtherAttendisDetails['non_profiled_comment'][$key];
			
			$this->db->select('id');
			$this->db->where('interaction_id',$details['interaction_id']);
			$this->db->where('name',$details['name']);
			$this->db->where('specialty_id',$details['specialty_id']);
			$query = $this->db->get('interactions_other_attendees');
			$num = $query->num_rows();
			if($num>0){
				$this->db->where('interaction_id',$details['interaction_id']);
				$this->db->where('name',$details['name']);
				$this->db->where('specialty_id',$details['specialty_id']);
				$this->db->update('interactions_other_attendees',$details);
			}
			else {
				$this->db->insert('interactions_other_attendees', $details);
			}
		}
		return true;
	}
	function saveInteractionTopicDetail($arrTopicDetails) {
		$details['interaction_id']=$arrTopicDetails['interaction_id'];
		foreach ($arrTopicDetails['product_id'] as $key=>$product_id){
			$details['product_id']		=$product_id;
			$details['interaction_type']=$arrTopicDetails['interaction_type'][$key];
			$details['topic_id']		=$arrTopicDetails['topic_id'][$key];
			
			$this->db->select('id');
			$this->db->where('interaction_id',$details['interaction_id']);
			$this->db->where('product_id',$details['product_id']);
			$this->db->where('interaction_type',$details['interaction_type']);
			$this->db->where('topic_id',$details['topic_id']);
			$query = $this->db->get('interactions_discussion_topic_mapped_data');
			$num = $query->num_rows();
			if($num<=0){
				$this->db->insert('interactions_discussion_topic_mapped_data',$details);
			}
		}
		return true;
	}
	function deleteInteractionOtherDetails($type,$id){
		$returnData['status']=false;
		switch ($type){
			case 'objective':$this->db->where('id',$id);
							$status=$this->db->delete('interactions_discussion_topic_mapped_data');
							break;
			case 'nonProfiledKols':$this->db->where('id',$id);
									$status=$this->db->delete('interactions_other_attendees');
									break;
			case 'kols':$this->db->where('id',$id);
								$status=$this->db->delete('interactions_attendees');
								break;
							
		}
		$returnData['status']=$status;
		return $returnData;
	}
	function getSpecialtyIdByKol($kolId) {
		$this->db->select('specialties.id');
		$this->db->where('kols.id', $kolId);
		$this->db->join('specialties','specialties.id = kols.specialty','left');
		$arrResult = $this->db->get('kols');
		foreach ($arrResult->result_array() as $row) {
			$speciltyId = $row['id'];
		}
		return $speciltyId;
	}
	function getOrgLocaionDetailsById($orgId) {
		$arrKolDetails = array();
		$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$this->db->where('organizations.id', $orgId);
		$this->db->select(array('organizations.*', 'countries.Country', 'states.name as Region', 'cities.City'));
		$this->db->join('countries', 'countries.CountryId = organizations.country_id', 'left');
		$this->db->join('states', 'states.id = organizations.state_id', 'left');
		$this->db->join('cities', 'cities.cityId = organizations.city_id', 'left');
		$arrKolDetailsResult = $this->db->get('organizations');
		foreach ($arrKolDetailsResult->result_array() as $row) {
			$arrKolDetails[] = $row;
		}
		return $arrKolDetails;
	}
	function saveInteractionAttendis($arrAttendeesDetails){
		foreach ($arrAttendeesDetails as $arrAttendeesDetail){
			$this->db->select('id');
			$this->db->where('interaction_id',$arrAttendeesDetail['interaction_id']);
			
			if(isset($arrAttendeesDetail['kol_id']) && $arrAttendeesDetail['kol_id']>0)
			$this->db->where('kol_id',$arrAttendeesDetail['kol_id']);
			
			if(isset($arrAttendeesDetail['org_id']) && $arrAttendeesDetail['org_id']>0)
			$this->db->where('org_id',$arrAttendeesDetail['org_id']);
			
			if(isset($arrAttendeesDetail['key_id']) && $arrAttendeesDetail['key_id']>0)
			$this->db->where('key_id',$arrAttendeesDetail['key_id']);
			
			if(isset($arrAttendeesDetail['specialty_id']) && $arrAttendeesDetail['specialty_id']>0)
			$this->db->where('specialty_id',$arrAttendeesDetail['specialty_id']);
			
			$query = $this->db->get('interactions_attendees');
			$num = $query->num_rows();
			if($num<=0){
				$this->db->insert('interactions_attendees',$arrAttendeesDetail);
			}
		}
	}
	function deleteEvent($id){
		$this->db->where('id',$id);
		if($this->db->delete('calendar_events')){
			return true;
		}else{
			return false;
		}
	}
	function deleteInteraction($interactionId) {
		$this->db->where('id', $interactionId);
		if ($this->db->delete('interactions'))
			return true;
		else
			return false;
	}
	function listInteractionsByDrilldown($type, $id, $seg, $arrFilters,$ipad=false) {
		//     	pr($arrFilters);exit;
		$userId 			= $this->session->userdata('user_id');
		$client_id 			= $this->session->userdata('client_id');
		$currentYear 		= date("Y");
		$arrInteractions = array();		
		$this->db->select("interactions.*,interactions_modes.name as mode_name");
		$this->db->join('interactions_modes_client_association', 'interactions.mode = interactions_modes_client_association.id', 'left');
		$this->db->join('interactions_modes','interactions_modes.id = interactions_modes_client_association.interactions_modes_id','left');
		if ($arrFilters['type'] != 'null' || $arrFilters['product'] != 'null' || $arrFilters['topic'] != 'null' || $type == 'type' || $type == 'product' || $type == 'topic')
			$this->db->join('interactions_discussion_topic_mapped_data', 'interactions_discussion_topic_mapped_data.interaction_id = interactions.id', 'left');
			
		if ($type == 'mode') {
			$this->db->where('interactions_modes.name !=', 'NULL');
			if ($id != 0) {
				$this->db->where('interactions_modes_client_association.id', $id);
			}
		}
		if ($type == 'grouping') {
			$this->db->join('interaction_grouping_client_association', 'interaction_grouping_client_association.id = interactions.grouping', 'left');
			$this->db->join('interaction_grouping', 'interaction_grouping.id = interaction_grouping_client_association.grouping', 'left');
			$this->db->where('interaction_grouping.name !=', 'NULL');
			if ($id != 0) {
				$this->db->where('interaction_grouping_client_association.id', $id);
			}
		}
		if ($type == 'type') {
			$this->db->join('interaction_types', 'interaction_types.id = interactions_discussion_topic_mapped_data.interaction_type', 'left');
			$this->db->where('interaction_types.name !=', 'NULL');
			if ($id != 0) {
				$this->db->where('interaction_types.id', $id);
			}
		}
		if ($type == 'product') {
			$this->db->join('products', 'products.id = interactions_discussion_topic_mapped_data.product_id', 'left');
			$this->db->where('products.name !=', 'NULL');
			if ($id != 0) {
				$this->db->where('products.id', $id);
			}
		}
		if ($type == 'topic') {
			$this->db->join('interaction_topics', 'interaction_topics.id = interactions_discussion_topic_mapped_data.topic_id', 'left');
			$this->db->where('interaction_topics.name !=', 'NULL');
			if ($id != 0) {
				$this->db->where('interaction_topics.id', $id);
			}
		}
		
		if ($seg == 'gp') {
			$this->db->where('DATE BETWEEN  "' . $arrFilters['sd'][0] . '" AND "' . $arrFilters['ed'][0] . '"');
		}
		if ($seg == 'q1') {
			$this->db->where('CONCAT(MONTH(DATE), "-", YEAR(DATE)) IN ( "1-' . $currentYear . '","2-' . $currentYear . '","3-' . $currentYear . '" )');
		}
		if ($seg == 'q2') {
			$this->db->where('CONCAT(MONTH(DATE), "-", YEAR(DATE)) IN ( "4-' . $currentYear . '","5-' . $currentYear . '","6-' . $currentYear . '" )');
		}
		if ($seg == 'q3') {
			$this->db->where('CONCAT(MONTH(DATE), "-", YEAR(DATE)) IN ( "7-' . $currentYear . '","8-' . $currentYear . '","9-' . $currentYear . '" )');
		}
		if ($seg == 'q4') {
			$this->db->where('CONCAT(MONTH(DATE), "-", YEAR(DATE)) IN ( "10-' . $currentYear . '","11-' . $currentYear . '","12-' . $currentYear . '" )');
		}
		if ($seg == 'ytd') {
			$this->db->where('DATE BETWEEN "' . $currentYear . '-01-01" AND CURDATE()');
		}
		
		if (!empty($arrFilters['mode'])) {
			$this->db->where_in('interactions.mode', $arrFilters['mode']);
		}
		if (!empty($arrFilters['grouping'])) {
			$this->db->where_in('interactions.grouping', $arrFilters['grouping']);
		}
		if (!empty($arrFilters['type'])) {
			$this->db->where_in('interactions_discussion_topic_mapped_data.interaction_type', $arrFilters['type']);
		}
		if (!empty($arrFilters['product'])) {
			$this->db->where_in('interactions_discussion_topic_mapped_data.product_id', $arrFilters['product']);
		}
		if (!empty($arrFilters['topic'])) {
			$this->db->where_in('interactions_discussion_topic_mapped_data.topic_id', $arrFilters['topic']);
		}
		if ($arrFilters['kol_id'][0] != null && $arrFilters['kol_id'][0] != -1 && $arrFilters['kol_id'][0] != 0) {
			$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
			$isAttendiesJoined = true;
			if (isset($arrFilters['interaction_for'][0]) && ($arrFilters['interaction_for'][0] == 'org')){
				$this->db->where('interactions_attendees.org_id', $arrFilters['kol_id'][0]);
			}else{
				$this->db->where('interactions_attendees.kol_id', $arrFilters['kol_id'][0]);
			}
		}
		if ($arrFilters['kol_id'][0] == null || $arrFilters['kol_id'][0] == -1 || $arrFilters['kol_id'][0] == 0) {
			if ($client_id != INTERNAL_CLIENT_ID){
				$userGroupName = getGroupDetails();
				if($this->session->userdata('user_role_id')==ROLE_MANAGER){
					$group_names = explode(',',  $userGroupName['group_names']);
					$this->db->join ( 'countries', 'countries.CountryId = interactions.country_id', 'left' );
					$this->db->where_in ( 'countries.GlobalRegion', $group_names);
				}
			}
		}
		//Security: within profile - all, track-user: his interactions, track-manager: all interactions
		if (!empty(array_filter($arrFilters['user_id']))) {
			$this->db->where_in('interactions.created_by', $arrFilters['user_id']);
		}
		$this->db->where('interactions.client_id', $client_id);
		if ($isAttendiesJoined == false) {
			$this->db->join('interactions_attendees', 'interactions_attendees.interaction_id = interactions.id', 'left');
			$isAttendiesJoined = true;
		}
		$this->db->select($select);
		$this->db->join('client_users','client_users.id = interactions.created_by', 'left');
		$this->db->where("client_users.id IS NOT NULL");
		$this->db->join('kols_client_visibility', 'kols_client_visibility.id = interactions_attendees.kol_id','left');
		$this->db->join('kols', 'kols_client_visibility.id= kols.id ','left');
		$this->db->join('organizations', 'interactions_attendees.org_id = organizations.id ', 'left');
		$this->db->group_by('interactions.id');
		$this->db->order_by('interactions.date','desc');
		$results = $this->db->get('interactions');
// 		echo $this->db->last_query();exit;
		foreach ($results->result_array() as $row) {
			$arrInteractionAttendees = $this->getInteractionAttendees($row['id'],null,null,$ipad);
			if(!empty($arrInteractionAttendees['kol_names'][0])){
				$arrInteractionAboutTopics = $this->getInteractionAboutTopics($row['id']);
				//$row['kol_name']			= implode(',',$arrInteractionAttendees['kol_names']);
				if(isset($arrInteractionAttendees['org_id'])){
						$row['kol_name'] =  '<a href="' . base_url() . 'organizations/view/' . $arrInteractionAttendees['org_id'] . '">' . $arrInteractionAttendees['org_name']. '</a>';
				}else{
					$row['kol_name'] = $arrInteractionAttendees['kol_names'][0];
				}
				$row['area_name'] = implode(',', $arrInteractionAttendees['specialties']);
				$row['category_name'] = implode(',', $arrInteractionAttendees['categories']);
				$row['role_name'] = implode(',', $arrInteractionAttendees['roles']);
				$row['topic_name'] = implode(',', $arrInteractionAboutTopics['topic_names']);
				$row['objective_name'] = $arrInteractionAboutTopics['objective_names'][0];
				$row['product_name'] = $arrInteractionAboutTopics['product_names'][0];
				$row['kol_name_for_export'] = implode(',', $arrInteractionAttendees['kol_name_for_export']);
				$arrInteractions[] = $row;
			}
		}
		$sort = array();
		foreach($arrInteractions as $k=>$v) {
			$sort['date'][$k] = $v['date'];
			$sort['kol_name'][$k] = $v['kol_name'];
		}
		$sorted = array_multisort(strip_tags($sort['kol_name']), SORT_ASC,$sort['date'], SORT_DESC,$arrInteractions);
		return $arrInteractions;
	}
}
?>
