<?php

/**
 * this is html file to show Contents for 'Privacy and Terms & service'
 * @package application.views.client_users
 * 
 * @author Vinayak
 * @since	3.2
 * @created: 4-10-11
 * 
 */

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
<title><?php echo APP_PRODUCT_INFO_HEADER;?></title>
	<!-- Load the Favicon :: Shows in the Address bar of the Browser -->
	<?php //echo link_tag('images/favicon.ico', 'shortcut icon', 'image/ico'); ?>
	<?php echo $this->load->view('elements/favicon');?>

<style type="text/css">
	.tosWrapper{
		width:85%;
		height: 350px;
		overflow: scroll;
		border:1px solid #7F9DB9;
		padding:5px;
		background: none repeat scroll 0 0 #fefefe;
	}
	.paragraphContent{
		padding: 5px;
		text-align: justify;
	}
	.paragraphContent strong{
		display:block;
	}
	.paragraphContent .subParagraphContent{
		padding-left:18px;
	}
	.paragraphContent .subParagraphContent ol{
		margin-top:2px;
	}
</style>
</head>
<body>
<table width="80%" border="0" align="center">
  <tr>
  <td><img src="<?php echo base_url();?>images/kolm_logo_beta.png" alt="Aissel solutions" /></td>
    <td style="color:#38537C;width: 100%; text-align: center;" valign="bottom">
		<h2 style="margin:0;"><?php echo PRODUCT_VERSION; ?></h2>
	</td>
  </tr>
  <tr><td colspan="2"><hr style="background:#2283AE;" /></td></tr>
<?php if($pageType=='privacy'){?>

  <tr><td><img style="float: left; height: 19px; padding-right: 5px;" src="<?php echo base_url();?>images/privacy.jpg" /><h3 style="margin:0; padding-left:0px;color:#A6A3A6;">Privacy Policy</h3></td></tr>
  <tr>
    <td colspan="2" align="center">
		<div style="background: none repeat scroll 0 0 #EFEFEF;padding:5px 0px 25px 0px;">
			<h4 style="padding: 0pt 54px; text-align: left;">
				Clicking on register is considered as your consent and agreement to be bound by all provisions of the Terms of Service.
			</h4>
			<textarea readonly cols="100" rows="20" style="width:85%;">
Aissel Solutions considers every information pertaining to our clients highly confidential. We are committed to protecting our client�s confidentiality. This page summarizes our privacy policy.

We collect information when you register an account to become a user (�User�), such as your name, e-mail, employer, country, and a password.

We do not share the information that is collected with any other entity or personnel. The information that is collected is used only by authorized employees of Aissel Solutions. We may use your contact information to communicate with you on our key product updates, new releases or any other promotional communication. You may choose to unsubscribe at any time.

We do not sell, rent, or otherwise provide personally identifiable information to any third parties.

All information that is provided about the Physicians on kolmtrial.com has been collected and curated from publicly available content on the internet. Aissel Solutions does not provide any lifestyle related information about any personnel such as home address, cell phone numbers, family information,  Date of Birth, personal interests etc.
			</textarea>
		</div>
	</td>
  </tr>


<?php }?>

<?php if($pageType=='terms'){?>
  <!-- <tr><td colspan="2"><h3 style="margin:0; padding-left:0px;color:#A6A3A6;">Terms of Service</h3></td></tr> -->
  <tr>
    <td colspan="2" align="center">
		<div style="background: none repeat scroll 0 0 #EFEFEF;padding:5px 0px 25px 0px;">
			<h4 style="padding: 0pt 54px; text-align: left;">Terms of Service</h4>
			<div class="tosWrapper">
			<!--<textarea readonly cols="100" rows="20" style="width:85%;"> -->
<div class="paragraphContent">
Your use of our online services (referred to collectively as the "Service" in this document and excluding any professional services or other items provided to you by us under a separate written agreement) is subject to the terms of this legal agreement between you and us, as amended from time to time (the "Terms"). See "Accepting these Terms" below for more information about accepting these Terms.  The term "You" or "you" or "your" means the person or entity who or which is acquiring the right to use the Service under these Terms; "we" or "us" or "Aissel" means Aissel Solutions and "both of us" means both you and us.
</div>
<div class="paragraphContent">
You agree that by registering or signing in on Key Opinion Leader Management site or any of our websites, you enter into a legally binding agreement with Aissel Solutions. By clicking on "Login", you acknowledge that you have read and understood the terms and conditions of this Agreement and that you agree to be bound by all of its provisions.
</div>
<div class="paragraphContent">
In order to access the Service, you may be required to provide information about yourself (such as identification or contact details) from time to time, including, but not limited to, as part of the registration process for the Service, or as part of your continued use of the Service.  You promise that any registration information you give to us will always be accurate, correct and up to date.  We promise to take commercially reasonable steps to preserve the confidentiality of such information.
</div>
<div class="paragraphContent">
You are responsible for maintaining the confidentiality of passwords associated with any account you use to access the Service.  Accordingly, you will be solely responsible to us for all activities that occur under your account.  If you become aware of any unauthorized use of your password or of your account, you promise to notify us immediately.
</div>
<div class="paragraphContent">
	<strong>1. OWNERSHIP/PROPRIETARY RIGHTS</strong>
	<div class="subParagraphContent">
	<?php echo PRODUCT_VERSION; ?> Software is completely owned by and is a copyright of Aissel Solutions. The Software (including all of its software and technology components), together with all intellectual property rights therein, are the exclusive property of Aissel Solutions (whether those rights happen to be registered or not, and wherever in the world those rights may exist). The product in all its elements is a property of Aissel and that only limited license is granted to the users to use the features.
	<p> </p>
	We (or our licensors) own all legal right, title and interest in and to the Service, including any intellectual property rights which subsist in the Service (whether those rights happen to be registered or not, and wherever in the world those rights may exist).  The Service may contain information which is designated confidential by us and you shall not disclose such information without our prior written consent.
	<p> </p>
	You may not (and you may not permit anyone else, on your behalf of otherwise, to) copy, modify, create a derivative work of, reverse engineer, decompile or otherwise attempt to extract the source code of the software used to provide the Service or any part thereof, unless this is expressly permitted or required by law, or unless you have been specifically told that you may do so by us, in writing.
	Certain portions of the website contain proprietary arrangements and content which you agree not to share publicly without our consent. This means among other things you may not provide copies of screen shots to third parties without our consent. Providing screen shots to us for help, maintenance and error correction purposes is of course not restricted.
	<p> </p>
	In general, the Service is provided in a manner which does not result in your downloading or using any of our software ("Software").  In the event that we do, however, provide you with Software (such as a plug-in or similar item), we grant you a personal, non-transferable and non-exclusive right and license to use the object code of its Software on the single computer to which it is provided in connection with your access to the Service; provided that you do not (and do not allow any third party to) copy, modify, create a derivative work of, reverse engineer, reverse assemble or otherwise attempt to discover any source code, sell, assign, sublicense, grant a security interest in or otherwise transfer any right in the Software. You may not modify the Software in any manner or form, or to use modified versions of the Software, including (without limitation) for the purpose of obtaining unauthorized access to the Service. You may not rent, lease, loan, sell, distribute or create derivative works based on the Software, in whole or in part.
	<p> </p>
	We obtain no right, title or interest from you (or your licensors) under these Terms in or to any information (such as data files, written text, computer software, music, audio files or other sounds, photographs, videos or other images) (collectively, "Content") that you or third parties transmit or display on, or through, the Service, including any intellectual property rights which subsist in that Content (whether those rights happen to be registered or not, and wherever in the world those rights may exist); provided, that the provisions below under "Rights to End User Data and Key Word Material" apply to any materials described therein which might otherwise be considered "Content".  You are responsible for protecting and enforcing those rights and we have no obligation to do so on your behalf.
	<p> </p>
	Notwithstanding the above, you may voluntarily provide (in connection with use of the Service, use of our products or services or otherwise) suggestions, comments or other feedback to us with respect to such items.  Such feedback is not "Content" and we are not required to hold such feedback in confidence, and such feedback may be used by us for any purpose without obligation of any kind; provided, nothing in these Terms restructure your use of feedback or ideas that you provide to us.
	You may not remove, obscure, or alter any proprietary rights notices (including copyright and trade mark notices) which may be affixed to or contained within the Service.  In using the Service, you will not use any trade mark, service mark, trade name, logo of any company or organization in a way that is likely or intended to cause confusion about the owner or authorized user of such marks, names or logos.  Nothing in these Terms gives you a right to use any of our trade names, trademarks, service marks, logos, domain names, and other distinctive brand features without obtaining, in each instance, our prior written consent.
	<p> </p>
	You retain copyright and/or any other rights you already hold in any and all Content which you submit, post or display on or through, the Service. We will make all reasonable attempts to hold your content confidential and be accessible by only you or the Personnel authorized by you.
	</div>
</div>
<div class="paragraphContent">
<strong>2. GENERAL</strong>
<div class="subParagraphContent">
	Nothing in this Agreement creates an obligation for you to enter into any other agreement with Aissel Solutions. Nothing in this Agreement shall be construed to constitute an agency, partnership, joint venture, or other similar relationship between you and us.
	 <p> </p>
	Further, we do not represent or warrant that the software or any related service will always be available, accessible, uninterrupted, timely, secure, accurate, complete, or error-free.
	<p> </p>
	Where applicable, we may collect information on scientific publications from US National Library of Medicine and pubmed.com or clinicaltrials.gov. Some material in the NLM databases is from copyrighted publications of the respective copyright claimants. You are solely responsible for fair usage of such content and compliance to any such copyright restrictions. Further, we do not claim any ownership rights in the text, files, images, photos, video, sounds, musical works, works of authorship, or any other materials (collectively, "Content") that are reported through our software.
	<p> </p>
	We will make reasonable attempts to backup data.  However, because the success of this process depends on equipment, software and services over which we have at best limited control, you agree that we have no responsibility or liability for the deletion or failure to store any data or other Content or communications maintained or transmitted by the Service.  We take reasonable steps to secure Content and other data.  However, we cannot guarantee that the Content and data transmitted by you will remain secure.
	
		<ol>
			<li>Requests for support shall be made by email to support@aissel.com.</li>
		</ol>
</div>
</div>
<div class="paragraphContent">
<strong>3. RESTRICTIONS ON USE</strong>
<div class="subParagraphContent">
	You promise to use the Service only for purposes and in a manner, permitted by 
	<ol>
		<li>these Terms and</li> 
		<li>any applicable law, regulation or generally accepted practices or guidelines in the relevant jurisdictions. In addition, you hereby assure us that you will not export directly or indirectly technical data to any country for which a validated license is required under United States law without first obtaining a validated license as required/ mandated.</li>
	</ol>
	
	You may not: 
	<ol>
		<li> sublicense, sell, resell, transfer, assign, distribute, share, lease, rent, make any commercial use of, outsource, use on a timeshare or use as an application service provider or managed service provider offering, or otherwise generate income from the Software;</li> 
		<li> modify, adapt, hack, publish, translate, reproduce, copy, or create derivative works, nor allow any of those actions to occur, based on all or any part of the Software; </li>
		<li> modify any proprietary rights notices which appear in the Software or components thereof.</li>
	</ol>	
	You may not: 
	<ol>
		<li>use the Service in a manner that would cause you or us to violate any applicable local, state, national or international law, including any rules and regulations of any securities exchange, any rules, regulations, requirements, procedures or policies in force from time to time relating to the Service, and any export or re-export laws, rules and regulations; interfere with or disrupt the Service or take any steps to interfere with or in any manner compromise any security measures with respect to the Service or any data transmitted, processed or stored on or through the Service, or interferes with or disrupts the Service (or the servers and networks which are connected to the Service).
		</li>
	</ol>
	You promise not to access (or attempt to access) the Service by any means other than through the interface(s) that are provided by us. Without limiting the generality of the foregoing, you specifically promise/agree not to access (or attempt to access) any of the Service through any automated means (including use of scripts or crawlers) other than customary indexing of content by search engines.  Similarly, you promise that you will not provide any third party access to material on the Service (or facilitate their attempt to access) by any means other than through the interface that is provided by us.
	<p> </p>
	The license granted to you under these Terms is for the most current version of the Service as of the time we make such version available to you under these Terms.  We may release future versions of the Service under these Terms or different terms. Nothing in these Terms
	<ol>
		<li> gives you the right to any future version of the Service or rights to any other Services marketed by us; or</li> 
		<li> is a commitment to you of compatibility between the Service and any future versions of either.</li>
	</ol>
</div>
</div>
<div class="paragraphContent">
<strong>4. UNAUTHORISED USE</strong>
	<div class="subParagraphContent">
		You shall notify us immediately of any unauthorized use of the Software or any other known or suspected breach of security or misuse of the Software. You are responsible for use of the Software by any and all employees, contractors, or other users that it allows to access the Software (each, a "User"), and shall ensure that all Users are subject to confidentiality and use provisions at least as restrictive as those contained herein, and shall abide by all applicable local, state, national and foreign laws, treaties and regulations in connection with each User"s use of the Software.
	</div>
</div>
<div class="paragraphContent">
<strong>5. APPLICABILITY</strong>
<div class="subParagraphContent">
	The terms set forth herein and any related service agreements constitute the final, complete and exclusive agreement with respect to the Software and may not be contradicted, explained or supplemented by evidence of any prior agreement. Should any term or provision hereof be deemed invalid, void or unenforceable either in its entirety or in a particular application, the remainder of this License shall nonetheless remain in full force and effect.
</div>
</div>
<div class="paragraphContent">
<strong>6. EXCLUSION OF WARRANTIES</strong>
<div class="subParagraphContent">
	THE SERVICE (INCLUDING ANY ADVERTISING DISPLAYED THEREON, IF APPLICABLE) AND ANY MATERIAL DOWNLOADED OR OTHERWISE OBTAINED THROUGH USE OF THE SERVICE (THE "MATERIALS") IS MADE AVAILABLE "AS IS, AS AVAILABLE".  WE EXPRESSLY DISCLAIM ALL WARRANTIES OF ANY KIND RELATING TO THE SERVICE OR THE MATERIALS, WHETHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. 
	<p> </p>
	WE DO NOT PROMISE THAT YOUR USE OF THE SERVICE WILL BE UNINTERRUPTED, ERROR-FREE OR COMPLETELY SECURE, AND YOU ACKNOWLEDGE THAT THERE ARE RISKS INHERENT IN INTERNET CONNECTIVITY THAT COULD RESULT IN THE LOSS OF YOUR PRIVACY AND CONFIDENTIAL INFORMATION.
	<p> </p>
	YOU ALONE SHALL BEAR THE RISK AND YOU SHALL BE SOLELY RESPONSIBLE FOR ANY DAMAGE TO YOUR COMPUTER OR OTHER DEVICE OR LOSS OF DATA THAT RESULTS FROM USE OF THE SERVICE OR ANY MATERIALS.  NO ADVICE OR INFORMATION, WHETHER ORAL OR WRITTEN, OBTAINED BY YOU FROM US OR THROUGH OR FROM THE SERVICE SHALL CREATE ANY WARRANTY NOT EXPRESSLY STATED IN THESE TERMS.
	<p> </p>
	WE DO NOT PROVIDE ANY WARRANTIES OR ENDORSEMENTS ON ANY PERSON, PRODUCT, BRAND, AND/OR COMPANY THAT ARE REPORTED IN OUR SOFTWARE, PROFILING, MAPPING OR ANY OTHER SERVICES. WE COLLECT CONTENT THAT IS PUBLICLY AVAILABLE, PARSE IT AND REPORT IT. YOU MAY NOT HOLD US RESPONSIBLE ON THE USAGE OF ANY CONTENT REPORTED BY US IN ANY MANNER. MORE SPECIFICALLY AND EMPHATICALLY WE DENY ANY KIND OF ENDORSEMENT FOR ANY OF THE PHYSICIANS/DOCTORS.
</div>
</div>
<div class="paragraphContent">
<strong>7. LIMITATION OF LIABILITY</strong>
<div class="subParagraphContent">
	You expressly understand and agree that we shall not be liable for any indirect, incidental, special, consequential or exemplary damages, including but not limited to damages for loss of profits, goodwill, use, data or other intangible losses including any such damages resulting from the use or the inability to use the software; the cost of procurement of substitute goods and softwares resulting from any goods, data, information or softwares purchased or obtained or messages received or transactions entered into through or from the software; unauthorized access to or alteration of licensee"s transmissions or data; statements or conduct of any third party on the software; or any other matter relating to the software.
</div> 
</div>
<div class="paragraphContent">
<strong>8. INDEMNIFICATION</strong>
<div class="subParagraphContent">
	You hereby agree that you shall indemnify us against any kind of misuse of the data that is rendered through our system. You indemnify us and hold us harmless for all damages, losses and costs (including, but not limited to, reasonable attorneys" fees and costs) related to all third party claims, charges, and investigations, caused by 
	<ol>
		<li> your failure to comply with this Agreement, including, without limitation, your submission 
		   of content that violates third party rights or applicable laws,
		</li>
		<li> any content you submit to the Services, and</li> 
		<li> any activity in which you engage on or through Aissel.</li>
	</ol>
</div>
</div>
<div class="paragraphContent">
<strong>9. ACCEPTING THESE TERMS</strong>
<div class="subParagraphContent">
	In order to use the Service, you must first agree to these Terms. You may not use the Service if you do not accept these Terms. Where applicable, you can accept these Terms by executing a Purchase Order referring to these Terms; or by clicking on "Login" or "Register," in the user interface for any service; or by actually using the Service.  You agree that we will treat your use of the Service as acceptance of these Terms from that point onwards.
	<p> </p>
	You may not use the Service and may not accept the Terms if 
	<ol>
		<li> you are not of legal age (under the laws of the jurisdiction of which you are a resident or from which you use the Service) to form a binding contract with us, or </li>
		<li> you are a person barred from using the Service under the laws of the United States or other countries including the country in which you are resident or from which you use the Service.</li>
	</ol>
	If you are entering into these Terms on behalf of a company or other organization, you must have the authority to bind your company or organization to these Terms and commit funds on its behalf.  Titles that typically carry that authority include, without limitation:  Chairman, Principal, President, Officer, Vice President, Director, Controller, Finance Manager or Purchasing Manager.  We may reject these Terms if we determine, in our sole discretion, that you do not have the appropriate authority.  In any case, if you are entering into these Terms on behalf of a company or other organization, you represent that you have the authority to bind it to these Terms and commit funds on its behalf, and the terms "you" and "your" will refer to that company or organization.
	<p> </p>
	In any of the above cases, case, you represent that you satisfy all of the above eligibility conditions.  If you do not satisfy the above conditions, or if you do not agree with these Terms, you may not use the Service or any portion thereof; in that case we may also terminate these Terms and your use of the Service immediately without liability to you.
</div>
</div>
<!-- </textarea>-->
			</div>
		</div>
	</td>
  </tr>
<?php }?>
 <tr><td colspan="2"><hr style="background:#2283AE;" /></td></tr>
  <tr>
    <td align="right" colspan="2"><div><input type="button" value="Close" onclick="javascript:window.close();" /> </div></td>
  </tr>
</table>
</body>
</html>