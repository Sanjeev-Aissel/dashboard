<?php
/**
 * File to 'add' Social Media details
 *
 * 
 * 
 */
?>			<script type="text/javascript">
				function saveSocialMedia(){
					formAction = '<?php echo base_url();?>kols/save_social_media';
					$('.activeContent div.msgBox').removeClass('success');
					$('.activeContent div.msgBox').addClass('notice');
					$('.activeContent div.msgBox').show();
					$('.activeContent div.msgBox').html('Updating the data... <img src="<?php echo base_url()?>images/ajax_loader_black.gif" />');
					
					$.ajax({
						type: "post",
						data: $("#socialMediaForm").serialize(),
						url: formAction,
						success: function(returnData){
							if(returnData){
								$('.activeContent div.msgBox').addClass('success');
								$('.activeContent div.msgBox').text('Updated the data successfully');
							}
						},
						complete: function(){
							$('.activeContent div.msgBox').fadeOut(1300);
							$('.formError').hide();
						}
						
					});
				}

			</script>
			
			<style type="text/css">
				#socialMediaForm label img{
					height:28px;
					vertical-align: text-top;
				}	
			</style>	
							
			<div class="verticalslider" id="socialMediaVerticalTabs">
				<ul class="verticalslider_tabs">
					<li>
						<?php $this->load->view('elements/kol_short_details');?>
					</li>
				</ul>
				<ul class="verticalslider_contents">
					<li>Dummy Content</li>
					
					<!-- Start of Persnoal and Professional Information -->
					<li>
						<div class="msgBoxContainer"><div class="msgBox"></div></div>
						<h1>Add Social Media details</h1>
						
						<form action="save_social_media" method="post" id="socialMediaForm" name="socialMediaForm" class="validateForm">
						
							<p>
								<label for="mediaBlog"><img src="<?php echo base_url()?>images/social/blogger.png" title="Blog"/></label>
								<input type="text" name="blog" value="<?php echo $arrKol['blog'];?>" id="mediaBlog" ></input>
							</p>
						
							<p>
								<label for="mediaLinkedIn"><img src="<?php echo base_url()?>images/social/linkedin.png" title="LinkedIn" /></label>
								<input type="text" name="linked_in" value="<?php echo $arrKol['linked_in'];?>" id="mediaLinkedIn"></input>
							</p>
								
							<p>
								<label for="mediaFacebook"><img src="<?php echo base_url()?>images/social/facebook.png" title="Facebook"/></label>
								<input type="text" name="facebook" value="<?php echo $arrKol['facebook'];?>" id="mediaFacebook"></input>
							</p>				
						
							<p>
								<label for="mediaTwitter"><img src="<?php echo base_url()?>images/social/twitter.png" title="Twitter"/></label>
								<input type="text" name="twitter" value="<?php echo $arrKol['twitter'];?>" id="mediaTwitter"></input>
							</p>
								
							<p>
								<label for="mediaMyspace"><img src="<?php echo base_url()?>images/social/myspace.png" title="Myspace"/></label>
								<input type="text" name="myspace" value="<?php echo $arrKol['myspace'];?>" id="mediaMyspace"></input>
							</p>	
								
							<p>
								<label for="mediaYouTube"><img src="<?php echo base_url()?>images/social/youtube.png" title="YouTube"/></label>
								<input type="text" name="you_tube" value="<?php echo $arrKol['you_tube'];?>" id="mediaYouTube"></input>
							</p>		
							
							<div class="formButtons">	
								<input type="button" value="Save" onClick="saveSocialMedia();">
							</div>
						</form>	
					</li>
				</ul>
			</div>
			
			<script>
				$(document).ready(function(){
					$("#socialMediaVerticalTabs").verticaltabs({speed: 50,slideShow: false,activeIndex: 1});
				});
			</script>