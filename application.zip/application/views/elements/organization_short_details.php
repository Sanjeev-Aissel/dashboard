<?php
/**
 * Used to display the short information of the Organization Profile
 */
?>
	<?php 
		if($arrOrganization['type_id'] != 0)
			$organizationType	= $arrOrganizationTypes[$arrOrganization['type_id']];
		else
			$organizationType = "";
		
	?>
	<div id="organizationShortDetails">
		<div class="profileImage">
			<?php 
				if($arrOrganization['company_logo'] != ''){
					if(strpos($arrOrganization['company_logo'], ":")!=false) {
						echo '<img alt="Image" width=120" src="'. $arrOrganization['company_logo'].'"/>';
					}else{
						echo '<img alt="Image" width="110" src="'. base_url(). 'images/organization_images/resized/'. $arrOrganization['company_logo'].'"/>';
					}
				}else{?>
					<img alt="Image" width="110" src="<?php echo base_url()?>images/organization_logo.png" />
					<?php 
				}
			?>
		</div>
		<p class="profileName">
			<?php echo $arrOrganization['name']; ?> <br />
			<?php echo $organizationType; ?>
		</p>
		<button id="uploadLogoLink">Upload Logo</button>		
	</div>