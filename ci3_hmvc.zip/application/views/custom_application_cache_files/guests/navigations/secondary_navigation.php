<?php
							$menuGenerator	= "";
							switch ($current_tab) {
										case "logins/client_module":
										case "contacts":
															$menuGenerator	.= ' <div id="MainMenu"><div class="list-group panel">
																<a  href="https://localhost/hmvc/contacts" class="list-group-item list-group-item-default strong">
																KOLs
																</a>
															</div></div> ';
														break;
										 }
			if(!empty($menuGenerator)){
				echo '<th class="col-sm-2"><div id="secondaryMenuWrapper">'.$menuGenerator.'</div></th>';
			}
		