<?php
/**
 * Profiles (KOL or Organization) aligned/assigned to Users
 * @author Laxman K
 * @since KOLM CORE v6.0.6
 * @created on 23 DEC 2013
 */
class Align_user extends Model{
//Constructor
	function Align_user(){
		parent::Model();
	}
	function listUsers($clientId){
		$arrUsers	= array();
		$userGroupIds = getGroupDetails();
		$group_ids = explode(',',  $userGroupIds['group_ids']);
// 		$group_ids = explode(',', $this->session->userdata('group_ids'));
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("client_users.client_id",$clientId);
		}
		if($this->session->userdata('user_role_id')==ROLE_USER || $this->session->userdata('user_role_id')==ROLE_READONLY_USER){
			$userId	= $this->session->userdata('user_id');
			$this->db->where("client_users.id",$userId);
		}
	//	$this->db->where_in('client_users.user_from',array(1,2));
		$this->db->where_in('client_users.status',array(ACTIVATED_USER));
		$this->db->select("client_users.id,client_users.first_name,client_users.last_name");
		if($this->session->userdata('user_role_id')==ROLE_MANAGER){
    		$this->db->join('user_groups','user_groups.user_id = client_users.id');
    		$this->db->where_in("user_groups.group_id",$group_ids);
    		$this->db->group_by('client_users.id');
		}
	//	$this->db->join('client_users as managers','managers.id = client_users.manager_id');
	//	$this->db->join('clients','clients.id = client_users.client_id');
		$this->db->order_by('client_users.first_name, client_users.last_name');
		$arrUserResult = $this->db->get('client_users');
		//pr($this->db->last_query());exit;
		foreach($arrUserResult->result_array() as $row){
				$arrUsers[] = $row;
		}
		return $arrUsers;
	}
	function getAllUserKolAlignment(){
		$arrUsersKol	= array();
		$arrUserResult = $this->db->get('user_kols');
		foreach($arrUserResult->result_array() as $row){
				$arrUsersKol[$row['user_id']][$row['kol_id']] = $row;
		}
		return $arrUsersKol;
	}
	function saveKolAlignment($kolIds,$arrUsers){
	    $this->load->model("kol");
		$separator	= '';
		$isInserted	= false;		
		$arrUsersKol= $this->getAllUserKolAlignment();
		$bulkInsert = 'insert into user_kols values ';
		$userGroupName = getGroupDetails();
		$group_names = explode(',',  $userGroupName['group_names']);
// 		$group_names = explode(',', $this->session->userdata('group_names'));
		$type = DEFAULT_ASSIGN_TYPE;
		$created_by = $this->session->userdata('user_id');
		$created_on = date("Y-m-d H:i:s");		
		$dataType = 'User Added';
		$client_id =$this->session->userdata('client_id');
		if($client_id == INTERNAL_CLIENT_ID){
		    $dataType = 'Aissel Analyst';
		}
		foreach($arrUsers as $key=>$userId){
			$userId	= (int)$userId;			
			foreach($kolIds as $index=>$kolId){			    
				$kolId	= (int)$kolId;
				$client_id = $this->session->userdata('client_id');
				if($client_id !== INTERNAL_CLIENT_ID  && $this->session->userdata('user_role_id') != ROLE_ADMIN){
					$kolRegion = $this->getKolRegion($kolId);
					if(!isset($arrUsersKol[$userId][$kolId]) && in_array($kolRegion, $group_names)){
						$bulkInsert .= $separator."(null,$userId,$kolId,'2','$created_by','$created_on','$created_by','$created_on','$dataType')";
						$separator	= ',';
						$arrUsersKol[$userId][$kolId]	= array('user_id'=>$userId,'kol_id'=>$kolId); 
						$isInserted	= true;
					}
				}else{
					if(!isset($arrUsersKol[$userId][$kolId])){
						$bulkInsert .= $separator."(null,$userId,$kolId,'2','$created_by','$created_on','$created_by','$created_on','$dataType')";
						$separator	= ',';
						$arrUsersKol[$userId][$kolId]	= array('user_id'=>$userId,'kol_id'=>$kolId);
						$isInserted	= true;
					}
				}
			}
		}
		if($isInserted){
			$this->db->query($bulkInsert);		
			return true;
		}
		
		return false;
	}
	function getAllUserOrgAlignment(){
		$arrUsersOrg	= array();
		$arrUserResult = $this->db->get('user_orgs');
		foreach($arrUserResult->result_array() as $row){
				$arrUsersOrg[$row['user_id']][$row['org_id']] = $row;
		}
		return $arrUsersOrg;
	}
	function saveOrgAlignment($orgIds,$arrUsers){
		$separator	= '';
		$isInserted	= false;
		$arrUsersOrg= $this->getAllUserOrgAlignment();
		$userGroupName = getGroupDetails();
		$group_names = explode(',',  $userGroupName['group_names']);
// 		$group_names = explode(',', $this->session->userdata('group_names'));
		$bulkInsert = 'insert into user_orgs values ';
		foreach($arrUsers as $key=>$userId){
			$userId	= (int)$userId;
			foreach($orgIds as $index=>$orgId){
				$orgId	= (int)$orgId;
				$client_id = $this->session->userdata('client_id');
				if($client_id !== INTERNAL_CLIENT_ID && $this->session->userdata('user_role_id') != ROLE_ADMIN){
					$orgRegion = $this->getOrgRegion($orgId);
					if(!isset($arrUsersOrg[$userId][$orgId])  && in_array($orgRegion, $group_names)){
						$bulkInsert .= $separator."(null,$userId,$orgId)";
						$separator	= ',';
						$arrUsersOrg[$userId][$orgId]	= array('user_id'=>$userId,'org_id'=>$orgId); 
						$isInserted	= true;
					}
				}else{
					if(!isset($arrUsersOrg[$userId][$orgId])){
						$bulkInsert .= $separator."(null,$userId,$orgId)";
						$separator	= ',';
						$arrUsersOrg[$userId][$orgId]	= array('user_id'=>$userId,'org_id'=>$orgId);
						$isInserted	= true;
					}	
				}
			}
		}
		if($isInserted){
			$this->db->query($bulkInsert);
			return true;
		}
		return false;
	}
	
	function getAssignedUsers($kolId){
		$kolId	= (int)$kolId;
		$clientId = $this->session->userdata('client_id');		
		$this->db->select("user_kols.user_id,CONCAT(first_name,' ',last_name) AS full_name",false);
		$this->db->join('client_users','client_users.id=user_kols.user_id');
		$this->db->where('kol_id',$kolId);
		if($clientId!=INTERNAL_CLIENT_ID){
		    $this->db->where("client_users.client_id",$clientId);
		}
		$arrResult = $this->db->get('user_kols');
		$arrUsers = array();
		foreach($arrResult->result_array() as $row){
			$arrUsers[$row['user_id']] = $row['full_name'];
		}
		return $arrUsers;
		
	}
	
	function getAssignedOrgUsers($orgId){
		$orgId	= (int)$orgId;
		$clientId = $this->session->userdata('client_id');		
		$this->db->select("user_orgs.user_id,CONCAT(first_name,' ',last_name) AS full_name",false);
		$this->db->join('client_users','client_users.id=user_orgs.user_id');
		$this->db->where('org_id',$orgId);
		if($clientId!=INTERNAL_CLIENT_ID){
		    $this->db->where("client_users.client_id",$clientId);
		}
		$arrResult = $this->db->get('user_orgs');
		foreach($arrResult->result_array() as $row){
			$arrUsers[$row['user_id']] = $row['full_name'];
		}
		return $arrUsers;
		
	}
	
	function deleteKolAlignment($kolIds,$arrUserIds,$role){
		$this->db->where_in('kol_id',$kolIds);
		if(!($role==ROLE_MANAGER || $role==ROLE_ADMIN)){
			$userId = $this->session->userdata('user_id');
			$this->db->where('user_id',$userId);
		}else{
			$this->db->where_not_in('user_id',$arrUserIds);
		}
		$this->db->delete('user_kols');
	}
	
	function deleteOrgAlignment($orgIds,$arrUserIds,$role){
		$this->db->where_in('org_id',$orgIds);
		if(!($role==ROLE_MANAGER || $role==ROLE_ADMIN)){
			$userId = $this->session->userdata('user_id');
			$this->db->where('user_id',$userId);
		}else{
			$this->db->where_not_in('user_id',$arrUserIds);
		}
		$this->db->delete('user_orgs');
	}
	
	function getRquetsterOfKol($arrKols){
		$arrUsres = array();
		$this->db->select('kol_id,requested_by as user_id');
		$this->db->where_in('kol_id',$arrKols);
		$arrResultSet = $this->db->get('user_requests');
		
		foreach($arrResultSet->result_array() as $row){
			$arrUsres[] = $row;
		}
		return $arrUsres;
	}
	
	function assignKolsToUser($arrUsers){
		$this->db->insert('user_kols',$arrUsers);
	}
	function getKolRegion($kolId){
	    $this->db->select('countries.GlobalRegion');
	    $this->db->join('kols', 'kols.country_id = countries.CountryId', 'left');
	    $this->db->where("kols.id",$kolId);
	    $get = $this->db->get('countries')->row();
	    return $get->GlobalRegion;
	}
	function getOrgRegion($kolId){
	    $this->db->select('countries.GlobalRegion');
	    $this->db->join('organizations', 'organizations.country_id = countries.CountryId', 'left');
	    $this->db->where("organizations.id",$kolId);
	    $get = $this->db->get('countries')->row();
	    return $get->GlobalRegion;
	}
}