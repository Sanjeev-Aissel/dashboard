<?php
/**
 * Form to add kol Personal Info
 * 
 * @author Ramesh B
 * @since	2.2
 * @created: 05-05-2011
 */
?>
<style>
	.personalInfoContainer input[type="text"] {
		width:90%;
	}
	.microView .ui-dialog-content{
		background-color: #FFFFFF;
	}
	.microView p {
		margin:0 0 4px;
		float: left;
		width:100%;
	}
	
	.personalInfoContainer #familyInfo,.personalInfoContainer #contactInfo,.personalInfoContainer #interestInfo,.personalInfoContainer #uploadInfo {
		float: left;
		clear: both;
		width: 100%;
		border-bottom: 0px dotted;
	}
	
	.personalInfoContainer div#familyInfo div div{
		width: 24%;
		float: left;
	}

	.personalInfoContainer #familyInfo p,.personalInfoContainer #contactInfo p {
		width: 25%;
		float:left;
	}
	
	#addPersonalInfoForm #familyInfo p label,#addPersonalInfoForm #contactInfo p label{
		float: left;
		margin-top:6px;
		padding-right:3px;
	}
	
	#addPersonalInfoForm #interestInfo td label{
		float: left;
		width: 30%;
		padding-right:3px;
		text-align: right;
		margin-top:6px;
	}
	
	#addPersonalInfoForm #interestInfo td input{
		width: 60%;
	}
	
	div.uploadedFiles,div#uploadFileds {
		float: left;
		clear: both;
		width: 100%
	}
	
	.personalInfoContainer div.uploadedFiles p{
		float: left;
		width: 25%
	}

	.personalInfoContainer #uploadFileds p {
		float: left;
		width: 30%;
	}
	
	#savePersonalInfo {
		margin-left:50%;
		margin-top:6px;
		text-align:center;
	}
	
</style>

<script type="text/javascript">
	$(document).ready(function(){
		$('#birthday').datepicker({
			dateFormat: 'mm/dd/yy'
		});

		$('#anniversary').datepicker({
			dateFormat: 'mm/dd/yy'
		});
	});
</script>
<div>
	<div class="formHeader"><h5>Personal Information</h5></div>
	<div id="addPersonalInfo" class="personalInfoContainer">
		<form action="<?php echo base_url();?>kols/save_personal_info" name="add_personal_info" id="addPersonalInfoForm" method="post" enctype="multipart/form-data">
			<?php if(isset($kolPersonalInfo)) {?>
				<input type="hidden" name="personal_info_id" value="<?php echo $kolPersonalInfo['id'];?>">
				<input type="hidden" name="birthday_event_id" value="<?php echo $kolPersonalInfo['birthday_event_id'];?>">
				<input type="hidden" name="anniversary_event_id" value="<?php echo $kolPersonalInfo['anniversary_event_id'];?>">
			<?php }?>
			<!-- Family Info -->
			<div id="familyInfo">
			<fieldset><legend>Family</legend>
				<div>
					<p>
						<label for=gender>Gender:</label>
						
						<input type="text" name="gender" id="gender" value="<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['gender'];?>" />
					</p>
					<p>
						<label for=hometown>Hometown:</label>
						<input type="text" name="home_town" id="hometown" value="<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['home_town'];?>"/>
					</p>
					<p>
						<label for=birthday>Birthday:</label>
						<input type="text" name="birthday" id="birthday" value="<?php if(isset($kolPersonalInfo) && $kolPersonalInfo['birthday']!='0000-00-00') echo $this->common_helpers->convertDateToMM_DD_YYYY($kolPersonalInfo['birthday']);?>"/>
					</p>
					<p>
						<label for=languages>Languages:</label>
						<input type="text" name="languages" id="languages" value="<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['languages'];?>"/>
					</p>
				</div>
				<div>
					<p>
						<label for=spouseName>Spouse Name:</label>
						<input type="text" name="spouse_name" id="spouseName" value="<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['spouse_name'];?>"/>
					</p>
					<p>
						<label for=anniversary>Anniversary:</label>
						<input type="text" name="anniversary" id="anniversary" value="<?php if(isset($kolPersonalInfo) && $kolPersonalInfo['anniversary']!='0000-00-00') echo $this->common_helpers->convertDateToMM_DD_YYYY($kolPersonalInfo['anniversary']);?>"/>
					</p>
					<p>
						<label for=children>Children:</label>
						<input type="text" name="children" id="children" value="<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['children'];?>"/>
					</p>
					<p>
						<label for=pets>Pets:</label>
						<input type="text" name="pets" id="pets" value="<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['pets'];?>"/>
					</p>
				</div>
			</fieldset>
			</div>
			<!-- Contact Info -->
			<div id="contactInfo">
			<fieldset><legend>Contact</legend>
				<p>
					<label for=homePhone>Home Phone:</label>
					<input type="text" name="home_phone" id="homePhone" value="<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['home_phone'];?>"/>
				</p>
				<p>
					<label for=cellPhone>Cell Phone:</label>
					<input type="text" name="cell_phone" id="cellPhone" value="<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['cell_phone'];?>"/>
				</p>
				<p>
					<label for=IMScreenName1>IM Screen Name:</label>
					<input type="text" name="IM_screen_name1" id="IMScreenName1" value="<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['IM_screen_name1'];?>"/>
				</p>
				<p>
					<label for=IMScreenName2>IM Screen Name:</label>
					<input type="text" name="IM_screen_name2" id="IMScreenName2" value="<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['IM_screen_name2'];?>"/>
				</p>
			</fieldset>
			</div>
			<!-- Interests Info -->
			<div id="interestInfo">
			<fieldset><legend>Interest</legend>
				<table>
					<tr>
						<td>
							<p>
								<label for=specialInterests>Special Interests:</label>
								<input type="text" name="special_interests" id="specialInterests" value="<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['special_interests'];?>"/>
							</p>
						</td>
						<td>
							<p>
								<label for=sports>Sports:</label>
								<input type="text" name="sports" id="sports" value="<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['sports'];?>"/>
							</p>
						</td>
					</tr>
					<tr>
						<td>
							<p>
								<label for=music>Music:</label>
								<input type="text" name="music" id="music" value="<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['music'];?>"/>
							</p>
						</td>
						<td>
							<p>
								<label for=activities>Activities:</label>
								<input type="text" name="activities" id="activities" value="<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['activities'];?>"/>
							</p>
						</td>
					</tr>
					<tr>
						<td>
							<p>
								<label for=books>Books:</label>
								<input type="text" name="books" id="books" value="<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['books'];?>"/>
							</p>
						</td>
						<td>
							<p>
								<label for=vacation>Vacation:</label>
								<input type="text" name="vacation" id="vacation" value="<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['vacation'];?>"/>
							</p>
						</td>
					</tr>
					<tr>
						<td>
							<p>
								<label for=journals>Journals:</label>
								<input type="text" name="journals" id="journals" value="<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['journals'];?>"/>
							</p>
						</td>
						<td>
							<p>
								<label for=magazines>Magazines:</label>
								<input type="text" name="magazines" id="magazines" value="<?php if(isset($kolPersonalInfo)) echo $kolPersonalInfo['magazines'];?>"/>
							</p>
						</td>
					</tr>
				</table>
			</fieldset>
			</div>
			<!-- Upload Info -->
			<div id="uploadInfo">
			<input type="hidden" name="no_of_files" value="<?php if(isset($arrDocuments)) echo sizeof($arrDocuments)+1; else echo 1;?>" />
			<fieldset id="uploadInfoFieldSet"><legend>Uploads</legend>
				<?php if(isset($arrDocuments)){
					foreach($arrDocuments as $documentDetails){	?>
					<?php $fileDetails=explode('.',$documentDetails['doc_path']);
							$fileExt=$fileDetails[1];
						?>
					<div class="uploadContainer uploadedFiles" id="doc<?php echo $documentDetails['id'];?>">
						<p>
							<label>Document Name:</label>
							<?php echo $documentDetails['doc_name'].".".$fileExt?>
						</p>
						<p>
							<label>Description:</label>
							<?php echo $documentDetails['description'];?>
						</p>
						<p>
							<label class="removeLabel" onclick="deleteDocument(<?php echo $documentDetails['id'];?>);"><img src="<?php echo base_url();?>images/delete.png" alt="Delete" title="Delete"/></label>
						</p>
					</div>
				<?php }}?>
				<div id="uploadFileds" class="uploadContainer"> 
					<p>
						<label for=docName1>Document Name:</label>
						<input type="text" name="doc_name1" id="docName1" />
					</p>
					<p>
						<label for=description1>Description:</label>
						<input type="text" name="description1" id="description1" />
					</p>
					<p>
						<label for="filePath1">Upload:</label>
						<input type="file" name="file_path1" id="filePath1" <?php if(isset($arrDocuments) && sizeof($arrDocuments)==5) echo "disabled='disabled'";?>/>
					</p>
						<label id="addMoreFile" onclick="addAnotherUpload();"><img src="<?php echo base_url();?>images/bullet_add.png" alt="Add" title="Add"/></label>
					
				</div>
			</fieldset>
			</div>
			<div class="alignCenter">
				<p style="padding-top:5px;"><input name="save_info" id="savePersonalInfo" type="submit" value="Save" /></p>
			</div>
		</form>
	</div>
</div>