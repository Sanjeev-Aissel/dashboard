<?php
class Import extends CI_Model {	
	
	function getAllKols(){
		$this->db->select(array('kols.id as id', 'kols.id as kol_id', 'kols.salutation', 'concat(COALESCE(kols.first_name,"")," ", COALESCE(kols.middle_name,"")," ", COALESCE(kols.last_name,"")) as kol_name', 'specialties.specialty as kol_speciality', 'kols.gender as kol_gender', 'organizations.name as kol_org', 'concat(COALESCE(client_users.first_name,"")," ", COALESCE(client_users.last_name,"")) as kol_created_by', 'kols.pin as kol_pin', 'kols.status as kol_status','kols.is_pubmed_processed','kols.is_clinical_trial_processed'));
		$this->db->join ( 'specialties', 'specialties.id = kols.specialty', 'left' );
		$this->db->join ( 'organizations', 'organizations.id = kols.org_id', 'left' );
		$this->db->join ( 'client_users', 'client_users.id = kols.created_by', 'left' );
		$this->db->order_by( 'kol_name', 'asc' );
		$arrKolsResult = $this->db->get ( 'kols' );
		//pr($this->db->last_query());exit;
		return $arrKolsResult->result_array();
	}
	
	function getKolsNotAssociatedWithClient($clientId){
		$this->db->select('kols.id');
		$this->db->join ( 'kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left' );
		$this->db->where ( 'kols_client_visibility.client_id', $clientId );
		$arrKolIdsResult = $this->db->get ( 'kols' );
		$arrKolIds = array();
		foreach ($arrKolIdsResult->result_array() as $row) {
			$arrKolIds[] = $row['id'];
		}
	
		$this->db->select(array('kols.id as id', 'kols.id as kol_id', 'kols.salutation', 'concat(COALESCE(kols.first_name,"")," ", COALESCE(kols.middle_name,"")," ", COALESCE(kols.last_name,"")) as kol_name', 'specialties.specialty as kol_speciality', 'kols.gender as kol_gender', 'organizations.name as kol_org', 'concat(COALESCE(client_users.first_name,"")," ", COALESCE(client_users.last_name,"")) as kol_created_by', 'kols.pin as kol_pin', 'kols.status as kol_status','kols.is_pubmed_processed','kols.is_clinical_trial_processed'));
		$this->db->join ( 'specialties', 'specialties.id = kols.specialty', 'left' );
		$this->db->join ( 'organizations', 'organizations.id = kols.org_id', 'left' );
		$this->db->join ( 'client_users', 'client_users.id = kols.created_by', 'left' );
	
		if(sizeof($arrKolIds) > 0){
			$this->db->where_not_in ( 'kols.id', $arrKolIds );
		}
	
		$this->db->order_by( 'kol_name', 'asc' );
		$arrKolsResult = $this->db->get ( 'kols' );
		//pr($this->db->last_query());exit;
		return $arrKolsResult->result_array();
	}
}