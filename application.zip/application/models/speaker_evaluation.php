<?php

/**
 * Model for Client users operations
 * 
 * @package application.models
 * @author Vinayak Malladad
 * @since 1.5
 * @created on  01-03-11
 */
class speaker_evaluation extends model {

    function speaker_evaluation() {
        parent::model();
    }

    function saveEvaluation($data) {

        $this->db->insert('speaker_evaluations', $data);
        return $this->db->insert_id();
    }

    function getSpeakerDetail($kolId = null) {
        
        $arrParams = $_POST; 
        $users=$this->common_helpers->getManagerAlignedUsers($arrParams['manager_id']);
        $this->db->select('speaker_evaluations.id as row_id,speaker_evaluations.evaluator,speaker_evaluations.program_date,speaker_evaluations.program_topic,kols.id as kol_id,concat(client_users.first_name," ",client_users.last_name) as user_name,kols.first_name,kols.middle_name,kols.last_name,speaker_evaluations.created_by,speaker_evaluations.created_on', false);
        $this->db->join('kols', 'kols.id=speaker_evaluations.kol_id', 'left');
        if ($kolId != null && !is_array($kolId)) {
            $this->db->where('kols.id', $kolId);
        }
        $this->db->join('client_users', 'client_users.id=speaker_evaluations.created_by', 'left');
//        $this->db->where('client_users.client_id', $this->session->userdata('client_id'));
        $this->db->order_by('speaker_evaluations.created_on', 'desc');
        $dateString = "";
        if ($arrParams['start_date'] != '' && $arrParams['end_date'] != '')
            $dateString = ' BETWEEN "' . $arrParams['start_date'] . '" AND "' . $arrParams['end_date'] . '"';
        else if ($arrParams['start_date'] != '')
            $dateString = ' >= "' . $arrParams['start_date'] . '"';
        else if ($arrParams['end_date'] != '')
            $dateString = ' <= "' . $arrParams['end_date'] . '"';

        if ($dateString != '') {
            $this->db->where('speaker_evaluations.program_date ' . $dateString);
        }
        if (isset($arrParams['msl'])) {

            $this->db->where_in("speaker_evaluations.created_by", $arrParams['msl']);
        }
        if (isset($arrParams['team'])) {
            $this->db->join('user_groups', 'user_groups.user_id=speaker_evaluations.created_by', 'left');
            $this->db->join('groups', 'groups.group_id=user_groups.group_id', 'left');

            $this->db->where_in('user_groups.group_id ', $arrParams['team']);
        }
         if (isset($arrParams['manager_id'])) {
                
                $this->db->where_in("speaker_evaluations.created_by", $users);
        }
        $this->db->group_by('speaker_evaluations.id');
        $arrResultSet = $this->db->get('speaker_evaluations');
        //echo $this->db->last_query();
        foreach ($arrResultSet->result_array() as $row) {
            if (IS_IPAD_REQUEST) {
                $row['kol_name'] = '<a href="' . base_url() . IPAD_URL_SEGMENT . '/kols/view/' . $row['kol_id'] . '">' . $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']) . '</a>';
            } else {
                $row['kol_name'] = '<a target="_NEW" href="' . base_url() . 'kols/view/' . $row['kol_id'] . '">' . $this->common_helpers->get_name_format($row['first_name'], $row['middle_name'], $row['last_name']) . '</a>';
            }
            $row['program_date'] = sql_date_to_app_date($row['program_date']);
            $arrDetail[] = $row;
        }
        return $arrDetail;
    }

    function getDetail($id = '') {
        //$this->db->select('ols.last_name) as kol_name,speaker_evaluations.created_by,speaker_evaluations.created_on',false);
        $this->db->select('kols.id as kol_id,concat(client_users.first_name," ",client_users.last_name) as user_name,concat(kols.first_name," ",kols.middle_name," ",kols.last_name) as kol_name,speaker_evaluations.created_by,speaker_evaluations.created_on,speaker_evaluations.*', false);
        $this->db->join('kols', 'kols.id=speaker_evaluations.kol_id', 'left');
        $this->db->join('client_users', 'client_users.id=speaker_evaluations.created_by', 'left');
        if ($id != '')
            $this->db->where('speaker_evaluations.id', $id);
        $arrResultSet = $this->db->get('speaker_evaluations');
//        echo $this->db->last_query();
        if ($id != '') {
            foreach ($arrResultSet->result_array() as $row) {
                $arrDetail = $row;
            }
            return $arrDetail;
        } else
            return $arrResultSet->result_array();
    }

    function getRatingDetail($id) {

        $this->db->where('speaker_ratings.parent_question_id', $id);
        $arrResultSet = $this->db->get('speaker_ratings');
        //echo $this->db->last_query();
        foreach ($arrResultSet->result_array() as $row) {
            $arrDetail[$row['question_id']] = $row;
        }
        return $arrDetail;
    }

    function saveSpeakerRating($data) {

        $this->db->insert('speaker_ratings', $data);
        return $this->db->insert_id();
    }

    function getSpeakerFilteredData() {
//            pr($_POST); exit;
        $userId = $this->session->userdata('user_id');
       $userRole = $this->session->userdata('user_role_id');
       $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
       $teamName = $this->common_helpers->getUserTeamName($userId);
        $params = array("evaluator", "speaker_detail", "speaker_background", "moderated_program", "venu", "venu_presentation", "audio_setup", "program_topic", "abilify_maintena", "rexulti", "nuedexta", "samsca", "speaker_stay", "saftey_info", "mirf", "adverse_event", "adverse_event_report", "speaker_articulation", "mirf_doc", "guideline", "msl_follow_up", "topic_presented", "scale","psychu");
        foreach ($params as $key => $value) {
            //$this->db->select("speaker_evaluations.$value as $value, count(speaker_evaluations.$value)  as count,speaker_evaluations.*,speaker_ratings.value as speaker_rating,count(speaker_ratings.value)  as speaker_ratings_count,speaker_ratings.*",false);
            $this->db->select("$value as $value, count($value)  as count,speaker_evaluations.*", false);
             $this->db->join('client_users', 'client_users.id=speaker_evaluations.created_by', 'left');
//      if($value="id")                   
            //     $this->db->join('speaker_ratings','speaker_ratings.parent_question_id=speaker_evaluations.id','left');  
//             $clientId = $this->session->userdata('client_id');
//        if ($clientId != INTERNAL_CLIENT_ID) {
//            $this->db->where('client_users.client_id', $clientId);
//            $this->db->where_in('client_users.user_from', array(1, 2, 3));
//        }
             $this->db->group_by("speaker_evaluations.$value");
            $this->db->where("speaker_evaluations.$value IS NOT NULL");
            $arrParams = $_POST;
            $dateString = "";
            if ($arrParams['start_date'] != '' && $arrParams['end_date'] != '')
                $dateString = ' BETWEEN "' . $arrParams['start_date'] . '" AND "' . $arrParams['end_date'] . '"';
            else if ($arrParams['start_date'] != '')
                $dateString = ' >= "' . $arrParams['start_date'] . '"';
            else if ($arrParams['end_date'] != '')
                $dateString = ' <= "' . $arrParams['end_date'] . '"';
            if ($dateString != '') {
                $this->db->where('speaker_evaluations.program_date ' . $dateString);
            }
            if (isset($arrParams['msl'])) {
                $this->db->where_in("speaker_evaluations.created_by", $arrParams['msl']);
            }
            if (isset($arrParams['team'])) {
                $this->db->join('user_groups', 'user_groups.user_id=speaker_evaluations.created_by', 'left');
                $this->db->join('groups', 'groups.group_id=user_groups.group_id', 'left');
                $this->db->where_in('user_groups.group_id ', $arrParams['team']);
            }
//               if($userRole == ROLE_USER){
//           $this->db->where('speaker_evaluations.created_by', $userId);
//       }
//       if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
//           $this->db->where_in('speaker_evaluations.created_by', $userIds);
//       }
      
            $arrResultSet = $this->db->get('speaker_evaluations');
//          echo $this->db->last_query(); exit;
            foreach ($arrResultSet->result_array() as $row) {
                $row[$value . '_count'] = $row['count'];
                $arrDetail[$value][] = $row;
            }
        }
//                 echo json_encode($arrDetail);
        return $arrDetail;
    }

    function getMslForSpeaker() {
        $arrMsl = array();
        $userId = $this->session->userdata('user_id');
        $userRole = $this->session->userdata('user_role_id');
        $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
        $teamName = $this->common_helpers->getUserTeamName($userId);
        $this->db->select('count(distinct speaker_evaluations.id) as entry_count ,client_users.*');
        $this->db->join('client_users', 'client_users.id=speaker_evaluations.created_by', 'left');
        $this->db->where('speaker_evaluations.created_by IS NOT NULL');
        $clientId = $this->session->userdata('client_id');
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2, 3));
        }
        
        $this->db->group_by('client_users.id');
        $this->db->order_by('client_users.user_name', 'asc');
        if($userRole == ROLE_USER){
           $this->db->where('client_users.id', $userId);
        }
        if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
            $this->db->where_in('client_users.id', $userIds);
        }
        $arrCoachingResultSet = $this->db->get('speaker_evaluations');
        foreach ($arrCoachingResultSet->result_array() as $row) {
            $row['username'] = $row['first_name'] . ' ' . $row['last_name'];
            $row['entry_count'] = $row['entry_count'];
            $arrMsl[] = $row;
        }
//         echo $this->db->last_query();
        return $arrMsl;
    }

    function getSpeakerRatingFilteredData() {
//      $arrParams = $_POST;
        $userId = $this->session->userdata('user_id');
       $userRole = $this->session->userdata('user_role_id');
       $userIds = $this->common_helpers->getTeamOtherUserIDs($userId);
       $teamName = $this->common_helpers->getUserTeamName($userId);
        $this->db->select("value as speaker_rating, count(value)  as count, speaker_ratings.*,speaker_evaluations.*,", false);
        $this->db->join('speaker_evaluations', 'speaker_evaluations.id=speaker_ratings.parent_question_id', 'left');
          $this->db->join('client_users', 'client_users.id=speaker_evaluations.created_by', 'left');
         $clientId = $this->session->userdata('client_id');
        if ($clientId != INTERNAL_CLIENT_ID) {
            $this->db->where('client_users.client_id', $clientId);
            $this->db->where_in('client_users.user_from', array(1, 2, 3));
        }
        $this->db->where("speaker_ratings.value IS NOT NULL");
        $arrParams = $_POST;
        $dateString = "";
        if ($arrParams['start_date'] != '' && $arrParams['end_date'] != '')
            $dateString = ' BETWEEN "' . $arrParams['start_date'] . '" AND "' . $arrParams['end_date'] . '"';
        else if ($arrParams['start_date'] != '')
            $dateString = ' >= "' . $arrParams['start_date'] . '"';
        else if ($arrParams['end_date'] != '')
            $dateString = ' <= "' . $arrParams['end_date'] . '"';
        if ($dateString != '') {
            $this->db->where('speaker_evaluations.program_date ' . $dateString);
        }
        if (isset($arrParams['msl'])) {
            $this->db->where_in("speaker_evaluations.created_by", $arrParams['msl']);
        }
        if (isset($arrParams['team'])) {
            $this->db->join('user_groups', 'user_groups.user_id=speaker_evaluations.created_by', 'left');
            $this->db->join('groups', 'groups.group_id=user_groups.group_id', 'left');
            $this->db->where_in('user_groups.group_id ', $arrParams['team']);
        }
        
         $this->db->group_by("speaker_ratings.value");
        $this->db->order_by('count', 'desc');
        if($userRole == ROLE_USER){
           $this->db->where('speaker_evaluations.created_by', $userId);
       }
       if(($userRole == ROLE_MANAGER || $userRole == ROLE_ADMIN) && strtolower($teamName) != "home office"){
           $this->db->where_in('speaker_evaluations.created_by', $userIds);
       }
      
        $arrResultSet1 = $this->db->get('speaker_ratings');
//               echo $this->db->last_query(); exit;
        foreach ($arrResultSet1->result_array() as $row) {
            $row['speaker_ratings_count'] = $row['count'];
            $arrDetail['speaker_ratings'][] = $row;
        }
        return $arrDetail;
    }

    function exportSpeakerReport($arrSpeakerId) {
$arrQuestions = array(1=>'Product / Topic Knowledge',2=>'Effectiveness of delivery',3=>'Ability to answer questions',4=>"Ability to hold the audience's
attention",5=>'Ability to engage audience in discussion',6=>'Provided an impactful presentation',7=>'Ability to present in fair and balanced manner');
        $allDetails = $this->getDetail();

        foreach ($allDetails as $key => $value) {


            if (in_array($value["id"], $arrSpeakerId)) {
               
                $ratings = $this->getRatingDetail($value['id']); //All 7 Ratings
                $stateCity=explode(',',$value["venu_city"]);
                $arrSepaker[] = array("id" => $value["id"],
                    "generic_id"=>$value["generic_id"],
                    "user_name" => $value["user_name"],
                    "evaluator" => $value["evaluator"],
                    "evaluator_name" => $value["evaluator_name"],
                    "program_date" => $value["program_date"],
                    "no_of_attendees" => $value["no_of_attendees"],
                    "speaker_detail" => $value["speaker_detail"],
                    "speaker_name" => $value["speaker_name"],
                    "speaker_background" => $value["speaker_background"],
                    "speaker_text" => $value["speaker_text"],
                    "moderated_program" => $value["moderated_program"],
                    "venu" => $value["venu"],
                    "venu_city" => $value["venu_city"],
                    "venu_presentation" => $value["venu_presentation"],
                    "venu_presentation_comments" => $value["venu_presentation_comments"],
                    "audio_setup" => $value["audio_setup"],
                    "audio_setup_comments" => $value["audio_setup_comments"],
                    "program_topic" => $value["program_topic"],
                    "abilify_maintena" => $value["abilify_maintena"],
                    "rexulti" => $value["rexulti"],
                    "nuedexta" => $value["nuedexta"],
                    "samsca" => $value["samsca"],
                    "disease_state" => $value["disease_state"],
                    "psychu" => $value["psychu"],
                    "topic_presented" => $value["topic_presented"],
                    "action" => $value["action"],
                    "speaker_stay" => $value["speaker_stay"],
                    "saftey_info" => $value["saftey_info"],
                    "mirf_other" => $value["mirf_other"],
                    "mirf" => $value["mirf"],
                    "adverse_event" => $value["adverse_event"],
                    "adverse_event_report" => $value["adverse_event_report"],
                    "speaker_articulation" => $value["speaker_articulation"],
                    "speaker_articulation_comment" => $value["speaker_articulation_comment"],
                    "mirf_doc" => $value["mirf_doc"],
                    "mirf_comment" => $value["mirf_comment"],
                    "guideline" => $value["guideline"],
                    "scale" => $value["scale"],
                    "msl_follow_up" => $value["msl_follow_up"],
                    "msl_follow_up_comment" => $value["msl_follow_up_comment"],
                    
                    "q1" => $ratings[1]['value'],
                    "q2" => $ratings[2]['value'],
                    "q3" => $ratings[3]['value'],
                    "q4" => $ratings[4]['value'],
                    "q5" => $ratings[5]['value'],
                    "q6" => $ratings[6]['value'],
                    "q7" => $ratings[7]['value'],
                    "state"=>$stateCity[1],
                    "city"=>$stateCity[0]
                );
            }
//            pr($arrSepaker);
        }
        return $arrSepaker;
    }

}
