<script type="text/javascript" src="<?php echo base_url()?>js/jquery.blockUI.js"></script>
<script type="text/javascript">
function loadURL(){
	var page = $('#selectedPage').val();
	var newURL = "<?php echo base_url();?>master_data_controller/view_types/"+page;
 	window.location = newURL;
}
</script>
</head>
<body>
<div class="extraOptions">
<label>Select Category : </label>
		<select name="master_data_controller" id="selectedPage" onchange="loadURL();">
			<option value="Regions" <?php echo $type=="Regions" ? "selected" : "";?>>Regions</option>
			<option value="Titles" <?php echo $type=="Titles" ? "selected" : "";?>>Titles</option>
			<option value="Topics" <?php echo $type=="Topics" ? "selected" : "";?>>Topics</option>
			<option value="Product" <?php echo $type=="Product" ? "selected" : "";?>>Product</option>
			<option value="Email_Type" <?php echo $type=="Email_Type" ? "selected" : "";?>>Email Type</option>
			<option value="Phone_Type" <?php echo $type=="Phone_Type" ? "selected" : "";?>>Phone Type</option>
			<option value="Specialties" <?php echo $type=="Specialties" ? "selected" : ""; ?>>Specialities</option>
			<option value="Event_Roles" <?php echo $type=="Event_Roles" ? "selected" : "";?>>Event Roles</option>
			<option value="Event_Topics" <?php echo $type=="Event_Topics" ? "selected" : "";?>>Event Topics</option>
			<option value="Event_Org_Types" <?php echo $type=="Event_Org_Types" ? "selected" : "";?>>Event Org types</option>
			<option value="Discussion_Type" <?php echo $type=="Discussion_Type" ? "selected" : "";?>>Discussion Type</option>
			<option value="Interaction_Type" <?php echo $type=="Interaction_Type" ? "selected" : "";?>>Interaction Type</option>
			<option value="Interaction_Location" <?php echo $type=="Interaction_Location" ? "selected" : "";?>>Interaction Location</option>
			<option value="Engagement_Types" <?php echo $type=="Engagement_Types" ? "selected" : "";?>>Engagement Types</option>
			<option value="Organization_Types" <?php echo $type=="Organization_Types" ? "selected" : "";?>>Organization Types</option>
			<option value="Requested_By" <?php echo $type=="Requested_By" ? "selected" : "";?>>Requested By</option>
			<option value="Paid_By" <?php echo $type=="Paid_By" ? "selected" : "";?>>Paid By</option>
			<option value="Payment_Type" <?php echo $type=="Payment_Type" ? "selected" : "";?>>Payment Type</option>
			<option value="Payment_Currency" <?php echo $type=="Payment_Currency" ? "selected" : "";?>>Payment Currency</option>			
			<option value="conf_event_types"<?php echo $type=="conf_event_types" ? "selected" : "";?>>Event Type</option>
			<option value="event_sponsor_types"	<?php echo $type=="event_sponsor_types" ? "selected" : "";?>>Sponsor Type</option>
			<option value="conf_session_types" <?php echo $type=="conf_session_types" ? "selected" : "";?>>Session Type</option>
		</select>
<a class="addLink" style="cursor: pointer;" onclick="openCountryForm();"><img src="<?php echo base_url();?>images/bullet_add.png" border="0" style="height: 30px;vertical-align: middle;" />Add Country</a>
<p align="right" style="float: right;" class="addLink">
	<input type="button" value="Import" id="masterImportButton"
			onclick="importMasterData()" />
	<input type="button" value="Export" id="masterExportButton"
			onclick="exportMasterData()" />
</p>
</div>
<div id="countryGridWrapper"> 
	<table id="countryTable"></table>
	<div id="pager10"></div>
</div>
<br />
 <div class="extraOptions">
 <div class="rightSideOptions">
<a class="addLink" style="cursor: pointer;" onclick="openStateForm();"><img src="<?php echo base_url();?>images/bullet_add.png" border="0" style="height: 30px;vertical-align: middle;" />Add State</a>
</div>
</div>
<div id="stateGridWrapper"> 
<table id="stateTable"></table>
<div id="pager10_d"></div>
</div>
<br />
 <div class="extraOptions">
 <div class="rightSideOptions">
  <a class="addLink" style="cursor: pointer;" onclick="openCityForm();"><img src="<?php echo base_url();?>images/bullet_add.png" border="0" style="height: 30px;vertical-align: middle;" />Add City</a>
</div>
</div>
<div id="cityGridWrapper"> 
<table id="cityTable"></table>
<div id="pager10_c"></div>
<br>
</div>
<div id="userContainer" class="microViewLoading">
	<div class="addC"></div>
</div>
<div id="exportKolsDialog">	
		<div id="exportKolsContainer" class="microProfileDialogBox">
			<div class="profileContent" id="exportKolsProfileContent"></div>
		</div>
	</div>
<script>
$(document).ready(function (){
	loadCountries();
});
function loadCountries(){
	$('#countryGridWrapper').html("");
	$('#countryGridWrapper').html('<table id="countryTable"></table><div id="pager10"></div>');
	jQuery("#countryTable").jqGrid({
	   	url:'<?php echo base_url();?>master_data_controller/country_jqgrid',
		datatype: "json",
		colNames:['Id','Name','Capital','Nationality Singular','Nationality Plural','Currency','Actions'],
		colModel:[
			{name:'Id',index:'CountryId',hidden:true,search:false,align:"center"},
			{name:'Name',index:'Country',search:true,align:"left"},
			{name:'Capital',index:'Capital',search:true,align:"left"},
			{name:'NationalitySingular',index:'NationalitySingular',search:true,align:"left"},
			{name:'NationalityPlural',index:'NationalityPlural',search:true,align:"left"},
			{name:'Currency',index:'Currency',search:true,align:"left"},
			{name:'action',index:'action',search:false,align:'center'}
		],	
		height:'auto',
		autowidth:true,
		rownumbers: true,
		rowList:paginationValues,
		mtype: "POST",
		recordpos: 'left',
		loadonce: false,
	   	pager: '#pager10',
		rowNum:10,
	   	sortname: 'id',
	    viewrecords: true,
	    sortorder: "desc",
		caption: "Countries",
		onSelectRow: function(ids){
			var rowid = $("#countryTable").jqGrid('getGridParam','selrow');
			var rowData = $("#countryTable").getRowData(rowid);
			if(ids == null) {
				ids=0;
			}
			jQuery("#stateTable").jqGrid('setGridParam',{url:"<?php echo base_url();?>master_data_controller/states_jqgrid/1/"+ids});
			jQuery("#stateTable").jqGrid('setCaption',"States of "+rowData.Name).trigger('reloadGrid');
		}
	});
	jQuery("#countryTable").jqGrid('navGrid','#pager10',{add:false,del:false,edit:false,position:'right',search:false}); 
	jQuery("#countryTable").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
	jQuery("#countryTable").jqGrid('navButtonAdd',"#pager10",{caption:"Search",buttonicon:"ui-icon-search",title:"Toggle Search",
		onClickButton:function () {
        if (jQuery("#countryGridWrapper").find(".ui-search-toolbar").css("display") == "none") {
        	jQuery("#countryGridWrapper").find(".ui-search-toolbar").css("display", "");
        } else {
        	jQuery("#countryGridWrapper").find(".ui-search-toolbar").css("display", "none");
        }
    }});
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
jQuery("#stateTable").jqGrid({
	height: 100,
    url:'<?php echo base_url();?>master_data_controller/states_jqgrid',
	datatype: "json",
	colNames:['Id','Name','Code','Actions'],
	colModel:[
		{name:'Id',index:'RegionId',search:false,hidden:true,align:"center"},
		{name:'Name',index:'Region',search:true,align:"left"},
		{name:'Code',index:'Code',search:true,align:"left"},
		{name:'action',index:'action',search:false,align:'center'}
	],
	height:'auto',
	autowidth:true,
	rownumbers:true,
	rowList:paginationValues,
	rowNum:10,
	mtype: "POST",
	recordpos: 'left',
	loadonce: false,
   	pager: '#pager10_d',
   	sortname: 'id',
    viewrecords: true,
    sortorder: "desc",
	caption:"States",
	onSelectRow: function(ids) {
		var rowid = $("#stateTable").jqGrid('getGridParam','selrow');
		var rowData = $("#stateTable").getRowData(rowid);
		if(ids == null) {
			ids=0;
		}
				jQuery("#cityTable").jqGrid('setGridParam',{url:"<?php echo base_url();?>master_data_controller/cities_jqgrid/1/"+ids});
				jQuery("#cityTable").jqGrid('setCaption',"Cities of  "+rowData.Name)
				.trigger('reloadGrid');
	}
})
jQuery("#stateTable").jqGrid('navGrid','#pager10_d',{add:false,del:false,edit:false,position:'right',search:false}); 
jQuery("#stateTable").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
jQuery("#stateTable").jqGrid('navButtonAdd',"#pager10_d",{caption:"Search",buttonicon:"ui-icon-search",title:"Toggle Search",
	onClickButton:function () {
        if (jQuery("#stateGridWrapper").find(".ui-search-toolbar").css("display") == "none") {
        	jQuery("#stateGridWrapper").find(".ui-search-toolbar").css("display", "");
        } else {
        	jQuery("#stateGridWrapper").find(".ui-search-toolbar").css("display", "none");
        }
    }
});
///////////////////////////////////////////////////////////////////////////////////////////////
jQuery("#cityTable").jqGrid({
   	url:'<?php echo base_url();?>master_data_controller/cities_jqgrid',
	datatype: "json",
	colNames:['Id','Name','Latitude','Longitude','Timezone','Code','Actions'],
	colModel:[
		{name:'Id',index:'CityId',hidden:true,search:false,align:"center"},
		{name:'Name',index:'City',search:true,align:"left"},
		{name:'Latitude',index:'Latitude',search:true,align:"left"},
		{name:'Longitude',index:'Longitude',search:true,align:"left"},
		{name:'TimeZone',index:'TimeZone',search:true,align:"left"},
		{name:'Code',index:'Code',search:true,align:"left"},
		{name:'Actions',index:'action',search:false,align:'center'}
	],	
	height:'auto',
	autowidth:true,
	rownumbers: true,
	rowList:paginationValues,
	mtype: "POST",
	recordpos: 'left',
	loadonce: false,
   	rowNum:10,
   	pager: '#pager10_c',
   	sortname: 'id',
    viewrecords: true,
    sortorder: "desc",
	caption: "Cities",
});
	jQuery("#cityTable").jqGrid('navGrid','#pager10_c',{add:false,del:false,edit:false,position:'right',search:false}); 
	 jQuery("#cityTable").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"});
	jQuery("#cityTable").jqGrid('navButtonAdd',"#pager10_c",{caption:"Search",buttonicon:"ui-icon-search",title:"Toggle Search",
		onClickButton:function () {
	        if (jQuery("#cityGridWrapper").find(".ui-search-toolbar").css("display") == "none") {
	        	jQuery("#cityGridWrapper").find(".ui-search-toolbar").css("display", "");
	        } else {
	        	jQuery("#cityGridWrapper").find(".ui-search-toolbar").css("display", "none");
	        }
	    }
	});
	var modalBoxLayout = {    /// modal box
		title: "",
		modal: true,
 		width: 600,
		position: ['center', 90],
		resizable: true,
	};
	function openCountryForm($id = null){   //opens add_country view page on modal
		$(".addC").html("<div class='microViewLoading'>Loading...</div>");
		$("#userContainer").dialog(modalBoxLayout);
		if($id != null)
		$('#ui-dialog-title-userContainer').html('Edit Country');
		else
			$('#ui-dialog-title-userContainer').html('Add a Country');
		$(".addC").load('<?php echo base_url()?>master_data_controller/get_country_by_countryid/'+$id);
		return false;	
	}
	function saveCountryDetails(){          //save country details for a new country/updates existing country details
		if($("#saveCountryform").validate().form()){
		}else{
			return false;
		}
		var id=$("#CountryId").val();
		if(id != 0){
			var url = 'master_data_controller/check_master_association/countries';
			$.ajax({
				type:'post',
				url:'<?php echo base_url();?>'+url,
				data:"id="+id,
				success:function(returnData){
					if(returnData > 0){
						jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
							if(event){
								action = '<?php echo base_url();?>master_data_controller/save_country';
							$.ajax({
								type:'POST',
								url:action,
								dataType:'json',
								data:$("#saveCountryform").serialize(),
								success:function(respData){
									if(respData.saved == true) {
										$("#userContainer").dialog("close");
										loadCountries();
									}
									else
									{
										alert("Data is already presentin database Or Error in Updating/Adding Data");
										$("#userContainer").dialog("close");
									}
								},
								error:function(){
									alert("Error in Updating/Adding Data");
									$("#userContainer").dialog("close");
								}				
							 });
							}						
						});		
			 		}else if(returnData == 0){
				 		action = '<?php echo base_url();?>master_data_controller/save_country';
		 			$.ajax({
		 				type:'POST',
		 				url:action,
		 				dataType:'json',
		 				data:$("#saveCountryform").serialize(),
		 				success:function(respData){
		 					if(respData.saved == true) {
		 						$("#userContainer").dialog("close");
		 						loadCountries();
		 					}
		 					else
		 					{
		 						alert("Data is already presentin database Or Error in Updating/Adding Data");
		 						$("#userContainer").dialog("close");
		 					}
		 				},
		 				error:function(){
		 					alert("Error in Updating/Adding Data");
		 					$("#userContainer").dialog("close");
		 				}				
		 			 });
					}		 		
				}
			 });
			}else{			
				action = '<?php echo base_url();?>master_data_controller/save_country';
	 			$.ajax({
	 				type:'POST',
	 				url:action,
	 				dataType:'json',
	 				data:$("#saveCountryform").serialize(),
	 				success:function(respData){
	 					if(respData.saved == true) {
	 						$("#userContainer").dialog("close");
	 						loadCountries();
	 					}
	 					else
	 					{
	 						alert("Data is already presentin database Or Error in Updating/Adding Data");
	 						$("#userContainer").dialog("close");
	 					}
	 				},
	 				error:function(){
	 					alert("Error in Updating/Adding Data");
	 					$("#userContainer").dialog("close");
	 				}				
	 			 });
		}	
	}
	function deleteCountry(sId){		
		jConfirm("Are you sure you want to delete the Country?",'Please Confirm',function(event){
			if(event){
				if(sId != 0){
					var url = 'master_data_controller/check_master_association/countries';
					$.ajax({
						type:'post',
						url:'<?php echo base_url();?>'+url,
						data:"id="+sId,
						success:function(returnData){
							if(returnData > 0){
								jConfirm('This country is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){						
								});			
					 	} else {
					 		$.ajax({
								url: base_url+'master_data_controller/delete_country_by_countryid/'+sId,
								type:'POST',
								dataType:'json',
								success:function(returnData){
										if(returnData.status==1){
											jAlert('deleted');
											loadCountries();
									}else{
										jAlert('Not deleted');
									}
								}
								});
						 	}
							 	
						}
					 });
					}
			}
		
		});		
	}
	function openStateForm($id = null){   //opens add_country view page on modal
		$(".addC").html("<div class='microViewLoading'>Loading...</div>");
		$("#userContainer").dialog(modalBoxLayout);
		if($id != null)
			$('#ui-dialog-title-userContainer').html('Edit State');		
		else
			$('#ui-dialog-title-userContainer').html('Add a State');
		$(".addC").load('<?php echo base_url()?>master_data_controller/get_state_by_stateid/'+$id);
		return false;	
	}
	function saveStateDetails(){
		if($("#saveStateform").validate().form()){
		}else{
			return false;
		}
		var id=$("#RegionID").val();
		if(id != 0){
			var url = 'master_data_controller/check_master_association/states';
			$.ajax({
				type:'post',
				url:'<?php echo base_url();?>'+url,
				data:"id="+id,
				success:function(returnData){
					if(returnData > 0){
						jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
							if(event){
								action = '<?php echo base_url();?>master_data_controller/save_state';
								$.ajax({
									type:'post',
									url:action,
									data:$("#saveStateform").serialize(),
									dataType:'json',
									success:function(returnData){
										if(returnData.saved == true)
										{	
											$("#userContainer").dialog("close");
											jQuery("#stateTable").jqGrid().trigger('reloadGrid');
										}
										else
										{
											alert("Data is already presentin database Or Error in Updating/Adding Data");
											$("#userContainer").dialog("close");
										}
									},
									error:function(){
										alert("Error in Updating/Adding Data");
										$("#userContainer").dialog("close");
									}				
								 });
							}						
						});		
			 		}else if(returnData == 0){
			 			action = '<?php echo base_url();?>master_data_controller/save_state';
						$.ajax({
							type:'post',
							url:action,
							data:$("#saveStateform").serialize(),
							dataType:'json',
							success:function(returnData){
								if(returnData.saved == true)
								{	
									$("#userContainer").dialog("close");
									jQuery("#stateTable").jqGrid().trigger('reloadGrid');
								}
								else
								{
									alert("Data is already presentin database Or Error in Updating/Adding Data");
									$("#userContainer").dialog("close");
								}
							},
							error:function(){
								alert("Error in Updating/Adding Data");
								$("#userContainer").dialog("close");
							}				
						 });
					}		 		
				}
			 });
			}else{			
				action = '<?php echo base_url();?>master_data_controller/save_state';
				$.ajax({
					type:'post',
					url:action,
					data:$("#saveStateform").serialize(),
					dataType:'json',
					success:function(returnData){
						if(returnData.saved == true)
						{	
							$("#userContainer").dialog("close");
							jQuery("#stateTable").jqGrid().trigger('reloadGrid');
						}
						else
						{
							alert("Data is already presentin database Or Error in Updating/Adding Data");
							$("#userContainer").dialog("close");
						}
					},
					error:function(){
						alert("Error in Updating/Adding Data");
						$("#userContainer").dialog("close");
					}				
				 });
		}
			
	}
	function deleteSstate(sId){		
		jConfirm("Are you sure you want to delete the State?",'Please Confirm',function(event){
			if(event){
				if(sId != 0){
					var url = 'master_data_controller/check_master_association/states';
					$.ajax({
						type:'post',
						url:'<?php echo base_url();?>'+url,
						data:"id="+sId,
						success:function(returnData){
							if(returnData > 0){
								jConfirm('This state is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){						
								});			
					 	} else {
					 		$.ajax({
								url: base_url+'master_data_controller/delete_state_by_stateid/'+sId,
								type:'POST',
								dataType:'json',
								success:function(returnData){	
									if(returnData.status == 1){
											jAlert('Deleted');
											jQuery("#stateTable").jqGrid().trigger('reloadGrid');
									}else{
										jAlert('Not deleted');
									}
								}
								});

						 	}
							 	
						}
					 });
					}
			}
		
		});		
	}
	function openCityForm($id = null){   //opens add_country view page on modal
		$(".addC").html("<div class='microViewLoading'>Loading...</div>");
		$("#userContainer").dialog(modalBoxLayout);
		if($id != null)
			$('#ui-dialog-title-userContainer').html('Edit City');
		else
			$('#ui-dialog-title-userContainer').html('Add a City');
		$(".addC").load('<?php echo base_url()?>master_data_controller/get_city_by_cityid/'+$id);
		return false;	
	}
	function saveCityDetails(){
		if($("#saveCityform").validate().form()){
		}else{
			return false;
		}
		var id=$("#CityId").val();
		if(id != 0){
			var url = 'master_data_controller/check_master_association/cities';
			$.ajax({
				type:'post',
				url:'<?php echo base_url();?>'+url,
				data:"id="+id,
				success:function(returnData){
					if(returnData > 0){
						jConfirm('Updating will effect the '+returnData+' records are you shore want to continue','Please Confirm',function(event){
							if(event){
								action = '<?php echo base_url();?>master_data_controller/save_city';
								$.ajax({
										type:'POST',
										url:action,
										dataType:'json',
										data:$("#saveCityform").serialize(),
										success:function(respData){
											if(respData.saved == true)
											{
												$("#userContainer").dialog("close");
												jQuery("#cityTable").jqGrid().trigger('reloadGrid');
											}
											else
											{
												alert("Data is already presentin database Or Error in Updating/Adding Data");
												$("#userContainer").dialog("close");
											}
										},
										error:function(){
											alert("Error in Updating/Adding Data");
											$("#userContainer").dialog("close");
										}		
								});
							}						
						});		
			 		}else if(returnData == 0){
			 			action = '<?php echo base_url();?>master_data_controller/save_city';
						$.ajax({
								type:'POST',
								url:action,
								dataType:'json',
								data:$("#saveCityform").serialize(),
								success:function(respData){
									if(respData.saved == true)
									{
										$("#userContainer").dialog("close");
										jQuery("#cityTable").jqGrid().trigger('reloadGrid');
									}
									else
									{
										alert("Data is already presentin database Or Error in Updating/Adding Data");
										$("#userContainer").dialog("close");
									}
								},
								error:function(){
									alert("Error in Updating/Adding Data");
									$("#userContainer").dialog("close");
								}		
						});
					}		 		
				}
			 });
			}else{			
				action = '<?php echo base_url();?>master_data_controller/save_city';
				$.ajax({
						type:'POST',
						url:action,
						dataType:'json',
						data:$("#saveCityform").serialize(),
						success:function(respData){
							if(respData.saved == true)
							{
								$("#userContainer").dialog("close");
								jQuery("#cityTable").jqGrid().trigger('reloadGrid');
							}
							else
							{
								alert("Data is already presentin database Or Error in Updating/Adding Data");
								$("#userContainer").dialog("close");
							}
						},
						error:function(){
							alert("Error in Updating/Adding Data");
							$("#userContainer").dialog("close");
						}		
				});
		}
	}
	function deleteCity(cId){		
		jConfirm("Are you sure you want to delete the City ?",'Please Confirm',function(event){
			if(event){
				if(cId != 0){
					var url = 'master_data_controller/check_master_association/cities';
					$.ajax({
						type:'post',
						url:'<?php echo base_url();?>'+url,
						data:"id="+cId,
						success:function(returnData){
							if(returnData > 0){
								jConfirm('This city is associated with '+returnData+' records cannot be deleted','Please Confirm',function(event){						
								});			
					 	} else {
					 		$.ajax({
								url: base_url+'master_data_controller/delete_city_by_cityid/'+cId,
								type:'POST',
								dataType:'json',
								success:function(returnData){							
									if(returnData.status==1){
										jAlert('Deleted');
										jQuery("#cityTable").jqGrid().trigger('reloadGrid');
									}else{
										jAlert('Not deleted');
									}
								}
							});
						 	}
							 	
						}
					 });
					}
		}});		
	}
    function getStatesByCountryId() {   //get states names of that country ,onchange/selecting of a country.
        $("#loadingStates").show();
        var countryId = $('#CountryID').val();
        var params = "country_id=" + countryId;
        var states = document.getElementById('state_id');
        $.ajax({
            url: "<?php echo base_url() ?>country_helpers/get_states_by_countryid/",
            dataType: "json",
            data: params,
            type: "POST",
            success: function (responseText) {
            	$("#state_id").html('');
            	$("#state_id").append("<option value=''>-- Select State --</option>");
                $.each(responseText, function (key, value) {
                    $('#state_id').append("<option value='"+value.state_id+"'>"+value.state_name+"</option>");
                });
            },
            complete: function () {
                $("#loadingStates").hide();
            }
        });
    }
    $(document).ready(function(){
    	var modalBoxAddOpts = {
    			title: "",
    			modal: true,
    			autoOpen: false,
    			height:500,
    			width: 600,
    			dialogClass: "microView",
    			position: ['center', 160],
    			open: function() {
    			}
    	};
    	$("#exportKolsContainer").dialog(modalBoxAddOpts);
    	loadCountries();
    });
    function exportMasterData(){
    	$("#exportKolsContainer .profileContent").html("<div class='microViewLoading'>Loading...</div>");
    	$("#exportKolsContainer").dialog("open");
    	$("#exportKolsProfileContent").load('<?php echo base_url();?>master_data_controller/export_page');	
    }
    function importMasterData(){
    	var newURL = "<?php echo base_url();?>master_data_controller/import_page";
    	window.location = newURL;
    }
</script>
</body>
</html>