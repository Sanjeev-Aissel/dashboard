<?php
	// prepare array of JS files to insert into queue
	$queued_js_scripts =array(//'highcharts 2.1.0',
							//'highchartsTheme',
							'kols/list_kols_client_view',
							//'jquery.validate',
							'jquery/jquery.validate1.9.min',
							'jquery.autocomplete',
							'chosen.jquery'
							);
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
?>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet" />
<style type="text/css">
	.horizontalDotSeparator{
		border-top: 1px dotted gray;
	    padding-bottom: 10px;
	}
	.record_name a{
		color:#38537C;
	}
	#searchResultsContainer table td,table.listResultSet td {
		font-size:11px !important;
	}
	#searchResultsContainer.span-12 {
	    width: 482px;
	}
	.record_name{
		font-weight:bold;
		letter-spacing:1.5px
	}

	.span-4{
		width:172px;
	}
	#kolsBySpecialtyChartContainer {
		margin-top:0px;
	}
	#searchResultsContainer .searchResultsMsg {
		border-bottom: 1px solid #BBBBBB;
	    border-top: 1px solid #BBBBBB;
	    padding-bottom: 5px;
	}
	#categoryModalBox .microView .ui-dialog-content {
	    background-color: #F9F9F9;
	}
	.microView .ui-dialog-content {
	    background: none repeat scroll 0 0 transparent;
	}
	.expandRightSideBar{
		display: block !important;
	}
	ul.pageRightOptions {
	    float: right;
	    list-style: outside none none;
	    margin: 0;
	    padding: 0;
	}
	ul.pageRightOptions li {
	    float: left;
	    height: 25px;
	    line-height: 25px;
	    list-style: outside none none;
	    padding: 2px 3px;
	    min-width: 25px;
	}
	#searchResultsContainer ul.pageRightOptions{
		width: 120px;
	}
	#searchResultsContainer ul.pageRightOptions li{
		float: right;
	}
</style>

<script type="text/javascript">
	var viewType	= 'tabular';
	$(document).ready(function(){

		var addKolsCustomFilters={
			title: "Add Custom Filters",
			modal: true,
			autoOpen: false,
			width: 400,
			height: 400,
			dialogClass: "microView",
			draggable:false,
			open: function(){

			}
		};
		$( "#addKolsCustomFilters" ).dialog(addKolsCustomFilters);
		var alignUserOpts = {
				title: "Align Users",
				modal: true,
				autoOpen: false,
				width: 500,
				height:400,
				draggable:false,
				dialogClass: "microView",
				position: ['center', modalBoxTopPosition],
				open: function() {
					//display correct dialog content
				}
		};
		$("#alignUsersModalBox").dialog(alignUserOpts);

		var requestKolsProfiles = {
				title: "Request Profiles",
				modal: true,
				autoOpen: false,
				width: 500,
				height:200,
				draggable:false,
				dialogClass: "microView",
				position: ['center', modalBoxTopPosition],
				open: function() {
					//display correct dialog content
				}
		};
		$("#requestKolsProfiles").dialog(requestKolsProfiles);
		
	});
	function addFilters(){
		$("#addKolsCustomFilters .profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$('#addKolsCustomFilters').dialog("open");
		$('#addKolsCustomFiltersContainer').load(base_url+'kols/add_kol_saved_filters/');
	}
//	function editSavedFilters() {
//		$(".profileContent").html("<div class='microViewLoading'>Loading...</div>");
//		$('#addKolsCustomFilters').dialog("open");
//		$('#addKolsCustomFiltersContainer').load(base_url+'kols/add_kol_saved_filters/');
//	}

	function getSavedFilters(){
		$("#addKolsCustomFilters .profileContent").html("<div class='microViewLoading'>Loading...</div>");
		$('#addKolsCustomFilters').dialog("open");
		$('#addKolsCustomFiltersContainer').load(base_url+'kols/get_saved_filters/');
	}
	function alignUsers(){
		var values = new Array();
		if(allPageSelected == false){
			$.each($("input[name='list[]']:checked"), function() {
			  values.push($(this).val());
			});
		}
		else
			values=allPageKolIds;
		
		if(values==''){
			jAlert("Please select at least one <?php echo lang('KOL');?>");
		}else{
			$("#addKolsCustomFilters .profileContent").html("<div class='microViewLoading'>Loading...</div>");
			$("#alignUsersModalBox").dialog("open");
			$(".alignUsersContent").load('<?php echo base_url()?>align_users/align_kols/'+values);
		}
		return false;	
	}
	function cancelAlignmentBox(){
		$("#alignUsersModalBox").dialog("close");
	}

	function addNewKolProfile(KolId,thisEle){
		/*$(".newProfileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#newKolProfile").dialog("open");
		$(".newProfileContent").load(base_url+'requested_kols/add_client_pre_kol/'+KolId);
		*/
		jConfirm(profileRequestConfirmMessage,"Confirm message",function (r){
			if(r){
				requestProfile(KolId,thisEle);
				return false;
			}else{
				return false;
			}
		});
	}

	function requestProfile(KolId,thisEle){
		var userRoleId = <?php echo $this->session->userdata('user_role_id')?>;
		if(userRoleId == ROLE_MANAGER || userRoleId == ROLE_ADMIN){
			jAlert("The Profile has been requested for processing. You will get a notification once the requests are processed.");
		}else{
			jAlert("Your <?php echo lang("KOL");?>  Profile request has been submitted to your manager for approval. We will notify you when your request is approved");
		}
		$.ajax({
			url:'<?php echo base_url()?>requested_kols/request_kol_profile/'+KolId,
			type:'post',
			dataType:'json',
			success:function(returnData){
				if(returnData.saved==true){
					$(thisEle).remove();
					
				}else{
					jAlert("Unable to send request for profiling.");
				}
			}
		});
	}

	function addNewKolProfileUAL(KolId,thisEle){
		/*$(".newProfileContent").html("<div class='microViewLoading'>Loading...</div>");
		$("#newKolProfile").dialog("open");
		$(".newProfileContent").load(base_url+'requested_kols/add_client_pre_kol/'+KolId);
		*/
		$("#requestKolsProfiles .requestKolsProfiles").html("<div class='microViewLoading'>Loading...</div>");
		$("#requestKolsProfiles").dialog("open");
		$("#requestKolsContainer").load(base_url+'requested_kols/add_client_pre_kol/'+KolId+'/1');
	}
	
</script>
<!-- Load the refinedByFilter CSS file ---- Added by Laxman -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/refinedByFilter.css" />
<div id="searchContainer">
	<div id="searchTopMenus"></div>
	<div class="myKolLists1">
		<div id="searchResultsContainer" class="maxWidth"  style="float:left;">
			<?php echo $this->load->view($kolResultsPage,$kolResultsData);?>
		</div>
<!-- 	<div id="refinedByWrapper" class="rightRefinedByFilter">
			<div id="refinedByContainer">
				<div id="rightSideBarSlider" class="tooltip-demo tooltop-left collapseRightSideBar"><a href="#" class="tooltipLink" rel='tooltip' title="Show Refine By">&nbsp;</a></div>
				<div id="searchLeftBar" style="display: block;">
					
					<h3>
						<div class="funnelIcon sprite_iconSet"></div>Refine By
						<div id="resetBttnContainer"><label class="tooltip-demo tooltop-left" id="resetBttn" onclick="resetFilters();"><a href="#" class="tooltipLink" rel='tooltip' title="Reset Filters">&nbsp;</a></label>Reset</div>
					</h3>
					<div id="searchFiltersContainer">
						<?php //echo $this->load->view($filterPage,$filterData);?>
					</div>
				</div>
			</div>
		</div>
-->
	</div>
	<div class="clear">&nbsp;</div>

	<!-- Container for the 'Kol Micro Profile' modal box -->
	<div id="dailog1">	
		<div id="kolMicroProfile" class="microProfileDialogBox">
			<div class="profileContent"></div>
		</div>
	</div>
	<!-- End of the Container for the 'Kol Micro Profile' modal box -->
	
	<div id="categoryModalBox" class="microProfileDialogBox">
		<div class="addListContent profileContent"></div>
	</div>
	<div id="alignUsersModalBox" class="microProfileDialogBox">
		<div class="alignUsersContent profileContent"></div>
	</div>

<!-- Container for the 'Kol Micro Profile'  box -->
	<div id="contentHolder" class="callOutTest microView" style="display: none;">
		<div>
			<!--<img class="ui-icon ui-icon-closethick" alt="" src="" onclick="closeKolProfile();" />-->
			<a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeKolProfile();" class="ui-icon ui-icon-closethick">close</span></a>
		</div>
		<div class="profileContent"></div>
	</div>
	<div id="arraouHolder" class="callOutTest" style="display: none;"><div class="arrowMarkIcon"></div></div>
</div>
<!-- Container to add Custom filters -->
<div id="addKolsCustomFilters1"></div>
<div id="addKolsCustomFilters" class="addCustomFilters">
	<div id="addKolsCustomFiltersContainer" class="profileContent"></div>
</div>
<!-- Container for the 'Kol's Request' modal box -->
	<div id="requestKolsDialog">	
			<div id="requestKolsProfiles" class="requestKolsProfiles">
			<div class="requestKolsContainer" id="requestKolsContainer"></div>
		</div>
	</div>
	<!--End of  Container for the 'Kol's Request' modal box -->