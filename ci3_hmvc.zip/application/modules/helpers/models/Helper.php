<?php
class Helper extends CI_Model {
	function getTableFields($table_name){
		return $this->db->list_fields($table_name);
	}
	/**
	 * Retruns the Organization Types matching given string
	 * @author 	Ramesh B
	 * @since	2.6
	 * @return Array
	 * @created 25-07-2011
	 */
	function getMatchingOrgTypes($orgType){
		$this->db->distinct();
		$this->db->select('organization_types.id,organization_types.type');
		$this->db->join('organization_types','organizations.type_id=organization_types.id','left');
		$this->db->like('organization_types.type', $orgType);
		$arrResultSet = $this->db->get_where('organizations');
		$arrOrgTypes = array();
		foreach($arrResultSet->result_array() as $arrRow){
			$arrOrgTypes[$arrRow['id']] = $arrRow['type'];
		}
		return $arrOrgTypes;
	}
	function getMatchingRegions($region) {
		$this->db->select('*');
		$this->db->like('name', $region);
		$this->db->group_by('name');
		$arrResultSet = $this->db->get('regions');
		$arrTitleNames = array();
		foreach ($arrResultSet->result_array() as $arrRow) {
			$arrTitleNames[$arrRow['id']] = $arrRow['name'];
		}
		return $arrTitleNames;
	}
	/**
	 * Searches for the Country name and Returns the list of Organizer names matched
	 *
	 *
	 * @param $orgName
	 * @return Array	$arrRoleNames
	 */
	function getCountryNames($Country){
		$this->db->select('CountryId,Country');
		$this->db->like('Country', $Country);
		$this->db->join('kols','kols.country_id=countries.CountryId','inner');
		$this->db->group_by('country_id');
		$arrResultSet = $this->db->get('countries');
		$arrCountryNames = array();
		foreach($arrResultSet->result_array() as $arrRow){
			$arrCountryNames[$arrRow['CountryId']] = $arrRow['Country'];
		}
		return $arrCountryNames;
	}
	function getMatchingKolTitles($title) {
		$this->db->select('*');
		$this->db->like('title', $title);
		$arrResultSet = $this->db->get('titles');
		$arrTitleNames = array();
		foreach ($arrResultSet->result_array() as $arrRow) {
			$arrTitleNames[$arrRow['id']] = $arrRow['title'];
		}
		return $arrTitleNames;
	}
	/**
	 * Returns all the specialties
	 * @return array	- ID, and Name
	 */
	function getSpecialties($specialty){
		$arrSpecialties	= array();
		$this->db->select('specialties.id,specialties.specialty');
		$this->db->like('specialties.specialty',$specialty);
		$this->db->join('kols','kols.specialty=specialties.id','inner');
		$this->db->group_by('kols.specialty');
// 		$this->db->where('status',COMPLETED);
		$arrSpecialtiesResult = $this->db->get('specialties');		
		foreach($arrSpecialtiesResult->result_array() as $arrSpecialty){
			$arrSpecialties[$arrSpecialty['id']]	= $arrSpecialty['specialty'];
		}
		return $arrSpecialties;
	}
	/**
	 * Searches for the Country name and Returns the list of Organizer names matched
	 *
	 *
	 * @param $orgName
	 * @return Array	$arrRoleNames
	 */
	function getStateNamesForAutoComplete($state,$isGeneric=false,$country='',$limit=50,$offset=0){
		$this->db->select('name as state, countries.Country as country,states.id');
		$this->db->join('countries','countries.countryId=states.country_id','inner');
		if(!empty($country))
			$this->db->like('countries.Country', $country);
			if(strlen($state)>2){
				$this->db->like('name', $state);
			}else{
				$this->db->like('Code', $state);
			}
			if(!$isGeneric){
				$client_id = $this->session->userdata('client_id');
				$this->db->join('kols','kols.state_id=states.id','inner');
				//$this->db->where('kols.status',COMPLETED);
				if($client_id !== INTERNAL_CLIENT_ID){
					$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
					$this->db->where('kols_client_visibility.client_id', $client_id);
				}
				$this->db->group_by('state_id');
			}
			$this->db->order_by('name');
			$this->db->limit($limit,$offset);
			$arrResultSet = $this->db->get('states');
			$arrStateNames = array();
			foreach($arrResultSet->result_array() as $arrRow){
				$arrStateNames[$arrRow['id']][] = $arrRow['state'];
				$arrStateNames[$arrRow['id']][] = $arrRow['country'];
			}
			//echo $this->db->last_query();
			return $arrStateNames;
	}
	/*
	 *  Retrives all the list names and also there respective category names
	 *  @author Ramesh B
	 *  @since 2.2
	 *  @created on 3-5-2011
	 */
	function getListNameAndCategoryName($listName,$user_id,$client_id){
		$arrListDetails=array();
		
		$this->db->select("DISTINCT(list_kols.list_name_id),list_kols.list_name_id,list_names.list_name,list_categories.category");
		$this->db->join('list_names', 'list_kols.list_name_id=list_names.id', 'left');
		$this->db->join('list_categories', 'list_names.category_id=list_categories.id', 'left');
		$this->db->like('list_names.list_name',$listName);
		$this->db->where('list_categories.client_id',$client_id);
		$where="(list_categories.user_id=$user_id OR list_categories.is_public=1)";
		$this->db->where($where);
		$results=$this->db->get('list_kols');
		foreach($results->result_array() as $row){
			$arrListDetails[$row['list_name_id']]=$row;
		}
		//echo $this->db->last_query();
		return $arrListDetails;
	}
	function getOrganizationNamesWithStateCity($organizationName,$restrictByRegion=0) {
		$client_id = $this->session->userdata('client_id');
		$this->db->select('organizations.id,organizations.name,states.name as state,cities.city as city');
		$this->db->join('states', 'states.id = organizations.state_id', 'left');
		$this->db->join('cities', 'cities.cityID = organizations.city_id', 'left');
		if(ORGS_VISIBILITY){
			if ($client_id !== INTERNAL_CLIENT_ID) {
				$this->db->join('org_client_visibility','organizations.id = org_client_visibility.org_id','left');
				$this->db->where(array('org_client_visibility.client_id'=>$client_id,'org_client_visibility.is_visible'=>1));
			}
		}
		if($restrictByRegion){
			if(INTERNAL_CLIENT_ID != $client_id && $this->session->userdata('user_role_id') != ROLE_ADMIN){
				if($this->session->userdata('user_role_id') == ROLE_USER || $this->session->userdata('user_role_id') == ROLE_MANAGER){
					$group_names = explode(',', $this->session->userdata('group_names'));
					$this->db->join ( 'countries', 'countries.CountryId=organizations.country_id', 'left' );
					$this->db->where_in( 'countries.GlobalRegion', $group_names);
				}
			}
		}
		$this->db->like('organizations.name', $organizationName);
		$arrResultSet = $this->db->get('organizations');
		$arrOrganizationNames = array();
		foreach ($arrResultSet->result_array() as $arrRow) {
			$arrOrganizationNames[] = $arrRow;
		}
		return $arrOrganizationNames;
	}
	/**
	 * Searches for the InstituteName and Returns the list of Institution Names matched
	 *
	 * @param $instituteName
	 * @return Array	$arrInstituteNames	Ex: arry('NIIT', 'JetKing');
	 */
	function getInstituteNames($instituteName) {
		$this->db->select('institutions.id,name');
		$this->db->like('name', $instituteName, 'after');
		$this->db->limit(10);
		$this->db->distinct();
		$this->db->join('kol_educations', 'kol_educations.institute_id=institutions.id', 'inner');
		$arrResultSet = $this->db->get('institutions');
		
		$arrInstituteNames = array();
		foreach ($arrResultSet->result_array() as $arrRow) {
			$arrInstituteNames[$arrRow['id']] = $arrRow['name'];
		}
		return $arrInstituteNames;
	}
	/**
	 * Searches for the EventName and Returns the list of Event Names matched
	 *
	 * @param String $category
	 * @param String $eventName
	 * @return Array	$arrEventLookupNames
	 */
	function getSearchEventLookupNames($eventName) {
		$this->db->select('events.id,events.name');
		$this->db->like('name', $eventName);
		$this->db->join('kol_events', 'kol_events.event_id=events.id', 'inner');
		$this->db->join('kols', 'kol_events.kol_id=kols.id', 'inner');
		$this->db->group_by('events.id');
		$arrResultSet = $this->db->get('events');
		$arrEventLookupNames = array();
		foreach ($arrResultSet->result_array() as $arrRow) {
			$arrEventLookupNames[$arrRow['id']] = $arrRow['name'];
		}
		return $arrEventLookupNames;
	}
	function getAllKolNamesForAllAutocomplete($kolName) {
		$client_id = $this->session->userdata('client_id');
		$this->db->select ( "kols_client_visibility.id,kols.unique_id,first_name,middle_name,last_name,kols.status" );
		$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
		$this->db->where('concat(coalesce(first_name,"")," ",coalesce(middle_name,"")," ",coalesce(last_name,"")) like "%'.$kolName.'%"', '',false);
		$this->db->where ('kols.customer_status', "ACTV" );
		$this->db->where ('kols_client_visibility.client_id',$client_id);
		$arrKolsResult = $this->db->get ( 'kols' );
// 		echo $this->db->last_query();
		$arrCompletedKols= array();
		foreach ($arrKolsResult->result_array() as $arrRow) {
			$arrCompletedKols[$arrRow['id']] = $arrRow['first_name'].' '.$arrRow['middle_name'].' '. $arrRow['last_name'];
		}
		return $arrCompletedKols;
	}
}