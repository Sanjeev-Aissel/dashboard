<?php
/**
*Model for pubmed operations
*
*@package application.models
*@author Ramesh B
*@since
*@created on 06-01-11
*/

class Pubmed extends Model{

	//Constructore
	function Pubmed(){
		parent::Model();
		$this->load->model("common_helpers");
	}
	
	 /*
      * Returns list of pubmed-unprocessed kol in date Asecending order
      */
     function getPubmedUnprocessedKols(){
     	$arrKolDetails=array();
     	$arrStatus = array(0);
     	$this->db->select("id,salutation,first_name,middle_name,last_name,specialty");
     	$this->db->where_in('is_pubmed_processed',$arrStatus);
     	$this->db->where('kols.status',PROFILING);
     	$this->db->order_by("created_on", "asc");
     	$arrKolDetailResult=$this->db->get('kols');
	    foreach($arrKolDetailResult->result_array() as $arrKol){
	    			$arrKolDetails[]= $arrKol;
	    		}
	    //echo $this->db->last_query();
	    return $arrKolDetails;
     }
     
     /**
      * 
      * @param $pmid
      * @return unknown_type
      */
     function checkPubExist($pmid){
     	$pubId='';
     	$this->db->select('id');
     	$this->db->where('pmid',$pmid);
		$arrPubs=$this->db->get('publications');		
    	 if($arrPubs->num_rows()!=0){
			$pubObj=$arrPubs->first_row();
			$pubId=$pubObj->id;		
			} else {
			
			}
			return $pubId;
     }
	
	/**
	 * saves journalName and returns id of that, if the name already exist it will returns the id of that name
	 * @param string $journalName
	 * @return Integer, journalID 
	 */
	function savejournalName($journalName){
		$journalId='';
		$arrJournal['name']=$journalName;
		$this->db->where('name',$journalName);
		if($arrJournals=$this->db->get('pubmed_journals')){			
			if($arrJournals->num_rows()!=0){
				$journalObj=$arrJournals->first_row();
				$journalId=$journalObj->id;		
			}
			else {
				if($this->db->insert('pubmed_journals',$arrJournal)){
					$journalId=$this->db->insert_id();	      		
		      	}else{	      		
		      	
		      	}
			}
		}
		return $journalId;
	}
	
	/**
	 * Saves the publication record and returns the id of last inserted record
	 * @param  $pubDetails Aray, which contains publication details
	 * @return Integer, Publication Id
	 */
	function savePublication($pubDetails,$publicationId=0){
	    if($publicationId==0){
		 $pubId='';
		 if($this->db->insert('publications',$pubDetails)){
				$pubId=$this->db->insert_id();	      		
		 }else{	      		
		    
		 }	
		 return $pubId;
	    }else{
	        $this->db->update("publications",$pubDetails,array("id"=>$publicationId));
	    }
	}

	function saveKolPublication($kolPublication){	
		//For Crone sceduler Cliend id is =1 (Aissel client id)
		$clientId = $this->session->userdata('client_id');
		$userId = $this->session->userdata('user_id');
		$dataType = 'User Added';
		if($clientId == INTERNAL_CLIENT_ID){
		    $dataType = 'Aissel Analyst';
		}
		$kolPublication['data_type_indicator'] = $dataType;
		if(isset($userId) && $userId != ''){
			$kolPublication['client_id'] = $clientId;
			$kolPublication['user_id'] = $userId;
		}else{
			$kolPublication['client_id'] = INTERNAL_CLIENT_ID;
			$kolPublication['user_id'] = INTERNAL_USER_ID;
		}
		
		if($this->db->insert('kol_publications',$kolPublication)){
			return true;  		
		}else{	      		
		    return false;
		}		
	}
	
	function updateKolPublication($kolPublication){	
	    $clientId = $this->session->userdata('client_id');
	    $userId = $this->session->userdata('user_id');
	    $dataType = 'User Added';
	    if($clientId == INTERNAL_CLIENT_ID){
	        $dataType = 'Aissel Analyst';
	    }
	    $arrKolPubDetail['data_type_indicator'] = $dataType;
		$arrKolPubDetail['is_verified']	= $kolPublication['is_verified'];
		$arrKolPubDetail['is_deleted']	= $kolPublication['is_deleted'];
		$this->db->where('kol_id', $kolPublication['kol_id']);
		$this->db->where('pub_id', $kolPublication['pub_id']);
		if($this->db->update('kol_publications', $arrKolPubDetail)){
			return true;
		}else{
		    return false;
		}		
	}
	
	/**
	 * Saves the Author record and returns the id of last inserted record
	 * @param  Array $author, which contains the Author details
	 * @return Integer
	 */
	function savePubmedAuthor($author){
		$authId='';
		if($this->db->insert('pubmed_authors',$author)){
				$authId=$this->db->insert_id();	      		
		}else{	      		
		    
		}	
		return $authId;
	}
	
	/**
	 * Saves the record to associate the Author to publication
	 * @param Array $pubAuthor, Array containing the Publication to Author association
	 * @return boolean
	 */
	function savePublicationAuthor($pubAuthor){
		$this->db->select('id');
		$this->db->where('pub_id',$pubAuthor['pub_id']);
		$this->db->where('author_id',$pubAuthor['author_id']);
		$this->db->where('position',$pubAuthor['position']);
		$resultSet	= $this->db->get('publications_authors');
		if($resultSet->num_rows()!=0){
			return true;
		}else if($this->db->insert('publications_authors',$pubAuthor)){
				return true;	      		
		}else{	      		
		    return false;
		}	
	}
	
	/**
	 * Saves the MeshTerm record and returns the id of last inserted record
	 * @param $term
	 * @return Integer
	 */
	function savePubmedMeshTerm($term){
		$termId='';
		$this->db->select('id');
		$this->db->where('term_name',$term['term_name']);
		$this->db->where('parent_id',$term['parent_id']);
		$arrMeshTerms=$this->db->get('pubmed_mesh_terms');
		if($arrMeshTerms->num_rows()!=0){
			$meshTermObj=$arrMeshTerms->first_row();
			$termId=$meshTermObj->id;		
		} else{
			if($this->db->insert('pubmed_mesh_terms',$term)){
					$termId=$this->db->insert_id();	
					//Add Log activity
					$arrLogDetails = array(
							'type' => ADD_RECORD,
							'description' => 'Add New MeshTerm record',
							'status' => STATUS_SUCCESS,
							'kols_or_org_type' => 'Kol',
							'transaction_id' =>  $termId,
							'transaction_table_id' => PUBMED_MESH_TERMS,
							'transaction_name' => 'Add New MeshTerm',
							'parent_object_id' =>  $termId
					);
					$this->config->set_item('log_details', $arrLogDetails);
					log_user_activity ( null, true ); 
			}else{	
				//Add Log activity
				$arrLogDetails = array(
						'type' => ADD_RECORD,
						'description' => 'Add New MeshTerm record',
						'status' => STATUS_FAIL,
						'kols_or_org_type' => 'Kol',
						'transaction_id' =>  $termId,
						'transaction_table_id' => PUBMED_MESH_TERMS,
						'transaction_name' => 'Add New MeshTerm',
						'parent_object_id' =>  $termId
				);
				$this->config->set_item('log_details', $arrLogDetails);
				log_user_activity ( null, true );  
			    
			}	
		}
		return $termId;	
	}
	
	/**
	 * Saves the record to associate the MeshTerm to publication
	 * @param $pubTerm
	 * @return unknown_type
	 */
	function savePublicationMeshTerm($pubTerm){
		$this->db->where('pub_id',$pubTerm['pub_id']);
		$this->db->where('term_id',$pubTerm['term_id']);
		$this->db->where('is_major',$pubTerm['is_major']);
		$arrMeshTerms=$this->db->get('publication_mesh_terms');
		if($arrMeshTerms->num_rows()!=0){
			return true;		
		}else if($this->db->insert('publication_mesh_terms',$pubTerm)){
				return true;	      		
		}else{	      		
		    return false;
		}	
	}
	
	/**
	 * Saves the Substance record and returns the id of last inserted record
	 * @param $substance
	 * @return Integer
	 */
	function savePubmedSubstance($substance){
		$substanceId='';
		$this->db->where('name',$substance['name']);
		$arrSubstances=$this->db->get('pubmed_substances');
		if($arrSubstances->num_rows()!=0){
			$substanceObj=$arrSubstances->first_row();
			$substanceId=$substanceObj->id;		
		} else{
			if($this->db->insert('pubmed_substances',$substance)){
					$substanceId=$this->db->insert_id();
					//Add Log activity
					$arrLogDetails = array(
							'type' => ADD_RECORD,
							'description' => 'Add New Substance record',
							'status' => STATUS_SUCCESS,
							'kols_or_org_type' => 'Kol',
							'transaction_id' => $substanceId,
							'transaction_table_id' => PUBMED_SUBSTANCES,
							'transaction_name' => 'Add New Substance',
							'parent_object_id' => $substanceId
					);
					$this->config->set_item('log_details', $arrLogDetails);
					log_user_activity ( null, true );
			}else{	      		
				//Add Log activity
				$arrLogDetails = array(
						'type' => ADD_RECORD,
						'description' => 'Add New Substance record',
						'status' => STATUS_FAIL,
						'kols_or_org_type' => 'Kol',
						'transaction_id' =>  $substanceId,
						'transaction_table_id' => PUBMED_SUBSTANCES,
						'transaction_name' => 'Add New Substance',
						'parent_object_id' =>  $substanceId
				);
				$this->config->set_item('log_details', $arrLogDetails);
				log_user_activity ( null, true );
			}	
		}
		return $substanceId;	
	}
	
	/**
	 * Saves the record to associate the Substance to publication
	 * @param $pubSubstance
	 * @return unknown_type
	 */
	function savePublicationSubstance($pubSubstance){
		$this->db->where('pub_id',$pubSubstance['pub_id']);
		$this->db->where('substance_id',$pubSubstance['substance_id']);
		$arrSubstance=$this->db->get('publication_substances');
		if($arrSubstance->num_rows()!=0){
			return true;		
		}else if($this->db->insert('publication_substances',$pubSubstance)){
				return true;	      		
		}else{	      		
		    return false;
		}	
	}
	
	/**
	 * Saves the Publication type record and returns the id of last inserted record
	 * @param $type
	 * @return unknown_type
	 */
	function savePubmedPubType($type){
		$typeId='';
		$this->db->where('type',$type['type']);
		$arrPubTypes=$this->db->get('pubmed_publications_types');
		if($arrPubTypes->num_rows()!=0){
			$pubTypeObj=$arrPubTypes->first_row();
			$typeId=$pubTypeObj->id;		
		} else{
			if($this->db->insert('pubmed_publications_types',$type)){
					$typeId=$this->db->insert_id();	
					//Add Log activity
					$arrLogDetails = array(
							'type' => ADD_RECORD,
							'description' => 'Add New Publication type record',
							'status' => STATUS_SUCCESS,
							'kols_or_org_type' => 'Kol',
							'transaction_id' => $typeId,
							'transaction_table_id' => PUBMED_PUBLICATIONS_TYPES,
							'transaction_name' => 'Add New Publication type',
							'parent_object_id' => $typeId
					);
					$this->config->set_item('log_details', $arrLogDetails);
					log_user_activity ( null, true );
			}else{	      		
				//Add Log activity
				$arrLogDetails = array(
						'type' => ADD_RECORD,
						'description' => 'Add New Publication type record',
						'status' => STATUS_FAIL,
						'kols_or_org_type' => 'Kol',
						'transaction_id' =>  $typeId,
						'transaction_table_id' => PUBMED_PUBLICATIONS_TYPES,
						'transaction_name' => 'Add New Publication type',
						'parent_object_id' =>  $typeId
				);
				$this->config->set_item('log_details', $arrLogDetails);
				log_user_activity ( null, true );
			}	
		}
		return $typeId;
	}
	
	/**
	 * Saves the record to associate the Publication type to publication
	 * @param $pubType
	 * @return unknown_type
	 */
	function savePublicationType($pubType){
		$this->db->select('id');
		$this->db->where('pub_id',$pubType['pub_id']);
		$this->db->where('pub_type_id',$pubType['pub_type_id']);
		$resultSet	= $this->db->get('publications_types');
		if($resultSet->num_rows()!=0){
			return true;
		}else if($this->db->insert('publications_types',$pubType)){
				return true;	      		
		}else{	      		
		    return false;
		}	
	}
	
	
	/**
	 * Saves the CommentsCorrections record and returns the id of last inserted record
	 * @param $cc
	 * @return Integer 
	 */
	function savePubmedCC($cc){
		$ccId='';
		$this->db->select('id');
		$this->db->where('ref_type',$cc['ref_type']);
		$this->db->where('ref_source',$cc['ref_source']);
		$this->db->where('cc_pmid',$cc['cc_pmid']);
		$this->db->where('cc_pmid_version',$cc['cc_pmid_version']);
		$resultSet	= $this->db->get('pubmed_cc');
		if($resultSet->num_rows()!=0){
			$PubObj	= $resultSet->first_row();
			$ccId	= $PubObj->id;	
		}else if($this->db->insert('pubmed_cc', $cc)){
			$ccId = $this->db->insert_id();
		}else{
				
		}
		return $ccId;
	}

	/**
	 * Saves the record to associate the CommentsCorrections to publication
	 * @param $pubCc
	 * @return boolean
	 */
	function savePublicationCC($pubCc){
		$this->db->select('id');
		$this->db->where('pub_id',$pubCc['pub_id']);
		$this->db->where('cc_id',$pubCc['cc_id']);
		$resultSet	= $this->db->get('publications_cc');
		if($resultSet->num_rows()!=0){
			return true;
		}else if($this->db->insert('publications_cc',$pubCc)){
			return true;	      		
		}else{	      		
		    return false;
		}	
	}

	/**
	 * Saves the PublicationHistory record 
	 * @param Array $pubHistory
	 * @return boolean
	 */
	function savePublicationHistory($pubHistory){
		if($this->db->insert('publication_history',$pubHistory)){
				return true;	      		
		}else{	      		
		    return false;
		}	
	}
	
	/**
	 * Saves the PubmedArticleId record and returns the id of last inserted record
	 * @param Array $articleId
	 * @return Integer
	 */
	function savePubmedArticleId($articleId){
		$id='';
		$this->db->select('id');
		$this->db->where('type',$articleId['type']);
		$this->db->where('id_value',$articleId['id_value']);
		$resultSet	= $this->db->get('pubmed_article_ids');
		if($resultSet->num_rows()!=0){
			$PubObj	= $resultSet->first_row();
			$id		= $PubObj->id;	
		}else if($this->db->insert('pubmed_article_ids', $articleId)){
			$id = $this->db->insert_id();
		}else{
				
		}
		return $id;
	}

	/**
	 * Saves the record to associate the PubmedArticleId to publication
	 * @param $pubArticleId
	 * @return boolean
	 */
	function savePublicationArticleId($pubArticleId){
		$this->db->select('id');
		$this->db->where('pub_id',$pubArticleId['pub_id']);
		$this->db->where('pub_article_id',$pubArticleId['pub_article_id']);
		$resultSet	= $this->db->get('publication_article_ids');
		if($resultSet->num_rows()!=0){
			return true;
		}else if($this->db->insert('publication_article_ids',$pubArticleId)){
			return true;	      		
		}else{	      		
			return false;
		}	
	}
	
	/**
	 * Updates kol as pubmed processed by setting 'is_pubmed_processed' to 1
	 * @param  $arrKolDetail
	 * @return unknown_type
	 */
	function updatePubmedProcessedKol($arrKolDetail){
		$kolDetail['is_pubmed_processed']=	$arrKolDetail['is_pubmed_processed'];
		$this->db->where('id', $arrKolDetail['id']);		
		$this->db->update('kols', $kolDetail);		
	}
	
	/**
	 * returns the list of publications belongs to perticular kolId passed
	 * @param $kolId
	 * @return unknown_type
	 */
	function listPublicationDetails($kolId,$listType){
		$arrPublications=array();
		$clientId = $this->session->userdata('client_id');
		
		$this->db->select('publications.*,kol_publications.auth_pos,kol_publications.id as asoc_id');
		$this->db->from('publications');
		$this->db->join('kol_publications', 'kol_publications.pub_id = publications.id','left');
		$this->db->where('kol_id', $kolId);
		$this->db->where('kol_publications.is_deleted', 0);
		$this->db->where('kol_publications.is_verified',1);
		if($listType!='export'){
    		if($clientId!=INTERNAL_CLIENT_ID){
    // 			$this->db->where("(kol_publications.client_id=$clientId or kol_publications.client_id=".INTERNAL_CLIENT_ID.")");
    		    $this->db->where("kol_publications.client_id",$clientId);
    		}
		}
		$arrPublicationResult = $this->db->get();
		foreach($arrPublicationResult->result_array() as $row){
			if($arrPublicationResult->num_rows()!=0){
				$arrPublications[]=$row;
			}else{
				return false;
			}
		}	
		return 	$arrPublications;
	}
	
	/**
	 * returns the list of publications belongs to perticular kolId passed
	 * @param $kolId
	 * @return unknown_type
	 */
	function listPublicationDetailsForAnalyst($kolId,$type){
		$arrPublications=array();
		$this->db->select('publications.*,kol_publications.auth_pos,kol_publications.id as asoc_id');
		$this->db->from('publications');
		$this->db->join('kol_publications', 'kol_publications.pub_id = publications.id','left');
		$this->db->where('kol_id', $kolId);
		if($type=='unVerified'){
			$this->db->where('kol_publications.is_deleted', 0);
			$this->db->where('kol_publications.is_verified', 0);
		}else if($type=='verified'){
			$this->db->where('kol_publications.is_deleted', 0);
			$this->db->where('kol_publications.is_verified', 1);
		}else{
			$this->db->where('kol_publications.is_verified', 0);
			$this->db->where('kol_publications.is_deleted', 1);
		}
		$this->db->distinct();
		$arrPublicationResult = $this->db->get();
		foreach($arrPublicationResult->result_array() as $row){
			if($arrPublicationResult->num_rows()!=0){
				$arrPublications[]=$row;
			}else{
				return false;
			}
		}
		return 	$arrPublications;
	}
	

	function getJournalNameById($journalId){
		$journalName='';
		
		$this->db->where('id',$journalId);
		$arrJournals=$this->db->get('pubmed_journals');
		if($arrJournals->num_rows()!=0){
			$journalObj=$arrJournals->first_row();
			$journalName=$journalObj->name;		
		}
		else {
			
		}
		return $journalName;
	}
	
	/**
	 * Sets publication as deleted by setting the 'is_deleted' to 1
	 * @param $kolPublication
	 * @return unknown_type
	 */
	function updatePublicationAsDeleted($id){
		$kolPublication['is_deleted']=1;
		$kolPublication['is_verified']=0;
		$this->db->select('kol_id');
		$this->db->where('id',$id);
		$queryRes = $this->db->get('kol_publications');
		$row = $queryRes->row();
		if (isset($row))
		{
			if($row->kol_id > 0){
				$transactionName = 'Sets publication as deleted by setting the is_deleted to 1';
				$kol_org_type = 'Kol';
				$kols_or_org_id = $row->kol_id;
				$parentObjectId = $row->kol_id;
			}
		}
		$this->db->where('id', $id);
		//$this->db->where('pub_id', $id);
		//$this->db->where('kol_id', $kol_id);
		if($this->db->update('kol_publications', $kolPublication)){
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
					'description' => $transactionName,
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => $kol_org_type,
					'kols_or_org_id' => $kols_or_org_id,
					'transaction_id' =>  $id,
					'transaction_table_id' => KOL_PUBLICATIONS,
					'transaction_name' =>$transactionName,
					'parent_object_id' =>  $parentObjectId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return true;
		} else {
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
					'description' => $transactionName,
					'status' => STATUS_FAIL,
					'kols_or_org_type' => $kol_org_type,
					'kols_or_org_id' => $kols_or_org_id,
					'transaction_id' =>  $id,
					'transaction_table_id' => KOL_PUBLICATIONS,
					'transaction_name' => $transactionName,
					'parent_object_id' =>  $parentObjectId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return false;
		}
	}
	
	/**
	 * Deletes the Association between Kol and Publication
	 * @param $pubId
	 * @return unknown_type
	 */
	function deletePublication($pubId){
		$this->db->where('pub_id', $pubId);
		if($this->db->delete('kol_publications')){
			return true;
		}else{
			return false;
		} 
	}
	
	function listPublicationAuthors($pubId){
		$arrAuthors=array();
		$this->db->select('pubmed_authors.*,publications_authors.position');
		$this->db->from('pubmed_authors');
		$this->db->join('publications_authors', 'publications_authors.author_id = pubmed_authors.id','left');
		$this->db->where('pub_id', $pubId);	
		$where="!((last_name='Not Available' ) and (initials='Not Available'))";
		$this->db->where($where);	
		$this->db->order_by("publications_authors.position","ASC");
		$arrAuthorsResult = $this->db->get();
		foreach($arrAuthorsResult->result_array() as $row){
				$arrAuthors[]=$row;
		}
		//echo $this->db->last_query();
		return 	$arrAuthors;
	}
	
	function listPublicationMeshTerms($pubId){
		$arrMeshTerms=array();
		$this->db->select('pubmed_mesh_terms.*,publication_mesh_terms.is_major');
		$this->db->from('pubmed_mesh_terms');
		$this->db->join('publication_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
		$this->db->where('pub_id', $pubId);		
		$arrMeshTermsResult = $this->db->get();
		foreach($arrMeshTermsResult->result_array() as $row){
				$arrMeshTerms[]=$row;
		}	
		return 	$arrMeshTerms;
	}
	
	function getMeshTermName($termId){
		$termName='';
		$this->db->where('id',$termId);
		$arrMeshTerms=$this->db->get('pubmed_mesh_terms');
		if($arrMeshTerms->num_rows()!=0){
			$meshTermObj=$arrMeshTerms->first_row();
			$termName=$meshTermObj->term_name;		
		} else {
		
		}
		return $termName;
	}
	
	function listPublicationSubstances($pubId){
		$arrSubstances=array();
		$this->db->select('pubmed_substances.*');
		$this->db->from('pubmed_substances');
		$this->db->join('publication_substances', 'publication_substances.substance_id = pubmed_substances.id','left');
		$this->db->where('pub_id', $pubId);		
		$arrSubstancesResult = $this->db->get();
		foreach($arrSubstancesResult->result_array() as $row){
				$arrSubstances[]=$row;
		}	
		return 	$arrSubstances;
	}
	
	function listPublicationPubTypes($pubId){
		$arrPubTypes=array();
		$this->db->select('pubmed_publications_types.*');
		$this->db->from('pubmed_publications_types');
		$this->db->join('publications_types', 'publications_types.pub_type_id = pubmed_publications_types.id','left');
		$this->db->where('pub_id', $pubId);		
		$arrPubTypesResult = $this->db->get();
		foreach($arrPubTypesResult->result_array() as $row){
				$arrPubTypes[]=$row;
		}	
		return 	$arrPubTypes;
	}
	
	function checkKolPubAssociationExist($kolPublication){
		$this->db->select('id');
		$this->db->where('kol_id',$kolPublication['kol_id']);
		$this->db->where('pub_id',$kolPublication['pub_id']);
		$arrPublicationAssoc=$this->db->get('kol_publications');
		if($arrPublicationAssoc->num_rows()!=0){
			return true;
		} else {
			return false;
		}
	}
	
	function getPublicationDetail($pubId){
		$publication=array();
		$this->db->where('id',$pubId);
		$publication=$this->db->get('publications');
		$publication=$publication->row_array();
		return 	$publication;	
	}
	
	function getKolDetail($kolId){
		$kolDetail=array();
		$this->db->where('id',$kolId);
		$kolDetail=$this->db->get('kols');
		$kolDetail=$kolDetail->row_array();
		return 	$kolDetail;
	}
	
	function getAuthorshipPos($pubId,$firstName,$lastName){
		$pos='';		
		$this->db->select('publications_authors.position');
		$this->db->from('pubmed_authors');
		$this->db->join('publications_authors', 'publications_authors.author_id = pubmed_authors.id','left');
		$this->db->where('pub_id', $pubId);	
		$this->db->where('last_name', $firstName);
		$where="(fore_name=\"".$lastName."\" OR initials=\"".$lastName."\")";	
		$this->db->where($where);		
		$arrAuthorsResult = $this->db->get();
// 		pr($this->db->last_query());
		if($arrAuthorsResult && $arrAuthorsResult->num_rows()!=0){
			$arrAuthor=$arrAuthorsResult->row_array();
			$pos=$arrAuthor['position'];
		} else {
			
		}		
		return 	$pos;
		
	}
	
	/**
	 * Get the Basic search details for the specified Article Name with Like option
	 * 
	 * @param unknown_type $keyword
	 * @return unknown_type
	 */
	function getMatchingPublications($keyword,$limit,$startFrom,$doCount){
		$arrPublications = array();
			if(!$doCount)
				$this->db->select(array('publications.id','publications.article_title','pubmed_journals.name as journal_name','publications.created_date'));
			$this->db->like('article_title',$keyword);
			$this->db->join('pubmed_journals', 'publications.journal_id=pubmed_journals.id','left');
			
			$this->db->order_by('article_title');
			//$this->db->group_by('article_title');
			if($doCount){
				/*TODO
				 *  modify this count logic
				 */
				$this->db->select('count(*) as count');
				$arrPublicationDetailsResult=$this->db->get('publications');
				$arrPublications[]=$arrPublicationDetailsResult->row();
				return 	$arrPublications[0]->count;
				/* Old logic
				$arrPublicationDetailsResult=$this->db->get('publications');
				foreach($arrPublicationDetailsResult->result_array() as $row){
					$arrPublications[]=$row;
				}	
				return sizeof($arrPublications);
				*/
			}
			else{
				$this->db->limit($limit, $startFrom);
				$arrPublicationDetailsResult=$this->db->get('publications');
				foreach($arrPublicationDetailsResult->result_array() as $row){
					$arrPublications[]=$row;
				}	
				return $arrPublications;
			}
		return $arrPublications;
	}
	
	/**
	 * Get the Advance search details with Like option for all fileds if its not empty
	 * @author 	Ambarish N
	 * @since	2.4
	 * @created June-07-2011
	 * @param $arrAdvSearchFields
	 * @return unknown_type
	 */
	function getAdvSearchMatchingPublications($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,$doCount,$doGroupBy=false,$groupByCategory=null){
		$arrPublications = array();
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		$this->db->join('publications','publications.id=kol_publications.pub_id','left');
		$this->db->join('pubmed_journals', 'publications.journal_id=pubmed_journals.id','left');
		if($arrAdvSearchFields['article_title'] !=''){
			$this->db->like('publications.article_title',$arrAdvSearchFields['article_title']);
		}
		if($arrAdvSearchFields['pubKeywords'] !=''){
			$pubKeywords=$arrAdvSearchFields['pubKeywords'];
			$whereWords="(`publications`.`article_title` LIKE '%".$pubKeywords."%' OR `pubmed_journals`.`name` 
							LIKE '%".$pubKeywords."%' OR `publications`.`abstract_text` LIKE '%".$pubKeywords."%' OR `pubmed_authors`.`last_name` 
							LIKE '%".$pubKeywords."%' OR `pubmed_authors`.`fore_name` LIKE '%".$pubKeywords."%' OR `pubmed_mesh_terms`.`term_name` 
							LIKE '%".$pubKeywords."%' OR `pubmed_substances`.`name` LIKE '%".$pubKeywords."%')";
			$this->db->where($whereWords);
		}
		
		if($arrAdvSearchFields['journals'] !=''){
			$this->db->like('pubmed_journals.name', $arrAdvSearchFields['journals']);
		}
		
		if($arrAdvSearchFields['affiliations'] !=''){
			$this->db->like('publications.affiliation', $arrAdvSearchFields['affiliations']);
		}
		
		if($arrAdvSearchFields['authors'] !='' || $arrAdvSearchFields['pubKeywords'] !=''){
			$this->db->join('publications_authors', 'publications_authors.pub_id = publications.id','left');
			$this->db->join('pubmed_authors', 'publications_authors.author_id = pubmed_authors.id','left');
			
			if($arrAdvSearchFields['authors'] !=''){
				$this->db->like('pubmed_authors.last_name',$arrAdvSearchFields['authors']);
				$this->db->or_like('pubmed_authors.fore_name',$arrAdvSearchFields['authors']);
			}
		}
		
		if($arrAdvSearchFields['mesh_term'] !='' || $arrAdvSearchFields['pubKeywords'] !='' || $groupByCategory=='meshterm' || $arrFilterFields['meshterm']!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			
			if($arrAdvSearchFields['mesh_term'] !=''){
				$this->db->like('pubmed_mesh_terms.term_name',$arrAdvSearchFields['mesh_term']);
			}
		}
		
		if($arrAdvSearchFields['substances'] !='' || $arrAdvSearchFields['pubKeywords'] !='' || $groupByCategory=='substance' || $arrFilterFields['substance']!=''){
			$this->db->join('publication_substances', 'publication_substances.pub_id = publications.id','left');
			$this->db->join('pubmed_substances', 'publication_substances.substance_id = pubmed_substances.id','left');
			
			if($arrAdvSearchFields['substances'] !=''){
				$this->db->like('pubmed_substances.name',$arrAdvSearchFields['substances']);
			}
		}
		
		//Filter fields
		if($arrFilterFields!=null && $arrFilterFields['journal']!='' && isset($arrFilterFields['journal']) && sizeof($arrFilterFields['journal'])>0 && !($doGroupBy==true && $groupByCategory=='journal'))
			$this->db->where_in('pubmed_journals.name', $arrFilterFields['journal']);
		if($arrFilterFields!=null && $arrFilterFields['affiliation']!='' && isset($arrFilterFields['affiliation']) && sizeof($arrFilterFields['affiliation'])>0 && !($doGroupBy==true && $groupByCategory=='affiliation'))
			$this->db->like('publications.affiliation', $arrFilterFields['affiliation']);
		if($arrFilterFields!=null && $arrFilterFields['meshterm']!='' && isset($arrFilterFields['meshterm']) && sizeof($arrFilterFields['meshterm'])>0 && !($doGroupBy==true && $groupByCategory=='meshterm'))
			$this->db->where_in('pubmed_mesh_terms.term_name', $arrFilterFields['meshterm']);
		if($arrFilterFields!=null && $arrFilterFields['substance']!='' && isset($arrFilterFields['substance']) && sizeof($arrFilterFields['substance'])>0 && !($doGroupBy==true && $groupByCategory=='substance'))
			$this->db->where_in('pubmed_substances.name', $arrFilterFields['substance']);
			
		if(!$doCount)	
			$this->db->select(array('publications.id','publications.article_title','pubmed_journals.name as journal_name','publications.created_date'));
		
		if(!$doGroupBy)
			$this->db->group_by('publications.pmid');
		//	$this->db->distinct();
		//$this->db->order_by('article_title');
		//$this->db->group_by('publications.pmid');
		
		
		if($doCount){
		//	$this->db->select('count(DISTINCT publications.pmid) as count');
			$arrPublicationDetailsResult=$this->db->get('kol_publications');
			foreach($arrPublicationDetailsResult->result_array() as $row){
					$arrPublications[]=$row;
				}	
				return sizeof($arrPublications);
				
		//	$arrPublications[]=$arrPublicationDetailsResult->row();;
		//	return 	$arrPublications[0]->count;		
			
			/*
			$arrPublicationDetailsResult=$this->db->get('publications');
			foreach($arrPublicationDetailsResult->result_array() as $row){
				$arrPublications[]=$row;
			}	
			return sizeof($arrPublications);
			*/
		}
		else{
			if($doGroupBy){
				if($groupByCategory=='journal'){
					$this->db->select('COUNT(DISTINCT publications.pmid) as count');
					$this->db->group_by('pubmed_journals.name');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='affiliation'){
					$this->db->select('COUNT(DISTINCT publications.pmid) as count,publications.affiliation');
					$this->db->group_by('publications.affiliation');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='meshterm'){
					$this->db->select('COUNT(DISTINCT publications.pmid) as count,pubmed_mesh_terms.term_name as meshterm');
					$this->db->group_by('pubmed_mesh_terms.term_name');
					//$this->db->where('country IS NOT NULL');
				}
				if($groupByCategory=='substance'){
					$this->db->select('COUNT(DISTINCT publications.pmid) as count,pubmed_substances.name as substance');
					$this->db->group_by('pubmed_substances.name');
					//$this->db->where('country IS NOT NULL');
				}
				$this->db->order_by('count','desc');
			}else
				$this->db->limit($limit, $startFrom);

			$arrPublicationDetailsResult=$this->db->get('kol_publications');
			foreach($arrPublicationDetailsResult->result_array() as $row){
				$arrPublications[]=$row;
			}	
			return $arrPublications;
		}
	}
	
	/**
	 * Get the Basic Filter details. Using Like option with Anding for all fileds if its not empty
	 * 
	 * @param $arrAdvSearchFields
	 * @return unknown_type
	 */
	function getFilterSearchMatchingPublications($arrAdvSearchFields,$limit,$startFrom,$doCount){
		$arrPublications = array();
		if($arrAdvSearchFields['keyword'] !=''){
			$this->db->like('publications.article_title',$arrAdvSearchFields['keyword']);
		}
		
		if($arrAdvSearchFields['journals'] !=''){
			$this->db->like('pubmed_journals.name', $arrAdvSearchFields['journals']);
		}
		
		if($arrAdvSearchFields['affiliations'] !=''){
			$this->db->like('publications.affiliation', $arrAdvSearchFields['affiliations']);
		}
		
		if($arrAdvSearchFields['mesh_term'] !=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			
			$this->db->like('pubmed_mesh_terms.term_name',$arrAdvSearchFields['mesh_term']);
		}
		
		if($arrAdvSearchFields['substances'] !=''){
			$this->db->join('publication_substances', 'publication_substances.pub_id = publications.id','left');
			$this->db->join('pubmed_substances', 'publication_substances.substance_id = pubmed_substances.id','left');
			
			$this->db->like('pubmed_substances.name',$arrAdvSearchFields['substances']);
		}
		
		if(!$doCount)
			$this->db->select(array('publications.id','publications.article_title','pubmed_journals.name as journal_name','publications.created_date'));
		$this->db->join('pubmed_journals', 'publications.journal_id=pubmed_journals.id','left');
		$this->db->order_by('article_title');
		//$this->db->group_by('article_title');
		
		if($doCount){
			$this->db->select('count(*) as count');
			$arrPublicationDetailsResult=$this->db->get('publications');
			$arrPublications[]=$arrPublicationDetailsResult->row();
			return 	$arrPublications[0]->count;			
			/* Old logic
			$arrPublicationDetailsResult=$this->db->get('publications');
			foreach($arrPublicationDetailsResult->result_array() as $row){
				$arrPublications[]=$row;
			}	
			return sizeof($arrPublications);
			*/
		}
		else{
			$this->db->limit($limit, $startFrom);
			$arrPublicationDetailsResult=$this->db->get('publications');
			foreach($arrPublicationDetailsResult->result_array() as $row){
				$arrPublications[]=$row;
			}	
			return $arrPublications;
		}
	}
	
	function getPubMeshTermsName($meshTermName){
		$arrMeshTerms=array();
		$this->db->select('term_name');
		$this->db->from('pubmed_mesh_terms');
		$this->db->like('term_name', $meshTermName);
		$arrMeshTermsResult = $this->db->get();
		foreach($arrMeshTermsResult->result_array() as $row){
				$arrMeshTerms[]=$row['term_name'];
		}	
		return 	$arrMeshTerms;
	}
	
	function getPubJournalsName($journalName){
		$arrJournals=array();
		$this->db->select('name');
		$this->db->from('pubmed_journals');
		$this->db->like('name', $journalName);
		$arrJournalsResult = $this->db->get();
		foreach($arrJournalsResult->result_array() as $row){
				$arrJournals[]=$row['name'];
		}	
		return 	$arrJournals;
	}
	
	function getPubAffiliationsName($affiliationName){
		$arrJournals=array();
		$this->db->select('affiliation');
		$this->db->from('publications');
		$this->db->like('affiliation', $affiliationName);
		$arrAffiliationsResult = $this->db->get();
		foreach($arrAffiliationsResult->result_array() as $row){
				$arrJournals[]=$row['affiliation'];
		}	
		return 	$arrJournals;
	}
	
	function getPubSubstancesName($substancesName){
		$arrSubstances=array();
		$this->db->select('name');
		$this->db->from('pubmed_substances');
		$this->db->like('name', $substancesName);
		$arrSubstancesResult = $this->db->get();
		foreach($arrSubstancesResult->result_array() as $row){
				$arrSubstances[]=$row['name'];
		}	
		return 	$arrSubstances;
	}
	
	/**
	 * Conts the publication of top 10 kols
	 */
	function countPublicationsOfKols(){
		
/*		$arrPublicationsDetail=array();
		$arrPublications=$this->db->query("SELECT kol_id,COUNT(pub_id) as count
										 FROM kol_publications
										 WHERE is_deleted=0 
											 GROUP BY(kol_id)
											 ORDER BY count desc limit 10");

		foreach($arrPublications->result_array() as $row){
			
			$arrPublicationsDetail[]=$row;
		}
		return $arrPublicationsDetail;
*/	
		$arrPublicationsDetail=array();
		$arrPublications	=	$this->db->query("SELECT kol_id, CONCAT(kols.first_name, ' ', kols.middle_name , ' ' , kols.last_name) AS kol_name, COUNT(kol_publications.id) as cnt FROM kol_publications, kols 
	WHERE 	kol_publications.kol_id = kols.id AND 
		kol_publications.is_deleted = 0 
		AND kol_publications.is_verified=1 
	GROUP BY kol_id order by COUNT(kol_publications.id) DESC LIMIT 10");
		
		foreach($arrPublications->result_array() as $row){
			
			$arrPublicationsDetail[]=$row;
		}
		//pr($arrPublicationsDetail);
		return $arrPublicationsDetail;
	
	} 


	/**
	 * returns the list of Top publications belongs to perticular kolId passed with Limit
	 * @param $kolId
	 * @return unknown_type
	 */
	function listPublicationDetailsByLimit($kolId,$limitValue){
		$clientId = $this->session->userdata('client_id');
		$arrPublications=array();
		$this->db->select('publications.*');
		$this->db->from('publications');
		$this->db->join('kol_publications', 'kol_publications.pub_id = publications.id','left');
		$this->db->where('kol_id', $kolId);
		$this->db->where('kol_publications.is_deleted', 0);
		$this->db->where('kol_publications.is_verified',1);
		
		if($clientId!=INTERNAL_CLIENT_ID){
			 $this->db->where("(kol_publications.client_id=$clientId or kol_publications.client_id=".INTERNAL_CLIENT_ID.")");
		}
		$this->db->order_by('publications.created_date','desc');
		$this->db->limit($limitValue);
		
		$arrPublicationResult = $this->db->get();
		foreach($arrPublicationResult->result_array() as $row){
			if($arrPublicationResult->num_rows()!=0){
				$arrPublications[]=$row;
			}else{
				return false;
			}
		}	
		return 	$arrPublications;
	}

	/**
	 * returns the list of publications belongs to perticular kolId passed
	 * @param $kolId
	 * @return unknown_type
	 * @author Vinayak
	 * @since 1.4.4
	 * kp -Kol_publications id
	 */
	function listPublicationsByYearRange($kolId,$fromYear,$toYear){
		$clientId = $this->session->userdata('client_id');
		$arrPublications=array();
	
		$this->db->select('publications.*,kol_publications.id as kp_id,kol_publications.auth_pos,kol_publications.client_id,kol_publications.user_id,pubmed_journals.name as journal_name');
		$this->db->join('kol_publications','kol_publications.pub_id = publications.id','inner');
		$this->db->join('pubmed_journals ','pubmed_journals.id = publications.journal_id','inner');
		$this->db->where('kol_publications.kol_id',$kolId);
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		$this->db->where('(YEAR(publications.created_date) BETWEEN '.$fromYear.'  and  '.$toYear.' OR YEAR(publications.created_date)="0")');
		//$this->db->where("(year(created_date) >= '$fromYear' AND year(created_date) <='$toYear')");
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("(kol_publications.client_id=$clientId or kol_publications.client_id=".INTERNAL_CLIENT_ID.")");
		}
		$this->db->order_by('created_date','desc');
		$arrPublicationResult = $this->db->get('publications');
		//echo $this->db->last_query();
		foreach($arrPublicationResult->result_array() as $row){
			if($arrPublicationResult->num_rows()!=0){
				$arrPublications[]=$row;
			}else{
				return false;
			}
		}	
		return 	$arrPublications;
	}	
	
	/**
	 * returns the list of publications belongs to perticular year for the passed kol_id,
	 * @return unknown_type
	 * @author Ambarish
	 * @since 1.4.4
	 * @Created-on 22/02/2011
	 * 
	 */
	function getYearPublications($kol_id, $year,$filters = null, $viewType){
		$arrPublicationsDetail=array();
		/*$arrPublications=$this->db->query("SELECT year(created_date) as year,publications.id,publications.pmid,pubmed_journals.name as journal_name,publications.article_title,publications.created_date, count(distinct kol_publications.pub_id) as count,kol_publications.auth_pos,publications.link
											FROM (`publications`)
											LEFT JOIN `kol_publications` ON `kol_publications`.`pub_id` = `publications`.`id`
											LEFT JOIN `pubmed_journals` ON `pubmed_journals`.`id` = `publications`.`journal_id`
											WHERE `kol_id` = '$kol_id'
											AND `kol_publications`.`is_deleted` = 0
											AND kol_publications.is_verified=1 
											AND year(publications.created_date)=$year
											GROUP BY `kol_publications`.`pub_id`
											ORDER BY year(created_date) desc");*/
		$this->db->select("year(created_date) as year,publications.id,publications.pmid,pubmed_journals.name as journal_name,publications.article_title,publications.created_date, count(distinct kol_publications.pub_id) as count,kol_publications.auth_pos,publications.link,count(publications_authors.id) as authcount");
		$this->db->join('kol_publications','kol_publications.pub_id = publications.id','left');
		$this->db->join('pubmed_journals','pubmed_journals.id = publications.journal_id','left');
		$this->db->join('kols', 'kol_publications.kol_id = kols.id','left');
		$this->db->join('publications_authors', 'publications_authors.pub_id = publications.id','left');
		if($kol_id != 0)
			$this->db->where('kol_publications.kol_id',$kol_id);
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		$this->db->where('year(publications.created_date)',$year);
		//$this->db->where('kols.status',COMPLETED);
		$this->db->order_by('created_date','desc');
		if(count($viewType)>0 && !empty($viewType))
			$this->db->where_in('kols.id',$viewType);
		//Refine by filters		
		if($filters != null){
			if(isset($filters['global_region'])){
				$globalRegion = $filters['global_region'];
				foreach($globalRegion as $arrGlobalRegionIds){
					 $str = str_replace("_","/",$arrGlobalRegionIds);
        			$globalRegionSorted[] = str_replace("%20"," ",$str);
				}
				$this->db->join('countries', 'countries.CountryId = kols.country_id','left');
				$isKolsJoined = true;
				$this->db->where_in('countries.GlobalRegion', $globalRegionSorted);
			}
			if(isset($filters['specialty'])){
				$this->db->join('specialties', 'specialties.id = kols.specialty','left');
				$this->db->where_in('specialties.id',$filters['specialty']);
			}
			if(isset($filters['country'])){
				if($isKolsJoined == false)
					$this->db->join('countries', 'countries.CountryId = kols.country_id','left');
				
				$this->db->where_in('countries.CountryId',$filters['country']);
			}
			if(isset($filters['state'])){
				$this->db->join('regions', 'regions.RegionID = kols.state_id','left');
				$this->db->where_in('regions.RegionID',$filters['state']);
			}
			if(isset($filters['kol_id'])){
				$this->db->where_in('kol_publications.kol_id',$filters['kol_id']);
			}
			if (isset($filters['profileType'][0])){
			    if(str_replace("%20"," ",$filters['profileType'][0]) == DISCOVERY){
			        $this->db->where('(kols.imported_as = 2 or kols.imported_as = 3)', null, false);
			    }else{
			        $this->db->where('kols.profile_type', str_replace("%20"," ",$filters['profileType'][0]));
			        $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
			    }
			    //             $this->db->where('kols.profile_type', $arrProfileType);
			}else{
			    if($kol_id == 0)
			    $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
			}
			if(isset($filters['listName'])){
				$userId   =$this->session->userdata('user_id');
		 		$clientId =$this->session->userdata('client_id');
		 		$this->db->join('list_kols','list_kols.kol_id=kol_publications.kol_id','left');
		 		$this->db->join('list_names','list_kols.list_name_id=list_names.id','left');
		 		$this->db->join('list_categories','list_names.category_id=list_categories.id','left');
		 		$this->db->where_in('list_names.id',$filters['listName']);
		 		$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
			}
		}
		$keyword = $filters['keyword'];
		
		if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		$this->db->group_by('kol_publications.pub_id');
		$this->db->order_by('year(created_date) desc');
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$arrPublications = $this->db->get('publications');
		//pr($this->db->last_query());exit;
		foreach($arrPublications->result_array() as $row){
		    if(isset($row['pmid']) && $row['pmid'] > 0){
		        $row['linkForArticle'] = 'pmid';
		    }else{
		        $row['linkForArticle'] = 'link';
		    }
			$arrPublicationsDetail[]=$row;
		}
		return $arrPublicationsDetail;
	}
	function getAuthBypubId($pubId){
	    $this->db->select('publications_authors.*,kol_publications.kol_id, pubmed_authors.fore_name, pubmed_authors.last_name,publications.pmid,publications.article_title');
	    $this->db->join('publications','publications.id=publications_authors.pub_id','left');
	    $this->db->join('kol_publications','kol_publications.pub_id=publications_authors.pub_id and kol_publications.auth_pos=publications_authors.position','left');
	    $this->db->join('kols', 'kol_publications.kol_id = kols.id','left');
	    $this->db->join('pubmed_authors','pubmed_authors.id=publications_authors.author_id','left');
	    $client_id = $this->session->userdata('client_id');
	    if($client_id !== INTERNAL_CLIENT_ID){
	        $this->db->select("kols_client_visibility.client_id");
	        $this->db->join("kols_client_visibility", "kols_client_visibility.kol_id = kols.id and kols_client_visibility.client_id = $client_id", 'left');
	    }
	    $this->db->where('publications_authors.pub_id',$pubId);
	    $this->db->order_by('kol_publications.kol_id','desc');
	    $get = $this->db->get('publications_authors');
	   /*$get = $this->db->query("SELECT publications_authors.*,kol_publications.kol_id, pubmed_authors.fore_name, pubmed_authors.last_name,publications.article_title FROM publications_authors
	    left join kol_publications on (kol_publications.pub_id=publications_authors.pub_id and kol_publications.auth_pos=publications_authors.position)
        left join publications on (publications.id=kol_publications.pub_id)    	           
	    left join pubmed_authors on (pubmed_authors.id=publications_authors.author_id)       
	    WHERE publications_authors.pub_id = $pubId order by kol_publications.kol_id desc");*/
	    return $get->result_array();
	}

	/**
	 * Counts the number of Minor Meshterm for one kol
	 * 
	 * @author Ambarish
	 * @since 1.4.4
	 * @Created-on 22/02/2011
	 * 
	 * @param unknown_type $kolId
	 * @param unknown_type $fromYear
	 * @param unknown_type $toYear
	 * @return unknown_type
	 */
	function getPubMinorMeshTermChart($kolId, $fromYear, $toYear){
		$arrMinorMeshterm=array();
		$this->db->select('pubmed_mesh_terms.id,pubmed_mesh_terms.term_name as mesh_term,count(distinct kol_publications.pub_id) as count');
		$this->db->join('publication_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
		$this->db->join('publications', 'publications.id = publication_mesh_terms.pub_id','left');
		$this->db->join('kol_publications', 'kol_publications.pub_id = publications.id','left');
		
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		if($kolId != 0)
			$this->db->where('kol_id',$kolId);
		$this->db->where('publication_mesh_terms.is_major','0');
		$this->db->where('year(publications.created_date) between ' .$fromYear. ' and ' .$toYear);
		$this->db->group_by('pubmed_mesh_terms.term_name');
		$this->db->order_by('count','desc');
		$this->db->limit('20');
		
		$arrMinorMeshtermResult	=	$this->db->get('pubmed_mesh_terms');
		foreach($arrMinorMeshtermResult->result_array() as $row){
			$arrMinorMeshterm[]=$row;
		}	
		//pr($arrMinorMeshterm);	
     	return $arrMinorMeshterm;
	}
	
	/**
	 * returns the list of publications belongs to perticular $meshterm for the passed kol_id,
	 * @return unknown_type
	 * @author Ambarish
	 * @since 1.4.4
	 * @Created-on 23/02/2011
	 * 
	 * @param unknown_type $meshterm
	 * @param unknown_type $kolId
	 * @param unknown_type $fromYear
	 * @param unknown_type $toYear
	 * @return unknown_type
	 */
	function getMinorMeshtermPublications($meshterm, $kol_id, $fromYear, $toYear){
		$arrPublicationsDetail=array();
		$arrPublications=$this->db->query("SELECT publications.id,publications.pmid,`pubmed_mesh_terms`.`term_name` as mesh_term,pubmed_journals.name as journal_name,publications.article_title,publications.created_date, count(distinct kol_publications.pub_id) as count,kol_publications.auth_pos,publications.link
											FROM (`pubmed_mesh_terms`)
											LEFT JOIN `publication_mesh_terms` ON `publication_mesh_terms`.`term_id` = `pubmed_mesh_terms`.`id`
											LEFT JOIN `publications` ON `publications`.`id` = `publication_mesh_terms`.`pub_id`
											LEFT JOIN `kol_publications` ON `kol_publications`.`pub_id` = `publications`.`id`
											LEFT JOIN `pubmed_journals` ON `pubmed_journals`.`id` = `publications`.`journal_id`
											WHERE `kol_publications`.`is_deleted` = 0
											AND kol_publications.is_verified=1 											
											AND `kol_id` = '$kol_id'
											AND `publication_mesh_terms`.`is_major` = '0'
											AND year(publications.created_date) between $fromYear and $toYear
											AND `pubmed_mesh_terms`.`id` = '$meshterm'
											GROUP BY `kol_publications`.`pub_id`
											ORDER BY `count` desc");

		foreach($arrPublications->result_array() as $row){
		    if(isset($row['pmid']) && $row['pmid'] > 0){
		        $row['linkForArticle'] = 'pmid';
		    }else{
		        $row['linkForArticle'] = 'link';
		    }
			$arrPublicationsDetail[]=$row;
		}
		return $arrPublicationsDetail;
	}
	
	/**
	 * Counts the number of Substances for one kol
	 * 
	 * @author Ambarish
	 * @since 1.4.4
	 * @Created-on 22/02/2011
	 * 
	 * @param unknown_type $kolId
	 * @param unknown_type $fromYear
	 * @param unknown_type $toYear
	 * @return unknown_type
	 */
	function getPubSubstancesChart($kolId, $fromYear, $toYear,$keyword){
		$arrSubstances=array();
		$this->db->select('pubmed_substances.id,pubmed_substances.name ,count(distinct kol_publications.pub_id) as count');
		$this->db->join('publication_substances', 'publication_substances.substance_id = pubmed_substances.id','left');
		$this->db->join('publications', 'publications.id = publication_substances.pub_id','left');
		$this->db->join('kol_publications', 'kol_publications.pub_id = publications.id','left');
	
		if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		$this->db->where('kol_id',$kolId);
		$this->db->where('year(publications.created_date) between ' .$fromYear. ' and ' .$toYear);
		$this->db->group_by('pubmed_substances.name');
		$this->db->order_by('count','desc');
		$this->db->limit('20');
		
		$arrSubstancesResult	=	$this->db->get('pubmed_substances');
		foreach($arrSubstancesResult->result_array() as $row){
			$arrSubstances[]=$row;
		}	
		//pr($arrSubstances);	
     	return $arrSubstances;
	}
	
	/**
	 * returns the list of publications belongs to perticular Substance for the passed kol_id,
	 * @return unknown_type
	 * @author Ambarish
	 * @since 1.4.4
	 * @Created-on 23/02/2011
	 * 
	 * @param unknown_type $substanceName
	 * @param unknown_type $kolId
	 * @param unknown_type $fromYear
	 * @param unknown_type $toYear
	 * @return unknown_type
	 */
	function getSubstancesPublications($substanceName, $kol_id, $fromYear, $toYear,$filters = null, $viewType){
		$arrPublicationsDetail=array();
		/*$arrPublications=$this->db->query("select pubmed_substances.name ,publications.id,publications.pmid,pubmed_journals.name as journal_name,publications.article_title,publications.created_date,count(distinct kol_publications.pub_id) as count,kol_publications.auth_pos,publications.link from pubmed_substances
											LEFT JOIN publication_substances ON publication_substances.substance_id=pubmed_substances.id 
											LEFT JOIN publications ON publications.id=publication_substances.pub_id 
											LEFT JOIN kol_publications ON kol_publications.pub_id=publications.id 
											LEFT JOIN `pubmed_journals` ON `pubmed_journals`.`id` = `publications`.`journal_id`
											where kol_id='$kol_id' AND `kol_publications`.`is_deleted` = 0 
											AND kol_publications.is_verified=1 
											AND pubmed_substances.id='$substanceName'
											AND year(publications.created_date) between $fromYear and $toYear
											group by kol_publications.pub_id order by count desc");*/

		$this->db->select('pubmed_substances.name ,publications.id,publications.pmid,pubmed_journals.name as journal_name,publications.article_title,publications.created_date,count(distinct kol_publications.pub_id) as count,kol_publications.auth_pos,publications.link,count(distinct(publications_authors.id)) as authcount');
		$this->db->join('publication_substances', 'publication_substances.substance_id = pubmed_substances.id','left');
		$this->db->join('publications', 'publications.id = publication_substances.pub_id','left');
		$this->db->join('kol_publications', 'kol_publications.pub_id = publications.id','left');
		$this->db->join('pubmed_journals', 'pubmed_journals.id = publications.journal_id','left');
		$this->db->join('kols', 'kol_publications.kol_id = kols.id','left');
		$this->db->join('publications_authors', 'publications_authors.pub_id = publications.id');
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		if($kol_id != 0)
			$this->db->where('kol_publications.kol_id',$kol_id);
		$this->db->where('pubmed_substances.id',$substanceName);
		$this->db->where('(YEAR(publications.created_date) BETWEEN '.$fromYear.' AND '.$toYear.' OR YEAR(publications.created_date)=0)');
		//$this->db->where('kols.status',COMPLETED);
		if(count($viewType)>0 && !empty($viewType))
			$this->db->where_in('kols.id',$viewType);
		//Refine by filters
		if($filters != null){
			if(isset($filters['global_region'])){
				$globalRegion = $filters['global_region'];
				foreach($globalRegion as $arrGlobalRegionIds){
					 $str = str_replace("_","/",$arrGlobalRegionIds);
        			$globalRegionSorted[] = str_replace("%20"," ",$str);
				}
				$this->db->join('countries', 'countries.CountryId = kols.country_id','left');
				$isKolsJoined = true;
				$this->db->where_in('countries.GlobalRegion', $globalRegionSorted);
			}
			
			if(isset($filters['specialty'])){
				$this->db->join('specialties', 'specialties.id = kols.specialty','left');
				$this->db->where_in('specialties.id',$filters['specialty']);
			}
			if(isset($filters['country'])){
				if($isKolsJoined == false)
					$this->db->join('countries', 'countries.CountryId = kols.country_id','left');
				$this->db->where_in('countries.CountryId',$filters['country']);
			}
			if(isset($filters['state'])){
				$this->db->join('regions', 'regions.RegionID = kols.state_id','left');
				$this->db->where_in('regions.RegionID',$filters['state']);
			}
			if(isset($filters['kol_id'])){
				$this->db->where_in('kol_publications.kol_id',$filters['kol_id']);
			}
			if(isset($filters['listName'])){
				$userId   =$this->session->userdata('user_id');
		 		$clientId =$this->session->userdata('client_id');
		 		$this->db->join('list_kols','list_kols.kol_id=kol_publications.kol_id','left');
		 		$this->db->join('list_names','list_kols.list_name_id=list_names.id','left');
		 		$this->db->join('list_categories','list_names.category_id=list_categories.id','left');
		 		$this->db->where_in('list_names.id',$filters['listName']);
		 		$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
			}
			if (isset($filters['profileType'][0])){
			    if(str_replace("%20"," ",$filters['profileType'][0]) == DISCOVERY){
			        $this->db->where('(kols.imported_as = 2 or kols.imported_as = 3)', null, false);
			    }else{
			        $this->db->where('kols.profile_type', str_replace("%20"," ",$filters['profileType'][0]));
			        $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
			    }
			    //             $this->db->where('kols.profile_type', $arrProfileType);
			}else{
			    $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
			}
		}
		$this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
		$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		
		$this->db->group_by('kol_publications.pub_id');
		$this->db->order_by('created_date','desc');
		//$this->db->limit('20');
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$arrPublications	=	$this->db->get('pubmed_substances');
		//echo $this->db->last_query();
		
		foreach($arrPublications->result_array() as $row){
		    if(isset($row['pmid']) && $row['pmid'] > 0){
		        $row['linkForArticle'] = 'pmid';
		    }else{
		        $row['linkForArticle'] = 'link';
		    }
			$arrPublicationsDetail[]=$row;
		}
		return $arrPublicationsDetail;
	}
	
	
	/**
	 * returns the list of publications belongs to perticular kolId passed
	 * @param $kolId
	 * @return unknown_type
	 * @author Vinayak
	 * @since 1.4.4
	 */
	function getMajorMeshtermPublications($meshterm1,$meshterm2,$kol_id, $fromYear, $toYear,$filters = null, $viewType){
		$arrPublications=array();
		/*$arrPublicationResult = $this->db->query("SELECT pubmed_mesh_terms.term_name as mesh_term,
														publications.article_title,
														publications.journal_id,
														publications.created_date,
														pubmed_journals.name as journal_name,
														publications.id,
														kols.first_name,kols.middle_name,kols.last_name,kol_publications.auth_pos,publications.pmid,publications.link
													FROM pubmed_mesh_terms
														LEFT JOIN publication_mesh_terms ON publication_mesh_terms.term_id = pubmed_mesh_terms.id
														LEFT JOIN publications ON publications.id = publication_mesh_terms.pub_id
														LEFT JOIN kol_publications ON kol_publications.pub_id = publications.id
														LEFT JOIN kols ON kol_publications.kol_id = kols.id
														LEFT JOIN pubmed_journals ON pubmed_journals.id = publications.journal_id
													WHERE kol_publications.is_deleted=0 
													AND kol_publications.is_verified=1 
													AND YEAR(publications.created_date)>='$fromYear' AND YEAR(publications.created_date)<='$toYear'
															AND pubmed_mesh_terms.id='$meshterm2'
															AND pubmed_mesh_terms.parent_id='$meshterm1' 
															AND kol_publications.kol_id=$kol_id
															AND publication_mesh_terms.is_major = '1'
													GROUP BY kol_publications.pub_id;");*/
		
		
		$this->db->select('pubmed_mesh_terms.term_name as mesh_term,
														publications.article_title,
														publications.journal_id,
														publications.created_date,
														pubmed_journals.name as journal_name,
														publications.id,
														kols.first_name,kols.middle_name,kols.last_name,kol_publications.auth_pos,publications.pmid,publications.link,count(distinct(publications_authors.id)) as authcount');
		$this->db->join('publication_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
		$this->db->join('publications', 'publications.id = publication_mesh_terms.pub_id','left');
		$this->db->join('kol_publications', 'kol_publications.pub_id = publications.id','left');
		$this->db->join('kols', 'kol_publications.kol_id = kols.id','left');
		$this->db->join('pubmed_journals', 'pubmed_journals.id = publications.journal_id','left');
		$this->db->join('publications_authors', 'publications_authors.pub_id = publications.id','left');
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		if($kol_id != 0)
			$this->db->where('kol_id',$kol_id);
		$this->db->where('(YEAR(publications.created_date) BETWEEN '.$fromYear.' AND '.$toYear.' OR YEAR(publications.created_date)=0)');
		//$this->db->where('kols.status',COMPLETED);
		$this->db->where('pubmed_mesh_terms.id',$meshterm2);
		$this->db->where('pubmed_mesh_terms.parent_id',$meshterm1);
		//$this->db->where('publication_mesh_terms.is_major',1);
		if(count($viewType)>0 && !empty($viewType))
			$this->db->where_in('kols.id',$viewType);
		//Refine by filters
		if($filters != null){
			if(isset($filters['global_region'])){
				$globalRegion = $filters['global_region'];
				foreach($globalRegion as $arrGlobalRegionIds){
					 $str = str_replace("_","/",$arrGlobalRegionIds);
        			$globalRegionSorted[] = str_replace("%20"," ",$str);
				}
				$this->db->join('countries', 'countries.CountryId = kols.country_id','left');
				$isKolsJoined = true;
				$this->db->where_in('countries.GlobalRegion', $globalRegionSorted);
			}
			
			if(isset($filters['specialty'])){
				$this->db->join('specialties', 'specialties.id = kols.specialty','left');
				$this->db->where_in('specialties.id',$filters['specialty']);
			}
			if(isset($filters['country'])){
				if($isKolsJoined == false)
					$this->db->join('countries', 'countries.CountryId = kols.country_id','left');
				$this->db->where_in('countries.CountryId',$filters['country']);
			}
			if(isset($filters['state'])){
				$this->db->join('regions', 'regions.RegionID = kols.state_id','left');
				$this->db->where_in('regions.RegionID',$filters['state']);
			}
			if(isset($filters['kol_id'])){
				$this->db->where_in('kol_publications.kol_id',$filters['kol_id']);
			}
			if(isset($filters['listName'])){
				$userId   =$this->session->userdata('user_id');
		 		$clientId =$this->session->userdata('client_id');
		 		$this->db->join('list_kols','list_kols.kol_id=kol_publications.kol_id','left');
		 		$this->db->join('list_names','list_kols.list_name_id=list_names.id','left');
		 		$this->db->join('list_categories','list_names.category_id=list_categories.id','left');
		 		$this->db->where_in('list_names.id',$filters['listName']);
		 		$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
			}
			if (isset($filters['profileType'][0])){
			    if(str_replace("%20"," ",$filters['profileType'][0]) == DISCOVERY){
			        $this->db->where('(kols.imported_as = 2 or kols.imported_as = 3)', null, false);
			    }else{
			        $this->db->where('kols.profile_type', str_replace("%20"," ",$filters['profileType'][0]));
			        $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
			    }
			    //             $this->db->where('kols.profile_type', $arrProfileType);
			}else{
			    $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
			}
			
		}
		$keyword = $this->session->userdata('kolKeyWords');
		if($keyword!=''){
				
				$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
				$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
				$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
				
			}
		$this->db->group_by('kol_publications.pub_id');
		$this->db->order_by('publications.created_date','desc');
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$arrPublicationResult = $this->db->get('pubmed_mesh_terms');
		//pr($this->db->last_query());exit;
		foreach($arrPublicationResult->result_array() as $row){
			if($arrPublicationResult->num_rows()!=0){
			    if(isset($row['pmid']) && $row['pmid'] > 0){
			        $row['linkForArticle'] = 'pmid';
			    }else{
			        $row['linkForArticle'] = 'link';
			    }
			    $arrPublications[]=$row;
			}else{
				return false;
			}
		}	
		return 	$arrPublications;
	
	}

	/**
	 * returns the list of publications belongs to perticular $coAuthName,$kol_id, $fromYear,$toYear passed
	 * @param $coAuthName,$kol_id, $fromYear,$toYear,
	 * @return unknown_type
	 * @author Vinayak
	 * @since 1.4.4
	 */
	function getPublicationsByCoauthor($coAuthName,$kol_id, $fromYear,$toYear,$keyword){
		$arrPublications=array();
		/*$arrPublicationResult = $this->db->query("SELECT pubmed_authors.last_name, pubmed_authors.initials, pubmed_authors.fore_name,
													COUNT(*) as count, pubmed_journals.name as journal_name, 
													publications.article_title, publications.created_date,publications.id,kol_publications.auth_pos,publications.pmid,publications.link
												FROM pubmed_authors
												LEFT JOIN publications_authors ON pubmed_authors.id=publications_authors.alias_id
												LEFT JOIN publications ON publications_authors.pub_id=publications.id
												LEFT JOIN kol_publications ON publications.id=kol_publications.pub_id
												LEFT JOIN pubmed_journals ON pubmed_journals.id = publications.journal_id
												WHERE kol_publications.is_deleted=0
												AND kol_publications.is_verified=1 
												AND kol_publications.kol_id=$kol_id AND YEAR(publications.created_date)>='$fromYear' AND YEAR(publications.created_date)<='$toYear'
																 AND CONCAT(pubmed_authors.last_name, ' ', pubmed_authors.fore_name) = \"".$coAuthName."\"
												GROUP BY kol_publications.pub_id order by publications.created_date desc");*/
		
		$this->db->select(' pubmed_authors.last_name, pubmed_authors.initials, pubmed_authors.fore_name,
							COUNT(*) as count, pubmed_journals.name as journal_name, 
							publications.article_title, publications.created_date,publications.id,kol_publications.auth_pos,
							publications.pmid,publications.link');
		$this->db->join('publications_authors','pubmed_authors.id=publications_authors.alias_id','left');
		$this->db->join('publications','publications_authors.pub_id=publications.id','left');
		$this->db->join('kol_publications','publications.id=kol_publications.pub_id','left');
		$this->db->join('pubmed_journals','pubmed_journals.id = publications.journal_id','left');
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		$this->db->where("( kol_publications.kol_id=$kol_id AND YEAR(publications.created_date)>='$fromYear' AND YEAR(publications.created_date)<='$toYear'
							AND CONCAT(pubmed_authors.last_name, ' ', pubmed_authors.fore_name) = \"".$coAuthName."\")");
	
		if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		$this->db->group_by('kol_publications.pub_id');
		$this->db->order_by('publications.created_date','desc');
		$arrPublicationResult = $this->db->get('pubmed_authors');
		//pr($this->db->last_query());exit;
		foreach($arrPublicationResult->result_array() as $row){
			if($arrPublicationResult->num_rows()!=0){
				$row['authcount'] = $this->pubmed->getNumberOfAuthors($row['id']);
				if(isset($row['pmid']) && $row['pmid'] > 0){
				    $row['linkForArticle'] = 'pmid';
				}else{
				    $row['linkForArticle'] = 'link';
				}
				$arrPublications[]=$row;
			}else{
				return false;
			}
		}	
		return 	$arrPublications;
	}


	/**
	 * Returns the list of To 20 Journals of partiucular Kol
 	 * @param $kol_id, $fromYear,$toYear,
	 * @return unknown_type
	 * @author Vinayak
	 * @since 1.4.4
	 */
	function getPubJournalsChart($kolId,$fromYear,$toYear,$keyword){
		$arrJournals=array();
		/*$arrJournalsResult = $this->db->query("SELECT pubmed_journals.id,pubmed_journals.name ,
													count(distinct kol_publications.pub_id) as count from pubmed_journals
												LEFT JOIN publications ON publications.journal_id=pubmed_journals.id 
												LEFT JOIN kol_publications ON kol_publications.pub_id=publications.id 
												where kol_id='".$kolId."' AND `kol_publications`.`is_deleted` = 0 
												AND kol_publications.is_verified=1 
												AND year(publications.created_date) between ".$fromYear." and ".$toYear."
												group by pubmed_journals.name order by count desc limit 20");*/
		
		$this->db->select("pubmed_journals.id,pubmed_journals.name ,count(distinct kol_publications.pub_id) as count");
		$this->db->join('publications','publications.journal_id=pubmed_journals.id','left');
		$this->db->join('kol_publications','kol_publications.pub_id=publications.id','left');
		
	if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		$this->db->where('kol_id',$kolId);
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		$this->db->where('(year(publications.created_date) between '.$fromYear.' and '.$toYear.')');
		$this->db->group_by('pubmed_journals.name');
		$this->db->order_by('count','desc');
		$this->db->limit(20);
		$arrJournalsResult = $this->db->get('pubmed_journals');
		if($arrJournalsResult->num_rows()!=0){
			foreach($arrJournalsResult->result_array() as $row){
					$arrJournals[]=$row;
			}
		}else{
				return false;
			}	
		return 	$arrJournals;
	}

	/**
	 * Returns the list of Publication details of Particular Journal Name,KOl_Id,Time Range
	 * @param $journalName,$kol_id, $fromYear,$toYear,
	 * @return unknown_type
	 * @author Vinayak
	 * @since 1.4.4
	 */
	function getPublicationsByJournals($journalName,$kol_id, $fromYear,$toYear,$filters = null,$viewType){
		$arrJournals=array();
		/*$arrJournalsResult = $this->db->query("select pubmed_journals.name ,publications.id,publications.pmid,
													pubmed_journals.name as journal_name,
													publications.article_title,publications.created_date,
													count(distinct kol_publications.pub_id) as count,kol_publications.auth_pos,publications.link from pubmed_journals
												LEFT JOIN publications ON publications.journal_id=pubmed_journals.id 
												LEFT JOIN kol_publications ON kol_publications.pub_id=publications.id 
												where kol_id='$kol_id' AND `kol_publications`.`is_deleted` = 0 
												AND kol_publications.is_verified=1 
												AND pubmed_journals.id='$journalName'
												AND year(publications.created_date) between $fromYear and $toYear
												group by kol_publications.pub_id order by count desc ");*/
		
		$this->db->select('pubmed_journals.name ,publications.id,publications.pmid,
													pubmed_journals.name as journal_name,
													publications.article_title,publications.created_date,
													count(distinct kol_publications.pub_id) as count,kol_publications.auth_pos,publications.link');
		$this->db->join('publications', 'publications.journal_id = pubmed_journals.id','left');
		$this->db->join('kol_publications', 'kol_publications.pub_id = publications.id','left');
		$this->db->join('kols', 'kol_publications.kol_id = kols.id','left');
		
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		if($kol_id != 0)
			$this->db->where('kol_publications.kol_id',$kol_id);
		$this->db->where('(YEAR(publications.created_date) BETWEEN '.$fromYear.' AND '.$toYear.' OR YEAR(publications.created_date)=0)');
// 		$this->db->where('kols.status',COMPLETED);
		$this->db->where('pubmed_journals.id',$journalName);
		if(count($viewType)>0 && !empty($viewType))
			$this->db->where_in('kols.id',$viewType);
		//Refine by filters
		if($filters != null){
			if(isset($filters['global_region'])){
				$globalRegion = $filters['global_region'];
				foreach($globalRegion as $arrGlobalRegionIds){
					 $str = str_replace("_","/",$arrGlobalRegionIds);
        			$globalRegionSorted[] = str_replace("%20"," ",$str);
				}
				$this->db->join('countries', 'countries.CountryId = kols.country_id','left');
				$isKolsJoined = true;
				$this->db->where_in('countries.GlobalRegion', $globalRegionSorted);
			}
			
			if(isset($filters['specialty'])){
				$this->db->join('specialties', 'specialties.id = kols.specialty','left');
				$this->db->where_in('specialties.id',$filters['specialty']);
			}
			if(isset($filters['country'])){
				if($isKolsJoined == false)
					$this->db->join('countries', 'countries.CountryId = kols.country_id','left');
				$this->db->where_in('countries.CountryId',$filters['country']);
			}
			if(isset($filters['state'])){
				$this->db->join('regions', 'regions.RegionID = kols.state_id','left');
				$this->db->where_in('regions.RegionID',$filters['state']);
			}
			if(isset($filters['kol_id'])){
				$this->db->where_in('kol_publications.kol_id',$filters['kol_id']);
			}
			if(isset($filters['listName'])){
				$userId   =$this->session->userdata('user_id');
		 		$clientId =$this->session->userdata('client_id');
		 		$this->db->join('list_kols','list_kols.kol_id=kol_publications.kol_id','left');
		 		$this->db->join('list_names','list_kols.list_name_id=list_names.id','left');
		 		$this->db->join('list_categories','list_names.category_id=list_categories.id','left');
		 		$this->db->where_in('list_names.id',$filters['listName']);
		 		$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
			}
			if (isset($filters['profileType'][0])){
			    if(str_replace("%20"," ",$filters['profileType'][0]) == DISCOVERY){
			        $this->db->where('(kols.imported_as = 2 or kols.imported_as = 3)', null, false);
			    }else{
			        $this->db->where('kols.profile_type', str_replace("%20"," ",$filters['profileType'][0]));
			        $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
			    }
			    //             $this->db->where('kols.profile_type', $arrProfileType);
			}else{
			    if($kol_id == 0)
			    $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
			}
			
		$keyword = $filters['keyword'];
		if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		}
		
		$this->db->group_by('kol_publications.pub_id');
		$this->db->order_by('created_date','desc');
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		
		$arrJournalsResult = $this->db->get('pubmed_journals');
		//echo $this->db->last_query();
		foreach($arrJournalsResult->result_array() as $row){
			if($arrJournalsResult->num_rows()!=0){
				$row['authcount'] = $this->pubmed->getNumberOfAuthors($row['id']);
				if(isset($row['pmid']) && $row['pmid'] > 0){
				    $row['linkForArticle'] = 'pmid';
				}else{
				    $row['linkForArticle'] = 'link';
				}
				$arrJournals[]=$row;
			}else{
				return false;
			}
		}	
		return 	$arrJournals;
	}

	/**
	 * Udates the Authorship position for publication of kol
	 * @author 	Ramesh B
	 * @Created on: 22-02-11
	 * @since 1.4.4
	 * @return unknown_type
	 */
	function updateAuthorshipPos($kolId,$pubId,$position){
		$kolPublication=array();
		$kolPublication['auth_pos']=$position;
		//$kolPublication['kol_id']=$kolId;
		//$kolPublication['pub_id']=$pubId;
		
		$this->db->where('kol_id', $kolId);	
		$this->db->where('pub_id', $pubId);		
		if($this->db->update('kol_publications', $kolPublication)){
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Returns the aray of results containing the kol publications results in which kol is a single author
	 * @author 	Ramesh B
	 * @Created on: 23-02-11
	 * @since 1.4.4
	 * @return Array
	 */
	function getKolPubsWithSingleAuthor($kolId,$start,$end,$arrKolIds=0,$arrCountries=0,$arrSpecialities=0,$arrListNamesIds=0,$keyword,$arrStatesIds,$profileType,$viewType, $arrGlobalRegionIds = 0){
		$arrPublicationsDetail=array();
		
		$queryString="SELECT kol_publications.kol_id,kol_publications.pub_id ,kol_publications.auth_pos,COUNT(publications_authors.pub_id) AS num_auths, YEAR(publications.created_date) AS YEAR
											FROM publications_authors 
											LEFT JOIN publications ON publications.id=publications_authors.pub_id 
											LEFT JOIN kol_publications ON kol_publications.pub_id=publications.id
											LEFT JOIN kols ON kols.id=kol_publications.kol_id 
											LEFT JOIN countries ON kols.country_id=countries.countryId
											WHERE ";
		$this->db->select("kol_publications.kol_id,kol_publications.pub_id ,kol_publications.auth_pos,COUNT(publications_authors.pub_id) AS num_auths, YEAR(publications.created_date) AS YEAR");
		$this->db->join('publications','publications.id=publications_authors.pub_id','left');
		$this->db->join('kol_publications','kol_publications.pub_id=publications.id','left');
		$this->db->join('kols','kols.id=kol_publications.kol_id','left');
		if($kolId!=0)
			$this->db->where("kol_publications.kol_id",$kolId);
			//$queryString.=" kol_publications.kol_id=".$kolId." ";
			
		//Adding where condition for Kol's if Exist
		if(is_array($arrKolIds) && $arrKolIds!=0){
			//$commaKolIds=$this->common_helpers->convertArrayToCommaSeparatedElements($arrKolIds);
			$this->db->where_in('kol_publications.kol_id',$arrKolIds);
			//$queryString	.= " AND kol_publications.kol_id IN($commaKolIds) ";
		}else if($arrKolIds!=0){
			$this->db->where_in('kol_publications.kol_id',$arrKolIds);
			//$queryString	.= " AND kol_publications.kol_id='$arrKolIds' ";
		}
		
		//Adding where condition for Global Region's if Exist
		if(is_array($arrGlobalRegionIds) && $arrGlobalRegionIds!=0){
			$this->db->join('countries','kols.country_id=countries.countryId','left');
			$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
		}else if($arrGlobalRegionIds!=0){
			$this->db->join('countries','kols.country_id=countries.countryId','left');
			$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
			$queryString	.= " AND countries.GlobalRegion='$arrGlobalRegionIds' ";
		}
		
		//Adding where condition for Country's if Exist
		if(is_array($arrCountries) && $arrCountries!=0){
			//$commaCountries=$this->common_helpers->convertArrayToCommaSeparatedElements($arrCountries);
			$this->db->where_in('kols.country_id',$arrCountries);
			//$queryString	.= " AND kols.country_id IN($commaCountries) ";
		}else if($arrCountries!=0){
			$this->db->where_in('kols.country_id',$arrCountries);
			$queryString	.= " AND kols.country_id='$arrCountries' ";
		}
		
		//Adding where condition for Speciality's if Exist
		if(is_array($arrSpecialities) && $arrSpecialities!=0){
			$commaSpecialities=$this->common_helpers->convertArrayToCommaSeparatedElements($arrSpecialities);
			$this->db->where_in('kols.specialty',$arrSpecialities);
			//$queryString	.= " AND kols.specialty IN($commaSpecialities) ";
		}else if($arrSpecialities!=0){
			$this->db->where_in('kols.specialty',$arrSpecialities);
			//$queryString	.= " AND kols.specialty='$arrSpecialities' ";
		}
	if(is_array($arrStatesIds) && $arrStatesIds!=0){
			$this->db->where_in('kols.state_id',$arrStatesIds);
		}else if($arrStatesIds!=0){
			$this->db->where_in('kols.state_id',$arrStatesIds);
		}
	if($profileType!=0){
			$this->db->where('kols.profile_type',$profileType);
		}
	if(is_array($viewType) && $viewType!=0 && !empty($viewType)){
			$this->db->where_in('kols.id',$viewType);
		}else if($viewType!=0 && !empty($viewType)){
			$this->db->where_in('kols.id',$viewType);
		}			
					
		if($arrListNamesIds!=''  && $arrListNamesIds!=0){
					$userId=$this->session->userdata('user_id');
					$clientId=$this->session->userdata('client_id');
					$this->db->join('list_kols','list_kols.kol_id=kols.id','left');
					$this->db->join('list_names','list_names.id=list_kols.list_name_id','left');
					$this->db->join('list_categories','list_categories.id=list_names.category_id','left');
					$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
					$this->db->where_in('list_names.id',$arrListNamesIds);
		}
		$this->db->where("(kol_publications.is_deleted=0 AND kol_publications.is_verified=1)");
		if($start!=0 && $end!=0){
		//$this->db->where("(YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."')");
			$this->db->where("(((YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."')or YEAR(publications.created_date)='0')) ");
		}
		
	
		if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		$this->db->group_by('kol_publications.kol_id,publications_authors.pub_id HAVING num_auths=1');

		//$queryString.=" AND kol_publications.is_deleted=0 AND kol_publications.is_verified=1 AND YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."'
											//GROUP BY kol_publications.kol_id,publications_authors.pub_id HAVING num_auths=1";
		
		$arrPublications = $this->db->get('publications_authors' );
		//pr($this->db->last_query());exit;
		foreach($arrPublications->result_array() as $row){
			
			$arrPublicationsDetail[]=$row;
		}
		
		return $arrPublicationsDetail;
	}
	
	/**
	 * Returns the kol publications in which his authorship position is 1
	 * @author 	Ramesh B
	 * @Created on: 23-02-11
	 * @since 1.4.4
	 * @return Array
	 */
	function getKolPubsWithFirstAuthorship($kolId,$start,$end,$arrKolIds=0,$arrCountries=0,$arrSpecialities=0,$arrListNamesIds=0,$keyword,$arrStatesIds,$profileType,$viewType, $arrGlobalRegionIds = 0){
		$arrPublicationsDetail=array();
		
		$queryString="SELECT kol_publications.kol_id,kol_publications.pub_id ,kol_publications.auth_pos,COUNT(publications_authors.pub_id) AS num_auths, YEAR(publications.created_date) AS YEAR
											FROM publications_authors 
											LEFT JOIN publications ON publications.id=publications_authors.pub_id 
											LEFT JOIN kol_publications ON kol_publications.pub_id=publications.id
											LEFT JOIN kols ON kols.id=kol_publications.kol_id
											LEFT JOIN countries ON kols.country=countries.countryId
											WHERE";
		$this->db->select("kol_publications.kol_id,kol_publications.pub_id ,kol_publications.auth_pos,COUNT(publications_authors.pub_id) AS num_auths, YEAR(publications.created_date) AS YEAR");
		$this->db->join('publications','publications.id=publications_authors.pub_id','left');
		$this->db->join('kol_publications','kol_publications.pub_id=publications.id','left');
		$this->db->join('kols','kols.id=kol_publications.kol_id','left');
		if($kolId!=0)
			$this->db->where("kol_publications.kol_id",$kolId);
			//$queryString.=" kol_publications.kol_id=".$kolId." ";
			
		//Adding where condition for Kol's if Exist
		if(is_array($arrKolIds) && $arrKolIds!=0){
			//$commaKolIds=$this->common_helpers->convertArrayToCommaSeparatedElements($arrKolIds);
			$this->db->where_in('kol_publications.kol_id',$arrKolIds);
			//$queryString	.= " AND kol_publications.kol_id IN($commaKolIds) ";
		}else if($arrKolIds!=0){
			$this->db->where_in('kol_publications.kol_id',$arrKolIds);
			//$queryString	.= " AND kol_publications.kol_id='$arrKolIds' ";
		}
		
		//Adding where condition for Global Region's if Exist
		if(is_array($arrGlobalRegionIds) && $arrGlobalRegionIds!=0){
			//$commaCountries=$this->common_helpers->convertArrayToCommaSeparatedElements($arrCountries);
        	$this->db->join('countries','kols.country_id=countries.countryId','left');
			$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
		}else if($arrGlobalRegionIds!=0){
			$this->db->join('countries','kols.country_id=countries.countryId','left');
			$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
			$queryString	.= " AND countries.GlobalRegion='$arrGlobalRegionIds' ";
		}
		
		//Adding where condition for Country's if Exist
		if(is_array($arrCountries) && $arrCountries!=0){
			//$commaCountries=$this->common_helpers->convertArrayToCommaSeparatedElements($arrCountries);
			$this->db->where_in('kols.country_id',$arrCountries);
			//$queryString	.= " AND kols.country_id IN($commaCountries) ";
		}else if($arrCountries!=0){
			$this->db->where_in('kols.country_id',$arrCountries);
			$queryString	.= " AND kols.country_id='$arrCountries' ";
		}
		
		//Adding where condition for Speciality's if Exist
		if(is_array($arrSpecialities) && $arrSpecialities!=0){
			$commaSpecialities=$this->common_helpers->convertArrayToCommaSeparatedElements($arrSpecialities);
			$this->db->where_in('kols.specialty',$arrSpecialities);
			//$queryString	.= " AND kols.specialty IN($commaSpecialities) ";
		}else if($arrSpecialities!=0){
			$this->db->where_in('kols.specialty',$arrSpecialities);
			//$queryString	.= " AND kols.specialty='$arrSpecialities' ";
		}
	if(is_array($arrStatesIds) && $arrStatesIds!=0){
			$this->db->where_in('kols.state_id',$arrStatesIds);
		}else if($arrStatesIds!=0){
			$this->db->where_in('kols.state_id',$arrStatesIds);
		}
	if($profileType!=0){
			$this->db->where('kols.profile_type',$profileType);
		}
	if(is_array($viewType) && $viewType!=0 && !empty($viewType)){
			$this->db->where_in('kols.id',$viewType);
		}else if($viewType!=0 && !empty($viewType)){
			$this->db->where_in('kols.id',$viewType);
		}				
		if($arrListNamesIds!='' && $arrListNamesIds!=0){
					$userId=$this->session->userdata('user_id');
					$clientId=$this->session->userdata('client_id');
					$this->db->join('list_kols','list_kols.kol_id=kols.id','left');
					$this->db->join('list_names','list_names.id=list_kols.list_name_id','left');
					$this->db->join('list_categories','list_categories.id=list_names.category_id','left');
					$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
					$this->db->where_in('list_names.id',$arrListNamesIds);
		}
		
		$this->db->where("(kol_publications.is_deleted=0 AND kol_publications.is_verified=1) AND kol_publications.auth_pos=1");
		if($start!=0 && $end!=0)
		$this->db->where("(((YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."')or YEAR(publications.created_date)='0')) ");
		//$this->db->where("(YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."')");
	if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		$this->db->group_by('kol_publications.kol_id,publications_authors.pub_id HAVING num_auths>1');
		
		
		//$queryString.=" AND kol_publications.is_deleted=0 AND kol_publications.is_verified=1 AND kol_publications.auth_pos=1 AND YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."'
											//GROUP BY kol_publications.kol_id,publications_authors.pub_id HAVING num_auths>1";
		
		$arrPublications = $this->db->get('publications_authors');
		//	$arrPublications = $this->db->query($queryString);
		//echo $this->db->last_query();
		foreach($arrPublications->result_array() as $row){
			
			$arrPublicationsDetail[]=$row;
		}
		return $arrPublicationsDetail;
	}
	
	/**
	 * Returns the kol publications in which kol is a last author // iterate trough reslts, get the results whose auth_pos=max_pos
	 * @author 	Ramesh B
	 * @Created on: 23-02-11
	 * @since 1.4.4
	 * @return Array
	 */
	function getKolPubsWithLastAuthorship($kolId,$start,$end,$arrKolIds=0,$arrCountries=0,$arrSpecialities=0,$arrListNamesIds=0,$keyword,$arrStatesIds,$profileType,$viewType){
		$arrPublicationsDetail=array();
		$queryString="SELECT kol_publications.kol_id,kol_publications.*,MAX(publications_authors.position) AS max_pos, kol_publications.auth_pos AS cur_pos, YEAR(publications.created_date) AS YEAR 
											FROM publications_authors 
											LEFT JOIN publications ON publications.id=publications_authors.pub_id
											LEFT JOIN kol_publications ON publications_authors.pub_id=kol_publications.pub_id
											LEFT JOIN kols ON kols.id=kol_publications.kol_id
											LEFT JOIN countries ON kols.country_id=countries.countryId
											WHERE";
		$this->db->select("kol_publications.kol_id,kol_publications.*,MAX(publications_authors.position) AS max_pos, kol_publications.auth_pos AS cur_pos, YEAR(publications.created_date) AS YEAR");
		$this->db->join('publications','publications.id=publications_authors.pub_id','left');
		$this->db->join('kol_publications','kol_publications.pub_id=publications.id','left');
		$this->db->join('kols','kols.id=kol_publications.kol_id','left');
		if($kolId!=0)
			$this->db->where("kol_publications.kol_id",$kolId);
			//$queryString.=" kol_publications.kol_id=".$kolId." ";
			
		//Adding where condition for Kol's if Exist
		if(is_array($arrKolIds) && $arrKolIds!=0){
			//$commaKolIds=$this->common_helpers->convertArrayToCommaSeparatedElements($arrKolIds);
			$this->db->where_in('kol_publications.kol_id',$arrKolIds);
			//$queryString	.= " AND kol_publications.kol_id IN($commaKolIds) ";
		}else if($arrKolIds!=0){
			$this->db->where_in('kol_publications.kol_id',$arrKolIds);
			//$queryString	.= " AND kol_publications.kol_id='$arrKolIds' ";
		}
		//Adding where condition for Global Region's if Exist
		if(is_array($arrGlobalRegionIds) && $arrGlobalRegionIds!=0){
			$this->db->join('countries','kols.country_id=countries.countryId','left');
			$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
		}else if($arrGlobalRegionIds!=0){
			$this->db->join('countries','kols.country_id=countries.countryId','left');
			$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
			$queryString	.= " AND countries.GlobalRegion='$arrGlobalRegionIds' ";
		}
		//Adding where condition for Country's if Exist
		if(is_array($arrCountries) && $arrCountries!=0){
			//$commaCountries=$this->common_helpers->convertArrayToCommaSeparatedElements($arrCountries);
			$this->db->where_in('kols.country_id',$arrCountries);
			//$queryString	.= " AND kols.country_id IN($commaCountries) ";
		}else if($arrCountries!=0){
			$this->db->where_in('kols.country_id',$arrCountries);
			$queryString	.= " AND kols.country_id='$arrCountries' ";
		}
		
		//Adding where condition for Speciality's if Exist
		if(is_array($arrSpecialities) && $arrSpecialities!=0){
			$commaSpecialities=$this->common_helpers->convertArrayToCommaSeparatedElements($arrSpecialities);
			$this->db->where_in('kols.specialty',$arrSpecialities);
			//$queryString	.= " AND kols.specialty IN($commaSpecialities) ";
		}else if($arrSpecialities!=0){
			$this->db->where_in('kols.specialty',$arrSpecialities);
			//$queryString	.= " AND kols.specialty='$arrSpecialities' ";
		}
	if(is_array($arrStatesIds) && $arrStatesIds!=0){
			$this->db->where_in('kols.state_id',$arrStatesIds);
		}else if($arrStatesIds!=0){
			$this->db->where_in('kols.state_id',$arrStatesIds);
		}
	if($profileType!=0){
			$this->db->where('kols.profile_type',$profileType);
		}
	if(is_array($viewType) && $viewType!=0 && !empty($viewType)){
			$this->db->where_in('kols.id',$viewType);
		}else if($viewType!=0 && !empty($viewType)){
			$this->db->where_in('kols.id',$viewType);
		}			
		if($arrListNamesIds!=''  && $arrListNamesIds!=0){
					$userId=$this->session->userdata('user_id');
					$clientId=$this->session->userdata('client_id');
					$this->db->join('list_kols','list_kols.kol_id=kols.id','left');
					$this->db->join('list_names','list_names.id=list_kols.list_name_id','left');
					$this->db->join('list_categories','list_categories.id=list_names.category_id','left');
					$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
					$this->db->where_in('list_names.id',$arrListNamesIds);
		}
		
		$this->db->where("(kol_publications.is_deleted=0 AND kol_publications.is_verified=1)");
		if($start!=0 && $end!=0)
		$this->db->where("(((YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."')or YEAR(publications.created_date)='0')) ");
	if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		$this->db->group_by('kol_publications.kol_id,publications_authors.pub_id');
		
		//$queryString.=" AND kol_publications.is_deleted=0 AND kol_publications.is_verified=1 AND YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."'
											//GROUP BY kol_publications.kol_id,publications_authors.pub_id";
		$arrPublications = $this->db->get('publications_authors');
		//$arrPublications = $this->db->query($queryString);
		//echo $this->db->last_query();
		foreach($arrPublications->result_array() as $row){
			
			$arrPublicationsDetail[]=$row;
		}
		return $arrPublicationsDetail;
	}
	
	/**
	 * Returns the kol publications in which kol is a last author // iterate trough reslts, get the results whose auth_pos=max_pos
	 * @author 	Ramesh B
	 * @Created on: 23-02-11
	 * @since 1.4.4
	 * @return Array
	 */
	function getKolPubsWithMiddleAuthorship($kolId,$start,$end,$arrKolIds=0,$arrCountries=0,$arrSpecialities=0,$arrListNamesIds=0,$keyword,$arrStatesIds,$profileType,$viewType){
		$arrPublicationsDetail=array();
		$queryString="SELECT kol_publications.kol_id,kol_publications.pub_id ,kol_publications.auth_pos,MAX(publications_authors.position) AS max_pos,COUNT(publications_authors.pub_id) AS num_auths, YEAR(publications.created_date) AS YEAR
											FROM publications_authors 
											LEFT JOIN publications ON publications.id=publications_authors.pub_id 
											LEFT JOIN kol_publications ON kol_publications.pub_id=publications.id
											LEFT JOIN kols ON kols.id=kol_publications.kol_id 
											LEFT JOIN countries ON kols.country_id=countries.countryId
											WHERE";
		
		$this->db->select("kol_publications.kol_id,kol_publications.pub_id ,kol_publications.auth_pos,MAX(publications_authors.position) AS max_pos,COUNT(publications_authors.pub_id) AS num_auths, YEAR(publications.created_date) AS YEAR");
		$this->db->join('publications','publications.id=publications_authors.pub_id','left');
		$this->db->join('kol_publications','kol_publications.pub_id=publications.id','left');
		$this->db->join('kols','kols.id=kol_publications.kol_id','left');
		if($kolId!=0)
			$this->db->where("kol_publications.kol_id",$kolId);
			//$queryString.=" kol_publications.kol_id=".$kolId." ";
			
		//Adding where condition for Kol's if Exist
		if(is_array($arrKolIds) && $arrKolIds!=0){
			//$commaKolIds=$this->common_helpers->convertArrayToCommaSeparatedElements($arrKolIds);
			$this->db->where_in('kol_publications.kol_id',$arrKolIds);
			//$queryString	.= " AND kol_publications.kol_id IN($commaKolIds) ";
		}else if($arrKolIds!=0){
			$this->db->where_in('kol_publications.kol_id',$arrKolIds);
			//$queryString	.= " AND kol_publications.kol_id='$arrKolIds' ";
		}
		//Adding where condition for Global Region's if Exist
		if(is_array($arrGlobalRegionIds) && $arrGlobalRegionIds!=0){
			$this->db->join('countries','kols.country_id=countries.countryId','left');
			$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
		}else if($arrGlobalRegionIds!=0){
			$this->db->join('countries','kols.country_id=countries.countryId','left');
			$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
			$queryString	.= " AND countries.GlobalRegion='$arrGlobalRegionIds' ";
		}
		//Adding where condition for Country's if Exist
		if(is_array($arrCountries) && $arrCountries!=0){
			//$commaCountries=$this->common_helpers->convertArrayToCommaSeparatedElements($arrCountries);
			$this->db->where_in('kols.country_id',$arrCountries);
			//$queryString	.= " AND kols.country_id IN($commaCountries) ";
		}else if($arrCountries!=0){
			$this->db->where_in('kols.country_id',$arrCountries);
			$queryString	.= " AND kols.country_id='$arrCountries' ";
		}
		
		//Adding where condition for Speciality's if Exist
		if(is_array($arrSpecialities) && $arrSpecialities!=0){
			$commaSpecialities=$this->common_helpers->convertArrayToCommaSeparatedElements($arrSpecialities);
			$this->db->where_in('kols.specialty',$arrSpecialities);
			//$queryString	.= " AND kols.specialty IN($commaSpecialities) ";
		}else if($arrSpecialities!=0){
			$this->db->where_in('kols.specialty',$arrSpecialities);
			//$queryString	.= " AND kols.specialty='$arrSpecialities' ";
		}
	if(is_array($arrStatesIds) && $arrStatesIds!=0){
			$this->db->where_in('kols.state_id',$arrStatesIds);
		}else if($arrStatesIds!=0){
			$this->db->where_in('kols.state_id',$arrStatesIds);
		}
	if($profileType!=0){
			$this->db->where('kols.profile_type',$profileType);
		}
	if(is_array($viewType) && $viewType!=0 && !empty($viewType)){
			$this->db->where_in('kols.id',$viewType);
		}else if($viewType!=0 && !empty($viewType)){
			$this->db->where_in('kols.id',$viewType);
		}			
		if($arrListNamesIds!=''  && $arrListNamesIds!=0){
					$userId=$this->session->userdata('user_id');
					$clientId=$this->session->userdata('client_id');
					$this->db->join('list_kols','list_kols.kol_id=kols.id','left');
					$this->db->join('list_names','list_names.id=list_kols.list_name_id','left');
					$this->db->join('list_categories','list_categories.id=list_names.category_id','left');
					$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
					$this->db->where_in('list_names.id',$arrListNamesIds);
		}
		
		$this->db->where("(kol_publications.is_deleted=0 AND kol_publications.is_verified=1) AND kol_publications.auth_pos!=1 ");
		if($start!=0 && $end!=0)
		//$this->db->where("(YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."')");
		$this->db->where("(((YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."')or YEAR(publications.created_date)='0')) ");
	if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		
		$this->db->group_by('kol_publications.kol_id,publications_authors.pub_id HAVING num_auths>1');
		
		//$queryString.=" AND kol_publications.is_deleted=0 AND kol_publications.is_verified=1 AND kol_publications.auth_pos!=1 AND YEAR(publications.created_date) BETWEEN '".$start."' AND '".$end."'
											//GROUP BY kol_publications.kol_id,publications_authors.pub_id HAVING num_auths>1";
		$arrPublications = $this->db->get('publications_authors');
		//$arrPublications = $this->db->query($queryString);
		//echo $this->db->last_query();
		foreach($arrPublications->result_array() as $row){
			
			$arrPublicationsDetail[]=$row;
		}
		return $arrPublicationsDetail;
	}
	
	/**
	 * Returns the kol publications years range
	 * @author 	Ramesh B
	 * @Created on: 23-02-11
	 * @since 1.4.4
	 * @return Array
	 */
	function getKolPubsYearsRange($kolId){
		$arrYears=array();
		$client_id = $this->session->userdata('client_id');
		$where="";
		if($client_id !== INTERNAL_CLIENT_ID){
		    $where = "AND (kol_publications.client_id = $client_id or kol_publications.client_id = 1)";
		}
		$arrResults=$this->db->query("SELECT MIN(YEAR(publications.created_date)) AS min_year,MAX(YEAR(publications.created_date)) AS max_year
									FROM publications
									LEFT JOIN kol_publications ON publications.id=kol_publications.pub_id
									WHERE kol_publications.kol_id=".$kolId." AND kol_publications.is_deleted=0 AND YEAR(publications.created_date)!=0
		                            $where");
		//pr($this->db->last_query());exit;
		foreach($arrResults->result_array() as $row){
			$arrYears['min_year']=$row['min_year'];
			$arrYears['max_year']=$row['max_year'];
		}
		return $arrYears;
	}

	/**
	 * Retrives the Publication details foe give set of ids
	 * @author 	Ramesh B
	 * @Created on: 23-02-11
	 * @since	1.5
	 * @return Array
	 */
	function getPubsIdsDetails($arrPubIds,$kolId){
		$arrPublicationsDetail=array();
		$pubIds="";
		foreach($arrPubIds as $pubId)
			$pubIds.=$pubId.",";
		$pubIds=substr($pubIds,0,-1);
		$arrPublications=$this->db->query("SELECT publications.*,pubmed_journals.name AS journal_name,kol_publications.auth_pos 
											FROM publications
											LEFT JOIN pubmed_journals ON publications.journal_id=pubmed_journals.id
											LEFT JOIN kol_publications on publications.id=kol_publications.pub_id
											WHERE publications.id IN($pubIds) and kol_publications.kol_id=$kolId order by created_date  desc");
	
		foreach($arrPublications->result_array() as $row){
			$row['authcount'] = $this->pubmed->getNumberOfAuthors($row['id']);
			if(isset($row['pmid']) && $row['pmid'] > 0){
			    $row['linkForArticle'] = 'pmid';
			}else{
			    $row['linkForArticle'] = 'link';
			}
			$arrPublicationsDetail[]=$row;
		}
		//pr($arrPublicationsDetail);exit;
		return $arrPublicationsDetail;
	}
	
	/**
	 * Retrives the all the Publications Or Count of Publications which matches the given parameters, for each parameter it does AND operation, 
	 * if the parameter is an 'Array' it does or with in that 
	 * @author 	Ramesh B
	 * @Created on: 10-03-11
	 * @since	1.5.1
	 * @return Array
	 */
	function getPublicationsByParam($fromYear, $toYear,$arrKolIds=0,$arrCountries=0,$arrSpecialties=0,$groupBy=0,$arrListNamesIds=0,$arrStates=0,$limit = 0,$arrProfileType='',$viewType, $arrGlobalRegionIds = 0, $analystSelectedClientId = 0){
		$arrPublications=array();
		$isKolsJoined=false;
		$isPubsJoined=false;
		//Adding where condition for KOL Id's if Exist
		if(is_array($arrKolIds) && sizeof($arrKolIds)>0){
			$this->db->where_in('kol_publications.kol_id',$arrKolIds);
		}else if($arrKolIds!=0){
			$this->db->where('kol_publications.kol_id',$arrKolIds);
		}

		//Adding where condition for Gobal Region's if Exist
		if (is_array($arrGlobalRegionIds)) {	
			$this->db->join('kols','kols.id=kol_publications.kol_id','left');
			$isKolsJoined = true;
			$this->db->join('countries','kols.country_id=countries.countryId','left');
			$this->db->where_in('countries.GlobalRegion', $arrGlobalRegionIds);
		} else if ($arrGlobalRegionIds != 0) {
			$this->db->join('kols','kols.id=kol_publications.kol_id','left');
			$isKolsJoined = true;
			$this->db->join('countries','kols.country_id=countries.countryId','left');
			$this->db->where('countries.GlobalRegion', $arrGlobalRegionIds);
		}
		
		//Adding where condition for Country's if Exist
		if(is_array($arrCountries)){
			if(!$isKolsJoined)
			$this->db->join('kols','kols.id=kol_publications.kol_id','left');
			$isKolsJoined=true;
			$this->db->where_in('kols.country_id',$arrCountries);
		}else if($arrCountries!=0){
			if(!$isKolsJoined)
			$this->db->join('kols','kols.id=kol_publications.kol_id','left');
			$isKolsJoined=true;
			$this->db->where('kols.country_id',$arrCountries);
		}
		if(is_array($arrStates)){
			if(!$isKolsJoined)
				$this->db->join('kols','kols.id=kol_publications.kol_id','left');
			$isKolsJoined=true;
			$this->db->where_in('kols.state_id',$arrStates);
		}else if($arrStates!=0){
			if(!$isKolsJoined)
				$this->db->join('kols','kols.id=kol_publications.kol_id','left');
			$isKolsJoined=true;
			$this->db->where('kols.state_id',$arrStates);
		}
		
		//Adding where condition for Speciality's if Exist
		if(is_array($arrSpecialties)){
			if(!$isKolsJoined)
				$this->db->join('kols','kols.id=kol_publications.kol_id','left');
			$isKolsJoined=true;
			$this->db->where_in('kols.specialty',$arrSpecialties);
		}else if($arrSpecialties!=0){
			if(!$isKolsJoined)
				$this->db->join('kols','kols.id=kol_publications.kol_id','left');
			$isKolsJoined=true;
			$this->db->where('kols.specialty',$arrSpecialties);
		}
		
		
		if(!$isPubsJoined)
			$this->db->join('publications','publications.id=kol_publications.pub_id','left');
		$isPubsJoined=true;
		if($fromYear!=0 && $toYear!=0){
			$wherBetween="(YEAR(publications.created_date) BETWEEN '$fromYear' AND '$toYear' OR YEAR(publications.created_date)='0')";
			$this->db->where($wherBetween);
		}
		
		//Adding Group by based param $groupBy
		if((string)$groupBy=="year"){
			//$this->db->select('YEAR(publications.created_date) AS year, COUNT(YEAR(publications.created_date)) AS count');
			$this->db->select('YEAR(publications.created_date) AS year, COUNT(distinct kol_publications.pub_id) AS count');
			$this->db->where('YEAR(publications.created_date)>','0',false);
			$this->db->group_by('YEAR(publications.created_date)');
			$this->db->order_by('year DESC');
			//echo $groupBy;
			
			//Over all reports pubs by year chart count variation fix
			/*$arrPublications = $this->db->QUERY('SELECT YEAR(un_pubs.created_date) AS YEAR, COUNT(YEAR(un_pubs.created_date)) AS COUNT
											FROM ('.$this->db->last_query().') un_pubs 
											GROUP BY YEAR(un_pubs.created_date)
											ORDER BY year DESC');*/
			
		}else if((string)$groupBy=='kolId'){
			if(!$isKolsJoined)
				$this->db->join('kols','kols.id=kol_publications.kol_id','left');
			$isKolsJoined=true;
			$this->db->select('kols.id as kol_id,kols.salutation,kols.last_name,kols.middle_name,kols.first_name, COUNT(kol_publications.kol_id) AS count');
			//$this->db->where('kols.status',COMPLETED);
			$this->db->group_by('kol_publications.kol_id');
			$this->db->order_by('count DESC');
			//echo $groupBy;
		}else if((string)$groupBy=='keyword'){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = kol_publications.pub_id');
			$this->db->join('pubmed_mesh_terms', 'pubmed_mesh_terms.id = publication_mesh_terms.term_id');
			$this->db->select('pubmed_mesh_terms.id, pubmed_mesh_terms.term_name AS mesh_term, pubmed_mesh_terms.parent_id AS parent_id, COUNT(distinct kol_publications.pub_id) AS count');
			//$this->db->where('publication_mesh_terms.is_major','1');
			//$this->db->where('pubmed_mesh_terms.id >','0');
			//$this->db->group_by('pubmed_mesh_terms.id');
			$this->db->group_by('pubmed_mesh_terms.term_name,pubmed_mesh_terms.parent_id');
			$this->db->order_by('count DESC');
			//echo $groupBy;
		}else if((string)$groupBy=='substance'){
			$this->db->join('publication_substances', 'publication_substances.pub_id = kol_publications.pub_id');
			$this->db->join('pubmed_substances', 'pubmed_substances.id = publication_substances.substance_id');
			$this->db->select('pubmed_substances.id, pubmed_substances.name AS name, COUNT(distinct kol_publications.pub_id) AS count');
			$this->db->group_by('pubmed_substances.id');
			$this->db->order_by('count DESC');
			//echo $groupBy;

		}else if((string)$groupBy=='journal'){
			if(!$isPubsJoined)
				$this->db->join('publications', 'publications.id = kol_publications.pub_id');
			$this->db->join('pubmed_journals', 'pubmed_journals.id = publications.journal_id');
			$this->db->select('pubmed_journals.id, pubmed_journals.name AS name, COUNT(distinct kol_publications.pub_id) AS count');
			$this->db->group_by('pubmed_journals.id');
			$this->db->order_by('count DESC');
			//echo $groupBy;
		}else if((string)$groupBy=='type'){
			
			$this->db->join('publications_types', 'publications_types.pub_id=kol_publications.pub_id');
			$this->db->join('pubmed_publications_types', 'pubmed_publications_types.id=publications_types.pub_type_id');
			$this->db->select('pubmed_publications_types.id,pubmed_publications_types.type AS name, COUNT(distinct kol_publications.pub_id) AS count');
			$this->db->group_by('`publications_types.pub_type_id');
			$this->db->order_by('count DESC');
			//echo $groupBy;
		}else{
			if(!$isPubsJoined)
				$this->db->join('publications','publications.id=kol_publications.pub_id','left');
			$isPubsJoined=true;
			$this->db->select('publications.*');
			//echo 'No Grouping';
		}
		if($isKolsJoined){
	 		//$this->db->where('kols.status',COMPLETED);
	 	}else{
 			$this->db->join('kols','kols.id=kol_publications.kol_id','left');
 			//$this->db->where('kols.status',COMPLETED);
	 	}
		if($arrListNamesIds!='' && $arrListNamesIds!=0){
	 		$userId   =$this->session->userdata('user_id');
	 		$clientId =$this->session->userdata('client_id');
	 		$this->db->join('list_kols','list_kols.kol_id=kol_publications.kol_id','left');
	 		$this->db->join('list_names','list_kols.list_name_id=list_names.id','left');
	 		$this->db->join('list_categories','list_names.category_id=list_categories.id','left');
	 		$this->db->where_in('list_names.id',$arrListNamesIds);
	 		$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
	 	}
	 	if ($arrProfileType != ''){
	 	    if($arrProfileType == DISCOVERY){
	 	        $this->db->where('(kols.imported_as = 2 or kols.imported_as = 3)', null, false);
	 	    }else{
	 	        $this->db->where('kols.profile_type', $arrProfileType);
	 	        $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
	 	    }
	 	    //             $this->db->where('kols.profile_type', $arrProfileType);
	 	}else{
	 	    $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
	 	}
	 	$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		if(isset($viewType) && sizeof($viewType) > 0){
			$this->db->where_in('kols.id',$viewType);
		}
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		if($limit != 0)
			$this->db->limit($limit);
		
		if($analystSelectedClientId != null || $analystSelectedClientId > 0){
        		$client_id = $analystSelectedClientId;
        	}else{
        		$client_id = $this->session->userdata('client_id');
        }
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
				
		$arrPublicationsResults=$this->db->get('kol_publications');
		if($arrPublicationsResults !== FALSE && $arrPublicationsResults->num_rows() > 0){
		    foreach($arrPublicationsResults->result_array() as $row){
		        $arrPublications[]=$row;
		    }
		}
		//pr($this->db->last_query());exit;
		return $arrPublications;
	}

	/**
	 * Sets publication as verified by setting the 'is_verified' to 1
	 * @param $kolPublication
	 * @return unknown_type
	 * @author Vinayak
	 */
	function updatePublicationAsVerified($id,$kolPublication){	
		$this->db->where('id', $id);
		if($this->db->update('kol_publications', $kolPublication)){
			return true;
		} else {
			return false;
		}
	}	
	
	/**
	 * returns the list of co-authors belongs to kol
	 * @author 	Ramesh B
	 * @since	2.0
	 * @return unknown_type
	 * @created 06-04-11
	 */
	function getKolCoAuthors($kolId,$arrKolName){
		$arrCoAuthos=array();
		$lastName   = $arrKolName['last_name'];
		$middleName = $arrKolName['middle_name'];
		//If Fore name contains only first name
		$foreName = $arrKolName['first_name'];
		
		$firstCharOfFMname = substr($foreName,0,1).' '.substr($middleName,0,1);
		
		$FnameMnameOfFchar = $foreName.' '.substr($arrKolName['middle_name'],0,1);
		
		//If Fore name contains first name & middle name
		$foreNameFM = $arrKolName['first_name'].' '.$arrKolName['middle_name'];;
		
		//If Fore name contains first name of First Char
		$foreNameFirstChar = substr($arrKolName['first_name'],0,1);
		
		//If Fore name contains Middle name of First Char
		$foreNameMiddleNameFirstChar = substr($arrKolName['middle_name'],0,1);
		
		//If Fore name contains first name of First Char  & middle name
		$foreNameFirstCharM = substr($arrKolName['first_name'],0,1).' '.$arrKolName['middle_name'];
		
		
		$this->db->select('pubmed_authors.id,pubmed_authors.last_name,pubmed_authors.initials,pubmed_authors.fore_name');
		$this->db->join('publications_authors','pubmed_authors.id=publications_authors.author_id','left');
		$this->db->join('publications','publications_authors.pub_id=publications.id','left');
		$this->db->join('kol_publications','publications.id=kol_publications.pub_id','left');
		$this->db->where('kol_publications.kol_id',$kolId);
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		$where="!((last_name='$lastName' and fore_name='$foreName') OR (last_name='$lastName' and fore_name='$foreNameFM') OR (last_name='$lastName' and fore_name='$foreNameFirstCharM') OR (last_name='$lastName' and fore_name='$foreNameFirstChar') OR (last_name='$lastName' and fore_name='$middleName') OR (last_name='$lastName' and fore_name='$foreNameMiddleNameFirstChar') OR(last_name='$lastName' and fore_name='$firstCharOfFMname')OR(last_name='$lastName' and fore_name='$FnameMnameOfFchar'))";
		//This code is commented in order to allow the KOL name combinations also in name disambiguation
		//$where="!(last_name='' and fore_name='Christopher P')";
		//$this->db->where($where);
		$where2="!((last_name='Not Available' ) and (fore_name='Not Available'))";
		$this->db->where($where2);
		$this->db->group_by('pubmed_authors.last_name,pubmed_authors.initials,pubmed_authors.fore_name');
		$this->db->order_by('pubmed_authors.last_name,pubmed_authors.fore_name');
		
		$arrCOAuth = $this->db->get('pubmed_authors');
		foreach($arrCOAuth->result_array() as $row){
			   	$arrCoAuthos[$row['id']]=$row;
		}	
		//echo $this->db->last_query();
		return $arrCoAuthos;
	}
	
	/**
	 * returns the list of co-authors which having alias belongs to kol
	 * @author 	Ramesh B
	 * @since	2.0
	 * @return unknown_type
	 * @created 06-04-11
	 */
	function getKolProcessedCoAuthors($kolId){
		$arrProceCoAuths=array();
		$this->db->select('pubmed_authors.*');
		$this->db->join('publications_authors','pubmed_authors.id=publications_authors.author_id','left');
		$this->db->join('publications','publications_authors.pub_id=publications.id','left');
		$this->db->join('kol_publications','publications.id=kol_publications.pub_id','left');
		$this->db->where('kol_publications.kol_id',$kolId);
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		//$where="!((last_name='$lastName' and fore_name='$foreName') OR (last_name='$lastName' and fore_name='$foreNameFM') OR (last_name='$lastName' and fore_name='$foreNameFirstCharM') OR (last_name='$lastName' and fore_name='$foreNameFirstChar') OR (last_name='$lastName' and fore_name='$middleName') OR (last_name='$lastName' and fore_name='$foreNameMiddleNameFirstChar') OR(last_name='$lastName' and fore_name='$firstCharOfFMname')OR(last_name='$lastName' and fore_name='$FnameMnameOfFchar'))";
		//$where="!(last_name='' and fore_name='Christopher P')";
		//$this->db->where($where);
		$this->db->group_by('pubmed_authors.last_name,pubmed_authors.initials,pubmed_authors.fore_name');
		$this->db->order_by('pubmed_authors.last_name,pubmed_authors.fore_name');
		$this->db->where('pubmed_authors.alias_id IS NOT NULL');
		
		$arrCOAuth = $this->db->get('pubmed_authors');
		foreach($arrCOAuth->result_array() as $row){
			   	$arrProceCoAuths[$row['id']]=$row;
		}	
		return $arrProceCoAuths;
	}
	
	/**
	 * returns all the Co-Authors id's matching the given Author id's first name and fore name
	 * Get the name details of all the co authoer id in the '$arrCoAuthIds', and get the all the co-authors having the same name details for given given kolId
	 * @author 	Ramesh B
	 * @since	2.0
	 * @return Array
	 * @created 07-04-11
	 */
	function getMatchingCoAuthors($arrCoAuthIds,$kolId){
		//Get the name details of all the co authoer id in the '$arrCoAuthIds', and get the all the co-authors having the same name details for given given kolId
		$arrCoAuthos=array();
		$coAuthIds=$this->common_helpers->convertArrayToCommaSeparatedElements($arrCoAuthIds);
		
		$this->db->select('pubmed_authors.id,pubmed_authors.last_name,pubmed_authors.initials,pubmed_authors.fore_name');
		$this->db->join('publications_authors','pubmed_authors.id=publications_authors.author_id','left');
		$this->db->join('publications','publications_authors.pub_id=publications.id','left');
		$this->db->join('kol_publications','publications.id=kol_publications.pub_id','left');
		$this->db->where('kol_publications.kol_id',$kolId);
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		//	$where="((pubmed_authors.last_name,pubmed_authors.fore_name) IN (SELECT last_name,fore_name FROM pubmed_authors WHERE id IN ($coAuthIds))";
	//	$where="((pubmed_authors.last_name,pubmed_authors.fore_name) IN (SELECT last_name,fore_name FROM pubmed_authors WHERE id IN ($coAuthIds) AND pubmed_authors.initials = '')";
		$where="(concat(pubmed_authors.last_name,pubmed_authors.fore_name,COALESCE(pubmed_authors.initials,'')) IN (SELECT concat(last_name,fore_name,COALESCE(initials,'')) FROM pubmed_authors WHERE id IN ($coAuthIds))";
		$where .=" OR (pubmed_authors.last_name,pubmed_authors.initials) IN (SELECT last_name,initials FROM pubmed_authors WHERE id IN ($coAuthIds) AND pubmed_authors.fore_name = '')";
		$where .=" OR (pubmed_authors.fore_name,pubmed_authors.initials) IN (SELECT fore_name,initials FROM pubmed_authors WHERE id IN ($coAuthIds) AND pubmed_authors.last_name = ''))";
		$this->db->where($where);
		$this->db->order_by('pubmed_authors.last_name,pubmed_authors.fore_name');
		$arrCOAuth = $this->db->get('pubmed_authors');
		foreach($arrCOAuth->result_array() as $row){
			   	$arrCoAuthos[$row['id']]=$row;
		}	
		return $arrCoAuthos;
	}
	
	/**
	 * returns all the Co-Authors id's which alias to one are the other co-Author
	 * @author 	Ramesh B
	 * @since	2.0
	 * @return Array
	 * @created 07-04-11
	 */
	function getAliasCoAuthors($kolId){
		$arrProceCoAuths=array();
		$this->db->select('ala.id,ala.last_name,ala.initials,ala.fore_name');
		$this->db->join('publications_authors','pubmed_authors.id=publications_authors.author_id','left');
		$this->db->join('publications','publications_authors.pub_id=publications.id','left');
		$this->db->join('kol_publications','publications.id=kol_publications.pub_id','left');
		$this->db->join('pubmed_authors as ala','pubmed_authors.alias_id=ala.id','left');
		$this->db->where('kol_publications.kol_id',$kolId);
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		$this->db->where('pubmed_authors.alias_id IS NOT NULL');
		$this->db->group_by('pubmed_authors.alias_id');
		$this->db->order_by('pubmed_authors.last_name,pubmed_authors.fore_name');
		$arrCOAuth = $this->db->get('pubmed_authors');
		foreach($arrCOAuth->result_array() as $row){
			   	$arrProceCoAuths[$row['id']]=$row;
		}
		//echo $this->db->last_query();
		return $arrProceCoAuths;
	}

	/**
	 * Returns the CoAuthor Details of given Id
	 * @author 	Ramesh B
	 * @since	2.0
	 * @return Array
	 * @created 07-04-11
	 */
	function getCoAuthorById($authorId){
		$coAuthorDetails=array();
		$this->db->where('id',$authorId);
		$result	=$this->db->get('pubmed_authors');
		foreach($result->result_array() as $row){
			$coAuthorDetails=$row;
		}
		return $coAuthorDetails;
	}
	
	/**
	 * Associates the given set of coAuthors with the given alias details
	 * @author 	Ramesh B
	 * @since	2.0
	 * @return Boolean
	 * @created 07-04-11
	 */
	function associateCoAuthors($matchingAuths,$aliasDeails){
	$isSavedToAuthTable=false;
		
		$this->db->where_in('id',$matchingAuths);
		if($this->db->update('pubmed_authors', $aliasDeails)){
			$isSavedToAuthTable=true;
		} else {
			$isSavedToAuthTable= false;
		}
		
		if($isSavedToAuthTable){
			$aliasId['alias_id']=$aliasDeails['alias_id'];
			$this->db->where_in('author_id',$matchingAuths);
			if($this->db->update('publications_authors', $aliasId)){
				return true;
			} else {
				return false;
			}
		}
		else {
			return false;
		}
		//echo $this->db->last_query();
	}
	
	function disassociateCoAuthors($matchingAuths,$aliasDeails){
		$isSavedToAuthTable=false;
		
		$this->db->where_in('id',$matchingAuths);
		if($this->db->update('pubmed_authors', $aliasDeails)){
			$isSavedToAuthTable=true;
		} else {
			$isSavedToAuthTable= false;
		}
		
		if($isSavedToAuthTable){
			$matchingAuthIds=$this->common_helpers->convertArrayToCommaSeparatedElements($matchingAuths);
			$arrResults=$this->db->query("UPDATE publications_authors SET alias_id=author_id WHERE author_id IN($matchingAuthIds)");
			//pr($arrResults);
			return true;
		}else {
			return false;
		}
	}
	
	
   	/**
	 * Updates the Manual Publication Detail Data 
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 * 
	 * @return true/false
	 */
	function updatePublicationManual($arrPublicationDetails){
		$this->db->where('id',$arrPublicationDetails['id']);
		if($this->db->update('publications',$arrPublicationDetails)){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * Returns the Manual Publication Details by ID
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 * 
	 * @param $id
	 * @return unknown_type
	 */
	function getPublicationManualById($id){
		
		$arrPublications=array();
		$this->db->where('id',$id);
		$publicationsRusult = $this->db->get('publications');
		foreach($publicationsRusult->result_array() as $row){
			$row['created_date']= $this->kol->convertDateToMM_DD_YYYY($row['created_date']);
		 	if($row['created_date']=='00/00/0000'){
		 		$row['created_date']='';
		 	}
			$arrPublications[] = $row;
		}
		return $arrPublications;
	}
	
	/**
	 * Generates 'pmid' automaticaly Based on min value
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 * 
	 * @return unknown_type
	 */
	function getManualPmid(){
		$pmid='';
		$this->db->select('min(pmid) as pmid');
		$returndPmid=$this->db->get('publications');
		if($returndPmid->num_rows() == 0){
			$pmid = -1;
		}else{
			foreach($returndPmid->result_array() as $arrRow){
				 if($arrRow['pmid'] <= 0){
				 	$pmid = $arrRow['pmid']-1;
				 }else
					 $pmid = -1;
			}
		}
		return $pmid;
	}
	
   	/**
	 * Updates the Manual Publication journal Data 
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 * 
	 * @return true/false
	 */
	function updatePublicationJournalManual($arrPublicationDetails){
		if($this->db->query("update pubmed_journals 
							LEFT JOIN publications ON pubmed_journals.id=publications.journal_id
							set pubmed_journals.name='".$arrPublicationDetails['journal_name']."'
							WHERE publications.id=".$arrPublicationDetails['id'])){
			return true;
		}else{
			return false;
		}
	}
	
	
	 /**
	 * Updates the Manual Publication Particular Author Data 
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 * 
	 * @return true/false
	 */
	function updatePublicationAuthorsManual($arrPublicationDetails){
		if($this->db->query("update publications 
								LEFT JOIN publications_authors ON publications.id=publications_authors.pub_id
								LEFT JOIN pubmed_authors ON publications_authors.author_id=pubmed_authors.id
								set pubmed_authors.last_name='".$arrPublicationDetails['last_name']."', pubmed_authors.fore_name='".$arrPublicationDetails['fore_name']."',pubmed_authors.initials='".$arrPublicationDetails['initials']."'
								WHERE publications.id=".$arrPublicationDetails['id']." and pubmed_authors.id=".$arrPublicationDetails['authId'])){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * @author Ambarish
	 * @since 2.5
	 * @Created-on 29-06-11
	 * Saves the manual Publication and returns the id of it. setting the Cliend id is logged client id. and  is_verified=1
	 * @param Array $pubDetails
	 * @param Integer $kolId
	 * @return Integer $pubId
	 */
	function savePublicationsManualAndFlags($pubDetails, $kolId){
	    $kolPublication=array();
	    $kolPublication['data_type_indicator'] = $pubDetails['data_type_indicator'];
	    unset($pubDetails['data_type_indicator']);
		//save the publication and get the publication id
		$pubId=$this->savePublication($pubDetails);
		//echo 'Publication with PMID:'.$pubDetails['pmid'].' Not exist and it is Saved and Associated to KolId :'.$kolId.'</br>';		
		//prepare the kol-to-publication association object		
		$kolPublication['kol_id']=$kolId;
		$kolPublication['pub_id']=$pubId;
		$kolPublication['is_deleted']=0;
		$client_id = $this->session->userdata('client_id');	
		$userId = $this->session->userdata('user_id');	
		//For manual saving Cliend id is logged client id and its verified
		if(isset($client_id)){
			$kolPublication['client_id']   = $client_id;
			$kolPublication['is_verified'] = 1;
			$kolPublication['user_id']     = $userId;
		}else{
			$kolPublication['client_id'] = INTERNAL_CLIENT_ID;
		}						
		//save the kol-to-publication record
		$isSaved=$this->saveKolPublication($kolPublication);
		//return the publication Id	
		return $pubId;
	}
	
	/**
	 * returns different combinations on names 
	 * @param $firsName
	 * @param $midleName
	 * @param $lastName
	 * @return Array,   Example Array('0'=>'JV  Heymach','1'=>'Heymach  J');
	 */
	function generate_name_combinations($firsName, $midleName, $lastName){
	
		$firstName = $firsName;
		$middleName = $midleName;
		$lastName = $lastName;
		
		$firstNameInitial = substr($firstName, 0, 1);		
		$middleNameInitial = substr($middleName, 0, 1);
		$middleNameLength = strlen($middleName);		
		
		$lastNameInitial = substr($lastName, 0, 1);
		
		$arrName= array();
			if($firstName!="" && $middleName=="" && $lastName!=""){
				//echo "<h3>Case : 1 </h3>";
				 $arrName[] = $firstName." ".$lastName;
				 $arrName[] = $lastName." ".$firstName;
				 $arrName[] = $lastName." ".$firstNameInitial;
			     $arrName[] = $firstNameInitial." ".$lastName;
				 
			}
			if($firstName!="" && $middleNameLength==1 && $lastName!=""){
				//echo "<h3>Case : 2 </h3>";
				 $arrName[] = $lastName." ".$firstName;
				 $arrName[] = $lastName." ".$middleNameInitial." ".$firstName;
				 $arrName[] = $lastName." ".$firstName." ".$middleNameInitial;
				 $arrName[] = $lastName." ".$firstNameInitial." ".$middleNameInitial;
				 //Added when finding the kol from the co authors
				 $arrName[] = $lastName." ".$firstNameInitial."".$middleNameInitial;
				 $arrName[] = $firstName." ".$lastName;
				 $arrName[] = $firstName." ".$middleNameInitial." ".$lastName;
				 $arrName[] = $firstName." ".$lastName." ".$middleNameInitial;
				 $arrName[] = $firstNameInitial." ".$middleNameInitial." ".$lastName;
				 $arrName[] = $lastName." ".$firstNameInitial." ".$middleNameInitial;
				 $arrName[] = $lastName." ".$firstNameInitial;
				 $arrName[] = $firstNameInitial." ".$lastName;
			}
			
			if($firstName!="" && $middleNameLength!=1 &&$middleName!="" && $lastName!=""){
				//echo "<h3>Case : 3 </h3>";
				$arrName[] = $lastName." ".$firstName;
				$arrName[] = $lastName." ".$firstName." ".$middleName;
				$arrName[] = $lastName." ".$middleNameInitial." ".$firstName;
				$arrName[] = $lastName." ".$middleName." ".$firstName;
				$arrName[] = $lastName." ".$firstName." ".$middleNameInitial;
				$arrName[] = $lastName." ".$firstNameInitial." ".$middleNameInitial;
				//Added when finding the kol from the co authors
				$arrName[] = $lastName." ".$firstNameInitial."".$middleNameInitial;
				$arrName[] = $firstName." ".$middleName." ".$lastName;
				$arrName[] = $firstName." ".$lastName;
				$arrName[] = $firstName." ".$middleNameInitial." ".$lastName;
				$arrName[] = $firstName." ".$lastName." ".$middleName;
				
				$arrName[] = $firstName." ".$middleNameInitial." ".$lastName;
				$arrName[] = $firstName." ".$lastName." ".$middleNameInitial;
				$arrName[] = $firstNameInitial." ".$middleNameInitial." ".$lastName;
				$arrName[] = $lastName." ".$firstNameInitial." ".$middleNameInitial;
				$arrName[] = $lastName." ".$firstNameInitial;
			    $arrName[] = $firstNameInitial." ".$lastName;
			}	
			
		return $arrName;	
	}

	function calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail){
		$position='';
		if($arrKolDetail==null)
			$arrKolDetail=$this->getKolDetail($kolId);
		// get the name details			
		$firstName=$arrKolDetail['first_name'];
		$midleName=$arrKolDetail['middle_name'];
		$lastName=$arrKolDetail['last_name'];
		$kolId=$arrKolDetail['id'];
		
		//get the different combinations of names
		$arrNameCombinations=$this->generate_name_combinations($firstName, $midleName, $lastName);
		foreach($arrNameCombinations as $nameCombination){
			$arrName=explode(" ", $nameCombination);
			if(sizeof($arrName)==2){					
				$arrPos[]=$this->getAuthorshipPos($pubId,$arrName[0],$arrName[1]);
			}
			else{										
				$arrPos[]=$this->getAuthorshipPos($pubId,$arrName[0],$arrName[1]." ".$arrName[2]);
				$arrPos[]=$this->getAuthorshipPos($pubId,$arrName[0],$arrName[1]."".$arrName[2]);
			}				
		}
		$position;
// 		pr($arrPos);
		foreach($arrPos as $pos){
			if($pos!='')
				$position=$pos;
		}
		// save the authorsip position in the kol_publications table, later remove this from this function				
		//$this->updateAuthorshipPos($kolId,$pubId,$position);
		//echo $position;
		return $position;
	}
		
	/**
	 * Check whether the Publication with PMID exist or not if exist it removes it from array and 
	 * get's the publication Id of theat and associates it with kol
	 * @param $arrUniquePMIDs
	 * @param $kolId
	 * @return unknown_type
	 * added new parameter $isVerfied so that while crawling it should be unverified and if pubs are imported then we can set it to verified
	 */
	function checkAndAssociateAlreadyExistPubs($arrUniquePMIDs, $kolId, $arrKolDetail,$isVerfied=0){
			$arrCount=sizeof($arrUniquePMIDs);
			//Optimized code
			/*$arrExsitingPmids = array();
			$arrPmidsAndPubIds = array();
			//get all the publications with pmid
			$result = $this->db->query("SELECT id, pmid FROM publications WHERE pmid IN (".implode(',',$arrUniquePMIDs).")");
			if($result->result_array() != null){
				foreach($result->result_array() as $row){
					$arrPmidsAndPubIds[$row['id']] = $row['pmid'];
				}
			}
			foreach($arrPmidsAndPubIds as $pubId => $pmid){
				$kolPublication=array();
				$kolPublication['kol_id']		= $kolId;
				$kolPublication['pub_id']		= $pubId;				
				//Save the association only if it is not exist
				$kolPublication['is_verified']	= $isVerfied;
				$kolPublication['is_deleted']	= 0;
				if(!$this->checkKolPubAssociationExist($kolPublication)){
					$isSaved=$this->saveKolPublication($kolPublication);
				}else if($isVerfied){
					$isSaved=$this->updateKolPublication($kolPublication);
				}
				//Calculate Authorship position and save
				$position=$this->calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail);
				$this->updateAuthorshipPos($kolId,$pubId,$position);
			}
			$arrExsitingPmids = array_values($arrPmidsAndPubIds);
			$arrRemainingPmids = array_diff($arrExsitingPmids, $arrUniquePMIDs);*/
			
			for($i=0;$i<$arrCount; $i++){
				$pmid=$arrUniquePMIDs[$i];
				$pubId=$this->checkPubExist($pmid);
				if($pubId!=''){
					//echo 'Publication with PMID:'.$pmid.' already exist and it is Associated to KolId :'.$kolId.'</br>';
					$kolPublication=array();
					$kolPublication['kol_id']		= $kolId;
					$kolPublication['pub_id']		= $pubId;				
					//Save the association only if it is not exist
					$kolPublication['is_verified']	= $isVerfied;
					$kolPublication['is_deleted']	= 0;
					if(!$this->checkKolPubAssociationExist($kolPublication)){
						$isSaved=$this->saveKolPublication($kolPublication);
					}else if($isVerfied){
						$isSaved=$this->updateKolPublication($kolPublication);
					}
					unset($arrUniquePMIDs[$i]);
					
					//Calculate Authorship position and save
					$position=$this->calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail);
					$this->updateAuthorshipPos($kolId,$pubId,$position);
					//echo "already exists PMID-".$pmid." Pub ID-".$pubId." Position-".$position;
				}
			}
			$arrUniquePMIDs=array_values($arrUniquePMIDs);
			//pr($arrUniquePMIDs);
			return $arrUniquePMIDs;
	}
	
	/**
	 * Returns the Co-Authored Kols and count with respect to given kol
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 11-07-11
	 */	
	function getCoAuthoredKols($arrKolIds=null){
		//Old Querry
		$arrKols=array();
		$this->db->select("pub2.kol_id, COUNT(pub2.kol_id) as count");
		$this->db->join('kol_publications as pub2','kol_publications.pub_id=pub2.pub_id','left');
		$this->db->join('kols','pub2.kol_id = kols.id','left');
		//$where="kol_publications.kol_id='$arrKolIds' AND pub2.kol_id!='$arrKolIds'";
		//$this->db->where($where);
		$this->db->where('kol_publications.kol_id',$arrKolIds);
		$this->db->where('pub2.kol_id !=',$arrKolIds);
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		$this->db->where('pub2.is_deleted',0);
		$this->db->where('pub2.is_verified',1);
// 		$this->db->where('kols.status',COMPLETED);
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
		    $this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
		    $this->db->where('kols_client_visibility.client_id', $client_id);
		}		
		$this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
		$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		$this->db->group_by('pub2.kol_id');
		$results=$this->db->get('kol_publications');
		//echo $this->db->last_query();
		foreach($results->result_array() as $row){
			$arrKols[]=$row;
		}
		return $arrKols;
				
		/*$arrKols=array();
		$this->db->select("kol_publications.kol_id as parent_kol,pub2.kol_id, COUNT(pub2.kol_id) as count");
		$this->db->join('kol_publications as pub2','kol_publications.pub_id=pub2.pub_id','left');
		$this->db->where('kol_publications.kol_id != pub2.kol_id');
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		if($arrKolIds != null)	
			$this->db->where_in('kol_publications.kol_id',$arrKolIds);	
		$this->db->group_by('kol_publications.kol_id,pub2.kol_id');
		$results=$this->db->get('kol_publications');
		foreach($results->result_array() as $row){
			$arrKols[$row['parent_kol']][]=$row;
		}
		//echo $this->db->last_query();
		return $arrKols;*/
	}
	
	/**
	 * Returns the Co-Authored co-authors and count with respect to given co-author of a kol
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 11-07-11
	 */	
	function getCoAuthoredCoAuthors($kolId,$koAuthDetails){
		$arrCoAutherInfluence=array();
		$this->db->select('pmda2.id,pmda2.last_name,pmda2.initials,pmda2.fore_name,COUNT(pa2.author_id) as count');
		$this->db->join('publications_authors AS pa2','pa1.pub_id = pa2.pub_id','left');
		$this->db->join('publications','pa1.pub_id=publications.id ','left');
		$this->db->join('kol_publications','publications.id=kol_publications.pub_id','left');
		$this->db->join('pubmed_authors AS pmda1','pa1.alias_id=pmda1.id','left');
		$this->db->join('pubmed_authors AS pmda2','pa2.alias_id=pmda2.id','left');
		$this->db->where('kol_publications.kol_id',$kolId);
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		//$where="(pmda1.last_name='".$koAuthDetails['last_name']."' AND pmda1.initials='".$koAuthDetails['initials']."' AND pmda1.fore_name='".$koAuthDetails['fore_name']."') AND !(pmda2.last_name='".$koAuthDetails['last_name']."' AND pmda2.initials='".$koAuthDetails['initials']."' AND pmda2.fore_name='".$koAuthDetails['fore_name']."')";
		//$this->db->where($where);
		/*$this->db->where('pmda1.last_name',$koAuthDetails['last_name']);
		$this->db->where('pmda1.initials',$koAuthDetails['initials']);
		$this->db->where('pmda1.fore_name',$koAuthDetails['fore_name']);
		$this->db->where('pmda2.last_name !=',$koAuthDetails['last_name']);
		$this->db->where('pmda2.initials !=',$koAuthDetails['initials']);
		$this->db->where('pmda2.fore_name !=',$koAuthDetails['fore_name']);*/
		$this->db->where('pmda1.id',$koAuthDetails['id']);
		$this->db->where('pmda2.id !=',$koAuthDetails['id']);
		$this->db->group_by('pmda2.last_name,pmda2.initials,pmda2.fore_name');
		
		$results=$this->db->get('publications_authors as pa1');
		foreach($results->result_array() as $row){
			$arrCoAutherInfluence[$row['id']]=$row;
		}
		return $arrCoAutherInfluence;
	}

	/**
	 * Deletes the Associated publications and the related data of a given kol
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 11-07-11
	 */	
	function deleteKolPublications($kolId){
		//Select publication id's
		$arrPubIds=array();
		$this->db->select('pub_id');
		$this->db->where('kol_id',$kolId);
		$results=$this->db->get('kol_publications');
		foreach($results->result_array() as $row){
			$arrPubIds[]=$row['pub_id'];
		}
		if(sizeof($arrPubIds)>0){
			// Authors----------------------------
			//Select authors_id's
			$arrAuthIds=array();
			$this->db->select('author_id');
			$this->db->where_in('pub_id',$arrPubIds);
			$results=$this->db->get('publications_authors');
			foreach($results->result_array() as $row){
				$arrAuthIds[]=$row['author_id'];
			}
			//Delete publications authors
			$this->db->where_in('pub_id',$arrPubIds);
			$this->db->delete('publications_authors'); 
			
			//Delete pubmed authors
			if(sizeof($arrAuthIds)>0){
				$this->db->where_in('id',$arrAuthIds);
				$this->db->delete('pubmed_authors'); 
			}
			
			
			//Article Ids-----------------------------
			
			//Select article_id's
			$arrArticleIds=array();
			$this->db->select('pub_article_id');
			$this->db->where_in('pub_id',$arrPubIds);
			$results=$this->db->get('publication_article_ids');
			foreach($results->result_array() as $row){
				$arrArticleIds[]=$row['pub_article_id'];
			}
			//Delete publications Article Ids
			$this->db->where_in('pub_id',$arrPubIds);
			$this->db->delete('publication_article_ids'); 
			
			//Delete pubmed Article Ids
			if(sizeof($arrArticleIds)>0){
				$this->db->where_in('id',$arrArticleIds);
				$this->db->delete('pubmed_article_ids'); 
			}
			
			//History's -----------------------------
			
			//Delete publications History's 
			$this->db->where_in('pub_id',$arrPubIds);
			$this->db->delete('publication_history'); 
			
					
			//MeshTerms Ids-----------------------------
			
			//Select MeshTerms id's
			$arrMeshTermIds=array();
			$this->db->select('term_id');
			$this->db->where_in('pub_id',$arrPubIds);
			$results=$this->db->get('publication_mesh_terms');
			foreach($results->result_array() as $row){
				$arrMeshTermIds[]=$row['term_id'];
			}
			//Delete publications MeshTerms Ids
			$this->db->where_in('pub_id',$arrPubIds);
			$this->db->delete('publication_mesh_terms'); 
			
			//Delete pubmed MeshTerms Ids
			//$this->db->where_in('id',$arrMeshTermIds);
			//$this->db->delete('pubmed_mesh_terms'); 
			
							
			//Substance Ids-----------------------------
			
			//Select Substance id's
			$arrSubstanceIds=array();
			$this->db->select('substance_id');
			$this->db->where_in('pub_id',$arrPubIds);
			$results=$this->db->get('publication_substances');
			foreach($results->result_array() as $row){
				$arrSubstanceIds[]=$row['substance_id'];
			}
			//Delete publications Substance Ids
			$this->db->where_in('pub_id',$arrPubIds);
			$this->db->delete('publication_substances'); 
			
			//Delete pubmed Substance Ids
			//$this->db->where_in('id',$arrSubstanceIds);
			//$this->db->delete('pubmed_substances'); 
			
			
			//CC Ids-----------------------------
			
			//Select CC id's
			$arrCCIds=array();
			$this->db->select('cc_id');
			$this->db->where_in('pub_id',$arrPubIds);
			$results=$this->db->get('publications_cc');
			foreach($results->result_array() as $row){
				$arrCCIds[]=$row['cc_id'];
			}
			//Delete publications CC Ids
			$this->db->where_in('pub_id',$arrPubIds);
			$this->db->delete('publications_cc'); 
			
			//Delete pubmed CC Ids
			if(sizeof($arrCCIds)>0){
				$this->db->where_in('id',$arrCCIds);
				$this->db->delete('pubmed_cc'); 
			}
			
			//Publications types Ids-----------------------------
			
			//Select Publications types id's
			$arrPubTypeIds=array();
			$this->db->select('pub_type_id');
			$this->db->where_in('pub_id',$arrPubIds);
			$results=$this->db->get('publications_types');
			foreach($results->result_array() as $row){
				$arrPubTypeIds[]=$row['pub_type_id'];
			}
			//Delete publications types Ids
			$this->db->where_in('pub_id',$arrPubIds);
			$this->db->delete('publications_types'); 
			
			//Delete pubmed publications types Ids
			//$this->db->where_in('id',$arrPubTypeIds);
			//$this->db->delete('pubmed_publications_types'); 
			
			
			//Publications ---------------------------
			
			//Delete Publication Associations
			$this->db->where_in('pub_id',$arrPubIds);
			$this->db->delete('kol_publications'); 
			
			//Delete Publications 
			$this->db->where_in('id',$arrPubIds);
			$this->db->delete('publications'); 
		}
		
	}	
	/**
	 * Deletes the Association between Kol and Publication for the passed KOL id
	 * @author 	Ambarish N
	 * @since	2.6
	 * @return 
	 * @created July-19-2011
	 * 
	 * @param $kolId
	 * @return Boolean
	 */
	function deleteKolPublicationByKolId($kolId){
		$this->db->where('kol_id', $kolId);
		if($this->db->delete('kol_publications')){
			return true;
		}else{
			return false;
		} 
	}
	
	/* To get Major mesh term data
	 * @author 	Vinayak
	 * @since	3.1.1
	 * @created July-19-2011
	 * @param $kolId
	 * @return array - $arrMajorMeshterm
	 * 
	 */
	function getPubMajorMeshTermChartForPdf($kolId){
		$arrMajorMeshterm=array();
		$this->db->select('pubmed_mesh_terms.term_name as mesh_term,count(distinct kol_publications.pub_id) as count,pubmed_mesh_terms.parent_id');
		$this->db->join('publication_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
		$this->db->join('publications', 'publications.id = publication_mesh_terms.pub_id','left');
		$this->db->join('kol_publications', 'kol_publications.pub_id = publications.id','left');

		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		$this->db->where('kol_id',$kolId);
		$this->db->where('publication_mesh_terms.is_major','1');
	
		$this->db->group_by('pubmed_mesh_terms.term_name');
		$this->db->order_by('count','desc');
		$this->db->limit('20');
		$arrMajorMeshtermResult	=	$this->db->get('pubmed_mesh_terms');
		foreach($arrMajorMeshtermResult->result_array() as $row){
			$arrMajorMeshterm[]=$row;
		}
		//pr($arrMajorMeshterm);
		return $arrMajorMeshterm;
	}
	
	/* To get Minor mesh term data
	 * @author 	Vinayak
	 * @since	3.1.1
	 * @created July-19-2011
	 * @param $kolId
	 * @return array - $arrMajorMeshterm
	 * 
	 */
	function getPubMinorMeshTermChartForPdf($kolId){
		$arrMinorMeshterm=array();
		$this->db->select('pubmed_mesh_terms.term_name as mesh_term,count(distinct kol_publications.pub_id) as count');
		$this->db->join('publication_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
		$this->db->join('publications', 'publications.id = publication_mesh_terms.pub_id','left');
		$this->db->join('kol_publications', 'kol_publications.pub_id = publications.id','left');
		
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		$this->db->where('kol_id',$kolId);
		$this->db->where('publication_mesh_terms.is_major','0');
	
		$this->db->group_by('pubmed_mesh_terms.term_name');
		$this->db->order_by('count','desc');
		$this->db->limit('20');
		
		$arrMinorMeshtermResult	=	$this->db->get('pubmed_mesh_terms');
		foreach($arrMinorMeshtermResult->result_array() as $row){
			$arrMinorMeshterm[]=$row;
		}	
		//pr($arrMinorMeshterm);	
     	return $arrMinorMeshterm;
	}
	
	/**
	 * Returns the given KOL Publications with given limit range, if KOL id 
	 * is null or '0' then publications of all the kols are returnd with given limit range
	 * 
	 * @author Ramesh B
	 * @since 3.2
	 * @param $kolId
	 * @return Array
	 * @created 31-10-11 
	 */
	function listPublications($kolId,$limit,$startFrom){
		$arrPublications=array();
		$this->db->select('publications.id,publications.pmid,publications.article_title,publications.created_date,kol_publications.auth_pos,pubmed_journals.name as journal_name');
		$this->db->join('kol_publications', 'kol_publications.pub_id = publications.id','left');
		$this->db->join('pubmed_journals', 'publications.journal_id = pubmed_journals.id','left');
		if($kolId!=null && $kolId!=0)
			$this->db->where('kol_publications.kol_id', $kolId);
		$this->db->where('kol_publications.is_deleted', 0);
		$this->db->where('kol_publications.is_verified',1);
		
		$this->db->order_by('publications.created_date','desc');
		$this->db->limit($limit,$startFrom);
		
		$arrPublicationResult = $this->db->get('publications');
		foreach($arrPublicationResult->result_array() as $row){
			$arrPublications[]=$row;
		}	
		return 	$arrPublications;
	}
	
	function filterUnprocessedCoAuthors($arrUnProcessedCoAuths,$arrPossibleAliasCoAuthors=null){
		if($arrPossibleAliasCoAuthors == null)
			$arrPossibleAliasCoAuthors=$arrUnProcessedCoAuths;
		$arrFilteredCoAuthors=array();
		foreach($arrUnProcessedCoAuths as $key => $value){
			if ( !array_key_exists($key, $arrFilteredCoAuthors) ){
				foreach($arrPossibleAliasCoAuthors as $key1 => $value1){
					if($key1 != $key){
						if($value['last_name'] == $value1['last_name'] && $value['fore_name'] == $value1['fore_name']){
							$arrFilteredCoAuthors[$key]=$value;
							//$arrFilteredCoAuthors[$key1]=$value1;
						}else if($value['last_name'] == $value1['last_name'] && substr($value['fore_name'],0,1) == substr($value1['fore_name'],0,1) ){
							$arrFilteredCoAuthors[$key]=$value;
							//$arrFilteredCoAuthors[$key1]=$value1;
						}
					}
				}
			}
		}
		return $arrFilteredCoAuthors;
	}
	
	/**
	 * Returns the given KOL Publications
	 *
	 * 
	 * @author Vinayak 
	 * @since 3.2
	 * @param $substance,$author,$meshTermName,$keyword,$aritcleName,$kolId,$fromYear,$toYear
	 * @return Array
	 * @created 5-3-12
	 */
	function searchPublicationsByParameters($substance,$author,$meshTermName,$keyword,$aritcleName,$kolId,$fromYear,$toYear){
		$this->db->select('distinct(publications.id),publications.*,kol_publications.auth_pos,kol_publications.kol_id,pubmed_journals.name as journal_name,kol_publications.client_id,kol_publications.user_id,kol_publications.id as kol_pub_id,kol_publications.data_type_indicator,client_users.is_analyst,client_users.first_name,client_users.last_name');
		$this->db->join('publications','publications.id=kol_publications.pub_id','left');
		$this->db->join('pubmed_journals','publications.journal_id=pubmed_journals.id','left');
		$this->db->join('client_users','client_users.id = kol_publications.user_id','left');
		
//		if($substance!=''){
//			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
//			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id');
//			$this->db->like("pubmed_substances.name",$substance);
//		}
//		
//		if($author!=''){
//			$this->db->join('publications_authors', 'publications_authors.pub_id = publications.id','left');
//			$this->db->join('pubmed_authors', 'publications_authors.author_id = pubmed_authors.id','left');
//			//$this->db->like('pubmed_authors.last_name',$author);
//			//$this->db->or_like('pubmed_authors.fore_name',$author);
//			
//			$this->db->where("((pubmed_authors.last_name  LIKE '%$author%' OR  pubmed_authors.fore_name  LIKE '%$author%'))");
//		}
		
		if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		
//		if($meshTermName !=''){
//			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
//			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
//			$this->db->like('pubmed_mesh_terms.term_name',$meshTermName);
//		}
//		
//		if($aritcleName !=''){
//			$this->db->like('publications.article_title',$aritcleName);
//		}
	
		if($fromYear !='' && $toYear!=''){
			
			$this->db->where("(year(publications.created_date) >= '$fromYear' AND year(publications.created_date) <='$toYear')");
		}
		$this->db->where('kol_publications.is_verified',1);
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.kol_id',$kolId);
		$this->db->order_by("publications.created_date",'desc');
		$arrResultSet = $this->db->get('kol_publications');
		$arrPubliations =array();
//		echo $this->db->last_query();
		foreach($arrResultSet->result_array() as $row){
			$arrPubliations[]=$row;
		}
		return $arrPubliations;
	}
	
	/**
	 * Retrives the publication details for the given kol publication association id
	 * @author 	Ramesh B 
	 * @since	4.2
	 * @return Array
	 * @created 14-06-2012
	 */
	function getKolPublicationDetail($kolPubId){
		$publication=array();
		$this->db->select('publications.*');
		$this->db->where('kol_publications.id',$kolPubId);
		$this->db->join('publications', 'kol_publications.pub_id = publications.id','left');
		$publication=$this->db->get('kol_publications');
		$publication=$publication->row_array();
		return 	$publication;	
	}
	
	/**
	 * Chamges the kol pubmed processing status to given status
	 * @author 	Ramesh B 
	 * @since	4.2
	 * @return text
	 * @created 15-06-2012
	 */
	function changeKolPubmedStatus($kolId, $status){
		$arrKolDetails = array();
		$arrKolDetails['is_pubmed_processed'] = $status;
		$this->db->where('id',$kolId);
		if($this->db->update('kols',$arrKolDetails)){
			//Add Log activity
			$arrLogDetails = array(
					'type' => 'Update',
					'description' => 'Update PubmedStatus of the KTL',
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => $kolId,
					'transaction_id' => $kolId,
					'transaction_table_id' => KOLS,
					'transaction_name' => 'Update status',
					'parent_object_id' => $kolId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			//log_user_activity ( null, true );
			return true;
		}else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => 'Update',
					'description' => 'Update PubmedStatus of the KTL',
					'status' => STATUS_FAIL,
					'kols_or_org_type' => 'Kol',
					'kols_or_org_id' => $kolId,
					'transaction_id' => $kolId,
					'transaction_table_id' => KOLS,
					'transaction_name' => 'Update status',
					'parent_object_id' => $kolId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			//log_user_activity ( null, true );
			return false;
		}
	}
	
	/**
	 * Gets co authors having affiliation info for given kol id
	 * @author 	Ramesh B 
	 * @since	4.2
	 * @param kolid
	 * @return Array
	 * @created 12-07-2012
	 */
	function getKolCoAuthorsHavingAffiliation($kolId){
		$arrKolName=$this->getKolDetail($kolId);
		$lastName   = $arrKolName['last_name'];
		$middleName = $arrKolName['middle_name'];
		$foreName = $arrKolName['first_name'];
		
		$firstCharOfFMname = substr($foreName,0,1).' '.substr($middleName,0,1);

		$FnameMnameOfFchar = $foreName.' '.substr($arrKolName['middle_name'],0,1);

		//If Fore name contains first name & middle name
		$foreNameFM = $arrKolName['first_name'].' '.$arrKolName['middle_name'];;

		//If Fore name contains first name of First Char
		$foreNameFirstChar = substr($arrKolName['first_name'],0,1);

		//If Fore name contains Middle name of First Char
		$foreNameMiddleNameFirstChar = substr($arrKolName['middle_name'],0,1);

		//If Fore name contains first name of First Char  & middle name
		$foreNameFirstCharM = substr($arrKolName['first_name'],0,1).' '.$arrKolName['middle_name'];
		
		//get the different combinations of names
		$arrNameCombinations=$this->generate_name_combinations($foreName, $middleName, $lastName);
			
		$arrCoAuthors = array();
		
		$arrCoAuthors = array();
		$this->db->select('publications_authors.author_id as id, publications_authors.alias_id');
		$this->db->join('publications_authors', 'publications_authors.pub_id = kol_publications.pub_id','left');
		$this->db->join('pubmed_authors', 'pubmed_authors.id = publications_authors.alias_id','left');
		$this->db->join('publications', 'kol_publications.pub_id = publications.id','left');
		$this->db->where('kol_id',$kolId);
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified ',1);
		$this->db->where('auth_pos !=',1);
		$this->db->where('publications_authors.position',1);
		$this->db->where('publications.affiliation !=','NA');
		$where="!((last_name='Not Available' ) and (fore_name='Not Available'))";
		$where1="!((last_name=\"$lastName\" and fore_name=\"$foreName\") OR (last_name=\"$lastName\" and fore_name=\"$foreNameFM\") OR (last_name=\"$lastName\" and fore_name=\"$foreNameFirstCharM\") OR (last_name=\"$lastName\" and fore_name=\"$foreNameFirstChar\") OR (last_name=\"$lastName\" and fore_name=\"$middleName\") OR (last_name=\"$lastName\" and fore_name=\"$foreNameMiddleNameFirstChar\") OR(last_name=\"$lastName\" and fore_name=\"$firstCharOfFMname\")OR(last_name=\"$lastName\" and fore_name=\"$FnameMnameOfFchar\"))";
		$this->db->where($where);
		$this->db->where($where1);
		$this->db->group_by('pubmed_authors.last_name,pubmed_authors.initials,pubmed_authors.fore_name');
		
		$results	=	$this->db->get('kol_publications');
		if(is_object($results) && $results->num_rows() > 0){
			foreach($results->result_array() as $row){
				$arrCoAuthors[$row['id']]=$row['alias_id'];
			}
		}
		
		return $arrCoAuthors;
	}
	
	function getCoAuthorAffiliationData($kolId, $authorId){
		$affiliation = "";
		$affWithEmail = '';
		
		$arrCoAuthsIds = array($authorId);
		$matchingAuths=$this->getMatchingCoAuthorIds($arrCoAuthsIds,$kolId);
		$this->db->select('publications.affiliation,pubmed_authors.*');
		$this->db->join('publications_authors', 'pubmed_authors.id = publications_authors.author_id','left');
		$this->db->join('publications', 'publications_authors.pub_id = publications.id','left');
		$this->db->join('kol_publications', 'publications.id = kol_publications.pub_id','left');
		$this->db->where_in('pubmed_authors.id',$matchingAuths);
		$this->db->where('publications_authors.position',1);
		$this->db->where('publications.affiliation !=','NA');
		$results	=	$this->db->get('pubmed_authors');
		
		
		//Alternative Approach
		/*$this->db->select('publications.affiliation,pubmed_authors.*');
		$this->db->join('publications', 'publications_authors.pub_id = publications.id','left');
		$this->db->join('kol_publications', 'publications_authors.pub_id = kol_publications.pub_id','left');
		$this->db->join('pubmed_authors', 'publications_authors.alias_id = pubmed_authors.id','left');
		$this->db->where('kol_publications.kol_id',$kolId);
		$this->db->where('publications_authors.position',1);
		$this->db->where('publications_authors.alias_id',$authorId);
		$this->db->where('publications.affiliation !=','NA');
		$results	=	$this->db->get('publications_authors');*/
		
		//echo $this->db->last_query();
		foreach($results->result_array() as $row){
			$affiliation=$row;
			$pos = strpos($row['affiliation'], "@");
			if ($pos === false) {
			    
			} else {
			    $affWithEmail = $row;
			}
		}
		
		if($affWithEmail != '')
			return $affWithEmail;
		else
			return $affiliation;
	}
	
	function deleteAllMeshtermsAndAsociations(){
		$this->db->delete('pubmed_mesh_terms');
		$this->db->delete('publication_mesh_terms');
	}
	
    function getAllPublicationIdsWithPMID($lastPubIdProcessed){
		$arrResultData = array();
		$arrPMIDs = array();
		$arrPubIdsWithPMID = array();
		$this->db->select('id,pmid');
		if($lastPubIdProcessed != null)
			$this->db->where('id >',$lastPubIdProcessed);
		$this->db->where('pmid >',0);
		$this->db->order_by('id','asc');
		
		/* this is for specific kol
		 * $this->db->select('publications.id,publications.pmid');
		 $this->db->join('kol_publications', 'kol_publications.pub_id = publications.id','left');
		 if($lastPubIdProcessed != null)
		     $this->db->where('id >',$lastPubIdProcessed);
		     $this->db->where('pmid >',0);
		     $this->db->where('kol_publications.kol_id',566);
		     $this->db->order_by('id','asc');*/
		
		$results = $this->db->get('publications');
		foreach($results->result_array() as $row){
			$arrPMIDs[] = $row['pmid'];
			$arrPubIdsWithPMID[$row['pmid']] = $row['id'];
		}
		$arrResultData['arrPMIDs'] =$arrPMIDs;
		$arrResultData['arrPubIdsWithPMID'] =$arrPubIdsWithPMID;
		return $arrResultData;
	}
	
	function getSubstanceNameById($substancesId){
		$arrSubstances='';
		$this->db->select('name');
		$this->db->from('pubmed_substances');
		$this->db->where('id', $substancesId);
		$arrSubstancesResult = $this->db->get();
		foreach($arrSubstancesResult->result_array() as $row){
				$arrSubstances=$row['name'];
		}	
		return 	$arrSubstances;
	}
	
	/**
	 * returns all the Co-Authors id's matching the given Author id's first name and fore name
	 * Get the name details of all the co authoer id in the '$arrCoAuthIds', and get the all the co-authors having the same name details for given given kolId
	 * @author 	Ramesh B
	 * @since	otsuka 1.0.5
	 * @return Array
	 * @created 07-04-11
	 */
	function getMatchingCoAuthorIds($arrCoAuthIds,$kolId){
		//Get the name details of all the co authoer id in the '$arrCoAuthIds', and get the all the co-authors having the same name details for given given kolId
		$arrCoAuthos=array();
		$coAuthIds=$this->common_helpers->convertArrayToCommaSeparatedElements($arrCoAuthIds);
		
		$this->db->select('pubmed_authors.id');
		$this->db->join('publications_authors','pubmed_authors.id=publications_authors.author_id','left');
		$this->db->join('publications','publications_authors.pub_id=publications.id','left');
		$this->db->join('kol_publications','publications.id=kol_publications.pub_id','left');
		$this->db->where('kol_publications.kol_id',$kolId);
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		$where="(pubmed_authors.last_name,pubmed_authors.fore_name,pubmed_authors.initials) IN (SELECT last_name,fore_name,initials FROM pubmed_authors WHERE id IN ($coAuthIds))";
		$this->db->where($where);
		$this->db->order_by('pubmed_authors.last_name,pubmed_authors.fore_name');
		
		$arrCOAuth = $this->db->get('pubmed_authors');
		foreach($arrCOAuth->result_array() as $row){
			   	$arrCoAuthos[]=$row['id'];
		}	
		//echo $this->db->last_query();
		return $arrCoAuthos;
	}
	
	function savePMID($pmid,$kolId){
		$arrData =array();
		$arrData['pmid'] = $pmid;
		$arrData['kol_id'] = $kolId;
		
		if($this->db->insert('kol_pmids',$arrData)){
				return true;	      		
		}else{	      		
		    return false;
		}	
	}
	
	 /*
      * Returns the kols with status 2 i.e Recrawl
      */
     function getPubmedRecrawlKols(){
     	$arrKolDetails=array();
     	$arrStatus = array(2);
     	$this->db->select("id,salutation,first_name,middle_name,last_name,specialty");
     	$this->db->where_in('is_pubmed_processed',$arrStatus);
     	$this->db->where('kols.status',PROFILING);
     	$this->db->order_by("created_on", "asc");
     	$arrKolDetailResult=$this->db->get('kols');
	    foreach($arrKolDetailResult->result_array() as $arrKol){
	    			$arrKolDetails[]= $arrKol;
	    		}
	    return $arrKolDetails;
     }
     
     function getPMIDs($kolId){
     	$arrPMIDs = array();
     	$this->db->select('pmid');
     	$this->db->where('kol_id',$kolId);
     	$arrResults = $this->db->get('kol_pmids');
     	foreach($arrResults->result_array() as $row){
     		$arrPMIDs[] = $row['pmid'];
     	}
     	
     	return $arrPMIDs;
     }
     
     function updateZeroAuthPosPubsAsDeleted($kolId){
     	$arrResults = $this->db->query("UPDATE kol_publications SET is_deleted = 1,is_verified = 0 WHERE id IN
							(
								SELECT id FROM
								(
									SELECT kol_publications.id
									FROM kol_publications WHERE auth_pos = 0 AND kol_id = $kolId
								) AS pudsasdeleted
							) 
						");
     	return $this->db->affected_rows();
     }
     
     //Save the given name combination for given KOL
     function saveNameCombination($rowData){
     	if($this->db->insert('kol_name_combinations',$rowData)){
			return true;	      		
		}else{	      		
		    return false;
		}	
     }
     
     //deleted the name combination 
     function deleteNameCombination($name,$kolId){
     	$this->db->where('name',$name);
     	$this->db->where('kol_id',$kolId);
     	if($this->db->delete('kol_name_combinations'))
     		return true;
     	else
     		return false;
     }
     
     //Retrives the name combinations stored in database for given KOL id
     function getKolNameCombinations($kolId){
     	$this->load->helper('text');
     	$arrNameCombinations = array();
     	$this->db->select('name');
     	$this->db->where('kol_id',$kolId);
     	$results = $this->db->get('kol_name_combinations');
     	if(is_object($results) && $results->num_rows() > 0){
	     	foreach($results->result_array() as $row){
	     		$arrNameCombinations[] = ascii_to_entities($row['name']);
	     	}
     	}
     	return $arrNameCombinations;
     }
     
     //Retrives the given KOL publications ids in which his authorship positoin is '0' 
	 function getPubsWithAuthPosZero($kolId){
     	$arrPubIds = array();
     	$this->db->select('pub_id');
     	$this->db->where('kol_id',$kolId);
     	$this->db->where('auth_pos',0);
     	$results = $this->db->get('kol_publications');
     	if(is_object($results) && $results->num_rows() > 0){
	     	foreach($results->result_array() as $row){
	     		$arrPubIds[] = $row['pub_id'];
	     	}
     	}
     	return $arrPubIds;
     }
     
     //
     function getAuthorshipPositionGivenAllNameCombinations($kolId,$pubId){
     	$position = 0;
     	$this->db->select('publications_authors.position as auth_pos',false);
     	$this->db->join('publications_authors','publications_authors.pub_id = kol_publications.pub_id','left');
     	$this->db->join('pubmed_authors','pubmed_authors.id = publications_authors.author_id','left');
     	$this->db->where('kol_publications.kol_id',$kolId);
     	$this->db->where('kol_publications.pub_id',$pubId);
     	//Old method given name combinaions
    	/*	$commaSepNames = implode(",",$arrNameCombinations);
     	$commaSepNames = "(\"" . str_replace(",", "\",\"", $commaSepNames) . "\")";
     	$nameWhere = '( CONCAT(pubmed_authors.last_name," ",pubmed_authors.initials) IN '.$commaSepNames.' OR CONCAT(pubmed_authors.last_name," ",pubmed_authors.fore_name) IN'.$commaSepNames.' )';*/
     	//New method, using inline query
     	$nameWhere = '( CONCAT(pubmed_authors.last_name," ",pubmed_authors.initials) IN (select name from kol_name_combinations where kol_id ='.$kolId.') OR CONCAT(pubmed_authors.last_name," ",pubmed_authors.fore_name) IN (select name from kol_name_combinations where kol_id ='.$kolId.') )';
     	$this->db->where($nameWhere);
     	$results = $this->db->get('kol_publications');
//      	echo $this->db->last_query();
     	echo "<br>";
     	if(is_object($results) && $results->num_rows() > 0){
     		$row = $results->row_array();
     		$position = $row['auth_pos'];
     	}
     		
     	return $position;
     }
     
     function getAliasIdReferences($aliasId){
     	$arrIds = array();
     	$this->db->select('pubmed_authors.id');
     	$this->db->where('alias_id',$aliasId);
     	$results = $this->db->get('pubmed_authors');
     	//echo $this->db->last_query();
     	if(is_object($results) && $results->num_rows() > 0){
     		foreach($results->result_array() as $row){
	     		$arrIds[] = $row['id'];
	     	}
     	}
     	return $arrIds;
     }
     
 	function getAuthorshipPositionGivenAllNameCombinations2($kolId,$pubId,$arrNameCombinations){
     	$position = 0;
     	
     	$queryStr1 = "SELECT publications_authors.position AS auth_pos FROM (kol_publications) 
     								LEFT JOIN publications_authors ON publications_authors.pub_id = kol_publications.pub_id 
     								LEFT JOIN pubmed_authors ON pubmed_authors.id = publications_authors.author_id 
     								WHERE `kol_publications`.`kol_id` = $kolId AND `kol_publications`.`pub_id` = $pubId 
     								AND ( CONCAT(pubmed_authors.last_name,' ',pubmed_authors.initials) IN ($arrNameCombinations) OR CONCAT(pubmed_authors.last_name,' ',pubmed_authors.fore_name) IN($arrNameCombinations) )";
     	
     	/*$commaSepNames = implode(",",$arrNameCombinations);
     	$commaSepNames = "\"" . str_replace(",", "\",\"", $commaSepNames) . "\"";
     	$queryStr2 = "SELECT publications_authors.position AS auth_pos FROM (kol_publications) 
     								LEFT JOIN publications_authors ON publications_authors.pub_id = kol_publications.pub_id 
     								LEFT JOIN pubmed_authors ON pubmed_authors.id = publications_authors.author_id 
     								WHERE `kol_publications`.`kol_id` = '1397' AND `kol_publications`.`pub_id` = '99254' 
     								AND ( CONCAT(pubmed_authors.last_name,' ',pubmed_authors.initials) IN ($commaSepNames) OR CONCAT(pubmed_authors.last_name,' ',pubmed_authors.fore_name) IN($commaSepNames) )";*/
     	
     	$results = $this->db->query($queryStr1);
     	//echo $queryStr2;
     	
 		/*foreach($arrNameCombinations as $combianation){
     		$arrCombs = explode(" ",$combianation);
     		if(sizeof($arrCombs) > 2){
     			$arrPers = getCombinations($arrCombs,2);
     		}else{
     			$firstName = $arrCombs[0];
     			$lastName = $arrCombs[1];
     			$pos = $this->getAuthorshipPos($pubId,$firstName, $lastName);
     			if($pos != 0)
     				$position = $pos;
     				
     			$firstName = $arrCombs[1];
     			$lastName = $arrCombs[0];
     			$pos = $this->getAuthorshipPos($pubId,$firstName, $lastName);
     			if($pos != 0)
     				$position = $pos;
     		}
     	}*/
     	
     	/*$arrNames = array();
     	foreach($arrNameCombinations as $name){
     		$arrNames[] = $name;
     	}
     	//$commaSepNames = implode(",",$arrNameCombinations);
     	$this->db->select('publications_authors.position as auth_pos',false);
     	$this->db->join('publications_authors','publications_authors.pub_id = kol_publications.pub_id','left');
     	$this->db->join('pubmed_authors','pubmed_authors.id = publications_authors.author_id','left');
     	$this->db->where('kol_publications.kol_id',$kolId);
     	$this->db->where('kol_publications.pub_id',$pubId);
     	$this->db->where_in("CONCAT(pubmed_authors.last_name,' ',pubmed_authors.initials)",$arrNames);
     	//$nameWhere = '( CONCAT(pubmed_authors.last_name," ",pubmed_authors.initials) IN '.$commaSepNames.' OR CONCAT(pubmed_authors.last_name," ",pubmed_authors.fore_name) IN'.$commaSepNames.' )';
     	//$this->db->where($nameWhere);
     	$results = $this->db->get('kol_publications');
     	echo $this->db->last_query();*/
     	
     	if(is_object($results) && $results->num_rows() > 0){
     		$row = $results->row_array();
     		$position = $row['auth_pos'];
     	}
     		
     	return $position;
     }
     
     function deletePublicationAuthorsAssociation($pubId){
     	$this->db->where('pub_id',$pubId);
     	$this->db->delete('publications_authors');
     }
     
     function deletePublicationAssociationDetails($pubId){
     	//Delete authors
     	$this->db->where('pub_id',$pubId);
     	$this->db->delete('publications_authors');
     	
     	//Delete MEshTerms
     	$this->db->where('pub_id',$pubId);
     	$this->db->delete('publication_mesh_terms');
     	
     	//Delete Substances
     	$this->db->where('pub_id',$pubId);
     	$this->db->delete('publication_substances');
     	
     	//Delete Publication types
     	$this->db->where('pub_id',$pubId);
     	$this->db->delete('publications_types');
     	
     	//Deelete CC
     	$this->db->where('pub_id',$pubId);
     	$this->db->delete('publications_cc');
     	
     	//Delete Artcile Ids
     	$this->db->where('pub_id',$pubId);
     	$this->db->delete('publication_article_ids');
     	
     	//Delete History
     	$this->db->where('pub_id',$pubId);
     	$this->db->delete('publication_history');
     }
     
     function getNumberOfAuthors($pubId){
     	$numAuthors = 0;
     	$this->db->where('pub_id',$pubId);
     	$numAuthors=$this->db->count_all_results('publications_authors');
     	return $numAuthors;
     }
     
     function getAssociatedKols($pubId){
     	$arrAssociatedKols = array();
     	$this->db->select("kols.id,salutation,first_name,middle_name,last_name,specialty");
     	$this->db->where('pub_id',$pubId);
     	$this->db->join("kols","kols.id = kol_publications.kol_id","left");
     	$this->db->group_by("kol_publications.kol_id");
     	$results = $this->db->get('kol_publications');
     	if(is_object($results) && $results->num_rows() > 0){
     		foreach($results->result_array() as $row){
     			$arrAssociatedKols[] = $row;
     		}
     	}
     		
     	return $arrAssociatedKols;
     }
     
     function getPossibleCoAuthorIdsForKol($kolId){
     	$arrKolName = $this->kol->getKolName($kolId);
     	$arrIds=array();
     			$arrSuffixes = array("Sr.","Sr","Jr.","Jr","I","II","III","IV");
		$arrLastNameWords = explode(" ",$arrKolName['last_name']);
		$numWords = sizeof($arrLastNameWords);
		if( $numWords > 1){
			$lastWord = $arrLastNameWords[$numWords-1];
			if(in_array($lastWord, $arrSuffixes)){
				unset($arrLastNameWords[$numWords-1]);
				$arrKolName['last_name'] = implode(" ",$arrLastNameWords);
			}
		}
		
		$lastName   = trim($arrKolName['last_name'],".");
		$middleName = trim($arrKolName['middle_name'],".");
		//If Fore name contains only first name
		$foreName = trim($arrKolName['first_name'],".");

		$firstCharOfFMname = substr($foreName,0,1).' '.substr($middleName,0,1);

		$FnameMnameOfFchar = $foreName.' '.substr($arrKolName['middle_name'],0,1);

		//If Fore name contains first name & middle name
		$foreNameFM = $arrKolName['first_name'].' '.$arrKolName['middle_name'];;

		//If Fore name contains first name of First Char
		$foreNameFirstChar = substr($arrKolName['first_name'],0,1);

		//If Fore name contains Middle name of First Char
		$foreNameMiddleNameFirstChar = substr($arrKolName['middle_name'],0,1);

		//If Fore name contains first name of First Char  & middle name
		$foreNameFirstCharM = substr($arrKolName['first_name'],0,1).' '.$arrKolName['middle_name'];
		
		$firstNameMiddleNameFirstChar = trim(substr($arrKolName['first_name'],0,1)."".substr($arrKolName['middle_name'],0,1));

		//Get KOL name combinations from the database if any
		$enteredNameCombinations = '';
		//Old method given name combinaions
		/*$commaSepNames = implode(",",$arrNameCombinations);
		$commaSepNames = "(\"" . str_replace(",", "\",\"", $commaSepNames) . "\")";
     	$enteredNameCombinations = 'OR CONCAT(pubmed_authors.last_name," ",pubmed_authors.initials) IN '.$commaSepNames.' OR CONCAT(pubmed_authors.last_name," ",pubmed_authors.fore_name) IN'.$commaSepNames;*/
		//New method, using inline query
     	$enteredNameCombinations = 'OR CONCAT(pubmed_authors.last_name," ",pubmed_authors.initials) IN (select name from kol_name_combinations where kol_id ='.$kolId.') OR CONCAT(pubmed_authors.last_name," ",pubmed_authors.fore_name) IN (select name from kol_name_combinations where kol_id ='.$kolId.')';
     	
     	$this->db->distinct();
		$this->db->select("pubmed_authors.id");
		$this->db->join('pubmed_authors','publications_authors.alias_id=pubmed_authors.id','left');
		$this->db->join('kol_publications','publications_authors.pub_id = kol_publications.pub_id','left');
		$this->db->where('kol_publications.kol_id',$kolId);
		$this->db->where('kol_publications.is_verified',1);
		$where1="((last_name=\"$lastName\" and fore_name=\"$foreName\") OR (last_name=\"$lastName\" and fore_name=\"$foreNameFM\") OR (last_name=\"$lastName\" and fore_name=\"$foreNameFirstCharM\") OR (last_name=\"$lastName\" and fore_name=\"$foreNameFirstChar\") OR (last_name=\"$lastName\" and fore_name=\"$middleName\") OR (last_name=\"$lastName\" and fore_name=\"$foreNameMiddleNameFirstChar\") OR(last_name=\"$lastName\" and fore_name=\"$firstCharOfFMname\")OR(last_name=\"$lastName\" and fore_name=\"$FnameMnameOfFchar\") OR(last_name=\"$lastName\" and initials=\"$firstNameMiddleNameFirstChar\") $enteredNameCombinations)";
		$this->db->where($where1);
		
		$results=$this->db->get('publications_authors');
		//echo $this->db->last_query();
		foreach($results->result_array() as $row){
			$arrIds[]=$row['id'];
		}
		return $arrIds;
     }
     
/**
	 * Retrives the publication details for the given kol publication association id
	 * @author 	Ramesh B 
	 * @since	4.2
	 * @return Array
	 * @created 14-06-2012
	 */
	function getOrgPublicationDetail($orgPubId){
		$publication=array();
		$this->db->select('publications.*');
		$this->db->where('org_publications.id',$orgPubId);
		$this->db->join('publications', 'org_publications.pub_id = publications.id','left');
		$publication=$this->db->get('org_publications');
		$publication=$publication->row_array();
		return 	$publication;	
	}
	
	function getPubTypeData($kolId,$fromYear,$toYear,$keyword){
		$this->db->select('pubmed_publications_types.id,pubmed_publications_types.type,COUNT(DISTINCT(publications_types.pub_id)) AS count');
		$this->db->join('publications','kol_publications.pub_id=publications.id','inner');
		$this->db->join('publications_types','publications_types.pub_id=kol_publications.pub_id','inner');
		$this->db->join('pubmed_publications_types','pubmed_publications_types.id=publications_types.pub_type_id','inner');
		if($fromYear !='' && $toYear!=''){
			
			$this->db->where("(year(publications.created_date) >= '$fromYear' AND year(publications.created_date) <='$toYear')");
		}
		
		if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
		}
		$this->db->where('kol_publications.is_verified',1);
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.kol_id',$kolId);
		$this->db->group_by('publications_types.pub_type_id');
		$this->db->order_by('count','desc');
		$this->db->limit('20');
		$results = $this->db->get('kol_publications');
		foreach($results->result_array() as $row){
			$arrIds[]=$row;
		}
		return $arrIds;
	}
	
	function getPublicationsByType($typeId,$kol_id, $fromYear,$toYear,$filters,$viewType){
		$arrPublicationsDetail=array();
	
		$this->db->select('pubmed_publications_types.type ,publications.id,publications.pmid,pubmed_journals.name as journal_name,publications.article_title,publications.created_date,count(distinct kol_publications.pub_id) as count,kol_publications.auth_pos,publications.link');
		$this->db->join('publications_types', 'pubmed_publications_types.id=publications_types.pub_type_id','left');
		//$this->db->join('publications_types', 'pubmed_publications_types.id=publications_types.pub_type_id','left');
		$this->db->join('kol_publications', 'kol_publications.pub_id = publications_types.pub_id','left');
		$this->db->join('publications', 'publications.id = kol_publications.pub_id','left');
		
		
		
		$this->db->join('pubmed_journals', 'pubmed_journals.id = publications.journal_id','left');
		$this->db->join('kols', 'kol_publications.kol_id = kols.id','left');
		
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.is_verified',1);
		if($kol_id != 0)
			$this->db->where('kol_publications.kol_id',$kol_id);
		$this->db->where('pubmed_publications_types.id',$typeId);
		$this->db->where('(YEAR(publications.created_date) BETWEEN '.$fromYear.' AND '.$toYear.' OR YEAR(publications.created_date)=0)');
// 		$this->db->where('kols.status',COMPLETED);
		if(count($viewType)>0 && !empty($viewType))
			$this->db->where_in('kols.id',$viewType);
		//Refine by filters
		if($filters != null){
			if(isset($filters['global_region'])){
				$globalRegion = $filters['global_region'];
				foreach($globalRegion as $arrGlobalRegionIds){
					 $str = str_replace("_","/",$arrGlobalRegionIds);
        			$globalRegionSorted[] = str_replace("%20"," ",$str);
				}
				$this->db->join('countries', 'countries.CountryId = kols.country_id','left');
				$isKolsJoined = true;
				$this->db->where_in('countries.GlobalRegion', $globalRegionSorted);
			}			
			if(isset($filters['specialty'])){
				$this->db->join('specialties', 'specialties.id = kols.specialty','left');
				$this->db->where_in('specialties.id',$filters['specialty']);
			}
			if(isset($filters['country'])){
				if($isKolsJoined == false)
					$this->db->join('countries', 'countries.CountryId = kols.country_id','left');
				$this->db->where_in('countries.CountryId',$filters['country']);
			}
			if(isset($filters['state'])){
				$this->db->join('regions', 'regions.RegionID = kols.state_id','left');
				$this->db->where_in('regions.RegionID',$filters['state']);
			}
			if(isset($filters['kol_id'])){
				$this->db->where_in('kol_publications.kol_id',$filters['kol_id']);
			}
			if(isset($filters['listName'])){
				$userId   =$this->session->userdata('user_id');
		 		$clientId =$this->session->userdata('client_id');
		 		$this->db->join('list_kols','list_kols.kol_id=kol_publications.kol_id','left');
		 		$this->db->join('list_names','list_kols.list_name_id=list_names.id','left');
		 		$this->db->join('list_categories','list_names.category_id=list_categories.id','left');
		 		$this->db->where_in('list_names.id',$filters['listName']);
		 		$this->db->where("(list_categories.client_id=$clientId and (list_categories.user_id=$userId or list_categories.is_public=1 ))");
			}
			if (isset($filters['profileType'][0])){
			    if(str_replace("%20"," ",$filters['profileType'][0]) == DISCOVERY){
			        $this->db->where('(kols.imported_as = 2 or kols.imported_as = 3)', null, false);
			    }else{
			        $this->db->where('kols.profile_type', str_replace("%20"," ",$filters['profileType'][0]));
			        $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
			    }
			    //             $this->db->where('kols.profile_type', $arrProfileType);
			}else{
			    if($kol_id == 0)
			        $this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
			}
		}
		$this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
		$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		$keyword = $filters['keyword'];
		if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		$this->db->group_by('kol_publications.pub_id');
		$this->db->order_by('created_date','desc');
		//$this->db->limit('20');
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$arrPublications	=	$this->db->get('pubmed_publications_types');
		foreach($arrPublications->result_array() as $row){
			$row['authcount'] = $this->pubmed->getNumberOfAuthors($row['id']);
			if(isset($row['pmid']) && $row['pmid'] > 0){
			    $row['linkForArticle'] = 'pmid';
			}else{
			    $row['linkForArticle'] = 'link';
			}
			$arrPublicationsDetail[]=$row;
		}
		return $arrPublicationsDetail;
	}
	
	function getIdentificationNames(){
		$arrNames = array();
		$this->db->where('status',0);
		$results=$this->db->get('identification_names');
		//echo $this->db->last_query();
		foreach($results->result_array() as $row){
			$arrNames[$row['id']]=$row;
		}
		return $arrNames;
	}
	
	function updateIdentificationName($data){
		$this->db->where('id', $data['id']);	
		if($this->db->update('identification_names', $data)){
			return true;
		} else {
			return false;
		}
	}
	
	function saveIdentificationReport($data){
		$arrJournal['name']=$journalName;
		$this->db->where('kol_id',$data['kol_id']);
		if($arrResults=$this->db->get('identification_report')){			
			if($arrResults->num_rows()!=0){
				$this->db->where('kol_id', $data['kol_id']);
				if($this->db->update('identification_report', $data)){
					return true;
				} else {
					return false;
				}
			}
			else {
				if($this->db->insert('identification_report',$data)){
					return true;    		
		      	}else{	      		
		      		return false;
		      	}
			}
		}
	}
	
	function updateIdentificationReport($data){
		$this->db->where('kol_id', $data['kol_id']);	
		if($this->db->update('identification_report', $data)){
			return true;
		} else {
			return false;
		}
	}
	
	function listIdentificationResults(){
		$arrResults = array();
		//$this->db->select("*");
		$this->db->join('identification_names','identification_report.kol_id = identification_names.id');
		$results=$this->db->get('identification_report');
		//echo $this->db->last_query();
		return $results->result_array();
	}
	
	function findAuthorshipPosition($kolDetails, $arrAuthors){
		$position = 0;
		$arrAuthNames = array();
		foreach($arrAuthors as $author)
			$arrAuthNames[] = strtolower($author['last_name']."".$author['initials']);
		
		$arrNameCombinations = array();
		$firstName 	= strtolower(trim($kolDetails['first_name']));
		$middleName = strtolower(trim($kolDetails['middle_name']));
		$lastName 	= strtolower(trim($kolDetails['last_name']));
		if($middleName != ''){
			$lnFnMn = $lastName.''.$firstName.' '.$middleName;
			$lnFnMi = $lastName.''.$firstName.' '.substr($middleName, 0, 1);
			$lnFiMn = $lastName.''.substr($firstName, 0 , 1).''.$middleName;
			$laFiMi = $lastName.''.substr($firstName, 0 , 1).''.substr($middleName, 0, 1);
			$laFi = $lastName.''.substr($firstName, 0 , 1);
			
			$arrNameCombinations[] = $lnFnMn;
			$arrNameCombinations[] = $lnFnMi;
			$arrNameCombinations[] = $lnFiMn;
			$arrNameCombinations[] = $laFiMi;
			$arrNameCombinations[] = $laFi;
		}else{
			$lnFnMi = $lastName.''.$firstName;
			$lnFiMn = $lastName.''.substr($firstName, 0 , 1);
			$arrNameCombinations[] = $lnFnMi;
			$arrNameCombinations[] = $lnFiMn;
		}
		
		/*$result = array_intersect($arrNameCombinations, $arrAuthNames);
		if(sizeof($result)  == 0)
			return $position;
		else{
			$name = $result[0];
			$key = array_search(strtolower($name), $arrAuthNames);
			if($key !== false)
				$position = $key+1;
				
			return $position;
		}*/
		
		foreach($arrNameCombinations as $name){
			$key = array_search(strtolower($name), $arrAuthNames);
			if($key !== false)
				$position = $key+1;
		}
		
		return $position;
	}
	
	function getPubFromLocalPubmed($pmid){
		error_reporting(E_ALL);
		ini_set('default_charset', 'utf-8');
		mb_internal_encoding("UTF-8");
		
		// Connect to test database
		$m = new Mongo("localhost:27017");
		$db = $m->pubmed; 
		//$db = $m->localpub; 
		
		$startTime	= microtime(true);
		$collection = $db->publications;
		$where = array();
		//$where['PMID'] = (string)$pmid;
		$where['_id'] = (int)$pmid;
		$result = $collection->findOne($where);
		return $result;
	}
	
	function getKolAllProjectPmids($kolId){
		$arrData = array();
		$this->db->select('pmid,project_id');
		$this->db->where('kol_id',$kolId);
		$res = $this->db->get('kol_pmids');
		if($res->num_rows() > 0){
			foreach($res->result_array() as $row){
				$arrData[$row['project_id']][] = $row['pmid'];
			}
		}
		return $arrData;
	}
	
	function getAuthorshipCategory($position,$numAuths){
		$positionCategory = '';
		if($position == 1 && $numAuths == 1)
			$positionCategory = 'sa';
		if($position == 1 && $numAuths > 1)
			$positionCategory = 'fa';
		if($position > 1 && $position == $numAuths)
			$positionCategory = 'la';
		if($position > 1 && $position != $numAuths)
			$positionCategory = 'ma';
			
		return $positionCategory;
	}
        
   function viewPubsByTopConcepts($kolId,$startYear,$endYear,$termName,$keyword){
		$this->db->select('pubmed_mesh_terms.term_name AS NAME,publication_mesh_terms.pub_id AS id,publications.pmid AS pmid,publications.article_title,
		pubmed_journals.name AS journal_name,publications.created_date,COUNT(DISTINCT kol_publications.pub_id) AS COUNT,kol_publications.auth_pos,publications.link');
		$this->db->join('publications','publication_mesh_terms.pub_id=publications.id','left');
		$this->db->join('kol_publications','kol_publications.pub_id=publications.id','left');
		$this->db->join('pubmed_mesh_terms','pubmed_mesh_terms.id=publication_mesh_terms.term_id','left');
		$this->db->join('pubmed_journals','pubmed_journals.id=publications.journal_id','left');
		if($keyword!=''){
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
		}
		$this->db->where("(year(publications.created_date) >= '$startYear' AND year(publications.created_date) <='$endYear')");
		$this->db->where_in('pubmed_mesh_terms.term_name',utf8_decode(urldecode($termName)));
		$this->db->where('kol_publications.is_verified',1);
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.kol_id',$kolId);
		$this->db->group_by('kol_publications.pub_id');
		$this->db->order_by('created_date','desc');
//		$this->db->limit('20');
		$results = $this->db->get('publication_mesh_terms');
		
		foreach($results->result_array() as $row){
			$row['authcount'] = $this->pubmed->getNumberOfAuthors($row['id']); 
			if(isset($row['pmid']) && $row['pmid'] > 0){
			    $row['linkForArticle'] = 'pmid';
			}else{
			    $row['linkForArticle'] = 'link';
			}
			$arrIds[]=$row;
		}
//		echo count($arrIds);
//		echo $this->db->last_query();
//		exit;
		return $arrIds;
	}
	
	function getTreeIdByMeshTerm($termName){
		$this->db->where("name",$termName);
		$arrMeh = $this->db->get("mesh_dictionary_terms");
		if($arrMeh->num_rows() > 0){
			foreach ($arrMeh->result_array() as $newRow){
				$arrUpdate = array();
				$arrUpdate["tree_id"] = $newRow['tree_id'];
				$arrUpdate["uid"] = $newRow['uid'];
			}
			return $arrUpdate;
		}else{
			return array();
		}
	}    
        
        /**
        * Displaying the publication details limited to 5 only for mobile ui
        * @package application.models
        * @author Shruti Purushan
        * @since
        * @created on  17-04-2015
        */
        function searchPublicationsByParametersRecent5($substance,$author,$meshTermName,$keyword,$aritcleName,$kolId,$fromYear,$toYear){
            $clientId = $this->session->userdata('client_id');
        $this->db->select('distinct(publications.id),publications.*,kol_publications.auth_pos,pubmed_journals.name as journal_name,kol_publications.id AS kp_id,kol_publications.client_id');
		$this->db->join('publications','publications.id=kol_publications.pub_id','left');
		$this->db->join('pubmed_journals','publications.journal_id=pubmed_journals.id','left');
		
//		if($substance!=''){
//			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
//			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id');
//			$this->db->like("pubmed_substances.name",$substance);
//		}
//		
//		if($author!=''){
//			$this->db->join('publications_authors', 'publications_authors.pub_id = publications.id','left');
//			$this->db->join('pubmed_authors', 'publications_authors.author_id = pubmed_authors.id','left');
//			//$this->db->like('pubmed_authors.last_name',$author);
//			//$this->db->or_like('pubmed_authors.fore_name',$author);
//			
//			$this->db->where("((pubmed_authors.last_name  LIKE '%$author%' OR  pubmed_authors.fore_name  LIKE '%$author%'))");
//		}
		
		if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		
//		if($meshTermName !=''){
//			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
//			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
//			$this->db->like('pubmed_mesh_terms.term_name',$meshTermName);
//		}
//		
//		if($aritcleName !=''){
//			$this->db->like('publications.article_title',$aritcleName);
//		}
	
		if($fromYear !='' && $toYear!=''){
			
			$this->db->where("(year(publications.created_date) >= '$fromYear' AND year(publications.created_date) <='$toYear')");
		}
		$this->db->where('kol_publications.is_verified',1);
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.kol_id',$kolId);
		if($clientId!=INTERNAL_CLIENT_ID){
		    $this->db->where("(kol_publications.client_id=$clientId or kol_publications.client_id=".INTERNAL_CLIENT_ID.")");
		}
		$this->db->order_by('publications.created_date','desc');
                $this->db->limit(5,0);
		$arrResultSet = $this->db->get('kol_publications');
		$arrPubliations =array();
//	echo $this->db->last_query();
//		if($arrResultSet->count > 0){
		foreach($arrResultSet->result_array() as $row){
			$arrPubliations[]=$row;
		}
//		}
		return $arrPubliations;
	}
        
         /*
         * Displaying 15 publication details for mobile ui
         */
	function searchPublicationsByParametersRecent15($substance,$author,$meshTermName,$keyword,$aritcleName,$kolId,$fromYear,$toYear,$count=false){
	    $clientId = $this->session->userdata('client_id');
	    if($count){
                    $this->db->select("count(distinct publications.id) as count");
                }else{
                    $this->db->select('distinct(publications.id),publications.*,kol_publications.auth_pos,pubmed_journals.name as journal_name,kol_publications.id AS kp_id,kol_publications.client_id');
                }
		$this->db->join('publications','publications.id=kol_publications.pub_id','left');
		$this->db->join('pubmed_journals','publications.journal_id=pubmed_journals.id','left');
		
//		if($substance!=''){
//			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
//			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id');
//			$this->db->like("pubmed_substances.name",$substance);
//		}
//		
//		if($author!=''){
//			$this->db->join('publications_authors', 'publications_authors.pub_id = publications.id','left');
//			$this->db->join('pubmed_authors', 'publications_authors.author_id = pubmed_authors.id','left');
//			//$this->db->like('pubmed_authors.last_name',$author);
//			//$this->db->or_like('pubmed_authors.fore_name',$author);
//			
//			$this->db->where("((pubmed_authors.last_name  LIKE '%$author%' OR  pubmed_authors.fore_name  LIKE '%$author%'))");
//		}
		
		if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		
//		if($meshTermName !=''){
//			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
//			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
//			$this->db->like('pubmed_mesh_terms.term_name',$meshTermName);
//		}
//		
//		if($aritcleName !=''){
//			$this->db->like('publications.article_title',$aritcleName);
//		}
	
		if($fromYear !='' && $toYear!=''){
			
			$this->db->where("(year(publications.created_date) >= '$fromYear' AND year(publications.created_date) <='$toYear')");
		}
		$this->db->where('kol_publications.is_verified',1);
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.kol_id',$kolId);
		if($clientId!=INTERNAL_CLIENT_ID){
		    $this->db->where("(kol_publications.client_id=$clientId or kol_publications.client_id=".INTERNAL_CLIENT_ID.")");
		}
		$this->db->order_by('publications.created_date','desc');
                $this->db->limit(15,0);
		$arrResultSet = $this->db->get('kol_publications');
		$arrPubliations =array();
		
                if($count){
//                	if($arrResultSet->count > 0){
                    foreach($arrResultSet->result_array() as $row){
                            $arrPubliationsCount=$row["count"];                            
                    }
                    return $arrPubliationsCount;
                    
//                	}
                }else{
//                	if($arrResultSet->count > 0){
                    foreach($arrResultSet->result_array() as $row){
                            $arrPubliations[]=$row;
                    }
                   
                    return $arrPubliations;
//                	}
                }
               
	}
        
       
         /*
         * Displaying only 15 details at a time for lazy loading in mobile ui
         */
        function searchPublicationsByParametersRecent15LoadMore($substance,$author,$meshTermName,$keyword,$aritcleName,$kolId,$fromYear,$toYear,$offset){
            $clientId = $this->session->userdata('client_id');
        $this->db->select('distinct(publications.id),publications.*,kol_publications.auth_pos,pubmed_journals.name as journal_name,kol_publications.id AS kp_id,kol_publications.client_id');
		$this->db->join('publications','publications.id=kol_publications.pub_id','left');
		$this->db->join('pubmed_journals','publications.journal_id=pubmed_journals.id','left');
		
//		if($substance!=''){
//			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
//			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id');
//			$this->db->like("pubmed_substances.name",$substance);
//		}
//		
//		if($author!=''){
//			$this->db->join('publications_authors', 'publications_authors.pub_id = publications.id','left');
//			$this->db->join('pubmed_authors', 'publications_authors.author_id = pubmed_authors.id','left');
//			//$this->db->like('pubmed_authors.last_name',$author);
//			//$this->db->or_like('pubmed_authors.fore_name',$author);
//			
//			$this->db->where("((pubmed_authors.last_name  LIKE '%$author%' OR  pubmed_authors.fore_name  LIKE '%$author%'))");
//		}
		
		if($keyword!=''){
			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
			$this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
			$this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$this->db->where("(publications.article_title  LIKE '%$keyword%' OR  publications.abstract_text  LIKE '%$keyword%' OR pubmed_substances.name LIKE '%$keyword%' OR pubmed_mesh_terms.term_name LIKE '%$keyword%')");
			
		}
		
//		if($meshTermName !=''){
//			$this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
//			$this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
//			$this->db->like('pubmed_mesh_terms.term_name',$meshTermName);
//		}
//		
//		if($aritcleName !=''){
//			$this->db->like('publications.article_title',$aritcleName);
//		}
	
		if($fromYear !='' && $toYear!=''){
			
			$this->db->where("(year(publications.created_date) >= '$fromYear' AND year(publications.created_date) <='$toYear')");
		}
		$this->db->where('kol_publications.is_verified',1);
		$this->db->where('kol_publications.is_deleted',0);
		$this->db->where('kol_publications.kol_id',$kolId);
		if($clientId!=INTERNAL_CLIENT_ID){
		    $this->db->where("(kol_publications.client_id=$clientId or kol_publications.client_id=".INTERNAL_CLIENT_ID.")");
		}
		$this->db->order_by('publications.created_date','desc');
                $this->db->limit(15,$offset);
		$arrResultSet = $this->db->get('kol_publications');
		$arrPubliations =array();
//		echo $this->db->last_query();
		foreach($arrResultSet->result_array() as $row){
			$arrPubliations[]=$row;
		}
		return $arrPubliations;
	}
        /*
         * To get the number of publications count
         */
        function totalPublications($kolId){
            $this->db->select("count(*) as count");
            $this->db->where("kol_id",$kolId);
            $result = $this->db->get("kol_publications");
            foreach( $result->result_array() as $row){
                $total = $row["count"];
            }        
            return $total;
        }
        
        /*
         * To get the number of authors of a particular publication
         */
        function getPublictionsAuthorsbyPubid($pub_id,$limit=5){
            
//            SELECT publications.*,pubmed_authors.* FROM publications
//LEFT JOIN publications_authors ON publications_authors.pub_id = publications.id
//LEFT JOIN pubmed_authors ON pubmed_authors.id = publications_authors.author_id
//WHERE publications.id = 267249
//LIMIT 5
                    
            $this->db->select("publications.id as pub_id,publications.pmid,pubmed_authors.*");
            $this->db->join("publications_authors","publications_authors.pub_id = publications.id","left");
            $this->db->join("pubmed_authors","pubmed_authors.id = publications_authors.author_id","left");
            $this->db->where("publications.id",$pub_id);
            $this->db->limit($limit);
            $resArr = $this->db->get("publications");
            $arrRetArr = array();
            foreach ($resArr->result_array() as $row){
                $arrRetArr[] = $row;
            }
            return $arrRetArr;
        }
        function delete_author_publication($pubId,$autId){
            if($this->db->delete("publications_authors",array("pub_id"=>$pubId,"author_id"=>$autId)) && $this->db->delete("pubmed_authors",array("id"=>$autId))){
                return true;
            }
            return false;
        }
/*         function SavePublicationType($arrayPublicationTypeDetails){
            $get = $this->db->get_where("publications_types",array("pub_id"=>$arrayPublicationTypeDetails['pub_id']));
            if($get->num_rows()==0){
               $this->db->insert("publications_types",$arrayPublicationTypeDetails); 
            }else{
                $this->db->update("publications_types",$arrayPublicationTypeDetails,array("pub_id"=>$arrayPublicationTypeDetails['pub_id']));
            }
        } */
        function getKolPublications($kolId,$limit, $startFrom, $sidx, $sord, $where){
            $arrPublicationsDetail=array();
            $this->db->select("count(distinct kol_publications.pub_id) as count
                                ,`publications`.`id`, `publications`.`pmid`, `pubmed_journals`.`name` as journal_name, `publications`.`article_title`, `publications`.`created_date`
                                , `publications`.`link`, count(publications_authors.id) as authcount
                                ,year(created_date) as year");
            $this->db->join('publications','kol_publications.pub_id = publications.id','left');
            $this->db->join('pubmed_journals','pubmed_journals.id = publications.journal_id','left');
            $this->db->join('publications_authors', 'publications_authors.pub_id = publications.id','left');            
            $this->db->where('kol_publications.kol_id',$kolId);
            $this->db->where('kol_publications.is_deleted',0);
            $this->db->where('kol_publications.is_verified',1);          
            
            
            if (isset($where['created_date'])) {
                $this->db->like("DATE_FORMAT(publications.created_date,'%m/%d/%Y')", $where['created_date']);
            }
            
            if (isset($where['article_title'])) {
                $this->db->like("publications.article_title",$where['article_title']);
                //             $this->db->where("(client_users.first_name LIKE '%" . $where['recorded_by'] . "%' or client_users.last_name LIKE '%" . $where['recorded_by'] . "%')");
            }
            if (isset($where['journal_name'])) {
                $this->db->like("journal_name",$where['journal_name']);
                //             $this->db->where("(client_users.first_name LIKE '%" . $where['recorded_by'] . "%' or client_users.last_name LIKE '%" . $where['recorded_by'] . "%')");
            }
           /*if (isset($where['auth_position'])) {
                $this->db->like("count", $where['count']);
            }
            if (isset($where['authcount'])) {
                $this->db->like("authcount", $where['authcount']);
            }*/
            
            
            if ($limit != 'all' && $limit != 0) {
                $this->db->limit($limit, $startFrom);
                //$this->db->limit(1000);
            }
            if ($sidx != '' && $sord != '') {
                switch ($sidx) {
                    case 'article_title' : $this->db->order_by("publications.article_title", $sord);
                    break;
                    case 'journal_name' :$this->db->order_by("journal_name", $sord);
                    break;
                    case 'created_date' :$this->db->order_by("publications.created_date", $sord);
                    break; 
                    case 'auth_position' :$this->db->order_by("count", $sord);
                    break;
                    case 'authcount' :$this->db->order_by("authcount", $sord);
                    break;
                }
                //$this->db->order_by($sidx,$sord);
            } else {
            
                $this->db->order_by("publications.created_date", 'desc');
            }         
            
            $this->db->group_by('kol_publications.id');        
            $arrPublications = $this->db->get('kol_publications');
//                     pr($this->db->last_query());exit;
            foreach($arrPublications->result_array() as $row){
                $arrPublicationsDetail[]=$row;
            }
            return $arrPublicationsDetail;
        }    
   
}
