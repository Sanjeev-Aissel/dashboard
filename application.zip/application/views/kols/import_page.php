<?php
?>
<script type="text/javascript">

function validateImportForm(thisEle){
	if($(thisEle).val() =="Upload"){

		if($('#profImport').val()==''){
		jAlert("Please select the file to Upload");
			
			return false;
		}else{
			var action ="<?php echo base_url()?>kols/upload_zip_file";
			$('#kolImportForm').attr('action',action);
			$('#kolImportForm').submit();

		}
	}else{
		$('#kolImportButton').attr('disabled', 'disabled');
		$('#wrapper').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(<?php echo base_url()?>/images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'100%',width:'100%',cursor:'default'}});
		var action ="<?php echo base_url()?>kols/list_all_uploaded_files";
		$('#kolImportForm').attr('action',action);
		$('#kolImportForm').submit();
	}
}


</script>

<div id="kolImportContainer">
	<form action="<?php echo base_url();?>kols/upload_zip_file" name="kolImportForm" id="kolImportForm" method="post" enctype="multipart/form-data">
			<?php
				 $currentMethod		= $this->uri->segment(2);
				 if($currentMethod == 'analyst_kol_import_page'){?>
					<input type="hidden" name="methodName"  value="<?php echo $currentMethod;?>" id="kolMethodName"></input>
			<?php }else{?>
					<input type="hidden" name="methodName"  value="<?php echo $currentMethod;?>" id="kolMethodName"></input>
			<?php }?>
		<p>
			<label>Import KOLs profile  :</label>
			<input type="file" name="prof_import" id="profImport"/>('.xls' files only)
			<?php 
			//TODO Change the name of Input field from 'prof_import' to 'kol_import' which makes more sense
			?>
		</p>
		<p>
			<input type="button" value="Upload"  id="kolImportButton" onclick="validateImportForm(this)"/>
			
		</p>
		
		<p>
			<input type="button" value="List Uploded Files"  id="kolImportButton" onclick="validateImportForm(this)"/>
			
		</p>
	</form>
	<div id="importInstructions">
		
	</div>
</div>