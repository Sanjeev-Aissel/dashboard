<?php
/**
 * This is Model file of 'Identification Project' related tasks
 *
 * @package application.models
 * @author Ramesh
 * @since
 * @created 06 Feb 2015
 */

class Identification extends Model{
	
	//Constructor
	function Identification(){
		parent::Model();
	}
	
	function saveProject($rowData){
		if($this->db->insert('projects',$rowData)){
			//return $this->db->insert_id();
                    $id = $this->db->insert_id();
                    $resultArray = $this->db->get_where('projects', array('id' => $id));
                    $projectDataArray=array();
                    foreach($resultArray->result_array() as $row){
                        $projectDataArray[]	= $row;
                    }
                    //Add Log activity
                    $arrLogDetails = array(
                    		'type' => ADD_RECORD,
                    		'description' => 'Add New project',
                    		'status' => STATUS_SUCCESS,
                    		'transaction_id' =>  $id,
                    		'transaction_table_id' => PROJECTS,
                    		'transaction_name' => 'Add New project',
                    		'parent_object_id' =>  $id
                    );
                    $this->config->set_item('log_details', $arrLogDetails);
                    log_user_activity ( null, true ); 
                    return $projectDataArray;
                }
		else
		//Add Log activity
			$arrLogDetails = array(
					'type' => ADD_RECORD,
					'description' => 'Add New project',
					'status' => STATUS_FAIL,
					'transaction_id' =>  $id,
					'transaction_table_id' => PROJECTS,
					'transaction_name' => 'Add New project',
					'parent_object_id' =>  $id
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity ( null, true ); 
			return false;
	}
	
	function updateProject($rowData){
		$this->db->where('id',$rowData['id']);
		if($this->db->update('projects',$rowData))
		    return true;
		else
			return false;
	}
	function getCountKols($id){
		$this->db->select('count(distinct(kol_id)) as total_kols');
		$this->db->where('project_id',$id);
		$res = $this->db->get('project_kols');
		//echo $this->db->last_query();
		$row = $res->result();
		return $row[0]->total_kols;
	}
	
	function getKols($id){
		$this->db->select('distinct(kol_id)');
		$this->db->where('project_id',$id);
		$res = $this->db->get('project_kols');
		//echo $this->db->last_query();
		return $res->result();
		
	}
	
	function getIndividualProjectDetails($id){
		$rowData = array();
		$this->db->select('*');
		$this->db->where('id',$id);
		$res = $this->db->get('projects');
		if($res->num_rows() > 0){
			foreach($res->result_array() as $row)
				$rowData = $row;
		}
		return $rowData;
	}
	
	function getProject($id){
		$rowData = array();
                $this->db->select('projects.*,GROUP_CONCAT(project_kols.kol_id) as kol_ids');
		$this->db->join('project_kols','projects.id = project_kols.project_id','left');
		$this->db->where('projects.id',$id);
		$res = $this->db->get('projects');
		if($res->num_rows() > 0){
			foreach($res->result_array() as $row)
				$rowData = $row;
		}
		return $rowData;
	}
	function getProjectKols($projectId=0){
		$arrReturnData	= array();
		$this->db->select('distinct project_kols.kol_id',false);
		$this->db->where('project_kols.project_id',$projectId);
		$resultSet = $this->db->get('project_kols');
		if($resultSet->num_rows() > 0){
			foreach($resultSet->result_array() as $row){
				$arrReturnData[] = $row['kol_id'];
			}
		}
		return $arrReturnData;
	}
	function listProjects(){
		$arrProjects = array();
		$this->db->select('projects.*,first_name,last_name,user_name');
		$this->db->join('client_users','projects.created_by = client_users.id','left');
		$clientId = $this->session->userdata('client_id');
		if($clientId != INTERNAL_CLIENT_ID){
			$this->db->join('kols_project_visibility','kols_project_visibility.project_id = projects.id','left');
			$this->db->where("kols_project_visibility.client_id",$clientId);
		}
		$res = $this->db->get('projects');
		if($res->num_rows() > 0){
			$arrProjects = $res->result_array();
		}
		
		return $arrProjects;
	}
	
	function saveIDKol($arrKol){
// 		$this->db->where('first_name',$arrKol['first_name']);
// 		$this->db->where('middle_name',$arrKol['middle_name']);
// 		$this->db->where('last_name',$arrKol['last_name']);
	    $this->db->where('id',$arrKol['id']);
		$arrKolDetail = $this->db->get('kols');
		if($arrKolDetail->num_rows()!=0){
			$row = $arrKolDetail->row_array(); 
			if($row['imported_as'] != 1 && $row['imported_as'] != 2){
			    $arrKol['imported_as'] = 3;
			}
			$arrKol['profile_type'] = $row['profile_type'];
			$this->db->where('id',$row['id']);
			$this->db->update('kols',$arrKol);
			
			return $row['id'];
		}else{
		    $arrKol['imported_as'] = 1;
			if($this->db->insert('kols',$arrKol)){
				return $this->db->insert_id();
			}else{
				return false;
			}
		}
	}
	
	function getKolId($name){
		$name = str_replace(' ', '', $name);
		$kolId='';
		$kolResultSet=$this->db->query("select id
										from kols
										where replace(CONCAT_WS('',first_name,middle_name,last_name), ' ','')='".addslashes($name)."'");
		foreach($kolResultSet->result_array() as $row){
			$kolId=$row['id'];
		}
		return $kolId;
		
	}
	
	function saveAffiliationDetailByBulk($affiliationDetail){
		
		foreach($affiliationDetail as $row){
			$row['role'] = custom_escape_string($row['role']);
			$row['department'] = custom_escape_string($row['department']);
			$bulkInsert.="('".$row['engagement_id']."','".$row['type']."','".$row['institute_id']."','".$row['department']."','".$row['role']."','".$row['start_date']."','".$row['end_date']."','".$row['created_by']."',
			
			'".$row['created_on']."','".$row['client_id']."','".$row['kol_id']."','".$row['project_id']."','".$row['data_type_indicator']."')".',';;
			//,$row['institute_id'],'".$row['degree']."','".$row['specialty']."','".$row['start_date']."','".$row['end_date']."','".$row['end_date']."')";
		}
		
		$affiliationString=  substr($bulkInsert,0,-1);
		
		$this->db->query('insert into kol_memberships(`engagement_id`,`type`,`institute_id`,`department`,`role`,`start_date`,`end_date`,`created_by`,`created_on`,`client_id`,`kol_id`,`project_id`,`data_type_indicator`) values '.$affiliationString.'');
//		echo $this->db->last_query();
	}
	
	function saveEventDetailByBulk($eventDetail){
		foreach($eventDetail as $row){
		    $row['session_name'] = custom_escape_string($row['session_name']);
		    $row['role'] = custom_escape_string($row['role']);
		    $row['organizer'] = custom_escape_string($row['organizer']);
		    $row['location'] = custom_escape_string($row['location']);
		    $row['address'] = custom_escape_string($row['address']);
		    
		    $row['organizer_type'] = custom_escape_string($row['organizer_type']);
		    $row['session_sponsor'] = custom_escape_string($row['session_sponsor']);
		    $row['sponsor_type'] = custom_escape_string($row['sponsor_type']);
			$bulkInsert.="('".$row['organizer_type']."','".$row['session_sponsor']."','".$row['sponsor_type']."','".$row['type']."','".$row['event_id']."','".$row['event_type']."','".$row['session_type']."',
						'".$row['session_name']."','".$row['role']."','".$row['topic']."','".$row['start']."',
						'".$row['end']."','".$row['organizer']."','".$row['location']."','".$row['address']."',
						'".$row['country_id']."','".$row['state_id']."','".$row['city_id']."','".$row['postal_code']."',
						'".$row['created_by']."','".$row['created_on']."','".$row['client_id']."','".$row['kol_id']."','".$row['data_type_indicator']."','".$row['project_id']."','".$row['activity_type']."')".',';;
			//,$row['institute_id'],'".$row['degree']."','".$row['specialty']."','".$row['start_date']."','".$row['end_date']."','".$row['end_date']."')";
		}
		
		$eventString=  substr($bulkInsert,0,-1);
		//echo $new;
		$this->db->query('insert into kol_events(`organizer_type`,`session_sponsor`,`sponsor_type`,`type`,`event_id`,`event_type`,`session_type`,`session_name`,`role`,`topic`,
						`start`,`end`,`organizer`,`location`,`address`,`country_id`,`state_id`,`city_id`,`postal_code`,`created_by`,`created_on`,`client_id`,`kol_id`,`data_type_indicator`,`project_id`,`activity_type`) values '.$eventString.'');
	}
	
	
	function savePMIDsBulk($arrDetails,$projectId){
		$bulkInsert = '';
		$i=0;
		foreach($arrDetails as $row){
		   
			//Get Existing PMIDs for kol, for this projectid
			$arrExistPmids = $this->getKolPMIDs($row['kol_id'],$projectId);
			$newPmids = array_map('trim', explode(',', $row['pmids']));
			$newPmids = array_unique($newPmids);
			$arrPmids = array();
			if(count($arrExistPmids) > 0){
				$comPmids = array_intersect($newPmids,$arrExistPmids);
				$newPmids = array_diff($newPmids,$comPmids);
			}
			foreach($newPmids as $pmid){
			    if($i>100){
			        $string=  substr($bulkInsert,0,-1);
			        if($string != '')
			            $this->db->query('insert into kol_pmids(`kol_id`,`pmid`,`project_id`) values '.$string.'');
			        $bulkInsert = '';
			        $i=0;
			    }
			    $i++;
				$bulkInsert.="('".$row['kol_id']."','".$pmid."','".$projectId."')".',';;
				//,$row['institute_id'],'".$row['degree']."','".$row['specialty']."','".$row['start_date']."','".$row['end_date']."','".$row['end_date']."')";
			}
		}
		
		$string=  substr($bulkInsert,0,-1);
		if($string != '')
			$this->db->query('insert into kol_pmids(`kol_id`,`pmid`,`project_id`) values '.$string.'');
	}
	
	function getKolPMIDs($kolId,$projectId){
		$arrData = array();
		$this->db->select('pmid');
		$this->db->where('kol_id',$kolId);
		$this->db->where('project_id',$projectId);
		$res = $this->db->get('kol_pmids');
		if($res->num_rows() > 0){
			foreach($res->result_array() as $row)
				$arrData[] = (string)$row['pmid'];
		}
		return $arrData;
	}
	
	function saveCTIDsBulk($arrDetails,$projectId){
		$bulkInsert = '';
		foreach($arrDetails as $row){
			//Get Existing PMIDs for kol, for this projectid
			$arrExistCtids = $this->getKolCTIDs($row['kol_id'],$projectId);
			$newCtids = array_map('trim', explode(',', $row['ctids']));
			$newCtids = array_unique($newCtids);
			if(count($arrExistCtids) > 0){
				$comCtids = array_intersect($newCtids,$arrExistCtids);
				$newCtids = array_diff($newCtids,$comCtids);
			}
			foreach($newCtids as $ctid){
				$bulkInsert.="('".$row['kol_id']."','".$ctid."','".$projectId."')".',';;
				//,$row['institute_id'],'".$row['degree']."','".$row['specialty']."','".$row['start_date']."','".$row['end_date']."','".$row['end_date']."')";
			}
		}
		
		$string=  substr($bulkInsert,0,-1);
		if($string != '')
			$this->db->query('insert into kol_ctids(`kol_id`,`ctid`,`project_id`) values '.$string.'');
	}
	
	function getKolCTIDs($kolId,$projectId){
		$arrData = array();
		$this->db->select('ctid');
		$this->db->where('kol_id',$kolId);
		$this->db->where('project_id',$projectId);
		$res = $this->db->get('kol_ctids');
		if($res->num_rows() > 0){
			foreach($res->result_array() as $row)
				$arrData[] = $row['ctid'];
		}
		return $arrData;
	}
	
	function saveGuidelinesBulk($arrData){
		$bulkInsert = '';
		foreach($arrData as $row){
			$row['name'] = custom_escape_string($row['name']);
			$row['role'] = custom_escape_string($row['role']);
			$row['committee'] = custom_escape_string($row['committee']);
			$bulkInsert.="('".$row['kol_id']."','".$row['name']."','".$row['committee']."','".$row['role']."','".$row['year']."','".$row['type']."','".$row['engagement_id']."','".$row['url']."','".$row['client_id']."','".$row['project_id']."','".$row['created_by']."',
			'".$row['created_on']."')".',';;
		}
		
		$string=  substr($bulkInsert,0,-1);
		if($string != '')
			$this->db->query('insert into kol_guidelines(`kol_id`,`name`,`committee`,`role`,`year`,`type`,`engagement_id`,`url`,`client_id`,`project_id`,`created_by`,`created_on`) values '.$string.'');
	}
	
	function saveProjectKol($projKolDetails){
		$this->db->where('project_id',$projKolDetails['project_id']);
		$this->db->where('kol_id',$projKolDetails['kol_id']);
		$arrKolDetail = $this->db->get('project_kols');
		if($arrKolDetail->num_rows()!=0){
			$row = $arrKolDetail->row_array(); 
			
			return true;
		}else{
			if($this->db->insert('project_kols',$projKolDetails))
				return true;
			else
				return false;
		}
		
		
	}
	
	function getKolsByAffiliationsCount($arrFilters){
		
		if(isset($arrFilters['industry']) && $arrFilters['industry']!= '' && $arrFilters['category'] != 'industry'){
			$arrIDs = $this->getIndustryKolIds($arrFilters);
			if(!empty($arrIDs)){
			 $this->db->where_in('kol_memberships.kol_id',$arrIDs);
			}
		}
		$arrData = array();
		$select = "kols.id,kols.unique_id, salutation, first_name, middle_name, last_name,kols.profile_type,
					COUNT(CASE WHEN kol_memberships.type = 'industry' and kol_memberships.engagement_id != '11' THEN kol_memberships.kol_id END) AS numia, 
					COUNT(CASE WHEN kol_memberships.type = 'association' and kol_memberships.engagement_id != '11' THEN kol_memberships.kol_id END) AS numas,
					COUNT(CASE WHEN kol_memberships.type = 'others' and kol_memberships.engagement_id != '11'  THEN kol_memberships.kol_id END) AS numeb,
					COUNT(CASE WHEN kol_memberships.type = 'university' and kol_memberships.engagement_id != '11' THEN kol_memberships.kol_id END) AS numec,
                    COUNT(CASE WHEN kol_memberships.engagement_id = '11' THEN kol_memberships.kol_id END) AS numgc,
                    COUNT(CASE WHEN kol_memberships.type IN ('industry','university','government','others','association') THEN kol_memberships.kol_id END) AS numed";
		$this->db->select($select,false);
		$this->db->join('kols','kol_memberships.kol_id = kols.id','left');
		$this->db->join('project_kols','kol_memberships.kol_id = project_kols.kol_id','left');
		$this->db->where('is_imported',2);
		//if(isset($arrFilters['aff_type']))
			//$this->db->where('type',$arrFilters['aff_type']);
		if(isset($arrFilters['project']) && $arrFilters['project'] != '')
			$this->db->where('kol_memberships.project_id',$arrFilters['project']);
		else
		    $this->db->where('kol_memberships.project_id >',0);
		if(isset($arrFilters['specialty']) && $arrFilters['specialty']!= '' && $arrFilters['category'] != 'specialty')
			$this->db->where_in('kols.specialty',$arrFilters['specialty']);
		if(isset($arrFilters['country']) && $arrFilters['country']!= '' && $arrFilters['category'] != 'country')
			$this->db->where_in('kols.country_id',$arrFilters['country']);
		if(isset($arrFilters['state']) && $arrFilters['state']!= '' && $arrFilters['state'] != 'state')
		    $this->db->where_in('kols.state_id',$arrFilters['state']);
		if(isset($arrFilters['region']) && $arrFilters['region']!= '' && $arrFilters['category'] != 'region'){
			$this->db->join('countries','kols.country_id = countries.CountryID','left');
			$this->db->where_in('countries.GlobalRegion',$arrFilters['region']);
		}
		if(isset($arrFilters['city']) && $arrFilters['city']!= '' && $arrFilters['category'] != 'city')
			$this->db->where_in('kols.city_id',$arrFilters['city']);
		if(isset($arrFilters['aff_year_range']) && $arrFilters['aff_year_range'] != ''){
			$yearEls = explode(",",$arrFilters['aff_year_range']);
			if($yearEls[0] != 0){
				$wherBetween="(
					((start_date != '' AND start_date BETWEEN $yearEls[0] AND $yearEls[1])OR (end_date != '' AND end_date BETWEEN $yearEls[0] AND $yearEls[1])) 
					OR (start_date = '' AND end_date BETWEEN $yearEls[0] AND $yearEls[1])
					OR (end_date = '' AND start_date BETWEEN $yearEls[0] AND $yearEls[1])
					OR (start_date = '' AND end_date = '')
						OR (start_date >= YEAR(CURDATE()))
				)";
				
				//$wherBetween="((start_date >= $yearEls[0] AND end_date <= $yearEls[1]) OR (start_date = '' AND end_date = ''))";
				$this->db->where($wherBetween);
			}
		}elseif(isset($arrFilters['year_range']) && $arrFilters['year_range'] != ''){
			$yearEls = explode(",",$arrFilters['year_range']);
			if($yearEls[0] != 0){
				$wherBetween="(
					((start_date != '' AND start_date BETWEEN $yearEls[0] AND $yearEls[1])OR (end_date != '' AND end_date BETWEEN $yearEls[0] AND $yearEls[1])) 
					OR (start_date = '' AND end_date BETWEEN $yearEls[0] AND $yearEls[1])
					OR (end_date = '' AND start_date BETWEEN $yearEls[0] AND $yearEls[1])
					OR (start_date = '' AND end_date = '')
						OR (start_date >= YEAR(CURDATE()))
				)";
				//$wherBetween="((start_date >= $yearEls[0] AND end_date <= $yearEls[1]) OR (start_date = '' AND end_date = ''))";
				$this->db->where($wherBetween);
			}
		}
		$this->db->where('(kols.deleted_by = 0 or kols.deleted_by is null)');
		$this->db->where('(kols.deleted_optin_no_response = 0 or kols.deleted_optin_no_response is null)','',false);
		//Priority condition
		if($arrFilters['wyn'] == 'yes' && ($arrFilters['aff_priority'] != '')){
		    if($arrFilters['guideline_all'] != 0){
		        $this->db->join('guidelines_priority','guidelines_priority.guideline_id = kol_memberships.id','left');
		        $this->db->where('guidelines_priority.priority',$arrFilters['aff_priority']);
		    }else{
    // 			$this->db->join('institutions','kol_memberships.institute_id = institutions.id','left');
    			$this->db->join('institutions_priority','institutions_priority.institution_id = kol_memberships.institute_id','left');
    			$this->db->where('institutions_priority.priority',$arrFilters['aff_priority']);
		    }
		}
		
		//Engagement type Condition
		//$this->load->model('engagement_type');
		//$engagementId					= $this->engagement_type->getEngagementId('Guideline');
		//$this->db->where('engagement_id !=',11);
		
		$this->db->group_by('kol_memberships.kol_id');
		//$this->db->order_by('numc','DESC');
		
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
		    $this->db->join('kols_project_visibility','kols_project_visibility.project_id = project_kols.project_id','left');
		    $this->db->where("kols_project_visibility.client_id",$client_id);
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		
		$res = $this->db->get('kol_memberships');
// 		pr($this->db->last_query()); exit;
		if($res->num_rows() > 0){
			foreach($res->result_array() as $row){
				$arrData[$row['id']] = $row;
			}
		}
		
		return $arrData;
	}
	
	function getKolsByEventsCount($arrFilters){
		if(isset($arrFilters['industry']) && $arrFilters['industry']!= '' && $arrFilters['category'] != 'industry'){
			$arrIDs = $this->getIndustryKolIds($arrFilters);
			if(!empty($arrIDs)){
				$this->db->where_in('kol_events.kol_id',$arrIDs);
			}
		}
		$arrData = array();
		$select = "kols.id,kols.unique_id, salutation, first_name, middle_name, last_name, kols.profile_type,
					COUNT(CASE WHEN kol_events.activity_type = 'Speaking' THEN kol_events.kol_id END) AS numspc,
					COUNT(CASE WHEN kol_events.activity_type = 'Organizing Committee' THEN kol_events.kol_id END) AS numocc,
                    COUNT(CASE WHEN kol_events.activity_type IN ('Speaking','Organizing Committee') THEN kol_events.kol_id END) AS numevc";
		$this->db->select($select);
		$this->db->join('kols','kol_events.kol_id = kols.id','left');
		$this->db->join('project_kols','kol_events.kol_id = project_kols.kol_id','left');
		$this->db->where('is_imported',2);
		//if(isset($arrFilters['aff_type']))
			//$this->db->where('type',$arrFilters['aff_type']);
		if(isset($arrFilters['project']) && $arrFilters['project'] != '')
			$this->db->where('kol_events.project_id',$arrFilters['project']);
		else
		    $this->db->where('kol_events.project_id >',0);
		if(isset($arrFilters['specialty']) && $arrFilters['specialty']!= '' && $arrFilters['category'] != 'specialty')
			$this->db->where_in('kols.specialty',$arrFilters['specialty']);
		if(isset($arrFilters['country']) && $arrFilters['country']!= '' && $arrFilters['category'] != 'country')
			$this->db->where_in('kols.country_id',$arrFilters['country']);
		if(isset($arrFilters['state']) && $arrFilters['state']!= '' && $arrFilters['state'] != 'state')
		    $this->db->where_in('kols.state_id',$arrFilters['state']);
		if(isset($arrFilters['region']) && $arrFilters['region']!= '' && $arrFilters['category'] != 'region'){
			$this->db->join('countries','kols.country_id = countries.CountryID','left');
			$this->db->where_in('countries.GlobalRegion',$arrFilters['region']);
		}
		if(isset($arrFilters['city']) && $arrFilters['city']!= '' && $arrFilters['category'] != 'city')
			$this->db->where_in('kols.city_id',$arrFilters['city']);
		if(isset($arrFilters['events_year_range']) && $arrFilters['events_year_range'] != ''){
			$yearEls = explode(",",$arrFilters['events_year_range']);
			if($yearEls[0] != 0){
				$wherBetween="(
					((YEAR(start) != '' AND YEAR(start) BETWEEN $yearEls[0] AND $yearEls[1])OR (YEAR(end) != '' AND YEAR(end) BETWEEN $yearEls[0] AND $yearEls[1])) 
					OR (YEAR(start) = '' AND YEAR(end) BETWEEN $yearEls[0] AND $yearEls[1])
					OR (YEAR(end) = '' AND YEAR(start) BETWEEN $yearEls[0] AND $yearEls[1])
					OR (YEAR(start) = '' AND YEAR(end) = '')
                    OR (YEAR(start) is null AND YEAR(end) is null)
						OR (year(START) >= YEAR(CURDATE()))
				)";
				
				//$wherBetween="((YEAR(start) >= $yearEls[0] AND YEAR(end) <= $yearEls[1]) OR (start = '' AND end = ''))";
				$this->db->where($wherBetween);
			}
		}elseif(isset($arrFilters['year_range']) && $arrFilters['year_range'] != ''){
			$yearEls = explode(",",$arrFilters['year_range']);
			if($yearEls[0] != 0){
				$wherBetween="(
					((YEAR(start) != '' AND YEAR(start) BETWEEN $yearEls[0] AND $yearEls[1])OR (YEAR(end) != '' AND YEAR(end) BETWEEN $yearEls[0] AND $yearEls[1])) 
					OR (YEAR(start) = '' AND YEAR(end) BETWEEN $yearEls[0] AND $yearEls[1])
					OR (YEAR(end) = '' AND YEAR(start) BETWEEN $yearEls[0] AND $yearEls[1])
					OR (YEAR(start) = '' AND YEAR(end) = '')
                    OR (YEAR(start) is null AND YEAR(end) is null)
						OR (year(START) >= YEAR(CURDATE()))
				)";
				
				//$wherBetween="((YEAR(start) >= $yearEls[0] AND YEAR(end) <= $yearEls[1]) OR (start = '' AND end = ''))";
				$this->db->where($wherBetween);
			}
		}
		// Keywords search conditions
		if(isset($arrFilters['meshTermIds']) && $arrFilters['meshTermIds'] !='' && count($arrFilters['meshTermIds']) > 0){
		    $this->db->join('event_topics','kol_events.topic = event_topics.id','left');
		    //$this->db->where_in('event_topics.mesh_dictionary_term_id',$arrFilters['meshTermIds']);
		    $where = '';
		    foreach($arrFilters['meshTermIds'] as $mesTermId){
		      $where .= "(FIND_IN_SET('$mesTermId',event_topics.mesh_dictionary_term_id) !=0) OR";
		    }
		    if($where != ''){
		        $where = substr($where,0,-3);
		        $where = "(".$where.")";
		        $this->db->where($where);
		    }
		}else if(isset($arrFilters['keywords']) && $arrFilters['keywords'] !='' && count($arrFilters['keywords']) > 0){
			$this->db->join('event_topics','kol_events.topic = event_topics.id','left');
			$wherLike = "";
			foreach($arrFilters['keywords'] as $word){
				if($word != ''){
					$wherLike .= 'event_topics.name LIKE "%'.$word.'%" OR ';
				}
			}
			if($wherLike != ''){
				$wherLike = substr($wherLike,0,-3);
				$wherLike = "(".$wherLike.")";
				$this->db->where($wherLike);
			}
		}
		
		//Priority condition
		if($arrFilters['wyn'] == 'yes' && ($arrFilters['events_priority'] != '')){
// 			$this->db->join('events','kol_events.event_id = events.id','left');
			$this->db->join('events_priority','events_priority.event_id = kol_events.event_id','left');
			$this->db->where('events_priority.priority',$arrFilters['events_priority']);
		}
		
		$this->db->group_by('kol_events.kol_id');
		$this->db->order_by('numevc','DESC');
		
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
		    $this->db->join('kols_project_visibility','kols_project_visibility.project_id = project_kols.project_id','left');
		    $this->db->where("kols_project_visibility.client_id",$client_id);
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		$this->db->where('(kols.deleted_optin_no_response = 0 or kols.deleted_optin_no_response is null)','',false);
		$res = $this->db->get('kol_events');
//		pr($this->db->last_query());
		if($res->num_rows() > 0){
			foreach($res->result_array() as $row){
				$arrData[$row['id']] = $row;
			}
		}
		
		return $arrData;
	}
	
	function getKolPublicationCountsByAuthPos($arrFilters){
		if(isset($arrFilters['industry']) && $arrFilters['industry']!= '' && $arrFilters['category'] != 'industry'){
			$arrIDs = $this->getIndustryKolIds($arrFilters);
			if(!empty($arrIDs)){
				$this->db->where_in('kol_publications.kol_id',$arrIDs);
			}
		}
		$arrData = array();
		$isPublicationJoined = false;
		$select = "kols.id,kols.unique_id, salutation, first_name, middle_name, last_name,kols.profile_type,
					COUNT(DISTINCT CASE WHEN kol_publications.position_category = 'sa' THEN kol_publications.pub_id END) AS numsa,
					COUNT(DISTINCT CASE WHEN kol_publications.position_category = 'fa' THEN kol_publications.pub_id END) AS numfa,
					COUNT(DISTINCT CASE WHEN kol_publications.position_category = 'ma' THEN kol_publications.pub_id END) AS numma,
					COUNT(DISTINCT CASE WHEN kol_publications.position_category = 'la' THEN kol_publications.pub_id END) AS numla,
					COUNT(DISTINCT CASE WHEN kol_publications.position_category IN ('fa','sa','la') THEN kol_publications.pub_id END) AS leadc,
					COUNT(DISTINCT kol_publications.pub_id) AS nump";
		$this->db->select($select,false);
		$this->db->join('kols','kol_publications.kol_id = kols.id','left');
		$this->db->join('project_kols','kol_publications.kol_id = project_kols.kol_id','left');
		$this->db->where('is_imported',2);
		if(isset($arrFilters['project']) && $arrFilters['project'] != '')
			$this->db->where('kol_publications.project_id',$arrFilters['project']);
		else
		    $this->db->where('kol_publications.project_id >',0);
		if(isset($arrFilters['specialty']) && $arrFilters['specialty']!= '' && $arrFilters['category'] != 'specialty')
			$this->db->where_in('kols.specialty',$arrFilters['specialty']);
		if(isset($arrFilters['country']) && $arrFilters['country']!= '' && $arrFilters['category'] != 'country')
			$this->db->where_in('kols.country_id',$arrFilters['country']);
		if(isset($arrFilters['state']) && $arrFilters['state']!= '' && $arrFilters['state'] != 'state')
		    $this->db->where_in('kols.state_id',$arrFilters['state']);
		if(isset($arrFilters['region']) && $arrFilters['region']!= '' && $arrFilters['category'] != 'region'){
			$this->db->join('countries','kols.country_id = countries.CountryID','left');
			$this->db->where_in('countries.GlobalRegion',$arrFilters['region']);
		}
		if(isset($arrFilters['city']) && $arrFilters['city']!= '' && $arrFilters['category'] != 'city')
			$this->db->where_in('kols.city_id',$arrFilters['city']);
		//Year range condition
		if(isset($arrFilters['pubs_year_range']) && $arrFilters['pubs_year_range'] != ''){
			$yearEls = explode(",",$arrFilters['pubs_year_range']);
			if($yearEls[0] != 0){
				$this->db->join('publications','kol_publications.pub_id = publications.id','left');
				$wherBetween="(YEAR(publications.created_date) BETWEEN '$yearEls[0]' AND '$yearEls[1]' OR YEAR(publications.created_date)='0')";
				$this->db->where($wherBetween);
				$isPublicationJoined = true;
			}
		}elseif(isset($arrFilters['year_range']) && $arrFilters['year_range'] != ''){
			$yearEls = explode(",",$arrFilters['year_range']);
			if($yearEls[0] != 0){
				$this->db->join('publications','kol_publications.pub_id = publications.id','left');
				$wherBetween="(YEAR(publications.created_date) BETWEEN '$yearEls[0]' AND '$yearEls[1]' OR YEAR(publications.created_date)='0')";
				$this->db->where($wherBetween);
				$isPublicationJoined = true;
			}
		}
		//Keywords condition
	if(isset($arrFilters['keywords']) && $arrFilters['keywords'] !='' && count($arrFilters['keywords']) > 0){
// 			$this->db->join('publication_mesh_terms','publication_mesh_terms.pub_id = publications.id','left');
// 			$this->db->join('pubmed_mesh_terms','publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
		    $this->db->join('publication_mesh_terms', 'publication_mesh_terms.pub_id = publications.id','left');
		    $this->db->join('pubmed_mesh_terms', 'publication_mesh_terms.term_id = pubmed_mesh_terms.id','left');
		    $this->db->join('publication_substances','publication_substances.pub_id=publications.id','left');
		    $this->db->join('pubmed_substances','pubmed_substances.id=publication_substances.substance_id','left');
			$wherLike = "";
			foreach($arrFilters['keywords'] as $word){
				if($word != ''){
				    $wherLike .= '(publications.article_title  LIKE "%'.$word.'%" OR  publications.abstract_text  LIKE "%'.$word.'%" OR pubmed_substances.name LIKE "%'.$word.'%" OR pubmed_mesh_terms.term_name LIKE "%'.$word.'%") OR';
// 					$wherLike .= 'term_name LIKE "%'.$word.'%" OR ';
// 				    $this->db->where("(publications.article_title  LIKE '%$word%' OR  publications.abstract_text  LIKE '%$word%' OR pubmed_substances.name LIKE '%$word%' OR pubmed_mesh_terms.term_name LIKE '%$word%')");
				}
			}
			if($wherLike != ''){
				$wherLike = substr($wherLike,0,-3);
				$wherLike = "(".$wherLike.")";
				$this->db->where($wherLike);
			}
		}
		
		//Priority condition
		if($arrFilters['wyn'] == 'yes' && ($arrFilters['pub_priority'] != '')){
			if(!$isPublicationJoined)
				$this->db->join('publications','kol_publications.pub_id = publications.id','left');
// 			$this->db->join('pubmed_journals','publications.journal_id = pubmed_journals.id','left');
			$this->db->join('pubmed_journals_priority','pubmed_journals_priority.journal_id = publications.journal_id','left');
			$this->db->where('pubmed_journals_priority.priority',$arrFilters['pub_priority']);
		}
			
		
		$this->db->where('kol_publications.is_verified',1);
		$this->db->group_by('kol_publications.kol_id');
		$this->db->order_by('nump','DESC');
		
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
		    $this->db->join('kols_project_visibility','kols_project_visibility.project_id = project_kols.project_id','left');
		    $this->db->where("kols_project_visibility.client_id",$client_id);
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		$this->db->where('(kols.deleted_optin_no_response = 0 or kols.deleted_optin_no_response is null)','',false);
		$res = $this->db->get('kol_publications');
// 		pr($this->db->last_query());exit;
		if($res->num_rows() > 0){
			foreach($res->result_array() as $row){
				$arrData[$row['id']] = $row;
			}
		}
		
		return $arrData;
	}
	
	function getKolGuidelinesCount($arrFilters){
		if(isset($arrFilters['industry']) && $arrFilters['industry']!= '' && $arrFilters['category'] != 'industry'){
			$arrIDs = $this->getIndustryKolIds($arrFilters);
			if(!empty($arrIDs)){
				$this->db->where_in('kol_memberships.kol_id',$arrIDs);
			}
		}
		$arrData = array();
		$select = "kols.id,kols.unique_id, salutation, first_name, middle_name, last_name,kols.profile_type,COUNT(kol_memberships.kol_id) AS numgc";
		$this->db->select($select);
		$this->db->join('kols','kol_memberships.kol_id = kols.id','left');
		$this->db->join('project_kols','kol_memberships.kol_id = project_kols.kol_id','left');
		$this->db->where('is_imported',2);
		//if(isset($arrFilters['aff_type']))
			//$this->db->where('type',$arrFilters['aff_type']);
		if(isset($arrFilters['project']) && $arrFilters['project'] != '')
			$this->db->where('kol_memberships.project_id',$arrFilters['project']);
		else
		    $this->db->where('kol_memberships.project_id >',0);
		if(isset($arrFilters['specialty']) && $arrFilters['specialty']!= '' && $arrFilters['category'] != 'specialty')
			$this->db->where_in('kols.specialty',$arrFilters['specialty']);
		if(isset($arrFilters['state']) && $arrFilters['state']!= '' && $arrFilters['state'] != 'state')
		    $this->db->where_in('kols.state_id',$arrFilters['state']);
		if(isset($arrFilters['country']) && $arrFilters['country']!= '' && $arrFilters['category'] != 'country')
			$this->db->where_in('kols.country_id',$arrFilters['country']);
		if(isset($arrFilters['region']) && $arrFilters['region']!= '' && $arrFilters['category'] != 'region'){
			$this->db->join('countries','kols.country_id = countries.CountryID','left');
			$this->db->where_in('countries.GlobalRegion',$arrFilters['region']);
		}
		if(isset($arrFilters['city']) && $arrFilters['city']!= '' && $arrFilters['category'] != 'city')
			$this->db->where_in('kols.city_id',$arrFilters['city']);
		if(isset($arrFilters['guideline_year_range']) && $arrFilters['guideline_year_range'] != ''){
			$yearEls = explode(",",$arrFilters['guideline_year_range']);
			if($yearEls[0] != 0){
				$wherBetween="((start_date >= $yearEls[0] AND end_date <= $yearEls[1]) OR (start_date = '' AND end_date = ''))";
				$this->db->where($wherBetween);
			}
		}elseif(isset($arrFilters['year_range']) && $arrFilters['year_range'] != ''){
			$yearEls = explode(",",$arrFilters['year_range']);
			if($yearEls[0] != 0){
				$wherBetween="((start_date >= $yearEls[0] AND end_date <= $yearEls[1]) OR (start_date = '' AND end_date = ''))";
				$this->db->where($wherBetween);
			}
		}
		
		//Priority condition
		if($arrFilters['wyn'] == 'yes' && ($arrFilters['guideline_priority'] != '')){
// 			$this->db->where('kol_memberships.priority',$arrFilters['guideline_priority']);
			$this->db->join('guidelines_priority','guidelines_priority.institute_id = kol_memberships.institute_id','left');
			$this->db->where('guidelines_priority.priority',$arrFilters['guideline_priority']);
		}
		
		//Engagement type Condition
		//$this->load->model('engagement_type');
		//$engagementId					= $this->engagement_type->getEngagementId('Guideline');
		$this->db->where('engagement_id',11);
		
		$this->db->group_by('kol_memberships.kol_id');
		//$this->db->order_by('numc','DESC');
		
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
		    $this->db->join('kols_project_visibility','kols_project_visibility.project_id = project_kols.project_id','left');
		    $this->db->where("kols_project_visibility.client_id",$client_id);
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		$this->db->where('(kols.deleted_optin_no_response = 0 or kols.deleted_optin_no_response is null)','',false);
		$res = $this->db->get('kol_memberships');
		//pr($this->db->last_query());
		if($res->num_rows() > 0){
			foreach($res->result_array() as $row){
				$arrData[$row['id']] = $row;
			}
		}
		
		return $arrData;
	}
	
	function getKolTrialsCount($arrFilters){
		if(isset($arrFilters['industry']) && $arrFilters['industry']!= '' && $arrFilters['category'] != 'industry'){
			$arrIDs = $this->getIndustryKolIds($arrFilters);
			if(!empty($arrIDs)){
				$this->db->where_in('kol_clinical_trials.kol_id',$arrIDs);
			}
		}
		$arrData = array();
		/*$select = "kols.id, salutation, first_name, middle_name, last_name,
					COUNT(DISTINCT CASE WHEN kol_clinical_trials.role = 'Principal Investigator' THEN kol_clinical_trials.cts_id END) AS numpi,
					COUNT(DISTINCT CASE WHEN kol_clinical_trials.role != 'Principal Investigator' THEN kol_clinical_trials.cts_id END) AS numci,
					COUNT(DISTINCT kol_clinical_trials.cts_id) AS numtc";*/
		$select = "kols.id,kols.unique_id, salutation, first_name, middle_name, last_name,kols.profile_type,
					COUNT(DISTINCT kol_clinical_trials.cts_id) AS numtc";
		$this->db->select($select,false);
		$this->db->join('kols','kol_clinical_trials.kol_id = kols.id','left');
		$this->db->join('project_kols','kol_clinical_trials.kol_id = project_kols.kol_id','left');
		$this->db->where('is_imported',2);
		if(isset($arrFilters['project']) && $arrFilters['project'] != '')
			$this->db->where('kol_clinical_trials.project_id',$arrFilters['project']);
		else
		    $this->db->where('kol_clinical_trials.project_id >',0);
		if(isset($arrFilters['specialty']) && $arrFilters['specialty']!= '' && $arrFilters['category'] != 'specialty')
			$this->db->where_in('kols.specialty',$arrFilters['specialty']);
		if(isset($arrFilters['country']) && $arrFilters['country']!= '' && $arrFilters['category'] != 'country')
			$this->db->where_in('kols.country_id',$arrFilters['country']);
		if(isset($arrFilters['state']) && $arrFilters['state']!= '' && $arrFilters['state'] != 'state')
		    $this->db->where_in('kols.state_id',$arrFilters['state']);
		if(isset($arrFilters['region']) && $arrFilters['region']!= '' && $arrFilters['category'] != 'region'){
			$this->db->join('countries','kols.country_id = countries.CountryID','left');
			$this->db->where_in('countries.GlobalRegion',$arrFilters['region']);
		}
		if(isset($arrFilters['city']) && $arrFilters['city']!= '' && $arrFilters['category'] != 'city')
			$this->db->where_in('kols.city_id',$arrFilters['city']);
		//Year range condition
		if(isset($arrFilters['trials_year_range']) && $arrFilters['trials_year_range'] != ''){
			$yearEls = explode(",",$arrFilters['trials_year_range']);
			if($yearEls[0] != 0){
			    $this->db->join('clinical_trials','kol_clinical_trials.cts_id = clinical_trials.id','left');
			    $wherBetween="((RIGHT(start_date,4) >= $yearEls[0] OR RIGHT(end_date,4) <= $yearEls[1]) OR (start_date = '' AND end_date = ''))";
			    $this->db->where($wherBetween);
			}
		}elseif(isset($arrFilters['year_range']) && $arrFilters['year_range'] != ''){
			$yearEls = explode(",",$arrFilters['year_range']);
			if($yearEls[0] != 0){
				$this->db->join('clinical_trials','kol_clinical_trials.cts_id = clinical_trials.id','left');
				$wherBetween="((RIGHT(start_date,4) >= $yearEls[0] OR RIGHT(end_date,4) <= $yearEls[1]) OR (start_date = '' AND end_date = ''))";
				$this->db->where($wherBetween);
			}
		}
		//Keywords condition
		if(isset($arrFilters['keywords']) && $arrFilters['keywords'] !='' && count($arrFilters['keywords']) > 0){
			$this->db->join('ct_mesh_terms','kol_clinical_trials.cts_id = ct_mesh_terms.cts_id','left');
			$this->db->join('cts_mesh_terms','ct_mesh_terms.term_id = cts_mesh_terms.id','left');
			$wherLike = "";
			foreach($arrFilters['keywords'] as $word){
				if($word != ''){
					$wherLike .= 'term_name LIKE "%'.$word.'%" OR ';
				}
			}
			if($wherLike != ''){
				$wherLike = substr($wherLike,0,-3);
				$wherLike = "(".$wherLike.")";
				$this->db->where($wherLike);
			}
		}
		
		//Priority condition
		if($arrFilters['wyn'] == 'yes' && ($arrFilters['trials_priority'] != '')){
			$this->db->join('ct_sponsers','kol_clinical_trials.cts_id = ct_sponsers.cts_id','left');
// 			$this->db->join('cts_sponsers','ct_sponsers.sponser_id = cts_sponsers.id','left');
			$this->db->join('sponsers_priority','sponsers_priority.sponser_id = ct_sponsers.sponser_id','left');
			$this->db->where('sponsers_priority.priority',$arrFilters['trials_priority']);
		}
			
		$this->db->group_by('kol_clinical_trials.kol_id');
		$this->db->order_by('numtc','DESC');
		$this->db->where('kol_clinical_trials.is_verified',1);
		
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
		    $this->db->join('kols_project_visibility','kols_project_visibility.project_id = project_kols.project_id','left');
		    $this->db->where("kols_project_visibility.client_id",$client_id);
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		$this->db->where('(kols.deleted_optin_no_response = 0 or kols.deleted_optin_no_response is null)','',false);
		
		$res = $this->db->get('kol_clinical_trials');
		//pr($this->db->last_query());exit;
		if($res->num_rows() > 0){
			foreach($res->result_array() as $row){
				$arrData[$row['id']] = $row;
			}
		}
		
		return $arrData;
	}
	
	function getKolsByInfluencesCount($arrFilters){
		$arrData = array();
		$select = "kols.id,kols.unique_id, salutation, first_name, middle_name, last_name,kols.profile_type,
					COUNT(survey_kol_names.kol_id) AS numic";
		$this->db->select($select);
		$this->db->join('survey_kol_names','survey_answers.nominee_id = survey_kol_names.id','left');
		$this->db->join('kols','survey_kol_names.kol_id = kols.id','left');
		$this->db->join('project_kols','survey_answers.kol_id = project_kols.kol_id','left');
		$this->db->where('is_imported',2);
		//if(isset($arrFilters['aff_type']))
			//$this->db->where('type',$arrFilters['aff_type']);
		//if(isset($arrFilters['project']) && $arrFilters['project'] != '')
			//$this->db->where('survey_answers.project_id',$arrFilters['project']);
		if(isset($arrFilters['specialty']) && $arrFilters['specialty']!= '' && $arrFilters['category'] != 'specialty')
			$this->db->where_in('kols.specialty',$arrFilters['specialty']);
		if(isset($arrFilters['country']) && $arrFilters['country']!= '' && $arrFilters['category'] != 'country')
			$this->db->where_in('kols.country_id',$arrFilters['country']);
		if(isset($arrFilters['state']) && $arrFilters['state']!= '' && $arrFilters['state'] != 'state')
		    $this->db->where_in('kols.state_id',$arrFilters['state']);
		if(isset($arrFilters['region']) && $arrFilters['region']!= '' && $arrFilters['category'] != 'region'){
			$this->db->join('countries','kols.country_id = countries.CountryID','left');
			$this->db->where_in('countries.GlobalRegion',$arrFilters['region']);
		}
		if(isset($arrFilters['city']) && $arrFilters['city']!= '' && $arrFilters['category'] != 'city')
			$this->db->where_in('kols.city_id',$arrFilters['city']);
				
		if(isset($arrFilters['surveys_priority']) && $arrFilters['surveys_priority']!= '')
			$this->db->where('survey_answers.survey_id',$arrFilters['surveys_priority']);
			
		$this->db->group_by('survey_kol_names.kol_id');
		//$this->db->order_by('numc','DESC');
		
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
		    $this->db->join('kols_project_visibility','kols_project_visibility.project_id = project_kols.project_id','left');
		    $this->db->where("kols_project_visibility.client_id",$client_id);
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		$this->db->where('(kols.deleted_optin_no_response = 0 or kols.deleted_optin_no_response is null)','',false);
		$res = $this->db->get('survey_answers');
		//pr($this->db->last_query());
		if($res->num_rows() > 0){
			foreach($res->result_array() as $row){
				$arrData[$row['id']] = $row;
			}
		}
		return $arrData;
	}
	
	function getClientKolIds(){
	    $clientId = $this->session->userdata('client_id');
	    $arrIds = array();
	    $this->db->distinct();
	    $this->db->select('user_kols.kol_id');
	    $this->db->where('client_users.client_id',$clientId);
	    //$this->db->where('kols.status',COMPLETED);
	    $this->db->join("client_users","user_kols.user_id = client_users.id","left");
	    $this->db->join("kols","user_kols.kol_id = kols.id","left");
	    $result = $this->db->get('user_kols');
	    foreach($result->result_array() as $row){
	        $arrIds[] = (int)$row['kol_id'];
	    }
	    // echo $this->db->last_query();exit;
	    return $arrIds;
	}
	
	
	function getKolCountsByCategory($arrFilters,$cat=null,$offset){
	    ini_set('memory_limit', "-1");
	    ini_set("max_execution_time", 0);
	    //if ignore mykols
	    
		$arrData = array();
		$isCountryJoined = false;
		//Add Select statements based on condition
		if(!isset($arrFilters['docount'])){
			if($arrFilters['category'] == 'specialty'){
				$this->db->select("specialties.id,specialties.specialty as name,COUNT(DISTINCT kols.id) AS count");
				$this->db->join('specialties','kols.specialty = specialties.id','left');
			}
			if($arrFilters['category'] == 'country'){
				$this->db->select("countries.CountryID as id,countries.Country as name,COUNT(DISTINCT kols.id) AS count");
				$this->db->join('countries','kols.country_id = countries.CountryID','left');
				$isCountryJoined = true;
			}
			 if($arrFilters['category'] == 'state'){
			    $this->db->select("regions.RegionID as id,regions.Region as name,COUNT(DISTINCT kols.id) AS count");
			    $this->db->join('regions','kols.state_id = regions.RegionID','left');
			    
			} 
			if($arrFilters['category'] == 'region'){
				$this->db->select("countries.GlobalRegion as id,countries.GlobalRegion as name,COUNT(DISTINCT kols.id) AS count");
				if(!$isCountryJoined)
					$this->db->join('countries','kols.country_id = countries.CountryID','left');
			}
			if($arrFilters['category'] == 'city'){
				$this->db->select("cities.CityID as id,cities.City as name,COUNT(DISTINCT kols.id) AS count");
				if(!$isCountryJoined)
					$this->db->join('cities','kols.city_id = cities.CityID','left');
			}
			if($arrFilters['category'] == 'industry'){
				$this->db->select("institutions.id as id,institutions.name as name,COUNT(DISTINCT kol_memberships.kol_id) AS count");
				$this->db->join('kol_memberships','kols.id = kol_memberships.kol_id','left');
				$this->db->join('institutions','kol_memberships.institute_id = institutions.id','left');
				$this->db->group_by('kol_memberships.institute_id');
				if(isset($arrFilters['project']) && $arrFilters['project'] != ''){
				    $this->db->where_in('kol_memberships.project_id',$arrFilters['project']);
				}else{
				    $this->db->where('kol_memberships.project_id >',0);
				}
				$this->db->where('kol_memberships.type','Industry');
			}
			if($arrFilters['category'] == 'org_ids'){
			    //             	var_dump($arrFilters);
			    //             	pr($arrFilters);
			    $this->db->select("organizations.id,organizations.name as name,COUNT(DISTINCT kols.id) AS count");
			    $this->db->join('organizations','kols.org_id = organizations.id','left');
			    $client_id = $this->session->userdata ( 'client_id' );
			    if ($client_id !== INTERNAL_CLIENT_ID) {
			        $this->db->join ( 'org_client_visibility', 'organizations.id = org_client_visibility.org_id', 'left' );
			        $this->db->where ( array (
			            'org_client_visibility.client_id' => $client_id,
			            'org_client_visibility.is_visible' => 1
			        ) );
			    }
			    // 				var_dump($arrFilters['saved_filter']);
			    /* if(!isset($arrFilters['saved_filter'])){
			        if(!empty($offset))
			            $this->db->limit(5,$offset);
			            //                                     $this->db->limit(5,$offset);
			    } */
			}
		}else{
		    if($arrFilters['category'] != 'org_ids'){
			 $this->db->select("COUNT(DISTINCT kols.id) as count,kols.unique_id");
		    }else{
		        $this->db->select("COUNT(DISTINCT kols.id) as count,kols.unique_id");
		        $this->db->join('organizations','kols.org_id = organizations.id','left');
		        $client_id = $this->session->userdata ( 'client_id' );
		        /*if ($client_id !== INTERNAL_CLIENT_ID) {
		            $this->db->join ( 'org_client_visibility', 'organizations.id = org_client_visibility.org_id', 'left' );
		            $this->db->where ( array (
		                'org_client_visibility.client_id' => $client_id,
		                'org_client_visibility.is_visible' => 1
		            ) );
		        }*/
		    }
		}
		
		//Joins
		$this->db->join('project_kols','project_kols.kol_id = kols.id','left');
		
		//Where Conditions
		$this->db->where('is_imported',2);
		if(isset($arrFilters['project']) && $arrFilters['project'] != ''){
			if($arrFilters['include_survey'] == 'on'){
				$this->db->join('survey_kol_names','survey_kol_names.kol_id = kols.id','left');
				$this->db->join('survey_answers','survey_kol_names.id = survey_answers.nominee_id','left');
				if(isset($arrFilters['surveys_priority']) && $arrFilters['surveys_priority'] != '')
					$surveyWhere .= "(project_kols.project_id =".$arrFilters['project']."  OR survey_answers.survey_id = ".$arrFilters['surveys_priority'].")";
				else
					$surveyWhere .= "(project_kols.project_id =".$arrFilters['project']."  OR survey_answers.survey_id IS NOT NULL)";
				$this->db->where($surveyWhere);
			}else
				$this->db->where('project_kols.project_id',$arrFilters['project']);
		}else{
			if($arrFilters['include_survey'] == 'on'){
				$this->db->join('survey_kol_names','survey_kol_names.kol_id = kols.id','left');
				$this->db->join('survey_answers','survey_kol_names.id = survey_answers.nominee_id','left');
				if(isset($arrFilters['surveys_priority']) && $arrFilters['surveys_priority'] != '')
					$surveyWhere .= "(project_kols.project_id > 0  OR survey_answers.survey_id = ".$arrFilters['surveys_priority'].")";
				else
					$surveyWhere .= "(project_kols.project_id > 0  OR survey_answers.survey_id IS NOT NULL)";
				$this->db->where($surveyWhere);
			}else
				$this->db->where('project_kols.project_id >',0);
		}
		//$this->db->where_in('kols.id',$arrFilters['kolids']);
		if(isset($arrFilters['specialty']) && $arrFilters['specialty']!= '' && $arrFilters['category'] != 'specialty'){
			$this->db->where_in('kols.specialty',$arrFilters['specialty']);
		}
		if(isset($arrFilters['country']) && $arrFilters['country']!= '' && $arrFilters['category'] != 'country')
			$this->db->where_in('kols.country_id',$arrFilters['country']);
		if(isset($arrFilters['state']) && $arrFilters['state']!= '' && $arrFilters['category'] != 'state')
		    $this->db->where_in('kols.state_id',$arrFilters['state']);
		if(isset($arrFilters['region']) && $arrFilters['region']!= '' && $arrFilters['category'] != 'region'){
			if(!$isCountryJoined)
				$this->db->join('countries','kols.country_id = countries.CountryID','left');
			$this->db->where_in('countries.GlobalRegion',$arrFilters['region']);
		}
		if(isset($arrFilters['city']) && $arrFilters['city']!= '' && $arrFilters['category'] != 'city')
			$this->db->where_in('kols.city_id',$arrFilters['city']);
		if(isset($arrFilters['industry']) && $arrFilters['industry']!= '' && $arrFilters['category'] != 'industry'){
			$this->db->join('kol_memberships','kols.id = kol_memberships.kol_id','left');
			$this->db->where_in('kol_memberships.institute_id',$arrFilters['industry']);
			if(isset($arrFilters['project']) && $arrFilters['project'] != ''){
			    $this->db->where_in('kol_memberships.project_id',$arrFilters['project']);
			}else{
			    $this->db->where('kol_memberships.project_id >',0);
			}
			$this->db->where('kol_memberships.type','Industry');
		}
		if(isset($arrFilters['org_ids']) && $arrFilters['org_ids']!= '' && $arrFilters['category'] != 'org_ids'){
		    $this->db->where_in('kols.org_id',$arrFilters['org_ids']);
		}
		
		//Group bys
		if(!isset($arrFilters['docount'])){
			if($arrFilters['category'] == 'specialty')
				$this->db->group_by('kols.specialty');
			if($arrFilters['category'] == 'country')
				$this->db->group_by('kols.country_id');
			if($arrFilters['category'] == 'state')
			    $this->db->group_by('kols.state_id');
			if($arrFilters['category'] == 'region')
				$this->db->group_by('countries.GlobalRegion');
			if($arrFilters['category'] == 'city')
				$this->db->group_by('kols.city_id');
			if($arrFilters['category'] == 'kolIds')
				$this->db->select('DISTINCT kols.id, salutation, first_name, middle_name, last_name,kols.profile_type,kols.unique_id');
			if($arrFilters['category'] == 'org_ids')
			    $this->db->group_by('kols.org_id');
		}
		if($arrFilters['category'] != 'kolIds')	
			$this->db->order_by('count','DESC');
		
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
		    $this->db->join('kols_project_visibility','kols_project_visibility.project_id = project_kols.project_id','left');
		    $this->db->where("kols_project_visibility.client_id",$client_id);
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		$this->db->where('(kols.deleted_optin_no_response = 0 or kols.deleted_optin_no_response is null)','',false);
		$res = $this->db->get('kols');
		//echo $this->db->last_query();
		if($res->num_rows() > 0){
			if(!isset($arrFilters['docount'])){
				foreach($res->result_array() as $row){
					$arrData[$row['id']] = $row;
				}
			}else{
				foreach($res->result_array() as $row){
					$arrData = $row['count'];
				}
			}
				
		}
		
		return $arrData;
	}
	
	function getAllJournals($filters){
	    $arrData = array();
	    $clientId = $this->session->userdata('client_id');
	    $this->db->select('pubmed_journals.id,pubmed_journals.name,pubmed_journals_priority.priority,pubmed_journals_priority.id as priority_id,pubmed_journals_priority.client_id');
	    $this->db->join('publications','publications.journal_id = pubmed_journals.id','left');
	    $this->db->join("pubmed_journals_priority","pubmed_journals_priority.journal_id = pubmed_journals.id and pubmed_journals_priority.client_id = $clientId","left");
	    $this->db->join('kol_publications','kol_publications.pub_id = publications.id','left');
	    $this->db->join('project_kols','kol_publications.kol_id = project_kols.kol_id','left');
	    if($filters['projectId']!="null")
	        $this->db->where("project_kols.project_id", $filters['projectId']);
        else
            $this->db->where('kol_publications.project_id is NOT NULL');
            $this->db->group_by('publications.journal_id');
            $res = $this->db->get('pubmed_journals');
            if($res->num_rows() > 0){
                $arrData = $res->result_array();
            }
            
            return $arrData;
	}
	
	function updateJournal($rowData,$id){
	    $this->db->where('journal_id',$rowData['journal_id']);
	    $this->db->where('client_id',$rowData['client_id']);
	    $res = $this->db->get('pubmed_journals_priority');
	    if($res->num_rows() >0){
	        $this->db->where('journal_id',$rowData['journal_id']);
	        $this->db->where('client_id',$rowData['client_id']);
	        if($this->db->update('pubmed_journals_priority',$rowData)){
	            //Add Log activity
	            $arrLogDetails = array(
	                'type' => EDIT_RECORD,
	                'description' => "Updated Pubmed Journal Priority",
	                'status' => STATUS_SUCCESS,
	                'transaction_name' => "Updated Pubmed Journal Priority",
	            );
	            $this->config->set_item('log_details', $arrLogDetails);
	            
	            return true;
	        }else{
	                return false;
	        }
	    }else{
	        if($this->db->insert('pubmed_journals_priority',$rowData)){
	            //Add Log activity
	            $arrLogDetails = array(
	                'type' => ADD_RECORD,
	                'description' => "Save Pubmed Journal Priority",
	                'status' => STATUS_SUCCESS,
	                'transaction_name' => "Save Pubmed Journal Priority",
	            );
	            $this->config->set_item('log_details', $arrLogDetails);
	            return $this->db->insert_id();
	        }else{
	            return false;
	        }
	    }
	}
	
	
	function getAllEvents($filters){
	    $arrData = array();
	    $clientId = $this->session->userdata('client_id');
	    $this->db->select('events.id,events.name,events_priority.priority,events_priority.id as priority_id,events_priority.client_id');
	    $this->db->join("events_priority","events_priority.event_id = events.id and events_priority.client_id = $clientId",'left');
	    $this->db->join('kol_events','kol_events.event_id = events.id','left');
	    $this->db->join('project_kols','kol_events.kol_id = project_kols.kol_id','left');
	    if($filters['projectId']!="null")
	        $this->db->where("kol_events.project_id", $filters['projectId']);
        else
            $this->db->where('kol_events.project_id is NOT NULL');
            $this->db->group_by('kol_events.event_id');
            $res = $this->db->get('events');
            if($res->num_rows() > 0){
                $arrData = $res->result_array();
            }
            
            return $arrData;
	}
	
	function updateEvent($rowData){
	    $this->db->where('event_id',$rowData['event_id']);
	    $this->db->where('client_id',$rowData['client_id']);
	    $res = $this->db->get('events_priority');
	    if($res->num_rows() >0){
	        $this->db->where('event_id',$rowData['event_id']);
	        $this->db->where('client_id',$rowData['client_id']);
	        if($this->db->update('events_priority',$rowData)){
	            //Add Log activity
	            $arrLogDetails = array(
	                'type' => EDIT_RECORD,
	                'description' => "Updated Event Priority",
	                'status' => STATUS_SUCCESS,
	                'transaction_name' => "Updated Event Priority",
	            );
	            $this->config->set_item('log_details', $arrLogDetails);
	            
	            return true;
	        }else{
	                return false;
	        }
	    }else{
	        if($this->db->insert('events_priority',$rowData)){
	            //Add Log activity
	            $arrLogDetails = array(
	                'type' => ADD_RECORD,
	                'description' => "Save Event Priority",
	                'status' => STATUS_SUCCESS,
	                'transaction_name' => "Save Event Priority",
	            );
	            $this->config->set_item('log_details', $arrLogDetails);
	            
	            return $this->db->insert_id();
	        }else{
	            return false;
	        }
	    }
	}
	
	function getAllInstitutions($filters){
	    $arrData = array();
	    $clientId = $this->session->userdata('client_id');
	    $this->db->select('institutions.id,institutions.name,institutions_priority.priority,institutions_priority.id as priority_id,institutions_priority.client_id');
	    $this->db->join("institutions_priority","institutions_priority.institution_id = institutions.id and institutions_priority.client_id = $clientId",'left');
	    $this->db->join('kol_memberships','kol_memberships.institute_id = institutions.id','left');
	    $this->db->join('project_kols','kol_memberships.kol_id = project_kols.kol_id','left');
	    if($filters['projectId']!="null")
	        $this->db->where("project_kols.project_id", $filters['projectId']);
        else
            $this->db->where('kol_memberships.project_id is NOT NULL');
            $this->db->where('engagement_id !=',11);
            $this->db->group_by('kol_memberships.institute_id');
            $res = $this->db->get('institutions');
            // 		echo $this->db->last_query();exit;
            if($res->num_rows() > 0){
                $arrData = $res->result_array();
            }
            
            return $arrData;
	}
	
	function updateInstitution($rowData){
	    $this->db->where('institution_id',$rowData['institution_id']);
	    $this->db->where('client_id',$rowData['client_id']);
	    $res = $this->db->get('institutions_priority');
	    if($res->num_rows() >0){
	        $this->db->where('institution_id',$rowData['institution_id']);
	        $this->db->where('client_id',$rowData['client_id']);
	        if($this->db->update('institutions_priority',$rowData)){
	            //Add Log activity
	            $arrLogDetails = array(
	                'type' => EDIT_RECORD,
	                'description' => "Updated Institution Priority",
	                'status' => STATUS_SUCCESS,
	                'transaction_name' => "Updated Institution Priority",
	            );
	            $this->config->set_item('log_details', $arrLogDetails);
	            return true;
	        }else{
	                return false;
	        }
	    }else{
	        if($this->db->insert('institutions_priority',$rowData)){
	            //Add Log activity
	            $arrLogDetails = array(
	                'type' => ADD_RECORD,
	                'description' => "Save Institution Priority",
	                'status' => STATUS_SUCCESS,
	                'transaction_name' => "Save Institution Priority",
	            );
	            $this->config->set_item('log_details', $arrLogDetails);
	            
	            return $this->db->insert_id();
	        }else{
	            return false;
	        }
	    }
	}
	
	function updateActivityType($rowData){
	    $this->db->where('id',$rowData['id']);
	    $this->db->set('activity_type',$rowData['activity_type']);
	    $this->db->update('kol_events');
	}
	function getAllSponsors($filters){
	    $arrData = array();
	    $clientId = $this->session->userdata('client_id');
	    $this->db->select('cts_sponsers.id,cts_sponsers.agency,sponsers_priority.priority,sponsers_priority.id as priority_id,sponsers_priority.client_id');
	    $this->db->join("sponsers_priority","sponsers_priority.sponser_id = cts_sponsers.id and sponsers_priority.client_id = $clientId",'left');
	    $this->db->join('ct_sponsers','ct_sponsers.sponser_id = cts_sponsers.id','left');
	    $this->db->join('kol_clinical_trials','ct_sponsers.cts_id = kol_clinical_trials.cts_id','left');
	    $this->db->join('project_kols','kol_clinical_trials.kol_id = project_kols.kol_id','left');
	    if($filters['projectId']!="null")
	        $this->db->where("project_kols.project_id", $filters['projectId']);
	        else
	            $this->db->where('kol_clinical_trials.project_id is NOT NULL');
	            $this->db->where('cts_sponsers.agency is NOT NULL');
	            $this->db->group_by('cts_sponsers.agency');
	            $res = $this->db->get('cts_sponsers');
	            //                echo $this->db->last_query(); exit;
	            if($res->num_rows() > 0){
	                $arrData = $res->result_array();
	            }
	            
	            return $arrData;
	}
	
	function getSponsorName($id){
		$name = '';
		$this->db->where('id',$id);
		$res = $this->db->get('cts_sponsers');
		if($res->num_rows() > 0){
			$arrData = $res->result_array();
			$name = $arrData[0]['agency'];
		}
		
		return $name;
	}
	
	function updateSponsors($rowData,$id){
	    $arrData =array();
	    $rowData['agency'] = $this->getSponsorName($rowData['sponser_id']);
	    if($rowData['agency'] != ''){
	        $this->db->where('agency',$rowData['agency']);
	        $res = $this->db->get('cts_sponsers');
	        $sponIds = '';
	        $saparator = '';
	        if($res->num_rows() > 0){
	            foreach($res->result_array() as $row){
	                $arrData['sponser_id'] = $row['id'];
	                $arrData['client_id'] = $rowData['client_id'];
	                $arrData['priority'] = $rowData['priority'];
	                
	                $this->db->where('sponser_id',$arrData['sponser_id']);
	                $this->db->where('client_id',$rowData['client_id']);
	                $result = $this->db->get('sponsers_priority');
	                
	                if($result->num_rows() >0){
	                    $this->db->where('sponser_id',$arrData['sponser_id']);
	                    $this->db->where('client_id',$rowData['client_id']);
	                    $this->db->update('sponsers_priority',$arrData);
	                    //Add Log activity
	                    $arrLogDetails = array(
	                        'type' => EDIT_RECORD,
	                        'description' => "Updated Sponsers Priority",
	                        'status' => STATUS_SUCCESS,
	                        'transaction_name' => "Updated Sponsers Priority",
	                    );
	                    $this->config->set_item('log_details', $arrLogDetails);
	                }else{
	                    $this->db->insert('sponsers_priority',$arrData);
	                    //Add Log activity
	                    $arrLogDetails = array(
	                        'type' => ADD_RECORD,
	                        'description' => "Save Sponsers Priority",
	                        'status' => STATUS_SUCCESS,
	                        'transaction_name' => "Save Sponsers Priority",
	                    );
	                    $this->config->set_item('log_details', $arrLogDetails);
	                }
	            }
	            return true;
	        }else{
	            return false;
	        }
	    }
	}
	
	function getAllGuidelines($filters){
	    $arrData = array();
	    $clientId = $this->session->userdata('client_id');
	    $this->db->select('kol_memberships.id,kol_memberships.department,guidelines_priority.priority,guidelines_priority.id as priority_id,guidelines_priority.client_id');
	    $this->db->join("guidelines_priority","guidelines_priority.guideline_id = kol_memberships.id and guidelines_priority.client_id = $clientId",'left');
	    $this->db->join('project_kols','kol_memberships.kol_id = project_kols.kol_id','left');
	    if($filters['projectId']!="null")
	        $this->db->where("project_kols.project_id", $filters['projectId']);
	        else
	            $this->db->where('kol_memberships.project_id is NOT NULL');
	            $this->db->where('kol_memberships.engagement_id',11);
	            $this->db->group_by('kol_memberships.department');
	            $res = $this->db->get('kol_memberships');
	            if($res->num_rows() > 0){
	                $arrData = $res->result_array();
	            }
	            
	            return $arrData;
	}
	
	function getGuidelineName($id){
		$name = '';
		$this->db->where('id',$id);
		$res = $this->db->get('kol_memberships');
		if($res->num_rows() > 0){
			$arrData = $res->result_array();
			$name = $arrData[0]['department'];
		}
		
		return $name;
	}
	
	function updateGuidelines($rowData){
	    $arrData =array();
	    $rowData['department'] = $this->getGuidelineName($rowData['guideline_id']);
	    if($rowData['department'] != ''){
	        $this->db->where('department',$rowData['department']);
	        $res = $this->db->get('kol_memberships');
	        if($res->num_rows() > 0){
	            foreach($res->result_array() as $row){
	                $arrData['guideline_id'] = $row['id'];
	                $arrData['client_id'] = $rowData['client_id'];
	                $arrData['priority'] = $rowData['priority'];
	                
	                $this->db->where('guideline_id',$arrData['guideline_id']);
	                $this->db->where('client_id',$rowData['client_id']);
	                $result = $this->db->get('guidelines_priority');
	                
	                if($result->num_rows() >0){
	                    $this->db->where('guideline_id',$arrData['guideline_id']);
	                    $this->db->where('client_id',$rowData['client_id']);
	                    $this->db->update('guidelines_priority',$arrData);
	                    //Add Log activity
	                    $arrLogDetails = array(
	                        'type' => EDIT_RECORD,
	                        'description' => "Updated Guidelines Priority",
	                        'status' => STATUS_SUCCESS,
	                        'transaction_name' => "Updated Guidelines Priority",
	                    );
	                    $this->config->set_item('log_details', $arrLogDetails);
	                    
	                }else{
	                    //Add Log activity
	                    $arrLogDetails = array(
	                        'type' => ADD_RECORD,
	                        'description' => "Save Guidelines Priority",
	                        'status' => STATUS_SUCCESS,
	                        'transaction_name' => "Save Guidelines Priority",
	                    );
	                    $this->config->set_item('log_details', $arrLogDetails);
	                    
	                    $this->db->insert('guidelines_priority',$arrData);
	                }
	            }
	            return true;
	        }else{
	            return false;
	        }
	    }
	}
	
	function getAllCustomFilterByUser($userId) {
		$arrData = array();
		$this->db->_reset_select();
		$this->db->where('created_by',$userId);
		$this->db->where('filter_type',3);
		$this->db->order_by('applied_on','desc');
		$this->db->order_by('name','asc');
		$result = $this->db->get('custom_filters');
		foreach ($result->result_array() as $row){
			$arrData[] = $row;
		}
		return $arrData;
	}
	
	function getInstituteNameById($arrCityIds){
		$arrCities =	array();
		$this->db->where_in('id',$arrCityIds);
		$result = $this->db->get('institutions');
		foreach($result->result_array() as $row){
			$arrCities[$row['id']] = $row['name'];
		}
		return $arrCities;
	}
	
	function getIndustryKolIds($arrFilters){
		$arrIds = array();
		$this->db->distinct();
		$this->db->select('kol_memberships.kol_id');
		$this->db->where('type','industry');
		if(isset($arrFilters['project']) && $arrFilters['project'] != '')
			$this->db->where('project_id',$arrFilters['project']);
		$this->db->where_in('institute_id',$arrFilters['industry']);
		$result = $this->db->get('kol_memberships');
		foreach($result->result_array() as $row){
			$arrIds[] = $row['kol_id'];
		}
                //echo $this->db->last_query();exit;
		return $arrIds;
	}
	
	function getIndustryNames($industryName){
		$this->db->select('institutions.id,institutions.name');
		$this->db->like('institutions.name', $industryName);
		$this->db->where('type','Industry');
		//$this->db->where('kol_memberships.project_id IS NOT NULL');
		$this->db->join('institutions','kol_memberships.institute_id = institutions.id','left');
		$this->db->group_by('kol_memberships.kol_id');
		$arrResultSet = $this->db->get('kol_memberships');
		$arrCountryNames = array();
		foreach($arrResultSet->result_array() as $arrRow){
			$arrCountryNames[$arrRow['id']] = $arrRow['name'];
		}
		//echo $this->db->last_query();
		return $arrCountryNames;
	}
	
	function getMeshTerms($meshTerm){
		$arrRet = array();
		$this->db->select("mesh_dictionary_terms.name,mesh_search_terms.mesh_term_id,mesh_search_terms.search_term");
		$this->db->join("mesh_search_terms","mesh_search_terms.mesh_term_id = mesh_dictionary_terms.id","left");
		$this->db->like("mesh_search_terms.search_term",$meshTerm,"after");
		$this->db->order_by("mesh_dictionary_terms.name",'asc');
		$result = $this->db->get("mesh_dictionary_terms");
		foreach ($result->result_array() as $row){
			$arrRet[] = $row;
		}
		
		return $arrRet;
	}
	
	function getTermIdByTermName($keyword){
		$this->db->where("name",$keyword);
		$result = $this->db->get("mesh_dictionary_terms");
		if($result->num_rows > 0){
			foreach ($result->result_array() as $row){
				$id = $row['id'];
			}
			return $id;
		}else{
			return '';
		}
	}
	
	function getSubTermIdByTermId($termId){
		$this->db->where("mesh_term_id",$termId);
		$result = $this->db->get("mesh_sub_terms");
		$retArr = array();
		foreach ($result->result_array() as $row){
			$retArr[] = $row['sub_term'];
		}
		return $retArr;
	}
	
	function saveCustomFilters($arrData) {
		if($this->db->insert('custom_filters',$arrData)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	function updateCustomFilters($arrData) {
		$this->db->where('id',$arrData['id']);
		$result = $this->db->update('custom_filters',$arrData);
		if($result)
			return true;
		else
			return false;
	}
        
        function duplicateCheckProjectKols($kol_ids,$overwrite_association){
            $this->db->select('*');
            $this->db->where_in('kol_id',$kol_ids);
            $this->db->join('projects', 'project_kols.project_id = projects.id', 'left');
            $results=$this->db->get('project_kols');
//           echo $this->db->last_query(); 
//           pr($results->num_rows()); exit;
            if($results->num_rows()<1)
			return 0;
            else{
                if($overwrite_association==1){
                    $status=$this->deleteProjectKolAssociation($kol_ids);
                    if($status)
                        return 0;
                }else{
                    foreach ($results->result_array() as $row){
                            echo $row['kol_id']." is already associated with Project Id: ".$row['project_id']. " and Project Name: ".$row['name']."<br/>";
                    }
                    exit; 
                }
            }
        }
        
        function updateKolIsImported($kolIds){
            $i=0;
            foreach($kolIds as $rowId){
                $this->db->where('id',$rowId);
                $arrKolDetail = $this->db->get('kols');
                if($arrKolDetail->num_rows()!=0){
                    $row = $arrKolDetail->row_array();
                    if($row['imported_as'] != '2' && $row['imported_as'] != '1'){
                        $this->db->set('imported_as',3);
                    }
                    $this->db->set('is_imported',2);
                    $this->db->where('id',$rowId);
                    $this->db->update('kols');
                }
                $i++;
            }
            return $i;
        }
        //Associated Kol Updated
        function UpdatekolMembershipKolIds($kolIds,$project_id){
            $this->db->where_in('kol_id',$kolIds); 
            $this->db->set('project_id',$project_id);
            $this->db->update('kol_memberships');
            $afftectedRows = $this->db->affected_rows();
            return $afftectedRows;
		
        }
        function UpdatekolEventKolIds($kolIds,$project_id){
            $this->db->where_in('kol_id',$kolIds); 
            $this->db->set('project_id',$project_id);
            $this->db->update('kol_events');
            $afftectedRows = $this->db->affected_rows();
            return $afftectedRows;
		
        }
        function UpdatekolPubKolIds($kolIds,$project_id,$startYear,$endYear){
            if($startYear!='0' && $endYear!='0'){
                $kolIds = implode(',', $kolIds);
                $this->db->query("UPDATE `kol_publications`
                join publications on publications.id=kol_publications.pub_id
                SET `kol_publications`.`project_id` = $project_id
                WHERE (YEAR(publications.created_date) BETWEEN '$startYear' AND '$endYear') AND `kol_publications`.`kol_id` IN ($kolIds)");
                $afftectedRows = $this->db->affected_rows();
                return $afftectedRows;
            }else{
                return '0';
            }
        }
        function UpdatekolClinicalTrialsKolIds($kolIds,$project_id){
            $this->db->where_in('kol_id',$kolIds); 
            $this->db->set('project_id',$project_id);
            $this->db->update('kol_clinical_trials');
            $afftectedRows = $this->db->affected_rows();
            return $afftectedRows;
		
        }
        //Dis-Associated Kol Updated
        function UpdateDisassociatedkolMembershipKolIds($kolIds,$project_id){
            $this->db->where_in('kol_id',$kolIds);
            $this->db->where('project_id',$project_id);
            $this->db->set('project_id',null);
            $this->db->update('kol_memberships');
            $afftectedRows = $this->db->affected_rows();
            return $afftectedRows;
            
        }
        function UpdateDisassociatedkolEventKolIds($kolIds,$project_id){
            $this->db->where_in('kol_id',$kolIds);
            $this->db->where('project_id',$project_id);
            $this->db->set('project_id',null);
            $this->db->update('kol_events');
            $afftectedRows = $this->db->affected_rows();
            return $afftectedRows;
            
        }
        function UpdateDisassociatedkolPubKolIds($kolIds,$project_id){
            $this->db->where_in('kol_id',$kolIds);
            $this->db->where('project_id',$project_id);
            $this->db->set('project_id',null);
            $this->db->update('kol_publications');
            $afftectedRows = $this->db->affected_rows();
            return $afftectedRows;
            
        }
        function UpdateDisassociatedkolClinicalTrialsKolIds($kolIds,$project_id){
            $this->db->where_in('kol_id',$kolIds);
            $this->db->where('project_id',$project_id);
            $this->db->set('project_id',null);
            $this->db->update('kol_clinical_trials');
            $afftectedRows = $this->db->affected_rows();
            return $afftectedRows;
		
        }
        function save_project_kols($kolIds,$project_id){
            foreach ($kolIds as $kolId) {
                $arrData['created_by'] = $this->session->userdata('user_id');
        		$arrData['created_on'] = date("Y-m-d H:i:s");
        		$arrData['kol_id'] = $kolId;
        		$arrData['project_id'] = $project_id;
                $status=$this->db->insert('project_kols',$arrData);
                    
            }
            $this->db->where('project_id',$project_id);
            $result=$this->db->get('project_kols');
            $rowcount = $result->num_rows();
            if($rowcount>1)
                return $rowcount;
            
        }
        
        function deleteProjectKols($kolIds,$project_id){
            foreach ($kolIds as $kolId) {
                $this->db->where("kol_id",$kolId);
                $this->db->where("project_id",$project_id);
                $status=$this->db->delete('project_kols');
            }
            return sizeof($kolIds);
                
        }
       
        
        function UpdateActivityTypeInKolEvent($project_id,$INFlag){
            if($INFlag=="IN"){
                $query="UPDATE kol_events
                LEFT JOIN event_topics ON kol_events.topic = event_topics.id
                SET activity_type = 'Organizing Committee'
                WHERE NAME IN ('Admin. & Management','Admin And Management') AND project_id  ='$project_id'";
            }
            else{
                $query="UPDATE kol_events
                LEFT JOIN event_topics ON kol_events.topic = event_topics.id
                SET activity_type = 'Speaking'
                WHERE NAME NOT IN ('Admin. & Management','Admin And Management') AND project_id  ='$project_id'";
            }
            $result=$this->db->query($query);
            $afftectedRows = $this->db->affected_rows();
            return $afftectedRows;
        }
        
        function deleteProjectKolAssociation($kol_ids){
            mysqli_query('SET foreign_key_checks = 0');
            $this->db->where_in('kol_id',$kol_ids);
            if($query = $this->db->delete('project_kols')){
                    return true;
            }else
                    return false;
        }
        function getLatestProjectId(){
        	$projectId = '';
        	$this->db->select('projects.*');
        	$clientId = $this->session->userdata('client_id');
        	$this->db->join('client_users','projects.created_by = client_users.id','left');
        	if($clientId != INTERNAL_CLIENT_ID){
        	    $this->db->join('kols_project_visibility','kols_project_visibility.project_id = projects.id','left');
        	    $this->db->where("kols_project_visibility.client_id",$clientId);
        	}
        	$result = $this->db->get("projects");       
        	if($result->num_rows() > 0){
            	foreach ($result->result_array() as $row){
            		$projectId = $row['id'];
            	}
        	}
        	return $projectId;
        }
        function getUserProjectsIds($userId){
        	$arrProjects = array();
        	$this->db->where("user_id",$userId);
        	$result = $this->db->get("user_projects");
        	if ($result && $result->num_rows() > 0 ){
        		foreach($result->result_array() as $row)
        			$arrProjects[] = $row['project_id'];
        	}
        	return $arrProjects;
        }
        function saveUserProject($userProjects){
        	if($this->db->insert('user_projects',$userProjects)){
        		return true;
        	}else{
        		return false;
        	}
        }
        
        function saveKolsProjectVisibility($arrData){
        	$arrDataIns['project_id'] = $arrData['project_id'];
        	foreach($arrData['client_id'] as $client){
        		$arrDataIns['client_id'] = $client;
        		$this->db->insert('kols_project_visibility',$arrDataIns);
        	}
        }
        function saveKolsClientVisibility($arrData){
            foreach($arrData['client_ids'] as $client){
                $arrDataIns['client_id'] = $client;
                foreach($arrData['kol_ids'] as $kol){
                    $arrDataIns['kol_id'] = $kol;
                    $arrDataIns['is_visible'] = 1;
                    $this->db->insert('kols_client_visibility',$arrDataIns);
                }
            }
        }
        
        function deleteKolsClientVisibility($arrData){
        	foreach($arrData['client_ids'] as $client){
        	    $this->db->where('client_id',$client);
        		foreach($arrData['kol_ids'] as $kol){
        			$this->db->where('kol_id',$kol);
        			$this->db->where('is_visible',1);
        			$this->db->delete('kols_client_visibility');
        		}
        	}
        }
        function updateKolsProjectVisibility($arrData){
        	$this->db->where('project_id',$arrData['project_id']);
        	$this->db->delete('kols_project_visibility');
        	$arrDataIns['project_id'] = $arrData['project_id'];
        	foreach($arrData['client_id'] as $client){
        		$arrDataIns['client_id'] = $client;
        		$this->db->insert('kols_project_visibility',$arrDataIns);
        	}
        }
        
        function getClientProjects($id){
        	$arrData = array();
        	$this->db->where('project_id',$id);
        	$query = $this->db->get('kols_project_visibility');
        	//pr($this->db->last_query());exit;
        	foreach($query->result_array() as $row){
        		$arrData[] = $row['client_id'];
        	}
        	return $arrData;
        }
        
        function getProjectAssociatedKols($projectId,$limit=null,$startFrom=null,$doCount=null,$sidx = '',$sord = '',$where){
            $this->db->select('kols.salutation,kols.first_name,kols.last_name,kols.middle_name,kols.id as kol_id,projects.year_range');
            $this->db->join('project_kols','project_kols.project_id = projects.id','left');
            $this->db->join('kols','kols.id = project_kols.kol_id','left');
            $this->db->where('projects.id',$projectId);
            $this->db->order_by('kols.first_name','asc');
            if(isset($where['kol_name'])){
                $this->db->where("(concat(kols.first_name,' ',CASE WHEN kols.middle_name IS NOT NULL || kols.middle_name!= '' THEN kols.middle_name ELSE '' END,' ',CASE WHEN kols.last_name IS NOT NULL || kols.last_name!= '' THEN kols.last_name ELSE '' END) like '%".$where['kol_name']."%' END)",'',false);
            }
            if($doCount){
                $count = $this->db->count_all_results('projects');
                return $count;
            }else{
                if($sidx!='' && $sord!=''){
                    switch($sidx){
                        case 'kol_name' : $this->db->order_by("kols.first_name", $sord);
                        break;
                    }
                }
            }
            $arrProjectKolDetails = $this->db->get('projects');
            return $arrProjectKolDetails;
        }
        
        function getKolsIdActivityCount($tableName,$project_id,$kolId,$startYear,$endYear){
            $this->db->where("$tableName.kol_id",$kolId);
//             $this->db->join("project_kols", "$tableName.kol_id = project_kols.kol_id", "left");
            switch($tableName){
                case 'kol_events':
                    $wherBetween="(
    					((YEAR(start) != '' AND YEAR(start) BETWEEN $startYear AND $endYear)OR (YEAR(end) != '' AND YEAR(end) BETWEEN $startYear AND $endYear))
    					OR (YEAR(start) = '' AND YEAR(end) BETWEEN $startYear AND $endYear)
    					OR (YEAR(end) = '' AND YEAR(start) BETWEEN $startYear AND $endYear)
    					OR (YEAR(start) = '' AND YEAR(end) = '')
                        OR (YEAR(start) is null AND YEAR(end) is null)
    						OR (year(START) >= YEAR(CURDATE()))
    				)";
                    $this->db->join("project_kols", "kol_events.kol_id = project_kols.kol_id", "left");
                break;
                case 'kol_memberships':
                    $wherBetween="(
    					((start_date != '' AND start_date BETWEEN $startYear AND $endYear)OR (end_date != '' AND end_date BETWEEN $startYear AND $endYear))
    					OR (start_date = '' AND end_date BETWEEN $startYear AND $endYear)
    					OR (end_date = '' AND start_date BETWEEN $startYear AND $endYear)
    					OR (start_date = '' AND end_date = '')
    						OR (start_date >= YEAR(CURDATE()))
    				)";
                    $this->db->join("project_kols", "kol_memberships.kol_id = project_kols.kol_id", "left");
                    break;
                case 'kol_publications':
                    $this->db->join('publications','kol_publications.pub_id = publications.id','left');
                    $this->db->join("project_kols", "kol_publications.kol_id = project_kols.kol_id", "left");
                    $wherBetween="(YEAR(publications.created_date) BETWEEN '$startYear' AND '$endYear' OR YEAR(publications.created_date)='0')";    
                break;
                case 'kol_clinical_trials':
                    $this->db->join('clinical_trials','kol_clinical_trials.cts_id = clinical_trials.id','left');
                    $this->db->join("project_kols", "kol_clinical_trials.kol_id = project_kols.kol_id", "left");
                    $wherBetween="((RIGHT(clinical_trials.start_date,4) >= $startYear OR RIGHT(clinical_trials.end_date,4) <= $endYear) OR (clinical_trials.start_date = '' AND clinical_trials.end_date = ''))";
                break;
            }
            $this->db->where("($tableName.project_id = $project_id or $tableName.project_id is null or $tableName.project_id = 0)","",false);
            $this->db->where($wherBetween);
            $count = $this->db->count_all_results($tableName);
//             echo $this->db->last_query();exit;
            return $count;
        }
        
        function getActivityByKolId($kolId,$projectId,$activityType,$startYear,$endYear,$limit=null,$startFrom=null,$doCount=null,$sidx = '',$sord = '',$where){
            switch($activityType){
                case 'events':
                    $this->db->select(array('event_sponsor_types.type as sponsor_type', 'kol_events.*', 'events.name', 'conf_event_types.event_type as conf_event_type', 'event_topics.name as event_topic','event_topics.specialty_id as et_specialty_id', 'conf_session_types.session_type as conf_session_type'));
                    $this->db->join('kols','kols.id = kol_events.kol_id','left');
                    $this->db->join('events', 'events.id = kol_events.event_id', 'left');
                    $this->db->join('event_topics', 'event_topics.id = kol_events.topic', 'left');
                    $this->db->join('conf_event_types', 'conf_event_types.id = kol_events.event_type', 'left');
                    $this->db->join('conf_session_types', 'conf_session_types.id = kol_events.session_type', 'left');
                    $this->db->join('event_sponsor_types', 'event_sponsor_types.id = kol_events.sponsor_type', 'left');
                    $this->db->join('project_kols', 'kol_events.kol_id = project_kols.kol_id', 'left');
                    $this->db->where("kol_events.kol_id",$kolId);
                    $this->db->where("(kol_events.project_id = $projectId or kol_events.project_id is null or kol_events.project_id = 0)","",false);
                    $wherBetween="(
    					((YEAR(kol_events.start) != '' AND YEAR(kol_events.start) BETWEEN $startYear AND $endYear)OR (YEAR(kol_events.end) != '' AND YEAR(kol_events.end) BETWEEN $startYear AND $endYear))
    					OR (YEAR(kol_events.start) = '' AND YEAR(kol_events.end) BETWEEN $startYear AND $endYear)
    					OR (YEAR(kol_events.end) = '' AND YEAR(kol_events.start) BETWEEN $startYear AND $endYear)
    					OR (YEAR(kol_events.start) = '' AND YEAR(kol_events.end) = '')
                        OR (YEAR(kol_events.start) is null AND YEAR(kol_events.end) is null)
    						OR (year(START) >= YEAR(CURDATE()))
    				)";
                    $this->db->where($wherBetween);
                    if($doCount){
                        $count = $this->db->count_all_results('kol_events');
                        return $count;
                    }
                    $arrEventDetailsResult = $this->db->get('kol_events');
                    return $arrEventDetailsResult;
                break;
                case 'affiliation':
                    $this->db->select(array('kol_memberships.*', 'institutions.name', 'engagement_types.engagement_type'));
                    $this->db->join('institutions', 'institutions.id = kol_memberships.institute_id', 'left');
                    $this->db->join('engagement_types', 'engagement_types.id = kol_memberships.engagement_id', 'left');
                    $this->db->join('project_kols', 'kol_memberships.kol_id = project_kols.kol_id', 'left');
                    $this->db->where('kol_memberships.kol_id', $kolId);
                    $this->db->where("(kol_memberships.project_id = $projectId or kol_memberships.project_id is null or kol_memberships.project_id = 0)","",false);
                    $wherBetween="(
    					((kol_memberships.start_date != '' AND kol_memberships.start_date BETWEEN $startYear AND $endYear)OR (kol_memberships.end_date != '' AND kol_memberships.end_date BETWEEN $startYear AND $endYear))
    					OR (kol_memberships.start_date = '' AND kol_memberships.end_date BETWEEN $startYear AND $endYear)
    					OR (kol_memberships.end_date = '' AND kol_memberships.start_date BETWEEN $startYear AND $endYear)
    					OR (kol_memberships.start_date = '' AND kol_memberships.end_date = '')
    						OR (kol_memberships.start_date >= YEAR(CURDATE()))
    				)";
                    $this->db->where($wherBetween);
                    $this->db->order_by('kol_memberships.start_date', 'desc');
                    if($doCount){
                        $count = $this->db->count_all_results('kol_memberships');
                        return $count;
                    }
                    $arrMembershipDetailResult = $this->db->get('kol_memberships');
                    return $arrMembershipDetailResult;
                break;
                case 'publication':
                    $this->db->select(array('kol_publications.*', 'publications.article_title', 'pubmed_journals.name as journal_name','publications.created_date','publications.pmid'));
                    $this->db->join('publications', 'publications.id = kol_publications.pub_id', 'left');
                    $this->db->join('pubmed_journals', 'pubmed_journals.id = publications.journal_id', 'left');
                    $this->db->join('project_kols', 'kol_publications.kol_id = project_kols.kol_id', 'left');
                    $this->db->where('kol_publications.kol_id', $kolId);
                    $this->db->where('kol_publications.is_verified', '1');
                    $this->db->where('kol_publications.is_deleted', '0');
                    $this->db->where("(kol_publications.project_id = $projectId or kol_publications.project_id is null or kol_publications.project_id = 0)","",false);
                    $this->db->order_by('publications.created_date', 'desc');
                    $wherBetween="(YEAR(publications.created_date) BETWEEN '$startYear' AND '$endYear' OR YEAR(publications.created_date)='0')";
                    $this->db->where($wherBetween);
                    if($doCount){
                        $count = $this->db->count_all_results('kol_publications');
                        return $count;
                    }
                    $arrPublicationDetailResult = $this->db->get('kol_publications');
                    return $arrPublicationDetailResult;
                break;
                case 'trial':
                    $this->db->select(array('clinical_trials.*','kol_clinical_trials.client_id','kol_clinical_trials.user_id','kol_clinical_trials.id as asoc_id','kol_clinical_trials.id as kol_clinical_id','kol_clinical_trials.project_id as project_id'));
                    $this->db->join('kol_clinical_trials', 'kol_clinical_trials.cts_id = clinical_trials.id','left');
                    $this->db->join('project_kols', 'kol_clinical_trials.kol_id = project_kols.kol_id', 'left');
                    $this->db->where('kol_clinical_trials.kol_id', $kolId);
                    $this->db->where("(kol_clinical_trials.project_id = $projectId or kol_clinical_trials.project_id is null or kol_clinical_trials.project_id = 0)","",false);
                    $wherBetween="((RIGHT(clinical_trials.start_date,4) >= $startYear OR RIGHT(clinical_trials.end_date,4) <= $endYear) OR (clinical_trials.start_date = '' AND clinical_trials.end_date = ''))";
                    $this->db->where($wherBetween);
                    if($doCount){
                        $count = $this->db->count_all_results('clinical_trials');
                        return $count;
                    }
                    $arrTrialDetailResult = $this->db->get('clinical_trials');
                    return $arrTrialDetailResult;
                break;
            }
        }
        
        function updateProjectAssociations($actionIds,$actionType,$action,$project_id){
            if($action=='association'){
                $data = array(
                    'project_id' => $project_id
                );
            }else{
                $data = array(
                    'project_id' => NULL
                );
            }
            $this->db->where_in('id', $actionIds);
            switch($actionType){
                case 'event':
                    $this->db->update('kol_events',$data);
                break;
                case 'affiliation':
                    $this->db->update('kol_memberships',$data);
                break;
                case 'publication':
                    $this->db->update('kol_publications',$data);
                break;
                case 'trial':
                    $this->db->update('kol_clinical_trials',$data);
                break;
            }
        }
        
        function getProjectYearRange($id){
            $rowData = array();
            $this->db->select('projects.year_range');
            $this->db->where('projects.id',$id);
            $res = $this->db->get('projects');
            $get = $res->row_array();
            $year = explode("-",$get['year_range']);
            return $year;
        }
        
        function getClentKolIds(){
            $arrIds = array();
            $this->db->select('id');
            $this->db->where('imported_as IS NULL or imported_as = 2 or imported_as = 0 or imported_as = 3', null, false);
            $result = $this->db->get('kols');
            foreach($result->result_array() as $row){
                $arrIds[] = (int)$row['id'];
            }
//             echo $this->db->last_query();exit;
            return $arrIds;
        }
        
        function saveKolToContact($kolIds){
            $this->db->set('imported_as',2);
            $this->db->where_in('id',$kolIds);
            $this->db->update('kols');
            return true;
        }
        
        function getAssociatedNonAssociatedProjectKols($projectId,$projectAssoc = false){
            $arrKolIds = array();
            if($projectId > 0){
                $this->db->select('kols.id');
                $this->db->join( 'project_kols', 'project_kols.kol_id = kols.id', 'left' );
                $this->db->where( 'project_kols.project_id', $projectId );
                $arrKolIdsResult = $this->db->get ( 'kols' );
                foreach ($arrKolIdsResult->result_array() as $row) {
                    $arrKolIds[] = $row['id'];
                }
            }
            $this->db->select(array('kols.id', 'kols.salutation','kols.pin', 'kols.is_imported', 'kols.salutation', 'kols.first_name', 'kols.middle_name', 'kols.last_name', 'kols.gender', 'specialties.specialty', 'organizations.name as org_name', 'kols.is_pubmed_processed', 'kols.is_clinical_trial_processed', 'kols.status', 'client_users.user_name as user_full_name'));
            // 		$this->db->select(array('kols.id',	 'kols.salutation', 'concat(COALESCE(kols.first_name,"")," ", COALESCE(kols.middle_name,"")," ", COALESCE(kols.last_name,"")) as kol_name', 'specialties.specialty as kol_speciality', 'kols.gender as kol_gender', 'organizations.name as kol_org', 'concat(COALESCE(client_users.first_name,"")," ", COALESCE(client_users.last_name,"")) as kol_created_by', 'kols.pin as kol_pin', 'kols.status as kol_status','kols.is_pubmed_processed','kols.is_clinical_trial_processed'));
            $this->db->join ( 'specialties', 'specialties.id = kols.specialty', 'left' );
            $this->db->join ( 'organizations', 'organizations.id = kols.org_id', 'left' );
            $this->db->join ( 'client_users', 'client_users.id = kols.created_by', 'left' );
            
            
            if($projectId > 0 && $projectAssoc){
                if(sizeof($arrKolIds) > 0){
                    $this->db->where_in ( 'kols.id', $arrKolIds );
                }else{
                    $this->db->where('kols.id',0);
                }
            }
            if($projectId >0 && $projectAssoc==false){
                if(sizeof($arrKolIds) > 0){
                    $this->db->where_not_in ( 'kols.id', $arrKolIds );
                }
                $this->db->where('kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3', null, false);
            }
            if(KOL_CONSENT){
                $this->db->where('(kols.opt_in_out_status is NULL OR kols.opt_in_out_status = 0 OR kols.opt_in_out_status =4)','',false);
            }
            $this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
            $this->db->order_by( 'kols.first_name', 'asc' );
            $arrKolsResult = $this->db->get ( 'kols' );
            // 		echo $this->db->last_query();exit;
            return $arrKolsResult->result_array();
        }
        
        function getProjectKolIds($projectId){
            $arrKolIds = array();
            $this->db->select('kol_id');
            $this->db->where('project_id',$projectId);
            $res = $this->db->get('project_kols');
            foreach($res->result_array() as $row){
                $arrKolIds[] = $row['kol_id'];
            }
            return $arrKolIds;
        }
}
