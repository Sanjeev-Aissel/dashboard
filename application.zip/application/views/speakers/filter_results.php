<?php ?>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/refinedByFilter.css" />

<style>
    .profileScoreCategoryBar{
        float:left;
    }
    #speakerForm .ui-datepicker-title{
        color:#fff !important;
    }		
    .formContainer span{
        color:#ff0000;
    }

    #speakerForm .ui-datepicker-calendar th{
        color:#fff !important;
    }
    #speakerForm .fieldContainer{
        margin-top:2px;
        margin-bottom:20px;
    }

    #speakerForm .inputFiedConatiner{
        margin-left: 6px;
        margin-top: 10px;
    }

    #speakerForm input[type="text"], #speakerForm select{
        width:293px;
    }

    #speakerForm .inputLabel{
        margin-left: 2px;
    }
    #speakerForm .questionHeading{
        border-bottom: 1px solid #cccccc;
        color: #333333;
        display: block;
        font-weight: bold !important;
        margin-bottom: 5px;
        margin-right: 25px;
        padding: 0 0 5px;
    }

    #speakerForm label{
        font-weight:normal;
    }
    .formContainer{
        /*margin-left:17px;*/
    }


    #speakerForm caption {
        background: transparent url("http://localhost/kolm/images/kolm-sprite-image.png") repeat-x scroll -2px -236px;
    }
    #speakerForm caption {
        border-left: 1px solid #ddd;
        border-right: 1px solid #ddd;
        color: #2d53af;
        font-weight: bold;
        line-height: 25px;
    }

    #speakerForm h5.heading {
        background: #d8e5f4 none repeat scroll 0 0;
        color: #2d53af;
        margin-bottom: 2px;
        padding: 5px;
    }
    .formContainer{
        /*margin-left: 10px;*/
        /*border: 1px solid #ccc;*/
        font-size: 12px;
    }
    .formContainer div{
        /*margin: 8px 0;*/
    }
    #speakerForm .manidatory{
        color:red;
    }
    #speakerForm{
        margin-left: 20px;
    }

    #speakerForm .buttonContainer{
        text-align: center; margin-bottom: 8px;
    }
    #speakerForm .buttonContainer input{
        height: 33px;
    }
    .ratingContent tr:nth-child(2n) {
        background: #eeeeee none repeat scroll 0 0;
        padding: 5px;
    }
    .ratingContent tr th {
        color: #333333;
        text-align: center;
    }
    .ratingContent tr td:not(:first-child) {
        color: #333333;
        text-align: center;
    }
    .capitalize {
    text-transform: capitalize;
}
<?php if(IS_IPAD_REQUEST == 1){ ?>
.optionHeader,.optionHeader1{
    
    width:330px !important;
    font-weight: normal;
    font-size: 12px;
}
.profileScoreCategoryBar{
     font-size: 12px;
}
      <?php } else { ?>
.optionHeader{
    
    font-weight: bold;
    width:200px !important;
}
.optionHeader1{
    
    font-weight: bold;
    width:400px !important;
}
      <?php } ?>
</style>
<div class="formContainer">

    <div id="addFormWrapper">
        <h5 class="heading">Speaker Evaluation</h5>
    </div>
    <form id="speakerForm">
        <div class="firstPageContainer" style="">

            <div class="fieldContainer">
                <label class="questionHeading"><span class='manidatory'>*</span>1. Evaluator</label><span id="evErr"></span>
                <?php
                // pr($results);
                foreach ($results['evaluator'] as $evaluator) {
                    //   pr($evaluator);
                    ?>
                    <?php //$evaluator=$evaluator[0];
                    // pr($evaluator); 
                    ?>
                    <table> <tr onclick="showParameters(this)" class="professionalCollapse">

                            <td class="right optionHeader" id="optionName" >
    <?php echo $evaluator['evaluator']; ?>
                            </td>
                            <td class="profileScoreCategoryBar">
                                <div class="filterBar">
                                    <div class="progress" title="<?php echo $evaluator['evaluator_count'] ?>">
                                        <div class="bar" style="width: <?php echo $evaluator['evaluator_count'] ?>%"></div>
                                    </div>
                                </div>

                            </td>
                            <td class="profileScoreCategoryBar">
                    <?php echo $evaluator['evaluator_count'] ?>
                            </td></tr> </table>
<?php } ?>


            </div>




            <div class="fieldContainer">
                <label class="questionHeading"><span class='manidatory'>*</span>4. Speaker Details</label><span id="spErr"></span>
<?php foreach ($results['speaker_detail'] as $speaker_detail) { ?>  
                    <table>
                        <tr onclick="showParameters(this)" class="professionalCollapse">

                            <td class="right optionHeader" id="optionName">
    <?php echo $speaker_detail['speaker_detail']; ?>
                            </td>
                            <td class="profileScoreCategoryBar">
                                <div class="filterBar">
                                    <div class="progress" title="<?php echo $speaker_detail['speaker_detail_count'] ?>">
                                        <div class="bar" style="width: <?php echo $speaker_detail['speaker_detail_count'] ?>%"></div>
                                    </div>
                                </div>

                            </td>
                            <td class="profileScoreCategoryBar">
    <?php echo $speaker_detail['speaker_detail_count'] ?>
                            </td>
                            <td class="left">
                                <label class="facet-toggle collapsed" ></label>
                            </td>
                        </tr></table><?php } ?>
            </div>
            <div class="fieldContainer" id="speaker_background">
                <label class="questionHeading"><span class='manidatory'>*</span> 5. Speaker background: </label><span id="sbErr"></span>
<?php foreach ($results['speaker_background'] as $speaker_background) { ?>  
                    <table>
                        <tr onclick="showParameters(this)" class="professionalCollapse">

                            <td class="right optionHeader" id="optionName">
    <?php echo $speaker_background['speaker_background']; ?>
                            </td>
                            <td class="profileScoreCategoryBar">
                                <div class="filterBar">
                                    <div class="progress" title="<?php echo $speaker_background['speaker_background_count'] ?>">
                                        <div class="bar" style="width: <?php echo $speaker_background['speaker_background_count'] ?>%"></div>
                                    </div>
                                </div>

                            </td>
                            <td class="profileScoreCategoryBar">
    <?php echo $speaker_background['speaker_background_count'] ?>
                            </td>
                            <td class="left">
                                <label class="facet-toggle collapsed" ></label>
                            </td>
                        </tr></table><?php } ?>
            </div><!--
            -->		<div class="fieldContainer">

                <label class="questionHeading">6. Was this a co-moderated program?</label>
<?php foreach ($results['moderated_program'] as $moderated_program) { ?>  
                    <table>
                        <tr onclick="showParameters(this)" class="professionalCollapse">

                            <td class="right capitalize optionHeader"  id="optionName">
    <?php echo $moderated_program['moderated_program']; ?>
                            </td>
                            <td class="profileScoreCategoryBar">
                                <div class="filterBar">
                                    <div class="progress" title="<?php echo $moderated_program['moderated_program_count'] ?>">
                                        <div class="bar" style="width: <?php echo $moderated_program['moderated_program_count'] ?>%"></div>
                                    </div>
                                </div>

                            </td>
                            <td class="profileScoreCategoryBar">
    <?php echo $moderated_program['moderated_program_count'] ?>
                            </td>
                            <td class="left">
                                <label class="facet-toggle collapsed" ></label>
                            </td>
                        </tr></table><?php } ?>
            </div><!--
            -->		<div class="fieldContainer">

                <label class="questionHeading"><span class='manidatory'>*</span>7. Venue</label><span id="veErr"></span>
<?php foreach ($results['venu'] as $venu) { ?>  
                    <table>
                        <tr onclick="showParameters(this)" class="professionalCollapse">

                            <td class="right optionHeader" id="optionName">
    <?php echo $venu['venu']; ?>
                            </td>
                            <td class="profileScoreCategoryBar">
                                <div class="filterBar">
                                    <div class="progress" title="<?php echo $venu['venu_count'] ?>">
                                        <div class="bar" style="width: <?php echo $venu['venu_count'] ?>%"></div>
                                    </div>
                                </div>

                            </td>
                            <td class="profileScoreCategoryBar">
    <?php echo $venu['venu_count'] ?>
                            </td>
                            <td class="left">
                                <label class="facet-toggle collapsed" ></label>
                            </td>
                        </tr></table><?php } ?>

            </div><!--
            -->		<div class="fieldContainer">

                <label class="questionHeading"><span class='manidatory'>*</span>8. Was venue appropriate for a promotional educational presentation (low noise level, private room/area, minimal distractions and modest venue)?</label><span id="vpErr"></span>
<?php foreach ($results['venu_presentation'] as $venu_presentation) { ?>  
                    <table>
                        <tr onclick="showParameters(this)" class="professionalCollapse">

                            <td class="right optionHeader" id="optionName">
    <?php echo $venu_presentation['venu_presentation']; ?>
                            </td>
                            <td class="profileScoreCategoryBar">
                                <div class="filterBar">
                                    <div class="progress" title="<?php echo $venu_presentation['venu_presentation_count'] ?>">
                                        <div class="bar" style="width: <?php echo $venu_presentation['venu_presentation_count'] ?>%"></div>
                                    </div>
                                </div>

                            </td>
                            <td class="profileScoreCategoryBar">
    <?php echo $venu_presentation['venu_presentation_count'] ?>
                            </td>
                            <td class="left">
                                <label class="facet-toggle collapsed" ></label>
                            </td>
                        </tr></table><?php } ?>
            </div><!--
            
            -->		<div class="fieldContainer">
                <label class="questionHeading"><span class='manidatory'>*</span>9. Did audio/visual setup work properly?</label><span id="auErr"></span>
<?php foreach ($results['audio_setup'] as $audio_setup) { ?>  
                    <table>
                        <tr onclick="showParameters(this)" class="professionalCollapse">

                            <td class="right capitalize optionHeader" id="optionName">
    <?php echo $audio_setup['audio_setup']; ?>
                            </td>
                            <td class="profileScoreCategoryBar">
                                <div class="filterBar">
                                    <div class="progress" title="<?php echo $audio_setup['audio_setup_count'] ?>">
                                        <div class="bar" style="width: <?php echo $audio_setup['audio_setup_count'] ?>%"></div>
                                    </div>
                                </div>

                            </td>
                            <td class="profileScoreCategoryBar">
    <?php echo $audio_setup['audio_setup_count'] ?>
                            </td>
                            <td class="left">
                                <label class="facet-toggle collapsed" ></label>
                            </td>
                        </tr></table><?php } ?>

            </div>	<!--
            
            -->		<div class="fieldContainer">
                <label class="questionHeading"><span class='manidatory'>*</span>10. Program Topic</label><span id="ptErr"></span>
<?php foreach ($results['program_topic'] as $program_topic) { ?>  
                    <table>
                        <tr onclick="showParameters(this)" class="professionalCollapse">

                            <td class="right optionHeader" id="optionName" >
    <?php echo $program_topic['program_topic']; ?>
                            </td>
                            <td class="profileScoreCategoryBar">
                                <div class="filterBar">
                                    <div class="progress" title="<?php echo $program_topic['program_topic_count'] ?>">
                                        <div class="bar" style="width: <?php echo $program_topic['program_topic_count'] ?>%"></div>
                                    </div>
                                </div>

                            </td>
                            <td class="profileScoreCategoryBar">
    <?php echo $program_topic['program_topic_count'] ?>
                            </td>
                            <td class="left">
                                <label class="facet-toggle collapsed" ></label>
                            </td>
                        </tr></table><?php } ?>
            </div><!--
            <div class="buttonContainer">
            
            <input type="button" onclick="showNext()" value="Next"></input>
            <input type="button" onclick="hideViewEvaluation()" value="Cancel"></input>
            </div>
    </div>
            
            
            <div class="secondPage" style="display:none">
            -->				<div class="fieldContainer">
                <div class="abilify questDetail">	
                    <label class="questionHeading">11. Abilify Maintena:</label>
<?php foreach ($results['abilify_maintena'] as $abilify_maintena) { ?>  
                        <table>
                            <tr onclick="showParameters(this)" class="professionalCollapse">

                                <td class="right optionHeader" id="optionName">
    <?php echo $abilify_maintena['abilify_maintena']; ?>
                                </td>
                                <td class="profileScoreCategoryBar">
                                    <div class="filterBar">
                                        <div class="progress" title="<?php echo $abilify_maintena['abilify_maintena_count'] ?>">
                                            <div class="bar" style="width: <?php echo $abilify_maintena['abilify_maintena_count'] ?>%"></div>
                                        </div>
                                    </div>

                                </td>
                                <td class="profileScoreCategoryBar">
    <?php echo $abilify_maintena['abilify_maintena_count'] ?>
                                </td>
                                <td class="left">
                                    <label class="facet-toggle collapsed" ></label>
                                </td>
                            </tr></table><?php } ?>
                </div>
            </div>
            <div class="fieldContainer">
                <div class="rexulti questDetail">
                    <label class="questionHeading">12. Rexulti:</label>
<?php foreach ($results['rexulti'] as $rexulti) { ?>  
                        <table>
                            <tr onclick="showParameters(this)" class="professionalCollapse">

                                <td class="right optionHeader" id="optionName">
    <?php echo $rexulti['rexulti']; ?>
                                </td>
                                <td class="profileScoreCategoryBar">
                                    <div class="filterBar">
                                        <div class="progress" title="<?php echo $rexulti['rexulti_count'] ?>">
                                            <div class="bar" style="width: <?php echo $rexulti['rexulti_count'] ?>%"></div>
                                        </div>
                                    </div>

                                </td>
                                <td class="profileScoreCategoryBar">
    <?php echo $rexulti['rexulti_count'] ?>
                                </td>
                                <td class="left">
                                    <label class="facet-toggle collapsed" ></label>
                                </td>
                            </tr></table><?php } ?>
                </div>
            </div><!--
            
            -->				<div class="fieldContainer">
                <div class="nuedexta questDetail">
                    <label class="questionHeading">13. Nuedexta:</label>
<?php foreach ($results['nuedexta'] as $nuedexta) { ?>  
                        <table>
                            <tr onclick="showParameters(this)" class="professionalCollapse">

                                <td class="right optionHeader" id="optionName">
    <?php echo $nuedexta['nuedexta']; ?>
                                </td>
                                <td class="profileScoreCategoryBar">
                                    <div class="filterBar">
                                        <div class="progress" title="<?php echo $nuedexta['nuedexta_count'] ?>">
                                            <div class="bar" style="width: <?php echo $nuedexta['nuedexta_count'] ?>%"></div>
                                        </div>
                                    </div>

                                </td>
                                <td class="profileScoreCategoryBar">
    <?php echo $nuedexta['nuedexta_count'] ?>
                                </td>
                                <td class="left">
                                    <label class="facet-toggle collapsed" ></label>
                                </td>
                            </tr></table><?php } ?>
                </div>
            </div><!--
            
            -->				<div class="fieldContainer">
                <div class="samsca questDetail">
                    <label class="questionHeading">14. Samsca:</label>
<?php foreach ($results['samsca'] as $samsca) { ?>  
                        <table>
                            <tr onclick="showParameters(this)" class="professionalCollapse">

                                <td class="right optionHeader" id="optionName">
    <?php echo $samsca['samsca']; ?>
                                </td>
                                <td class="profileScoreCategoryBar">
                                    <div class="filterBar">
                                        <div class="progress" title="<?php echo $samsca['samsca_count'] ?>">
                                            <div class="bar" style="width: <?php echo $samsca['samsca_count'] ?>%"></div>
                                        </div>
                                    </div>

                                </td>
                                <td class="profileScoreCategoryBar">
    <?php echo $samsca['samsca_count'] ?>
                                </td>
                                <td class="left">
                                    <label class="facet-toggle collapsed" ></label>
                                </td>
                            </tr></table><?php } ?>
                </div>
            </div><!--
            
            -->					<div class="fieldContainer" style="display:none;">
                <div class="disease questDetail">
                    <label class="questionHeading">15. Disease State (Enter Program Topic Below)</label>
<?php foreach ($results['disease_state'] as $disease_state) { ?>  
                        <table>
                            <tr onclick="showParameters(this)" class="professionalCollapse">

                                <td class="right optionHeader" id="optionName">
    <?php echo $disease_state['disease_state']; ?>
                                </td>
                                <td class="profileScoreCategoryBar">
                                    <div class="filterBar">
                                        <div class="progress" title="<?php echo $disease_state['disease_state_count'] ?>">
                                            <div class="bar" style="width: <?php echo $disease_state['disease_state_count'] ?>%"></div>
                                        </div>
                                    </div>

                                </td>
                                <td class="profileScoreCategoryBar">
    <?php echo $disease_state['disease_state_count'] ?>
                                </td>
                                <td class="left">
                                    <label class="facet-toggle collapsed" ></label>
                                </td>
                            </tr></table><?php } ?>
                </div>
            </div>
            <?php if(!empty($results['psychu'][0]['psychu_count'])) { ?>
            <div class="fieldContainer">
                <div class="psychU questDetail">
                    <label class="questionHeading">16. PsychU (Enter Program Topic Below)</label>
<?php foreach ($results['psychu'] as $psychu) { ?>  
                        <table>
                            <tr onclick="showParameters(this)" class="professionalCollapse">

                                <td class="right optionHeader" id="optionName">
    <?php echo $psychu['psychu']; ?>
                                </td>
                                <td class="profileScoreCategoryBar">
                                    <div class="filterBar">
                                        <div class="progress" title="<?php echo $psychu['psychu_count'] ?>">
                                            <div class="bar" style="width: <?php echo $psychu['psychu_count'] ?>%"></div>
                                        </div>
                                    </div>

                                </td>
                                <td class="profileScoreCategoryBar">
    <?php echo $psychu['psychu_count'] ?>
                                </td>
                                <td class="left">
                                    <label class="facet-toggle collapsed" ></label>
                                </td>
                            </tr></table><?php } ?>
                </div>
            </div>
            <?php } ?>
            <div class="fieldContainer">

                <label class="questionHeading"><span class='manidatory'>*</span>17. Were the attendees the appropriate audience for the topic(s) presented?</label><span id="tpErr"></span>
<?php foreach ($results['topic_presented'] as $topic_presented) { ?>  
                    <table>
                        <tr onclick="showParameters(this)" class="professionalCollapse">

                            <td class="right optionHeader" id="optionName">
    <?php echo $topic_presented['topic_presented']; ?>
                            </td>
                            <td class="profileScoreCategoryBar">
                                <div class="filterBar">
                                    <div class="progress" title="<?php echo $topic_presented['topic_presented_count'] ?>">
                                        <div class="bar" style="width: <?php echo $topic_presented['topic_presented_count'] ?>%"></div>
                                    </div>
                                </div>

                            </td>
                            <td class="profileScoreCategoryBar">
    <?php echo $topic_presented['topic_presented_count'] ?>
                            </td>
                            <td class="left">
                                <label class="facet-toggle collapsed" ></label>
                            </td>
                        </tr></table><?php } ?>	
            </div><!--
                                            
                                            <div class="fieldContainer">
                                            <label class="questionHeading"><span class='manidatory'>*</span>18. What actions were taken to assure only appropriate individuals were in the audience?</label>
                                            <div><textarea name="action"></textarea>
                                            </div>
                                            </div>
                                            
                                                    
            -->				<div class="fieldContainer">
                <label class="questionHeading"><span class='manidatory'>*</span>19. Please rate the speakers based on the following:</label><div>
<?php foreach ($results_rating['speaker_ratings'] as $speaker_ratings) { ?>  
                        <table>
                            <tr onclick="showParameters(this)" class="professionalCollapse">

                                <td class="right optionHeader1" id="optionName">
                                    <?php
                                    $arrQuestions = array(1 => 'Product / Topic Knowledge', 2 => 'Effectiveness of delivery', 3 => 'Ability to answer questions', 4 => "Ability to hold the audience's
attention", 5 => 'Ability to engage audience in discussion', 6 => 'Provided an impactful presentation', 7 => 'Ability to present in fair and balanced manner');
                                    foreach ($arrQuestions as $key => $value) {
                                        if ($speaker_ratings['question_id'] == $key) {
                                            echo "<label>" . $value . "</label>";
                                            if ($speaker_ratings['speaker_rating'] == 1)
                                                echo "&nbsp; Outstanding";
                                            if ($speaker_ratings['speaker_rating'] == 2)
                                                echo "&nbsp; Strong";
                                            if ($speaker_ratings['speaker_rating'] == 3)
                                                echo "&nbsp; Satisfactory";
                                            if ($speaker_ratings['speaker_rating'] == 4)
                                                echo "&nbsp; Poor";
                                            if ($speaker_ratings['speaker_rating'] == 5)
                                                echo "&nbsp; Very Poor";
                                            if ($speaker_ratings['speaker_rating'] == 6)
                                                echo "&nbsp; N/A";
                                        }
                                    }
                                ?> 
    <?php // if($speaker_ratings['question_id']==1){ echo "<label> Product / Topic Knowledge</label>"; ?> 
    <?php //if($speaker_ratings['speaker_rating']==1) echo "Outstanding"; ?>
    <?php // if($speaker_ratings['speaker_rating']==2) echo "Strong"; ?>
    <?php // if($speaker_ratings['speaker_rating']==3) echo "Satisfactory"; ?>
    <?php //  if($speaker_ratings['speaker_rating']==4) echo "Poor"; ?>
    <?php // if($speaker_ratings['speaker_rating']==5) echo "Very Poor"; ?>
    <?php //if($speaker_ratings['speaker_rating']==6) echo "N/A"; } ?>
    <?php //echo $speaker_ratings['speaker_rating'].$speaker_ratings['question_id'];  ?>
                                </td>
                                <td class="">
                                    <div class="filterBar">
                                        <div class="progress" title="<?php echo $speaker_ratings['speaker_ratings_count'] ?>">
                                            <div class="bar" style="width: <?php echo $speaker_ratings['speaker_ratings_count'] ?>%"></div>
                                        </div>
                                    </div>

                                </td>
                                <td class="">
    <?php echo $speaker_ratings['speaker_ratings_count'] ?>
                                </td>
                                <td class="left">
                                    <label class="facet-toggle collapsed" ></label>
                                </td>
                            </tr></table><?php } ?>

                    <!--
            
                                                    <table class="ratingContent">
                                                            <tr>
                                                                    <th>
                                                                            
                                                                    </th>
                                                                    <th>
                                                                    5 </br>
                                                                    (Outstanding)
                                                                    </th>
                                                                    <th>
                                                                    4 </br>
                                                                    (Strong)
                                                                    </th>
                                                                    <th>
                                                                    3 </br>
                                                                    (Satisfactory)
                                                                    </th>
                                                                    <th>
                                                                    2 </br>
                                                                    (Poor)
                                                                    </th>
                                                                    <th>
                                                                    1 </br>
                                                                    (Very Poor)
                                                                    </th>
                                                                    <th>
                                                                    N/A
                                                                    </th>
                                                            </tr>
<?php foreach ($arrQuestions as $key => $row) { ?>
                                                                <tr>
                                                                        <td style="width:28%">
                                                                                <label>
    <?php echo $row; ?>
                                                                                </label>
                                                                        </td>
                                                                        <td>
                                                                        <input type='radio' name="speaker_rate_<?php echo $key ?>" value="5">
                                                                        </td>
                                                                        <td>
                                                                        <input type='radio' name="speaker_rate_<?php echo $key ?>" value="4">
                                                                        </td>
                                                                        <td>
                                                                        <input type='radio' name="speaker_rate_<?php echo $key ?>" value="3">
                                                                        </td>
                                                                        <td>
                                                                        <input type='radio' name="speaker_rate_<?php echo $key ?>" value="2">
                                                                        </td>
                                                                        <td>
                                                                        <input type='radio' name="speaker_rate_<?php echo $key ?>" value="1">
                                                                        </td>
                                                                        <td>
                                                                        <input type='radio' name="speaker_rate_<?php echo $key ?>" value="0">
                                                                        </td>
                                                                </tr>
<?php } ?>
                                                    
                                                    </table>
                                                    <div>
                                                    
                                                    
                                                    </div>
                                                    
                                            </div>
                                            
                    -->				<div class="fieldContainer">

                        <label class="questionHeading"><span class='manidatory'>*</span>20. Did the speaker stay within label during the presentation?</label><span id="ssErr"></span>
<?php foreach ($results['speaker_stay'] as $speaker_stay) { ?>  
                            <table>
                                <tr onclick="showParameters(this)" class="professionalCollapse">

                                    <td class="right optionHeader" id="optionName">
    <?php echo $speaker_stay['speaker_stay']; ?>
                                    </td>
                                    <td class="profileScoreCategoryBar">
                                        <div class="filterBar">
                                            <div class="progress" title="<?php echo $speaker_stay['speaker_stay_count'] ?>">
                                                <div class="bar" style="width: <?php echo $speaker_stay['speaker_stay_count'] ?>%"></div>
                                            </div>
                                        </div>

                                    </td>
                                    <td class="profileScoreCategoryBar">
    <?php echo $speaker_stay['speaker_stay_count'] ?>
                                    </td>
                                    <td class="left">
                                        <label class="facet-toggle collapsed" ></label>
                                    </td>
                                </tr></table><?php } ?>				
                    </div><!--
                                                    
                    -->				<div class="fieldContainer">

                        <label class="questionHeading"><span class='manidatory'>*</span>21. Did the speaker minimize or dismiss product safety information?</label><span id="siErr"></span>
<?php foreach ($results['saftey_info'] as $saftey_info) { ?>  
                            <table>
                                <tr onclick="showParameters(this)" class="professionalCollapse">

                                    <td class="right optionHeader" id="optionName">
    <?php echo $saftey_info['saftey_info']; ?>
                                    </td>
                                    <td class="profileScoreCategoryBar">
                                        <div class="filterBar">
                                            <div class="progress" title="<?php echo $saftey_info['saftey_info_count'] ?>">
                                                <div class="bar" style="width: <?php echo $saftey_info['saftey_info_count'] ?>%"></div>
                                            </div>
                                        </div>

                                    </td>
                                    <td class="profileScoreCategoryBar">
    <?php echo $saftey_info['saftey_info_count'] ?>
                                    </td>
                                    <td class="left">
                                        <label class="facet-toggle collapsed" ></label>
                                    </td>
                                </tr></table><?php } ?>	
                    </div>
                    <!--
                    
                    -->				<div class="fieldContainer">

                        <label class="questionHeading"><span class='manidatory'>*</span>22. Was all off label discussion appropriately handled per Otsuka policy including documentation using a MIRF?</label><span id="miErr"></span>
<?php foreach ($results['mirf'] as $mirf) { ?>  
                            <table>
                                <tr onclick="showParameters(this)" class="professionalCollapse">

                                    <td class="right optionHeader" id="optionName">
    <?php echo $mirf['mirf']; ?>
                                    </td>
                                    <td class="profileScoreCategoryBar">
                                        <div class="filterBar">
                                            <div class="progress" title="<?php echo $mirf['mirf_count'] ?>">
                                                <div class="bar" style="width: <?php echo $mirf['mirf_count'] ?>%"></div>
                                            </div>
                                        </div>

                                    </td>
                                    <td class="profileScoreCategoryBar">
    <?php echo $mirf['mirf_count'] ?>
                                    </td>
                                    <td class="left">
                                        <label class="facet-toggle collapsed" ></label>
                                    </td>
                                </tr></table><?php } ?>	
                    </div><!--
                    
                    -->
                    <div class="fieldContainer">

                        <label class="questionHeading"><span class='manidatory'>*</span>23. Were any adverse events reported by any attendee during the event?</label><span id="aeErr"></span>
<?php foreach ($results['adverse_event'] as $adverse_event) { ?>  
                            <table>
                                <tr onclick="showParameters(this)" class="professionalCollapse">

                                    <td class="right optionHeader" id="optionName">
    <?php echo $adverse_event['adverse_event']; ?>
                                    </td>
                                    <td class="profileScoreCategoryBar">
                                        <div class="filterBar">
                                            <div class="progress" title="<?php echo $adverse_event['adverse_event_count'] ?>">
                                                <div class="bar" style="width: <?php echo $adverse_event['adverse_event_count'] ?>%"></div>
                                            </div>
                                        </div>

                                    </td>
                                    <td class="profileScoreCategoryBar">
                                <?php echo $adverse_event['adverse_event_count'] ?>
                                    </td>
                                    <td class="left">
                                        <label class="facet-toggle collapsed" ></label>
                                    </td>
                                </tr></table><?php } ?>	
                    </div><!--
                    -->				<div class="fieldContainer">	
                        <div class="policyContainer">
                            <label class="questionHeading"><span class='manidatory'>*</span>24. Was the adverse event reported as per Otsuka Policy?</label><span id="aerErr"></span>
<?php foreach ($results['adverse_event_report'] as $adverse_event_report) { ?>  
                                <table>
                                    <tr onclick="showParameters(this)" class="professionalCollapse">

                                        <td class="right optionHeader" id="optionName">
    <?php echo $adverse_event_report['adverse_event_report']; ?>
                                        </td>
                                        <td class="profileScoreCategoryBar">
                                            <div class="filterBar">
                                                <div class="progress" title="<?php echo $adverse_event_report['adverse_event_report_count'] ?>">
                                                    <div class="bar" style="width: <?php echo $adverse_event_report['adverse_event_report_count'] ?>%"></div>
                                                </div>
                                            </div>

                                        </td>
                                        <td class="profileScoreCategoryBar">
    <?php echo $adverse_event_report['adverse_event_report_count'] ?>
                                        </td>
                                        <td class="left">
                                            <label class="facet-toggle collapsed" ></label>
                                        </td>
                                    </tr></table><?php } ?>	
                        </div>
                    </div><!--
                    
                    -->				<div class="fieldContainer">	
                        <div class="productContainer">
                            <label class="questionHeading"><span class='manidatory'>*</span>25. Was the speaker's articulation of their experience with the product on label?</label><span id="saErr"></span>
<?php foreach ($results['speaker_articulation'] as $speaker_articulation) { ?>  
                                <table>
                                    <tr onclick="showParameters(this)" class="professionalCollapse">

                                        <td class="right optionHeader" id="optionName">
    <?php echo $speaker_articulation['speaker_articulation']; ?>
                                        </td>
                                        <td class="profileScoreCategoryBar">
                                            <div class="filterBar">
                                                <div class="progress" title="<?php echo $speaker_articulation['speaker_articulation_count'] ?>">
                                                    <div class="bar" style="width: <?php echo $speaker_articulation['speaker_articulation_count'] ?>%"></div>
                                                </div>
                                            </div>

                                        </td>
                                        <td class="profileScoreCategoryBar">
                            <?php echo $speaker_articulation['speaker_articulation_count'] ?>
                                        </td>
                                        <td class="left">
                                            <label class="facet-toggle collapsed" ></label>
                                        </td>
                                    </tr></table><?php } ?>	
                        </div>
                    </div><!--
                    -->				<div class="fieldContainer">
                        <label class="questionHeading"><span class='manidatory'>*</span>26. Was all off label discussion appropriately handled per Otsuka policy including documentation using a MIRF?</label><span id="mdErr"></span>
<?php foreach ($results['mirf_doc'] as $mirf_doc) { ?>  
                            <table>
                                <tr onclick="showParameters(this)" class="professionalCollapse">

                                    <td class="right optionHeader" id="optionName">
    <?php echo $mirf_doc['mirf_doc']; ?>
                                    </td>
                                    <td class="profileScoreCategoryBar">
                                        <div class="filterBar">
                                            <div class="progress" title="<?php echo $mirf_doc['mirf_doc_count'] ?>">
                                                <div class="bar" style="width: <?php echo $mirf_doc['mirf_doc_count'] ?>%"></div>
                                            </div>
                                        </div>

                                    </td>
                                    <td class="profileScoreCategoryBar">
                            <?php echo $mirf_doc['mirf_doc_count'] ?>
                                    </td>
                                    <td class="left">
                                        <label class="facet-toggle collapsed" ></label>
                                    </td>
                                </tr></table><?php } ?>	
                    </div><!--
                    -->				<div class="fieldContainer">

                        <label class="questionHeading"><span class='manidatory'>*</span>27. Speaker was compliant based on Otsuka's Regulatory and Compliance Guidelines:</label><span id="guErr"></span>
<?php foreach ($results['guideline'] as $guideline) { ?>  
                            <table>
                                <tr onclick="showParameters(this)" class="professionalCollapse">

                                    <td class="right optionHeader" id="optionName">
    <?php echo $guideline['guideline']; ?>
                                    </td>
                                    <td class="profileScoreCategoryBar">
                                        <div class="filterBar">
                                            <div class="progress" title="<?php echo $guideline['guideline_count'] ?>">
                                                <div class="bar" style="width: <?php echo $guideline['guideline_count'] ?>%"></div>
                                            </div>
                                        </div>

                                    </td>
                                    <td class="profileScoreCategoryBar">
    <?php echo $guideline['guideline_count'] ?>
                                    </td>
                                    <td class="left">
                                        <label class="facet-toggle collapsed" ></label>
                                    </td>
                                </tr></table><?php } ?>	
                    </div><!--
                    
                    -->				<div class="fieldContainer">

                        <label class="questionHeading"><span class='manidatory'>*</span>28. On a scale of 15(1 = extremely unlikely; 5 = Extremely likely),How likely would you be to recommend this speaker to continue to be utilized by Otsuka?</label><span id="scErr"></span>
                                    <?php foreach ($results['scale'] as $scale) { ?>  
                            <table>
                                <tr onclick="showParameters(this)" class="professionalCollapse">

                                    <td class="right optionHeader" id="optionName">
    <?php if ($scale['scale'] == 1) echo "Extremely unlikely"; ?>
    <?php if ($scale['scale'] == 2) echo "Not likely"; ?>
    <?php if ($scale['scale'] == 3) echo "Somewhat likely"; ?>
    <?php if ($scale['scale'] == 4) echo "Likely"; ?>
    <?php if ($scale['scale'] == 5) echo "Extremely likely"; ?>
                                    </td>
                                    <td class="profileScoreCategoryBar">
                                        <div class="filterBar">
                                            <div class="progress" title="<?php echo $scale['scale_count'] ?>">
                                                <div class="bar" style="width: <?php echo $scale['scale_count'] ?>%"></div>
                                            </div>
                                        </div>

                                    </td>
                                    <td class="profileScoreCategoryBar">
    <?php echo $scale['scale_count'] ?>
                                    </td>
                                    <td class="left">
                                        <label class="facet-toggle collapsed" ></label>
                                    </td>
                                </tr></table><?php } ?>	
                            <!--					<table>
                                                                            <tr>
                                                                                    <td>
                                                                                    1.Extremely unlikely
                                                                                    </td>
                                                                                    <td>
                                                                                    2. Not likely
                                                                                    </td>
                                                                                    <td>
                                                                                    3. Somewhat likely
                                                                                    </td>
                                                                                    <td>
                                                                                    4. Likely
                                                                                    </td>
                                                                                    <td>
                                                                                    5. Extremely likely
                                                                                    </td>
                                                                            
                                                                            </tr>
                                                                            <tr>
                                                                                    <td>
                                                                                    <input type='radio' name="scale" value="1"></input>
                                                                                    </td>
                                                                                    <td>
                                                                                    <input type='radio' name="scale" value="2"></input>
                                                                                    </td>
                                                                                    <td>
                                                                                    <input type='radio' name="scale" value="3"></input>
                                                                                    </td>
                                                                                    <td>
                                                                                    <input type='radio' name="scale" value="4"></input>
                                                                                    </td>
                                                                                    <td>
                                                                                    <input type='radio' name="scale" value="5"></input>
                                                                                    </td>
                                                                            
                                                                            </tr>
                                                                    
                                                                    </table>-->
                    </div><!--
                    
                    -->					<div class="fieldContainer">

                        <label class="questionHeading"><span class='manidatory'>*</span>29. Recommend speaker for MSL followup visit for support (if any rating 3 or lower on any category, or identified need for greater than quarterly support):</label><span id="mfErr"></span>
<?php foreach ($results['msl_follow_up'] as $msl_follow_up) { ?>  
                            <table>
                                <tr onclick="showParameters(this)" class="professionalCollapse">

                                    <td class="right optionHeader" id="optionName">
    <?php echo $msl_follow_up['msl_follow_up']; ?>
                                    </td>
                                    <td class="profileScoreCategoryBar">
                                        <div class="filterBar">
                                            <div class="progress" title="<?php echo $msl_follow_up['msl_follow_up_count'] ?>">
                                                <div class="bar" style="width: <?php echo $msl_follow_up['msl_follow_up_count'] ?>%"></div>
                                            </div>
                                        </div>

                                    </td>
                                    <td class="profileScoreCategoryBar">
    <?php echo $msl_follow_up['msl_follow_up_count'] ?>
                                    </td>
                                    <td class="left">
                                        <label class="facet-toggle collapsed" ></label>
                                    </td>
                                </tr></table><?php } ?>	
                    </div>
                </div>
                </form>


            </div>






<!--<table>
    <tr><td  style="font-weight: bold">Evaluator</td></tr>

            <?php
            // pr($results);
            foreach ($results['evaluator'] as $evaluator) {
                //   pr($evaluator);
                ?>
    <?php //$evaluator=$evaluator[0];
    // pr($evaluator); 
    ?>
     <tr onclick="showParameters(this)" class="professionalCollapse">

                                        <td class="right" id="optionName"  style="font-weight: bold">
                <?php echo $evaluator['evaluator']; ?>
                                        </td>
                                        <td class="profileScoreCategoryBar">
                                            <div class="filterBar">
                                                <div class="progress" title="<?php echo $evaluator['evaluator_count'] ?>">
                                                    <div class="bar" style="width: <?php echo $evaluator['evaluator_count'] ?>%"></div>
                                                </div>
                                            </div>

                                        </td>
                                        <td>
    <?php echo $evaluator['evaluator_count'] ?>
                                        </td>
    <?php // } ?>
    </tr> 
<?php } foreach ($results['speaker_detail'] as $speaker_detail) { ?>  
     <tr onclick="showParameters(this)" class="professionalCollapse">

                                        <td class="right" id="optionName"  style="font-weight: bold">
                <?php echo $speaker_detail['speaker_detail']; ?>
                                        </td>
                                        <td class="profileScoreCategoryBar">
                                            <div class="filterBar">
                                                <div class="progress" title="<?php echo $speaker_detail['speaker_detail_count'] ?>">
                                                    <div class="bar" style="width: <?php echo $speaker_detail['speaker_detail_count'] ?>%"></div>
                                                </div>
                                            </div>

                                        </td>
                                        <td>
    <?php echo $speaker_detail['speaker_detail_count'] ?>
                                        </td>
                                        <td class="left">
                                            <label class="facet-toggle collapsed" ></label>
                                        </td>
    </tr><?php } ?>
</table>-->