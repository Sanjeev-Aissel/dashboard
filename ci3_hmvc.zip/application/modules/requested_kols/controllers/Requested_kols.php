<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class requested_kols extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->model('requested_kol');
		$this->load->model('kols/kol');
		$this->load->model('specialities/Speciality');
		$this->load->model('helpers/common_helper');
	}
	function request_kol_profile($kolId=0){
		$this->isApprover	= IS_APPROVER;
		$dataFound	= false;
		$data['msg'] = "Error in requesting profile";
		$data['saved'] = false;
		$arrKol	= array();
		if($kolId==0){
			$arrData = $this->session->flashdata('arrData');
			$dataFound	= true;
			//if($arrData['kol_id']==0){
			$arrKol['first_name']	 	=	ucwords(trim($arrData['first_name']));
			$arrKol['middle_name']	 	=	ucwords(trim($arrData['middle_name']));
			$arrKol['last_name']     	=	ucwords(trim($arrData['last_name']));
			$orgDetails['name']        	=	ucwords(trim($arrData['org_name']));
			if($orgDetails['name'] !=''){
				$orgDetails['status']	= "Requested";
				// org type
				$orgDetails['profile_type'] = BASIC;
				$arrKol['org_id']	= $this->organization->saveOrganization($orgDetails);
			}
			$arrKol['country_id']	=	$arrData['country_id'];
			$arrKol['state_id']     =	$arrData['state_id'];
			$arrKol['city_id']      =	$arrData['city_id'];
			$arrKol['is_pubmed_processed']        =	1;
			$arrKol['created_by']	 = 	$this->loggedUserId;
			$arrKol['created_on']	 =	date("Y-m-d H:i:s");
			$arrKol['status']		 =	New1;
			$arrKol['request_status'] = 1;
			//$arrKol['profile_type'] = 'Full Profile';
			
			//if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN){
			if($this->isApprover){
				$arrKol['status']		 =	APPROVED;
				$arrKol['request_status'] = 3;
			}
			//Save KOL and Get Id
			$kolId = $this->kol->saveKolNoDuplicateCheck($arrKol);
		}else if($kolId>0){
			$arrKol	=$this->kol->editKol($kolId);
			$dataFound	= true;
		}
		if($dataFound){
			$arrUpdateKol['id'] 			=  $kolId;
			// 			$arrUpdateKol['pin'] 			=  $kolId;
			//$arrUpdateKol['profile_type'] =  'Full Profile';
			$arrUpdateKol['id']	=	$kolId;
			$arrUpdateKol['is_pubmed_processed']	=	1;
			$arrUpdateKol['status']		=	New1;
			$arrUpdateKol['request_status'] = 1;
			if($this->isApprover){
				$arrUpdateKol['status']	=	APPROVED;
				$arrUpdateKol['request_status'] = 3;
			}
			$this->requested_kol->updateClientPreKol($arrUpdateKol);
			//Save Profile Request
			$userRequest = array();
			$userRequest['kol_id'] = $kolId;
			$userRequest['requested_by'] = $this->loggedUserId;
			$userRequest['requested_on'] = date("Y-m-d H:i:s");
			$userRequest['status']		 =	New1;
			if($this->isApprover){
				$userRequest['status']		 =	APPROVED;
				$userRequest['rej_or_appr_by'] = $this->session->userdata('user_id');
				$userRequest['rej_or_appr_on'] = date("Y-m-d H:i:s");
			}
			$userRequest['request_for'] = REQUEST_TYPE_PROFILE;
			$userRequest['profile_type'] = 'Full Profile';
			$isSaved = $this->common_helper->insertEntity('user_requests',$userRequest);
			
			$data['msg'] = "Request saved succefully";
			$data['saved'] = true;
			$data['is_manager'] = false;
			if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN)
				$data['is_manager'] = true;
				
				$rowData = array();
				$rowData['id'] =  $isSaved;
				$rowData['kol_id'] = $userRequest['kol_id'];
				$rowData['kol_name'] = $arrSalutations[$arrKol['salutation']]." ".$this->common_helper->get_name_format($arrKol['first_name'],$arrKol['middle_name'], $arrKol['last_name']);;
				$rowData['org_name'] = $arrKol['org_id'];
				$rowData['request_for'] = 'Profile - '.ucwords($arrKol['profile_type']);
				$rowData['status'] = $userRequest['status'];
				$rowData['user_full_name'] = $this->session->userdata('user_full_name');
				$data['arrKol'] = $rowData;
				//Send mails
				$mailSent = $this->send_user_request_mails($arrKol);
				if(!$mailSent){
					$data['msg'] = "Error in sending mail";
					$data['saved'] = false;
				}
		}
		echo json_encode($data);
	}
	function send_user_request_mails($arrKol){
		$this->load->model('specialities/speciality');
		$this->isApprover	= IS_APPROVER;
		$arrSpecialties					= $this->speciality->getAllSpecialties();
		$config = email_config_initializer('profile_request');

		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear();
		//$config['mailtype'] = 'html';
		$this->email->set_newline("\r\n");
		$this->email->set_crlf( "\r\n" );
		$clientId = $this->session->userdata('client_id');
		
		//send mail to Analyst Managers if the request is from Client manager
		if($this->isApprover){
			$arr =array();
			$arr[$arrKol['id']] = $this->kol->editKol($arrKol['id']);
			
			$clientId = $this->session->userdata('client_id');
			$clientName = $this->common_helper->getFieldValueByEntityDetails('clients','id',$clientId,'name');
			$data1['clientName'] = $clientName;
			$data1['arrKols'] = $arr;
			$data1['requestAction'] = 'MANAGER_REQUEST_ANALYST';
			
			$analystMangerEmailId  = $this->requested_kol->getAnalystManagerEmailId();
			foreach($analystMangerEmailId as $email=>$ids){
				$emailIds[]=$ids['email'];
			}
			//pr($analystMangerEmailId);
			$analystMangerEmailIds = implode(',',$emailIds);
			$this->email->subject(PRODUCT_NAME.': New Profiling Request');
			$userNAme = $this->session->userdata('user_full_name');
			$this->email->from($config['smtp_user'],$userNAme);
			$arrKol['org_id']			= $this->kol->getOrgId($arrKol['org_id']);
			
			$arrKol['specialty']=$arrSpecialties[$arrKol['specialty']];
			$arrKol['country_name']		= $this->common_helper->getFieldValueByEntityDetails('countries','CountryID',$arrKol['country_id'],'Country');
			//Getting  the name of the specified 'state'  By passing The Id
			if($arrKol['state_id']!='' && $arrKol['state_id']!=0){
				$arrKol['state_name']			= $this->common_helper->getFieldValueByEntityDetails('states','id',$arrKol['state_id'],'name');
			}
			
			if($arrKol['city_id']!='' && $arrKol['city_id']!=0){
				//Getting  the name of the specified 'city'  By passing The Id
				$arrKol['city_name']			= $this->common_helper->getFieldValueByEntityDetails('cities','CityID',$arrKol['city_id'],'city');
			}
			//pr($arrKol);
			$data1['arrKol'] = $arrKol;
			$data1['requestAction'] = 'MANAGER_REQUEST_ANALYST';
			$html = $this->load->view('requested_kols/prepare_email_content',$data1,true);

			$this->email->message($html);
			$this->email->to($analystMangerEmailIds);
			$this->email->reply_to($analystMangerEmailIds);
			if($this->email->send()){
				$status	=  true;
			}else{
				$status	=  false;
			}
			$this->email->clear(TRUE);
			return $status;
		}else{
			//Send mail to  Client manager
			$userId = $this->session->userdata('user_id');
			//$clientMangerEmailIds = $this->Client_User->getUserManagerEmailId($userId);
			$managerEmailId = $this->Client_User->getUserManagerEmailId($userId);
			$approverIds	= explode(',',APPROVER_IDS);
			$clientMangerEmailIds = $this->Client_User->getUserEmailIdById($approverIds);
			//$clientMangerEmailIds[]	= $managerEmailId;
			$baseUrl = base_url().'requested_kols/show_client_requested_kols';
			$data1['arrKol'] = $arrKol;
			$data1['requestAction'] = 'USER_REQUEST_MANAGER';
			$html = $this->load->view('requested_kols/prepare_email_content',$data1,true);
			$emailStatus = $this->send_mail($clientMangerEmailIds,$managerEmailId,'New Profiling Request',$html);
			
			//Send mail to  User
			$userEmail = $this->session->userdata('email');
			$userRoleId = $this->session->userdata('user_role_id');
			$data1['arrKol'] = $arrKol;
			$data1['requestAction'] = 'USER_REQUEST_USER';
			$html = $this->load->view('prepare_email_content',$data1,true);
			//$this->email->reply_to($userEmail);
			$emailStatus = $this->send_mail($userEmail,'','New Profiling Request',$html);
			return $emailStatus;
		}
	}
	function send_mail($receipients,$additionalemailids,$subject,$html){
		$to    = $receipients;
		if(!is_array($receipients)){
			$to  = explode(",",$receipients);
		}
		$managerEmailId    = $additionalemailids;
		if(!is_array($additionalemailids)){
			$managerEmailId  = explode(",",$additionalemailids);
		}
		$emailDescription = "To- ".implode(",",$to)."<br/> CC- ".implode(",",$managerEmailId);
		$userNAme = $this->session->userdata('user_full_name');
		$config = email_config_initializer('profile_request');
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->set_newline("\r\n");
		$this->email->from($config['smtp_user'],$userNAme);
		$this->email->subject(PRODUCT_NAME.': '.$subject);
		$this->email->message($html);
		$this->email->to($to);
		$this->email->cc($managerEmailId);
		$this->email->set_crlf("\r\n");
		//$this->email->reply_to($clientMangerEmailIds);
		if($this->email->send()){
			$status	=  true;
		}else{
			$status	=  false;
		}
		$this->email->clear(TRUE);
		return $status;
	}
	/**
	 * List the Requested Kol detail
	 * @author Vinayak
	 * @version 4.2
	 * @since june 7,2012
	 * @param
	 * @return
	 *
	 */
	function list_requested_kols(){
	
		$this->common_helper->checkUsers();
		//$arrKolDetailResult = $this->kol->getRequestedKolDetail();
		$arrKolDetailResult = $this->requested_kol->listAll();
		$data			=	array();
		$arrKolDetail	=	array();
		$data['arrKol']	=	$arrKolDetailResult;
	
		// To show the pubmed and CT Links for Autorised users right now for user id=5
		$data['user_id'] = $this->session->userdata('user_id');
	
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		
		$arrSpecialties	= $this->Speciality->getAllSpecialties();
		$data['arrSpecialties']	= $arrSpecialties;
	
		//$data['clientUser'] = $this->Client_User->getUserDetail($this->session->userdata('user_id'));
	
		$data['contentPage'] 	=	'list_requested_kols';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	function update_request_status_analyst(){
		/* $config['protocol'] 	= PROTOCOL;
			$config['smtp_host'] 	= HOST;
			$config['smtp_port'] 	= PORT;
			$config['smtp_user'] 	= USER;
			$config['smtp_pass'] 	= PASS;
			$config['mailtype']		= 'html'; */
		$config = email_config_initializer('profile_request');
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear();
		$this->email->set_crlf( "\r\n" );
		$arr['status'] = $this->input->post('status');
		$arr['kolId'] = $this->input->post('kolId');
	
		$arr['modified_by'] =$this->loggedUserId;
		$status = 100;
		if($arr['status']==COMPLETED){
			$status = STATUS_COMPLETED;
		}
	
		if($arr['status']==APPROVED){
			$arr['approved_by'] =$this->loggedUserId;
			$status = STATUS_APPROVED;
		}
	
		if($arr['status'] == PROFILING)
			$status = STATUS_PROFILING;
			if($arr['status'] == REVIEW)
				$status = STATUS_REVIEW;
				if($arr['status'] == New1)
					$status = STATUS_NEW;
	
					foreach($arr['kolId'] as $id){
						//Update request
						$rowData = array();
						$arrRequestData = $this->requested_kol->get($id);
						$arrKol = $this->kol->editKol($arrRequestData['kol_id']);
						$rowData['id'] = $arrRequestData['id'];
						$rowData['status'] = $arr['status'];
						if($arr['status'] == APPROVED || $arr['status'] == REJECT){
							$rowData['rej_or_appr_by'] = $this->session->userdata('user_id');
							$rowData['rej_or_appr_on'] = date("Y-m-d H:i:s");
						}
						$isUpdated = $this->requested_kol->update($rowData);
							
						//Update KOL status
						if(($arrRequestData['request_for'] == REQUEST_TYPE_PROFILE && $arrKol['status'] == New1) || $arr['status'] == COMPLETED ){
							$kolDetails = array();
							$kolDetails['id'] = $arrRequestData['kol_id'];
							$kolDetails['status'] = $arr['status'];
							if($arr['status'] == COMPLETED)
								$kolDetails['profile_type'] = $arrRequestData['profile_type'];
								$this->kol->updateKol($kolDetails);
						}
							
						if($arr['status'] == APPROVED || $arr['status'] == REJECT || $arr['status'] == COMPLETED){
							//Send mail
							$userEmailId  = $this->requested_kol->getUserEmailId($arrRequestData['requested_by']);
							$data1['arrKol']=	$arrKol;
							$data1['arrRequestData']=	$arrRequestData;
							$userNAme = $this->session->userdata('user_full_name');
							$this->email->from($config['smtp_user'],$userNAme);
							if($arr['status'] == APPROVED){
								$this->email->subject(PRODUCT_NAME.': Profiling Request - Approved');
								$data1['requestAction'] = ANALYST_APPROVE_USER;
							}else if($arr['status'] == REJECT){
								$this->email->subject(PRODUCT_NAME.": Profiling Request - Rejected");
								$data1['requestAction'] = ANALYST_REJECT_USER;
							}else if($arr['status'] == COMPLETED){
								$this->email->subject(PRODUCT_NAME.': Profiling Request - Completed');
								$data1['requestAction'] = ANALYST_COMPLETE_USER;
							}
							$html = $this->load->view('requested_kols/prepare_email_content',$data1,true);
							$this->email->message($html);
							$this->email->to($userEmailId);
							$this->email->send();
	
							//Send mail to user manager if the status is completed
							if($arr['status'] == COMPLETED){
								$clientMangerEmailIds = $this->Client_User->getUserManagerEmailId($arrRequestData['requested_by']);
								$clientMangerEmailIds = str_replace($userEmailId, "", $clientMangerEmailIds);
								$clientMangerEmailIds = str_replace(",,", ",", $clientMangerEmailIds);
								$clientMangerEmailIds = trim($clientMangerEmailIds,',');
								if($clientMangerEmailIds != ''){
									$html = $this->load->view('requested_kols/prepare_email_content',$data1,true);
									$this->email->message($html);
									$this->email->subject(PRODUCT_NAME.': Profiling Request - Completed');
									$this->email->to($clientMangerEmailIds);
									$this->email->send();
								}
							}
	
						}
							
						//$this->update->insertUpdateEntry(KOL_STATUS_UPDATE,$status, MODULE_KOL_REQUEST, $kolId,$status);
					}
	
	
					if($arr['status']==COMPLETED){
						foreach($arr['kolId'] as $id){
							$arrRequestData = $this->requested_kol->get($id);
							$arrIds[]=$arrRequestData['kol_id'];
						}
						$arrUsers = $this->align_user->getRquetsterOfKol($arrIds);
						foreach($arrUsers as $row){
							//$this->align_user->assignKolsToUser($row);
						}
					}
	
	}
	function list_pre_requested_kols(){
		$this->common_helper->checkUsers();
		$clientId = $this->session->userdata('client_id');
		$status = PRENEW;
		$arrKolDetailResult = $this->requested_kol->getNonProfiledKols($status,$clientId);
	
		$data			=	array();
		$arrKolDetail	=	array();
		$data['arrKol']	=	$arrKolDetailResult;
	
		// To show the pubmed and CT Links for Autorised users right now for user id=5
		$data['user_id'] = $this->session->userdata('user_id');
	
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;

		$arrSpecialties	= $this->Speciality->getAllSpecialties();
		$data['arrSpecialties']	= $arrSpecialties;
	
		//$data['clientUser'] = $this->Client_User->getUserDetail($this->session->userdata('user_id'));
	
		$data['contentPage'] 	=	'list_pre_requested_kols';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	
}
?>