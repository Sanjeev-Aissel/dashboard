<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$autoload['packages'] = array();

$autoload['libraries'] = array('database','session','upload','email');

$autoload['drivers'] = array();


$autoload['helper'] = array('url','file','form','email','html','date','xml','path','string','language');


$autoload['config'] = array();


$autoload['language'] = array('kolm');


$autoload['model'] = array('helpers/common_helper');
