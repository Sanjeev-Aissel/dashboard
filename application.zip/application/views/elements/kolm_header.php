<?php
/**
 * Common headers for Kol Analyst application. 
 *
 * @author: Ambarish N
 * @created on: 01-02-11
 */

?>

	<div id="header">

		<div id="logo"><img alt="Aissel solutions" width="75" height="40" src="<?php echo base_url()?>images/kol_logo.jpg" /></div>

		<div id="topLeftMenu">
			<p class="loggedUserInfo"><img src="<?php echo base_url()?>images/user3.png" alt="" height="18" /> Hi, <?php echo $this->session->userdata('user_name');?></p>
		
			<div id="pageLoader" style="display:none">Loading Content....
				<img src="<?php echo base_url()?>images/ajax_loader_black.gif" />
			</div>
		
		</div>
		
		<div id="topRightMenu">
			<?php //echo $this->load->view('search/search_box');?>
			
			<a href="<?php echo base_url()?>kols/list_kols" class="indexLink"><img src="<?php echo base_url()?>images/homepage.gif" title="Index"/></a>
			
			&nbsp;&nbsp; | &nbsp;&nbsp;

			<a href="<?php echo base_url()?>login/logout" class="logoutLink"><img src="<?php echo base_url()?>images/logout_1.png" title="Logout"/></a>
		</div>

		<div id="topMenu">
			
		</div>
	</div>