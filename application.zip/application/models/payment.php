<?php
/**
 * This is Model file of 'Payment'
 * 
 * @package application.models
 * @author Ambarish
 * @since
 * @created on 28-02-11
 */

class Payment extends Model{
	
	//Constructor 	
	function Payment(){
		parent::Model();
	}
	
  	/**
	 * Saves the Payment Detail to DB 
	 * 
	 * @return Last Insert Id/false
	 */
	function savePayment($paymentDetails){
	    $clientId = $this->session->userdata('client_id');
	    $dataType = 'User Added';
	    if($clientId == INTERNAL_CLIENT_ID){
	        $dataType = 'Aissel Analyst';
	    }
	    $paymentDetails['data_type_indicator']=$dataType;
		if($this->db->insert('payments',$paymentDetails)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	/**
	 *  List all Payment details
	 *  
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 28-02-11
	 * 
	 * @param 
	 * @return array - $arrPaymentDetail - Returns
	 */
	function listPaymentDetails($clientId,$kolId,$userId,$startDate=0,$endDate=0,$limit=0){
	    $userGroupName = getGroupDetails();
		$arrPaymentDetail	=	array();
		$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$this->db->select(array('payments.*','kols.salutation','kols.first_name','kols.middle_name','kols.last_name','kols.status','kols.unique_id','payments.requested_by','payments.paid_by','kols.deleted_by as kol_deleted','CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name'));
		$this->db->select('CONCAT(COALESCE(CASE
									WHEN kols.salutation = 1 THEN "Dr."
									WHEN kols.salutation = 2 THEN "Prof."
									WHEN kols.salutation = 3 THEN "Mr."
									WHEN kols.salutation = 4 THEN "Ms."
									ELSE ""
									END ,""),COALESCE(kols.first_name,"")," ",COALESCE(kols.middle_name,"")," ",COALESCE(kols.last_name,"")) as kol_full_name,
	                              client_users.client_id,CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name',false);
		$this->db->join('kols', 'kols.id = payments.kol_id', 'left');
		$this->db->join('client_users', 'client_users.id = payments.created_by', 'left');

		//To check user is not the manager 
		//If he is not the manager then show only the created payments by him of that organization
		//if(($this->session->userdata('user_role_id')!=ROLE_MANAGER || $this->session->userdata('user_role_id')!=ROLE_ADMIN) && $userId!=0){
		//	$this->db->where('payments.created_by',$userId);
		//}
		//If he is the manager then show the payments of that organization irrespective of client_users of that organization
		if($clientId!=0){
		    if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where('payments.client_id',$clientId);
		    }
		}
		//Setting kol_id = -1 when track is clicked
		if($kolId!=null && $kolId!=-1){
			$this->db->where('payments.kol_id',$kolId);
		}
		if($startDate!=0 && $endDate!=0){
			$wherBetween="(payments.date  BETWEEN '".$startDate."-01' AND '".$endDate."-31')";
			$this->db->where($wherBetween);
		}
		/*if($userId!='' && $kolId==null){
			$this->db->where('payments.created_by',$userId);
		}*/
		if($kolId==null && $clientId!=INTERNAL_CLIENT_ID){
    		if($this->session->userdata('user_role_id')==ROLE_MANAGER || $this->session->userdata('user_role_id')==ROLE_USER){
    		    $group_names = explode(',',  $userGroupName['group_names']);
//     		    $group_names = explode(',', $this->session->userdata('group_names'));
    		    $this->db->join ( 'countries', 'countries.CountryId = kols.country_id', 'left' );
    		    $this->db->where_in ( 'countries.GlobalRegion', $group_names);
    		}
		}
		if($limit>0){
		  $this->db->limit($limit);
		}
		$this->db->order_by('kol_full_name','asc');
		$this->db->order_by('payments.date','desc');
		$arrPaymentDetailResult	=	$this->db->get('payments');
// 	pr($this->db->last_query());exit;
		foreach ($arrPaymentDetailResult->result_array() as $paymentDetail){
		    $paymentDetail['requested_by']		= $this->payment->getPaymentRequestedBy($paymentDetail['requested_by']);
		    $paymentDetail['paid_by']			= $this->payment->getPaymentPaidBy($paymentDetail['paid_by']);
			$arrPaymentDetail[] = $paymentDetail;
		}
     	//pr($arrPaymentDetail);
		return $arrPaymentDetail;
	}
	
	/**
	 * Get Payment details by Payment ID 
	 * 
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 01-03-11
	 * 
	 * @param $id
	 * @return array - $arrPaymentDetail 
	 */  
	function getPaymentById($paymentId){
		$arrPaymentDetail	= array();
		$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		
		$this->db->select(array('payments.*','kols.salutation','kols.first_name','kols.middle_name','kols.last_name','CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name'));
		//$this->db->join('payment_split', 'payment_split.payment_id = payments.id', 'left');
	//	$this->db->join('payment_types', 'payment_types.id = payment_split.type', 'left');
		$this->db->join('kols', 'kols.id = payments.kol_id', 'left');
		$this->db->join('client_users', 'client_users.id = payments.created_by', 'left');
		
		$this->db->where('payments.id',$paymentId);
		if($arrPaymentDetailResult	=	$this->db->get('payments')){
			// If the results are not available
			if($arrPaymentDetailResult->num_rows() == 0){
				return false;
			}
			foreach($arrPaymentDetailResult->result_array() as $arrPayment){
				$arrPayment['date'] = $this->convertDateToMM_DD_YYYY($arrPayment['date']);
				if($arrPayment['date']=='00/00/0000'){
			 		$arrPayment['date']='';
			 	}
			 	
				//setting Kol Name 
				//if( $arrPayment['salutation']!=0){
					//$arrPayment['kol_name']= $arrSalutations[$arrPayment['salutation']].$arrPayment['first_name'].' '.$arrPayment['middle_name'].' '.$arrPayment['last_name'];
				//}else{
//					$arrPayment['kol_name']= $arrPayment['first_name'].' '.$arrPayment['middle_name'].' '.$arrPayment['last_name'];
					$arrPayment['kol_name']= nf($arrPayment['first_name'],$arrPayment['middle_name'],$arrPayment['last_name']);
			//	}
			
				$arrPaymentDetail	= $arrPayment;
			}
			return $arrPaymentDetail;
		}else{
			return false;
		}
	}	
	
   	/**
	 * Updates the Payment Details Data 
	 * 
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 01-03-11
	 * 
	 * @return true/false
	 */
	function updatePayment($paymentDetails){
		$result=array();
		$this->db->where('id',$paymentDetails['id']);
		if($this->db->update('payments',$paymentDetails)){
			return true;
		}else{
			return false;
		}
	}
	
  	/**
	 * Delete the Payment Details By Id
	 * 
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 01-03-11
	 * 
	 */	
  	function deletePaymentById($paymentId){
  		$this->db->select('kol_id');
  		$this->db->where('id',$paymentId);
  		$queryRes = $this->db->get('payments');
  		$row = $queryRes->row();
  		if (isset($row))
  		{
  			if($row->kol_id > 0){
  				$transactionName = 'Delete payments';
  				$kol_org_type = 'Kol';
  				$kols_or_org_id = $row->kol_id;
  				$parentObjectId = $row->kol_id;
  			}
  		}
		$this->db->where('id',$paymentId);
		if($query=$this->db->delete('payments')){
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
					'description' => $transactionName,
					'status' => STATUS_SUCCESS,
					'kols_or_org_type' => $kol_org_type,
					'kols_or_org_id' => $kols_or_org_id,
					'transaction_id' =>  $paymentId,
					'transaction_table_id' => PAYMENTS,
					'transaction_name' => $transactionName,
					'parent_object_id' =>  $parentObjectId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return true;
		}else{
			//Add Log activity
			$arrLogDetails = array(
					'type' => DELET_RECORD,
					'description' => $transactionName,
					'status' => STATUS_FAIL,
					'kols_or_org_type' => $kol_org_type,
					'kols_or_org_id' => $kols_or_org_id,
					'transaction_id' =>  $paymentId,
					'transaction_table_id' => PAYMENTS,
					'transaction_name' => $transactionName,
					'parent_object_id' =>  $parentObjectId
			);
			$this->config->set_item('log_details', $arrLogDetails);
			return false;
		}
	}
	
	/**
	 * Returns all Payment Types from 'payment_types' Table
	 * 
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 02-03-11
	 * 
	 * @return unknown_type
	 */
	function getAllPaymentTypes(){
		$arrPaymentTypes	= array();
		
		$arrPaymentTypesResult = $this->db->get('payment_types');
		foreach($arrPaymentTypesResult->result_array() as $arrPaymentType){
			$arrPaymentTypes[$arrPaymentType['id']]	= $arrPaymentType['name'];
		}
		return $arrPaymentTypes;
	}
	
	function arrPaymentCurrencies(){
		$arrPaymentCurrencies	= array();
		$arrPaymentCurrencyResult = $this->db->get('payments_currency');
		foreach($arrPaymentCurrencyResult->result_array() as $arrPaymentCurrency){
			$arrPaymentCurrencies[$arrPaymentCurrency['id']]	= $arrPaymentCurrency;
		}
		return $arrPaymentCurrencies;
	}
	
	/**
	 * Returns all Interaction Id's from 'interactions' Table
	 * 
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 02-03-11
	 * 
	 * @return unknown_type
	 */
	function getAllInteractionIds($clientId,$userId){
		$arrInteractionIds	= array();
		if($this->session->userdata('user_role_id')!=ROLE_MANAGER || $this->session->userdata('user_role_id')!=ROLE_ADMIN)
			$this->db->where('created_by',$userId);		
		$this->db->where('client_id',$clientId);
		$arrInteractionResult = $this->db->get('interactions');
		foreach($arrInteractionResult->result_array() as $interaction){
			$arrInteractionIds[$interaction['id']]	= $interaction['id'];
		}
		return $arrInteractionIds;
	}
	
	/** Date function to convert the date from php format to mysql.
	 *
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 02-03-11
	 *
	 * @param date $inputDate Input date (format - MM/DD/YYYY)
	 * @return date  Output date (format - YYYY-MM-DD).
	 */
	function convertDateToYYYY_MM_DD($inputDate){

		$mmDate	=	substr($inputDate,0,2);
		$ddDate	=	substr($inputDate,3,2);
		$yyDate	=	substr($inputDate,6,4);
		return	($yyDate.'-'.$mmDate.'-'.$ddDate);
	}	
	
	/**
	 * Date function to convert from mysql format to php.
	 *
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 02-03-11
	 *
	 * @param date $inputDate Input date (format - YYYY-MM-DD)
	 * @param string $delimeter Delimeter you want afetr converted
	 * @return date  Output date (format - MM/DD/YYYY).
	 */
	function convertDateToMM_DD_YYYY($inputDate, $delimiter='/'){

		$ddDate	=	substr($inputDate,8,2);
		$mmDate	=	substr($inputDate,5,2);
		$yyDate	=	substr($inputDate,0,4);
		return	($mmDate.$delimiter.$ddDate.$delimiter.$yyDate);
	}
	
	
	/**
	 * To get the Sum of Payments made for one KOL with associated client
	 * 
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 03-03-11
	 * 
	 * @param unknown_type $kol_id
	 * @return unknown_type
	 */
	function  getSumOfPaymentByKolId($kol_id,$client_id){
		$payment = array();
		
		$this->db->select('sum(payment) as payment');
		$this->db->where('kol_id',$kol_id);
		$this->db->where('client_id',$client_id);
		$paymentResult=$this->db->get('payments');
		
		if($paymentResult->num_rows() == 0){
			return false;
		}
		foreach($paymentResult->result_array() as $result){
			$payment	= $result['payment'];
		}
		return $payment;
	}
	
	/**
	 * To get the Sum of Payments made for one KOL Except updating Payment data
	 * 
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 03-03-11
	 * 
	 * @param unknown_type $kol_id
	 * @return unknown_type
	 */
	function  getUpdateSumOfPaymentByKolId($kol_id,$paymentId){
		$payment = array();
		
		$this->db->select('sum(payment) as payment');
		$this->db->where('kol_id',$kol_id);
		$this->db->where_not_in('payments.id',$paymentId);
		$paymentResult=$this->db->get('payments');
		
		if($paymentResult->num_rows() == 0){
			return false;
		}
		foreach($paymentResult->result_array() as $result){
			$payment	= $result['payment'];
		}
		return $payment;
	}
	
	/**
	 * Returns all Kols Name and Id's from 'kols' Table
	 * 
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 04-03-11
	 * 
	 * @return unknown_type
	 */
	function getAllKolsName($restrictByRegion=0){
	    $userGroupName = getGroupDetails();
		$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$arrKol	= array();
		$this->db->select('kols.id as kol_id,kols.salutation,kols.first_name,kols.middle_name,kols.last_name');
		$this->db->order_by('first_name');
		if($restrictByRegion){
		    $group_names = explode(',',  $userGroupName['group_names']);
// 		    $group_names = explode(',', $this->session->userdata('group_names'));
		    $this->db->join ( 'countries', 'countries.CountryId=kols.country_id', 'left' );
		    $this->db->where_in( 'countries.GlobalRegion', $group_names);
		}
		$arrKolResult = $this->db->get('kols');
		foreach($arrKolResult->result_array() as $kol){
		if( $kol['salutation']!=0){
			$kol['name']= $kol['first_name'].' '.$kol['middle_name'].' '.$kol['last_name'];
		}else{
			$kol['name']= $kol['first_name'].' '.$kol['middle_name'].' '.$kol['last_name'];
		}
			$arrKol[$kol['kol_id']]	= $kol['name'];
		}
		return $arrKol;
	}
	
  	/**
	 * Saves the Threshhold Detail to DB 
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 04-03-11
	 * 
	 * @return Last Insert Id/false
	 */
	function saveThreshhold($threshholdDetails){
		if($this->db->insert('payment_threshholds',$threshholdDetails)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
   	/**
	 * Updates the Threshhold Details Data 
	 * 
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 04-03-11
	 * 
	 * @return true/false
	 */
	function updateThreshhold($threshholdDetails){
		$result=array();
		$this->db->where('id',$threshholdDetails['id']);
		if($this->db->update('payment_threshholds',$threshholdDetails)){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * Get the Threshhold Rate of one Kol
	 * 
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 03-03-11
	 * 
	 * @param $kol_id
	 * @return unknown_type
	 */
	function  getThreshholdValueByKolId($kol_id){
		$threshhold_rate = array();
		
		$this->db->select('id,payment_threshholds.threshhold_rate');
		$this->db->where('kol_id',$kol_id);
		$this->db->limit('1');	
		$threshholdResult=$this->db->get('payment_threshholds');
		
		if($threshholdResult->num_rows() == 0){
			return false;
		}
		foreach($threshholdResult->result_array() as $result){
			$threshhold_rate	= $result;
		}
		return $threshhold_rate;
	}
	
	/**
	 * Returns the Payment min and max year 
	 * 
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 08-03-11
	 * 
	 * @param unknown_type $kol_id
	 * @param unknown_type $client_Id
	 * @return $arrYears
	 */
	function getPaymentMinMaxYear($kol_id,$client_Id){
		$arrYears=array();
		$this->db->select('MIN(YEAR(date)) AS min_year,MAX(YEAR(date)) AS max_year');
		$this->db->where_not_in('YEAR(date)','0');
		$this->db->where('client_id',$client_Id);
		
		if($kol_id != '-1'){
			$this->db->where('kol_id',$kol_id);
		}
		$arrYearsResult=$this->db->get('payments');
		
		foreach($arrYearsResult->result_array() as $row){
			$arrYears['min_year']=$row['min_year'];
			$arrYears['max_year']=$row['max_year'];
		}
		return $arrYears;
	}
	
	/**
	 * Retrives the all the Payments which matches the given parameters, for each parameter it does AND operation, 
	 * if the parameter is an 'Array' it does or with in that 
	 * @author 	Ramesh B
	 * @Created on: 09-03-11
	 * @since	1.5.1
	 * @return Array
	 */
	function getPaymentsByParam($fromYear,$toYear,$clientId,$arrKolIds=0,$arrCountries=0,$arrSpecialties=0,$groupBy=0){
		$arrPayments=array();
		$isKolsJoined=false;
		
		//Adding condition for client id
		if($clientId!=0)
			$this->db->where('payments.client_id',$clientId);
		
		//Adding where condition for KOL Id's if Exist
		if(is_array($arrKolIds)){
			$this->db->where_in('payments.kol_id',$arrKolIds);
		}else if($arrKolIds!=0){
			$this->db->where('payments.kol_id',$arrKolIds);
		}
		
		//Adding where condition for Country's if Exist
		if(is_array($arrCountries)){
			$this->db->join('kols','kols.id=payments.kol_id','left');
			$isKolsJoined=true;
			$this->db->where_in('kols.country_id',$arrCountries);
		}else if($arrCountries!=0){
			$this->db->join('kols','kols.id=payments.kol_id','left');
			$isKolsJoined=true;
			$this->db->where('kols.country_id',$arrCountries);
		}
		
		//Adding where condition for Speciality's if Exist
		if(is_array($arrSpecialties)){
			if(!$isKolsJoined)
				$this->db->join('kols','kols.id=payments.kol_id','left');
			$isKolsJoined=true;
			$this->db->where_in('kols.specialty',$arrSpecialties);
		}else if($arrSpecialties!=0){
			if(!$isKolsJoined)
				$this->db->join('kols','kols.id=payments.kol_id','left');
			$isKolsJoined=true;
			$this->db->where('kols.specialty',$arrSpecialties);
		}
		
		$wherBetween="(YEAR(payments.date) BETWEEN '$fromYear' AND '$toYear' OR YEAR(payments.date)='0')";
		$this->db->where($wherBetween);
		
		
		//Adding Group by based param $groupBy
		if((string)$groupBy=="year"){
			$this->db->select('YEAR(payments.date) AS year, COUNT(YEAR(payments.date)) AS count');
			$this->db->group_by('YEAR(payments.date)');
			//echo $groupBy;
		}else if((string)$groupBy=='kolId'){
			if(!$isKolsJoined)
				$this->db->join('kols','kols.id=payments.kol_id','left');
			$isKolsJoined=true;
			$this->db->select('kols.salutation,kols.last_name,kols.middle_name,kols.first_name, COUNT(payments.id) AS count');
			$this->db->group_by('payments.kol_id');
			$this->db->order_by('count DESC');
			//echo $groupBy;
		}else {
			$this->db->select('payments.*');
			//echo 'No Grouping';
		}
		
		$arrPaymentsResults=$this->db->get('payments');
		foreach($arrPaymentsResults->result_array() as $row){
			$arrPayments[]=$row;
		}
		//echo $this->db->last_query();;
		return $arrPayments;
	}
	
  	/**
	 * Delete the Payment Details By Kol Id
	 * 
	 * @author Ambarish
	 * @since 1.4.5
	 * @Created-on 01-03-11
 	 * @return Boolean
	 */	
  	function deletePaymentsByKolId($clientId,$kolId){
		if($clientId!=0)
			$this->db->where('client_id',$clientId);
		$this->db->where('kol_id',$kolId);
		if($query=$this->db->delete('payments')){
			return true;
		}else{
			return false;
		}
	}
	
	  /**
	 * Returns the all the payments id who are referring given interaction
	 * @author Ramesh B
	 * @since 3.0
	 * @Created-on 26-08-11
 	 * @return Array
	 */	
	function getAllPaymentsReferringInteraction($interactionId){
		$arrPaymentIds=array();
		$this->db->select('id');
		$this->db->where('interaction_id',$interactionId);
		$arrPaymentsResults=$this->db->get('payments');
		foreach($arrPaymentsResults->result_array() as $row){
			$arrPaymentIds[]=$row['id'];
		}
		return $arrPaymentIds;
	}
	
	/**
	 * Returns the years range of the user .
	 * @author 	Ramesh B
	 * @since	3.1
	 * @param  $clientId
	 * @param  $userId
	 * @return Array
	 * @Created on: 26-09-11
	 */
	function getPaymentsYearsRange($clientId,$userId,$kolId=null){
		$arrYears=array();
		$arrYears['min_year']='';
		$arrYears['max_year']='';
		$this->db->select("MIN(year(date)) AS min_year, max(year(date)) AS max_year");
		$this->db->where("year(date)!=",0);
		$this->db->where("client_id",$clientId);
		if($userId!=0)
			$this->db->where("created_by",$userId);
		if($kolId!=null)
			$this->db->where('kol_id',$kolId);
		$arrResults=$this->db->get("payments");

		foreach($arrResults->result_array() as $row){
			$arrYears['min_year']=$row['min_year'];
			$arrYears['max_year']=$row['max_year'];
		}
		//echo $this->db->last_query();
		return $arrYears;
	}
	
	/**
	 * 
	 * @author 	Ramesh B
	 * @since	4.7
	 * @param  $clientId
	 * @param  $userId
	 * @return Array
	 * @Created on: 26-09-11
	 */
	function saveTypeAndAmount($payementId,$arrTypesAndAmounts){
		$seperator='';
		$bulkInsert='';
		foreach($arrTypesAndAmounts as $row){
			$bulkInsert.=$seperator;
			//$bulkInsert.="($payementId,$row['type'],'".$row['amount']."')";
			$bulkInsert.="($payementId,".$row['type'].",".$row['currency'].",'".$row['amount']."')";
			$seperator=',';
		}
		
		$this->db->query("insert into payment_split(`payment_id`,`type`,`currency`,`amount`) values $bulkInsert");
	}
	
	function getAllKolsName1($restrictByRegion=0){
	    $userGroupName = getGroupDetails();
		$arrkols=array();
		$this->db->select('kols.id,kols.first_name,kols.middle_name,kols.last_name');
		//$status = COMPLETED;
		//$this->db->where('status',"$status");
		if($restrictByRegion){
		    $group_names = explode(',',  $userGroupName['group_names']);
// 		    $group_names = explode(',', $this->session->userdata('group_names'));
		    $this->db->join ( 'countries', 'countries.CountryId=kols.country_id', 'left' );
		    $this->db->where_in( 'countries.GlobalRegion', $group_names);
		}
		$arrResult = $this->db->get('kols');
// 		pr($this->db->last_query());exit;
		foreach($arrResult->result_array() as $row){
			if($row['middle_name']!=''){
//			$arrkols[$row['id']] = $row[FIRST_ORDER]." ".$row[SECOND_ORDER]." ".$row[THIRD_ORDER];
			$arrkols[$row['id']] = nf($row['first_name'],$row['middle_name'],$row['last_name']);
			}else{
//				$arrkols[$row['id']] = $row[FIRST_ORDER]." ".$row[SECOND_ORDER];
				$arrkols[$row['id']] = nf($row['first_name'],$row['middle_name'],$row['last_name']);
			}
		}
		return $arrkols;
	}
	
	function getPayementTypeAndAmount($paymentId){
		$arrPaymentTypesAndAmounts =array();
		$this->db->select('payment_split.type,payment_split.currency, payment_split.amount as indAmount');
		$this->db->where('payment_split.payment_id',$paymentId);
		$arrResult = $this->db->get('payment_split');
		foreach($arrResult->result_array() as $row){
			$arrPaymentTypesAndAmounts[]=$row;
		}
		return $arrPaymentTypesAndAmounts;
	}

	function updateTypeAndAmount($payementId,$arrTypes){
		$this->db->where('payment_id',$payementId);
		$this->db->delete('payment_split');
		
		$seperator='';
		$bulkInsert='';
		foreach($arrTypes as $row){
			$bulkInsert.=$seperator;
			//$bulkInsert.="($payementId,$row['type'],'".$row['amount']."')";
			$bulkInsert.="($payementId,".$row['type'].",".$row['currency'].",'".$row['amount']."')";
			$seperator=',';
		}
		
		$this->db->query("insert into payment_split(`payment_id`,`type`,`currency`,`amount`) values $bulkInsert");
		}
	
		
	function getAllPaymentsPaidBy(){
		$arrData = array();
		$resultSet = $this->db->get('payments_paid_by');
		foreach($resultSet->result_array() as $row){
			$arrData[$row['id']] = $row['paid_by'];			
		}
		return $arrData;
	}
	
	function getAllPaymentsRequestedBy(){
		$arrData = array();
		$resultSet = $this->db->get('payments_requested_by');
		foreach($resultSet->result_array() as $row){
			$arrData[$row['id']] = $row['requested_by'];			
		}
		return $arrData;
	}
	
	/**
	 * Saves the given payment split  details
	 * 
	 * @author Ramesh B
	 * @since 4.7
	 * @param $eventPayment
	 * @created 26-07-12 
	 */
	function savePaymentSplit($paymentSplit){
		if($this->db->insert('payment_split',$paymentSplit)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	function updatePaymentSplitClientEvent($paymentSplit){
		$this->db->where('payment_id',$paymentSplit['payment_id']);
		if($this->db->update('payment_split',$paymentSplit)){
			return true;
		}else{
			return false;
		}
	}
	
	function getPaymentRequestedBy($requestedId){
		$reqBy	= '';
		$this->db->where('id',$requestedId);
		$arrResult = $this->db->get('payments_requested_by');
		foreach($arrResult->result_array() as $row){
			$reqBy = $row['requested_by'];
		}
		return $reqBy;
	}
	
	function getPaymentPaidBy($paidId){
		$paidBy	= '';
		$this->db->where('id',$paidId);
		$arrResult = $this->db->get('payments_paid_by');
		foreach($arrResult->result_array() as $row){
			$paidBy = $row['paid_by'];
		}
		return $paidBy;
	}
	
	function savenNotProfiledKols($kolDetails){
		if($this->db->insert('kols',$kolDetails)){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	
	function exportPaymentDetails($clientId,$kolId,$userId,$startDate=0,$endDate=0,$paymentIds){
		$arrPaymentDetail	=	array();
		$arrSalutations	= array(1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$this->db->select(array('payments.*','kols.salutation','kols.first_name','kols.middle_name','kols.last_name','kols.status','payments.requested_by','payments.paid_by','CONCAT(COALESCE(client_users.first_name,"")," ",COALESCE(client_users.last_name,"")) as created_by_full_name'));
		$this->db->join('kols', 'kols.id = payments.kol_id', 'left');
		$this->db->join('client_users', 'client_users.id = payments.created_by', 'left');
		//Setting kol_id = -1 when track is clicked
		if($kolId!=null && $kolId!=-1){
			$this->db->where('payments.kol_id',$kolId);
		}
		
		$this->db->where_in('payments.id',$paymentIds);
		
		$this->db->order_by('kols.first_name');
		$this->db->order_by('payments.date','desc');
		$arrPaymentDetailResult	=	$this->db->get('payments');
		foreach ($arrPaymentDetailResult->result_array() as $paymentDetail){
			$arrPaymentDetail[] = $paymentDetail;
		}
     	
		return $arrPaymentDetail;
	}
	
	function getTotalPaymentsOfKol($kolId){
	    $client_id = $this->session->userdata('client_id');
	    $user_id = $this->session->userdata('user_id');
	    $this->db->select("id");
	    $this->db->from("payments");
	    $this->db->where("kol_id",$kolId);
	    $this->db->where("client_id",$client_id);
	    if($client_id!=INTERNAL_CLIENT_ID){
// 		  $this->db->where("created_by",$user_id);
		  $this->db->where("client_id",$client_id);
	    }
	    $get = $this->db->get();
	    return $get->num_rows();
	}
	
	function getAssignedUsersForType($id){
	    $client_id = $this->session->userdata('client_id');
	    $this->db->select("user_kols.user_id, client_users.email");
	    $this->db->select("CONCAT(kols.last_name, '\, ', kols.first_name,' ', kols.middle_name) AS typename", FALSE);
	    $this->db->join('client_users', 'client_users.id = user_kols.user_id', 'left');
	    $this->db->join('kols', 'kols.id = user_kols.kol_id', 'left');
	    $this->db->where('user_kols.kol_id', $id);
	    if($client_id !== INTERNAL_CLIENT_ID){
	        $this->db->where('client_users.client_id', $client_id);
	    }
	    $query = $this->db->get('user_kols');
	    $result = $query->result();
	    foreach($result as $row){
	        $typeName = $row->typename;
	        $userEmails[] =  $row->email;
	    }
	    $arrUsersDetails['type_name'] = $typeName;
	    $arrUsersDetails['user_details'] = $userEmails;
	    return $arrUsersDetails;
	}
}