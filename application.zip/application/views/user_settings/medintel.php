<?php




?>

<style type="text/css">
	.nameFormats .egStyle{
		font-style: italic;
    	margin-left: 40px;
	}
	.nameFormats .description{
		font-size: 14px;
    	margin-left: -20px;
	}
	.nameFormats .nameLabel{
		margin-left: 10px;
	}
        .ipadClass{
            width: 75px !important;
   
    width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
    border: 1px solid #ccc;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
        }
</style>
<script type="text/javascript">
	function medintel(thisEle){
           
                
               
                $.ajax({
									url:"<?php echo base_url()?>user_settings/save_medintel_settings/"+$("input[name='email']:checked").val(),
									type:"post",
									
									dataType:"TEXT",
									success: function (){
										$("#msg").show();
                            $("#msg").html("<center>Preference saved successfully.</center>");
                            
                          setTimeout(function(){ $("#msg").hide();$('#eventContainer').dialog('close');
                $('#myModal').modal('hide'); }, 3000);
										}
                        });
                }
                
                function cancel(){
                
                $('#eventContainer').dialog('close');
                $('#myModal').modal('hide');
                }
               
</script>
<div class="topHeader">
   
	<div class="headerTitle">
		<div class="titleOfPage"><h3>Media Email Alerts</h3></div>
                 <span id="msg" style="color:green"></span>
	</div>
</div>
<div id="medintel" style="width: 100%; margin: auto;">

    
    <table class="nameFormats" style="width: 85%; margin: 20px auto auto;">
		<tr>
			<td ><div class="description">Would you like to receive a daily email alert whenever there is news on the topics that you are following?</div></td>
		</tr>
		<tr>
			<td><input <?php if(isset($option) && $option == 'yes')echo "checked='checked'";?> type="radio" value="yes" name="email" id="yes"   ><label style="color: #000000;font-weight: 500;" for="opt3" class="nameLabel">Yes</label></input></td>
		</tr>
		
		<tr>
			<td><input <?php if(isset($option) && $option == 'no')echo "checked='checked'";?> type="radio" value="no" name="email" id="no"   ><label style="color: #000000;font-weight: 500;" for="opt1" class="nameLabel">No</label></input></td>
		</tr>
                
              
	</table>
      <center><button class="<?php if(IS_IPAD_REQUEST) echo 'ipadClass' ?>" style="width:75px" onclick="medintel(1)">Save</button>&nbsp;<?php if(isset($media)) { ?><button style="width:75px" class="<?php if(IS_IPAD_REQUEST) echo 'ipadClass' ?>" onclick="cancel()">Cancel</button> <?php } ?></center><br/>
    
 
   
</div>