<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class specialities extends MX_Controller{
	function __construct()
	{
		parent::__construct();
		$this->load->model('speciality');
	}
}
?>