<?php
$queued_js_scripts = array('jquery/jquery-ui-1.8.16.datepicket',
    'chosen.jquery','signature_pad'
);
// add the JS files into queue i.e Append to the existing queue
$this->config->set_item('js_files_to_load,', array_merge($this->config->item('js_files_to_load'), $queued_js_scripts));

$currentController = $this->uri->segment(1);
$currentMethod = $this->uri->segment(2);
?>
<?php 
$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {reloadSection();}";
$GLOBALS['count']=0;
$GLOBALS['countOrg']=0;
?>
<style type="text/css">
    /*    Enable Verticle separator between content and side menu list  By Laxman   */
    #contentWrapper.span-23 {
        background-image: url("<?php echo base_url(); ?>images/verticlesep_terNav.jpg");
        background-position: 135px 50%;
        background-repeat: repeat-y;
    }
    /*	#medContainer{
                    width: 800px;
                    margin-top: -75px;
                    margin-top: 0px;
                    float: right;
            }*/
    select.chosenSelect{
        width:200px;
    }
    td .chzn-container-multi .chzn-choices{
        height: 60px !important;
    }
    .alignRight{
        padding-right:0px;
    }
    .alignCenter{
        text-align: center;
    }
    table caption{
        background:url("<?php echo base_url(); ?>images/kolm-sprite-image.png") repeat-x scroll -2px -236px transparent;
    }
    /*	table {
            border: 1px solid #DDDDDD;
        }*/
    table th{
        vertical-align: top;
    }
    tr.tableSubHeader th{
        background-color:#eee;
    }
    .oddRow {
        background-color: #F5F5F5;
    }
    div.deleteIcon{
        float: none;
    }
    .type, .product, .topic{
        width:100%;
    }
    #organization, #organization_chzn {
        <?php if ($currentMethod == "edit_compliance") { ?>
            display: block;
        <?php } else { ?>
            display: none;
        <?php } ?>
    }
    #objectiveTable select{
    	width: 200px;
    }
    #medContainer .add-icon{
    	background-image: url("<?php echo base_url();?>images/bullet_add.png");
    	display: inline-block;
	    height: 23px;
	    width: 25px;
	    cursor: pointer;
    }
    #medContainer .remove-icon{
    	background-image: url("<?php echo base_url();?>images/delete.png");
    	display: inline-block;
	    height: 31px;
	    width: 25px;
	    cursor: pointer;
	    background-repeat: no-repeat;
	    background-position: 1px 16px;
    }
    
    .m-signature-pad {
  position: absolute;
  font-size: 10px;
  width: 600px;
  height: 200px;
  top: 50%;
  left: 50%;
  margin-left: -350px;
  margin-top: -200px;
  border: 1px solid #e8e8e8;
  background-color: #fff;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.27), 0 0 40px rgba(0, 0, 0, 0.08) inset;
  border-radius: 4px;
}

.m-signature-pad:before, .m-signature-pad:after {
	position: absolute;
  z-index: -1;
  content: "";
	width: 40%;
	height: 10px;
	left: 20px;
	bottom: 10px;
	background: transparent;
	-webkit-transform: skew(-3deg) rotate(-3deg);
	-moz-transform: skew(-3deg) rotate(-3deg);
	-ms-transform: skew(-3deg) rotate(-3deg);
	-o-transform: skew(-3deg) rotate(-3deg);
	transform: skew(-3deg) rotate(-3deg);
	box-shadow: 0 8px 12px rgba(0, 0, 0, 0.4);
}

.m-signature-pad:after {
	left: auto;
	right: 20px;
	-webkit-transform: skew(3deg) rotate(3deg);
	-moz-transform: skew(3deg) rotate(3deg);
	-ms-transform: skew(3deg) rotate(3deg);
	-o-transform: skew(3deg) rotate(3deg);
	transform: skew(3deg) rotate(3deg);
}

.m-signature-pad--body {
  position: absolute;
  left: 20px;
  right: 20px;
  top: 20px;
  bottom: 60px;
  border: 1px solid #f4f4f4;
}

.m-signature-pad--body
  canvas {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    border-radius: 4px;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.02) inset;
  }

.m-signature-pad--footer {
  position: absolute;
  left: 20px;
  right: 20px;
  bottom: 20px;
  height: 40px;
}

.m-signature-pad--footer
  .description {
    color: #C3C3C3;
    text-align: center;
    font-size: 1.2em;
    margin-top: 1.8em;
  }

.m-signature-pad--footer
  .button {
    position: absolute;
    bottom: 0;
  }

.m-signature-pad--footer
  .button.clear {
    left: 0;
  }

.m-signature-pad--footer
  .button.save {
    right: 0;
  }

@media screen and (max-width: 1024px) {
  .m-signature-pad {
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    width: auto;
    height: auto;
    min-width: 250px;
    min-height: 140px;
    margin: 5%;
  }
  #github {
    display: none;
  }
}

@media screen and (min-device-width: 768px) and (max-device-width: 1024px) {
  .m-signature-pad {
    margin: 10%;
  }
}

@media screen and (max-height: 320px) {
  .m-signature-pad--body {
    left: 0;
    right: 0;
    top: 0;
    bottom: 32px;
  }
  .m-signature-pad--footer {
    left: 20px;
    right: 20px;
    bottom: 4px;
    height: 28px;
  }
  .m-signature-pad--footer
    .description {
      font-size: 1em;
      margin-top: 1em;
    }
}

</style>
<link href="<?php echo base_url(); ?>css/chosen.css" media="screen" rel="stylesheet">

<div id="medContainer">
    <h5>Compliance Monitoring Form<?php //pr($arrClientUsers);                                          ?></h5>
    <form id="complianceForm" action="<?php echo base_url(); ?>coachings/save_compliance" method="post">
        <?php
        if ($currentMethod == "edit_compliance") {
            ?>
            <input type="hidden" name="compliance_id" value="<?php echo $arrComplianceData["id"]; ?>">
        <?php } ?>
        <table>
            <tr class="evenRow">
                <th>01)</th><th style="width:315px;">Date of Visit</th>
                <td colspan="2"><input type="text" name="date" value="<?php
                    if ($currentMethod == "edit_compliance")
                        echo $arrComplianceData['date'];
                    else
                        echo date('m/d/Y');
                    ?>" id="date" /></td>
            </tr>
            <tr class="oddRow">
                <th>02)</th><th>Location(s) of interactions observed during visit</th>
                <td colspan="2">
                    <select style="width:95%;" multiple="multiple" name="location[]" class="chosenMultipleSelect">
                        <option value=""></option>
                        <?php
                        if ($currentMethod == "edit_compliance") {
                            $arrSelectedLocations = explode(",", $arrComplianceData["location"]);
                            foreach ($arrLocations as $key => $value) {
                                if (in_array($key, $arrSelectedLocations)) {
                                    echo '<option value="' . $key . '" selected>' . $value . '</option>';
                                } else {
                                    echo '<option value="' . $key . '">' . $value . '</option>';
                                }
                            }
                        } else {
                            foreach ($arrLocations as $key => $value) {
                                echo '<option value="' . $key . '">' . $value . '</option>';
                            }
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr class="evenRow">
                <th>03)</th><th>Username</th>
                <td colspan="2"><?php
                    if ($currentMethod == "edit_compliance") {
                        echo $arrComplianceData["ufname"] . " " . $arrComplianceData["ulname"];
                    } else {
                        echo $this->session->userdata('user_full_name');
                    }
                    ?>
                </td>
            </tr>
            <tr class="oddRow">
                <th>04)</th><th>Name of Monitor</th>
                <td colspan="2"><select name="monitored_by" class="chosenSelect">
                        <option>Select User</option>
                        <?php
                        if ($currentMethod == "edit_compliance") {
                            foreach ($arrClientUsers as $key => $row) {
                                if ($arrComplianceData['monitored_by'] != $row['id']) {
                                    echo '<option value="' . $row['id'] . '">' . $row['first_name'] . ' ' . $row['last_name'] . '</option>';
                                } else {
                                    echo '<option value="' . $row['id'] . '" selected>' . $row['first_name'] . ' ' . $row['last_name'] . '</option>';
                                }
                            }
                        } else {
                            foreach ($arrClientUsers as $key => $row) {
                                echo '<option value="' . $row['id'] . '">' . $row['first_name'] . ' ' . $row['last_name'] . '</option>';
                            }
                        }
                        ?>
                    </select></td>
            </tr>
            <tr class="evenRow">
                    <!--<th>05)</th><th>KOL(s) in Attendance</th>-->
                <th>05)</th>
                <th>HCP's</th>
               <?php if ($currentMethod != "edit_compliance") {
                         
                            ?>
                <td id="kolSearch"><input id='kolName'  class='autocompleteInputBox' autocomplete='off' type='text' placeholder='Search Kol' /><a class="add-icon" onclick="addMoreKols()"></a><span id="moreKol"></span></td>
               <?php } ?>

<!--                <th>HCP(s) in Attendance</th>-->
                
               
                      <?php if ($currentMethod == "edit_compliance") {
                         
                            ?>
                <td id="kolSearch">
                    <?php $flag=0; foreach($arrComplianceKOLs as $kolIds){
                                                     if($flag==0)
                                                               {
                                                               $flag=1;
                                                                echo "<input id='kolName'  class='autocompleteInputBox' autocomplete='off' value='".$kolIds['first_name'].' '.$kolIds['middle_name'].' '.$kolIds['last_name']."' type='text' placeholder='Search Kol' /><a class='add-icon' onclick=\"addMoreKols()\"></a><span id=\"moreKol\"></span>";
                                                                echo "<input type='text' hidden class='kolName'  name=kol[] value='".$kolIds['id']."'>"; 
                                                                
                                                               }
                                                               else{
                                                $count=$count+1;
                                                                     echo "<br class='kolName".$count."br'/><input id='kolName".$count."' value='".$kolIds['first_name'].' '.$kolIds['middle_name'].' '.$kolIds['last_name']."' class='autocompleteInputBox kolName".$count."' autocomplete='off' type='text' placeholder='Search Kol' /><a class='remove-icon' onclick=\"removeMoreKols('kolName".$count."',this)\"></a>";
                                                                        echo "<input type='text' hidden class='kolName".$count."'  name=kol[] value='".$kolIds['id']."'>";
                                                               }
                     }}?>
                    
            </tr>
                 <tr class="evenRow">
                    <!--<th>05)</th><th>KOL(s) in Attendance</th>-->
                <th></th>
                <th>HCO's</th>
                  <?php if ($currentMethod != "edit_compliance") {
                         
                            ?>
                <td id="orgSearch"><input id='orgName'  class='autocompleteInputBox' autocomplete='off' type='text' placeholder='Search Organization' /><a class='add-icon' onclick="addMoreOrgs()"></a><span id="moreOrg"></span></td>
  <?php } ?>
<!--                <th>HCP(s) in Attendance</th>-->
               <?php if ($currentMethod == "edit_compliance") {
                         
                            ?>
               
     <td id="orgSearch">
                    <?php $orgFlag=0; foreach($arrComplianceOrgs as $orgIds){
                                                     if($orgFlag==0)
                                                               {
                                                               $orgFlag=1;
                                                                echo "<input id='orgName'  class='autocompleteInputBox' autocomplete='off' value='".$orgIds['name']."' type='text' placeholder='Search Org' /><a class='add-icon' onclick=\"addMoreOrgs()\"></a><span id=\"moreOrg\"></span>";
                                                                echo "<input type='text' hidden class='orgName'  name=org[] value='".$orgIds['id']."'>"; 
                                                                
                                                               }
                                                               else{
                                                $countOrg=$countOrg+1;
                                                                     echo "<br class='orgName".$countOrg."br'/><input id='orgName".$countOrg."' value='".$orgIds['name']."' class='autocompleteInputBox orgName".$countOrg."' autocomplete='off' type='text' placeholder='Search Organaization' /><a class='remove-icon' onclick=\"removeMoreOrgs('orgName".$countOrg."',this)\"></a>";
                                                                    echo "<input type='text' hidden class='kolName".$orgIds."'  name=kol[] value='".$orgIds['id']."'>";
                                                               }
                     }}?>
                    
            </tr>
            <tr class="oddRow">
<!--				<th>06)</th><th>Interaction Grouping</th>-->
                <th>06)</th><th>Interaction Category</th>
                <td colspan="2"><select name="interaction_type" class="chosenSelect" id="groupId">
                        <?php if ($currentMethod == "edit_compliance") {
                            ?>
                            <option value="1" <?php if ($arrComplianceData["interaction_type"] == "1") echo "selected"; ?>>One-on-One</option>
                            <option value="2" <?php if ($arrComplianceData["interaction_type"] == "2") echo "selected"; ?>>Group</option>
                            <?php
                        } else {
                            ?>
                            <option value="1" selected>One-on-One</option>
                            <option value="2" >Group</option>
                        <?php } ?>
                    </select></td>
            </tr>
         
            <tr class="evenRow">
                <th></th>
                <td colspan="3">
                   
                        <?php
//                        if ($currentMethod == "edit_compliance") {
//                            for ($i = 0; $i < count($arrComplianceTopics["topic_names"]); $i++) {
                        ?>
<!--                                <tr>
                                    <td><select name="visit_type" class="type" onchange="getProducts(this, 0)">
                                            <option>Select  Type</option>-->
                        <?php
//                                            $product = $arrComplianceTopics["types"][$i];
//                                            foreach ($arrTypes as $key => $row) {
//                                                echo '<option value="' . $row['id'] . '"';
//                                                if ($product == $row['name'])
//                                                    echo "selected";
//                                                echo '>' . $row['name'] . '</option>';
//                                            }
                        ?>
                        <!--                                        </select>
                                                            </td>
                                                            <td><select name="product" class="product" onchange="getTopics(this, 0)">
                                                                    <option>Select Product</option>
                                                                </select>
                                                            </td>
                                                            <td><select name="topics[]" class="topic">
                                                                    <option>Select Topic</option>
                                                                </select>
                                                            </td>
                                                            <td><div onclick="deleteRow(this, 0);" class="actionIcon deleteIcon" alt="Delete" title="Delete"></div></td>
                                                        </tr>-->
                        <?php
//                            }
//                        }
                        ?>
                        <!--                        <tr>
                        <td>Proactive Promotional</td>
                        <td>Abilify</td>
                        <td><input type="hidden" name="topics[]" class="1_1_2" value="1_1_2">Label/Safety Warning Update</td>
                        <td><div onclick="deleteRow(this, 0);" class="actionIcon deleteIcon" alt="Delete" title="Delete"></div></td>
                        </tr>-->
                      <table id="objectiveTable" class="highlightHeadings tabularGrid">
						<caption>Purpose of Visit
							<div id="collapseExpandButton" class="expandSlider collapseSlider">
								<a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
							</div>
						</caption>
						<tr>
							<th class="alignCenter"><label for="product">Product<span class="required">*</span></label></th>
							<th class="alignCenter"><label for="objective">Interaction Type<span class="required">*</span></label></th>
							<th class="alignCenter"><label for=topic>Topic<span class="required">*</span></label></th>
							<th class="alignCenter"></th>
							<th></th>
							<th>&nbsp;</th>
						</tr>
						<?php if(!isset($arrComplianceData)){	?>
						<input type="hidden" id="noOfObjectives" value="0" name="noOfObjectives"></input>
							<tr id="objective">
								<td class="alignCenter">
									<p>
										<select name="product"  id="product" class="required" onchange="resetDropDowns(this)">
											<option value="">Select</option>
											<?php foreach($arrProduct as $row){?>
												<option value="<?php echo $row['id'];?>">
													<?php echo $row['name'];?>
												</option>
											<?php }?>
										</select>
										<img id="loadingProduct" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
									</p>
								</td>
								<td class="alignCenter">
									<p>
										<select name="objective"  id="objective"  onchange="getTopic(this)" class="required">
											<option value="">Select</option>	
											<?php foreach($arrType as $row){?>
												<option value="<?php echo $row['id'];?>">
													<?php echo $row['name'];?>
												</option>
											<?php }?>
										</select>
									</p>
								</td>
								<td class="alignCenter">
									<p>
										<select name="topic"  id="topic" class="required">
											<option value="">Select</option>	
										</select>
										<img id="loadingTopic" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
									</p>
								</td>
								<td class="alignCenter">
									<p>
										
									</p>
								</td>
								<td>
									<p></p>
								</td>
								<td class="TextAlignCenter">
									<label id="addMoreObjectives"><img src="<?php echo base_url();?>images/bullet_add.png" alt="Add" title="Add"/></label>
								</td>
							</tr>
						<?php }else{?>
							<input type="hidden" id="noOfObjectives" value="<?php echo $arrComplianceData['noOfObjectives']?>" name="noOfObjectives"></input>
							<?php  $objectiveNo='';
							foreach($arrDiscussion as $topicKey=>$arrDiscussionData){?>
							<tr id="objective">
								<td>
									<p>
										<select name="product<?php echo $objectiveNo?>"  id="product<?php echo $objectiveNo?>" onchange="resetDropDowns(this)" class="required">
												<option value="">Select</option>	
											<?php foreach($arrDiscussionData['arrProducts'] as $product){?>
												<option value="<?php echo $product['id'];?>" <?php  if($product['id']==$arrDiscussionData['row']['product_id']) echo 'SELECTED';?>>
													<?php echo $product['name'];?>
												</option>
											<?php }?>
										</select>
										<img id="loadingProduct" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
									</p>
								</td>
								<td><p>
										<select name="objective<?php echo $objectiveNo?>"  id="objective<?php echo $objectiveNo?>"  onchange="getTopic(this)" class="required">
												<option value="">Select</option>	
											<?php  foreach($arrDiscussionData['arrTypes'] as $key=>$objective){?>
												<option value="<?php echo $objective['id'];?>" <?php if($objective['id']==$arrDiscussionData['row']['type_id']) echo 'SELECTED';?>>
													<?php echo $objective['name']?>
												</option>
											<?php }?>
										</select>
									</p>
								</td>
								<td>
									<p>
										<select name="topic<?php echo $objectiveNo?>"  id="topic<?php echo $objectiveNo?>" onchange="getSubTopic(this)" class="required">
												<option value="">Select</option>	
											<?php foreach($arrDiscussionData['arrTopics'] as $key=>$value){?>
												<option value="<?php echo $key;?>" <?php  if($key==$arrDiscussionData['row']['topic_id']) echo 'SELECTED';?>>
													<?php echo $value;?>
												</option>
											<?php }?>
										</select>
										<img id="loadingTopic" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
									</p>
								</td>
								<td><p>
										
									</p>
								</td>
								<td>
									<p></p>
								</td>
								<td class="TextAlignCenter">
								<?php if($topicKey==0){?>
											<label id="addMoreObjectives"><img src="<?php echo base_url();?>images/bullet_add.png" alt="Add" title="Add"/></label>
										<?php }else{?>
											<label id="deleteMoreObjectives"><img src="<?php echo base_url();?>images/delete.png" alt="Delete" title="Delete" onclick="deleteRow(this)"></label>
									<?php }?>
								</td>
							</tr>
						<?php $objectiveNo++;}
						}?>
					</table>
                    
                    <table style="margin-top:5px; display: none;">
                        <caption style="font-weight: bold;">Additional Topic(s): (Optional)</caption>
                        <tr class="tableSubHeader">
                            <th style="text-align: center;width:25%;">Type</th><th style="text-align: center;width:25%;">Product</th><th style="text-align: center;width:50%;">Topic</th><th></th>
                        </tr>
                        <tr>
                            <td><select name="additional_visit_type" class="type" onchange="getProducts(this, 1)">
                                    <option>Select  Type</option>
                                    <?php
                                    foreach ($arrTypes as $key => $row) {
                                        echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
                                    }
                                    ?>
                                </select>
                            </td>
                            <td><select name="additional_product" class="product" onchange="getTopics(this, 1)">
                                    <option>Select Product</option>
                                </select>
                            </td>
                            <td><select name="additional_topics[]" class="topic">
                                    <option>Select Topic</option>
                                </select>
                            </td>
                            <td><div class="actionIcon addIcon" onclick="addMore(this, 1)"></div></td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr class="oddRow">
                <th>08)</th><th>Off-Label Inquiry</th>
                <?php
                if ($currentMethod == "edit_compliance") {
                    ?>
                    <td><input type="radio" name="off_label_inquiry" onclick="toggleOffLabelInquiry(1)" value="yes" 
                        <?php
                        if ($arrComplianceData["off_label_inquiry"] == "yes") {
                            echo "checked";
                        }
                        ?>></input><label for="yes">Yes</label></td>
                    <td><input type="radio" name="off_label_inquiry" onclick="toggleOffLabelInquiry(0)" value="no" 
                        <?php
                        if ($arrComplianceData["off_label_inquiry"] == "no") {
                            echo "checked";
                        }
                        ?>></input><label for="no">No</label></td>
                        <?php
                    } else {
                        ?>
                    <td><input type="radio" name="off_label_inquiry" onclick="toggleOffLabelInquiry(1)" value="yes" ></input><label for="yes">Yes</label></td>
                    <td><input type="radio" name="off_label_inquiry" onclick="toggleOffLabelInquiry(0)" value="no" checked="checked"></input><label for="no">No</label></td>
                    <?php
                }
                ?>
            </tr>
            <tr class="oddRow toggleOffLabelInquiry" 
                <?php
                if ($currentMethod == "edit_compliance") {
                    if($arrComplianceData["off_label_inquiry"] != "yes") {
                        echo "style='display:none'";
                    }
                }
                    ?>>
                <th></th><th>a)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; was the inquiry unsolicited?</th>
                <?php
                if ($currentMethod == "edit_compliance") {
                    ?>
                    <td><input type="radio" name="inquiry_unsolicited" value="yes"
                        <?php
                        if ($arrComplianceData["inquiry_unsolicited"] == "yes") {
                            echo "checked";
                        }
                        ?>></input><label for="yes">Yes</label></td>
                    <td><input type="radio" name="inquiry_unsolicited" value="no" 
                        <?php
                        if ($arrComplianceData["inquiry_unsolicited"] == "no") {
                            echo "checked";
                        }
                        ?>></input><label for="no">No</label></td>
                    <?php } else { ?>
                    <td><input type="radio" name="inquiry_unsolicited" value="yes"></input><label for="yes">Yes</label></td>
                    <td><input type="radio" name="inquiry_unsolicited" value="no" checked="checked"></input><label for="no">No</label></td>
                <?php } ?>
            </tr>
            <tr class="oddRow toggleOffLabelInquiry"
                <?php
                if ($currentMethod == "edit_compliance") {
                    if($arrComplianceData["off_label_inquiry"] != "yes") {
                        echo "style='display:none'";
                    }
                }
                    ?>>
                <th></th><th>b)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;was KOL Response consistent with
                    company policy?</th>
                <?php
                if ($currentMethod == "edit_compliance") {
                    ?>
                    <td><input type="radio" name="response_consistancy" value="yes" 
                        <?php
                        if ($arrComplianceData["response_consistancy"] == "yes") {
                            echo "checked";
                        }
                        ?>></input><label for="yes">Yes</label></td>
                    <td><input type="radio" name="response_consistancy" value="no" 
                        <?php
                        if ($arrComplianceData["response_consistancy"] == "no") {
                            echo "checked";
                        }
                        ?>></input><label for="no">No</label></td>
                    <?php } else { ?>
                    <td><input type="radio" name="response_consistancy" value="yes"></input><label for="yes">Yes</label></td>
                    <td><input type="radio" name="response_consistancy" value="no" checked="checked"></input><label for="no">No</label></td>
                <?php } ?>
            </tr>
            <tr class="evenRow">
                <th>09)</th><th>Did you identify any compliance violations?</th>
                <?php
                if ($currentMethod == "edit_compliance") {
                    ?>
                    <td><input type="radio" name="compliance_violation" value="yes" onclick="toggleViolationDescription(1)" 
                        <?php
                        if ($arrComplianceData["compliance_violation"] == "yes") {
                            echo "checked";
                        }
                        ?>></input><label for="yes">Yes</label></td>
                    <td><input type="radio" name="compliance_violation" value="no" onclick="toggleViolationDescription(0)" 
                        <?php
                        if ($arrComplianceData["compliance_violation"] == "no") {
                            echo "checked";
                        }
                        ?>></input><label for="no">No</label></td>
                    <?php } else { ?>
                    <td><input type="radio" name="compliance_violation" value="yes" onclick="toggleViolationDescription(1)"></input><label for="yes">Yes</label></td>
                    <td><input type="radio" name="compliance_violation" value="no" onclick="toggleViolationDescription(0)" checked="checked"></input><label for="no">No</label></td>
                <?php } ?>
            </tr>
            <tr class="oddRow toggleViolationDescription" 
                <?php
                if ($currentMethod == "edit_compliance") {
                    if($arrComplianceData["compliance_violation"] != "yes") {
                        echo "style='display:none'";
                    }
                }
                    ?>>
                <th>10)</th><th colspan="3">If the answer to question 09 is "yes", please explain
                    and ensure the Director or Vice President informs the
                    Chief Compliance Officer within two (2) business days.</th>
            </tr>
            <tr class="oddRow toggleViolationDescription" 
                <?php
                if ($currentMethod == "edit_compliance") {
                    if($arrComplianceData["compliance_violation"] != "yes") {
                        echo "style='display:none'";
                    }
                }
                    ?>><th></th>
                <td colspan="3" style="text-align: center;">
                    <textarea name="violation_description" rows="5" style="width:98%;">
                        <?php
                        if ($currentMethod == "edit_compliance") {
                            echo $arrComplianceData["violation_description"];
                        }
                        ?>
                    </textarea>
                </td>
            </tr>
            <tr class="oddRow toggleViolationDescription" 
                <?php
                if ($currentMethod == "edit_compliance") {
                    if($arrComplianceData["compliance_violation"] != "yes") {
                        echo "style='display:none'";
                    }
                }
                    ?>>
                <th>
                </th>
                <th>Name:&nbsp;&nbsp;&nbsp;<input name="compliance_violated_by" type="text" 
                    <?php
                    if ($currentMethod == "edit_compliance") {
                        echo 'value="' . $arrComplianceData["compliance_violated_by"] . '"';
                    }
                    ?> /></th>
                <th>Title:&nbsp;&nbsp;&nbsp;<input name="compliance_violated_by_title" type="text" 
                    <?php
                    if ($currentMethod == "edit_compliance") {
                        echo 'value="' . $arrComplianceData["compliance_violated_by_title"] . '"';
                    }
                    ?>/></th>
                <th>Date:&nbsp;&nbsp;&nbsp;<input name="compliance_violated_by_date" id="compliance_violated_date" type="text" value="<?php echo date('m/d/Y'); ?>"/></th>
                <th></th>
            </tr>
            <tr><th class="alignRight">HCP SIGNATURE:</th> <td> 
                		<a href="#" onclick="openSignaturePad(); return false;">Click here</a> 
                		<img id="signatureImage" width="500" height="200" <?php  if(isset($mirfDetails[0]['hcp_signature'])) echo "src='".base_url()."images/mirf_signatures/".$mirfDetails[0]['hcp_signature']."'";?>></img> 
                        <input type="hidden" name="hcp_signature" value="<?php  if(isset($mirfDetails[0]['hcp_signature'])) echo $mirfDetails[0]['hcp_signature']; else echo ''; ?>" style="width:97%;"></input></td>
                </tr>
        </table>
        <center>
            <input type="button" value="Submit" onclick="validate()" />
            <input type="reset" value="Clear" />
            <a class="blueButton" href="#" onclick="window.history.back();">Cancel</a>
        </center>
    </form>

</div>
    <div id="signaturePadDialoge" class="microProfileDialogBox">
		<div class="signaturePadDialoge profileContent"></div>
	</div>
<script type="text/javascript">
   
    var countOrg=0;
    var autosearchId;
    var autosearchIdOrg;
    var currentMethod = '<?php echo $currentMethod; ?>';
    var count=  <?php if($count==''){echo $count=0;}else echo $count; ?>;
      
    $(document).ready(function () {
          $("#kolSearch input").live('click',function(){
        
          var id=$(this).attr("id");
        autosearchId=id;
          $('#'+id).autocomplete(kolAutoCompleteOptions);
      });
      
         $("#orgSearch input").live('click',function(){
        
          var id=$(this).attr("id");
        autosearchIdOrg=id;
          $('#'+id).autocomplete(orgAutoCompleteOptions);
      });
      
	       var kolAutoCompleteOptions = {
    
       serviceUrl: '<?php echo base_url(); ?>kols/get_kol_names_for_autocomplete',
        <?php echo $autoSearchOptions; ?>,
       onSelect: function(event, ui) { 
       var selTextKol = $(event).children('.kolName').html(); 
      
       var id = $(event).children('.id1').html();
 $("."+autosearchId+"_hidden").remove();
    
       selTextKol=selTextKol.replace(/\&amp;/g,'&');
        $('#'+autosearchId).val(selTextKol);
        $('#contact_id').val(id);
        $("#kolSearch").append("<input type='text' hidden class='"+autosearchId+"_hidden'  name=kol[] value='"+id+"'>");
        }
       }
	      var orgAutoCompleteOptions = {
    
       serviceUrl: '<?php echo base_url(); ?>kols/get_organization_names',
        <?php echo $autoSearchOptions; ?>,
       onSelect: function(event, ui) { 
       var selText = $(event).children().html(); 
    
       
       var id = $(event).children().attr("name");
       selText=selText.replace(/\&amp;/g,'&');
        $('#'+autosearchIdOrg).val(selText);
        $('#contact_id').val(id);
        $("#orgSearch").append("<input type='text' hidden class='"+autosearchIdOrg+"'  name=org[] value='"+id+"'>");
        }
       };
        
        $('#date').datepicker({
            dateFormat: 'mm/dd/yy'
        });
        $('#compliance_violated_date').datepicker({
            dateFormat: 'mm/dd/yy'
        });
        $('.chosenSelect').chosen({allow_single_deselect: true});
        $('.chosenMultipleSelect').chosen({
            no_results_text: "Location not found",
            placeholder_text: "Click to Select Location(s)",
            allow_single_deselect: true
        });
        $('.chosenSelect1').chosen({
//		no_results_text: "KOL not found with the name ",
//		placeholder_text : "Click to Select KOL Name(s)",
            no_results_text: "HCP not found with the name",
            allow_single_deselect: true
        });

        $('.chosenSelect3').chosen({
//		no_results_text: "KOL not found with the name ",
//		placeholder_text : "Click to Select KOL Name(s)",
            no_results_text: "Contact Type not found with the name",
            allow_single_deselect: true
        });

        $('.chosenSelect2').chosen({
//		no_results_text: "KOL not found with the name ",
//		placeholder_text : "Click to Select KOL Name(s)",
            no_results_text: "Organization not found with the name",
            allow_single_deselect: true
        });
        if (currentMethod != "edit_compliance") {
            toggleViolationDescription(0);
            toggleOffLabelInquiry(0);
        }
        $('#addMoreObjectives').click(function(){
			
			var kolSHtml = 	$('#objective').html();
			
			$('#objectiveTable').append("<tr>"+kolSHtml+"</tr>");
			var noofKols = $('#noOfObjectives').val();
			var noOfFields = parseInt(noofKols)+1;
			$('#noOfObjectives').val(noOfFields);

			var order = 'product'+noOfFields;
			$('#objectiveTable tr:last td:eq(0) select').attr('name',order);
			$('#objectiveTable tr:last td:eq(0) select').attr('id',order);

			$('#objectiveTable tr:last td:eq(0) select option:first').attr('selected','selected').val('').text('Select');
			
			var objectFieldName = 'objective'+noOfFields;
			$('#objectiveTable tr:last td:eq(1) select').attr('name',objectFieldName);
			$('#objectiveTable tr:last td:eq(1) select').attr('id',objectFieldName);
			$('#objectiveTable tr:last td:eq(1) select option:first').attr('selected','selected').val('').text('Select');
			
			var topic = 'topic'+noOfFields;
			$('#objectiveTable tr:last td:eq(2) select').attr('name',topic);
			$('#objectiveTable tr:last td:eq(2) select').attr('id',topic);
			$('#objectiveTable tr:last td:eq(2) select option:first').attr('selected','selected').val('').text('Select');

			var product = 'subtopic'+noOfFields;
			$('#objectiveTable tr:last td:eq(3) select').attr('name',product);
			$('#objectiveTable tr:last td:eq(3) select').attr('id',product);
			$('#objectiveTable tr:last td:eq(3) select option:first').attr('selected','selected').val('').text('Select');
	
			
		//	var brand = 'brand'+noOfFields;
		//	$('#objectiveTable tr:last td:eq(3) select').attr('name',brand);
		//	$('#objectiveTable tr:last td:eq(3) select').attr('id',brand);

			$('#objectiveTable tr:last td:eq(5) label').html("<img title='Delete' alt='Delete' src='<?php echo base_url()?>/images/delete.png' onclick='deleteRow1(this)'>");
			

		});

      //Signature Pad dialogBox config
        var signaturePadDialogConf = {
				title: "Add KOL",
				modal: true,
				autoOpen: false,
				width: 710,
				height:550,
				draggable:false,
				position: ['center', 80],
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};

		$("#signaturePadDialoge").dialog(signaturePadDialogConf);

    });

    function deleteRow1(thisObj){
		$(thisObj).parent().parent().parent().remove();
	}
    function deleteRow(thisObj, isSecondary) {
        var prevRowObj = $(thisObj).parent().parent();
        $(prevRowObj).remove();
    }
    function addMore(thisObj, isSecondary) {
        var topicFieldName = 'topics';
        if (isSecondary == 1) {
            topicFieldName = 'additional_' + topicFieldName;
        }
        var prevRowObj = $(thisObj).parent().parent();
        var newRow = '<tr>' + $(prevRowObj).html() + '</tr>';
        var topicId = $(prevRowObj).find('.topic').val();
        $(prevRowObj).find('td:eq(0)').html($(prevRowObj).find('.type option:selected').text());
        $(prevRowObj).find('td:eq(1)').html($(prevRowObj).find('.product option:selected').text());
        var topicDetails = '<input type="hidden" name="' + topicFieldName + '[]" class="' + topicId + '" value="' + topicId + '" />' + $(prevRowObj).find('.topic option:selected').text();
        $(prevRowObj).find('td:eq(2)').html(topicDetails);
        $(prevRowObj).find('td:last').html('<div onclick="deleteRow(this,' + isSecondary + ');" class="actionIcon deleteIcon" alt="Delete" title="Delete"></div>');
        $(prevRowObj).parent().append(newRow);
        $(prevRowObj).parent().find('tr:last .product option').remove();
        $(prevRowObj).parent().find('tr:last .product').append('<option value="">Select Product</option>');
        $(prevRowObj).parent().find('tr:last .topic option').remove();
        $(prevRowObj).parent().find('tr:last .topic').append('<option value="">Select Topic</option>');
    }
	function getProduct(proObject){
		//$('#loadingProduct').show();
		$('#'+topicId+" option" ).remove();
		$('#'+topicId).append('<option value="">Select</option>');
		var typeId = $(proObject).val();
	
		var productId = $(proObject).parent().parent().parent().find('td').eq(2).find('select').attr('id');

		var topicId = $(proObject).parent().parent().parent().find('td').eq(3).find('select').attr('id');
		$.ajax({
			url:'<?php echo base_url()?>/interactions/get_product_by_type/'+typeId,
			dataType:'json',
			success:function(returndata){
				$('#'+topicId+" option" ).remove();
				$('#'+topicId).append('<option value="">Select</option>');
				$('#'+productId+" option" ).remove();
				$('#'+productId).append('<option value="">Select</option>');
				// .each loops through the array
				$.each(returndata.arrProducts, function(key,value){
				
		  				  $('#'+productId).append($("<option></option>")
			                    .attr("value",key)
			                    .text(value));
			
				});
			},
			complete:function(){
			//	$('#loadingProduct').hide();
				}
		});
	}

	function getTopic(proObject){
		//$('#loadingTopic').show();
		//var productId = $(proObject).parent().parent().parent().find('td').eq(0).find('select').val();

		var groupId =  $('#grouping').val();
		var typeId = $(proObject).parent().parent().parent().find('td').eq(1).find('select').val();
		//var typeId = $(proObject).val();	
		var topicId = $(proObject).parent().parent().parent().find('td').eq(2).find('select').attr('id');
		var subTopicId	= $(proObject).parent().parent().parent().find('td').eq(3).find('select').attr('id');
		$.ajax({
			url:'<?php echo base_url()?>/interactions/get_topic_by_type/'+typeId,
			dataType:'json',
			success:function(returndata){
			
				$('#'+topicId+" option" ).remove();
				$('#'+topicId).append('<option value="">Select</option>');
				$('#'+subTopicId+" option" ).remove();
				$('#'+subTopicId).append('<option value="">Select</option>');
				// .each loops through the array
				$.each(returndata.arrTopics, function(key,value){
				
		  				  $('#'+topicId).append($("<option></option>")
			                    .attr("value",key)
			                    .text(value));
			
				});
			},
			complete:function(){
			//	$('#loadingTopic').hide();
				}
		});
	}
  function resetDropDowns(proObject){
		var topicId = $(proObject).parent().parent().parent().find('td').eq(2).find('select').attr('id');
		var subTopicId	= $(proObject).parent().parent().parent().find('td').eq(3).find('select').attr('id');
		$('#'+topicId+" option" ).remove();
		$('#'+topicId).append('<option value="">Select</option>');
		$('#'+subTopicId+" option" ).remove();
		$('#'+subTopicId).append('<option value="">Select</option>');
	}
	
    function toggleOffLabelInquiry(activate) {
        if (activate) {
            $('.toggleOffLabelInquiry').show();
        } else {
            $('.toggleOffLabelInquiry').hide();
        }
    }
    function toggleViolationDescription(activate) {
        if (activate) {
            $('.toggleViolationDescription').show();
        } else {
            $('.toggleViolationDescription').hide();
        }
    }
    function validate() {
        $('#complianceForm').submit();
    }

    function toggleContactType() {
        if ($("#contact_type").val() == "kol") {
//            $("#kols").show();
            $("#kols_chzn").css("display", "inline-block");
//            $("#organization").hide();
            $("#organization_chzn").css("display", "none");
        } else {
//            $("#kols").hide();
            $("#kols_chzn").css("display", "none");
//            $("#organization").show();
            $("#organization_chzn").css("display", "inline-block");
        }
    }
     function removeMoreOrgs(id,thisEle){
            $(id).remove();
            $(thisEle).remove();
            $("."+id+"br").remove();
            $("."+id).remove();
        }
      function removeMoreKols(id,thisEle){
            $(id).remove();
            $(thisEle).remove();
            $("."+id+"br").remove();
            $("."+id).remove();
        }
         function addMoreOrgs(){
          countOrg=countOrg+1;
            $("#orgSearch").append("<br class='orgName"+countOrg+"br'/><input id='orgName"+countOrg+"'  class='autocompleteInputBox orgName"+countOrg+"' autocomplete='off' type='text' placeholder='Search Organization' /><a class='remove-icon' onclick=\"removeMoreOrgs('orgName"+countOrg+"',this)\"></a>");
        }
        function addMoreKols(){
             count=count+1;
            $("#kolSearch").append("<br class='kolName"+count+"br'/><input id='kolName"+count+"'  class='autocompleteInputBox kolName"+count+"' autocomplete='off' type='text' placeholder='Search Kol' /><a class='remove-icon' onclick=\"removeMoreKols('kolName"+count+"',this)\"></a>");
           
        }


        //Signature related js
        var signaturePad;
        function openSignaturePad(){
        	$(".signaturePadDialoge").html("");
    		$(".signaturePadDialoge").html('<div id="signature-pad" class="m-signature-pad"> <div class="m-signature-pad--body"> <canvas></canvas> </div> <div class="m-signature-pad--footer"> <div class="description">Sign above</div>  <button class="button clear" data-action="clear">Clear</button>  <button class="button save" data-action="save">Save</button> </div></div>');
    		$("#signaturePadDialoge").dialog("open");

    		var wrapper = document.getElementById("signature-pad"),
    	    clearButton = wrapper.querySelector("[data-action=clear]"),
    	    saveButton = wrapper.querySelector("[data-action=save]"),
    	    canvas = wrapper.querySelector("canvas"),
    	    signaturePad;

    		 function resizeCanvas() {
    		        // When zoomed out to less than 100%, for some very strange reason,
    		        // some browsers report devicePixelRatio as less than 1
    		        // and only part of the canvas is cleared then.
    		        var ratio =  Math.max(window.devicePixelRatio || 1, 1);
    		        canvas.width = canvas.offsetWidth * ratio;
    		        canvas.height = canvas.offsetHeight * ratio;
    		        canvas.getContext("2d").scale(ratio, ratio);
    		    }
    		    
    		window.onresize = resizeCanvas;
    		resizeCanvas();

    		signaturePad = new SignaturePad(canvas);

    		clearButton.addEventListener("click", function (event) {
    		    signaturePad.clear();
    		});

    		saveButton.addEventListener("click", function (event) {
    		    if (signaturePad.isEmpty()) {
    		        alert("Please provide signature first.");
    		    } else {
    		        //window.open(signaturePad.toDataURL());
    		        var data = {};
    				data['signature_data'] = signaturePad.toDataURL();
    		        $.ajax({
    					url:base_url+"interactions/parse_signature_image",
    					data:data,
    					type:"POST",
    					dataType:'json',
    					success:function(returnData){
    						//alert(returnData.image_name);
    						imageUrl = returnData.image_url;
    						$("#signatureImage").attr('src',imageUrl);
    						$("#mirfForm input[name='hcp_signature']").val(returnData.image_name);
    						$("#signaturePadDialoge").dialog("close");
    		       		}
    			    });
    		    }
    		});
    		
    		//$(".signaturePadDialoge").load(base_url+'requested_kols/upgrade_request_page');
    		return false;
        }
</script>