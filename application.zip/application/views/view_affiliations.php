<?php
/**
*Description:File to create view page for Memberships and Affiliations module
*
*Created by:Vinayak
*
*Created on:Dec 9, 2010
*/
	// prepare array of JS files to insert into queue
	//$queued_js_scripts = array('kols/view_affiliations','highcharts 2.1.0','highchartsTheme','i18n/grid.locale-en','jquery.jqGrid.min','jquery.validate');
	$queued_js_scripts = array('chosen.jquery','kols/view_affiliations','highcharts2_2_2/highcharts3.0.5','highcharts2_2_2/modules/exporting3.0.5','i18n/grid.locale-en','jquery.jqGrid.min','jquery/jquery.validate1.9.min','jqgridExportToExcel');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
		
?>
	<!-- JQGrid Plugins -->
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
	<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet" />
	<!-- Load c3.css -->
    <link href="<?php echo base_url();?>c3js/c3.css" rel="stylesheet" type="text/css">
    
    <!-- Load d3.js and c3.js -->
    <script src="<?php echo base_url();?>c3js/d3.v3.min.js" charset="utf-8"></script>
    <script src="<?php echo base_url();?>c3js/c3.min.js"></script>   
	<style type="text/css">
		/*    Enable Verticle separator between content and side menu list  By Laxman   */
		#contentWrapper.span-23 {
			background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
		    background-position: 135px 50%;
		    background-repeat: repeat-y;
		
		}
		.ui-tabs-vertical .ui-tabs-nav {
		    margin-left: 2px;
	    }
	
		div.toggleBtnWrapper{
			text-align:right;	
		}
		
		#affiliationsChart, #affiliationsChartByEngType, #engagementChart, #affiliationsChartByOrgType{
			
		}
		#affiliationsChartLoader, #affiliationsChartByEngTypeLoader,.pieCharts{
		  text-align:center;
		}
		.firstColumn{
			border-bottom: 1px solid #EEEEEE;
		    border-right: 1px solid #EEEEEE
	    }
	    
	    .secondColumn {
			border-bottom: 1px solid #EEEEEE;
		}
		.pubChartContainer td {
		    padding: 0;
		    width: 50%;
		}
		table.tableSections tr.tableHeader th:nth-child(2n+1), table.tableSections td:nth-child(2n+1) {
		    border-right: 1px solid #EEEEEE;
		}
		.exportOptionsContainer ul:first-child li .addIcon {
    		background-position: -150px -165px;
		}
		div.editIcon{
			margin-left: 10px;
			margin-right: 2px;
		}
		div.editIcon:HOVER{
			margin-left: 10px;
			margin-right: 2px;
		}
	</style>	
	<script type="text/javascript">
	var base_url='<?php echo base_url()?>';
	var kolId=<?php echo $arrKol['id'];?>;
	
	var clientId='<?php echo $this->session->userdata('client_id')?>';
	var userId='<?php echo $this->session->userdata('user_id')?>';
	var userRoleId='<?php echo $this->session->userdata('user_role_id')?>';
	var ROLE_MANAGER ='<?php echo ROLE_MANAGER?>';
	var ROLE_ADMIN 	= '<?php echo ROLE_ADMIN?>';
	var ROLE_USER ='<?php echo ROLE_USER?>';
	var INTERNAL_CLIENT_ID ='<?php echo INTERNAL_CLIENT_ID?>';
	var subContentPage	= '<?php echo $subContentPage;?>';

	var title = "<?php echo lang('Overview.title');?>";
	var allAffiliations ="<?php echo lang('Overview.allAffiliations')?>";
	var organizationName ="<?php echo lang('Overview.OrganizationName')?>";
	var department ="<?php echo lang('Overview.Department')?>";
	var timeFrame ="<?php echo lang('Overview.TimeFrame')?>";
	var orgType ="<?php echo lang('Overview.OrgType')?>";
	var engType ="<?php echo lang('Overview.engType')?>";
	var action ="<?php echo lang('Overview.Action')?>";
	var uniHospital = "<?php echo lang("Overview.UNIVERSITYHOSPITAL");?>";
	var association = "<?php echo lang("Overview.ASSOCIATION");?>";
	var industry = "<?php echo lang("Overview.INDUSTRY");?>";
	var government = "<?php echo lang("Overview.GOVERNMENT");?>";
	var others = "<?php echo lang("Overview.OTHERS");?>";
	jqgridIds	= new Array('JQBlistAllResultSet','JQBlistUniversityResultSet','JQBlistAssociationResultSet','JQBlistIndustryResultSet','JQBlistGovernmentResultSet','JQBlistOthersResultSet');
	var arrExcludeColumnsInExcelExport = new Array('act'); 
	var arrExcludeHeaderColumnsInExcelExport = new Array('Id','client_id','created_by');
	</script>

		<div id="kolOverviewTernaryNav" class="span-20 last">
			<!--<ul class="span-3 append-1 ternaryNav" >
				<?php $this->load->view('elements/kol_short_details_client_view');?>
				<li><a href="#all">All</a></li>
				<li><a href="#university">Univ / Hospital</a></li>
				<li><a href="#society">Associations</a></li>
				<li><a href="#industry">Industry</a></li>
				<li><a href="#govt">Govt. Agency</a></li>
				<li><a href="#others">Others</a></li>
				<li><a href="#report">Reports org</a></li>
				<li><a href="#reportEng">Reports Eng</a></li>
			</ul>
			-->
			<?php 
			     $data['kol_id']= $arrKol['id'];
				switch($subContentPage){
						case 'university':
			?>
									<div id="university">
										<div class="exportOptionsContainer">
											<ul class="pageRightOptions">
												<li><input type="button" onClick="toggleAffiliationGrouping('JQBlistUniversityResultSet', 'toggleUnivGrouping');" value="All Affiliations" name="toggleUnivGrouping" id="toggleUnivGrouping" /></li>
												<?php if($add_affiliation==1 && $this->common_helpers->isActionAllowed('kol_details', 'add', $data)) { ?>
													<li><label class="link" onclick="showAffiliationModalBox();"><a rel="tooltip" title="Add Affiliation" data-placement="top" id="addDataLink"><div class="actionIcon addIcon"></div>Add Affiliation</a></label></li>
												<?php } ?>
												<li><div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="float: right;margin-right: 50px;margin-right: 20px !important;" onclick="exportExcel('#JQBlistUniversityResultSet','university');">
                                                	<a href="#" rel="tooltip" data-original-title="Export University Details into Excel format">&nbsp;</a>
                                                </div></li>
											</ul>
										</div>
										<!-- Start of JQGrid based Table to list University / Hospital Results -->										
										<div class="clear">
											<div class="gridWrapper" id="universityGridContainer">
												<table id="JQBlistUniversityResultSet"></table>
												<div id="listUniversityPager"></div>
											</div>
										</div>
										<!-- End of Listing University / Hospital Results--> 	
									</div>
									<!-- End of University / Hospital Form--> 
			<?php 
							break;
						case 'associations':
			?>
									<!-- Start of Association Form-->
									<div id="society">
										<div class="exportOptionsContainer">
											<ul class="pageRightOptions">
												<li><input type="button" onClick="toggleAffiliationGrouping('JQBlistAssociationResultSet', 'toggleAssocGrouping');" value="All Affiliations" name="toggleAssocGrouping" id="toggleAssocGrouping" /></li>
												<?php if($add_affiliation==1 && $this->common_helpers->isActionAllowed('kol_details', 'add', $data)) { ?>
													<li><label class="link" onclick="showAffiliationModalBox();"><a rel="tooltip" title="Add Affiliation" data-placement="top" id="addDataLink"><div class="actionIcon addIcon"></div>Add Affiliation</a></label></li>
												<?php } ?>
												<li><div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="float: right;margin-right: 50px;margin-right: 20px !important;" onclick="exportExcel('#JQBlistAssociationResultSet','association');">
                                                	<a href="#" rel="tooltip" data-original-title="Export Association Details into Excel format">&nbsp;</a>
                                                </div></li>
											</ul>
										</div>
										<!-- Start of JQGrid based Table to list Association Results -->
										<div class="clear">
											<div class="gridWrapper" id="associationGridContainer">
												<table id="JQBlistAssociationResultSet"></table>
												<div id="listAssociationPager"></div>
											</div>
										</div>
										<!-- End of Table to Association Results -->
					  				</div> 
					 				<!-- End of Association Form--> 
			<?php 
							break;
						case 'industry':
			?>
									<!-- Start of Industry form -->
									<div id="industry">
										<div class="exportOptionsContainer">
											<ul class="pageRightOptions">
												<li><input type="button" onClick="toggleAffiliationGrouping('JQBlistIndustryResultSet', 'toggleIndustryGrouping');" value="All Affiliations" name="toggleIndustryGrouping" id="toggleIndustryGrouping" /></li>
												<?php if($add_affiliation==1 && $this->common_helpers->isActionAllowed('kol_details', 'add', $data)) { ?>
													<li><label class="link" onclick="showAffiliationModalBox();"><a rel="tooltip" title="Add Affiliation" data-placement="top" id="addDataLink"><div class="actionIcon addIcon"></div>Add Affiliation</a></label></li>
												<?php } ?>
												<li><div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="float: right;margin-right: 50px;margin-right: 20px !important;" onclick="exportExcel('#JQBlistIndustryResultSet','industry');">
                                                	<a href="#" rel="tooltip" data-original-title="Export Industry Details into Excel format">&nbsp;</a>
                                                </div></li>
											</ul>
										</div>
										<!-- Start of JQGrid based Table to list industry Results -->
										<div class="clear">
											<div class="gridWrapper" id="industryGridContainer">
												<table id="JQBlistIndustryResultSet"></table>
												<div id="listIndustryPager"></div>
											</div>
										</div>
										<!--End of Table industry Agency  -->	
									</div>		
									<!-- End of industry Agency--> 
			<?php 
							break;
						case 'govt_agency':
			?>
								<!-- Start of  Government Agency form-->		
								<div id="govt">
									<div class="exportOptionsContainer">
										<ul class="pageRightOptions">
											<li><input type="button" onClick="toggleAffiliationGrouping('JQBlistGovernmentResultSet', 'toggleGovtGrouping');" value="All Affiliations" name="toggleGovtGrouping" id="toggleGovtGrouping" /></li>
											<?php if($add_affiliation==1 && $this->common_helpers->isActionAllowed('kol_details', 'add', $data)) { ?>
												<li><label class="link" onclick="showAffiliationModalBox();"><a rel="tooltip" title="Add Affiliation" data-placement="top" id="addDataLink"><div class="actionIcon addIcon"></div>Add Affiliation</a></label></li>
											<?php } ?>
											<li><div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="float: right;margin-right: 50px;margin-right: 20px !important;" onclick="exportExcel('#JQBlistGovernmentResultSet','GovernmentAgency');">
                                            	<a href="#" rel="tooltip" data-original-title="Export Government Agency Details into Excel format">&nbsp;</a>
                                            </div></li>
										</ul>
									</div>
									<!-- Start of JQGrid based Table to list Government Results -->
									<div class="clear">
										<div class="gridWrapper" id="governmentGridContainer">
											<table id="JQBlistGovernmentResultSet"></table>
											<div id="listGovernmentPager"></div>
										</div>
									</div>
									<!--End of Table Government Agency  -->	
								</div>		
								<!-- End of Government Agency--> 
			<?php 
							break;
						case 'others':
			?>
			
							<!-- Start of  Others Form-->		 	
							<div id="others">	
								<div class="exportOptionsContainer">
									<ul class="pageRightOptions">
										<li><input type="button" onClick="toggleAffiliationGrouping('JQBlistOthersResultSet', 'toggleOthersGrouping');" value="All Affiliations" name="toggleOthersGrouping" id="toggleOthersGrouping" /></li>
										<?php if($add_affiliation==1 && $this->common_helpers->isActionAllowed('kol_details', 'add', $data)) { ?>
											<li><label class="link" onclick="showAffiliationModalBox();"><a rel="tooltip" title="Add Affiliation" data-placement="top" id="addDataLink"><div class="actionIcon addIcon"></div>Add Affiliation</a></label></li>
										<?php } ?>
										<li><div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="float: right;margin-right: 50px;margin-right: 20px !important;" onclick="exportExcel('#JQBlistOthersResultSet','other');">
                                            	<a href="#" rel="tooltip" data-original-title="Export Other Details into Excel format">&nbsp;</a>
                                            </div></li>
									</ul>
								</div>
								<!-- Start of JQGrid based Table to list Others Results -->
								<div class="clear">
									<div class="gridWrapper" id="othersGridContainer">
										<table id="JQBlistOthersResultSet"></table>
										<div id="listOthersPager"></div>
									</div>
								</div>
								<!-- End of Table to listOthers -->
							</div>
							<!-- End of Others form--> 
			<?php 
							break;
						case 'reports_org':
			?>
							<!-- Start of Report Details -->
						<div class="pubChartContainer">
							<table class="tableSections">
								<tr class="tableHeader">
									<th>Affiliations By Organization Type</th>
									<th>Affiliations By Engagement Type</th>
								</tr>
								<tr>
									<td class="firstColumn">
									<div id="affiliationsChartLoader" class="pieCharts">
										<div id="affiliationsChart"></div>
									</div>
									</td>
									<td class="secondColumn">
									<div id="affiliationsChartByEngTypeLoader" class="pieCharts">
										<div id="affiliationsChartByEngType"><div class="chartHighlightText">Click on Organization Type</div></div>
									</div>
									</td>
								</tr>
							</table>
						</div>
							<!--<div id="report">	
								<div class="kolCharts">
									<div class="pieCharts">
										<div id="affiliationsChart">
											
										</div>
									</div>
									<div class="pieCharts">
										<div id="affiliationsChartByEngType">
											
										</div>
									</div>
								</div>
							
							</div>
			 				--><!-- End of Report Details -->
			<?php 
							break;
						case 'reports_eng':
			?>
							<!-- Start of Engagement Report Details -->
							<div class="pubChartContainer">
								<table class="tableSections">
									<tr class="tableHeader">
										<th>Affiliations By Engagement Type</th>
										<th>Affiliations By Organization Type</th>
									</tr>
									<tr>
										<td class="firstColumn">
										<div class="pieCharts">
											<div id="engagementChart"></div>
										</div>
										</td>
										<td class="secondColumn">
										<div class="pieCharts">
											<div id="affiliationsChartByOrgType"><div class="chartHighlightText">Click on Engagement Type</div></div>
										</div>
										</td>
									</tr>
								</table>
							</div>
								<!--<div id="reportEng">	
									<div class="kolCharts">
										<div class="pieCharts">
											<div id="engagementChart">
												
											</div>
										</div>
										<div class="pieCharts">
											<div id="affiliationsChartByOrgType">
												
											</div>
										</div>
									</div>
								
								</div>
				 			--><!-- End of Engagement Report Details -->
			<?php 
							break;
						default:
			?>
								<!-- Start of  ALL Form-->	
								<div id="all">
									<div class="exportOptionsContainer">
										<ul class="pageRightOptions">
                                           <?php if($add_affiliation==1 && $this->common_helpers->isActionAllowed('kol_details', 'add', $data)) { ?>
											<li><label class="link" onclick="showAffiliationModalBox();"><a rel="tooltip" title="Add Affiliation" data-placement="top" id="addDataLink"><div class="actionIcon addIcon"></div>Add Affiliation</a></label></li>
                                            <?php } ?>
                                            <li><div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" style="float: right;margin-right: 50px;margin-right: 20px !important;" onclick="exportExcel('#JQBlistAllResultSet','allAffilations');">
                                            	<a href="#" rel="tooltip" data-original-title="Export All Affilations Details into Excel format">&nbsp;</a>
                                            </div></li>
                                         </ul>
									</div>
									<!-- Start of JQGrid based Table to list Others Results -->
									<div class="clear">
										<div class="gridWrapper" id="allAfiliationGridContainer">
											<table id="JQBlistAllResultSet"></table>
											<div id="listAllPager"></div>
										</div>		
										<!-- End of Table to listOthers -->
									</div>
								</div>
								<!-- End of ALL form--> 
			<?php 
							break;
				} 
			?>	
 			
 			<!-- Affiliation Modal box container -->
 			<div id="addAffiliation" class="microProfileDialogBox">
 				<div id="affiliationContainer"  class="profileContent"></div>
 			</div>
 
 </div>
 			
	               