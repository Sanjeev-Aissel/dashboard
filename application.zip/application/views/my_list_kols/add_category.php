<?php

/**
 * File to open  modal box to add category
 * @author: Vinayak
 * @since :2.0
 * @created on: 11-4-11
 * @package application.views.my_list_kols
 *
 */
?>


<style type="text/css">
.clientTbl label {
	color: DimGray;
	display: block;
	font-size: 125%;
	padding-right: 8px;
	text-align: left;
}

label {
	font-weight: bold;
}

.clientTbl select {
	width: 35%;
}

.clientTbl input[type="text"],.clientTbl select {
	width: 200px;
}

</style>
<script type="text/javascript">
/**
* Validate the text for 'Alpha Numeric Only'
*/
function alphanumeric(catName)
{
	var numaric = catName;
	for(var j=0; j<numaric.length; j++)
	{
		var alphaa = numaric.charAt(j);
		 
		var hh = alphaa.charCodeAt(0);
		
		if((hh > 47 && hh<58) || (hh > 64 && hh<91) || (hh > 96 && hh<123))
		{
			
		}
		else{
			jAlert("Enter Only Alpha numeric value");
			return false;
		}
	}
	return true;

}
	function validate(){
		var name = $('#categoryName').val();
		if(name==''){
			$('#msgBox').html('name required');
			$('#msgBox').css({color:"red"});
		}else{
			$('#msgBox').html('');
			}
	}

	var validationRules	=  {
			category: {
				required:true,
				alphaNumeric:true
				
			}
		};

		var validationMessages = {
				category: {
				required: "Required",
				remote: ""
			}
		};

	$(document).ready(function(){
		<?php 
	   /** @Author Vinayak
	   ** @since  22 Aug 2012
	   **The following code is used to disable caching in IE
	   **/
		$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
		$this->output->set_header("Pragma: no-cache"); 
		?>
		$("#saveCategoryForm").validate({
			debug:true,
			//onkeyup:true,
			rules: validationRules,
			messages: validationMessages
		});

		$.validator.addMethod("alphaNumeric", function(value, element) {
	        return this.optional(element) || /^[a-z0-9\- ]+$/i.test(value);
	    }, "Letters, numbers and dashes are allowed..");
	});
</script>

<div class="uniMsgBox"></div>
<form action="<?php echo base_url()."my_list_kols/";if($arrCategory==null) echo "save_category"; else echo "update_category";?>" method="post" id="saveCategoryForm" name="saveCategoryForm" class="validateForm" onsubmit="return validateCategory();">
	<input type="hidden" name="id" id="categoryIdAdd" value="<?php if($arrCategory!=null) echo $arrCategory['id'];?>"></input>

<?php if($this->session->userdata('user_role_id')==ROLE_MANAGER || $this->session->userdata('user_role_id')==ROLE_ADMIN){?> <?php if($arrCategory==null){?>
	<input type="radio" name="is_public" id="isPrivate" value="0" checked="checked" /><label>Private</label>
	<input	type="radio" name="is_public" id="isPublic" value="1" class="required" /><label>Public</label>
<?php }else{
	if($arrCategory['is_public']==1){
		echo '<input type="radio" name="is_public" id="isPrivate" value="0" /><label>Private</label>';
		echo '<input type="radio" name="is_public" id="isPublic" value="1"  class="required" checked="checked"><label>Public</label>';
	}else{
		echo '<input type="radio" name="is_public" id="isPrivate" value="0" checked="checked" /><label>Private</label>';
		echo '<input type="radio" name="is_public" id="isPublic" value="1"  class="required" /><label>Public</label>';
	}

	?> <?php }?> <?php }?>
	<table class="anaylystForm clientTbl addCategory">
		<tr>
			<td>
			<p><label for="categoryName">Category Name:</label> <input type="text"
				name="category" id="categoryName"
				value="<?php if($arrCategory!=null) echo $arrCategory['category'];?>"
				class="required" ></input><br />
			<br />
			</p>
			<div id='msgBox'></div>
			</td>
		</tr>
		<tr>
			<td>
			<div class="formButtons""><input type="submit" value="Save"
				onclick="saveCategory()"></div>
			</td>
		</tr>
	</table>
</form>
