<script src="<?php echo base_url().MODULES_ASSETS;?>clients/js/client.js"></script>
<link  href="<?php echo base_url().MODULES_ASSETS;?>clients/css/client.css" rel="stylesheet">
<script type="text/javascript">
var validationRules	=  {
	client_name: {
		required:true
	},
	client_email: {
		officialemail: true
	},
	client_logo: {
		 accept: "jpg,jpeg,png,gif"
     },
     client_favicon: {
		 accept: "jpg,jpeg,png,gif"
    }
};
var validationMessages = {
	client_name: {
		required: "This field is required."
	},
	client_email: {
		officialemail: "Invalid Mail-id"
	},
	client_logo: {
		accept: "Invalid file type"
	},
	client_favicon: {
		accept: "Invalid file type"
	}
};
$(function () {
	$("#saveClientForm").validate({
        debug: false,
        onkeyup: false,
        rules: validationRules,
        messages: validationMessages
    });
	jQuery.validator.addMethod("officialemail", function (value, element) {
	    if (value != "") {
	        var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	        return regex.test(value);
	    }
	        return false;	    
	}, "Invalid email");
});
</script>
<h1  class="page_title"><?php if($arrClient==null) echo "Add Client"; else echo "Update Client";?></h1>
<div class="container ">
<form action="" method="post" id="saveClientForm" name="save_client_form" class="validateForm" enctype="multipart/form-data">
		<input type="hidden" name="client_id" id="client_id" value="<?php if($arrClient!=null) echo $arrClient['id'];?>"/> 
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Client Name:</label>
				<div class="col-sm-9">
					<input type="text" class="form-control" name="client_name" id="client_name" value="<?php if($arrClient['name']!=null) echo $arrClient['name'];?>"  />
		    	<div id="clientname_duplicate_error"></div>
		    	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Support Email ID:</label>
				<div class="col-sm-9">
					<input type="text" class="form-control" name="client_email" id="clientEmail" value="<?php if($arrClient['support_email_id']!=null) echo $arrClient['support_email_id'];?>"  />
			    </div>
		</div>
			<div class="form-group row">
				<label class="col-sm-3 col-form-label">Notes:</label>
				<div class="col-sm-9">
					<textarea  name="client_notes" id="clientNotes" class="form-control" rows="5"><?php if($arrClient['notes']!=null) echo $arrClient['notes'];?></textarea>
			    </div>
		</div>	
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Client Logo<br><span style="font-size: 11px">(Recommended size: 100x50)</span>:</label>
				<div class="col-sm-9">
				<input type="file" name="client_logo" id="client_logo" class="form-control" style="width:40%;display: inline;"/>
				<?php 
					if($arrClient['client_logo']!=null){
						$clientLogo = $arrClient['client_logo'];
						echo '<input type="hidden" name="client_logo_name" value="'.$clientLogo.'"/>';
						echo '<img src="'.base_url().'images/client_logos/logos/'.$clientLogo.'" style="height: 100px;"/>';
					}
 				?>
			    </div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label">Client Favicon<br><span style="font-size: 11px">(Recommended size: 16x16)</span>:</label>
				<div class="col-sm-9">
				<input type="file" name="client_favicon" id="client_logo" class="form-control" style="width:40%;display: inline;"/>
				<?php 
					if($arrClient['client_favicon']!=null){
						$clientFavicon = $arrClient['client_favicon'];
						echo '<input type="hidden" name="client_favicon_name" value="'.$clientFavicon.'"/>';
						echo '<img src="'.base_url().'images/client_logos/favicons/'.$clientFavicon.'" style="height: 100px;"/>';
					}
 				?>
			    </div>
		</div>
		<div class="form-group row">
			<label class="col-sm-3"></label>
				<div class="col-sm-9">
				<div class="clientMsgBox"></div>
   		  	</div>
		</div>
		<div class="form-group row">
				<label class="col-sm-3 col-form-label"></label>
		   		<div class="col-sm-9">
		     		<input type="submit" class="btn btn-primary" value="Save" onclick="saveClient();return false;" name="submit_button" />
		         	<a type="button" class="btn btn-primary" href="<?php echo base_url();?>clients/clients/list_clients">Cancel</a>
		    	</div>
		</div>
		</form>
	</div>