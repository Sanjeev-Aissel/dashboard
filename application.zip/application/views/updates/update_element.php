<script>
/* $(document).ready(function(){
	var norecord = $('#no-record').val();
	if(norecord!= null){
setTimeout(function() {
	 $('#no-record').fadeOut();
	 $('#no-record').val('');
	}, 10000 );
 }
}); */
</script>
<?php

//pr($arrUpdates);exit;
$i = 1;
if($startFrom > 0)
	$i = $startFrom+1;
	$html = '';
	$base_url=base_url();
	//pr($arrUpdates);exit;
	if(sizeof($arrUpdates) == 0){
		//echo '<p  style="text-align:center;margin-top: 25px;" id="no-record">No records to view</p>';
	}
	foreach($arrUpdates as $update){
		$exclude="false";
		$updateEntryhtml = "<div id='".$i."' class='update-row'>";
		
		//Analyst links
		if(($this->uri->segment(2) == 'show_updates_analyst' || $this->input->post('is_analyst_app') == true) && $update['client_id'] == INTERNAL_CLIENT_ID)
			$updateEntryhtml .= "<span class='activities-select'><input type='checkbox' name='activities[]' value='".$update['created_by']."/".$update['update_type_id']."/".$update['parent_object_id']."/".$update['created_day']."'/></span>";
			if(($this->uri->segment(2) == 'show_updates_analyst' || $this->input->post('is_analyst_app') == true) && $update['client_id'] != INTERNAL_CLIENT_ID)
				$updateEntryhtml .= "<span class='checkbox-place-holder'></span>";
				
				switch ($update['update_type_id']){
					case KOL_PROFILE_IMPORT : 	$kolName = $this->kol->getKolName($update['object_id']);
					$updateEntryhtml .= "<div class='category-box category-overview' >KTL :</div>";
					$updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
					$updateEntryhtml .= "Imported  KOL Profile ".getFullName($kolName);
					break;
					
					case "New HCP" : 			$kolName = $this->kol->getKolName($update['object_id']);
					if($update['is_published'] == 1){
						$time = strtotime($update['published_time']);
					}else{
						$time = strtotime($update['created_time']);
					}
					if($update['client_id'] == INTERNAL_CLIENT_ID){
						$createdBy = "by Aissel Analyst";
					}else{
						$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
					}
					if(getFullName($kolName) !== ''){
						$updateEntryhtml .= '<div class="record-row record-wrapper">
										<div class="record-heading heading-hcp">
										KTL
										</div>
										<div class="record-content">
										<p>Added New KTL '.getFullName($kolName).'</p>
										</div>
										<div class="record-user">
										<p>by <span>'.$createdBy.'</span></p>
										</div>
										<div class="record-time">
										<p>'.humanTiming($time).'</p>
										</div>
										</div>';
					}
					/* $updateEntryhtml .= "<div class='category-box category-overview' >HCP :</div>";
					 $updateEntryhtml .= "<div onclick='viewKolMicroProfile(".$update['object_id'].",event); return false;' class='tooltip-demo tooltop-left microViewIcon Male'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Profile Snapshot'>&nbsp;</a></div>";
					 $updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
					 $updateEntryhtml .="Added HCP Profile ".getFullName($kolName); */
					break;
					
					case "Save Location" : 		$kolName = $this->kol->getKolName($update['parent_object_id']);
					
					if($update['is_published'] == 1){
						$time = strtotime($update['published_time']);
					}else{
						$time = strtotime($update['created_time']);
					}
					if($update['client_id'] == INTERNAL_CLIENT_ID){
						$createdBy = "by Aissel Analyst";
					}else{
						$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
					}
					if(getFullName($kolName) !== ''){
						$updateEntryhtml .= '<div class="record-row record-wrapper">
										<div class="record-heading heading-hcp">
										KTL
										</div>
										<div class="record-content">
										<p>Added Location For KTL '.getFullName($kolName).'</p>
										</div>
										<div class="record-user">
										<p>by <span>'.$createdBy.'</span></p>
										</div>
										<div class="record-time">
										<p>'.humanTiming($time).'</p>
										</div>
										</div>';
					}
					/* $updateEntryhtml .= "<div class='category-box category-overview' >HCP :</div>";
					 $updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
					 $updateEntryhtml .="Added Location For HCP  ".getFullName($kolName); */
					break;
					
					
					case "Save Note" : 			$kolName = $this->kol->getKolName($update['parent_object_id']);
					
					if($update['is_published'] == 1){
						$time = strtotime($update['published_time']);
					}else{
						$time = strtotime($update['created_time']);
					}
					if($update['client_id'] == INTERNAL_CLIENT_ID){
						$createdBy = "by Aissel Analyst";
					}else{
						$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
					}
					if(getFullName($kolName) !== ''){
						$updateEntryhtml .= '<div class="record-row record-wrapper">
										<div class="record-heading heading-hcp">
										KTL
										</div>
										<div class="record-content">
										<p>Added KTL Note For '.getFullName($kolName).'</p>
										</div>
										<div class="record-user">
										<p>by <span>'.$createdBy.'</span></p>
										</div>
										<div class="record-time">
										<p>'.humanTiming($time).'</p>
										</div>
										</div>';
					}
					
					/* $updateEntryhtml .= "<div class='category-box category-overview' >HCP Note :</div>";
					 $updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
					 $updateEntryhtml .="Added HCP Note for ".getFullName($kolName)." "."<a target='' href='$base_url/kols/view/".$update['transaction_id']."'>View</a>"; */
					break;
					
					case "Update Note" :
						//pr($update);
						$kolName = $this->kol->getKolName($update['parent_object_id']);
						
						if($update['is_published'] == 1){
							$time = strtotime($update['published_time']);
						}else{
							$time = strtotime($update['created_time']);
						}
						if($update['client_id'] == INTERNAL_CLIENT_ID){
							$createdBy = "by Aissel Analyst";
						}else{
							$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
						}
						if(getFullName($kolName) !== ''){
							$updateEntryhtml .= '<div class="record-row record-wrapper">
														<div class="record-heading heading-hcp">
														KTL
														</div>
														<div class="record-content">
														<p>'.$update['method_count'].' Note(s) Updated For KTL '.getFullName($kolName).'</p>
														</div>
														<div class="record-user">
														<p>by <span>'.$createdBy.'</span></p>
														</div>
														<div class="record-time">
														<p>'.humanTiming($time).'</p>
														</div>
														</div>';
						}
						break;
					case "Update Notifications" :
						if($update['is_published'] == 1){
							$time = strtotime($update['published_time']);
						}else{
							$time = strtotime($update['created_time']);
						}
						if($update['client_id'] == INTERNAL_CLIENT_ID){
							$createdBy = "by Aissel Analyst";
						}else{
							$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
						}
						
						$updateEntryhtml .= '<div class="record-row record-wrapper">
									<div class="record-heading heading-notification">
									Notifications
									</div>
									<div class="record-content">
									<p> '.$update['number'].' Notification Updated <a target="" href="'.$base_url.'notifications/notifications_home">View</a></p>
									</div>
									<div class="record-user">
									<p>by <span>'.$createdBy.'</span></p>
									</div>
									<div class="record-time">
									<p>'.humanTiming($time).'</p>
									</div>
									</div>';
						break;
					case "Notifications" :
						if($update['is_published'] == 1){
							$time = strtotime($update['published_time']);
						}else{
							$time = strtotime($update['created_time']);
						}
						if($update['client_id'] == INTERNAL_CLIENT_ID){
							$createdBy = "by Aissel Analyst";
						}else{
							$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
						}
						
						$updateEntryhtml .= '<div class="record-row record-wrapper">
									<div class="record-heading heading-notification">
									Notifications
									</div>
									<div class="record-content">
									<p>'.$update['number'].' New Notification Added <a target="" href="'.$base_url.'notifications/notifications_home">View</a></p>
									</div>
									<div class="record-user">
									<p>by <span>'.$createdBy.'</span></p>
									</div>
									<div class="record-time">
									<p>'.humanTiming($time).'</p>
									</div>
									</div>';
						/* $updateEntryhtml .= "<div class='category-box category-overview'  style='background-color:#954A03' >Notifications :</div>";
						 $updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						 $updateEntryhtml .="New Notification added  <a target='' href='$base_url/notifications/notifications_home'>View</a>"; */
						break;
						
					case "Update Location" : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
					
					if($update['is_published'] == 1){
						$time = strtotime($update['published_time']);
					}else{
						$time = strtotime($update['created_time']);
					}
					if($update['client_id'] == INTERNAL_CLIENT_ID){
						$createdBy = "by Aissel Analyst";
					}else{
						$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
					}
					if(getFullName($kolName) !== ''){
						$updateEntryhtml .= '<div class="record-row record-wrapper">
										<div class="record-heading heading-hcp">
										KTL
										</div>
										<div class="record-content">
										<p>Updated Location for KTL '.getFullName($kolName).'</p>
										</div>
										<div class="record-user">
										<p>by <span>'.$createdBy.'</span></p>
										</div>
										<div class="record-time">
										<p>'.humanTiming($time).'</p>
										</div>
										</div>';
					}
					/* $updateEntryhtml .= "<div class='category-box category-overview' >HCP :</div>";
					 $updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
					 $updateEntryhtml .="Updated Location For HCP  ".getFullName($kolName); */
					break;
					
					/*case KOL_PROFILE_DELETE : 	$updateEntryhtml .= "<div class='category-box category-overview' >KOL</div>";
					 $updateEntryhtml .= "<div class='update-small-content' utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
					 $updateEntryhtml .="Deleted KOL";
					 break;*/
					case "Update KTL" : 		$kolName = $this->kol->getKolName($update['object_id']);
					
					if($update['is_published'] == 1){
						$time = strtotime($update['published_time']);
					}else{
						$time = strtotime($update['created_time']);
					}
					if($update['client_id'] == INTERNAL_CLIENT_ID){
						$createdBy = "by Aissel Analyst";
					}else{
						$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
					}
					if(getFullName($kolName) !== ''){
						$updateEntryhtml .= '<div class="record-row record-wrapper">
										<div class="record-heading heading-hcp">
										KTL
										</div>
										<div class="record-content">
										<p>Updated details for KTL '.getFullName($kolName).'</p>
										</div>
										<div class="record-user">
										<p>by <span>'.$createdBy.'</span></p>
										</div>
										<div class="record-time">
										<p>'.humanTiming($time).'</p>
										</div>
										</div>';
					}
					/* $updateEntryhtml .= "<div class='category-box category-overview' >HCP :</div>";
					 $updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
					 $updateEntryhtml .="Updated Overview information for ".getFullName($kolName); */
					break;
					/*case "Save coaching" : 	 	$name= $this->common_helpers->getUserName($update['user_id']);
					
					$updateEntryhtml .= "<div class='category-box ' style='background-color:#000'>Coaching :</div>";
					$updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."' utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
					$updateEntryhtml .="New Coaching Added for  ".$name." "."<a target='' href='$base_url/coachings/view/".$update['transaction_id']."'>View</a>";
					break;*/
					/* case "Update Coaching" : 	 	$name= $this->common_helpers->getUserName($update['user_id']);
					
					$updateEntryhtml .= "<div class='category-box category-overview' style='background-color:#000' >Coaching :</div>";
					$updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."' utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
					$updateEntryhtml .=" Coaching Update for  ".$name." "."<a target='' href='$base_url/coachings/view/".$update['transaction_id']."'>View</a>";
					break;*/
					
					/* case "Save Compliance" : 	 	$name= $this->common_helpers->getUserName($update['user_id']);
					
					$updateEntryhtml .= "<div class='category-box ' style='background-color:#ff0000' >Compliance :</div>";
					$updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."' utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
					$updateEntryhtml .=" New Compliance Added for  ".$name." "."<a target='' href='$base_url/coachings/view_compliance/".$update['transaction_id']."'>View</a>";
					break;
					
					case "Update Compliance" : 		$name= $this->common_helpers->getUserName($update['user_id']);
					
					$updateEntryhtml .= "<div class='category-box ' style='background-color:#ff0000' >Compliance :</div>";
					$updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."' utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
					$updateEntryhtml .="  Compliance Updated for  ".$name." "."<a target='' href='$base_url/coachings/view_compliance/".$update['transaction_id']."'>View</a>";
					break;*/
					
					
					case "Save Speaker" : 	 	 $kolName = $this->kol->getKolName($update['parent_object_id']);
					
					$updateEntryhtml .= "<div class='category-box category-overview' style='background-color:#059A0D' >Speaker Evaluation :</div>";
					$updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."' utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
					$updateEntryhtml .=" New Speaker Evaluation Added for KTL  ".getFullName($kolName)." "."<a target='' href='$base_url/speaker_evaluations/view_micro_detail/".$update['transaction_id']."'></a>";
					break;
					
					case "Update Speaker" : 	 	 $kolName = $this->kol->getKolName($update['parent_object_id']);
					
					$updateEntryhtml .= "<div class='category-box ' style='background-color:#059A0D' >Speaker Evaluation :</div>";
					$updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."' utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
					$updateEntryhtml .=" New Speaker Evaluation Added for KOL  ".getFullName($kolName)." "."<a target='' href='$base_url/speaker_evaluations/view_micro_detail/".$update['transaction_id']."'></a>";
					break;
					
					case "Save Medical Insight" :
						
						$updateEntryhtml .= "<div class='category-box '  style='background-color:#0E50F6'>Medical Insight :</div>";
						$updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."' utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						$updateEntryhtml .="  New Medical Insight was added <a target='' href='$base_url/coachings/view_medical_insight/".$update['transaction_id']."'>View</a>";
						break;
						
					case "Update Medical Insight" :
						
						$updateEntryhtml .= "<div class='category-box ' style='background-color:#0E50F6' >Medical Insight :</div>";
						$updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."' utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						$updateEntryhtml .="   Medical Insight  updated <a target='' href='$base_url/coachings/view_medical_insight/".$update['transaction_id']."'>View</a>";
						break;
						//		case KOL_PROFILE_CONTACT_UPDATE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-overview' >HCP :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."' utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." Contact(s) updated for ".getFullName($kolName);
						//								 	break;
						//		/*case KOL_PROFILE_CONTACT_DELETE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-overview' >HCP :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content' utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .="Deleted ".$update['number']." Contact(s) information for ".getFullName($kolName);
						//								 	break;*/
						//		case KOL_PROFILE_EDUCATION_ADD : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-education' >Education :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."' utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."kols/view/".$update['parent_object_id']."'> Education(s) </a> Added for ".getFullName($kolName);
						//								 	break;
						//		case KOL_PROFILE_EDUCATION_UPDATE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-education' >Education :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."' utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."kols/view/".$update['parent_object_id']."'> Education(s) </a> Updated for ".getFullName($kolName);
						//								 	break;
						//		/*case KOL_PROFILE_EDUCATION_DELETE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-education' >Education :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content' utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .="Deleted ".$update['number']." <a class='update-aff' href='".base_url()."kols/view/".$update['parent_object_id']."'> Education(s) </a> information for ".getFullName($kolName);
						//								 	break;*/
						//		case KOL_PROFILE_AFFILITION_ADD : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-affiliation' >Affiliation :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."kols/view_affiliations/".$update['parent_object_id']."'> Affiliation(s) </a> Added for  ".getFullName($kolName);
						//								 	break;
						//		case KOL_PROFILE_AFFILITION_UPDATE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-affiliation' >Affiliation :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."' utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."kols/view_affiliations/".$update['parent_object_id']."'> Affiliation(s) </a> Updated for ".getFullName($kolName);
						//								 	break;
						//		/*case KOL_PROFILE_AFFILITION_DELETE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-affiliation' >Affiliation :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content' utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .="Deleted ".$update['number']." <a class='update-aff' href='".base_url()."kols/view_affiliations/".$update['parent_object_id']."'> Affiliation(s) </a> information for ".getFullName($kolName);
						//								 	break;*/
						//		case KOL_PROFILE_EVENT_ADD : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-event' >Event :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."' utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."kols/view_events/".$update['parent_object_id']."'> Event(s) </a> Added for ".getFullName($kolName);
						//								 	break;
						//		case KOL_PROFILE_EVENT_UPDATE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-event' >Event :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."kols/view_events/".$update['parent_object_id']."'> Event(s) </a> Updated for ".getFullName($kolName);
						//								 	break;
						//		/*case KOL_PROFILE_EVENT_DELETE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-event' >Event</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .="Deleted ".$update['number']." <a class='update-aff' href='".base_url()."kols/view_events/".$update['parent_object_id']."'> Event(s) </a> information for ".getFullName($kolName);
						//								 	break;*/
						//		case KOL_PROFILE_SOCIAL_MEDIA_UPDATE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-overview' >HCP :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .="Updated <a  class='update-aff' href='".base_url()."kols/view_social_media/".$update['parent_object_id']."'> Social Media </a> information for ".getFullName($kolName);
						//								 	break;
						//		case KOL_PROFILE_PUBLICATION_ADD : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-publication' >Publication :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."kols/view_publications/".$update['parent_object_id']."'> Publication(s) </a> Added for ".getFullName($kolName);
						//								 	break;
						//		/*case KOL_PROFILE_PUBLICATION_DELETE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-publication' >Publication :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .="Deleted ".$update['number']." <a class='update-aff' href='".base_url()."kols/view_publications/".$update['parent_object_id']."'> Publication(s) </a> information for ".getFullName($kolName);
						//								 	break;*/
						//		case KOL_PROFILE_PUBLICATION_VERIFY : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-publication' >Publication :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."kols/view_publications/".$update['parent_object_id']."'> Publication(s) </a> Verified for ".getFullName($kolName);
						//								 	break;
						//		case KOL_PROFILE_PUBLICATION_UNVERIFY : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-publication' >Publication :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."kols/view_publications/".$update['parent_object_id']."'> Publication(s) </a> Unverified for ".getFullName($kolName);
						//								 	break;
						//		case KOL_PROFILE_PUBLICATION_UPDATE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-publication' >Publication :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." <a target='_NEW' class='update-aff' href='".base_url()."kols/view_publications/".$update['parent_object_id']."'> Publication(s) </a> Updated for ".getFullName($kolName);
						//								 	break;
						//		case KOL_PROFILE_TRIAL_ADD : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-trial' >Trial :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."kols/view_clinical_trials/".$update['parent_object_id']."'> Clinical Trial(s) </a> Added for ".getFullName($kolName);
						//								 	break;
						//		case KOL_PROFILE_TRIAL_UPDATE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-trial' >Trial :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."kols/view_clinical_trials/".$update['parent_object_id']."'> Clinical Trial(s) </a> Updated for ".getFullName($kolName);
						//								 	break;
						//		/*case KOL_PROFILE_TRIAL_DELETE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-trial' >Trial :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .="Deleted ".$update['number']." <a class='update-aff' href='".base_url()."kols/view_clinical_trials/".$update['parent_object_id']."'> Clinical Trial(s) </a> information for ".getFullName($kolName);
						//								 	break;*/
						//		case KOL_PERSONAL_INFO_ADD : 	$kolName = $this->kol->getKolName($update['object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-overview' >HCP :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .="Added  <a  class='update-aff' href='".base_url()."kols/view/".$update['object_id']."/personalinfo'> Personal Info </a> information for ".getFullName($kolName);
						//								 	break;
						//		case KOL_PERSONAL_INFO_UPDATE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-overview' >HCP :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .="Updated  <a  class='update-aff' href='".base_url()."kols/view/".$update['object_id']."/personalinfo'> Personal Info  </a> information for ".getFullName($kolName);
						//								 	break;
						//
						//		case ORG_IMPORT : 	$orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
						//							$updateEntryhtml .="<div>Imported Organization <a  href='".base_url()."organization/view/".$update['object_id']."'>".$orgName."</a> ";
						//								 	break;
					case "New Organization" :
						$orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
						
						if($update['is_published'] == 1){
							$time = strtotime($update['published_time']);
						}else{
							$time = strtotime($update['created_time']);
						}
						if($update['client_id'] == INTERNAL_CLIENT_ID){
							$createdBy = "by Aissel Analyst";
						}else{
							$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
						}
						if($orgName !== ''){
							$updateEntryhtml .= '<div class="record-row record-wrapper">
										<div class="record-heading heading-org">
										Organizations
										</div>
										<div class="record-content">
										<p>Added Organization <a href='.base_url().'organizations/view/'.$update['object_id'].'>'.$orgName.'</a></p>
										</div>
										<div class="record-user">
										<p>by <span>'.$createdBy.'</span></p>
										</div>
										<div class="record-time">
										<p>'.humanTiming($time).'</p>
										</div>
										</div>';
						}
						/* $orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
						 $updateEntryhtml .= "<div class='category-box category-enrollment' >HCO :</div>";
						 $updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						 $updateEntryhtml .="Added HCO <a  href='".base_url()."organization/view/".$update['object_id']."'>".$orgName."</a> "; */
						break;
						
					case "Save Location Org" :
						$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
						
						if($update['is_published'] == 1){
							$time = strtotime($update['published_time']);
						}else{
							$time = strtotime($update['created_time']);
						}
						if($update['client_id'] == INTERNAL_CLIENT_ID){
							$createdBy = "by Aissel Analyst";
						}else{
							$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
						}
						if($orgName !== ''){
							$updateEntryhtml .= '<div class="record-row record-wrapper">
										<div class="record-heading heading-org">
										Organizations
										</div>
										<div class="record-content">
										<p>Added Location For Organization <a  href='.base_url().'organizations/view/'.$update['parent_object_id'].'>'.$orgName.'</a></p>
										</div>
										<div class="record-user">
										<p>by <span>'.$createdBy.'</span></p>
										</div>
										<div class="record-time">
										<p>'.humanTiming($time).'</p>
										</div>
										</div>';
						}
						/* $orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
						 $updateEntryhtml .= "<div class='category-box category-enrollment' >HCO :</div>";
						 $updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						 $updateEntryhtml .="Added location for HCO <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> "; */
						break;
						
					case "Update Location Org" :
						$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
						
						if($update['is_published'] == 1){
							$time = strtotime($update['published_time']);
						}else{
							$time = strtotime($update['created_time']);
						}
						if($update['client_id'] == INTERNAL_CLIENT_ID){
							$createdBy = "by Aissel Analyst";
						}else{
							$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
						}
						if($orgName !== ''){
							$updateEntryhtml .= '<div class="record-row record-wrapper">
											<div class="record-heading heading-org">
											Organizations
											</div>
											<div class="record-content">
											<p>Updated Location For Organization <a  href='.base_url().'organizations/view/'.$update['parent_object_id'].'>'.$orgName.'</a></p>
											</div>
											<div class="record-user">
											<p>by <span>'.$createdBy.'</span></p>
											</div>
											<div class="record-time">
											<p>'.humanTiming($time).'</p>
											</div>
											</div>';
						}
						/* $orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
						 $updateEntryhtml .= "<div class='category-box category-enrollment' >HCO :</div>";
						 $updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						 $updateEntryhtml .="Updated location for HCO <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> "; */
						break;
						//		case ORG_DELETE : 	$orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
						//							$updateEntryhtml .="<div>Deleted Organization ";
						//								 	break;
					case "Update Organization" :
						$orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
						
						if($update['is_published'] == 1){
							$time = strtotime($update['published_time']);
						}else{
							$time = strtotime($update['created_time']);
						}
						if($update['client_id'] == INTERNAL_CLIENT_ID){
							$createdBy = "by Aissel Analyst";
						}else{
							$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
						}
						if($orgName !== ''){
							$updateEntryhtml .= '<div class="record-row record-wrapper">
											<div class="record-heading heading-org">
											Organizations
											</div>
											<div class="record-content">
											<p>Updated Overview Information For Organization <a  href='.base_url().'organizations/view/'.$update['parent_object_id'].'>'.$orgName.'</a></p>
											</div>
											<div class="record-user">
											<p>by <span>'.$createdBy.'</span></p>
											</div>
											<div class="record-time">
											<p>'.humanTiming($time).'</p>
											</div>
											</div>';
						}
						/* $orgName = $this->organization->getOrgDetailsForRecentAvtivity($update['object_id']);
						 $updateEntryhtml .= "<div class='category-box category-enrollment' >HCO :</div>";
						 $updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						 $updateEntryhtml .="Updated Overview information for ".getOrgName($orgName); */
						break;
						//		case ORG_ADDRESS_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
						//									$updateEntryhtml .="<div>Updated Address information for organization <a href='".base_url()."organization/view/".$update['object_id']."'>".$orgName."</a> ";
						//								 	break;
						//		case ORG_CONTACT_ADD : 		$orgName = $this->organization->getOrgDetailsForRecentAvtivity($update['parent_object_id']);
						//									//$updateEntryhtml .="<div>Added ".$update['number']." Contact information for organization <a href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									//$updateEntryhtml .= "<div class='category-box category-enrollment' >Organization :</div>";
						//									//$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									//$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Contact(s) </a> Added for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									break;
						//		case ORG_CONTACT_UPDATE : 	$orgName = $this->organization->getOrgDetailsForRecentAvtivity($update['parent_object_id']);
						//									$updateEntryhtml .="<div>Updated ".$update['number']." Contact information for organization ".getOrgName($orgName);;
						//								 	break;
						//		case ORG_CONTACT_DELETE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
						//									//$updateEntryhtml .="<div>Deleted ".$update['number']." Contact information for organization <a href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//								 	break;
						//		case ORG_SOCIAL_MEDIA_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['object_id']);
						//										$updateEntryhtml .="<div>Updated Social Media information for organization <a href='".base_url()."organization/view/".$update['object_id']."'>".$orgName."</a> ";
						//								 		break;
						//		case ORG_KEY_PEOPLE_ADD : 	$orgName = $this->organization->getOrgDetailsForRecentAvtivity($update['parent_object_id']);
						//
						//									$updateEntryhtml .= "<div class='category-box category-keypeople' >Key People :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									//$updateEntryhtml .="<div>Added ".$update['number']." Key People information for organization <a href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//								 	$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."organizations/view_keypeople/".$update['parent_object_id']."'> Key People </a> Added for organization ".getOrgName($orgName);;
						//									break;
						//		case ORG_KEY_PEOPLE_UPDATE : 	$orgName = $this->organization->getOrgDetailsForRecentAvtivity($update['parent_object_id']);
						//
						//									$updateEntryhtml .= "<div class='category-box category-keypeople' >Key People :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									//$updateEntryhtml .="<div>Updated ".$update['number']." Key People information for organization <a href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view_keypeople/".$update['parent_object_id']."'> Key People </a> information Updated for organization ".getOrgName($orgName);;
						//									break;
						//		case ORG_KEY_PEOPLE_DELETE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
						//										$updateEntryhtml .="<div>Deleted ".$update['number']." Key People information for organization <a href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									 	break;
						//
						//			case ORG_ENROLLEMET_ADD : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
						//										//$updateEntryhtml .="Added ".$update['number']." Enrollment for  organization <a  href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									//$updateEntryhtml .="Added ".$update['number']." Enrollement information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//	 								//$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Enrollment </a> Added for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									//$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."kols/view/".$update['parent_object_id']."'> Enrollment </a> Added for <a  href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//										//break;
						//
						//									$updateEntryhtml .= "<div class='category-box category-enrollment' >Enrollment :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Enrollment </a> Added for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//								 	break;
						//
						//		case ORG_ENROLLEMET_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
						//										//$updateEntryhtml .="Added ".$update['number']." Enrollment for  organization <a  href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//										 $updateEntryhtml .= "<div class='category-box category-enrollment' >Enrollment :</div>";
						//										$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//										$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Enrollment </a> Updated for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									 	break;
						//
						//		case ORG_FORMULARY_ADD : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
						//										//$updateEntryhtml .="Added ".$update['number']." Enrollment for  organization <a  href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//
						//									  	$updateEntryhtml .= "<div class='category-box category-formulary' >Formulary :</div>";
						//										$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//										$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Formulary </a> information Added for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//	 								//$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."kols/view/".$update['parent_object_id']."'> Enrollment </a> Added for <a  href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//										break;
						//
						//		case ORG_FORMULARY_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
						//										$updateEntryhtml .= "<div class='category-box category-formulary' >Formulary :</div>";
						//										$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//										$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Formulary </a> information Updated for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									 	break;
						//
						//		case ORG_DISEASE_ADD : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
						//									//$updateEntryhtml .="Added ".$update['number']." Disease Management information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//
						//									$updateEntryhtml .= "<div class='category-box category-disiease' >Disease Management :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." new  <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Disease Management </a> information Added for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									break;
						//
						//		case ORG_DISEASE_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
						//									 	//$updateEntryhtml .="Updated ".$update['number']." Disease Management information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//
						//									$updateEntryhtml .= "<div class='category-box category-disiease' >Disease Management :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//										$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Disease Management </a> information Updated for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									 	break;
						//		case ORG_COLLABARATION_ADD : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
						//									 	//$updateEntryhtml .="Updated ".$update['number']." Disease Management information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//										$updateEntryhtml .= "<div class='category-box category-disiease' >Collaboration Rating :</div>";
						//										$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//										$updateEntryhtml .="Added <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Collaboration Rating </a> information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									 	break;
						//
						//		case ORG_NOTES_ADD : 		$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
						//									//$updateEntryhtml .="Added ".$update['number']." Notes for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									$updateEntryhtml .= "<div class='category-box category-enrollment' >Notes :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Note(s) </a>  Added for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									break;
						//
						//		case ORG_NOTES_UPDATE : 	$orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
						//									 //	$updateEntryhtml .="Updated ".$update['number']." Notes for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									$updateEntryhtml .= "<div class='category-box category-enrollment' >Notes :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view/".$update['parent_object_id']."'> Note(s) </a>  Updated for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									break;
						//		case ORG_PUBLICATION_ADD : 	$orgName = $this->organization->getOrgDetailsForRecentAvtivity($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-publication' >Publication :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." new <a target='_NEW' class='update-aff' href='".base_url()."organizations/view_publications/".$update['parent_object_id']."'> Publication(s) </a> Added for organization ".getOrgName($orgName);
						//								 	break;
						//
						//
						//		case ORG_PUBLICATION_VERIFY : 	$orgName = $this->organization->getOrgDetailsForRecentAvtivity($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-publication' >Publication :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view_publications/".$update['parent_object_id']."'> Publication(s) </a> Verified for ".getOrgName($orgName);
						//								 	break;
						//		case ORG_PUBLICATION_UNVERIFY : 	$orgName = $this->organization->getOrgDetailsForRecentAvtivity($update['parent_object_id']);
						//									$updateEntryhtml .= "<div class='category-box category-publication' >Publication :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view_publications/".$update['parent_object_id']."'> Publication(s) </a> Unverified for ".getOrgName($orgName);
						//								 	break;
						//
						//
						//		case ORG_PUBLICATION_UPDATE : 	$orgName = $this->organization->getOrgDetailsForRecentAvtivity($update['parent_object_id']);
						//
						//									$updateEntryhtml .= "<div class='category-box category-publication' >Publication :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." <a target='_NEW' class='update-aff' href='".base_url()."organizations/view_publications/".$update['parent_object_id']."'> Publication(s) </a> Updated for organization ".getOrgName($orgName);
						//								 	break;
						//
						//
						//
						//		case ORG_TRIAL_ADD : 	$orgName = $this->organization->getOrgDetailsForRecentAvtivity($update['parent_object_id']);
						//										//$updateEntryhtml .="Added ".$update['number']." Enrollment for  organization <a  href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									//$updateEntryhtml .="Added ".$update['number']." <a  class='update-aff' href='".base_url()."organizations/view_clinical_trials/".$update['parent_object_id']."'> Trial(s) </a> information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//	 								//$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."organizations/view_clinical_trials/".$update['parent_object_id']."'> Trial(s) </a>  Added for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									//$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."kols/view/".$update['parent_object_id']."'> Enrollment </a> Added for <a  href='".base_url()."organization/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									//break;
						//									$updateEntryhtml .= "<div class='category-box category-trial' >Trial :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."organizations/view_clinical_trials/".$update['parent_object_id']."'> Clinical Trial(s) </a> Added for organization ".getOrgName($orgName);
						//								 	break;
						//
						//		case ORG_TRIAL_UPDATE : 	$orgName = $this->organization->getOrgDetailsForRecentAvtivity($update['parent_object_id']);
						//										//$updateEntryhtml .="Updated ".$update['number']." <a  class='update-aff' href='".base_url()."organizations/view_clinical_trials/".$update['parent_object_id']."'> Trial(s) </a> information for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									//$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view_clinical_trials/".$update['parent_object_id']."'> Trial(s) </a>  Updated for organization <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> ";
						//									//break;
						//
						//									$updateEntryhtml .= "<div class='category-box category-trial' >Trial :</div>";
						//									$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."organizations/view_clinical_trials/".$update['parent_object_id']."'> Clinical Trial(s) </a> Updated for organization ".getOrgName($orgName);
						//								 	break;
						
						/*case USER_ADD : $user = $this->Client_User->editUser($update['object_id']);
						 $updateEntryhtml .="<div>Added User ".$user['first_name'];
						 break;
						 case USER_UPDATE : 	$user = $this->Client_User->editUser($update['object_id']);
						 $updateEntryhtml .="<div>Updated User ".$user['first_name'];
						 break;
						 case USER_DELETE : 	$updateEntryhtml .="<div>Deleted User";
						 break;
						 case CLIENT_ADD : 	$updateEntryhtml .="<div>Added Client";
						 break;
						 case CLIENT_UPDATE : 	$updateEntryhtml .="<div>Updated Client";
						 break;
						 case CLIENT_DELETE : 	$updateEntryhtml .="<div>Updated Client";
						 break;
						 
						 case KOL_LIST_CREATE : 	$updateEntryhtml .="<div>Updated Client";
						 break;
						 case KOL_LIST_UPDATE : 	$updateEntryhtml .="<div>Updated Client";
						 break;
						 case KOL_LIST_ADD : 	$updateEntryhtml .="<div>Updated Client";
						 break;
						 case KOL_LIST_DELETE : 	$updateEntryhtml .="<div>Updated Client";
						 break;
						 
						 case OBJECTIVE_ADD : 	$updateEntryhtml .="<div>Updated Client";
						 break;
						 case OBJECTIVE_UPDATE : 	$updateEntryhtml .="<div>Updated Client";
						 break;
						 case OBJECTIVE_DELETE : 	$updateEntryhtml .="<div>Updated Client";
						 break;
						 
						 case PLAN_ADD : 	$updateEntryhtml .="<div>Updated Client";
						 break;
						 case PLAN_UPDATE : 	$updateEntryhtml .="<div>Updated Client";
						 break;
						 case PLAN_DELETE : 	$updateEntryhtml .="<div>Updated Client";
						 break;*/
					case "New Interaction" : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
					
					if($update['is_published'] == 1){
						$time = strtotime($update['published_time']);
					}else{
						$time = strtotime($update['created_time']);
					}
					if($update['client_id'] == INTERNAL_CLIENT_ID){
						$createdBy = "by Aissel Analyst";
					}else{
						$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
					}
					if(getFullName($kolName) !== ''){
						$updateEntryhtml .= '<div class="record-row record-wrapper">
										<div class="record-heading heading-interaction">
										Interactions
										</div>
										<div class="record-content">
										<p>'.$update['number'].' new <a href="'.base_url().'kols/view/'.$update['parent_object_id'].'/interaction_report">Interaction(s)</a> Added for '.getFullName($kolName).'</p>
										</div>
										<div class="record-user">
										<p>by <span>'.$createdBy.'</span></p>
										</div>
										<div class="record-time">
										<p>'.humanTiming($time).'</p>
										</div>
										</div>';
					}
					/* $updateEntryhtml .= "<div class='category-box category-interaction' >Interaction :</div>";
					 $updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
					 $updateEntryhtml .=$update['number']." new <a class='update-aff' href='".base_url()."kols/view/".$update['parent_object_id']."/interaction_report'> Interaction(s) </a> Added for ".getFullName($kolName); */
					break;
					
					case "Update Interaction" : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
					
					if($update['is_published'] == 1){
						$time = strtotime($update['published_time']);
					}else{
						$time = strtotime($update['created_time']);
					}
					if($update['client_id'] == INTERNAL_CLIENT_ID){
						$createdBy = "by Aissel Analyst";
					}else{
						$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
					}
					if(getFullName($kolName) !== ''){
						$updateEntryhtml .= '<div class="record-row record-wrapper">
											<div class="record-heading heading-interaction">
											Interactions
											</div>
											<div class="record-content">
											<p>'.$update['number'].' <a href="'.base_url().'kols/view/'.$update['parent_object_id'].'/interaction_report">Interaction(s)</a> Updated for '.getFullName($kolName).'</p>
											</div>
											<div class="record-user">
											<p>by <span>'.$createdBy.'</span></p>
											</div>
											<div class="record-time">
											<p>'.humanTiming($time).'</p>
											</div>
											</div>';
					}
					/* $updateEntryhtml .= "<div class='category-box category-interaction' >Interaction :</div>";
					 $updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
					 $updateEntryhtml .=$update['number']." new <a class='update-aff' href='".base_url()."kols/view/".$update['parent_object_id']."/interaction_report'> Interaction(s) </a> Updated for ".getFullName($kolName); */
					break;
					//		case INTERACTION_UPDATE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
					//								$updateEntryhtml .= "<div class='category-box category-interaction' >Interaction :</div>";
					//								$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
					//								if($kolName['status']==PRENEW || $kolName['status'] ==COMPLETED)
						//									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."kols/view/".$update['parent_object_id']."/interaction'> Interaction(s) </a> Updated for ".getFullName($kolName);
					//								else
						//									$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."interactions/list_interactions'> Interaction(s) </a> Updated for ".getFullName($kolName);
					//							 	break;
						/*case INTERACTION_DELETE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						 $updateEntryhtml .= "<div class='category-box category-interaction' >Interaction :</div>";
						 $updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						 $updateEntryhtml .="Deleted  ".$update['number']." <a class='update-aff' href='".base_url()."interactions/list_interactions'> Interaction(s) </a> information for ".getFullName($kolName);
						 break;*/
					
					
					case "New Payment" :
						$kolName = $this->kol->getKolName($update['parent_object_id']);
						
						if($update['is_published'] == 1){
							$time = strtotime($update['published_time']);
						}else{
							$time = strtotime($update['created_time']);
						}
						if($update['client_id'] == INTERNAL_CLIENT_ID){
							$createdBy = "by Aissel Analyst";
						}else{
							$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
						}
						if(getFullName($kolName) !== ''){
							$updateEntryhtml .= '<div class="record-row record-wrapper">
											<div class="record-heading heading-payment">
											Payments
											</div>
											<div class="record-content">
											<p>'.$update['number'].' new <a href="'.base_url().'kols/view/'.$update['parent_object_id'].'/payments"> Payment(s) </a> Added for '.getFullName($kolName).'</p>
											</div>
											<div class="record-user">
											<p>by <span>'.$createdBy.'</span></p>
											</div>
											<div class="record-time">
											<p>'.humanTiming($time).'</p>
											</div>
											</div>';
						}
						break;
					case "Update Payment" :
						$kolName = $this->kol->getKolName($update['parent_object_id']);
						
						if($update['is_published'] == 1){
							$time = strtotime($update['published_time']);
						}else{
							$time = strtotime($update['created_time']);
						}
						if($update['client_id'] == INTERNAL_CLIENT_ID){
							$createdBy = "by Aissel Analyst";
						}else{
							$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
						}
						if(getFullName($kolName) !== ''){
							$updateEntryhtml .= '<div class="record-row record-wrapper">
								<div class="record-heading heading-payment">
								Payments
								</div>
								<div class="record-content">
								<p>'.$update['method_count'].' <a href="'.base_url().'kols/view/'.$update['parent_object_id'].'/payments"> Payment(s) </a> Updated for '.getFullName($kolName).'</p>
								</div>
								<div class="record-user">
								<p>by <span>'.$createdBy.'</span></p>
								</div>
								<div class="record-time">
								<p>'.humanTiming($time).'</p>
								</div>
								</div>';
						}
						
						/* $updateEntryhtml .= "<div class='category-box category-payment' >Payment :</div>";
						 $updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						 $updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."payments/list_payments/payment'> Payment(s) </a> Added for ".getFullName($kolName); */
						break;
						
					case "New Contract" :
						$kolName = $this->kol->getKolName($update['parent_object_id']);
						
						if($update['is_published'] == 1){
							$time = strtotime($update['published_time']);
						}else{
							$time = strtotime($update['created_time']);
						}
						if($update['client_id'] == INTERNAL_CLIENT_ID){
							$createdBy = "by Aissel Analyst";
						}else{
							$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
						}
						if(getFullName($kolName) !== ''){
							$updateEntryhtml .= '<div class="record-row record-wrapper">
								<div class="record-heading heading-contract">
								Contracts
								</div>
								<div class="record-content">
								<p>'.$update['number'].' new <a href="'.base_url().'contracts/show_contracts"> Contract(s) </a> Added for '.getFullName($kolName).'</p>
								</div>
								<div class="record-user">
								<p>by <span>'.$createdBy.'</span></p>
								</div>
								<div class="record-time">
								<p>'.humanTiming($time).'</p>
								</div>
								</div>';
						}
						
						/* $updateEntryhtml .= "<div class='category-box category-contract' >Contract :</div>";
						 $updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						 $updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."contracts/show_contracts'> Contract(s) </a> Added for ".getFullName($kolName); */
						break;
						
					case "Update Contract" :
						$kolName = $this->kol->getKolName($update['parent_object_id']);
						
						if($update['is_published'] == 1){
							$time = strtotime($update['published_time']);
						}else{
							$time = strtotime($update['created_time']);
						}
						if($update['client_id'] == INTERNAL_CLIENT_ID){
							$createdBy = "by Aissel Analyst";
						}else{
							$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
						}
						if(getFullName($kolName) !== ''){
							$updateEntryhtml .= '<div class="record-row record-wrapper">
								<div class="record-heading heading-contract">
								Contracts
								</div>
								<div class="record-content">
								<p>'.$update['number'].' <a href="'.base_url().'contracts/show_contracts"> Contract(s) </a> Updated for '.getFullName($kolName).'</p>
								</div>
								<div class="record-user">
								<p>by <span>'.$createdBy.'</span></p>
								</div>
								<div class="record-time">
								<p>'.humanTiming($time).'</p>
								</div>
								</div>';
						}
						
						/* $updateEntryhtml .= "<div class='category-box category-contract' >Contract :</div>";
						 $updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						 $updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."contracts/show_contracts'> Contract(s) </a> Added for ".getFullName($kolName); */
						break;
						
					case "New Planning" :
						$kolName = $this->kol->getKolName($update['parent_object_id']);
						if($update['is_published'] == 1){
							$time = strtotime($update['published_time']);
						}else{
							$time = strtotime($update['created_time']);
						}
						if($update['client_id'] == INTERNAL_CLIENT_ID){
							$createdBy = "by Aissel Analyst";
						}else{
							$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
						}
						$updateEntryhtml .= '<div class="record-row record-wrapper">
										<div class="record-heading heading-planning">
										Plans
										</div>
										<div class="record-content">
										<p>'.$update['number'].' new Plan(s) Added <a href="'.base_url().'plannings/show_plans"> View</a></p>
										</div>
										<div class="record-user">
										<p>by <span>'.$createdBy.'</span></p>
										</div>
										<div class="record-time">
										<p>'.humanTiming($time).'</p>
										</div>
										</div>';
						/* $updateEntryhtml .= "<div class='category-box category-planning' >Planning :</div>";
						 $updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						 $updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."plannings/show_plans'> Planning(s) </a> Added"; */
						break;
					case "Update Planning" :
						$kolName = $this->kol->getKolName($update['parent_object_id']);
						if($update['is_published'] == 1){
							$time = strtotime($update['published_time']);
						}else{
							$time = strtotime($update['created_time']);
						}
						if($update['client_id'] == INTERNAL_CLIENT_ID){
							$createdBy = "by Aissel Analyst";
						}else{
							$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
						}
						$updateEntryhtml .= '<div class="record-row record-wrapper">
								<div class="record-heading heading-planning">
								Plans
								</div>
								<div class="record-content">
								<p>'.$update['number'].' Plan(s) Updated <a href="'.base_url().'plannings/show_plans"> View</a></p>
								</div>
								<div class="record-user">
								<p>by <span>'.$createdBy.'</span></p>
								</div>
								<div class="record-time">
								<p>'.humanTiming($time).'</p>
								</div>
								</div>';
						/* $updateEntryhtml .= "<div class='category-box category-planning' >Planning :</div>";
						 $updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						 $updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."plannings/show_plans'> Planning(s) </a> Added"; */
						break;
					case "New Objective" :
						if($update['is_published'] == 1){
							$time = strtotime($update['published_time']);
						}else{
							$time = strtotime($update['created_time']);
						}
						if($update['client_id'] == INTERNAL_CLIENT_ID){
							$createdBy = "by Aissel Analyst";
						}else{
							$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
						}
						$updateEntryhtml .= '<div class="record-row record-wrapper">
										<div class="record-heading heading-planning">
										Objectives
										</div>
										<div class="record-content">
										<p>'.$update['number'].' new Objective(s) Added <a href="'.base_url().'plannings/show_plans"> View</a></p>
										</div>
										<div class="record-user">
										<p>by <span>'.$createdBy.'</span></p>
										</div>
										<div class="record-time">
										<p>'.humanTiming($time).'</p>
										</div>
										</div>';
						break;
					case "Update Objective" :
						if($update['is_published'] == 1){
							$time = strtotime($update['published_time']);
						}else{
							$time = strtotime($update['created_time']);
						}
						if($update['client_id'] == INTERNAL_CLIENT_ID){
							$createdBy = "by Aissel Analyst";
						}else{
							$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
						}
						$updateEntryhtml .= '<div class="record-row record-wrapper">
						<div class="record-heading heading-planning">
						Objectives
						</div>
						<div class="record-content">
						<p>'.$update['number'].' Objective(s) Updated <a href="'.base_url().'plannings/show_plans"> View</a></p>
						</div>
						<div class="record-user">
						<p>by <span>'.$createdBy.'</span></p>
						</div>
						<div class="record-time">
						<p>'.humanTiming($time).'</p>
						</div>
						</div>';
						/* $updateEntryhtml .= "<div class='category-box category-planning' >Planning :</div>";
						 $updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						 $updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."plannings/show_plans'> Planning(s) </a> Added"; */
						break;
						
						//		case PAYMENT_ADD : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//							$updateEntryhtml .= "<div class='category-box category-payment' >Payment :</div>";
						//							$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//							$updateEntryhtml .=$update['number']." new <a  class='update-aff' href='".base_url()."payments/list_payments/payment'> Payment(s) </a> Added for ".getFullName($kolName);
						//							break;
						//		case PAYMENT_UPDATE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						//								$updateEntryhtml .= "<div class='category-box category-payment' >Payment :</div>";
						//								$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//								$updateEntryhtml .=$update['number']." <a  class='update-aff' href='".base_url()."payments/list_payments/payment'> Payment(s) </a> Updated for ".getFullName($kolName);
						//							 	break;
						/*case PAYMENT_DELETE : 	$kolName = $this->kol->getKolName($update['parent_object_id']);
						 $updateEntryhtml .= "<div class='category-box category-interaction' >Payment :</div>";
						 $updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						 $updateEntryhtml .="Deleted  ".$update['number']." <a class='update-aff' href='".base_url()."payments/list_payments'> Payment(s) </a> information for ".getFullName($kolName);
						 break;*/
						
						/*case EVENT_ADD : 	$updateEntryhtml .="<div>Updated Client";
						 break;
						 case EVENT_UPDATE : 	$updateEntryhtml .="<div>Updated Client";
						 break;
						 case EVENT_DELETE : 	$updateEntryhtml .="<div>Updated Client";
						 break;
						 
						 case CONTRACT_ADD : 	$updateEntryhtml .="<div>Updated Client";
						 break;
						 case CONTRACT_UPDATE : 	$updateEntryhtml .="<div>Updated Client";
						 break;
						 case CONTRACT_DELETE : 	$updateEntryhtml .="<div>Updated Client";
						 break;
						 
						 case CALENDER_EVENT_ADD : 	$updateEntryhtml .="<div>Updated Client";
						 break;
						 case CALENDER_EVENT_UPDATE : 	$updateEntryhtml .="<div>Updated Client";
						 break;
						 case CALENDER_EVENT_DELETE : 	$updateEntryhtml .="<div>Updated Client";
						 break;*/
						//		case KOL_STATUS_UPDATE : $kolName = $this->kol->getKolName($update['parent_object_id']);
						//								$updateEntryhtml .= "<div class='category-box category-status' >HCP :</div>";
						//								$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//								$statusString = "";
						//								if($update['object_id'] == STATUS_COMPLETED){
						//									$statusString = COMPLETED;
						//									$updateEntryhtml .= "Changed  KOL Profile <a href='".base_url()."kols/view/".$update['parent_object_id']."'>".getFullName($kolName)."</a> Status to ".$statusString."";
						//								}
						//								if($update['object_id'] == STATUS_APPROVED){
						//									$statusString = APPROVED;
						//									$updateEntryhtml .= "Changed  KOL Profile <a href='".base_url()."requested_kols/show_client_requested_kols'>".getFullName($kolName)."</a> Status to ".$statusString."";
						//								}
						//								if($update['object_id'] == STATUS_NEW){
						//									$statusString = New1;
						//									$updateEntryhtml .= "Changed  KOL Profile <a href='".base_url()."requested_kols/show_client_requested_kols'>".getFullName($kolName)."</a> Status to ".$statusString."";
						//								}
						//								if($update['object_id'] == STATUS_PROFILING){
						//									$statusString = PROFILING;
						//									$updateEntryhtml .= "Changed  KOL Profile <a href='".base_url()."requested_kols/show_client_requested_kols'>".getFullName($kolName)."</a> Status to ".$statusString."";
						//								}
						//								if($update['object_id'] == STATUS_REVIEW){
						//									$statusString = REVIEW;
						//									$updateEntryhtml .= "Changed  KOL Profile <a href='".base_url()."requested_kols/show_client_requested_kols'>".getFullName($kolName)."</a> Status to ".$statusString."";
						//								}
						//								if($update['object_id'] == STATUS_REJECTED){
						//									$statusString = REJECT;
						//									$updateEntryhtml .= "Changed  KOL Profile <a href='".base_url()."requested_kols/show_client_requested_kols'>".getFullName($kolName)."</a> Status to ".$statusString."";
						//								}
						//							 	break;
						//		case ORG_STATUS_UPDATE : $orgName = $this->organization->getOrgNameByOrgId($update['parent_object_id']);
						//								$updateEntryhtml .= "<div class='category-box category-status' style='background-color: #4C99CC;'>Organization :</div>";
						//								$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//								$statusString = "";
						//								if($update['object_id'] == STATUS_COMPLETED){
						//									$statusString = COMPLETED;
						//									$updateEntryhtml .= "Changed  ORG Profile <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> Status to ".$statusString."";
						//								}
						//								if($update['object_id'] == STATUS_NEW){
						//									$statusString = New1;
						//									$updateEntryhtml .= "Changed  ORG Profile <a href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> Status to ".$statusString."";
						//								}
						//								if($update['object_id'] == STATUS_PROFILING){
						//									$statusString = PROFILING;
						//									$updateEntryhtml .= "Changed  ORG Profile <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> Status to ".$statusString."";
						//								}
						//								if($update['object_id'] == STATUS_REQUESTED){
						//									$statusString = REQUESTED;
						//									$updateEntryhtml .= "Changed  ORG Profile <a  href='".base_url()."organizations/view/".$update['parent_object_id']."'>".$orgName."</a> Status to ".$statusString."";
						//								}
						//							 	break;
						//		case SURVEY_STATUS_ADD : $surveyName = $this->survey->getSurveyNameById($update['parent_object_id']);
						//								$updateEntryhtml .= "<div class='category-box category-status' style='background-color: #6A6A68;' >Survey :</div>";
						//								$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//								$statusString = "";
						//								if($update['object_id'] == STATUS_CREATED){
						//									$statusString = CREATED;
						//									$updateEntryhtml .= "A new Survey <a  href='".base_url()."surveys/list_surveys/".$update['parent_object_id']."'>".$surveyName."</a> has been ".$statusString."";
						//								}
						//								if($update['object_id'] == STATUS_UPDATED){
						//									$statusString = UPDATED;
						//									$updateEntryhtml .= "A Survey <a  href='".base_url()."surveys/list_surveys/".$update['parent_object_id']."'>".$surveyName."</a> has been ".$statusString."";
						//								}
						//							 	break;
						//		case SURVEY_STATUS_UPDATE : $surveyName = $this->survey->getSurveyNameById($update['parent_object_id']);
						//								$updateEntryhtml .= "<div class='category-box category-status' style='background-color: #6A6A68;'>Survey :</div>";
						//								$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//								$statusString = "";
						//								if($update['object_id'] == STATUS_UPDATED){
						//									$statusString = UPDATED;
						//									$updateEntryhtml .= "A Survey <a  href='".base_url()."surveys/list_surveys/".$update['parent_object_id']."'>".$surveyName."</a> has been ".$statusString."";
						//								}
						//							 	break;
						//		case SURVEY_STATUS_RESPONDED : $surveyName = $this->survey->getSurveyNameById($update['parent_object_id']);
						//								$updateEntryhtml .= "<div class='category-box category-status' style='background-color: #6A6A68;'>Survey :</div>";
						//								$updateEntryhtml .= "<div class='update-small-content'  cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
						//								$statusString = "";
						//								if($update['object_id'] == STATUS_RESPONDED){
						//									$statusString = RESPONDED;
						//									$updateEntryhtml .= "New survey response received for <a  href='".base_url()."surveys/list_surveys/".$update['parent_object_id']."'>".$surveyName."</a>";
						//								}
						//							 	break;
		case "Add Affilation" :
			$kolName = $this->kol->getKolName($update['parent_object_id']);
			
			if($update['is_published'] == 1){
				$time = strtotime($update['published_time']);
			}else{
				$time = strtotime($update['created_time']);
			}
			if($update['client_id'] == INTERNAL_CLIENT_ID){
				$createdBy = "by Aissel Analyst";
			}else{
				$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
			}
			if(getFullName($kolName) !== ''){
				$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-affilation">
							Affilations
							</div>
							<div class="record-content">
							<p>'.$update['number']. ' New <a href="'.base_url().'kols/view_affiliations/'.$update['parent_object_id'].'"> Affiliation(s) </a> Added for '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
			}
			
			break;
		case "Update Affilation" :
			$kolName = $this->kol->getKolName($update['parent_object_id']);
			
			if($update['is_published'] == 1){
				$time = strtotime($update['published_time']);
			}else{
				$time = strtotime($update['created_time']);
			}
			if($update['client_id'] == INTERNAL_CLIENT_ID){
				$createdBy = "by Aissel Analyst";
			}else{
				$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
			}
			if(getFullName($kolName) !== ''){
				$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-affilation">
							Affilations
							</div>
							<div class="record-content">
							<p>'.$update['number'].' <a href="'.base_url().'kols/view_affiliations/'.$update['parent_object_id'].'"> Affiliation(s) </a> Updated for '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
			}
			
			break;
			
		case "New Events" :
			$kolName = $this->kol->getKolName($update['parent_object_id']);
			
			if($update['is_published'] == 1){
				$time = strtotime($update['published_time']);
			}else{
				$time = strtotime($update['created_time']);
			}
			if($update['client_id'] == INTERNAL_CLIENT_ID){
				$createdBy = "by Aissel Analyst";
			}else{
				$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
			}
			if(getFullName($kolName) !== ''){
				$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-event">
							Events
							</div>
							<div class="record-content">
							<p>'.$update['number']. ' New <a href="'.base_url().'kols/view_events/'.$update['parent_object_id'].'"> Event(s) </a> Added for '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
			}
			
			break;
		case "Update Events" :
			$kolName = $this->kol->getKolName($update['parent_object_id']);
			
			if($update['is_published'] == 1){
				$time = strtotime($update['published_time']);
			}else{
				$time = strtotime($update['created_time']);
			}
			if($update['client_id'] == INTERNAL_CLIENT_ID){
				$createdBy = "by Aissel Analyst";
			}else{
				$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
			}
			if(getFullName($kolName) !== ''){
				$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-event">
							Events
							</div>
							<div class="record-content">
							<p>'.$update['number'].' <a href="'.base_url().'kols/view_events/'.$update['parent_object_id'].'"> Event(s) </a> Updated for '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
			}
			
			break;
		case "New Publications" :
			$kolName = $this->kol->getKolName($update['parent_object_id']);
			
			if($update['is_published'] == 1){
				$time = strtotime($update['published_time']);
			}else{
				$time = strtotime($update['created_time']);
			}
			if($update['client_id'] == INTERNAL_CLIENT_ID){
				$createdBy = "by Aissel Analyst";
			}else{
				$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
			}
			if(getFullName($kolName) !== ''){
				$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-publication">
							Publications
							</div>
							<div class="record-content">
							<p>'.$update['number']. ' New <a href="'.base_url().'kols/view_publications/'.$update['parent_object_id'].'"> Publication(s) </a> Added for '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
			}
			
			break;
		case "Update Publications" :
			$kolName = $this->kol->getKolName($update['parent_object_id']);
			
			if($update['is_published'] == 1){
				$time = strtotime($update['published_time']);
			}else{
				$time = strtotime($update['created_time']);
			}
			if($update['client_id'] == INTERNAL_CLIENT_ID){
				$createdBy = "by Aissel Analyst";
			}else{
				$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
			}
			if(getFullName($kolName) !== ''){
				$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-publication">
							Publications
							</div>
							<div class="record-content">
							<p>'.$update['number'].' <a href="'.base_url().'kols/view_publications/'.$update['parent_object_id'].'"> Publication(s) </a> Updated for '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
			}
			
			break;
		case "New Clinical Trails" :
			$kolName = $this->kol->getKolName($update['parent_object_id']);
			
			if($update['is_published'] == 1){
				$time = strtotime($update['published_time']);
			}else{
				$time = strtotime($update['created_time']);
			}
			if($update['client_id'] == INTERNAL_CLIENT_ID){
				$createdBy = "by Aissel Analyst";
			}else{
				$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
			}
			if(getFullName($kolName) !== ''){
				$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-trials">
							Clinical Trails
							</div>
							<div class="record-content">
							<p>'.$update['number']. ' New <a href="'.base_url().'kols/view_clinical_trials/'.$update['parent_object_id'].'"> Clinical Trail(s) </a> Added for '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
			}
			
			break;
		case "Update Clinical Trails" :
			$kolName = $this->kol->getKolName($update['parent_object_id']);
			
			if($update['is_published'] == 1){
				$time = strtotime($update['published_time']);
			}else{
				$time = strtotime($update['created_time']);
			}
			if($update['client_id'] == INTERNAL_CLIENT_ID){
				$createdBy = "by Aissel Analyst";
			}else{
				$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
			}
			if(getFullName($kolName) !== ''){
				$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-trials">
							Clinical Trails
							</div>
							<div class="record-content">
							<p>'.$update['number'].' <a href="'.base_url().'kols/view_clinical_trials/'.$update['parent_object_id'].'"> Clinical Trail(s) </a> Updated for '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
			}
			
			break;
		case "New Education" :
			$kolName = $this->kol->getKolName($update['parent_object_id']);
			
			if($update['is_published'] == 1){
				$time = strtotime($update['published_time']);
			}else{
				$time = strtotime($update['created_time']);
			}
			if($update['client_id'] == INTERNAL_CLIENT_ID){
				$createdBy = "by Aissel Analyst";
			}else{
				$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
			}
			if(getFullName($kolName) !== ''){
				$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-hcp">
							KTL
							</div>
							<div class="record-content">
							<p>'.$update['number'].' New Education(s) Added for '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
			}
			
			break;
		case "Update Education" :
			$kolName = $this->kol->getKolName($update['parent_object_id']);
			
			if($update['is_published'] == 1){
				$time = strtotime($update['published_time']);
			}else{
				$time = strtotime($update['created_time']);
			}
			if($update['client_id'] == INTERNAL_CLIENT_ID){
				$createdBy = "by Aissel Analyst";
			}else{
				$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
			}
			if(getFullName($kolName) !== ''){
				$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-hcp">
							KTL
							</div>
							<div class="record-content">
							<p>'.$update['number'].' Education(s) Updated for '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
			}
			
			break;
			
		case "New Training" :
			$kolName = $this->kol->getKolName($update['parent_object_id']);
			
			if($update['is_published'] == 1){
				$time = strtotime($update['published_time']);
			}else{
				$time = strtotime($update['created_time']);
			}
			if($update['client_id'] == INTERNAL_CLIENT_ID){
				$createdBy = "by Aissel Analyst";
			}else{
				$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
			}
			if(getFullName($kolName) !== ''){
				$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-hcp">
							KTL
							</div>
							<div class="record-content">
							<p>'.$update['number'].' New Training(s) Added for '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
			}
			
			break;
		case "Update Training" :
			$kolName = $this->kol->getKolName($update['parent_object_id']);
			
			if($update['is_published'] == 1){
				$time = strtotime($update['published_time']);
			}else{
				$time = strtotime($update['created_time']);
			}
			if($update['client_id'] == INTERNAL_CLIENT_ID){
				$createdBy = "by Aissel Analyst";
			}else{
				$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
			}
			if(getFullName($kolName) !== ''){
				$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-hcp">
							KTL
							</div>
							<div class="record-content">
							<p>'.$update['number'].' Training(s) Updated for '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
			}
			
			break;
			
		case "New Board_certification" :
			$kolName = $this->kol->getKolName($update['parent_object_id']);
			
			if($update['is_published'] == 1){
				$time = strtotime($update['published_time']);
			}else{
				$time = strtotime($update['created_time']);
			}
			if($update['client_id'] == INTERNAL_CLIENT_ID){
				$createdBy = "by Aissel Analyst";
			}else{
				$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
			}
			if(getFullName($kolName) !== ''){
				$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-hcp">
							KTL
							</div>
							<div class="record-content">
							<p>'.$update['number'].' New Board Certification(s) Added for '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
			}
			
			break;
		case "Update Board_certification" :
			$kolName = $this->kol->getKolName($update['parent_object_id']);
			
			if($update['is_published'] == 1){
				$time = strtotime($update['published_time']);
			}else{
				$time = strtotime($update['created_time']);
			}
			if($update['client_id'] == INTERNAL_CLIENT_ID){
				$createdBy = "by Aissel Analyst";
			}else{
				$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
			}
			if(getFullName($kolName) !== ''){
				$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-hcp">
							KTL
							</div>
							<div class="record-content">
							<p>'.$update['number'].' Board Certification(s) Updated for '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
			}
			
			break;
		case "New Honors_awards" :
			$kolName = $this->kol->getKolName($update['parent_object_id']);
			
			if($update['is_published'] == 1){
				$time = strtotime($update['published_time']);
			}else{
				$time = strtotime($update['created_time']);
			}
			if($update['client_id'] == INTERNAL_CLIENT_ID){
				$createdBy = "by Aissel Analyst";
			}else{
				$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
			}
			if(getFullName($kolName) !== ''){
				$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-hcp">
							KTL
							</div>
							<div class="record-content">
							<p>'.$update['number'].' New Honors Award(s) Added for '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
			}
			
			break;
		case "Update Honors_awards" :
			$kolName = $this->kol->getKolName($update['parent_object_id']);
			
			if($update['is_published'] == 1){
				$time = strtotime($update['published_time']);
			}else{
				$time = strtotime($update['created_time']);
			}
			if($update['client_id'] == INTERNAL_CLIENT_ID){
				$createdBy = "by Aissel Analyst";
			}else{
				$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
			}
			if(getFullName($kolName) !== ''){
				$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-hcp">
							KTL
							</div>
							<div class="record-content">
							<p>'.$update['number'].' Honors Award(s) Updated for '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
			}
			
			break;
		case "New Phone" : 		$kolName = $this->kol->getKolName($update['parent_object_id']);
		
		if($update['is_published'] == 1){
			$time = strtotime($update['published_time']);
		}else{
			$time = strtotime($update['created_time']);
		}
		if($update['client_id'] == INTERNAL_CLIENT_ID){
			$createdBy = "by Aissel Analyst";
		}else{
			$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
		}
		if(getFullName($kolName) !== ''){
			$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-hcp">
							KTL
							</div>
							<div class="record-content">
							<p>'.$update['number'].' New Phone(s) Added For KTL '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
		}
		/* $updateEntryhtml .= "<div class='category-box category-overview' >HCP :</div>";
		 $updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
		 $updateEntryhtml .="Added Location For HCP  ".getFullName($kolName); */
		break;
		case "Update Phone" : 		$kolName = $this->kol->getKolName($update['parent_object_id']);
		
		if($update['is_published'] == 1){
			$time = strtotime($update['published_time']);
		}else{
			$time = strtotime($update['created_time']);
		}
		if($update['client_id'] == INTERNAL_CLIENT_ID){
			$createdBy = "by Aissel Analyst";
		}else{
			$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
		}
		if(getFullName($kolName) !== ''){
			$updateEntryhtml .= '<div class="record-row record-wrapper">
    							<div class="record-heading heading-hcp">
    							KTL
    							</div>
    							<div class="record-content">
    							<p>'.$update['number'].' Phone(s) Updated For KTL '.getFullName($kolName).'</p>
    							</div>
    							<div class="record-user">
    							<p>by <span>'.$createdBy.'</span></p>
    							</div>
    							<div class="record-time">
    							<p>'.humanTiming($time).'</p>
    							</div>
    							</div>';
		}
		/* $updateEntryhtml .= "<div class='category-box category-overview' >HCP :</div>";
		 $updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
		 $updateEntryhtml .="Added Location For HCP  ".getFullName($kolName); */
		break;
		case "New Email" : 		$kolName = $this->kol->getKolName($update['parent_object_id']);
		
		if($update['is_published'] == 1){
			$time = strtotime($update['published_time']);
		}else{
			$time = strtotime($update['created_time']);
		}
		if($update['client_id'] == INTERNAL_CLIENT_ID){
			$createdBy = "by Aissel Analyst";
		}else{
			$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
		}
		if(getFullName($kolName) !== ''){
			$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-hcp">
							KTL
							</div>
							<div class="record-content">
							<p>'.$update['number'].' New Email(s) Added For KTL '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
		}
		/* $updateEntryhtml .= "<div class='category-box category-overview' >HCP :</div>";
		 $updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
		 $updateEntryhtml .="Added Location For HCP  ".getFullName($kolName); */
		break;
		case "Update Email" : 		$kolName = $this->kol->getKolName($update['parent_object_id']);
		
		if($update['is_published'] == 1){
			$time = strtotime($update['published_time']);
		}else{
			$time = strtotime($update['created_time']);
		}
		if($update['client_id'] == INTERNAL_CLIENT_ID){
			$createdBy = "by Aissel Analyst";
		}else{
			$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
		}
		if(getFullName($kolName) !== ''){
			$updateEntryhtml .= '<div class="record-row record-wrapper">
    							<div class="record-heading heading-hcp">
    							KTL
    							</div>
    							<div class="record-content">
    							<p>'.$update['number'].' Email(s) Updated For KTL '.getFullName($kolName).'</p>
    							</div>
    							<div class="record-user">
    							<p>by <span>'.$createdBy.'</span></p>
    							</div>
    							<div class="record-time">
    							<p>'.humanTiming($time).'</p>
    							</div>
    							</div>';
		}
		/* $updateEntryhtml .= "<div class='category-box category-overview' >HCP :</div>";
		 $updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
		 $updateEntryhtml .="Added Location For HCP  ".getFullName($kolName); */
		break;
		
		case "New Staff" : 		$kolName = $this->kol->getKolName($update['parent_object_id']);
		
		if($update['is_published'] == 1){
			$time = strtotime($update['published_time']);
		}else{
			$time = strtotime($update['created_time']);
		}
		if($update['client_id'] == INTERNAL_CLIENT_ID){
			$createdBy = "by Aissel Analyst";
		}else{
			$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
		}
		if(getFullName($kolName) !== ''){
			$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-hcp">
							KTL
							</div>
							<div class="record-content">
							<p>'.$update['number'].' New Staff(s) Added For KTL '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
		}
		/* $updateEntryhtml .= "<div class='category-box category-overview' >HCP :</div>";
		 $updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
		 $updateEntryhtml .="Added Location For HCP  ".getFullName($kolName); */
		break;
		case "Update Staff" : 		$kolName = $this->kol->getKolName($update['parent_object_id']);
		
		if($update['is_published'] == 1){
			$time = strtotime($update['published_time']);
		}else{
			$time = strtotime($update['created_time']);
		}
		if($update['client_id'] == INTERNAL_CLIENT_ID){
			$createdBy = "by Aissel Analyst";
		}else{
			$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
		}
		if(getFullName($kolName) !== ''){
			$updateEntryhtml .= '<div class="record-row record-wrapper">
    							<div class="record-heading heading-hcp">
    							KTL
    							</div>
    							<div class="record-content">
    							<p>'.$update['number'].' Staff(s) Updated For KTL '.getFullName($kolName).'</p>
    							</div>
    							<div class="record-user">
    							<p>by <span>'.$createdBy.'</span></p>
    							</div>
    							<div class="record-time">
    							<p>'.humanTiming($time).'</p>
    							</div>
    							</div>';
		}
		/* $updateEntryhtml .= "<div class='category-box category-overview' >HCP :</div>";
		 $updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
		 $updateEntryhtml .="Added Location For HCP  ".getFullName($kolName); */
		break;
		case "New License" : 		$kolName = $this->kol->getKolName($update['parent_object_id']);
		
		if($update['is_published'] == 1){
			$time = strtotime($update['published_time']);
		}else{
			$time = strtotime($update['created_time']);
		}
		if($update['client_id'] == INTERNAL_CLIENT_ID){
			$createdBy = "by Aissel Analyst";
		}else{
			$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
		}
		if(getFullName($kolName) !== ''){
			$updateEntryhtml .= '<div class="record-row record-wrapper">
							<div class="record-heading heading-hcp">
							KTL
							</div>
							<div class="record-content">
							<p>'.$update['number'].' New License(s) Added For KTL '.getFullName($kolName).'</p>
							</div>
							<div class="record-user">
							<p>by <span>'.$createdBy.'</span></p>
							</div>
							<div class="record-time">
							<p>'.humanTiming($time).'</p>
							</div>
							</div>';
		}
		/* $updateEntryhtml .= "<div class='category-box category-overview' >HCP :</div>";
		 $updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
		 $updateEntryhtml .="Added Location For HCP  ".getFullName($kolName); */
		break;
		case "Update License" : 		$kolName = $this->kol->getKolName($update['parent_object_id']);
		
		if($update['is_published'] == 1){
			$time = strtotime($update['published_time']);
		}else{
			$time = strtotime($update['created_time']);
		}
		if($update['client_id'] == INTERNAL_CLIENT_ID){
			$createdBy = "by Aissel Analyst";
		}else{
			$createdBy = $update[FIRST_ORDER]." ".$update[THIRD_ORDER];
		}
		if(getFullName($kolName) !== ''){
			$updateEntryhtml .= '<div class="record-row record-wrapper">
    							<div class="record-heading heading-hcp">
    							KTL
    							</div>
    							<div class="record-content">
    							<p>'.$update['number'].' License(s) Updated For KTL '.getFullName($kolName).'</p>
    							</div>
    							<div class="record-user">
    							<p>by <span>'.$createdBy.'</span></p>
    							</div>
    							<div class="record-time">
    							<p>'.humanTiming($time).'</p>
    							</div>
    							</div>';
		}
		/* $updateEntryhtml .= "<div class='category-box category-overview' >HCP :</div>";
		 $updateEntryhtml .= "<div class='update-small-content' cby='".$update['created_by']."'  utype='".$update['update_type_id']."' pid='".$update['parent_object_id']."' cday='".$update['created_day']."'>";
		 $updateEntryhtml .="Added Location For HCP  ".getFullName($kolName); */
		break;
		
		default: $exclude="true";
		break;
	}
	if($update['module_id'] == "Speaker Evaluation" ){
		$updateEntryhtml .= "<span id='micro-".$i."' onclick='viewKolMicroProfileSpeaker(".$update['object_id'].",".$i.",this); return false;' class='tooltip-demo tooltop-top microViewIcon Male'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Speaker Snapshot'>&nbsp;</a></span>";
		
	}
	/* if($update['is_published'] == 1)
	 $time = strtotime($update['published_time']);
	 else
	 $time = strtotime($update['created_time']);
	 $updateEntryhtml .= "<span class='human-time'> ".humanTiming($time)."</span>"; */
	 
	 if($update['module_id'] == "KOL" && $update['update_type_id'] != KOL_PROFILE_SOCIAL_MEDIA_UPDATE){
	 	if($update['update_type_id']=='Save Location' || $update['update_type_id']=='Update Location'){
	 		//$updateEntryhtml .= "<span id='micro-".$i."' onclick='viewKolMicroProfileKolLocation(".$update['object_id'].",".$i.",this); return false;' class='tooltip-demo tooltop-top microViewIcon Male'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Location Snapshot'>&nbsp;</a></span>";
	 	}else{
	 		//$updateEntryhtml .= "<span id='micro-".$i."' onclick='viewKolMicroProfile(".$update['object_id'].",".$i.",this); return false;' class='tooltip-demo tooltop-top microViewIcon Male'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Profile Snapshot'>&nbsp;</a></span>";
	 	}
	 }else if($update['module_id'] == MODULE_KOL_REQUEST ){
	 	if($update['object_id'] == STATUS_COMPLETED){
	 		//$updateEntryhtml .= "<span id='micro-".$i."' onclick='viewKolMicroProfile(".$update['object_id'].",".$i.",this); return false;' class='tooltip-demo tooltop-top microViewIcon Male'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Profile Snapshot'>&nbsp;</a></span>";
	 	}
	 }else if($update['module_id'] == "Organization"){
	 	if($update['update_type_id']=='Save Location Org' || $update['update_type_id']=='Update Location Org'){
	 		//$updateEntryhtml .= "<span id='micro-".$i."' onclick='viewOrgMicroProfileLocation(".$update['object_id'].",".$i.",this); return false;' class='tooltip-demo tooltop-right orgProfile sprite_iconSet orgRecent'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Organization Location Snapshot'>&nbsp;</a></span>";
	 	}else{
	 		//$updateEntryhtml .= "<span id='micro-".$i."' onclick='viewOrgMicroProfile(".$update['object_id'].",".$i.",this); return false;' class='tooltip-demo tooltop-right orgProfile sprite_iconSet orgRecent'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Organization  Snapshot'>&nbsp;</a></span>";
	 	}
	 }
	 else if($update['update_type_id']!=ORG_KEY_PEOPLE_ADD && $update['update_type_id']!=ORG_KEY_PEOPLE_UPDATE &&
	 		$update['update_type_id']!=ORG_FORMULARY_ADD && $update['update_type_id']!=ORG_FORMULARY_UPDATE && $update['update_type_id']!=ORG_DISEASE_ADD &&
	 		$update['update_type_id']!=ORG_DISEASE_UPDATE &&  $update['update_type_id']!=ORG_NOTES_ADD &&
	 		$update['update_type_id']!=ORG_NOTES_UPDATE && $update['update_type_id']!=ORG_COLLABARATION_ADD && $update['module_id'] != MODULE_SURVEY && $update['module_id'] != MODULE_ORG_REQUEST
	 		
	 		){
	 			if($update['module_id'] == "Interaction"){
	 				//$updateEntryhtml .= "<span class='expand-image tooltip-demo tooltop-top'><a rel='tooltip' class='tooltipLink' href='#' data-original-title='Expand to view the updated data'>&nbsp;</a></span>";
	 			}
	 			
	 }
	 /* if($update['client_id'] == INTERNAL_CLIENT_ID)
	  $updateEntryhtml .= "<div class='created-by'>by Aissel Analyst</div>";
	  else
	  $updateEntryhtml .= "<div class='created-by'>by ".$update[FIRST_ORDER]." ".$update[THIRD_ORDER]." </div>"; */
	  $updateEntryhtml .= "</div>";
	  $updateEntryhtml .= "<div class='update-full-content'></div>";
	  
	  //Analyst links
	  if(($this->uri->segment(2) == 'show_updates_analyst' || $this->input->post('is_analyst_app') == true) && $update['client_id'] == INTERNAL_CLIENT_ID){
	  	$updateEntryhtml .= "<div class='analyst-links'>";
	  	if($update['is_published'] == 1)
	  		$updateEntryhtml .= "<a href='#' class='publish-toggle-llink upl'>UnPublish</a>";
	  		else
	  			$updateEntryhtml .= "<a href='#' class='publish-toggle-llink pl'>Publish</a>";
	  			$updateEntryhtml .= "<a href='#' class='delete-link' title='delete'></a>";
	  			$updateEntryhtml .= "</div>";
	  }
	  
	  //$updateEntryhtml .= '</div>';
	  
	  if($exclude!="true"){
	  	
	  	$html .= $updateEntryhtml;
	  	
	  	
	  }
	  
	  $i++;
}

echo $html;

function getFullName($arrKol){
	/*$firstName	= $arrKol['first_name'];
	 $middleName	= $arrKol['middle_name'];
	 $lastName	= $arrKol['last_name'];
	 
	 $fullName	= $firstName;
	 if(!empty($middleName))
	 $fullName	.= ' '. $middleName;
	 if(!empty($lastName))
	 $fullName	.= ' '. $lastName;*/
	 $fullName = '';
	 if(sizeof($arrKol) > 0){
	 	$arrSalutations	= array(0 => '',1 => 'Dr.', 'Prof.', 'Mr.', 'Ms.');
	 	if($arrKol['status']==PRENEW || $arrKol['status'] ==COMPLETED){
	 		//			$fullName = '<a  href="'.base_url().'kols/view/'.$arrKol['id'].'">'.$arrSalutations[$arrKol['salutation']]." ".$arrKol[FIRST_ORDER].' '.$arrKol[SECOND_ORDER].' '.$arrKol[THIRD_ORDER].'</a>';
	 		$fullName = '<a  href="'.base_url().'kols/view/'.$arrKol['unique_id'].'">'.$arrSalutations[$arrKol['salutation']]." ".nf($arrKol['first_name'],$arrKol['middle_name'],$arrKol['last_name']).'</a>';
	 	}elseif($arrKol['status']==New1 || $arrKol['status']=='Approved'){
	 		//			$fullName = '<a  href="'.base_url().'requested_kols/show_client_requested_kols">'.$arrSalutations[$arrKol['salutation']]." ".$arrKol[FIRST_ORDER].' '.$arrKol[SECOND_ORDER].' '.$arrKol[THIRD_ORDER].'</a>';
	 		$fullName = '<a  href="'.base_url().'requested_kols/show_client_requested_kols">'.$arrSalutations[$arrKol['salutation']]." ".nf($arrKol['first_name'],$arrKol['middle_name'],$arrKol['last_name']).'</a>';
	 	}elseif($arrKol['status']=='rejected' ){
	 		//			$fullName = '<a  href="'.base_url().'requested_kols/show_non_profiled_kols">'.$arrSalutations[$arrKol['salutation']]." ".$arrKol[FIRST_ORDER].' '.$arrKol[SECOND_ORDER].' '.$arrKol[THIRD_ORDER].'</a>';
	 		$fullName = '<a  href="'.base_url().'requested_kols/show_non_profiled_kols">'.$arrSalutations[$arrKol['salutation']]." ".nf($arrKol['first_name'],$arrKol['middle_name'],$arrKol['last_name']).'</a>';
	 	}else{
	 		//			$fullName = $arrSalutations[$arrKol['salutation']]." ".$arrKol[FIRST_ORDER]." ".$arrKol[SECOND_ORDER]." ".$arrKol[THIRD_ORDER];
	 		$fullName = $arrSalutations[$arrKol['salutation']]." ".nf($arrKol['first_name'],$arrKol['middle_name'],$arrKol['last_name']);
	 	}
	 }
	 return $fullName;
}

function getOrgName($arrNames){
	if($arrNames['status'] == COMPLETED){
		$orgName = "<a  href='".base_url()."organizations/view/".$arrNames['id']."'>".$arrNames['name']."</a> ";
	}else{
		$orgName = $arrNames['name'];
	}
	return $orgName;
}