#
# File contains the alter commands/statements to be executed for the application
#
