<?php
/**
 * This is Controller file for 'Maps'
 * 
 * @author Ambarish
 * @since 2.2.1
 * @package application.controllers	
 * @created on 13-05-11
 */

class Maps extends Controller{
	
	private $loggedUserId	= null;
	var $arrOrgIds = array();
	var $arrKols = array();
	private $arrSurveyTypes	= array(
									1=>'Local',
									2=>'National'/*,
									3=>'Global'*/
								);
								
	//Constructor
	function Maps(){
		parent::Controller();
		$this->load->model('kol');
		$this->load->model('map');
		$this->load->model('pubmed');
		$this->load->model('clinical_trial');
		$this->load->model('common_helpers');
		$this->load->library("Ajax_pagination");
		$this->load->model('My_list_kol');
		$this->load->model('payment');
	}
	
	/**
	 * Checks if the user has logged in or not 
	 *@access private
	 */
	private function _is_logged_in(){
		if(!$this->session->userdata('logged_in')) {
			redirect(base_url()."/login");
		}else{
			$this->loggedUserId = $this->session->userdata('user_id');
		}
	}
	/**
	 * Gets all kols lat and lang and details for map
	 * @return unknown_type
	 */
	function get_kols_for_map(){
		$data['arrkols']		=	$this->map->getKolsForMap();
		//	pr($data['arrkols']);
		echo json_encode($data);
	}
	/**
	 * Returns the 'view_maps' page 
	 * @return unknown_type
	 */
	function view_maps(){
		$data['contentPage'] 	=	'maps/view_maps';
		$this->load->view('layouts/client_view',$data);
	}
	
	/**
	 * returns the results for map, matching the keyword with name(first, middle and last)
	 * @author Ambarish
	 * @Created on: May-18-11
	 * @since 2.2.1
	 * @return Array 
	 */
	function search_kols_map(){
		$mapSection='';
		if($this->uri->segment(3)){
			$mapSection	= $this->uri->segment(3);
		}
		$count=0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=0;
		$arrFilterFields	= array();
		$arrFilterFields	= $this->session->userdata('arrMapFilterFields');
		$category=$this->input->post('category');
		$keyword=trim($this->input->post('keyword'));
		$isRequestFromSearch=true;
		//echo $category;
		//echo " ".$keyword;
		//if this function is called from 'list_kols_client_view' as list of kols is same as search kols by 'blank' search string
		if($category==null){
			$category='people';
			$keyword='';
			$isRequestFromSearch=false;
		}
			
		$doAnd=false;
		$splitDone=false;
		
		//Split the keyword by 'comma' or '+' or 'space'	
		$arrKeywords=explode("+",$keyword);	
		// Do And operation if Words are separated by '+' else do or operation	
		if(sizeof($arrKeywords)>1){
			$doAnd=true;	
		}
		else if(!$doAnd){	
			$arrKeywords=explode(",",$keyword);
			if(sizeof($arrKeywords)>1){
				$splitDone=true;	
			}		
		}			
		if(!$doAnd && !$splitDone)
			$arrKeywords=explode(" ",$keyword);			
		
		//We can modify the below logic so as to use the single 'or' and 'and' methods by 
		//sending the array of keyword names and enbling the where condition based on the 
		//size of the array in those methods
		if(sizeof($arrKeywords)==1){
			$arrKeywords[0]=trim($keyword);
			//Get count of kols grouping by category(for each category)
			$arrKolsByCountryCount=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'country');
			$arrKolsBySpecialtyCount=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'specialty');
			$arrKolsByOrgCount=array();//$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'organization');
			$arrKolsByEduCount=array();//$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'education');
			$arrKolsByEventCount=array();//$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'event');
			$arrKolsByListCount=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'list');
			
		}

		//Save the search keyword and arrFilter fileds in order to use them when request comes for different page results(pagination)
		$this->session->set_userdata('keyword',$keyword);
		$this->session->set_userdata('arrMapFilterFields',$arrFilterFields);
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		
		//Preparing the kols by category results as required by the filter page and aso getting the total count for category
		$allCountryCount=0;
		$assoArrKolsByCountryCount=array();
		foreach($arrKolsByCountryCount as $row){
			$assoArrKolsByCountryCount[$row['country']]=$row;
			$allCountryCount+=$row['count'];
		}
		$allSpecialtyCount=0;
		$assoArrKolsBySpecialtyCount=array();
		foreach($arrKolsBySpecialtyCount as $row){
			$assoArrKolsBySpecialtyCount[$row['specs']]=$row;
			$allSpecialtyCount+=$row['count'];
		}
		$allOrgCount=0;
		$assoArrKolsByOrgCount=array();
		foreach($arrKolsByOrgCount as $row){
			$assoArrKolsByOrgCount[$row['name']]=$row;
			$allOrgCount+=$row['count'];
		}
		$allEduCount=0;
		$assoArrKolsByEduCount=array();
		foreach($arrKolsByEduCount as $row){
			$assoArrKolsByEduCount[$row['institute_name']]=$row;
			$allEduCount+=$row['count'];
		}
		$allEventCount=0;
		$assoArrKolsByEventCount=array();
		foreach($arrKolsByEventCount as $row){
			$assoArrKolsByEventCount[$row['event_name']]=$row;
			$allEventCount+=$row['count'];
		}
		$allListCount=0;
		$assoArrKolsByListCount=array();
		foreach($arrKolsByListCount as $row){
			$assoArrKolsByListCount[$row['list_name_id']]=$row;
			$allListCount+=$row['count'];
		}
		
		//Setting all the required data and forwording in to respective page
		$filterData['allCountryCount']=$allCountryCount;
		$filterData['allSpecialtyCount']=$allSpecialtyCount;
		$filterData['allOrgCount']=$allOrgCount;
		$filterData['allEduCount']=$allEduCount;
		$filterData['allEventCount']=$allEventCount;
		$filterData['allListCount']=$allListCount;
		
		$filterData['arrKolsByCountryCount']=$assoArrKolsByCountryCount;
		$filterData['arrKolsBySpecialtyCount']=$assoArrKolsBySpecialtyCount;
		$filterData['arrKolsByOrgCount']=$assoArrKolsByOrgCount;
		$filterData['arrKolsByEduCount']=$assoArrKolsByEduCount;
		$filterData['arrKolsByEventCount']=$assoArrKolsByEventCount;
		$filterData['arrKolsByListCount']=$assoArrKolsByListCount;
		
		$filterData['keyword']=$keyword;
		$filterData['arrAdvSearchFields']="";
		$filterData['arrFilterFields']="";
		$filterData['searchType']="simple";
		
		$data['mapSection'] =$mapSection;
		if($isRequestFromSearch){
			$details['filterPage']	=	'search/kol_filters';
			$details['kolResultsPage']	=	'search/kol_search_results';
		}
		else{
			$details['filterPage']	=	'search/kol_filters_li_style';
			$details['kolResultsPage']	=	'maps/view_maps';
		}
		$details['filterData']	=$filterData;
		$data['data']=$details;
		if($isRequestFromSearch)
			$data['contentPage'] 	=	'search/kol_results';
		else
			$data['contentPage'] 	=	'maps/map_kols_client_view';
		$this->load->view('layouts/client_view',$data);
	}
	/**
	 * Retrives the data for goegraphical map when any filters are applied
	 * @author Ambarish
	 * @Created on: May-18-11
	 * @since 2.2.1
	 * @return unknown_type
	 */
	function filter_map_kols(){
		$arrFilterFields=array();
		$page=$this->input->post('page');
		$myKols=$this->input->post('my_kols');
		$count=0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
		$searchType='';
		$keyword='';
		
		$arrCountries	= array();
		if((int)$page>-1){
			//if the request is for the next page result then get the already saved search and filter fields from session
			$keyword=trim($this->session->userdata('keyword'));	
			$arrFilterFields=$this->session->userdata('arrMapFilterFields');	
		}
		else{
			$searchType=$this->input->post('search_type');
			$keyword=trim($this->session->userdata('keyword'));
			
			//get the values entered in the input fields
			$specialty		=	trim($this->input->post('specialty'));		
			$country		=	trim($this->input->post('country'));
			$state			=	trim($this->input->post('state'));
			$organization	=	trim($this->input->post('organization'));
			$education		=	trim($this->input->post('education'));
			$eventName		=	trim($this->input->post('event_name'));
			$listName		=	trim($this->input->post('list_name'));
			
			//Get all the selected checkboxs details for respective category
			$arrCountries	=	$this->input->post('countries');
			if($arrCountries!='')
				$arrCountries	=explode(",",$arrCountries);
			//if the input field is not blank add the value in to respective category array values
			if($country!='')
				$arrCountries[]	=	$country;
				
			$arrStates	=	$this->input->post('states');
			if($arrStates!='')
				$arrStates	=explode(",",$arrStates);
			//if the input field is not blank add the value in to respective category array values
			if($state!='')
				$arrStates[]	=	$state;
			
			$arrSpecialties	=	$this->input->post('specialties');
			if($arrSpecialties!='')
				$arrSpecialties	=explode(",",$arrSpecialties);
			if($specialty!=''){
				$arrSpecialties[]	=	$specialty;
			}
			
			$arrOrganizations	=	$this->input->post('organizations');
			if($arrOrganizations!='')
				$arrOrganizations	=explode(",",$arrOrganizations);
			if($organization!=''){
				$arrOrganizations[]	=	$organization;
			}
			
			$arrEducations	=	$this->input->post('educations');
			if($arrEducations!='')
				$arrEducations	=explode(",",$arrEducations);
			if($education!=''){
				$arrEducations[]	=	$education;
			}
			
			$arrEvents	=	$this->input->post('events');
			if($arrEvents!='')
				$arrEvents	=explode(",",$arrEvents);
			if($eventName!=''){
				$arrEvents[]	=	$eventName;
			}
			
			$arrLists	=	$this->input->post('lists');
			if($arrLists!='')
				$arrLists	=explode(",",$arrLists);
			if($listName!=''){
				if(stripos($listName, '(')){
					$arrListDetails=explode("(",$listName);
					$listName=trim($arrListDetails[0]);
					$categoryName=trim($arrListDetails[1],") ");
					$listName=$this->My_list_kol->getListName($listName,$categoryName);
				}
				$arrLists[]	=	$listName;
			}
			
			//Prepare array of filter fields, ehich will be used for querying
			$arrFilterFields['specialty']=$arrSpecialties;		
			$arrFilterFields['country']=$arrCountries;
			$arrFilterFields['state']=$arrStates;
			$arrFilterFields['organization']=$arrOrganizations;
			//$arrFilterFields['education']=$this->kol->getInstituteId($education);
			//$arrFilterFields['event_id']=$this->kol->getEventLookupId($eventName);
			$arrFilterFields['education']=$arrEducations;
			$arrFilterFields['event_id']=$arrEvents;
			$arrFilterFields['list_id']=$arrLists;
			$arrFilterFields['event_name']=$eventName;
		}
		$doAnd=false;		
		$splitDone=false;
		
		//Split the keyword by 'comma' or '+' or 'space'	
		$arrKeywords=explode("+",$keyword);		
		if(sizeof($arrKeywords)>1){
			
			$doAnd=true;	
		}
		else if(!$doAnd){	
			$arrKeywords=explode(",",$keyword);
			if(sizeof($arrKeywords)>1){
				$splitDone=true;	
			}		
		}			
		if(!$doAnd && !$splitDone)
			$arrKeywords=explode(" ",$keyword);			
		
		$arrKols=array();
		if(sizeof($arrKeywords)==1){
			$arrKeywords[0]=trim($keyword);
			$arrKols=$this->map->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false);
			$count=$this->map->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,true);
			
		}
		
		$this->session->set_userdata('keyword',$keyword);
		$this->session->set_userdata('arrMapFilterFields',$arrFilterFields);
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		
		$filterData['keyword']=$keyword;
		$filterData['arrAdvSearchFields']="";
		$filterData['arrMapFilterFields']=$arrFilterFields;
		$filterData['searchType']=$searchType;
		$kolResultsData['arrKols']=$arrKols;
		$kolResultsData['arrSalutations']=$arrSalutations;
		$kolResultsData['searchType']="simple";
		$kolResultsData['kolsCount']=$count;
		$kolResultsData['msg']=$this->common_helpers->genSearchResMsgs($startFrom,$limit,$count,$keyword);
		$details['filterPage']	=	'search/kol_filters';
		if($myKols!=null)
			$details['kolResultsPage']	=	'maps/view_maps';
		else
			$details['kolResultsPage']	=	'search/kol_search_results';
		$details['kolResultsData']	=	$kolResultsData;
		$details['filterData']	=$filterData;
//		$data['data']=$details;
//		$data['contentPage'] 	=	'maps/map_kols_client_view';
		$data['arrKols']=$kolResultsData['arrKols'];
		echo json_encode($data);
//		//pr($keyword) ;
//		if($myKols!=null)
//			$this->load->view('maps/view_maps',$kolResultsData);
//		else
//			$this->load->view('search/kol_search_results',$kolResultsData);
			
			
	}
	
	/**
	 * Retrives the data required for the map checkbox's- to get the each filter category counts
	 * @author Ambarish
	 * @Created on: May-18-11
	 * @since 2.2.1
	 */
	function reload_filters(){
		$arrFilterFields=array();
		$page=$this->input->post('page');
		$count=0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
		$searchType='';
		$keyword='';
		
		$arrCountries	=array();
		$arrSpecialties	=array();

		if((int)$page>-1){
			$keyword=trim($this->session->userdata('keyword'));	
			$arrFilterFields=$this->session->userdata('arrMapFilterFields');	
		}
		else{
			$searchType=$this->input->post('search_type');
			$keyword=trim($this->session->userdata('keyword'));
			
			$specialty		=	trim($this->input->post('specialty'));		
			$country		=	trim($this->input->post('country'));
			$state			=	trim($this->input->post('state'));
			$organization	=	trim($this->input->post('organization'));
			$education		=	trim($this->input->post('education'));
			$eventName		=	trim($this->input->post('event_name'));
			$listName		=	trim($this->input->post('list_name'));
			
			
			$arrSpecialties		=	$this->input->post('specialties');
			$arrCountries		=	$this->input->post('countries');
			$arrStates			=	$this->input->post('states');
			$arrOrganizations	=	$this->input->post('organizations');
			$arrEducations		=	$this->input->post('educations');
			$arrEvents			=	$this->input->post('events');
			$arrLists			=	$this->input->post('lists');
			
			if($arrCountries!='')
				$arrCountries	=	explode(",",$arrCountries);
			if($country!='')
				$arrCountries[]	=	$country;
				
			if($arrStates!='')
				$arrStates	=	explode(",",$arrStates);
			if($state!='')
				$arrStates[]	=	$state;
			//echo $specialty;
			
			if($arrSpecialties!='')
				$arrSpecialties	=	explode(",",$arrSpecialties);
			if($specialty!=''){
				$arrSpecialties[]	=	$specialty;
			}
			
			if($arrOrganizations!='')
				$arrOrganizations	=	explode(",",$arrOrganizations);
			if($organization!=''){
				$arrOrganizations[]	=	$organization;
			}
			
			
			if($arrEducations!='')
				$arrEducations		=	explode(",",$arrEducations);
			if($education!=''){
				$arrEducations[]	=	$education;
			}
			
			
			if($arrEvents!='')
				$arrEvents		=	explode(",",$arrEvents);
			if($eventName!=''){
				$arrEvents[]	=	$eventName;
			}
			
			
			if($arrLists!='')
				$arrLists	=explode(",",$arrLists);
			if($listName!=''){
				if(stripos($listName, '(')){
					$arrListDetails=explode("(",$listName);
					$listName=trim($arrListDetails[0]);
					$categoryName=trim($arrListDetails[1],") ");
					$listName=$this->My_list_kol->getListName($listName,$categoryName);
				}
				$arrLists[]	=	$listName;
			}
			
			//Prepare array of filter fields, ehich will be used for querying
			$arrFilterFields['specialty']=$arrSpecialties;		
			$arrFilterFields['country']=$arrCountries;
			$arrFilterFields['state']=$arrStates;
			$arrFilterFields['organization']=$arrOrganizations;
			//$arrFilterFields['education']=$this->kol->getInstituteId($education);
			//$arrFilterFields['event_id']=$this->kol->getEventLookupId($eventName);
			$arrFilterFields['education']=$arrEducations;
			$arrFilterFields['event_id']=$arrEvents;
			$arrFilterFields['list_id']=$arrLists;
			$arrFilterFields['event_name']=$eventName;
		}
		$doAnd=false;		
		$splitDone=false;
		
		//Split the keyword by 'comma' or '+' or 'space'	
		$arrKeywords=explode("+",$keyword);	
		// Do And operation if Words are separated by '+' else do or operation		
		if(sizeof($arrKeywords)>1){
			$doAnd=true;	
		}
		else if(!$doAnd){	
			$arrKeywords=explode(",",$keyword);
			if(sizeof($arrKeywords)>1){
				$splitDone=true;	
			}		
		}			
		if(!$doAnd && !$splitDone)
			$arrKeywords=explode(" ",$keyword);			
		
		$arrKols=array();
		if(sizeof($arrKeywords)==1){
			$arrKeywords[0]=trim($keyword);
			//$arrKols=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false);
			//$count=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,true);
			//Get count of kols grouping by category(for each category)
			$arrKolsByCountryCount=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'country');
			$arrKolsByStateCount=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'state');
			$arrKolsBySpecialtyCount=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'specialty');
			$arrKolsByOrgCount=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'organization');
			$arrKolsByEduCount=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'education');
			$arrKolsByEventCount=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'event');
			$arrKolsByListCount=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'list');
		}
		
	
		//Save the search keyword and arrFilter fileds in order to use them when request comes for different page results(pagination)
		$this->session->set_userdata('keyword',$keyword);
		$this->session->set_userdata('arrMapFilterFields',$arrFilterFields);
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		
		//Preparing the kols by category results as required by the filter page and aso getting the total count for category
		$allCountryCount=0;
		$assoArrKolsByCountryCount=array();
		foreach($arrKolsByCountryCount as $row){
			$assoArrKolsByCountryCount[$row['country']]=$row;
			$allCountryCount+=$row['count'];
		}
		$allStateCount=0;
		$assoArrKolsByStateCount=array();
		foreach($arrKolsByStateCount as $row){
			$assoArrKolsByStateCount[$row['state']]=$row;
			$allStateCount+=$row['count'];
		}
		$allSpecialtyCount=0;
		$assoArrKolsBySpecialtyCount=array();
		foreach($arrKolsBySpecialtyCount as $row){
			$assoArrKolsBySpecialtyCount[$row['specs']]=$row;
			$allSpecialtyCount+=$row['count'];
		}
		$allOrgCount=0;
		$assoArrKolsByOrgCount=array();
		foreach($arrKolsByOrgCount as $row){
			$assoArrKolsByOrgCount[$row['name']]=$row;
			$allOrgCount+=$row['count'];
		}
		$allEduCount=0;
		$assoArrKolsByEduCount=array();
		foreach($arrKolsByEduCount as $row){
			$assoArrKolsByEduCount[$row['institute_name']]=$row;
			$allEduCount+=$row['count'];
		}
		$allEventCount=0;
		$assoArrKolsByEventCount=array();
		foreach($arrKolsByEventCount as $row){
			$assoArrKolsByEventCount[$row['event_name']]=$row;
			$allEventCount+=$row['count'];
		}
		$allListCount=0;
		$assoArrKolsByListCount=array();
		foreach($arrKolsByListCount as $row){
			$assoArrKolsByListCount[$row['list_name_id']]=$row;
			$allListCount+=$row['count'];
		}
		$filterData['mapSection']='geoMap';
		//Setting all the required data and forwording in to respective page
		$filterData['allCountryCount']=$allCountryCount;
		$filterData['allStateCount']=$allStateCount;
		$filterData['allSpecialtyCount']=$allSpecialtyCount;
		$filterData['allOrgCount']=$allOrgCount;
		$filterData['allEduCount']=$allEduCount;
		$filterData['allEventCount']=$allEventCount;
		$filterData['allListCount']=$allListCount;
		
		$filterData['arrKolsByCountryCount']=$assoArrKolsByCountryCount;
		$filterData['arrKolsByStateCount']=$assoArrKolsByStateCount;
		$filterData['arrKolsBySpecialtyCount']=$assoArrKolsBySpecialtyCount;
		$filterData['arrKolsByOrgCount']=$assoArrKolsByOrgCount;
		$filterData['arrKolsByEduCount']=$assoArrKolsByEduCount;
		$filterData['arrKolsByEventCount']=$assoArrKolsByEventCount;
		$filterData['arrKolsByListCount']=$assoArrKolsByListCount;
		
		$filterData['selectedCountries']=$arrCountries;
		$filterData['selectedStates']=$arrStates;
		$filterData['selectedSpecialties']=$arrSpecialties;
		$filterData['selectedOrgs']=$arrOrganizations;
		$filterData['selectedEdus']=$arrEducations;
		$filterData['selectedEvents']=$arrEvents;
		$filterData['selectedLists']=$arrLists;
		
		$filterData['keyword']=$keyword;
		$filterData['arrAdvSearchFields']="";
		$filterData['arrMapFilterFields']=$arrFilterFields;
		$filterData['searchType']=$searchType;
		$kolResultsData['arrKols']=$arrKols;
		$kolResultsData['arrSalutations']=$arrSalutations;
		$kolResultsData['searchType']="simple";
		$kolResultsData['kolsCount']=$count;
		$kolResultsData['msg']=$this->common_helpers->genSearchResMsgs($startFrom,$limit,$count,$keyword);
		$details['filterPage']	=	'search/kol_filters';
		$details['kolResultsPage']	=	'search/kol_search_results';
		$details['kolResultsData']	=	$kolResultsData;
		$details['filterData']	=$filterData;
		$data['data']=$details;
		$data['contentPage'] 	=	'search/kol_results';
		//echo json_encode($data);
		$this->load->view('search/kol_filters_li_style',$filterData);
	}
	
	/**
	 * Prepares the filter data for the influence map and redirects to the influence map page with the data 
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 11-07-11
	 */
	/*function view_influence_map($kolId = null){	
		$filterData						= array();
		$filterData['allSpecialtyCount']= 1;
		$filterData['allCountryCount']	= 1;
		$filterData['allStateCount']	= 1;
		$filterData['allListCount']		= 1;
		$filterData['allOrgCount']		= 1;
		$filterData['allEduCount']		= 1;
		$filterData['allEventCount']	= 1;
		$filterData['arrKolsBySpecialtyCount']	= array();
		$filterData['arrKolsByCountryCount']	= array();
		$filterData['arrKolsByStateCount']		= array();
		$filterData['arrKolsByListCount']		= array();
		$filterData['arrKolsByOrgCount']		= array();
		$filterData['arrKolsByEduCount']		= array();
		$filterData['customFilters']			= $this->kol->getAllCustomFilterByUser($this->session->userdata('user_id'));
//		pr($filterData['customFilters']);
		$data['mapSection']				= '';
		$data['filterPage']				= 'search/kol_filters_li_style';
		$data['filterData']				= $filterData;
		$this->load->model('survey');
		$data['arrCompletedSurveys']	= $this->survey->getCompletedSurveys();
		$data['contentPage'] 			= 'maps/view_influence_map';
		$this->load->view('layouts/client_view',$data);
	}*/
	
	/**
	 * Calculates the kol's influence among themseleves and prpares a json data in a format required by the map and returns the JSON data
	 * @author 	Ramesh B
	 * @since	
	 * @return JSON
	 * @created 11-07-11
	 */
	function get_kols_influence_data(){
		
		//Get array of KOLs
		$arrKolDetailResult = $this->kol->getKolDetail();
		$arrKolDetails	=	array();
		$arrKolIds		=	array();
		foreach($arrKolDetailResult->result_array() as $row){
			$arrKolDetails[$row['id']]=$row;
			$arrKolIds[]=$row['id'];
		}
		
		$arrPubResults=$this->pubmed->getCoAuthoredKols($arrKolIds);
		$arrEventResults=$this->kol->getCoEventedKols($arrKolIds);
		$arrAffResults=$this->kol->getCoAffiliatedKols($arrKolIds);
		foreach($arrKolIds as $kolId){
			$arrPubKols=$arrPubResults[$kolId];
			$arrEventKols=$arrEventResults[$kolId];
			$arrAffKols=$arrAffResults[$kolId];
			$arrKols=$this->get_unique_kolids_with_weightages($arrPubKols,$arrEventKols,$arrAffKols);
			if(sizeof($arrKols)>0)
				$arrData[$kolId]=$arrKols;
		}
		/*$arrData=array();
		foreach($arrKolDetails as $kolDetails){
			//echo "KolId : ".$kolDetails['id']."<br>";
			$arrPubKols=$this->pubmed->getCoAuthoredKols($kolDetails['id']);
			$arrEventKols=$this->kol->getCoEventedKols($kolDetails['id']);
			$arrAffKols=$this->kol->getCoAffiliatedKols($kolDetails['id']);
			$arrKols=$this->get_unique_kolids_with_weightages($arrPubKols,$arrEventKols,$arrAffKols);
			if(sizeof($arrKols)>0)
				$arrData[$kolDetails['id']]=$arrKols;
		}*/
		//pr($arrData);
		$nodeData=array();
		$nodeData['$color']="#2200C1";
		$nodeData['$color']="#555555";
		$nodeData['$type']="circle";
		$data=array();
		foreach($arrData as $key => $value){
			//echo "KolId : ".$key."<br>";
			$nodeDetails=array();
			$nodeDetails['id']=$key;
			$nodeDetails['name']=$arrKolDetails[$key]['first_name']." ".$arrKolDetails[$key]['last_name'];
			$nodeDetails['data']=$nodeData;
			$arrAdjecencies=array();
			foreach($value as $row){
				
				//if the kol is not in the array of kol points. then skip the connection
				if (!array_key_exists($row['kol_id'], $arrData)) {
				    //$arrData[$row['kol_id']]=array();
				    continue;
				} 
				$adjecent=array();
				$adjecent['nodeTo']=$row['kol_id'];
				$adjecent['nodeFrom']=$key;
				$adjecentData=array();
				if($row['count'] > 30) $row['count']=30;
				$adjecentData['$lineWidth']=$row['count']/5;
				$adjecentData['auths']=$row['count'];
				$adjecent['data']=$adjecentData;
				$arrAdjecencies[]=$adjecent;

			}
			$nodeDetails['adjacencies']=$arrAdjecencies;
			$data[]=$nodeDetails;
		}
		
		echo json_encode($data);
		
	}
	
	/**
	 * Calculates the kol's influence among themseleves based on the filters provided 
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 11-07-11
	 */
	function filter_influence_data($isFirstTime=null){
		$arrFilterFields=array();
		$page=$this->input->post('page');
		$count=0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
		$searchType='';
		$keyword='';
		$name='';
		$arrPubDegrees=array();
		
		$arrCountries	=array();
		$arrSpecialties	=array();
		
		if($isFirstTime != null){
			$searchType=$this->input->post('search_type');
			$keyword=trim($this->session->userdata('keyword'));
			$arrFilterFields=$this->session->userdata('arrMapFilterFields');
			$arrPubDegrees=array('edu','org');
		}else{		
			$specialty		=	trim($this->input->post('specialty'));		
			$country		=	trim($this->input->post('country'));
			$state			=	trim($this->input->post('state'));
			$organization	=	trim($this->input->post('organization'));
			$education		=	trim($this->input->post('education'));
			$eventName		=	trim($this->input->post('event_name'));
			$listName		=	trim($this->input->post('list_name'));
			
			$arrPubDegrees	=	explode(",",$this->input->post('map_degrees'));
			
			$arrCountries	=	$this->input->post('countries');
			if($arrCountries!='')
				$arrCountries	=explode(",",$arrCountries);
			if($country!='')
				$arrCountries[]	=	$country;
				
			$arrStates	=	$this->input->post('states');
			if($arrStates!='')
				$arrStates	=explode(",",$arrStates);
			if($state!='')
				$arrStates[]	=	$state;
			//echo $specialty;
			$arrSpecialties	=	$this->input->post('specialties');
			if($arrSpecialties!='')
				$arrSpecialties	=explode(",",$arrSpecialties);
			if($specialty!=''){
				$arrSpecialties[]	=	$specialty;
			}
			$arrOrganizations	=	$this->input->post('organizations');
			if($arrOrganizations!='')
				$arrOrganizations	=explode(",",$arrOrganizations);
			if($organization!=''){
				$arrOrganizations[]	=	$organization;
			}
			
			$arrEducations	=	$this->input->post('educations');
			if($arrEducations!='')
				$arrEducations	=explode(",",$arrEducations);
			if($education!=''){
				$arrEducations[]	=	$education;
			}
			
			$arrEvents	=	$this->input->post('events');
			if($arrEvents!='')
				$arrEvents	=explode(",",$arrEvents);
			if($eventName!=''){
				$arrEvents[]	=	$eventName;
			}
			
			$arrLists	=	$this->input->post('lists');
			if($arrLists!='')
				$arrLists	=explode(",",$arrLists);
			if($listName!=''){
				if(stripos($listName, '(')){
					$arrListDetails=explode("(",$listName);
					$listName=trim($arrListDetails[0]);
					$categoryName=trim($arrListDetails[1],") ");
					$listName=$this->My_list_kol->getListName($listName,$categoryName);
				}
				$arrLists[]	=	$listName;
			}
			
			//Prepare array of filter fields, ehich will be used for querying
			$arrFilterFields['specialty']=$arrSpecialties;		
			$arrFilterFields['country']=$arrCountries;
			$arrFilterFields['state']=$arrStates;
			$arrFilterFields['organization']=$arrOrganizations;
			//$arrFilterFields['education']=$this->kol->getInstituteId($education);
			//$arrFilterFields['event_id']=$this->kol->getEventLookupId($eventName);
			$arrFilterFields['education']=$arrEducations;
			$arrFilterFields['event_id']=$arrEvents;
			$arrFilterFields['list_id']=$arrLists;
			$arrFilterFields['event_name']=$eventName;
		}
		$arrKolIds=array();
		//pr($arrFilterFields);
		$arrKeywords[0]=$name;
		$startTime=microtime(true);
		$arrKolDetailResult=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,false,null,$arrKolIds,true);
		//$arrKolDetailResult = $this->kol->getKolDetail();
		$timeTaken=microtime(true)-$startTime;
		//echo "Total time taken by query : ".$timeTaken."<br />";
		
		$arrKolDetails	=	array();
		$arrKolIds		=	array();
		foreach($arrKolDetailResult as $row){
			//echo $row['id']."";
			$row['first_name'] = str_replace(".", "", $row['first_name']);
			$row['last_name'] = str_replace(".", "", $row['last_name']);
			$row['middle_name'] = str_replace(".", "", $row['middle_name']);
			$arrKolDetails[$row['id']]=$row;
			$arrKolIds[]=$row['id'];
		}
		$this->session->set_userdata('arrMapFilterFields',$arrFilterFields);
		//pr($arrKolDetails);
		$arrData=array();
		$arrPubKols=array();
		$arrEventKols=array();
		$arrAffKols=array();
		$arrEduKols=array();
		$arrOrgKols=array();
		$arrTrialKols=array();
		
		/*if(in_array('pub',$arrPubDegrees))
			$arrPubResults=$this->pubmed->getCoAuthoredKols($arrKolIds);
		if(in_array('event',$arrPubDegrees))
			$arrEventResults=$this->kol->getCoEventedKols($arrKolIds);
		if(in_array('aff',$arrPubDegrees))
			$arrAffResults=$this->kol->getCoAffiliatedKols($arrKolIds);
				
		foreach($arrKolIds as $kolId){
			$arrPubKols=$arrPubResults[$kolId];
			$arrEventKols=$arrEventResults[$kolId];
			$arrAffKols=$arrAffResults[$kolId];
			$arrKols=$this->get_unique_kolids_with_weightages($arrPubKols,$arrEventKols,$arrAffKols);
			if(sizeof($arrKols)>0)
				$arrData[$kolId]=$arrKols;
		}*/
		$startTime=microtime(true);
		foreach($arrKolDetails as $kolDetails){
			//echo "KolId : ".$kolDetails['id']."<br>";
			if(in_array('pub',$arrPubDegrees))
				$arrPubKols=$this->pubmed->getCoAuthoredKols($kolDetails['id']);
			if(in_array('event',$arrPubDegrees))
				$arrEventKols=$this->kol->getCoEventedKols($kolDetails['id']);
			if(in_array('aff',$arrPubDegrees))
				$arrAffKols=$this->kol->getCoAffiliatedKols($kolDetails['id']);
			if(in_array('edu',$arrPubDegrees))
				$arrEduKols=$this->kol->getCoEducatedKols($kolDetails['id'],$arrFilterFields);
			if(in_array('org',$arrPubDegrees))
				$arrOrgKols=$this->kol->getCoOrganizedKols($kolDetails['id'],$arrFilterFields);
			if(in_array('trial',$arrPubDegrees))
				$arrTrialKols=$this->clinical_trial->getCoTrialledKols($kolDetails['id'],$arrFilterFields);
			$arrKols=$this->get_unique_kolids_with_weightages($arrPubKols,$arrEventKols,$arrAffKols,$arrEduKols,$arrOrgKols,$arrTrialKols);
			if(sizeof($arrKols)>0)
				$arrData[$kolDetails['id']]=$arrKols;
		}
		$timeTaken=microtime(true)-$startTime;
		//echo "Total time taken for getting categories data by query : ".$timeTaken."<br />";
		
		//Prepares the Json data as required by the TheJit Radial/ForeceDirected graph
		/*$nodeData=array();
		$nodeData['$color']="#2200C1";
		$nodeData['$color']="#555555";
		$nodeData['$type']="circle";
		$data=array();
		foreach($arrData as $key => $value){
			//echo "KolId : ".$key."<br>";
			$nodeDetails=array();
			$nodeDetails['id']=$key;
			$nodeDetails['name']=$arrKolDetails[$key]['first_name']." ".$arrKolDetails[$key]['last_name'];
			$nodeDetails['data']=$nodeData;
			$arrAdjecencies=array();
			foreach($value as $row){
				
				//if the kol is not in the array of kol points. then skip the connection
				if (!array_key_exists($row['kol_id'], $arrData)) {
				    //$arrData[$row['kol_id']]=array();
				    continue;
				} 
				$adjecent=array();
				$adjecent['nodeTo']=$row['kol_id'];
				$adjecent['nodeFrom']=$key;
				$adjecentData=array();
				if($row['count'] > 30) $row['count']=30;
				$adjecentData['$lineWidth']=$row['count']/5;
				$adjecentData['auths']=$row['count'];
				$adjecent['data']=$adjecentData;
				$arrAdjecencies[]=$adjecent;
				

			}
			$nodeDetails['adjacencies']=$arrAdjecencies;
			$data[]=$nodeDetails;
		}
		//echo "Total Kols :".sizeof($arrData);
		//pr($data);
		ob_start('ob_gzhandler');	*/

		$startTime=microtime(true);
		//Prepares the json data as rqured by the flare dependency graph
		$nodeData=array();
		$data=array();
		$arrConnectionsStrength = array();
		foreach($arrData as $key => $value){
			//Skip the kol if the kol don't have any connections
			if(sizeof($value) <= 0)
				countinue;
			//echo "KolId : ".$key."<br>";
			$nodeDetails=array();
			$nodeDetails['name']="kol.".$arrKolDetails[$key]['first_name']." ".$arrKolDetails[$key]['last_name'].".".$key;
			$nodeDetails['size']=sizeof($value);
			$nodeDetails['kolId']=$key;
			$arrAdjecencies=array();
			$arrConnectionsCounts = array();
			$arrConnections = array();
			foreach($value as $row){
				$connection = array();
				$connection['id'] = $row['kol_id'];
				$connection['count'] = $row['count'];
				$arrConnections[] = $connection;
				//if the kol is not in the array of kol points. then skip the connection
				if (!array_key_exists($row['kol_id'], $arrData)) {
				    //$arrData[$row['kol_id']]=array();
				    continue;
				} 
				$arrAdjecencies[]="kol.".$arrKolDetails[$row['kol_id']]['first_name']." ".$arrKolDetails[$row['kol_id']]['last_name'].".".$row['kol_id'];
			}
			
			$nodeDetails['imports']=$arrAdjecencies;
			//Skip the kol if all his connections are not in the list of matching kols
			if(sizeof($arrAdjecencies) > 0){
				$data[]=$nodeDetails;
				$arrConnectionsCounts['kolId'] = $key;
				$arrConnectionsCounts['connections'] = $arrConnections;
				$arrConnectionsStrength[] = $arrConnectionsCounts;
			}
		}
		//Looping once again to make more number of nodes for testing
		/*foreach($arrData as $key => $value){
			//echo "KolId : ".$key."<br>";
			$nodeDetails=array();
			$nodeDetails['name']="kol.".$arrKolDetails[$key]['first_name']." ".$arrKolDetails[$key]['last_name']."2";
			$nodeDetails['size']=$key;
			$arrAdjecencies=array();
			foreach($value as $row){
				
				//if the kol is not in the array of kol points. then skip the connection
				if (!array_key_exists($row['kol_id'], $arrData)) {
				    //$arrData[$row['kol_id']]=array();
				    continue;
				} 
				$arrAdjecencies[]="kol.".$arrKolDetails[$row['kol_id']]['first_name']." ".$arrKolDetails[$row['kol_id']]['last_name']."2";
			}
			$nodeDetails['imports']=$arrAdjecencies;
			$data[]=$nodeDetails;
		}*/
		
		$returnData[] = $data;
		$returnData[] = $arrConnectionsStrength;
		
		$timeTaken=microtime(true)-$startTime;
		//echo "Total time taken for preparing data : ".$timeTaken."<br />";
		
		$arrAllNodes = $returnData[0];
		foreach($arrAllNodes as $c=>$key) {
	        $sort_numcie[] = $key['size'];
	        $sort_ref[] = $key['name'];
	    }
		array_multisort($sort_numcie, SORT_DESC, $sort_ref, SORT_STRING, $arrAllNodes);
		$returnData[0] = $arrAllNodes;
		
		ob_start('ob_gzhandler');
		echo json_encode($returnData);
				
	}
	
	/**
	 * Gets the filter data for the influence map 
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 11-07-11
	 */
	function reload_influence_filters($isFirstTime=null){
		ini_set("max_execution_time",0);
		$arrOrganizations	= '';
		$arrEducations		= '';
		$arrEvents			= '';
		$arrLists			= '';
		$arrFilterFields=array();
		$page=$this->input->post('page');
		$count=0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
		$searchType='';
		$keyword='';
		$name='';
		$arrKeywords[0]=$name;
		
		$arrCountries	=array();
		$arrStates	=array();
		$arrSpecialties	=array();
		$arrCountries		= array();
		$arrStates			= array();
		$arrSpecialties		= array();
		$arrOrganizations	= array();
		$arrEducations		= array();
		$arrEvents			= array();
		$arrLists			= array();
		$arrOrganizations	= array();
			
		
		if($isFirstTime != null){
			$searchType=$this->input->post('search_type');
			$keyword=trim($this->session->userdata('keyword'));
			$arrFilterFields=$this->session->userdata('arrMapFilterFields');
			$arrPubDegrees=array('event','aff');
		}else{
			$specialty		=	trim($this->input->post('specialty'));		
			$country		=	trim($this->input->post('country'));
			$state			=	trim($this->input->post('state'));
			$organization	=	trim($this->input->post('organization'));
			$education		=	trim($this->input->post('education'));
			$eventName		=	trim($this->input->post('event_name'));
			$listName		=	trim($this->input->post('list_name'));
			
			$arrPubDegrees	=	explode(",",$this->input->post('map_degrees'));
			
			$arrCountries	=	$this->input->post('countries');
			if($arrCountries!='')
				$arrCountries	=explode(",",$arrCountries);
			if($country!='')
				$arrCountries[]	=	$country;
				
			$arrStates	=	$this->input->post('states');
			if($arrStates!='')
				$arrStates	=explode(",",$arrStates);
			if($state!='')
				$arrStates[]	=	$state;
				
			//echo $specialty;
			$arrSpecialties	=	$this->input->post('specialties');
			if($arrSpecialties!='')
				$arrSpecialties	=explode(",",$arrSpecialties);
			if($specialty!=''){
				$arrSpecialties[]	=	$specialty;
			}
			$arrOrganizations	=	$this->input->post('organizations');
			if($arrOrganizations!='')
				$arrOrganizations	=explode(",",$arrOrganizations);
			if($organization!=''){
				$arrOrganizations[]	=	$organization;
			}
			
			$arrEducations	=	$this->input->post('educations');
			if($arrEducations!='')
				$arrEducations	=explode(",",$arrEducations);
			if($education!=''){
				$arrEducations[]	=	$education;
			}
			
			$arrEvents	=	$this->input->post('events');
			if($arrEvents!='')
				$arrEvents	=explode(",",$arrEvents);
			if($eventName!=''){
				$arrEvents[]	=	$eventName;
			}
			
			$arrLists	=	$this->input->post('lists');
			if($arrLists!='')
				$arrLists	=explode(",",$arrLists);
			if($listName!=''){
				if(stripos($listName, '(')){
					$arrListDetails=explode("(",$listName);
					$listName=trim($arrListDetails[0]);
					$categoryName=trim($arrListDetails[1],") ");
					$listName=$this->My_list_kol->getListName($listName,$categoryName);
				}
				$arrLists[]	=	$listName;
			}
			
			//Prepare array of filter fields, ehich will be used for querying
			$arrFilterFields['specialty']=$arrSpecialties;		
			$arrFilterFields['country']=$arrCountries;
			$arrFilterFields['state']=$arrStates;
			$arrFilterFields['organization']=$arrOrganizations;
			//$arrFilterFields['education']=$this->kol->getInstituteId($education);
			//$arrFilterFields['event_id']=$this->kol->getEventLookupId($eventName);
			$arrFilterFields['education']=$arrEducations;
			$arrFilterFields['event_id']=$arrEvents;
			$arrFilterFields['list_id']=$arrLists;
			$arrFilterFields['event_name']=$eventName;
		}
		$arrKolIds=array();
		$arrKolDetailResult=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,false,null,$arrKolIds,true);
		//$arrKolDetailResult = $this->kol->getKolDetail();
		$arrKolDetails	=	array();
		foreach($arrKolDetailResult as $row){
			$arrKolDetails[$row['id']]=$row;
		}
		//pr($arrKolDetails);
		$this->session->set_userdata('arrMapFilterFields',$arrFilterFields);
		$arrData=array();
		$arrPubKols=array();
		$arrEventKols=array();
		$arrAffKols=array();
		foreach($arrKolDetails as $kolDetails){
			if(in_array('pub',$arrPubDegrees))
				$arrPubKols=$this->pubmed->getCoAuthoredKols($kolDetails['id'],$arrFilterFields);
			if(in_array('event',$arrPubDegrees))
				$arrEventKols=$this->kol->getCoEventedKols($kolDetails['id'],$arrFilterFields);
			if(in_array('aff',$arrPubDegrees))
				$arrAffKols=$this->kol->getCoAffiliatedKols($kolDetails['id'],$arrFilterFields);
			if(in_array('edu',$arrPubDegrees))
				$arrEduKols=$this->kol->getCoEducatedKols($kolDetails['id'],$arrFilterFields);
			if(in_array('org',$arrPubDegrees))
				$arrOrgKols=$this->kol->getCoOrganizedKols($kolDetails['id'],$arrFilterFields);
			if(in_array('trial',$arrPubDegrees))
				$arrTrialKols=$this->clinical_trial->getCoTrialledKols($kolDetails['id'],$arrFilterFields);
			if(sizeof($arrPubKols)>0 || sizeof($arrEventKols)>0 || sizeof($arrAffKols)>0 || sizeof($arrEduKols)>0 || sizeof($arrOrgKols)>0 || sizeof($arrTrialKols)>0)
				$arrData[$kolDetails['id']]="";
		}
		
		$arrKolIds=array_keys($arrData);
		
		//Get count of kols grouping by category(for each category)
		$arrKolsByCountryCount=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'country',$arrKolIds);
		$arrKolsByStateCount=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'state',$arrKolIds);
		$arrKolsBySpecialtyCount=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'specialty',$arrKolIds);
		$arrKolsByOrgCount=array();//$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'organization',$arrKolIds);
		$arrKolsByEduCount=array();//$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'education',$arrKolIds);
		$arrKolsByEventCount=array();//$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'event',$arrKolIds);
		$arrKolsByListCount=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'list',$arrKolIds);
		
		//Preparing the kols by category results as required by the filter page and aso getting the total count for category
		$allCountryCount=0;
		$assoArrKolsByCountryCount=array();
		foreach($arrKolsByCountryCount as $row){
			$assoArrKolsByCountryCount[$row['country']]=$row;
			$allCountryCount+=$row['count'];
		}
		$allStateCount=0;
		$assoArrKolsByStateCount=array();
		foreach($arrKolsByStateCount as $row){
			$assoArrKolsByStateCount[$row['state']]=$row;
			$allStateCount+=$row['count'];
		}
		$allSpecialtyCount=0;
		$assoArrKolsBySpecialtyCount=array();
		foreach($arrKolsBySpecialtyCount as $row){
			$assoArrKolsBySpecialtyCount[$row['specs']]=$row;
			$allSpecialtyCount+=$row['count'];
		}
		$allOrgCount=0;
		$assoArrKolsByOrgCount=array();
		foreach($arrKolsByOrgCount as $row){
			$assoArrKolsByOrgCount[$row['name']]=$row;
			$allOrgCount+=$row['count'];
		}
		$allEduCount=0;
		$assoArrKolsByEduCount=array();
		foreach($arrKolsByEduCount as $row){
			$assoArrKolsByEduCount[$row['institute_name']]=$row;
			$allEduCount+=$row['count'];
		}
		$allEventCount=0;
		$assoArrKolsByEventCount=array();
		foreach($arrKolsByEventCount as $row){
			$assoArrKolsByEventCount[$row['event_name']]=$row;
			$allEventCount+=$row['count'];
		}
		$allListCount=0;
		$assoArrKolsByListCount=array();
		foreach($arrKolsByListCount as $row){
			$assoArrKolsByListCount[$row['list_name_id']]=$row;
			$allListCount+=$row['count'];
		}
		
		//Setting all the required data and forwording in to respective page
		$filterData['allCountryCount']=$allCountryCount;
		$filterData['allStateCount']=$allStateCount;
		$filterData['allSpecialtyCount']=$allSpecialtyCount;
		$filterData['allOrgCount']=$allOrgCount;
		$filterData['allEduCount']=$allEduCount;
		$filterData['allEventCount']=$allEventCount;
		$filterData['allListCount']=$allListCount;
		
		$filterData['arrKolsByCountryCount']=$assoArrKolsByCountryCount;
		$filterData['arrKolsByStateCount']=$assoArrKolsByStateCount;
		$filterData['arrKolsBySpecialtyCount']=$assoArrKolsBySpecialtyCount;
		$filterData['arrKolsByOrgCount']=$assoArrKolsByOrgCount;
		$filterData['arrKolsByEduCount']=$assoArrKolsByEduCount;
		$filterData['arrKolsByEventCount']=$assoArrKolsByEventCount;
		$filterData['arrKolsByListCount']=$assoArrKolsByListCount;
		
		
		$filterData['selectedCountries']=$arrCountries;
		$filterData['selectedStates']=$arrStates;
		$filterData['selectedSpecialties']=$arrSpecialties;
		$filterData['selectedOrgs']=$arrOrganizations;
		$filterData['selectedEdus']=$arrEducations;
		$filterData['selectedEvents']=$arrEvents;
		$filterData['selectedLists']=$arrLists;
		$filterData['mapSection']='';
		$this->load->view('search/kol_filters_li_style',$filterData);
	}
	
	/**
	 * Loop trought all the array and prpares a array of unique kolId's with combined weightges
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 11-07-11
	 */
	function get_unique_kolids_with_weightages($arrPubKols,$arrEventKols,$arrAffKols,$arrEduKols,$arrOrgKols,$arrTrialKols){
		$arrKols=array();
		if(sizeof($arrPubKols) > 0){
			foreach($arrPubKols as $row){
				$arrKols[$row['kol_id']]=$row;
			}
		}
		
		if(sizeof($arrEventKols) > 0){
			foreach($arrEventKols as $row){
				if (array_key_exists($row['kol_id'], $arrKols)) {
				    $arrKols[$row['kol_id']]['count']=(int)$arrKols[$row['kol_id']]['count']+(int)$row['count'];
				} else{
					$arrKols[$row['kol_id']]=$row;
				}
			}
		}
		
		if(sizeof($arrAffKols) > 0){
			foreach($arrAffKols as $row){
				if (array_key_exists($row['kol_id'], $arrKols)) {
				    $arrKols[$row['kol_id']]['count']=(int)$arrKols[$row['kol_id']]['count']+(int)$row['count'];
				} else{
					$arrKols[$row['kol_id']]=$row;
				}
			}
		}
		if(sizeof($arrOrgKols) > 0){
			foreach($arrOrgKols as $row){
				if (array_key_exists($row['kol_id'], $arrKols)) {
				    $arrKols[$row['kol_id']]['count']=(int)$arrKols[$row['kol_id']]['count']+(int)$row['count'];
				} else{
					$arrKols[$row['kol_id']]=$row;
				}
			}
		}
		if(sizeof($arrEduKols) > 0){
			foreach($arrEduKols as $row){
				if (array_key_exists($row['kol_id'], $arrKols)) {
				    $arrKols[$row['kol_id']]['count']=(int)$arrKols[$row['kol_id']]['count']+(int)$row['count'];
				} else{
					$arrKols[$row['kol_id']]=$row;
				}
			}
		}
		if(sizeof($arrTrialKols) > 0){
			foreach($arrTrialKols as $row){
				if (array_key_exists($row['kol_id'], $arrKols)) {
				    $arrKols[$row['kol_id']]['count']=(int)$arrKols[$row['kol_id']]['count']+(int)$row['count'];
				} else{
					$arrKols[$row['kol_id']]=$row;
				}
			}
		}
		
		return $arrKols;
	}

	/**
	 * Calculates a given kol influence with other co-autheras and influence amoung the co-authars of the kol
	 * @author 	Ramesh B
	 * @since	
	 * @return JSON
	 * @created 11-07-11
	 */
	function get_kol_influence_data($kolId=null){
		
		$arrFilterFields=array();
		$page=$this->input->post('page');
		$count=0;
		$limit=0;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
		$searchType='';
		$keyword='';
		$name='';
		$arrPubDegrees	=	explode(",",$this->input->post('map_degrees'));
	
		$kolName		= $this->input->post('influence_kol_name');
		
		if($kolId == null){
			//$value1=str_replace(" ","",$kolName);
			$kolId=$this->kol->getKolId($kolName);
		}
		
		$arrKolIds=array();
		$arrKeywords[0]=$name;
		$arrKolDetailResult=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,false,null,$arrKolIds,true);
		
		$arrKolDetails	=	array();
		$arrMicroviewDetails = array();
		foreach($arrKolDetailResult as $row){
			/*$details['first_name']=trim($row['first_name'],'.');
			$details['last_name']=trim($row['last_name'],'.');*/
			$row['first_name'] = str_replace(".", "", $row['first_name']);
			$row['middle_name'] = str_replace(".", "", $row['middle_name']);
			$row['last_name'] = str_replace(".", "", $row['last_name']);
			$arrKolDetails[$row['id']]=$row;
			
			$mvDetail = array();
			$mvDetail['id'] = $row['id'];
			$mvDetail['on'] = $row['name'];
			$mvDetail['pi'] = $row['profile_image'];
			$arrMicroviewDetails[]=  $mvDetail;
		}
		
		//pr($arrKolDetails);
		$arrData=array();
		$arrPubKols=array();
		$arrEventKols=array();
		$arrAffKols=array();
		$arrEduKols=array();
		$arrOrgKols=array();
		$arrTrialKols=array();
				
		if(in_array('pub',$arrPubDegrees))
			$arrPubKols=$this->pubmed->getCoAuthoredKols($kolId);
		if(in_array('event',$arrPubDegrees))
			$arrEventKols=$this->kol->getCoEventedKols($kolId);
		if(in_array('aff',$arrPubDegrees))
			$arrAffKols=$this->kol->getCoAffiliatedKols($kolId);
		if(in_array('edu',$arrPubDegrees))
			$arrEduKols=$this->kol->getCoEducatedKols($kolId,$arrFilterFields);
		if(in_array('org',$arrPubDegrees))
			$arrOrgKols=$this->kol->getCoOrganizedKols($kolId,$arrFilterFields);
		if(in_array('trial',$arrPubDegrees))
			$arrTrialKols=$this->clinical_trial->getCoTrialledKols($kolId,$arrFilterFields);
		$arrKols=$this->get_unique_kolids_with_weightages($arrPubKols,$arrEventKols,$arrAffKols,$arrEduKols,$arrOrgKols,$arrTrialKols);
		if(sizeof($arrKols)>0){
			$arrData[$kolId]=$arrKols;
			foreach($arrKols as $row){
				$arrDetails=array();
				$arrDetails[$row['kol_id']]['kol_id']=$kolId;
				$arrDetails[$row['kol_id']]['count']=$row['count'];
			    $arrData[$row['kol_id']]=$arrDetails;
			}
		}
		
		//pr($arrData);
		/*$nodeData=array();
		$nodeData['$color']="#2200C1";
		$nodeData['$color']="#555555";
		$nodeData['$type']="circle";
		$data=array();
		foreach($arrData as $key => $value){
			$nodeDetails=array();
			$nodeDetails['id']=$key;
			if (array_key_exists($key, $arrKolDetails)) {
				$nodeDetails['name']=$arrKolDetails[$key]['first_name']." ".$arrKolDetails[$key]['last_name'];
			} 
			else
				$nodeDetails['name']="";
			$nodeDetails['data']=$nodeData;
			$arrAdjecencies=array();
			foreach($value as $row){				
				$adjecent=array();
				$adjecent['nodeTo']=$row['kol_id'];
				$adjecent['nodeFrom']=$key;
				$adjecentData=array();
				if($row['count'] > 30) $row['count']=30;
				$adjecentData['$lineWidth']=$row['count']/5;
				$adjecentData['auths']=$row['count'];
				$adjecent['data']=$adjecentData;
				$arrAdjecencies[]=$adjecent;
				
				if (!array_key_exists($row['kol_id'], $arrData)) {
					$arrDetails=array();
					$arrDetails['kol_id']=$key;
					$arrDetails['count']=$row['count'];
				    $arrData[$row['kol_id']]=$arrDetails;
				} 
			}
			$nodeDetails['adjacencies']=$arrAdjecencies;
			$data[]=$nodeDetails;
		}*/
		$nodeData=array();
		$data=array();
		$arrConnectionsStrength = array();
		foreach($arrData as $key => $value){
			//Skip the kol if the kol don't have any connections
			if(sizeof($value) <= 0)
				countinue;
			//echo "KolId : ".$key."<br>";
			$nodeDetails=array();
//			$nodeDetails['name']="kol.".$arrKolDetails[$key]['first_name']." ".$arrKolDetails[$key]['last_name'].".".$key;
			$nodeDetails['name']="kol.".$this->common_helpers->get_name_format($arrKolDetails[$key]['first_name'],$arrKolDetails[$key]['middle_name'],$arrKolDetails[$key]['last_name']).".".$key;
			$nodeDetails['size']=sizeof($value);;
			$nodeDetails['kolId']=$key;
			$arrAdjecencies=array();
			$arrConnections=array();
			foreach($value as $row){
				$connection = array();
				$connection['id'] = $row['kol_id'];
				$connection['count'] = $row['count'];
				$arrConnections[] = $connection;
				
				//if the kol is not in the array of kol points. then skip the connection
				if (!array_key_exists($row['kol_id'], $arrData)) {
				    //$arrData[$row['kol_id']]=array();
				    continue;
				} 
//				$arrAdjecencies[]="kol.".$arrKolDetails[$row['kol_id']]['first_name']." ".$arrKolDetails[$row['kol_id']]['last_name'].".".$row['kol_id'];
				$arrAdjecencies[]="kol.".$this->common_helpers->get_name_format($arrKolDetails[$row['kol_id']]['first_name'],$arrKolDetails[$row['kol_id']]['middle_name'],$arrKolDetails[$row['kol_id']]['last_name']).".".$row['kol_id'];
			}
			$nodeDetails['imports']=$arrAdjecencies;
			//Skip the kol if all his connections are not in the list of matching kols
			if(sizeof($arrAdjecencies) > 0){
				$data[]=$nodeDetails;
				$arrConnectionsCounts['kolId'] = $key;
				$arrConnectionsCounts['connections'] = $arrConnections;
				$arrConnectionsStrength[] = $arrConnectionsCounts;
			}
		}
		
		//echo json_encode($data);
		$returnData['influenceData']=$data;
		$returnData['connetionsCount'] = $arrConnectionsStrength;
		$returnData['mvDetails'] = $arrMicroviewDetails;
		$returnData['kolId']=$kolId;
//		$returnData['kolName'] = $arrKolDetails[$kolId]['first_name']." ".$arrKolDetails[$kolId]['last_name'];
		$returnData['kolName'] = $this->common_helpers->get_name_format($arrKolDetails[$kolId]['first_name'],$arrKolDetails[$kolId]['middle_name'],$arrKolDetails[$kolId]['last_name']);
		ob_start('ob_gzhandler');
		echo json_encode($returnData);
	}
	
	
	/**
	 * Calculates a given kol influence with other co-autheras and influence amoung the co-authars of the kol
	 * @author 	Ramesh B
	 * @since	
	 * @return JSON
	 * @created 11-07-11
	 */	
	function get_kol_coauthors_influence_data($kolIdPassed=null){
		ini_set("memory_limit","200M");
		$fromYear=0;
		$toYear=0;
		$kolId = $kolIdPassed;
		if($kolId == null){
			$kolName		= $this->input->post('influence_kol_name');
			//$value1=str_replace(" ","",$kolName);
			$kolId=$this->kol->getKolId($kolName);
		}
		
		$kolName = $this->kol->getKolName($kolId);
		
		//Get co authors having affiliation info
		$arrCoAuthorsHavingAffiliation = $this->pubmed->getKolCoAuthorsHavingAffiliation($kolId);
		$arrCoAuthorsHavingAffAll = array();
		foreach($arrCoAuthorsHavingAffiliation as $id => $aliasId){
			$arrCoAuthsIds = array($id);
			$matchingAuths=$this->pubmed->getMatchingCoAuthorIds($arrCoAuthsIds,$kolId);
			$arrCoAuthorsHavingAffAll = array_merge($arrCoAuthorsHavingAffAll, $matchingAuths);
			
			if($aliasId == null)
				$aliasId = $id;
			$aliasIdReferences = $this->pubmed->getAliasIdReferences($aliasId);
			$arrCoAuthorsHavingAffAll = array_merge($arrCoAuthorsHavingAffAll, $aliasIdReferences);
		}
		$arrCoAuthorsHavingAffiliation = $arrCoAuthorsHavingAffAll;
		
		//Get all the co authors for given kol
		$arrKolCoAuthors=$this->kol->getKolCoAuthFreqency($kolId, $fromYear, $toYear,$kolName,true,'');
		
		//Get all the kol who are co-authors for given kol publications
		$arrPubKols=$this->pubmed->getCoAuthoredKols($kolId);
		//pr($arrPubKols);
		$arrKolNames=array();
		foreach($arrPubKols as $row){
			$arrKolName = $this->kol->getKolName($row['kol_id']);
			$arrNameCombinations=$this->pubmed->generate_name_combinations($arrKolName['first_name'], $arrKolName['middle_name'], $arrKolName['last_name']);
			foreach($arrNameCombinations as $name){
				$arrKolNames[$name]=$row['kol_id'];
			}
		}
		
		$arrData=array();
		foreach($arrKolCoAuthors as $koAuthDetails){
			$arrCoAuthInfluence=$this->pubmed->getCoAuthoredCoAuthors($kolId,$koAuthDetails);
			$arrData[$koAuthDetails['id']]=$arrCoAuthInfluence;
		}
		//pr($arrData);
		//$arrData=$arrKolCoAuthors;
		/*$nodeData=array();
		$nodeData['$color']="#83548B";
		$nodeData['$type']="circle";
		$data=array();
		foreach($arrData as $key => $value){
			//echo "KolId : ".$key."<br>";
			$nodeDetails=array();
			$nodeDetails['id']=$key;
			$nodeDetails['name']=$arrKolCoAuthors[$key]['last_name']." ".$arrKolCoAuthors[$key]['initials'];
			$nodeDetails['data']=$nodeData;
			$arrAdjecencies=array();
			foreach($value as $row){
				
				//if the kol is not in the array of kol points. then skip the connection
				if (!array_key_exists($row['id'], $arrData)) {
				    //$arrData[$row['kol_id']]=array();
				    continue;
				} 
				$adjecent=array();
				$adjecent['nodeTo']=$row['id'];
				$adjecent['nodeFrom']=$key;
				$adjecentData=array();
				if($row['count'] > 30) $row['count']=30;
				$adjecentData['$lineWidth']=$row['count']/5;
				$adjecentData['auths']=$row['count'];
				$adjecent['data']=$adjecentData;
				$arrAdjecencies[]=$adjecent;
				

			}
			$nodeDetails['adjacencies']=$arrAdjecencies;
			$data[]=$nodeDetails;
		}*/
		
		$arrConnectionsStrength = array();
		$nodeData=array();
		$data=array();
		$affData = array();
		$parentNode=array();
		$parentNode['name']="kol.".$kolName['first_name']." ".$kolName['middle_name']." ".$kolName['last_name'].".".$kolId;
		$parentNode['size']=sizeof($arrData);
		$parentNode['totalconn']=sizeof($arrData);
		$parentNode['kolId']=$kolId;
		$arrParentAdjecencies=array();
		$arrParentAffAdjecencies=array();
		foreach($arrData as $key => $value){
			//echo "KolId : ".$key."<br>";
			$authorName = '';
			//based on the name avilability, construct a proper name
			if($arrKolCoAuthors[$key]['last_name']!='' && $arrKolCoAuthors[$key]['fore_name']!='')
				$authorName =$arrKolCoAuthors[$key]['last_name']." ".$arrKolCoAuthors[$key]['fore_name'];
			else if($arrKolCoAuthors[$key]['fore_name']=='')
				$authorName =$arrKolCoAuthors[$key]['last_name']." ".$arrKolCoAuthors[$key]['initials'];
			else if($arrKolCoAuthors[$key]['last_name']=='')
				$authorName =$arrKolCoAuthors[$key]['fore_name']." ".$arrKolCoAuthors[$key]['initials'];
				
			$nodeDetails=array();
			$arrParentAdjecencies[]="kol.".$authorName.".".$key;
			if(in_array($key, $arrCoAuthorsHavingAffiliation))
				$arrParentAffAdjecencies[]="kol.".$authorName.".".$key;
			$nodeDetails['name']="kol.".$authorName.".".$key;
			$nodeDetails['size']=$arrKolCoAuthors[$key]['count'];
			$nodeDetails['totalconn']=sizeof($value);
			$nodeDetails['kolId']=0;
			if (array_key_exists($authorName,$arrKolNames)) {
			  	$nodeDetails['kolId']=$arrKolNames[$authorName];
			  	//pr($nodeDetails);
			 }
			$arrAdjecencies=array();
			$arrAffAdjecencies=array();
			$arrConnectionsCounts = array();
			$arrConnections = array();
			foreach($value as $row){
				$authorName = '';
				//based on the name avilability, construct a proper name
				if($arrKolCoAuthors[$row['id']]['last_name']!='' && $arrKolCoAuthors[$row['id']]['fore_name']!='')
					$authorName =$arrKolCoAuthors[$row['id']]['last_name']." ".$arrKolCoAuthors[$row['id']]['fore_name'];
				else if($arrKolCoAuthors[$row['id']]['fore_name']=='')
					$authorName =$arrKolCoAuthors[$row['id']]['last_name']." ".$arrKolCoAuthors[$row['id']]['initials'];
				else if($arrKolCoAuthors[$row['id']]['last_name']=='')
					$authorName =$arrKolCoAuthors[$row['id']]['fore_name']." ".$arrKolCoAuthors[$row['id']]['initials'];
				
				$connection = array();
				$connection['id'] = $row['id'];
				$connection['count'] = $row['count'];
				$arrConnections[] = $connection;
				//if the kol is not in the array of kol points. then skip the connection
				if (!array_key_exists($row['id'], $arrData)) {
				    //$arrData[$row['kol_id']]=array();
				    continue;
				} 
				$arrAdjecencies[]="kol.".$authorName.".".$row['id'];
				if(in_array($row['id'], $arrCoAuthorsHavingAffiliation))
					$arrAffAdjecencies[] = "kol.".$authorName.".".$row['id'];
			}
			$nodeDetails['imports']=$arrAdjecencies;
			$data[]=$nodeDetails;
			if(in_array($key, $arrCoAuthorsHavingAffiliation)){
				$nodeDetails['imports']=$arrAffAdjecencies;
				$affData[] = $nodeDetails;
			}
			$arrConnectionsCounts['kolId'] = $key;
			$arrConnectionsCounts['connections'] = $arrConnections;
			$arrConnectionsStrength[] = $arrConnectionsCounts;
		}
		$parentNode['imports']=$arrParentAdjecencies;
		array_unshift($data, $parentNode);
		
		$affParentNode = $parentNode;
		$affParentNode['imports']=$arrParentAffAdjecencies;
		array_unshift($affData, $affParentNode);
		
		if($kolIdPassed == null){
			$returnData['influenceData']=$data;
			$returnData['kolId']=$kolId;
			ob_start('ob_gzhandler');
			echo json_encode($returnData);
		}
		else{
			$returnData[] = $data;
			$returnData[] = $arrConnectionsStrength;
			$returnData[] = $affData;
			ob_start('ob_gzhandler');
			echo json_encode($returnData);
		}
			
	}
	
	function isCoAuthorHavingAff($key, $arrCoAuthorsHavingAffiliation,$kolId){
		$arrCoAuthsIds = array($key);
		$matchingAuths=$this->pubmed->getMatchingCoAuthorIds($arrCoAuthsIds,$kolId);
		$authExist = false;
		foreach ($matchingAuths as $key1 => $value){
			if(in_array($key1, $arrCoAuthorsHavingAffiliation)){
				$authExist = true;
			}
		}
		
		return $authExist;
	}
	
	/**
	 * Calculates the kol's influence among themseleves based on the filters provided 
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 11-07-11
	 */
	function filter_influence_data_flex(){
		$arrFilterFields=array();
		$page=$this->input->post('page');
		$count=0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
		$searchType='';
		$keyword='';
		$name='';
		$arrPubDegrees=array();
		
		$arrCountries	=array();
		$arrSpecialties	=array();
		$arrPubDegrees=array('edu','org');
		
		if($isFirstTime != null){
			$searchType=$this->input->post('search_type');
			$keyword=trim($this->session->userdata('keyword'));
			$arrFilterFields=$this->session->userdata('arrMapFilterFields');
			$arrPubDegrees=array('edu','org');
		}else{		
			$specialty		=	trim($this->input->post('specialty'));		
			$country		=	trim($this->input->post('country'));
			$organization	=	trim($this->input->post('organization'));
			$education		=	trim($this->input->post('education'));
			$eventName		=	trim($this->input->post('event_name'));
			$listName		=	trim($this->input->post('list_name'));
			
			//$arrPubDegrees	=	explode(",",$this->input->post('map_degrees'));
			
			$arrCountries	=	$this->input->post('countries');
			if($arrCountries!='')
				$arrCountries	=explode(",",$arrCountries);
			if($country!='')
				$arrCountries[]	=	$country;
			//echo $specialty;
			$arrSpecialties	=	$this->input->post('specialties');
			if($arrSpecialties!='')
				$arrSpecialties	=explode(",",$arrSpecialties);
			if($specialty!=''){
				$arrSpecialties[]	=	$specialty;
			}
			$arrOrganizations	=	$this->input->post('organizations');
			if($arrOrganizations!='')
				$arrOrganizations	=explode(",",$arrOrganizations);
			if($organization!=''){
				$arrOrganizations[]	=	$organization;
			}
			
			$arrEducations	=	$this->input->post('educations');
			if($arrEducations!='')
				$arrEducations	=explode(",",$arrEducations);
			if($education!=''){
				$arrEducations[]	=	$education;
			}
			
			$arrEvents	=	$this->input->post('events');
			if($arrEvents!='')
				$arrEvents	=explode(",",$arrEvents);
			if($eventName!=''){
				$arrEvents[]	=	$eventName;
			}
			
			$arrLists	=	$this->input->post('lists');
			if($arrLists!='')
				$arrLists	=explode(",",$arrLists);
			if($listName!=''){
				if(stripos($listName, '(')){
					$arrListDetails=explode("(",$listName);
					$listName=trim($arrListDetails[0]);
					$categoryName=trim($arrListDetails[1],") ");
					$listName=$this->My_list_kol->getListName($listName,$categoryName);
				}
				$arrLists[]	=	$listName;
			}
			
			//Prepare array of filter fields, ehich will be used for querying
			$arrFilterFields['specialty']=array();		
			$arrFilterFields['country']=array();
			$arrFilterFields['organization']=array();
			//$arrFilterFields['education']=$this->kol->getInstituteId($education);
			//$arrFilterFields['event_id']=$this->kol->getEventLookupId($eventName);
			$arrFilterFields['education']=array();
			$arrFilterFields['event_id']=array();
			$arrFilterFields['list_id']=array();
			$arrFilterFields['event_name']=array();
		}
		$arrKolIds=array();
		//pr($arrFilterFields);
		$arrKeywords[0]=$name;
		$arrKolDetailResult=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,false,null,$arrKolIds,true);
		//$arrKolDetailResult = $this->kol->getKolDetail();
		$arrKolDetails	=	array();
		$arrKolIds		=	array();
		foreach($arrKolDetailResult as $row){
			//echo $row['id']."";
			$arrKolDetails[$row['id']]=$row;
			$arrKolIds[]=$row['id'];
		}
		$this->session->set_userdata('arrMapFilterFields',$arrFilterFields);
		//pr($arrKolDetails);
		$arrData=array();
		$arrPubKols=array();
		$arrEventKols=array();
		$arrAffKols=array();
		$arrEduKols=array();
		$arrOrgKols=array();
		$arrTrialKols=array();
		
		/*if(in_array('pub',$arrPubDegrees))
			$arrPubResults=$this->pubmed->getCoAuthoredKols($arrKolIds);
		if(in_array('event',$arrPubDegrees))
			$arrEventResults=$this->kol->getCoEventedKols($arrKolIds);
		if(in_array('aff',$arrPubDegrees))
			$arrAffResults=$this->kol->getCoAffiliatedKols($arrKolIds);
				
		foreach($arrKolIds as $kolId){
			$arrPubKols=$arrPubResults[$kolId];
			$arrEventKols=$arrEventResults[$kolId];
			$arrAffKols=$arrAffResults[$kolId];
			$arrKols=$this->get_unique_kolids_with_weightages($arrPubKols,$arrEventKols,$arrAffKols);
			if(sizeof($arrKols)>0)
				$arrData[$kolId]=$arrKols;
		}*/
		foreach($arrKolDetails as $kolDetails){
			//echo "KolId : ".$kolDetails['id']."<br>";
			if(in_array('pub',$arrPubDegrees))
				$arrPubKols=$this->pubmed->getCoAuthoredKols($kolDetails['id']);
			if(in_array('event',$arrPubDegrees))
				$arrEventKols=$this->kol->getCoEventedKols($kolDetails['id']);
			if(in_array('aff',$arrPubDegrees))
				$arrAffKols=$this->kol->getCoAffiliatedKols($kolDetails['id']);
			if(in_array('edu',$arrPubDegrees))
				$arrEduKols=$this->kol->getCoEducatedKols($kolDetails['id'],$arrFilterFields);
			if(in_array('org',$arrPubDegrees))
				$arrOrgKols=$this->kol->getCoOrganizedKols($kolDetails['id'],$arrFilterFields);
			if(in_array('trial',$arrPubDegrees))
				$arrTrialKols=$this->clinical_trial->getCoTrialledKols($kolDetails['id'],$arrFilterFields);
			$arrKols=$this->get_unique_kolids_with_weightages($arrPubKols,$arrEventKols,$arrAffKols,$arrEduKols,$arrOrgKols,$arrTrialKols);
			if(sizeof($arrKols)>0)
				$arrData[$kolDetails['id']]=$arrKols;
		}
		
		//Prepares the Json data as required by the TheJit Radial/ForeceDirected graph
		/*$nodeData=array();
		$nodeData['$color']="#2200C1";
		$nodeData['$color']="#555555";
		$nodeData['$type']="circle";
		$data=array();
		foreach($arrData as $key => $value){
			//echo "KolId : ".$key."<br>";
			$nodeDetails=array();
			$nodeDetails['id']=$key;
			$nodeDetails['name']=$arrKolDetails[$key]['first_name']." ".$arrKolDetails[$key]['last_name'];
			$nodeDetails['data']=$nodeData;
			$arrAdjecencies=array();
			foreach($value as $row){
				
				//if the kol is not in the array of kol points. then skip the connection
				if (!array_key_exists($row['kol_id'], $arrData)) {
				    //$arrData[$row['kol_id']]=array();
				    continue;
				} 
				$adjecent=array();
				$adjecent['nodeTo']=$row['kol_id'];
				$adjecent['nodeFrom']=$key;
				$adjecentData=array();
				if($row['count'] > 30) $row['count']=30;
				$adjecentData['$lineWidth']=$row['count']/5;
				$adjecentData['auths']=$row['count'];
				$adjecent['data']=$adjecentData;
				$arrAdjecencies[]=$adjecent;
				

			}
			$nodeDetails['adjacencies']=$arrAdjecencies;
			$data[]=$nodeDetails;
		}
		//echo "Total Kols :".sizeof($arrData);
		//pr($data);
		ob_start('ob_gzhandler');	*/

		//Prepares the json data as rqured by the flare dependency graph
		$nodeData=array();
		$data=array();
		foreach($arrData as $key => $value){
			//echo "KolId : ".$key."<br>";
			$nodeDetails=array();
			$nodeDetails['name']="kol.".$arrKolDetails[$key]['first_name']." ".$arrKolDetails[$key]['last_name'].".".$key;
			$nodeDetails['size']=sizeof($value);
			$nodeDetails['otoConnections']=$value['count'];
			$nodeDetails['kolId']=$key;
			$arrAdjecencies=array();
			foreach($value as $row){
				
				//if the kol is not in the array of kol points. then skip the connection
				if (!array_key_exists($row['kol_id'], $arrData)) {
				    //$arrData[$row['kol_id']]=array();
				    continue;
				} 
				$arrAdjecencies[]="kol.".$arrKolDetails[$row['kol_id']]['first_name']." ".$arrKolDetails[$row['kol_id']]['last_name'].".".$row['kol_id'];
			}
			$nodeDetails['imports']=$arrAdjecencies;
			$data[]=$nodeDetails;
		}
		ob_start('ob_gzhandler');
		echo json_encode($data);
	}
	
	function load_kols_influence_json_data_file(){
		$this->load->view("kol.influence.json.data.txt");
	}
	
	function view_influence_map($kolId = null){
		$filterData=array();
		$filterData['allSpecialtyCount']= 1;
		$filterData['allCountryCount']	= 1;
		$filterData['allStateCount']	= 1;
		$filterData['allListCount']		= 1;
		$filterData['allOrgCount']		= 1;
		$filterData['allEduCount']		= 1;
		$filterData['allEventCount']	= 1;
		$filterData['arrKolsBySpecialtyCount']	= array();
		$filterData['arrKolsByCountryCount']	= array();
		$filterData['arrKolsByStateCount']		= array();
		$filterData['arrKolsByListCount']		= array();
		$filterData['arrKolsByOrgCount']		= array();
		$filterData['arrKolsByEduCount']		= array();
		$data['mapSection']						= '';
		$data['filterPage']						= 'search/kol_filters_li_style';
		$data['filterData']						= $filterData;
		$this->load->model('survey');
		$data['arrCompletedSurveys']	= $this->survey->getCompletedSurveys();
		$data['contentPage']					= 'maps/thejit_influence_map';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited view influence network map Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "Viewed influence network map Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/client_view',$data);
	}
	
	function thejit_filter_influence_data($isFirstTime=null){
		$arrFilterFields=array();
		$page=$this->input->post('page');
		$count=0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
		$searchType='';
		$keyword='';
		$name='';
		$arrPubDegrees=array();
		
		$arrCountries	=array();
		$arrStates	=array();
		$arrSpecialties	=array();
		
		if($isFirstTime != null){
			$searchType=$this->input->post('search_type');
			$keyword=trim($this->session->userdata('keyword'));
			$arrFilterFields=$this->session->userdata('arrMapFilterFields');
			$arrPubDegrees=array('edu','org');
		}else{		
			$specialty		=	trim($this->input->post('specialty'));		
			$country		=	trim($this->input->post('country'));
			$state			=	trim($this->input->post('state'));
			$organization	=	trim($this->input->post('organization'));
			$education		=	trim($this->input->post('education'));
			$eventName		=	trim($this->input->post('event_name'));
			$listName		=	trim($this->input->post('list_name'));
			
			$arrPubDegrees	=	explode(",",$this->input->post('map_degrees'));
			
			$arrCountries	=	$this->input->post('countries');
			if($arrCountries!='')
				$arrCountries	=explode(",",$arrCountries);
			if($country!='')
				$arrCountries[]	=	$country;
			$arrStates	=	$this->input->post('states');
			if($arrStates!='')
				$arrStates	=explode(",",$arrStates);
			if($state!='')
				$arrStates[]	=	$state;
				
			//echo $specialty;
			$arrSpecialties	=	$this->input->post('specialties');
			if($arrSpecialties!='')
				$arrSpecialties	=explode(",",$arrSpecialties);
			if($specialty!=''){
				$arrSpecialties[]	=	$specialty;
			}
			$arrOrganizations	=	$this->input->post('organizations');
			if($arrOrganizations!='')
				$arrOrganizations	=explode(",",$arrOrganizations);
			if($organization!=''){
				$arrOrganizations[]	=	$organization;
			}
			
			$arrEducations	=	$this->input->post('educations');
			if($arrEducations!='')
				$arrEducations	=explode(",",$arrEducations);
			if($education!=''){
				$arrEducations[]	=	$education;
			}
			
			$arrEvents	=	$this->input->post('events');
			if($arrEvents!='')
				$arrEvents	=explode(",",$arrEvents);
			if($eventName!=''){
				$arrEvents[]	=	$eventName;
			}
			
			$arrLists	=	$this->input->post('lists');
			if($arrLists!='')
				$arrLists	=explode(",",$arrLists);
			if($listName!=''){
				if(stripos($listName, '(')){
					$arrListDetails=explode("(",$listName);
					$listName=trim($arrListDetails[0]);
					$categoryName=trim($arrListDetails[1],") ");
					$listName=$this->My_list_kol->getListName($listName,$categoryName);
				}
				$arrLists[]	=	$listName;
			}
			
			//Prepare array of filter fields, ehich will be used for querying
			$arrFilterFields['specialty']=$arrSpecialties;		
			$arrFilterFields['country']=$arrCountries;
			$arrFilterFields['state']=$arrStates;
			$arrFilterFields['organization']=$arrOrganizations;
			//$arrFilterFields['education']=$this->kol->getInstituteId($education);
			//$arrFilterFields['event_id']=$this->kol->getEventLookupId($eventName);
			$arrFilterFields['education']=$arrEducations;
			$arrFilterFields['event_id']=$arrEvents;
			$arrFilterFields['list_id']=$arrLists;
			$arrFilterFields['event_name']=$eventName;
		}
		$arrKolIds=array();
		//pr($arrFilterFields);
		$arrKeywords[0]=$name;
		$arrKolDetailResult=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,false,null,$arrKolIds,true);
		//$arrKolDetailResult = $this->kol->getKolDetail();
		$arrKolDetails	=	array();
		$arrKolIds		=	array();
		foreach($arrKolDetailResult as $row){
			//echo $row['id']."";
			$arrKolDetails[$row['id']]=$row;
			$arrKolIds[]=$row['id'];
		}
		$this->session->set_userdata('arrMapFilterFields',$arrFilterFields);
		//pr($arrKolDetails);
		$arrData=array();
		$arrPubKols=array();
		$arrEventKols=array();
		$arrAffKols=array();
		$arrEduKols=array();
		$arrOrgKols=array();
		$arrTrialKols=array();
		//echo "size ".sizeof($arrKolDetails)."<br>";
		foreach($arrKolDetails as $kolDetails){
			//echo "KolId : ".$kolDetails['id']."<br>";
			if(in_array('pub',$arrPubDegrees))
				$arrPubKols=$this->pubmed->getCoAuthoredKols($kolDetails['id']);
			if(in_array('event',$arrPubDegrees))
				$arrEventKols=$this->kol->getCoEventedKols($kolDetails['id']);
			if(in_array('aff',$arrPubDegrees))
				$arrAffKols=$this->kol->getCoAffiliatedKols($kolDetails['id']);
			if(in_array('edu',$arrPubDegrees))
				$arrEduKols=$this->kol->getCoEducatedKols($kolDetails['id'],$arrFilterFields);
			if(in_array('org',$arrPubDegrees))
				$arrOrgKols=$this->kol->getCoOrganizedKols($kolDetails['id'],$arrFilterFields);
			if(in_array('trial',$arrPubDegrees))
				$arrTrialKols=$this->clinical_trial->getCoTrialledKols($kolDetails['id'],$arrFilterFields);
			$arrKols=$this->get_unique_kolids_with_weightages($arrPubKols,$arrEventKols,$arrAffKols,$arrEduKols,$arrOrgKols,$arrTrialKols);
			//echo "size ".sizeof($arrKols)."<br>";
			if(sizeof($arrKols)>0){
				$arrData[$kolDetails['id']]=$arrKols;
				//echo "In <br>";
			}
		}
		
		$arrData = $this->sortByConnections($arrData);
		
		//echo "after ".sizeof($arrData)."<br>";
		//Prepares the Json data as required by the TheJit Radial/ForeceDirected graph
		$nodeData=array();
		$nodeData['$lineWidth']= 5;
		$nodeData['$color']="#ddeeff";
		$nodeData['$dim']= 0;
		$nodeData['nocn']= 0;
		$data=array();
		$centerNode = array();
		$data['id']="dummy100";
		$data['name']="";
		$data['data']=$nodeData;
		$data['children'] = array();
		foreach($arrData as $key => $value){
			//echo "KolId : ".$key."<br>";
			$nodeData =array();
			$nodeData['$color']="#555555";
			//$nodeData['relation'] = $arrKolDetails[$key]['first_name']." ".$arrKolDetails[$key]['last_name'];
			$nodeData['connections']=sizeof($value);
			$nodeDetails=array();
			$nodeDetails['id']=$key;
			$nodeDetails['name']=$arrKolDetails[$key]['first_name']." ".$arrKolDetails[$key]['last_name'];
			$nodeDetails['data']=$nodeData;
			$arrAdjecencies=array();
			foreach($value as $row){
				//if the kol is not in the array of kol points. then skip the connection
				if (!array_key_exists($row['kol_id'], $arrData)) {
				    //$arrData[$row['kol_id']]=array();
				    continue;
				} 
				$adjecent=array();
				$adjecent['id']=$row['kol_id'];
				$adjecent['name']=$arrKolDetails[$row['kol_id']]['first_name']." ".$arrKolDetails[$row['kol_id']]['last_name'];;
				$adjecentData=array();
				$adjecentData['relation']=$arrKolDetails[$row['kol_id']]['first_name']." ".$arrKolDetails[$row['kol_id']]['last_name'];
				$adjecentData['ooc']=$row['count'];
				$adjecent['data']=$adjecentData;
				$adjecent['children'] = array();
				$arrAdjecencies[]=$adjecent;
				

			}
			$nodeDetails['children']=$arrAdjecencies;
			$nodeDetails['size']=sizeof($arrAdjecencies);
			$data['children'][]=$nodeDetails;
		}
		
		$arrAllNodes = $data['children'];
		foreach($arrAllNodes as $c=>$key) {
	        $sort_numcie[] = $key['size'];
	        $sort_ref[] = $key['name'];
	    }
		array_multisort($sort_numcie, SORT_DESC, $sort_ref, SORT_STRING, $arrAllNodes);
		$data['children'] = $arrAllNodes;
		ob_start('ob_gzhandler');
		
		echo json_encode($data);
	}
	
	// Comparison function
	function cmp($a, $b) {
	    if (sizeof($a) == sizeof($b)) {
	        return 0;
	    }
	    return (sizeof($a) > sizeof($b)) ? -1 : 1;
	}
	

	/**
	 * Calculates a given kol influence with other co-autheras and influence amoung the co-authars of the kol
	 * @author 	Ramesh B
	 * @since	
	 * @return JSON
	 * @created 11-07-11
	 */	
	function get_kol_coauthors_influence_data_thejit($kolIdPassed=null){
		ini_set("memory_limit","200M");
		$fromYear=0;
		$toYear=0;
		$kolId = $kolIdPassed;
		if($kolId == null){
			$kolName		= $this->input->post('influence_kol_name');
			//$value1=str_replace(" ","",$kolName);
			$kolId=$this->kol->getKolId($kolName);
		}
		
		$kolName = $this->kol->getKolName($kolId);
		
		//Get all the co authors for given kol
		$arrKolCoAuthors=$this->kol->getKolCoAuthFreqency($kolId, $fromYear, $toYear,$kolName,true,'');
		
		//Get co authors having affiliation info
		$arrCoAuthorsHavingAffiliation = $this->pubmed->getKolCoAuthorsHavingAffiliation($kolId);
		$arrCoAuthorsHavingAffAll = array();
		foreach($arrCoAuthorsHavingAffiliation as $id => $aliasId){
			$arrCoAuthsIds = array($id);
			$matchingAuths=$this->pubmed->getMatchingCoAuthorIds($arrCoAuthsIds,$kolId);
			$arrCoAuthorsHavingAffAll = array_merge($arrCoAuthorsHavingAffAll, $matchingAuths);
			
			if($aliasId == null)
				$aliasId = $id;
			$aliasIdReferences = $this->pubmed->getAliasIdReferences($aliasId);
			$arrCoAuthorsHavingAffAll = array_merge($arrCoAuthorsHavingAffAll, $aliasIdReferences);
		}
		$arrCoAuthorsHavingAffiliation = $arrCoAuthorsHavingAffAll;
		
		//Ge all the kol who are co-authors for given kol publications
		$arrPubKols=$this->pubmed->getCoAuthoredKols($kolId);
		//pr($arrPubKols);
		$arrKolNames=array();
		foreach($arrPubKols as $row){
			$arrKolName = $this->kol->getKolName($row['kol_id']);
			$arrNameCombinations=$this->pubmed->generate_name_combinations($arrKolName['first_name'], $arrKolName['middle_name'], $arrKolName['last_name']);
			foreach($arrNameCombinations as $name){
				$arrKolNames[$name]=$row['kol_id'];
			}
		}
		
		$arrData=array();
		foreach($arrKolCoAuthors as $koAuthDetails){
			$arrCoAuthInfluence=$this->pubmed->getCoAuthoredCoAuthors($kolId,$koAuthDetails);
			$arrData[$koAuthDetails['id']]=$arrCoAuthInfluence;
		}
		
		//Prepares the Json data as required by the TheJit Radial/ForeceDirected graph
		$arrCoAuthorKOLIds = array();
		$nodeData=array();
		$nodeData['$lineWidth']= 5;
		$nodeData['$color']="#ddeeff";
		$nodeData['$dim']= 0;
		$data=array();
		$centerNode = array();
		$data['id']='kol_'.$kolId;
		$data['name']=$kolName['first_name']." ".$kolName['middle_name']." ".$kolName['last_name'];
		$data['data']=$nodeData;
		$data['children'] = array();
		foreach($arrData as $key => $value){
			//echo "KolId : ".$key."<br>";
			$nodeData =array();
			$nodeData['$color']="#555555";
			$nodeData['connections']=$arrKolCoAuthors[$key]['count'];
			if (array_key_exists($arrKolCoAuthors[$key]['last_name']." ".$arrKolCoAuthors[$key]['initials'],$arrKolNames)) {
			  	//$nodeData['kolid']=$arrKolNames[$arrKolCoAuthors[$key]['last_name']." ".$arrKolCoAuthors[$key]['initials']];
			  	//pr($arrKolNames[$arrKolCoAuthors[$key]['last_name']." ".$arrKolCoAuthors[$key]['initials']]);
			  	$arrCoAuthorKOLIds[$key] = $arrKolNames[$arrKolCoAuthors[$key]['last_name']." ".$arrKolCoAuthors[$key]['initials']];
			 }
			$nodeDetails=array();
			$nodeDetails['id']=$key;
			$nodeDetails['name']=$arrKolCoAuthors[$key]['last_name']." ".$arrKolCoAuthors[$key]['initials'];
			$nodeDetails['data']=$nodeData;
			$arrAdjecencies=array();
			foreach($value as $row){
				if (array_key_exists($row['id'], $arrKolCoAuthors)) {
					$adjecent=array();
					$adjecent['id']=$row['id'];
					$adjecent['name']=$arrKolCoAuthors[$row['id']]['last_name']." ".$arrKolCoAuthors[$row['id']]['initials'];
					$adjecentData=array();
					$adjecentData['ooc']=$row['count'];
					$adjecent['data']=$adjecentData;
					$adjecent['children'] = array();
					$arrAdjecencies[]=$adjecent;
				}

			}
			$nodeDetails['children']=$arrAdjecencies;
			$data['children'][]=$nodeDetails;
		}
		
		$retunData['connectionData'] = $data;
		$retunData['coAuthorsKOLIds'] = $arrCoAuthorKOLIds;
		$retunData['coAuthorsHavingAffiliation'] = $arrCoAuthorsHavingAffiliation;
		ob_start('ob_gzhandler');
		echo json_encode($retunData);
	}
	
	function sortByConnections($arrData){
		
		$arrConnctionsCount = array();
		foreach($arrData as $key => $connections){
			$arrConnctionsCount[$key] = sizeof($connections);
		}
		
		arsort($arrConnctionsCount);
		
		$sortedData = array();
		
		foreach($arrConnctionsCount as $key => $value){
			$sortedData[$key] = $arrData[$key];
		}
		
		return $sortedData;
	}
	
	/**
	 * Calculates a given kol influence with other co-autheras and influence amoung the co-authars of the kol
	 * @author 	Ramesh B
	 * @since	
	 * @return JSON
	 * @created 11-07-11
	 */
	function get_kol_influence_data_thejit($kolIdPassed=null){
		
		$arrFilterFields=array();
		$page=$this->input->post('page');
		$count=0;
		$limit=0;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
		$searchType='';
		$keyword='';
		$name='';
		$arrPubDegrees	=	explode(",",$this->input->post('map_degrees'));
	
		$kolId = $kolIdPassed;
		if($kolId == null){
			$kolName		= $this->input->post('influence_kol_name');
			//$value1=str_replace(" ","",$kolName);
			$kolId=$this->kol->getKolId($kolName);
		}
		
		$kolName = $this->kol->getKolName($kolId);
		
		$arrKolIds=array();
		$arrKeywords[0]=$name;
		$arrKolDetailResult=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,false,null,$arrKolIds,true);
		
		$arrKolDetails	=	array();
		foreach($arrKolDetailResult as $row){
			$arrKolDetails[$row['id']]=$row;
		}
		//pr($arrKolDetails);
		$arrData=array();
		$arrPubKols=array();
		$arrEventKols=array();
		$arrAffKols=array();
		$arrEduKols=array();
		$arrOrgKols=array();
		$arrTrialKols=array();
				
		if(in_array('pub',$arrPubDegrees))
			$arrPubKols=$this->pubmed->getCoAuthoredKols($kolId);
		if(in_array('event',$arrPubDegrees))
			$arrEventKols=$this->kol->getCoEventedKols($kolId);
		if(in_array('aff',$arrPubDegrees))
			$arrAffKols=$this->kol->getCoAffiliatedKols($kolId);
		if(in_array('edu',$arrPubDegrees))
			$arrEduKols=$this->kol->getCoEducatedKols($kolId,$arrFilterFields);
		if(in_array('org',$arrPubDegrees))
			$arrOrgKols=$this->kol->getCoOrganizedKols($kolId,$arrFilterFields);
		if(in_array('trial',$arrPubDegrees))
			$arrTrialKols=$this->clinical_trial->getCoTrialledKols($kolId,$arrFilterFields);
		$arrKols=$this->get_unique_kolids_with_weightages($arrPubKols,$arrEventKols,$arrAffKols,$arrEduKols,$arrOrgKols,$arrTrialKols);
		if(sizeof($arrKols)>0){
			$arrData=$arrKols;
			
		}
		
		//pr($arrData);
		/*$nodeData=array();
		$nodeData['$color']="#2200C1";
		$nodeData['$color']="#555555";
		$nodeData['$type']="circle";
		$data=array();
		foreach($arrData as $key => $value){
			$nodeDetails=array();
			$nodeDetails['id']=$key;
			if (array_key_exists($key, $arrKolDetails)) {
				$nodeDetails['name']=$arrKolDetails[$key]['first_name']." ".$arrKolDetails[$key]['last_name'];
			} 
			else
				$nodeDetails['name']="";
			$nodeDetails['data']=$nodeData;
			$arrAdjecencies=array();
			foreach($value as $row){				
				$adjecent=array();
				$adjecent['nodeTo']=$row['kol_id'];
				$adjecent['nodeFrom']=$key;
				$adjecentData=array();
				if($row['count'] > 30) $row['count']=30;
				$adjecentData['$lineWidth']=$row['count']/5;
				$adjecentData['auths']=$row['count'];
				$adjecent['data']=$adjecentData;
				$arrAdjecencies[]=$adjecent;
				
				if (!array_key_exists($row['kol_id'], $arrData)) {
					$arrDetails=array();
					$arrDetails['kol_id']=$key;
					$arrDetails['count']=$row['count'];
				    $arrData[$row['kol_id']]=$arrDetails;
				} 
			}
			$nodeDetails['adjacencies']=$arrAdjecencies;
			$data[]=$nodeDetails;
		}*/
		
		//Prepares the Json data as required by the TheJit Radial/ForeceDirected graph
		$nodeData=array();
		$nodeData['$lineWidth']= 5;
		$nodeData['$color']="#ddeeff";
		$nodeData['$dim']= 0;
		$data=array();
		$centerNode = array();
		$data['id']='kol-'.$kolId;
		$data['name'] = $this->common_helpers->get_name_format($kolName['first_name'],$kolName['middle_name'],$kolName['last_name']);
		//$data['name']=$kolName['first_name']." ".$kolName['middle_name']." ".$kolName['last_name'];
		$data['data']=$nodeData;
		$data['children'] = array();
		foreach($arrData as $key => $value){
			//echo "KolId : ".$key."<br>";
			$nodeData =array();
			$nodeData['$color']="#555555";
			$nodeData['connections']=$value['count'];
			$nodeDetails=array();
			$nodeDetails['id']=$key;
			$nodeDetails['name']=trim($arrKolDetails[$key]['first_name']." ".$arrKolDetails[$key]['last_name']);
			$nodeDetails['data']=$nodeData;
			$arrAdjecencies=array();
			$nodeDetails['children']=$arrAdjecencies;
			if(!empty($nodeDetails['name'])){
                $data['children'][]=$nodeDetails;
			}
		}
		
		$retunData['connectionData'] = $data;
		$retunData['coAuthorsKOLIds'] = array();
		//$retunData['kolName'] = $arrKolDetails[$kolId]['first_name']." ".$arrKolDetails[$kolId]['last_name'];
		$retunData['kolName'] = $this->common_helpers->get_name_format($kolName['first_name'],$kolName['middle_name'],$kolName['last_name']);
		$retunData['kolId'] = $kolId;
		//pr($retunData);
		ob_start('ob_gzhandler');
		echo json_encode($retunData);
	}
	
	/**
	 * Prepares the influence data for the given shub organization with multilevel,this is called in recursive form
	 * @author 	Ramesh B
	 * @since Otsuka 1.0.11	
	 * @return JSON
	 * @created 28 mar 2013
	 */	
	function get_sub_org_influence_data($subOrgData, $arrFilterOrgs, $isParent = false){
			$nodeType = "customNode";
			$u_agent = $_SERVER['HTTP_USER_AGENT']; 
			if(preg_match('/MSIE/i',$u_agent)){
				$nodeType = "circle";
			}
			$arrKols = $this->arrKols;
			if(sizeof($arrKols) <= 0)
				$arrKols				= $this->payment->getAllKolsName1();
			$orgId = $subOrgData['id'];
			$arrOrgIds = $this->arrOrgIds;
			$arrOrgIds[] = $orgId;
			$this->arrOrgIds = $arrOrgIds;
		
			$childNode=array();
			$childNodeData=array();
			$childMembers=array();
			$childNode['id']='org-'.$orgId;
			$childNode['name']=$subOrgData['name'];
			//Get the sub organizations of the parent organization and create there node objects
			$arrSubOrganizations=$this->organization->listSubOrgs($orgId,$arrFilterOrgs);
			if(sizeof($arrSubOrganizations) > 0){
				$showOrgNodes=4;
				if(sizeof($arrSubOrganizations) > $showOrgNodes){
					for($i=0;$i<$showOrgNodes;$i++){
						$orgNode=array();
						$childMemberData=array();
						$orgNode['id']="stat-org-".$arrSubOrganizations[$i]['id'];
						$orgNode['name']=$arrSubOrganizations[$i]['name'];
						$orgNode['children']=array();
						$childMemberData['$type']="star";
						$childMemberData['$dim']=9;
						$childMemberData['$color']="#2d00ff";
						$orgNode['data']=$childMemberData;
						$childMembers[]=$orgNode;
					}
					$kolNode=array();
					$childMemberData=array();
					$kolNode['id']="stat-org-".$orgId;
					$kolNode['name']="More Orgs(".(sizeof($arrSubOrganizations)-$showOrgNodes).")";
					$kolNode['children']=array();
					$childMemberData['$type']="star";
					$childMemberData['$dim']=12;
					$childMemberData['$color']="#2d00ff";
					$kolNode['data']=$childMemberData;
					$childMembers[]=$kolNode;
				}
				else{
					foreach($arrSubOrganizations as $key => $rowData){
						$orgNode=array();
						$childMemberData=array();
						$orgNode['id']="stat-org-".$rowData['id'];
						$orgNode['name']=$rowData['name'];
						$orgNode['children']=array();
						$childMemberData['$type']="star";
						$childMemberData['$dim']=10;
						$childMemberData['$color']="#2d00ff";
						$orgNode['data']=$childMemberData;
						$childMembers[]=$orgNode;
					}
				}
			}
			//Associated people
			$arrSubOrgMembers=$this->organization->getOrgMembersByOrgId($orgId);
			if(sizeof($arrSubOrgMembers) > 0){
				$kolNode=array();
				$childMemberData=array();
				$kolNode['id']="stat-kol-".$orgId;
				$kolNode['name']="Associated ".lang('HCP')."s(".sizeof($arrSubOrgMembers).")";//$rowData[FIRST_ORDER].' '.$rowData[SECOND_ORDER].' '.$rowData[THIRD_ORDER];
				$kolNode['children']=array();
				$childMemberData['$type']="circle";
				$childMemberData['$dim']=10;
				$childMemberData['$color']="#555555";
				$kolNode['data']=$childMemberData;
				$childMembers[]=$kolNode;
			}
			//Key People
			$arrSubOrgKeyPeoples=$this->organization->getKeyPeopleDetailsOfOrg($orgId);
			if(sizeof($arrSubOrgKeyPeoples) > 0){
				$kolNode=array();
				$childMemberData=array();
				$kolNode['id']="stat-key-".$orgId;
				$kolNode['name']= "Key People(".sizeof($arrSubOrgKeyPeoples).")";
				$kolNode['children']=array();
				$childMemberData['$type']="circle";
				$childMemberData['$dim']=10;
				$childMemberData['$color']="#5ff555";
				$kolNode['data']=$childMemberData;
				$childMembers[]=$kolNode;
			}
			//echo $this->db->last_query();
// 			foreach($arrSubOrganizations as $subId => $subData){
// 				//proceeed only if this org id is not present in the $arrORgIds in order to avoid the infinate recursion
// 				if(!in_array($subData['id'],$arrOrgIds)){
// 					$cNode=$this->get_sub_org_influence_data($subData, $arrFilterOrgs);
// 					$childMembers[]=$cNode;	
// 				}else{
// 					$cNode = array();
// 					$cNode['id']='org-'.$subData['id'];
// 					$cNode['name']=$this->organization->getOrgNameByOrgId($subData['id']);
// 					$childMembers[]=$cNode;	
// 				}
// 			}			
			//Get organinzation associated people, key people, ke authors and key investigators and create there node objects
			
// 			//Associated people
// 			$arrSubOrgMembers=$this->organization->getOrgMembersByOrgId($orgId);
// 			foreach($arrSubOrgMembers as $kolId => $rowData){
// 				$kolNode=array();
// 				$childMemberData=array();
// 				$kolNode['id']="kol-".$kolId;
// 				$kolNode['name']=$this->common_helpers->get_name_format($rowData['first_name'],$rowData['middle_name'],$rowData['last_name']);//$rowData[FIRST_ORDER].' '.$rowData[SECOND_ORDER].' '.$rowData[THIRD_ORDER];
// 				$kolNode['children']=array();
// 				$childMemberData['$type']="circle";
// 				$childMemberData['$dim']=3;
// 				$childMemberData['$color']="#555555";
// 				$kolNode['data']=$childMemberData;
// 				$childMembers[]=$kolNode;		
// 			}

				
			/*foreach($arrSubOrgKeyPeoples as $id => $rowData){
				$kolNode=array();
				$childMemberData=array();
				$kolId = array_search($rowData['first_name']." ".$rowData['middle_name']." ".$rowData['last_name'],$arrKols);
				if($kolId)
					$kolNode['id']="kol-".$kolId;
				else
					$kolNode['id']="key-".$rowData['id'];
				$kolNode['name']=$rowData['first_name'].' '.$rowData['middle_name'].' '.$rowData['last_name'];
				$kolNode['children']=array();
				$childMemberData['$type']="circle";
				$childMemberData['$dim']=3;
				$childMemberData['$color']="#ADA2C3";
				$kolNode['data']=$childMemberData;
				$childMembers[]=$kolNode;		
			}*/
			
// 			//Key Authors
// 			$arrFirstAuthors=$this->organization->getFistAuthors($orgId);
// 			if(sizeof($arrFirstAuthors) > 0){
// 				$kolNode=array();
// 				$childMemberData=array();
// 				$kolNode['id']="stat-auth-".$orgId;
// 				$kolNode['name']= "Key Authors(".sizeof($arrFirstAuthors).")";
// 				$kolNode['children']=array();
// 				$childMemberData['$type']="circle";
// 				$childMemberData['$dim']=10;
// 				$childMemberData['$color']="#ffff55";
// 				$childMemberData['$linecolor']="#FF5555";
// 				$kolNode['data']=$childMemberData;
// 				$childMembers[]=$kolNode;
// 			}
			/*foreach($arrFirstAuthors as $id => $rowData){
				$kolNode=array();
				$childMemberData=array();
				$authorName = '';
				//based on the name avilability, construct a proper name
				if($rowData['last_name']!='' && $rowData['fore_name']!='')
					$authorName =$rowData['last_name']." ".$rowData['fore_name'];
				else if($rowData['fore_name']=='')
					$authorName =$rowData['last_name']." ".$rowData['initials'];
				else if($rowData['last_name']=='')
					$authorName =$rowData['fore_name']." ".$rowData['initials'];
			
				$kolId = array_search($authorName,$arrKols);
				if($kolId)
					$kolNode['id']="kol-".$kolId;
				else
					$kolNode['id']="auth-".$rowData['id'];
				
				$kolNode['name']=$authorName;
				$childMemberData['$type']="circle";
				$childMemberData['$dim']=3;
				$childMemberData['$color']="#ffff55";
				$childMemberData['$linecolor']="#FF5555";
				$kolNode['data']=$childMemberData;
				$childMembers[]=$kolNode;
			}
			*/
// 			//Key Investigators
// 			$arrKeyInvestigators=$this->organization->getKeyInvestigators($orgId);
// 			if(sizeof($arrKeyInvestigators) > 0){
// 				$kolNode=array();
// 				$childMemberData=array();
// 				$kolNode['id']="stat-invest-".$orgId;
// 				$kolNode['name']= "Key Investigators(".sizeof($arrKeyInvestigators).")";
// 				$kolNode['children']=array();
// 				$childMemberData['$type']="circle";
// 				$childMemberData['$dim']=10;
// 				$childMemberData['$color']="#ffaa55";
// 				$childMemberData['$linecolor']="#FF5555";
// 				$kolNode['data']=$childMemberData;
// 				$childMembers[]=$kolNode;
// 			}
			
			/*foreach($arrKeyInvestigators as $id => $rowData){
				$kolNode=array();
				$childMemberData=array();
				$kolId = array_search($rowData['last_name'],$arrKols);
				if($kolId)
					$kolNode['id']="kol-".$kolId;
				else
					$kolNode['id']="invest-".$rowData['id'];
				$kolNode['name']=$rowData['last_name'];
				$childMemberData['$type']="circle";
				$childMemberData['$dim']=3;
				$childMemberData['$color']="#ffaa55";
				$childMemberData['$linecolor']="#FF5555";
				$kolNode['data']=$childMemberData;
				$childMembers[]=$kolNode;
			}*/
				
			$childNode['children']=$childMembers;
			//$childNodeData['$type']='ellipse';
			$childNodeData['$type']='star';
			//$childNodeData['$type']='customNode';
			$childNodeData['node_type']='org';
			$childNodeData['$dim']=6;
			$childNodeData['$color']="#2200C1";
			$childNode['data']=$childNodeData;
			
			return $childNode;
	}
	
	
	/**
	 * Prepares the influence data considering all the organizations
	 * @author 	Ramesh B
	 * @since Otsuka 1.0.11	
	 * @return JSON
	 * @created 28 mar 2013
	 */	
	function org_influence_data($orgId = null){
		$this->load->model("organization");
		//Get the filters from the post variables
		$acOrgName	= trim($this->input->post('org_name'));

		if($orgId != null){
			$arrOrgIds[]	= $orgId;
			$acOrgName = $this->organization->getOrgNameByOrgId($orgId);
		} else if($acOrgName !='' && $acOrgName != 'Enter Organization'){
			$arrOrgIds[]	=	$this->organization->getOrgIdByOrgName($acOrgName);
		}
		
		$arrCountries  = array();
		$arrStates  = array();
		$arrOrgTypes  = array();
		//Set all the filters in the array
		$arrFilterOrgs['orgIds'] 	= $arrOrgIds;
		$arrFilterOrgs['country'] 	= $arrCountries;
		$arrFilterOrgs['state'] 	= $arrStates;
		$arrFilterOrgs['type'] 		= $arrOrgTypes;
					
		$subOrgData = array();
		$subOrgData['id'] = $arrFilterOrgs['orgIds'][0];
		$subOrgData['name'] = $acOrgName;
		$arrFilterOrgs['orgIds'] = array();
		$arrInfluenceData = $this->get_sub_org_influence_data($subOrgData, $arrFilterOrgs, true);

		ob_start('ob_gzhandler');
		echo json_encode($arrInfluenceData);
	}
	
	function view_influence_map_org(){
		$this->load->model("organization");
		$count=0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=0;
		$arrOrganizations	= array();
		$searchType	= 'simple';
		$keyword	= $this->input->post('keyword');
		if($keyword==null)	
			$keyword="";
		
		//Getting "all Matching Events by event name"
		$arrOrganizations		= $this->organization->getMatchOrganiations($keyword,$limit,$startFrom,false);
		$count					= $this->organization->getMatchOrganiations($keyword,$limit,$startFrom,true);
		$arrOrgByCountryCount	= $this->organization->getMatchOrganiations($keyword,$limit,$startFrom,false,true,'country');
		$arrOrgByStateCount		= $this->organization->getMatchOrganiations($keyword,$limit,$startFrom,false,true,'state');
		$arrOrgByTypeCount		= $this->organization->getMatchOrganiations($keyword,$limit,$startFrom,false,true,'type');
		
		$arrFilterOrgs=array();
		$this->session->set_userdata('keyword',$keyword);
		$this->session->set_userdata('arrFilterFields',$arrFilterOrgs);
		
		$allCountryCount=0;
		$assoArrOrgByCountryCount=array();
		foreach($arrOrgByCountryCount as $row){
			$assoArrOrgByCountryCount[$row['country']]=$row;
			$allCountryCount+=$row['count'];
		}
		$allStateCount=0;
		$assoArrOrgByStateCount=array();
		foreach($arrOrgByStateCount as $row){
			$assoArrOrgByStateCount[$row['state']]=$row;
			$allStateCount+=$row['count'];
		}
		$allOrgTypeCount=0;
		$assoArrOrgByTypeCount=array();
		foreach($arrOrgByTypeCount as $row){
			$assoArrOrgByTypeCount[$row['type']]=$row;
			$allOrgTypeCount+=$row['count'];
		}
		
		//Setting all the required data and forwording in to respective page
		$filterData['allCountryCount']		=	$allCountryCount;
		$filterData['allStateCount']		=	$allStateCount;
		$filterData['allOrgTypeCount']		=	$allOrgTypeCount;
		$filterData['arrOrgByCountryCount']	=	$assoArrOrgByCountryCount;
		$filterData['arrOrgByStateCount']	=	$assoArrOrgByStateCount;
		$filterData['arrOrgByTypeCount']	=	$assoArrOrgByTypeCount;
		$filterData['keyword']				=	$keyword;
		$filterData['searchType']			= 	$searchType;
		$filterData['arrFilterFields']		= 	"";
		$filterData['arrAdvSearchFields']	= 	"";
		$orgResultsData['orgsCount']=$count;
		$orgResultsData['arrOrganiations']	=	$arrOrganizations;
		$orgResultsData['searchType']		=	"simple";
		$orgResultsData['msg']=$this->common_helpers->genSearchResMsgs($startFrom,$limit,$count,$keyword);
		$data['orgResultsPage']			=	'search/my_org_results';
		$data['orgResultsData']			=	$orgResultsData;
		
		$data['arrOrganiations']			=	$arrOrganizations;
		//$data['filterPage']				=	'search/org_filters_li_style';
		//$data['filterData']				=	$filterData;
		$data['mapSection']				= '';
		$data['data']['additionalContent']	= '<div id="refinedByWrapper" class="rightRefinedByFilter">
													<div id="refinedByContainer">
														<div id="rightSideBarSlider" class="expandRightSideBar tooltip-demo tooltop-left"><a href="#" class="tooltipLink" rel="tooltip" title="Show Key People">&nbsp;</a></div>
														<div id="searchLeftBar" style="display: none;">
															<h3>Key People</h3>
															<input id="search-names" type="text" onkeyup="filterOrgMembersList(this);">
															<div id="searchFiltersContainer" style="position: relative;">
																<ul>
																	
																</ul>
															</div>
														</div>
													</div>
												</div>';
		$data['showOrgInputBox'] = true;
		$data['contentPage'] 			= 'organizations/view_network_map';
		$this->load->view('layouts/client_view',$data);
	}
	
	function org_influence_map_stats($orgId = null){
		$this->load->model("organization");
		$orgName	= '';
		
		if($orgId == null){
			$acOrgName	= trim($this->input->post('org_name'));
			//Get all the selected checkboxs details for respective category
			$arrOrgIds=array();
			if($acOrgName != '')
				$orgId	=	$this->organization->getOrgIdByOrgName($acOrgName);
		}
		
			$arrOrgIds[] = $orgId;
		$arrFilterOrgs['orgIds'] 	= $arrOrgIds;
		
		//get all the suborganization ids and send it to
		$arrSubOrgIds = $this->organization->getSuborganizationIds($orgId);

		$arrOrganizations		= $this->organization->getOrgsMatchingGivenIds($arrSubOrgIds);

		$arrCountryStats= array();
		$arrSateStats	= array();
		$arrTypeStats	= array();
		
		$allCountryCount=0;
		$assoArrOrgByCountryCount=array();
		foreach($arrOrganizations as $row){
			$arrCountryStats[$row['country']][] = $row;
			$arrSateStats[$row['state']][] 		= $row;
			$arrTypeStats[$row['city']][] 		= $row;
		}
		
		//Sort the array by the size of subarray
		function cmp($a, $b){
		    return (count($b) - count($a));
		}
		uasort($arrCountryStats, 'cmp');
		uasort($arrSateStats, 'cmp');
		uasort($arrTypeStats, 'cmp');

		$filterData['totalSubOrgs']		= sizeof($arrOrganizations);
		$filterData['arrCountryStats']	= $arrCountryStats;
		$filterData['arrSateStats']		= $arrSateStats;
		$filterData['arrTypeStats']		= $arrTypeStats;
		
		$this->load->view('organizations/org_influence_map_stats',$filterData);
	}
	
	function get_org_memebers_network_data($orgId){
		$this->load->model("organization");
		$arrMembers = array();
		$parentNode=array();
		$childMembers=array();
		$parentNode['id']='org-'.$orgId;
		
		$arrKols				= $this->payment->getAllKolsName1();
				
		//Associated people
		$arrSubOrgMembers=$this->organization->getOrgMembersByOrgId($orgId);
		foreach($arrSubOrgMembers as $kolId => $rowData){
			$kolNode=array();
			$childMemberData=array();
			$kolNode['id']="kol-".$kolId;
			$kolNode['name']=$rowData['first_name'].' '.$rowData['middle_name'].' '.$rowData['last_name'];
			$childMemberData['$type']="circle";
			$childMemberData['$dim']=3;
			$childMemberData['$color']="#555555";
			$childMemberData['$linecolor']="#FF5555";
			$kolNode['data']=$childMemberData;
			$arrMembers[]=$kolNode;
			$childMembers[] = $kolNode['id'];	
		}
		//Key People
		$arrSubOrgKeyPeoples=$this->organization->getKeyPeopleDetailsOfOrg($orgId);
		foreach($arrSubOrgKeyPeoples as $id => $rowData){
			$kolNode=array();
			$childMemberData=array();
			$kolId = array_search($rowData['first_name']." ".$rowData['middle_name']." ".$rowData['last_name'],$arrKols);
			if($kolId)
				$kolNode['id']="kol-".$kolId;
			else
				$kolNode['id']="key-".$rowData['id'];
						
			$kolNode['name']=$rowData['first_name'].' '.$rowData['middle_name'].' '.$rowData['last_name'];
			$childMemberData['$type']="circle";
			$childMemberData['$dim']=3;
			$childMemberData['$color']="#ADA2C3";
			$childMemberData['$linecolor']="#FF5555";
			$kolNode['data']=$childMemberData;
			$arrMembers[]=$kolNode;
			$childMembers[] = $kolNode['id'];		
		}
		
		//Key Authors
		/*$arrFirstAuthors=$this->organization->getFistAuthors($orgId);
		foreach($arrFirstAuthors as $id => $rowData){
			$kolNode=array();
			$childMemberData=array();
			$authorName = '';
			//based on the name avilability, construct a proper name
			if($rowData['last_name']!='' && $rowData['fore_name']!='')
				$authorName =$rowData['last_name']." ".$rowData['fore_name'];
			else if($rowData['fore_name']=='')
				$authorName =$rowData['last_name']." ".$rowData['initials'];
			else if($rowData['last_name']=='')
				$authorName =$rowData['fore_name']." ".$rowData['initials'];
				
			$kolId = array_search($authorName,$arrKols);
			if($kolId)
				$kolNode['id']="kol-".$kolId;
			else
				$kolNode['id']="auth-".$rowData['id'];
						
			$kolNode['name']=$authorName;
			$childMemberData['$type']="circle";
			$childMemberData['$dim']=3;
			$childMemberData['$color']="#ffff55";
			$childMemberData['$linecolor']="#FF5555";
			$kolNode['data']=$childMemberData;
			$arrMembers[]=$kolNode;
			$childMembers[] = $kolNode['id'];		
		}
		
		//Key Investigators
		$arrKeyInvestigators=$this->organization->getKeyInvestigators($orgId);
		foreach($arrKeyInvestigators as $id => $rowData){
			$kolNode=array();
			$childMemberData=array();
			$kolId = array_search($rowData['last_name'],$arrKols);
			if($kolId)
				$kolNode['id']="kol-".$kolId;
			else
				$kolNode['id']="invest-".$rowData['id'];
			$kolNode['name']=$rowData['last_name'];
			$childMemberData['$type']="circle";
			$childMemberData['$dim']=3;
			$childMemberData['$color']="#ffaa55";
			$childMemberData['$linecolor']="#FF5555";
			$kolNode['data']=$childMemberData;
			$arrMembers[]=$kolNode;
			$childMembers[] = $kolNode['id'];		
		}*/
			
		$parentNode['adjacencies']=$childMembers;
		$arrMembers[] = $parentNode;
		ob_start('ob_gzhandler');
		echo json_encode($arrMembers);
	}
	
	/**
	 * load the view page to show geo map
	 * @author 	Vinayak B
	 * @since Otsuka 1.0.14	
	 * @return JSON
	 */	
	function view_geo_map_org(){
		$data['contentPage'] = 'organizations/maps/view_geo_map';
		$this->load->view('layouts/client_view',$data);
	}
	
	function get_organizations(){
		$orgName = $this->input->post('orgName');
		$arrOrganizations = $this->map->getOrganizationDetails($orgName);
		
		foreach($arrOrganizations as $details){
			$details['connections'] =$this->map->getsubOrgDetais($details['id']);
			$row[] = $details;
			
		}
		//pr($row);
		$data['arrOrganizations'] = $row;
		//pr($data);
		echo json_encode($data);
	}
	
	function view_network_map(){
		$this->load->model('survey');
		$data['arrCompletedSurveys']	= $this->survey->getCompletedSurveys();
		$data['arrTypes']				= $this->arrSurveyTypes;
		$data['contentPage']			= 'surveys/view_network_map';
		$this->load->view('layouts/client_view', $data);
	}
	
	/**
	 * Prepares the influence data to show it in geo map
	 * @author Vinayak
	 * @since Otsuka 1.0.14	
	 * @return JSON
	 * @created 28 may 2013
	 */	
	function view_geo_map(){
		$this->load->model('survey');
		$data['arrCompletedSurveys']	= $this->survey->getCompletedSurveys();
		$data['arrTypes']				= $this->arrSurveyTypes;
		$data['contentPage']			= 'surveys/view_geo_map';
		$this->load->view('layouts/client_view', $data);
	}
	
	function get_org_members_by_type($orgId,$type){
		$this->load->model("organization");
		$arrData = array();
		$arrKols				= $this->payment->getAllKolsName1();
		if($type == 'key'){
		    $arrKolsIds  = $this->organization->getKolKeyIdWithConcat();
		    $globalName = $this->organization->getGlobalRegionByOrgCountry($orgId);
		    $userGroupName = getGroupDetails();
		    $group_names = explode(',',  $userGroupName['group_names']);
// 		    $group_names = explode(',', $this->session->userdata('group_names'));
		    $regionNames = $this->kol->getEnableRegionForOptInOut();
		    $resultOptRegion=array_intersect($group_names,$regionNames);
		    $optRegionEnabled = false;
		    if(KOL_CONSENT && sizeof($resultOptRegion) > 0){
		        $optRegionEnabled = true;
		    }
		    if($optRegionEnabled){
		        $result=array_intersect($group_names,$regionNames);
		        if(strlen($globalName) > 1){
		            $global_names = explode(',', $globalName);
		            $result = array_intersect($global_names,$result);
		        }
		    }else{
		        if(strlen($globalName) > 1){
		            $globalName = explode(',', $globalName);
		            $result=array_intersect($group_names,$globalName);
		        }
		    }
		    
			$resultData = $this->organization->getKeyPeopleDetailsOfOrg($orgId);
			foreach($resultData as $rowData){
				$nameData = array();
				$kolId = array_search($rowData['id'],$arrKolsIds);
				if($kolId){
				    if($this->session->userdata('client_id')!=INTERNAL_CLIENT_ID){
				        if(KOL_CONSENT){
				            $optStatus = $this->organization->getOptInStatusById($kolId);
				            if($optStatus == 4 || $optStatus == 0) {
				                $nameData['id'] = "kol-".$kolId;
				                $nameData['kol_id'] = $kolId;
				                $nameData['unique_id'] = $this->common_helpers->getUniqueIdByKolId($kolId);
				                $nameData['is_kol'] = 'Yes';
				                $nameData['is_kol_opt'] = 'Yes';
				            }else{
				                $nameData['is_kol'] = 'Yes';
				                $nameData['is_kol_opt'] = 'No';
				            }
				        }else{
				            $nameData['unique_id'] = $this->common_helpers->getUniqueIdByKolId($kolId);
				            $nameData['id'] = "kol-".$kolId;
				            $nameData['kol_id'] = $kolId;
				            $nameData['is_kol'] = 'Yes';
				            $nameData['is_kol_opt'] = 'Yes';
				        }
				    }else{
				        $nameData['unique_id'] = $this->common_helpers->getUniqueIdByKolId($kolId);
				        $nameData['id'] = "kol-".$kolId;
				        $nameData['kol_id'] = $kolId;
				        $nameData['is_kol'] = 'Yes';
				        $nameData['is_kol_opt'] = 'Yes';
				    }
				}else{
				    $nameData['id']="key-".$rowData['id'];
				    $nameData['is_kol'] = 'No';
				    $nameData['is_kol_opt'] = 'No';
				}
				if($this->session->userdata('client_id')!=INTERNAL_CLIENT_ID){
				    if($optRegionEnabled){
				        $nameData['isOptEnabled'] = 'true';
				    }else{
				        $nameData['isOptEnabled'] = 'false';
				    }
				    if(sizeof($result) > 0){
				        $nameData['optInAllowed'] = 'true';
				    }else{
				        $nameData['optInAllowed'] = 'false';
				    }
				}else{
				    $nameData['optInAllowed'] = 'true';
				}
				if($this->session->userdata('user_role_id')==ROLE_ADMIN){
				    $nameData['optInAllowed'] = 'true';
				}
				/* if($kolId)
					$nameData['id']="kol-".$kolId;
				else
					$nameData['id']="key-".$rowData['id']; */
				$nameData['key_id'] = $rowData['id'];
				$nameData['name']=$rowData['salutation']." ".$this->common_helpers->get_name_format($rowData['first_name'],$rowData['middle_name'],$rowData['last_name']);//$row[FIRST_ORDER]." ".$row[SECOND_ORDER]." ".$row[THIRD_ORDER];
				$nameData['department'] = $rowData['department'];
				$nameData['title'] = $rowData['title'];
				$nameData['aff'] = "";
				if($rowData['title'] != '')
					$nameData['aff'] .= "<span id='title'>".$rowData['title']."</span><br>";
				if($rowData['department'] != '')
					$nameData['aff'] .= "<span id='department'>".$rowData['department']."</span>";
				$arrData[] = $nameData;
			}
		}
		if($type == 'auth'){
			$resultData = $this->organization->getFistAuthors($orgId);
			foreach($resultData as $rowData){
				$nameData = array();
				$authorName = '';
				//based on the name avilability, construct a proper name
				if($rowData['last_name']!='' && $rowData['fore_name']!='')
					$authorName =$rowData['last_name']." ".$rowData['fore_name'];
				else if($rowData['fore_name']=='')
					$authorName =$rowData['last_name']." ".$rowData['initials'];
				else if($rowData['last_name']=='')
					$authorName =$rowData['fore_name']." ".$rowData['initials'];
					
				$kolId = array_search($authorName,$arrKols);
				if($kolId)
					$nameData['id']="kol-".$kolId;
				else
					$nameData['id']="auth-".$rowData['id']."-".$orgId;
					
				$nameData['name'] = $authorName;
				$nameData['aff'] = $rowData['affiliation'];
				$nameData['num_pubs'] = $rowData['num_pubs'];
				$arrData[] = $nameData;
			}
				
		}
		if($type == 'invest'){
			$resultData = $this->organization->getKeyInvestigators($orgId);
			foreach($resultData as $rowData){
				$nameData = array();
				$kolId = array_search($rowData['last_name'],$arrKols);
				if($kolId)
					$nameData['id']="kol-".$kolId;
				else
					$nameData['id']="invest-".$rowData['id'];
					
				$nameData['name'] = $rowData['last_name'];
				$nameData['aff'] = $rowData['affiliation'];
				$nameData['trial_count'] = $rowData['trial_count'];
				if($nameData['aff'] == null) $nameData['aff'] = '';
				$arrData[] = $nameData;
			}
		}
		if($type == 'kols'){
			$resultData=$this->organization->getOrgMembersByOrgId($orgId,true);
// 			pr($resultData);exit;
			foreach($resultData as $rowData){
				$nameData = array();
				$nameData['id']=$rowData['id'];
				$nameData['kol_unique_id']=$rowData['unique_id'];
				if($rowData['salutation'] != '0'){
				    $rowData['salutation'] = $rowData['salutation']." ";
				}else{
				    $rowData['salutation'] = '';
				}
				$nameData['name'] = $rowData['salutation'].$this->common_helpers->get_name_format($rowData['first_name'],$rowData['middle_name'],$rowData['last_name']);//$row[FIRST_ORDER]." ".$row[SECOND_ORDER]." ".$row[THIRD_ORDER];
				$nameData['aff'] = $rowData['affiliation'];
				$nameData['specialty'] = $rowData['specialty'];
				$nameData['City'] = $rowData['City'];
				$nameData['Region'] = $rowData['Region'];
				$nameData['Country'] = $rowData['Country'];
				if($nameData['aff'] == null) $nameData['aff'] = '';
				$arrData[] = $nameData;
			}
		}
		if($type == 'orgs'){
			$resultData=$this->organization->listSubOrgs($orgId,$arrFilterOrgs);
			foreach($resultData as $rowData){
				$nameData = array();
				$nameData['id']=$rowData['id'];
				$nameData['name'] = $rowData['name'];
				$nameData['type'] = $rowData['type'];
				$nameData['aff'] = $rowData['affiliation'];
				$nameData['City'] = $rowData['City'];
				$nameData['Region'] = $rowData['Region'];
				$nameData['Country'] = $rowData['Country'];
				$nameData['aff_org_count'] = $rowData['aff_org_count'];
				if($nameData['aff'] == null) $nameData['aff'] = '';
				$arrData[] = $nameData;
			}
		}
		ob_start('ob_gzhandler');
		echo json_encode($arrData);
	}
	
	/**
	 * Calculates the kol's influence among themseleves based on the filters provided 
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 11-07-11
	 */
	function filter_influence_data_optimized($isFirstTime=null){
		ini_set("max_execution_time",7200);
		ini_set("memory_limit","200M");
		$arrFilterFields=array();
		$page=$this->input->post('page');
		$count=0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
		$searchType='';
		$keyword='';
		$name='';
		$arrPubDegrees=array();
		
		$arrCountries	=array();
		$arrSpecialties	=array();
		
		if($isFirstTime != null){
			$viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
			if(sizeof($viewMyKols) > 0){
				$viewTypeMyKols = MY_RECORDS;
				$arrFilterFields['viewType'] = $viewMyKols;
			}else{
				$viewTypeMyKols = ALL_RECORDS;
			}
			$searchType=$this->input->post('search_type');
			$keyword=trim($this->session->userdata('keyword'));
//			$arrFilterFields=$this->session->userdata('arrMapFilterFields');
			$arrPubDegrees=array('edu','org');
			$arrSavedFilters = array();
// 			$arrSavedFilters = $this->kol->getFilterByRecentApplied();
			
//			pr($arrSavedFilters);
			$arrAppliedSavedFilters = $arrSavedFilters['arrFilterFields']; 
			if($arrSavedFilters['id'] != 0){
				$arrFilterFields['specialty']=$arrAppliedSavedFilters['specialty'];		
				$arrFilterFields['country']=$arrAppliedSavedFilters['country'];
				$arrFilterFields['state']=$arrAppliedSavedFilters['state'];
				$arrFilterFields['organization']=$arrAppliedSavedFilters['organization'];
				$arrFilterFields['education']=$arrAppliedSavedFilters['education'];
				$arrFilterFields['event_id']=$arrAppliedSavedFilters['event_id'];
				$arrFilterFields['list_id']=$arrAppliedSavedFilters['list_id'];
//				$arrFilterFields['kol_id']=$arrAppliedSavedFilters['kol_id'];
				$arrFilterFields['profile_type']=$arrAppliedSavedFilters['profile_type'];
				$arrFilterFields['savedFilterId']=$arrSavedFilters['id'];
//				pr($arrFilterFields);
			}
//			$arrPubDegrees=array('event');
		}else{
			$specialty		=	trim($this->input->post('specialty_id'));		
			$country		=	trim($this->input->post('country_id'));
			$state			=	trim($this->input->post('state_id'));
			$organization	=	trim($this->input->post('organization'));
			$education		=	trim($this->input->post('education'));
			$eventName		=	trim($this->input->post('event_name'));
			$listName		=	trim($this->input->post('list_name'));
//			$kol_id			=	trim($this->input->post('kol_id'));
			$viewTypeMyKols		=   trim($this->input->post('viewTypeMyKols'));
			
			$arrPubDegrees	=	explode(",",$this->input->post('map_degrees'));
			
			$arrCountries	=	$this->input->post('countries');
			if($arrCountries!='')
				$arrCountries	=explode(",",$arrCountries);
			if($country!='')
				$arrCountries[]	=	$country;
				
			$arrStates	=	$this->input->post('states');
			if($arrStates!='')
				$arrStates	=explode(",",$arrStates);
			if($state!='')
				$arrStates[]	=	$state;
			//echo $specialty;
			$arrSpecialties	=	$this->input->post('specialties');
			if($arrSpecialties!='')
				$arrSpecialties	=explode(",",$arrSpecialties);
			if($specialty!=''){
				$arrSpecialties[]	=	$specialty;
			}
			$arrOrganizations	=	$this->input->post('organizations');
			if($arrOrganizations!='')
				$arrOrganizations	=explode(",",$arrOrganizations);
			if($organization!=''){
				$arrOrganizations[]	=	$organization;
			}
			
			$arrEducations	=	$this->input->post('educations');
			if($arrEducations!='')
				$arrEducations	=explode(",",$arrEducations);
			if($education!=''){
				$arrEducations[]	=	$education;
			}
			
			$arrEvents	=	$this->input->post('events');
			if($arrEvents!='')
				$arrEvents	=explode(",",$arrEvents);
			if($eventName!=''){
				$arrEvents[]	=	$eventName;
			}
			
			$arrLists	=	$this->input->post('lists');
			if($arrLists!='')
				$arrLists	=explode(",",$arrLists);
			if($listName!=''){
				if(stripos($listName, '(')){
					$arrListDetails=explode("(",$listName);
					$listName=trim($arrListDetails[0]);
					$categoryName=trim($arrListDetails[1],") ");
					$listName=$this->My_list_kol->getListName($listName,$categoryName);
				}
				$arrLists[]	=	$listName;
			}
			
			//Prepare array of filter fields, ehich will be used for querying
			$arrFilterFields['specialty']=$arrSpecialties;		
			$arrFilterFields['country']=$arrCountries;
			$arrFilterFields['state']=$arrStates;
			$arrFilterFields['organization']=$arrOrganizations;
			//$arrFilterFields['education']=$this->kol->getInstituteId($education);
			//$arrFilterFields['event_id']=$this->kol->getEventLookupId($eventName);
			$arrFilterFields['education']=$arrEducations;
			$arrFilterFields['event_id']=$arrEvents;
			$arrFilterFields['list_id']=$arrLists;
			$arrFilterFields['event_name']=$eventName;
			if($kol_id != '')
			$arrFilterFields['kol_id']=array($kol_id);
//			pr($arrFilterFields);
			if($viewTypeMyKols == MY_RECORDS){
				$viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
				if(sizeof($viewMyKols) > 0){
					$viewTypeMyKols = MY_RECORDS;
					$arrFilterFields['viewType'] = $viewMyKols;
				}else{
					$arrFilterFields['viewType'] = array(0);
					$viewTypeMyKols = MY_RECORDS;
				}
			}else{
				$viewTypeMyKols = ALL_RECORDS;
			}
		}
		
//		pr($arrFilterFields);
		if(sizeof($arrFilterFields['kol_id'])>0 && $viewTypeMyKols == MY_RECORDS){
			foreach ($arrFilterFields['kol_id'] as $key => $kol_id){
				$kolId = $kol_id;
			}
			if(in_array($kolId,$arrFilterFields['viewType'])){
				$arrFilterFields['viewType'] = '';
			}else{
				$arrFilterFields['kol_id'] = '';
				$arrFilterFields['viewType'] = '';
			}
		}
//		pr($arrFilterFields);
		$arrKolIds=array();
		//pr($arrFilterFields);
		$arrKeywords[0]=$name;
		$startTime=microtime(true);
//		pr($arrFilterFields['viewType']);
		$arrKolDetailResult=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,false,null,$arrKolIds,true);
//		echo $this->db->last_query();
		//$arrKolDetailResult = $this->kol->getKolDetail();
		$timeTaken=microtime(true)-$startTime;
		//echo "Total time taken by query : ".$timeTaken."<br />";

		$arrKolDetails	=	array();
		$arrKolIds		=	array();
		foreach($arrKolDetailResult as $row){
			//echo $row['id']."";
			$row['first_name'] = str_replace(".", "", $row['first_name']);
			$row['middle_name'] = str_replace(".", "", $row['middle_name']);
			$row['last_name'] = str_replace(".", "", $row['last_name']);
			$arrKolDetails[$row['id']]=$row;
			$arrKolIds[]=$row['id'];
		}
//		$this->session->set_userdata('arrMapFilterFields',$arrFilterFields);
		$arrData=array();
		$arrPubKols=array();
		$arrEventKols=array();
		$arrAffKols=array();
		$arrEduKols=array();
		$arrOrgKols=array();
		$arrTrialKols=array();
		$arrSurveyKols=array();
		$result = array();

		$arrKolIds=array();
		$arrKeywords[0]=$name;
		$arrKolDetailResult=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,false,null,$arrKolIds,true);
		$arrKolDetails	=	array();
		$arrKolIds		=	array();
		$arrMicroviewDetails = array();
		foreach($arrKolDetailResult as $row){
			//echo $row['id']."";
			$row['first_name'] = str_replace(".", "", $row['first_name']);
			$row['middle_name'] = str_replace(".", "", $row['middle_name']);
			$row['last_name'] = str_replace(".", "", $row['last_name']);
			
			$arrKolDetails[$row['id']]=$row;
			$arrKolIds[]=$row['id'];
			$mvDetail = array();
			$mvDetail['id'] = $row['id'];
			$mvDetail['on'] = $row['name'];
			$mvDetail['pi'] = $row['profile_image'];
			$arrMicroviewDetails[]=  $mvDetail;
		}
		$startTime=microtime(true);
		
		$this->load->model('map');
		//$arrPubDegrees = array('org','edu','aff','event','pub','trial');
		if(in_array('event',$arrPubDegrees)){
			$arrEventKols=$this->map->getCoEventedKols(null,$arrFilterFields);
			$result = array_merge_recursive($result, $arrEventKols['connections']);
		}
		if(in_array('aff',$arrPubDegrees)){
			$arrAffKols=$this->map->getCoAffiliatedKols(null,$arrFilterFields);
			$result = array_merge_recursive($result, $arrAffKols['connections']);
		}
		
		if(in_array('edu',$arrPubDegrees)){
			$arrEduKols=$this->map->getCoEducatedKols(null,$arrFilterFields);
			$result = array_merge_recursive($result, $arrEduKols['connections']);
		}
		
		if(in_array('org',$arrPubDegrees)){
			$arrOrgKols=$this->map->getCoOrganizedKols(null,$arrFilterFields);
			$result = array_merge_recursive($result, $arrOrgKols['connections']);
		}
		
		if(in_array('pub',$arrPubDegrees)){
			$arrPubKols=$this->map->getCoAuthoredKols(null,$arrFilterFields);
			$result = array_merge_recursive($result, $arrPubKols['connections']);
		}
		if(in_array('trial',$arrPubDegrees)){
			$arrTrialKols=$this->map->getCoTrialledKols(null,$arrFilterFields);
			$result = array_merge_recursive($result, $arrTrialKols['connections']);
		}
		
		$arrData = array();
		if(in_array('survey',$arrPubDegrees)){
			$arrFilterFields['survey_id'] = $this->input->post('survey_id');
			$arrSurveyKols = $this->map->getSurveyNomineesToRespondentConnnecionsMap(49,$arrFilterFields);
			$result = array_merge_recursive($result, $arrSurveyKols['connections']);
		}
		$arrData = $result;
		$timeTaken=microtime(true)-$startTime;
		//echo "Total time taken by query : ".$timeTaken."<br />";
		
		//Merge the connections count from different categories
		$arrConnectionCounts=$this->map->mergeConnectionCounts($arrPubKols['counts'],$arrEventKols['counts'],$arrAffKols['counts'],$arrEduKols['counts'],$arrOrgKols['counts'],$arrTrialKols['counts'],$arrSurveyKols['counts']);
		//pr($arrConnectionCounts);
		
		
		//Prepares the json data as rqured by the flare dependency graph
		$nodeData=array();
		$data=array();
		$arrConnectionsStrength = array();
		foreach($arrData as $key => $value){
			//Skip the kol if the kol don't have any connections
			if(sizeof($value) <= 0)
				continue;
			$value = array_unique($value);
			$idElements = explode("_",$key);
			$key = (int)$idElements[1];
			$nodeDetails=array();
//			$nodeDetails['name']="kol.".$arrKolDetails[$key][FIRST_ORDER]." ".$arrKolDetails[$key][SECOND_ORDER].".".$key;
			$nodeDetails['name']="kol.".$this->common_helpers->get_name_format($arrKolDetails[$key][FIRST_ORDER],$arrKolDetails[$key][SECOND_ORDER],$arrKolDetails[$key][THIRD_ORDER]).".".$key;
			$nodeDetails['kolId']=$key;
			$arrAdjecencies=array();
			$arrConnectionsCounts = array();
			$arrConnections = array();
			foreach($value as  $kolId){
				$connection = array();
				$connection['id'] =  $kolId;
				$connection['count'] = $arrConnectionCounts['kol_'.$key][$kolId];
				$arrConnections[] = $connection;
				//if the kol is not in the array of kol points. then skip the connection
				if (!array_key_exists('kol_'.$kolId, $arrData)) {
				    //$arrData[ $kolId]=array();
				    continue;
				} 
				$arrAdjecencies[]="kol.".$this->common_helpers->get_name_format($arrKolDetails[$kolId][FIRST_ORDER],$arrKolDetails[$kolId][SECOND_ORDER],$arrKolDetails[$kolId][THIRD_ORDER]).".".$kolId;
			}
			
			$nodeDetails['imports']=$arrAdjecencies;
			$nodeDetails['size']=sizeof($arrAdjecencies);
			//Skip the kol if all his connections are not in the list of matching kols
			if(sizeof($arrAdjecencies) > 0){
				$data[]=$nodeDetails;
				$arrConnectionsCounts['kolId'] = $key;
				$arrConnectionsCounts['connections'] = $arrConnections;
				$arrConnectionsStrength[] = $arrConnectionsCounts;
			}
		}
		
		$returnData[] = $data;
		$returnData[] = $arrConnectionsStrength;
		$returnData[] = $arrMicroviewDetails;
		
		$timeTaken=microtime(true)-$startTime;
		//echo "Total time taken for preparing data : ".$timeTaken."<br />";
		
		$arrAllNodes = $returnData[0];
		foreach($arrAllNodes as $c=>$key) {
	        $sort_numcie[] = $key['size'];
	        $sort_ref[] = $key['name'];
	    }
		array_multisort($sort_numcie, SORT_DESC, $sort_ref, SORT_STRING, $arrAllNodes);
		$returnData[0] = $arrAllNodes;
		
		ob_start('ob_gzhandler');
		echo json_encode($returnData);
	}
	
	function thejit_filter_influence_data_optimized($isFirstTime=null){
		ini_set('memory_limit', "-1");
		ini_set("max_execution_time", 0);
		$startTime=microtime(true);
		$arrFilterFields=array();
		$page=$this->input->post('page');
		$count=0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
		$searchType='';
		$keyword='';
		$name='';
		$arrPubDegrees=array();
		
		$arrCountries	=array();
		$arrStates	=array();
		$arrSpecialties	=array();
		
		if($isFirstTime != null){
				
			$viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
			if(sizeof($viewMyKols) > 0){
				$viewTypeMyKols = MY_RECORDS;
				$arrFilterFields['viewType'] = $viewMyKols;
			}else{
				$viewTypeMyKols = ALL_RECORDS;
			}
			$searchType=$this->input->post('search_type');
			$keyword=trim($this->session->userdata('keyword'));
//			$arrFilterFields=$this->session->userdata('arrMapFilterFields');
			$arrSavedFilters = array();
// 			$arrSavedFilters = $this->kol->getFilterByRecentApplied();
			$arrAppliedSavedFilters = $arrSavedFilters['arrFilterFields']; 
			if($arrSavedFilters['id'] != 0){
				
//				pr($arrAppliedSavedFilters);
				
				$arrFilterFields['specialty']=$arrAppliedSavedFilters['specialty'];		
				$arrFilterFields['country']=$arrAppliedSavedFilters['country'];
				$arrFilterFields['state']=$arrAppliedSavedFilters['state'];
				$arrFilterFields['organization']=$arrAppliedSavedFilters['organization'];
				$arrFilterFields['education']=$arrAppliedSavedFilters['education'];
				$arrFilterFields['event_id']=$arrAppliedSavedFilters['event_id'];
				$arrFilterFields['list_id']=$arrAppliedSavedFilters['list_id'];
				$arrFilterFields['profile_type']=$arrAppliedSavedFilters['profile_type'];
				
//				pr($arrFilterFields);
			}
			$arrPubDegrees=array('edu','org');
		}else{		
			$specialty		=	trim($this->input->post('specialty_id'));		
			$country		=	trim($this->input->post('country_id'));
			$state			=	trim($this->input->post('state_id'));
			$organization	=	trim($this->input->post('organization'));
			$education		=	trim($this->input->post('education'));
			$eventName		=	trim($this->input->post('event_name'));
			$listName		=	trim($this->input->post('list_name'));
			$profileType	=	trim($this->input->post('profile_type'));
			$viewTypeMyKols	=	trim($this->input->post('viewTypeMyKols'));
			$regionType 	= trim($this->input->post('region_type_id'));
			
			$arrPubDegrees	=	explode(",",$this->input->post('map_degrees'));
			//$arrPubDegrees = array('trial');
			$arrCountries	=	$this->input->post('countries');
			if($arrCountries!='')
				$arrCountries	=explode(",",$arrCountries);
			if($country!='')
				$arrCountries[]	=	$country;
			$arrStates	=	$this->input->post('states');
			if($arrStates!='')
				$arrStates	=explode(",",$arrStates);
			if($state!='')
				$arrStates[]	=	$state;
				
			//echo $specialty;
			$arrSpecialties	=	$this->input->post('specialties');
			if($arrSpecialties!='')
				$arrSpecialties	=explode(",",$arrSpecialties);
			if($specialty!=''){
				$arrSpecialties[]	=	$specialty;
			}
			$arrOrganizations	=	$this->input->post('organizations');
			if($arrOrganizations!='')
				$arrOrganizations	=explode(",",$arrOrganizations);
			if($organization!=''){
				$arrOrganizations[]	=	$organization;
			}
			
			$arrEducations	=	$this->input->post('educations');
			if($arrEducations!='')
				$arrEducations	=explode(",",$arrEducations);
			if($education!=''){
				$arrEducations[]	=	$education;
			}
			
			$arrEvents	=	$this->input->post('events');
			if($arrEvents!='')
				$arrEvents	=explode(",",$arrEvents);
			if($eventName!=''){
				$arrEvents[]	=	$eventName;
			}
			
			$arrLists	=	$this->input->post('lists');
			if($arrLists!='')
				$arrLists	=explode(",",$arrLists);
			if($listName!=''){
				if(stripos($listName, '(')){
					$arrListDetails=explode("(",$listName);
					$listName=trim($arrListDetails[0]);
					$categoryName=trim($arrListDetails[1],") ");
					$listName=$this->My_list_kol->getListName($listName,$categoryName);
				}
				$arrLists[]	=	$listName;
			}
			
			$arrRegionTypes	=	$this->input->post('region_types');
			if($arrRegionTypes!='')
				$arrRegionTypes	=explode(",",$arrRegionTypes);
				if($regionType!=''){
					$arrRegionTypes[]	=	$regionType;
				}
			//Prepare array of filter fields, ehich will be used for querying
			$arrFilterFields['specialty']=$arrSpecialties;		
			$arrFilterFields['country']=$arrCountries;
			$arrFilterFields['state']=$arrStates;
			$arrFilterFields['organization']=$arrOrganizations;
			//$arrFilterFields['education']=$this->kol->getInstituteId($education);
			//$arrFilterFields['event_id']=$this->kol->getEventLookupId($eventName);
			$arrFilterFields['education']=$arrEducations;
			$arrFilterFields['event_id']=$arrEvents;
			$arrFilterFields['list_id']=$arrLists;
			$arrFilterFields['event_name']=$eventName;
			$arrFilterFields['profile_type']=$profileType;
			$arrFilterFields['region'] 		= $arrRegionTypes;
			
			if($viewTypeMyKols == MY_RECORDS){
				$viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
				if(sizeof($viewMyKols) > 0){
					$viewTypeMyKols = MY_RECORDS;
					$arrFilterFields['viewType'] = $viewMyKols;
				}else{
					$arrFilterFields['viewType'] = array(0);
					$viewTypeMyKols = MY_RECORDS;
				}
			}else{
				$viewTypeMyKols = ALL_RECORDS;
			}
			
		}		
		$arrKolIds=array();
	
		$this->session->set_userdata('arrMapFilterFields',$arrFilterFields);
		$arrData=array();
		$arrPubKols=array();
		$arrEventKols=array();
		$arrAffKols=array();
		$arrEduKols=array();
		$arrOrgKols=array();
		$arrTrialKols=array();
		$arrSurveyKols=array();
		$result = array();

        $arrKolIds=array();
		$arrKeywords[0]=$name;
		$arrKolDetailResult=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,false,null,$arrKolIds,true);
		$arrKolDetails	=	array();
		$arrKolIds		=	array();
		foreach($arrKolDetailResult as $row){
			//echo $row['id']."";
			$arrKolDetails[$row['id']]=$row;
			$arrKolIds[]=$row['id'];
		}
		$startTime=microtime(true);
		
		$this->load->model('map');
		//$arrPubDegrees = array('org','edu','aff','event','pub','trial');
		if(in_array('event',$arrPubDegrees)){
			$arrEventKols=$this->map->getCoEventedKols(null,$arrFilterFields);
			$result = array_merge_recursive($result, $arrEventKols['connections']);
		}
		if(in_array('aff',$arrPubDegrees)){
			$arrAffKols=$this->map->getCoAffiliatedKols(null,$arrFilterFields);
			$result = array_merge_recursive($result, $arrAffKols['connections']);
		}
		
		if(in_array('edu',$arrPubDegrees)){
			$arrEduKols=$this->map->getCoEducatedKols(null,$arrFilterFields);
			$result = array_merge_recursive($result, $arrEduKols['connections']);
		}
		
		if(in_array('org',$arrPubDegrees)){
			$arrOrgKols=$this->map->getCoOrganizedKols(null,$arrFilterFields);
			$result = array_merge_recursive($result, $arrOrgKols['connections']);
		}
		if(in_array('pub',$arrPubDegrees)){
			$arrPubKols=$this->map->getCoAuthoredKols(null,$arrFilterFields);
			$result = array_merge_recursive($result, $arrPubKols['connections']);
		}
		if(in_array('trial',$arrPubDegrees)){
			$arrTrialKols=$this->map->getCoTrialledKols(null,$arrFilterFields);
			$result = array_merge_recursive($result, $arrTrialKols['connections']);
		}
		
		$arrData = array();
		if(in_array('survey',$arrPubDegrees)){
			$arrFilterFields['survey_id'] = $this->input->post('survey_id');
			$arrSurveyKols = $this->map->getSurveyNomineesToRespondentConnnecionsMap(49,$arrFilterFields);
			$result = array_merge_recursive($result, $arrSurveyKols['connections']);
		}
		$arrData = $result;
		
		$timeTaken=microtime(true)-$startTime;
		//echo "Total time taken by query : ".$timeTaken."<br />";
		
		//Merge the connections count from different categories
		$arrConnectionCounts=$this->map->mergeConnectionCounts($arrPubKols['counts'],$arrEventKols['counts'],$arrAffKols['counts'],$arrEduKols['counts'],$arrOrgKols['counts'],$arrTrialKols['counts'],$arrSurveyKols['counts']);
		//pr($arrConnectionCounts);
		
		//Prepares the Json data as required by the TheJit Radial/ForeceDirected graph
		$nodeData=array();
		$nodeData['$lineWidth']= 0;
		$nodeData['$color']="#fff";
		$nodeData['$dim']= 0;
		$nodeData['nocn']= 0;
		$data=array();
		$centerNode = array();
		$data['id']="dummy100";
		$data['name']="";
		$data['data']=$nodeData;
		$data['children'] = array();
		foreach($arrData as $key => $value){
			$value = array_unique($value);
			//echo "KolId : ".$key."<br>";
			$nodeData =array();
			$nodeData['$color']="#fff";
			$nodeData['connections']=sizeof($value);
			$nodeData['nocn']= 0;
			$nodeDetails=array();
			$idElements = explode("_",$key);
			$key = (int)$idElements[1];
			$nodeDetails['id']=$key;
			$nodeDetails['name']=$this->common_helpers->get_name_format($arrKolDetails[$key]['first_name'],$arrKolDetails[$key]['middle_name'],$arrKolDetails[$key]['last_name']);
			$nodeDetails['data']=$nodeData;
			$arrAdjecencies=array();
			foreach($value as $kolId){
				if (!array_key_exists('kol_'.$kolId, $arrData)) {
				    $arrData[$row['kol_id']]=array();
				    continue;
				} 
				$adjecent=array();
				$adjecent['id']=$kolId;
				$adjecent['name']=$this->common_helpers->get_name_format($arrKolDetails[$kolId]['first_name'],$arrKolDetails[$kolId]['middle_name'],$arrKolDetails[$kolId]['last_name']);
				$adjecentData=array();
				$adjecentData['ooc']=$arrConnectionCounts['kol_'.$key][$kolId];
				$adjecent['data']=$adjecentData;
				$adjecent['children'] = array();
				$arrAdjecencies[]=$adjecent;
			}
			$nodeDetails['children']=$arrAdjecencies;
			$nodeDetails['size']=sizeof($arrAdjecencies);
			$data['children'][]=$nodeDetails;
		}
		$arrAllNodes = $data['children'];
		foreach($arrAllNodes as $c=>$key) {
	        $sort_numcie[] = $key['size'];
	        $sort_ref[] = $key['name'];
	    }
		array_multisort($sort_numcie, SORT_DESC, $sort_ref, SORT_STRING, $arrAllNodes);
		$data['children'] = $arrAllNodes;
		
		ob_start('ob_gzhandler');
		echo json_encode($data);
		
		/*$startTime=microtime(true);
		$timeTaken=microtime(true)-$startTime;
		echo "Total time taken by query : ".$timeTaken."<br />";	*/
	}
	
	/**
	 * Gets the filter data for the influence map 
	 * @author 	Ramesh B
	 * @since	
	 * @return Array
	 * @created 11-07-11
	 */
	function reload_influence_filters_optimized($isFirstTime=null){
		ini_set('memory_limit', "-1");
		ini_set("max_execution_time",0);
		$arrOrganizations	= '';
		$arrEducations		= '';
		$arrEvents			= '';
		$arrLists			= '';
		$arrFilterFields=array();
		$page=$this->input->post('page');
		$count=0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
		$searchType='';
		$keyword='';
		$name='';
		$arrKeywords[0]=$name;
		
		$arrCountries	=array();
		$arrStates	=array();
		$arrSpecialties	=array();
		$arrCountries		= array();
		$arrStates			= array();
		$arrSpecialties		= array();
		$arrOrganizations	= array();
		$arrEducations		= array();
		$arrEvents			= array();
		$arrLists			= array();
		$arrOrganizations	= array();
			
		
		if($isFirstTime != null){
			$viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
			if(sizeof($viewMyKols) > 0){
				$viewTypeMyKols = MY_RECORDS;
				$arrFilterFields['viewType'] = $viewMyKols;
			}else{
				$viewTypeMyKols = ALL_RECORDS;
			}
			$searchType=$this->input->post('search_type');
			$keyword=trim($this->session->userdata('keyword'));
//			$arrFilterFields=$this->session->userdata('arrMapFilterFields');
//			$arrCountries = array(254,253);
//			$arrFilterFields['country']=$arrCountries;
			$arrSavedFilters = array();
// 			$arrSavedFilters = $this->kol->getFilterByRecentApplied();
			$arrAppliedSavedFilters = $arrSavedFilters['arrFilterFields']; 
			if($arrSavedFilters['id'] != 0){
				$arrFilterFields['specialty']=$arrAppliedSavedFilters['specialty'];		
				$arrFilterFields['country']=$arrAppliedSavedFilters['country'];
				$arrFilterFields['state']=$arrAppliedSavedFilters['state'];
				$arrFilterFields['organization']=$arrAppliedSavedFilters['organization'];
				$arrFilterFields['education']=$arrAppliedSavedFilters['education'];
				$arrFilterFields['event_id']=$arrAppliedSavedFilters['event_id'];
				$arrFilterFields['list_id']=$arrAppliedSavedFilters['list_id'];
				$arrFilterFields['kol_id']=$arrAppliedSavedFilters['kol_id'];
				$arrFilterFields['profile_type']=$arrAppliedSavedFilters['profile_type'];
				$arrFilterFields['savedFilterId']=$arrSavedFilters['id'];
			}	
			$arrPubDegrees=array('org','edu');
		}else{
			$specialty		=	trim($this->input->post('specialty_id'));		
			$country		=	trim($this->input->post('country_id'));
			$state			=	trim($this->input->post('state_id'));
			$organization	=	trim($this->input->post('organization'));
			$education		=	trim($this->input->post('education'));
			$eventName		=	trim($this->input->post('event_name'));
			$listName		=	trim($this->input->post('list_name'));
			$profileType	=	trim($this->input->post('profile_type'));
			$viewTypeMyKols = 	trim($this->input->post('viewTypeMyKols'));
			$regionType 	= 	trim($this->input->post('region_type_id'));
			
			$arrPubDegrees	=	explode(",",$this->input->post('map_degrees'));
			
			$arrRegionTypes	=	$this->input->post('region_types');
			if($arrRegionTypes!='')
				$arrRegionTypes	=explode(",",$arrRegionTypes);
				if($regionType!=''){
					$arrRegionTypes[]	=	$regionType;
				}
				
			$arrCountries	=	$this->input->post('countries');
			if($arrCountries!='')
				$arrCountries	=explode(",",$arrCountries);
			if($country!='')
				$arrCountries[]	=	$country;
				
			$arrStates	=	$this->input->post('states');
			if($arrStates!='')
				$arrStates	=explode(",",$arrStates);
			if($state!='')
				$arrStates[]	=	$state;
				
			//echo $specialty;
			$arrSpecialties	=	$this->input->post('specialties');
			if($arrSpecialties!='')
				$arrSpecialties	=explode(",",$arrSpecialties);
			if($specialty!=''){
				$arrSpecialties[]	=	$specialty;
			}
			$arrOrganizations	=	$this->input->post('organizations');
			if($arrOrganizations!='')
				$arrOrganizations	=explode(",",$arrOrganizations);
			if($organization!=''){
				$arrOrganizations[]	=	$organization;
			}
			
			$arrEducations	=	$this->input->post('educations');
			if($arrEducations!='')
				$arrEducations	=explode(",",$arrEducations);
			if($education!=''){
				$arrEducations[]	=	$education;
			}
			
			$arrEvents	=	$this->input->post('events');
			if($arrEvents!='')
				$arrEvents	=explode(",",$arrEvents);
			if($eventName!=''){
				$arrEvents[]	=	$eventName;
			}
			
			$arrLists	=	$this->input->post('lists');
			if($arrLists!='')
				$arrLists	=explode(",",$arrLists);
			if($listName!=''){
				if(stripos($listName, '(')){
					$arrListDetails=explode("(",$listName);
					$listName=trim($arrListDetails[0]);
					$categoryName=trim($arrListDetails[1],") ");
					$listName=$this->My_list_kol->getListName($listName,$categoryName);
				}
				$arrLists[]	=	$listName;
			}
			
			//Prepare array of filter fields, ehich will be used for querying
			$arrFilterFields['specialty']=$arrSpecialties;		
			$arrFilterFields['country']=$arrCountries;
			$arrFilterFields['state']=$arrStates;
			$arrFilterFields['organization']=$arrOrganizations;
			//$arrFilterFields['education']=$this->kol->getInstituteId($education);
			//$arrFilterFields['event_id']=$this->kol->getEventLookupId($eventName);
			$arrFilterFields['education']=$arrEducations;
			$arrFilterFields['event_id']=$arrEvents;
			$arrFilterFields['list_id']=$arrLists;
			$arrFilterFields['event_name']=$eventName;
			$arrFilterFields['profile_type'] = $profileType;
			$arrFilterFields['region'] 		= $arrRegionTypes;
			
			if($viewTypeMyKols == MY_RECORDS){
				$viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
				if(sizeof($viewMyKols) > 0){
					$viewTypeMyKols = MY_RECORDS;
					$arrFilterFields['viewType'] = $viewMyKols;
				}else{
					$arrFilterFields['viewType'] = array(0);
					$viewTypeMyKols = MY_RECORDS;
				}
			}else{
				$viewTypeMyKols = ALL_RECORDS;
			}
		}
		$arrKolIds=array();
		$arrKolDetailResult=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,false,null,$arrKolIds,true);
		//$arrKolDetailResult = $this->kol->getKolDetail();
		$arrKolDetails	=	array();
		foreach($arrKolDetailResult as $row){
			$arrKolDetails[$row['id']]=$row;
		}
		//pr($arrKolDetails);
		$this->session->set_userdata('arrMapFilterFields',$arrFilterFields);
		$arrData=array();
		$arrPubKols=array();
		$arrEventKols=array();
		$arrAffKols=array();
		$arrEduKols=array();
		$arrOrgKols=array();
		$arrTrialKols=array();
		$arrSurveyKols=array();
		$result = array();
		//Get the kols who has the connections
		//$arrPubDegrees = array('org','edu','aff','event','pub','trial');
		$this->load->model('map');
		if(in_array('event',$arrPubDegrees)){
			$arrEventKols=$this->map->getCoEventedKols();
			$result = array_merge_recursive($result, $arrEventKols['connections']);
		}
		
		if(in_array('aff',$arrPubDegrees)){
			$arrAffKols=$this->map->getCoAffiliatedKols();
			$result = array_merge_recursive($result, $arrAffKols['connections']);
		}
		
		if(in_array('edu',$arrPubDegrees)){
			$arrEduKols=$this->map->getCoEducatedKols();
			$result = array_merge_recursive($result, $arrEduKols['connections']);
		}
		
		if(in_array('org',$arrPubDegrees)){
			$arrOrgKols=$this->map->getCoOrganizedKols();
			$result = array_merge_recursive($result, $arrOrgKols['connections']);
		}
		
		if(in_array('pub',$arrPubDegrees)){
			$arrPubKols=$this->map->getCoAuthoredKols();
			$result = array_merge_recursive($result, $arrPubKols['connections']);
		}
		if(in_array('trial',$arrPubDegrees)){
			$arrTrialKols=$this->map->getCoTrialledKols();
			$result = array_merge_recursive($result, $arrTrialKols['connections']);
		}
		if(in_array('survey',$arrPubDegrees)){
			$arrFilterData['survey_id'] = $this->input->post('survey_id');
			$arrSurveyKols = $this->map->getSurveyNomineesToRespondentConnnecionsMap($arrFilterData['survey_id'],$arrFilterData);
			$result = array_merge_recursive($result, $arrSurveyKols['connections']);
		}
		//Prepare the kolIds who has the connections
		$arrKolIdStrings=array_keys($result);
		foreach($arrKolIdStrings as $idString){
			$idElements = explode("_",$idString);
			$arrKolIds[] = (int)$idElements[1];
			//$coIds = $result[$idString];
			//$arrKolIds = array_merge($arrKolIds, $coIds);
		}
		$arrKolIds = array_unique($arrKolIds);
		
		//Get count of kols grouping by category(for each category)
		$arrKolsByCountryCount=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'country',$arrKolIds);
		$arrKolsByStateCount=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'state',$arrKolIds);
		$arrKolsBySpecialtyCount=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'specialty',$arrKolIds);
		$arrKolsByOrgCount=array();//$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'organization',$arrKolIds);
		$arrKolsByEduCount=array();//$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'education',$arrKolIds);
		$arrKolsByEventCount=array();//$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'event',$arrKolIds);
		$arrKolsByListCount=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,true,'list',$arrKolIds);
		$arrRegionCount = $this->kol->getKolsLike1($arrKeywords, $arrFilterFields, $limit, $startFrom, false, true, 'region', $arrKolIds);
		
		//Preparing the kols by category results as required by the filter page and aso getting the total count for category
		$allCountryCount=0;
		$assoArrKolsByCountryCount=array();
		foreach($arrKolsByCountryCount as $row){
			$assoArrKolsByCountryCount[$row['country_id']]=$row;
			$allCountryCount+=$row['count'];
		}
		$allStateCount=0;
		$assoArrKolsByStateCount=array();
		foreach($arrKolsByStateCount as $row){
			$assoArrKolsByStateCount[$row['state_id']]=$row;
			$allStateCount+=$row['count'];
		}
		$allSpecialtyCount=0;
		$assoArrKolsBySpecialtyCount=array();
		foreach($arrKolsBySpecialtyCount as $row){
			$assoArrKolsBySpecialtyCount[$row['specialty']]=$row;
			$allSpecialtyCount+=$row['count'];
		}
		$allOrgCount=0;
		$assoArrKolsByOrgCount=array();
		foreach($arrKolsByOrgCount as $row){
			$assoArrKolsByOrgCount[$row['name']]=$row;
			$allOrgCount+=$row['count'];
		}
		$allEduCount=0;
		$assoArrKolsByEduCount=array();
		foreach($arrKolsByEduCount as $row){
			$assoArrKolsByEduCount[$row['institute_name']]=$row;
			$allEduCount+=$row['count'];
		}
		$allEventCount=0;
		$assoArrKolsByEventCount=array();
		foreach($arrKolsByEventCount as $row){
			$assoArrKolsByEventCount[$row['event_name']]=$row;
			$allEventCount+=$row['count'];
		}
		$allListCount=0;
		$assoArrKolsByListCount=array();
		foreach($arrKolsByListCount as $row){
			$assoArrKolsByListCount[$row['list_name_id']]=$row;
			$allListCount+=$row['count'];
		}
		$allRegionCount=0;
		$assoRegionCount=array();
		foreach($arrRegionCount as $row){
			$assoRegionCount[$row['GlobalRegion']]=$row;
			$allRegionCount+=$row['count'];
		}
		//Setting all the required data and forwording in to respective page
		$filterData['allCountryCount']=$allCountryCount;
		$filterData['allStateCount']=$allStateCount;
		$filterData['allSpecialtyCount']=$allSpecialtyCount;
		$filterData['allOrgCount']=$allOrgCount;
		$filterData['allEduCount']=$allEduCount;
		$filterData['allEventCount']=$allEventCount;
		$filterData['allListCount']=$allListCount;
		$filterData['allRegionCount'] = $allRegionCount;
		
		$filterData['arrKolsByCountryCount']=$assoArrKolsByCountryCount;
		$filterData['arrKolsByStateCount']=$assoArrKolsByStateCount;
		$filterData['arrKolsBySpecialtyCount']=$assoArrKolsBySpecialtyCount;
		$filterData['arrKolsByOrgCount']=$assoArrKolsByOrgCount;
		$filterData['arrKolsByEduCount']=$assoArrKolsByEduCount;
		$filterData['arrKolsByEventCount']=$assoArrKolsByEventCount;
		$filterData['arrKolsByListCount']=$assoArrKolsByListCount;
		$filterData['arrRegionCount']	=	$assoRegionCount;
		$filterData['selectedCountries']=$arrCountries;
		
		$selectedRegionTypes=array();
		foreach($arrRegionTypes as $values){
			$selectedRegionTypes[$values]=$values;
		}
		$filterData['selectedRegionTypes']=$selectedRegionTypes;
		$filterData['selectedStates']=$arrStates;
//		$filterData['selectedStates']=($arrSavedFilters['id'])?$arrSavedFilters['id']:0;
		$filterData['profileType']=$profileType;
		if($isFirstTime==null){
			$this->load->model("Specialty");
			$filterData['selectedSpecialties']=$this->Specialty->getSpecialtiesById($arrSpecialties);
		}else{
			$filterData['selectedSpecialties']=$arrSpecialties;
		}
		$filterData['viewType']=$viewTypeMyKols;
		$filterData['selectedOrgs']=$arrOrganizations;
		$filterData['selectedEdus']=$arrEducations;
		$filterData['selectedEvents']=$arrEvents;
		$filterData['selectedLists']=$this->My_list_kol->getListsById($arrLists);
		$filterData['mapSection']='';
		$filterData['customFilters']			= $this->kol->getAllCustomFilterByUser($this->session->userdata('user_id'));
		//pr($filterData);exit;
		$this->load->view('search/kol_filters_li_style',$filterData);
	}
	
/**
	 * Calculates a given kol influence with other co-autheras and influence amoung the co-authars of the kol
	 * @author 	Ramesh B
	 * @since	
	 * @return JSON
	 * @created 11-07-11
	 */	
	function get_kol_coauthors_influence_data_thejit_optimized($kolIdPassed=null){
		ini_set("memory_limit","200M");
		$fromYear=0;
		$toYear=0;
		$kolId = $kolIdPassed;
		$kolName = '';
		if($kolId == null){
			$kolName		= $this->input->post('influence_kol_name');
			//$value1=str_replace(" ","",$kolName);
			$kolId=$this->kol->getKolId($kolName);
		}else{
			$kolName = $this->kol->getKolName($kolId);
		}
		
		$this->load->model('map');
		$arrData = $this->map->getKolCoAuthorsToAutorsConnections($kolId);
		$arrKolAuthIds = $this->pubmed->getPossibleCoAuthorIdsForKol($kolId);
		
		//Ge all the kol who are co-authors for given kol publications
		$arrPubKols=$this->pubmed->getCoAuthoredKols($kolId);
		//pr($arrPubKols);
		$arrKolNames=array();
		foreach($arrPubKols as $row){
			$arrKolName = $this->kol->getKolName($row['kol_id']);
			$arrNameCombinations=$this->pubmed->generate_name_combinations($arrKolName['first_name'], $arrKolName['middle_name'], $arrKolName['last_name']);
			foreach($arrNameCombinations as $name){
				$arrKolNames[$name]=$row['kol_id'];
			}
		}
		
		//Prepares the Json data as required by the TheJit Radial/ForeceDirected graph
		$arrCoAuthorKOLIds = array();
		$nodeData=array();
		$nodeData['$lineWidth']= 5;
		$nodeData['$color']="#ddeeff";
		$nodeData['$dim']= 0;
		$data=array();
		$centerNode = array();
		$data['id']='kol_'.$kolId;
		$data['name']=$kolName['first_name']." ".$kolName['middle_name']." ".$kolName['last_name'];
		$data['data']=$nodeData;
		$data['children'] = array();
		foreach($arrData as $key => $value){
			if($key != $arrKolAuthIds[0]){
				//echo "KolId : ".$key."<br>";
				$nodeData =array();
				$nodeData['$color']="#555555";
				$nodeData['connections']=$arrData[$arrKolAuthIds[0]][$key]['conn'];
				$nodeDetails=array();
				$nodeDetails['id']=$key;
				$nodeDetails['data']=$nodeData;
				$nodeDetails['size']=sizeof($value);
				$nodeDetails['connections']=$arrData[$arrKolAuthIds[0]][$key]['conn'];
				$arrAdjecencies=array();
				foreach($value as $authId => $row){
					if($authId != $arrKolAuthIds[0]){
						$adjecent=array();
						$adjecent['id']=$authId;
						$adjecent['name']=$row['last_name2']." ".$row['fore_name2'];
						$adjecentData=array();
						$adjecentData['ooc']=$row['conn'];
						$adjecent['data']=$adjecentData;
						$adjecent['children'] = array();
						$arrAdjecencies[]=$adjecent;
						//KOL 
						if (array_key_exists($row['last_name2']." ".$row['fore_name2'],$arrKolNames)) {
						  	//$nodeData['kolid']=$arrKolNames[$arrKolCoAuthors[$key]['last_name']." ".$arrKolCoAuthors[$key]['initials']];
						  	//pr($arrKolNames[$arrKolCoAuthors[$key]['last_name']." ".$arrKolCoAuthors[$key]['initials']]);
						  	$arrCoAuthorKOLIds[$authId] = $arrKolNames[$row['last_name2']." ".$row['fore_name2']];
						 }
						 if($row['position2'] == 1 && $row['aff'] != '' && $row['aff'] != 'NA'){
						 	$arrCoAuthorsHavingAffiliation[] = $authId;
						 }
						$nodeDetails['name']=$row['last_name']." ".$row['fore_name'];
					}
				}
				$nodeDetails['children']=$arrAdjecencies;
				$data['children'][]=$nodeDetails;
			}
		}
		
		$arrAllNodes = $data['children'];
		foreach($arrAllNodes as $c=>$key) {
	        //$sort_numcie[] = $key['size'];
	        $sort_numcie[] = $key['connections'];
	        //$sort_ref[] = $key['name'];
	    }
		array_multisort($sort_numcie, SORT_DESC, $sort_ref, SORT_STRING, $arrAllNodes);
		$data['children'] = $arrAllNodes;
		
		$arrCoAuthorsHavingAffiliation = array_unique($arrCoAuthorsHavingAffiliation);
		$arrCoAuthorsHavingAffiliation = array_values($arrCoAuthorsHavingAffiliation);
		$retunData['connectionData'] = $data;
		$retunData['coAuthorsKOLIds'] = $arrCoAuthorKOLIds;
		$retunData['coAuthorsHavingAffiliation'] = $arrCoAuthorsHavingAffiliation;
		ob_start('ob_gzhandler');
		echo json_encode($retunData);
	}
	
	
	/**
	 * Calculates a given kol influence with other co-autheras and influence amoung the co-authars of the kol
	 * @author 	Ramesh B
	 * @since	
	 * @return JSON
	 * @created 11-07-11
	 */	
	function get_kol_coauthors_influence_data_optimized($kolIdPassed=null){
		ini_set("memory_limit","200M");
		$fromYear=0;
		$toYear=0;
		$kolId = $kolIdPassed;
		$kolName = '';
		if($kolId == null){
			$kolName		= $this->input->post('influence_kol_name');
			//$value1=str_replace(" ","",$kolName);
			$kolId=$this->kol->getKolId($kolName);
		}else{
			$kolName = $this->kol->getKolName($kolId);
		}
		
		$this->load->model('map');
		$arrData = $this->map->getKolCoAuthorsToAutorsConnections($kolId);
		$arrKolAuthIds = $this->pubmed->getPossibleCoAuthorIdsForKol($kolId);
		
		//Ge all the kol who are co-authors for given kol publications
		$arrPubKols=$this->pubmed->getCoAuthoredKols($kolId);
		$arrKolNames=array();
		foreach($arrPubKols as $row){
			$arrKolName = $this->kol->getKolName($row['kol_id']);
			$arrNameCombinations=$this->pubmed->generate_name_combinations($arrKolName['first_name'], $arrKolName['middle_name'], $arrKolName['last_name']);
			foreach($arrNameCombinations as $name){
				$arrKolNames[$name]=$row['kol_id'];
			}
		}
		
		$arrConnectionsStrength = array();
		$nodeData=array();
		$data=array();
		$affData = array();
		$parentNode=array();
		$parentNode['name']="kol.".$kolName['first_name']." ".$kolName['middle_name']." ".$kolName['last_name'].".".$kolId;
		$parentNode['size']=sizeof($arrData);
		$parentNode['totalconn']=sizeof($arrData);
		$parentNode['kolId']=$kolId;
		$arrParentAdjecencies=array();
		$arrParentAffAdjecencies=array();
		foreach($arrData as $key => $value){
			if($key != $arrKolAuthIds[0]){
				$authorNameP = '';
				$nodeDetails=array();
				$nodeDetails['size']=$arrData[$arrKolAuthIds[0]][$key]['conn'];
				$nodeDetails['totalconn']=sizeof($value);
				$nodeDetails['kolId']=0;
				
				$arrAdjecencies=array();
				$arrAffAdjecencies=array();
				$arrConnectionsCounts = array();
				$arrConnections = array();
				foreach($value as $authId => $row){
						$authorName = '';
						//based on the name avilability, construct a proper name
						$authorName =$row['last_name2']." ".$row['fore_name2'];
						
						$connection = array();
						$connection['id'] = $authId;
						$connection['count'] = $row['conn'];
						$arrConnections[] = $connection;
						//if the kol is not in the array of kol points. then skip the connection
						if (!array_key_exists($authId, $arrData)) {
						    //$arrData[$row['kol_id']]=array();
						    continue;
						}

						//based on the name avilability, construct a proper name
						$authorNameP =$row['last_name']." ".$row['fore_name'];
						$arrAdjecencies[]="kol.".$authorName.".".$authId;
					 	if($row['position2'] == 1 && $row['aff'] != '' && $row['aff'] != 'NA'){
						 	$arrAffAdjecencies[] = "kol.".$authorName.".".$authId;
						 }
				}
				$arrParentAdjecencies[]="kol.".$authorNameP.".".$key;
				if($row['aff'] != null && $row['aff'] != '')
					$arrParentAffAdjecencies[]="kol.".$authorNameP.".".$key;
				
				$nodeDetails['name']="kol.".$authorNameP.".".$key;
				if (array_key_exists($authorNameP,$arrKolNames)) {
				  	$nodeDetails['kolId']=$arrKolNames[$authorNameP];
				  	//pr($nodeDetails);
				 }
				$nodeDetails['imports']=$arrAdjecencies;
				$data[]=$nodeDetails;
				if($arrData[$arrKolAuthIds[0]][$key]['position2'] == 1 && $arrData[$arrKolAuthIds[0]][$key]['aff'] != '' && $arrData[$arrKolAuthIds[0]][$key]['aff'] != 'NA'){
					$nodeDetails['imports']=$arrAffAdjecencies;
					$affData[] = $nodeDetails;
				}
				
				$arrConnectionsCounts['kolId'] = $key;
				$arrConnectionsCounts['connections'] = $arrConnections;
				$arrConnectionsStrength[] = $arrConnectionsCounts;
			}
		}
		$parentNode['imports']=$arrParentAdjecencies;
		array_unshift($data, $parentNode);
		
		$affParentNode = $parentNode;
		$affParentNode['imports']=$arrParentAffAdjecencies;
		array_unshift($affData, $affParentNode);
		
		if($kolIdPassed == null){
			$returnData['influenceData']=$data;
			$returnData['kolId']=$kolId;
			ob_start('ob_gzhandler');
			echo json_encode($returnData);
		}
		else{
			$returnData[] = $data;
			$returnData[] = $arrConnectionsStrength;
			$returnData[] = $affData;
			ob_start('ob_gzhandler');
			echo json_encode($returnData);
		}
			
	}
	
	
	function view_influence_geo_map($kolId = null){
		$filterData=array();
		$filterData['allSpecialtyCount']= 1;
		$filterData['allCountryCount']	= 1;
		$filterData['allStateCount']	= 1;
		$filterData['allListCount']		= 1;
		$filterData['allOrgCount']		= 1;
		$filterData['allEduCount']		= 1;
		$filterData['allEventCount']	= 1;
		$filterData['arrKolsBySpecialtyCount']	= array();
		$filterData['arrKolsByCountryCount']	= array();
		$filterData['arrKolsByStateCount']		= array();
		$filterData['arrKolsByListCount']		= array();
		$filterData['arrKolsByOrgCount']		= array();
		$filterData['arrKolsByEduCount']		= array();
		$data['mapSection']						= '';
		$data['filterPage']						= 'search/kol_filters_li_style';
		$data['filterData']						= $filterData;
		$this->load->model('survey');
		$data['arrCompletedSurveys']	= $this->survey->getCompletedSurveys();
		$data['contentPage']					= 'maps/geo_influence_map';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited geographical influence map Page",
				'status' => STATUS_SUCCESS,
				'transaction_name' => "View geographical influence map of KTL"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/client_view',$data);
	}
	
	function geo_filter_influence_data_optimized($isFirstTime=null){
		ini_set('memory_limit', "-1");
		ini_set("max_execution_time", 0);
		$startTime=microtime(true);
		$arrFilterFields=array();
		$page=$this->input->post('page');
		$count=0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
		$searchType='';
		$keyword='';
		$name='';
		$arrPubDegrees=array();
		
		$arrCountries	=array();
		$arrStates	=array();
		$arrSpecialties	=array();
		
		if($isFirstTime != null){
		    $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
		    if(sizeof($viewMyKols) > 0){
		        $viewTypeMyKols = MY_RECORDS;
		        $arrFilterFields['viewType'] = $viewMyKols;
		    }else{
		        $viewTypeMyKols = ALL_RECORDS;
		    }
			$searchType=$this->input->post('search_type');
			$keyword=trim($this->session->userdata('keyword'));
//			$arrFilterFields=$this->session->userdata('arrMapFilterFields');
			$arrSavedFilters = array();
// 			$arrSavedFilters = $this->kol->getFilterByRecentApplied();
			$arrAppliedSavedFilters = $arrSavedFilters['arrFilterFields']; 
			if($arrSavedFilters['id'] != 0){
				$arrFilterFields['specialty']=$arrAppliedSavedFilters['specialty'];		
				$arrFilterFields['country']=$arrAppliedSavedFilters['country'];
				$arrFilterFields['state']=$arrAppliedSavedFilters['state'];
				$arrFilterFields['organization']=$arrAppliedSavedFilters['organization'];
				$arrFilterFields['education']=$arrAppliedSavedFilters['education'];
				$arrFilterFields['event_id']=$arrAppliedSavedFilters['event_id'];
				$arrFilterFields['list_id']=$arrAppliedSavedFilters['list_id'];
				$arrFilterFields['profile_type']=$arrAppliedSavedFilters['profile_type'];
			}
			$arrPubDegrees=array('edu','org');
			//$arrPubDegrees=array('trial');
		}else{		
			$specialty		=	trim($this->input->post('specialty_id'));		
			$country		=	trim($this->input->post('country_id'));
			$state			=	trim($this->input->post('state_id'));
			$organization	=	trim($this->input->post('organization'));
			$education		=	trim($this->input->post('education'));
			$eventName		=	trim($this->input->post('event_name'));
			$listName		=	trim($this->input->post('list_name'));
			$profileType	=	trim($this->input->post('profile_type'));
			$viewTypeMyKols	=   trim($this->input->post('viewTypeMyKols'));
			$regionType 	= 	trim($this->input->post('region_type_id'));
			
			$arrPubDegrees	=	explode(",",$this->input->post('map_degrees'));
			//$arrPubDegrees = ('trial');
			$arrCountries	=	$this->input->post('countries');
			if($arrCountries!='')
				$arrCountries	=explode(",",$arrCountries);
			if($country!='')
				$arrCountries[]	=	$country;
			$arrStates	=	$this->input->post('states');
			if($arrStates!='')
				$arrStates	=explode(",",$arrStates);
			if($state!='')
				$arrStates[]	=	$state;
				
			//echo $specialty;
			$arrSpecialties	=	$this->input->post('specialties');
			if($arrSpecialties!='')
				$arrSpecialties	=explode(",",$arrSpecialties);
			if($specialty!=''){
				$arrSpecialties[]	=	$specialty;
			}
			$arrOrganizations	=	$this->input->post('organizations');
			if($arrOrganizations!='')
				$arrOrganizations	=explode(",",$arrOrganizations);
			if($organization!=''){
				$arrOrganizations[]	=	$organization;
			}
			
			$arrEducations	=	$this->input->post('educations');
			if($arrEducations!='')
				$arrEducations	=explode(",",$arrEducations);
			if($education!=''){
				$arrEducations[]	=	$education;
			}
			
			$arrEvents	=	$this->input->post('events');
			if($arrEvents!='')
				$arrEvents	=explode(",",$arrEvents);
			if($eventName!=''){
				$arrEvents[]	=	$eventName;
			}
			
			$arrLists	=	$this->input->post('lists');
			if($arrLists!='')
				$arrLists	=explode(",",$arrLists);
			if($listName!=''){
				if(stripos($listName, '(')){
					$arrListDetails=explode("(",$listName);
					$listName=trim($arrListDetails[0]);
					$categoryName=trim($arrListDetails[1],") ");
					$listName=$this->My_list_kol->getListName($listName,$categoryName);
				}
				$arrLists[]	=	$listName;
			}
			
			$arrRegionTypes	=	$this->input->post('region_types');
			if($arrRegionTypes!='')
				$arrRegionTypes	=explode(",",$arrRegionTypes);
			if($regionType!=''){
					$arrRegionTypes[]	=	$regionType;
				}
			
			//Prepare array of filter fields, ehich will be used for querying
			$arrFilterFields['specialty']=$arrSpecialties;		
			$arrFilterFields['country']=$arrCountries;
			$arrFilterFields['state']=$arrStates;
			$arrFilterFields['organization']=$arrOrganizations;
			//$arrFilterFields['education']=$this->kol->getInstituteId($education);
			//$arrFilterFields['event_id']=$this->kol->getEventLookupId($eventName);
			$arrFilterFields['education']=$arrEducations;
			$arrFilterFields['event_id']=$arrEvents;
			$arrFilterFields['list_id']=$arrLists;
			$arrFilterFields['event_name']=$eventName;
			$arrFilterFields['profile_type']=$profileType;
			$arrFilterFields['region'] 		= $arrRegionTypes;
			
			if($viewTypeMyKols == MY_RECORDS){
			    $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
			    if(sizeof($viewMyKols) > 0){
			        $viewTypeMyKols = MY_RECORDS;
			        $arrFilterFields['viewType'] = $viewMyKols;
			    }else{
			        $arrFilterFields['viewType'] = array(0);
			        $viewTypeMyKols = MY_RECORDS;
			    }
			}else{
			    $viewTypeMyKols = ALL_RECORDS;
			}
		}
		$arrKolIds=array();
	
		$this->session->set_userdata('arrMapFilterFields',$arrFilterFields);
		$arrData=array();
		$arrPubKols=array();
		$arrEventKols=array();
		$arrAffKols=array();
		$arrEduKols=array();
		$arrOrgKols=array();
		$arrTrialKols=array();
		$arrSurveyKols=array();
		$result = array();

		$arrKolIds=array();
		$arrKeywords[0]=$name;
		$arrKolDetailResult=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,false,null,$arrKolIds,true);
// 		pr($arrKolDetailResult);
		$arrKolDetails	=	array();
		$arrKolIds		=	array();
		foreach($arrKolDetailResult as $row){
			//echo $row['id']."";
			$arrKolDetails[$row['id']]=$row;
			$arrKolIds[]=$row['id'];
		}
		$startTime=microtime(true);
		
		$this->load->model('map');
		//$arrPubDegrees = array('trial');
		if(in_array('event',$arrPubDegrees)){
			$arrEventKols=$this->map->getCoEventedKols(null,$arrFilterFields);
			$result = array_merge_recursive($result, $arrEventKols['connections']);
		}
		
		if(in_array('aff',$arrPubDegrees)){
			$arrAffKols=$this->map->getCoAffiliatedKols(null,$arrFilterFields);
			$result = array_merge_recursive($result, $arrAffKols['connections']);
		}
		
		if(in_array('edu',$arrPubDegrees)){
			$arrEduKols=$this->map->getCoEducatedKols(null,$arrFilterFields);
			$result = array_merge_recursive($result, $arrEduKols['connections']);
		}
		
		if(in_array('org',$arrPubDegrees)){
			$arrOrgKols=$this->map->getCoOrganizedKols(null,$arrFilterFields);
			$result = array_merge_recursive($result, $arrOrgKols['connections']);
		}
		
		if(in_array('pub',$arrPubDegrees)){
			$arrPubKols=$this->map->getCoAuthoredKols(null,$arrFilterFields);
			$result = array_merge_recursive($result, $arrPubKols['connections']);
		}
		if(in_array('trial',$arrPubDegrees)){
			$arrTrialKols=$this->map->getCoTrialledKols(null,$arrFilterFields);
			$result = array_merge_recursive($result, $arrTrialKols['connections']);
		}
		
		$arrData = array();
		if(in_array('survey',$arrPubDegrees)){
			$arrFilterFields['survey_id'] = $this->input->post('survey_id');
			$arrSurveyKols = $this->map->getSurveyNomineesToRespondentConnnecionsMap(49,$arrFilterFields);
			$result = array_merge_recursive($result, $arrSurveyKols['connections']);
		}
		$arrData = $result;
		//pr($arrData);
		$timeTaken=microtime(true)-$startTime;
		//echo "Total time taken by query : ".$timeTaken."<br />";
		
		//Merge the connections count from different categories
		$arrConnectionCounts=$this->map->mergeConnectionCounts($arrPubKols['counts'],$arrEventKols['counts'],$arrAffKols['counts'],$arrEduKols['counts'],$arrOrgKols['counts'],$arrTrialKols['counts'],$arrSurveyKols['counts']);
		//pr($arrConnectionCounts);
		$lats = array();
		$val =mt_rand(1, 10);
		$arrLongAndLat = array();
		$i=1;
		//pr($arrKolDetails);
		foreach($arrData as $key => $value){
			$value = array_unique($value);
			//echo "KolId : ".$key."<br>";
			
			
			$nodeDetails=array();
			$idElements = explode("_",$key);
			$key = (int)$idElements[1];
			
			
			if($arrKolDetails[$key]['city']!=''){
			
				if(in_array($arrKolDetails[$key]['lat'],$lats['lats'])){
					$val =mt_rand(1, 10);
					$random_num_lat = .00065 * mt_rand(1, 10);
					$random_num_lng = .00065 * mt_rand(1, 10);
					$lat1 =  $arrKolDetails[$key]['lat']+('0.00'.mt_rand(1, 10));
					$lang1 =  $arrKolDetails[$key]['lang']+('0.00'.mt_rand(1, 10));
					$lats['lats'][] =  $arrKolDetails[$key]['lat'];
					$arrKeyAndLat[$key]['lat']=$lat1;
					$arrKeyAndLat[$key]['lang']=$lang1;
					
				}else{
					$lat1 = $arrKolDetails[$key]['lat'];
					$lang1 =  $arrKolDetails[$key]['lang'];
					$lats['lats'][] =  $arrKolDetails[$key]['lat'];
				}
			}else{
				$lat1='';
				$lang1='';
			}
			$arrLongAndLat[$key]['id'] = $key;
			$arrLongAndLat[$key]['lat'] = $lat1;
			$arrLongAndLat[$key]['lang'] = $lang1;
//			$arrLongAndLat[$key]['name'] = $arrKolDetails[$key]['first_name']." ".$arrKolDetails[$key]['last_name'];
			$arrLongAndLat[$key]['name'] = $this->common_helpers->get_name_format($arrKolDetails[$key]['first_name'],$arrKolDetails[$key]['middle_name'],$arrKolDetails[$key]['last_name']);
			$arrLongAndLat[$key]['orgName'] = $arrKolDetails[$key]['name'];
			$arrLongAndLat[$key]['orgId'] = $arrKolDetails[$key]['org_id'];
			$arrLongAndLat[$key]['unique_id'] = $arrKolDetails[$key]['unique_id'];
			$arrLongAndLat[$key]['profileImage'] = $arrKolDetails[$key]['profile_image'];			
			$arrLongAndLat[$key]['gender']= $arrKolDetails[$key]['gender'];
			$arrAdjecencies=array();
			foreach($value as $kolId){
				
				
				if (!array_key_exists('kol_'.$kolId, $arrData)) {
				    //$arrData[$row['kol_id']]=array();
				    continue;
				} 
				
				if($arrKolDetails[$kolId]['city']!=''){
					if(in_array($arrKolDetails[$kolId]['lat'],$lats['lats'])){
						
						$val =mt_rand(1, 10);
						$random_num_lat = .00065 * mt_rand(1, 10);
						$random_num_lng = .00065 * mt_rand(1, 10);
						$lat = $arrKolDetails[$kolId]['lat']+('0.00'.mt_rand(1, 10));
						$lang = $arrKolDetails[$kolId]['lang']+('0.00'.mt_rand(1, 10));
						$lats['lats'][] = $lat;
						$lats['lags'][] = $lang;
						$arrKeyAndLat[$kolId]['lat']=$lat;
						$arrKeyAndLat[$kolId]['lang']=$lang;
					}else{
						$lat = $arrKolDetails[$kolId]['lat'];
						$lang = $arrKolDetails[$kolId]['lang'];
						
						$lats['lats'][] = $arrKolDetails[$kolId]['lat'];
						$lats['langs'][] = $arrKolDetails[$kolId]['lang'];
					}
				}else{
					$lat='';
					$lang='';
				}
				$adjecent=array();
				
				$arrLongAndLat[$key]['connections'][$kolId]['id']=$kolId;
				$arrLongAndLat[$key]['connections'][$kolId]['lat']=$lat;
				$arrLongAndLat[$key]['connections'][$kolId]['lang']=$lang;
				if(array_key_exists($kolId,$lats['lats'])){
				//	$arrLongAndLat[$key]['connections'][$kolId]['lat'] = $lats['lats'][$kolId];
				//	$arrLongAndLat[$key]['connections'][$kolId]['lang'] = $lats['langs'][$kolId];
				}
				$arrLongAndLat[$key]['connections'][$kolId]['city']=$arrKolDetails[$kolId]['city'];
//				$arrLongAndLat[$key]['connections'][$kolId]['name']=$arrKolDetails[$kolId]['first_name']." ".$arrKolDetails[$kolId]['last_name'];
				$arrLongAndLat[$key]['connections'][$kolId]['name']= $this->common_helpers->get_name_format($arrKolDetails[$kolId]['first_name'],$arrKolDetails[$kolId]['middle_name'],$arrKolDetails[$kolId]['last_name']);
				$arrLongAndLat[$key]['connections'][$kolId]['ooc']=$arrConnectionCounts['kol_'.$key][$kolId];
				$arrLongAndLat[$key]['connections'][$kolId]['orgName']=$arrKolDetails[$kolId]['name'];
				$arrLongAndLat[$key]['connections'][$kolId]['orgId']=$arrKolDetails[$kolId]['org_id'];
				$arrLongAndLat[$key]['connections'][$kolId]['unique_id']=$arrKolDetails[$kolId]['unique_id'];
				$arrLongAndLat[$key]['connections'][$kolId]['profileImage']=$arrKolDetails[$kolId]['profile_image'];
				
			}
			$arrLongAndLat[$key]['size'] = count($arrLongAndLat[$key]['connections']);
			$i++;
			
		}
		
		//echo count($arrLongAndLat);
		
		//pr($arrLongAndLat);
		
		foreach($arrLongAndLat as $key=>$value){
			if(array_key_exists($key,$arrKeyAndLat)){
				$arrLongAndLat[$key]['lat'] = $arrKeyAndLat[$key]['lat'];
				$arrLongAndLat[$key]['lang'] = $arrKeyAndLat[$key]['lang'];
			}
			
			foreach($value['connections'] as $key1=>$value1){
				
				if(array_key_exists($key1,$arrKeyAndLat)){
					$arrLongAndLat[$key]['connections'][$key1]['lat'] = $arrKeyAndLat[$key1]['lat'];
					$arrLongAndLat[$key]['connections'][$key1]['lang'] = $arrKeyAndLat[$key1]['lang'];
				}
				
				//if($arrLongAndLat[$key]['connections'][$key1]['city']==''){
					//$arrLongAndLat[$key]['connections'][$key1]['lat'] = '';
					//$arrLongAndLat[$key]['connections'][$key1]['lang'] = '';
				//}
				
			}
		}
		
		foreach($arrLongAndLat as $c=>$key) {
	        $sort_numcie[] = count($key['connections']);
	        $sort_ref[] = $key['name'];
	    }
		array_multisort($sort_numcie, SORT_DESC, $sort_ref, SORT_STRING, $arrLongAndLat);
		//echo count($arrLongAndLat);
		//pr($arrLongAndLat);
		$data['data'] = $arrLongAndLat;
		//0echo count($data['data']);
		//pr($data['data']);
		//echo count($data['data']);
		ob_start('ob_gzhandler');
		echo json_encode($data);
		
		/*$startTime=microtime(true);
		$timeTaken=microtime(true)-$startTime;
		echo "Total time taken by query : ".$timeTaken."<br />";	*/
	}
	
/**
	 * Calculates a given kol influence with other co-autheras and influence amoung the co-authars of the kol
	 * @author 	Ramesh B
	 * @since	
	 * @return JSON
	 * @created 11-07-11
	 */
	function get_geo_kol_influence_data($kolIdPassed=null){
		/*
		$arrFilterFields=array();
		$page=$this->input->post('page');
		$count=0;
		$limit=0;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
		$searchType='';
		$keyword='';
		$name='';
		$arrPubDegrees	=	explode(",",$this->input->post('map_degrees'));
	
		$kolId = $kolIdPassed;
		if($kolId == null){
			$kolName		= $this->input->post('influence_kol_name');
			//$value1=str_replace(" ","",$kolName);
			$kolId=$this->kol->getKolId($kolName);
		}
		
		$kolName = $this->kol->getKolName($kolId);
		
		$arrKolIds=array();
		$arrKeywords[0]=$name;
		
		if(sizeof($viewMyKols) > 0){
			$viewTypeMyKols = MY_RECORDS;
			$arrFilterFields['viewType'] = $viewMyKols;
		}else{
			$viewMyKols = $this->kol->getAllMyKolsViewByClient($this->session->userdata('user_id'));
			if (sizeof($viewMyKols) > 0) {
				$arrFilterFields['viewType'] = $viewMyKols;
			} else {
				$arrFilterFields['viewType'] = array(0);
			}
			$viewTypeMyKols = ALL_RECORDS;
		}
		
		$arrKolDetailResult=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,false,null,$arrKolIds,true);
		//pr($arrKolDetailResult);
		$arrKolDetails	=	array();
		foreach($arrKolDetailResult as $row){
			$arrKolDetails[$row['id']]=$row;
		}
		//pr($arrKolDetails);
		$arrData=array();
		$arrPubKols=array();
		$arrEventKols=array();
		$arrAffKols=array();
		$arrEduKols=array();
		$arrOrgKols=array();
		$arrTrialKols=array();
		//$arrPubDegrees = array('trial');		
		if(in_array('pub',$arrPubDegrees))
			$arrPubKols=$this->pubmed->getCoAuthoredKols($kolId);
		if(in_array('event',$arrPubDegrees))
			$arrEventKols=$this->kol->getCoEventedKols($kolId);
		if(in_array('aff',$arrPubDegrees))
			$arrAffKols=$this->kol->getCoAffiliatedKols($kolId);
		if(in_array('edu',$arrPubDegrees))
			$arrEduKols=$this->kol->getCoEducatedKols($kolId,$arrFilterFields);
		if(in_array('org',$arrPubDegrees))
			$arrOrgKols=$this->kol->getCoOrganizedKols($kolId,$arrFilterFields);
		if(in_array('trial',$arrPubDegrees))
			$arrTrialKols=$this->clinical_trial->getCoTrialledKols($kolId,$arrFilterFields);
		$arrKols=$this->get_unique_kolids_with_weightages($arrPubKols,$arrEventKols,$arrAffKols,$arrEduKols,$arrOrgKols,$arrTrialKols);
		if(sizeof($arrKols)>0){
			$arrData=$arrKols;
			
		}
		$nodeData=array();
		
		$data=array();
		
		$data['id']=$kolId;
		$data['lat'] = $arrKolDetails[$kolId]['lat'];
		$data['lang'] = $arrKolDetails[$kolId]['lang'];
		$data['name']=$kolName['first_name']." ".$kolName['middle_name']." ".$kolName['last_name'];
		$data['orgName']= $arrKolDetails[$kolId]['name'];
		$data['orgId']= $arrKolDetails[$kolId]['org_id'];
		$data['profileImage'] = '';
		if(file_exists("images/kol_images/resized/".$arrKolDetails[$kolId]['profile_image'])){
			$data['profileImage'] = $arrKolDetails[$kolId]['profile_image'];
		}
		$data['gender']= $arrKolDetails[$kolId]['gender'];
		$lats['lats'][]=$data['lat'];
		//pr($arrKolDetails);
		foreach($arrData as $key => $value){
			//echo "KolId : ".$key."<br>";
			$nodeData =array();
			
			$nodeDetails['id']=$key;
			$nodeDetails['name'] = $arrKolDetails[$key]['first_name']." ".$arrKolDetails[$key]['last_name'];
			$nodeDetails['orgName'] = $arrKolDetails[$key]['name'];
			$nodeDetails['orgId'] = $arrKolDetails[$key]['org_id'];
			$nodeDetails['profileImage'] = '';
			if(file_exists("images/kol_images/resized/".$arrKolDetails[$kolId]['profile_image'])){
				$nodeDetails['profileImage'] = $arrKolDetails[$key]['profile_image'];
			}
			
			$nodeDetails['gender'] = $arrKolDetails[$key]['gender'];
			
			
			if($arrKolDetails[$key]['city']!=''){
			if(in_array($arrKolDetails[$key]['lat'],$lats['lats'])){
					
					$val =mt_rand(1, 10);
					$random_num_lat = .00065 * mt_rand(1, 10);
					$random_num_lng = .00065 * mt_rand(1, 10);
					$lat = $arrKolDetails[$key]['lat']+('0.00'.mt_rand(1, 10));
					$lang =$arrKolDetails[$key]['lang']+('0.00'.mt_rand(1, 10));
					$lats['lats'][] = $lat;
					$lats['lags'][] = $lang;
					//$arrKeyAndLat[$kolId]['lat']=$lat;
					//$arrKeyAndLat[$kolId]['lang']=$lang;
				}else{
					$lat = $arrKolDetails[$key]['lat'];
					$lang = $arrKolDetails[$key]['lang'];
					$lats['lats'][] = $lat;
					$lats['lags'][] = $lang;
				}
			}else{
				$lat='';
				$lang='';
			}
			
			$nodeDetails['lat']  = $lat;
			$nodeDetails['lang']  = $lang;
			$data['connections'][$key]=$nodeDetails;
			
		}
// 		pr($data);
		$retunData['data'] = array($data);
		
		//$retunData['kolName'] = $arrKolDetails[$kolId]['first_name']." ".$arrKolDetails[$kolId]['last_name'];
		//$retunData['kolId'] = $kolId;
		//pr($data);
		ob_start('ob_gzhandler');
		echo json_encode($retunData);
		*/
		ini_set('memory_limit', "-1");
		ini_set("max_execution_time", 0);
		$startTime=microtime(true);
		$arrFilterFields=array();
		$page=$this->input->post('page');
		$count=0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		if($startFrom==-1)
        $startFrom=0;
        $searchType='';
        $keyword='';
        $name='';
        $arrPubDegrees=array();
        
        $arrCountries	=array();
        $arrStates	=array();
        $arrSpecialties	=array();
        $specialty		=	trim($this->input->post('specialty_id'));
        $country		=	trim($this->input->post('country_id'));
        $state			=	trim($this->input->post('state_id'));
        $organization	=	trim($this->input->post('organization'));
        $education		=	trim($this->input->post('education'));
        $eventName		=	trim($this->input->post('event_name'));
        $listName		=	trim($this->input->post('list_name'));
        $profileType	=	trim($this->input->post('profile_type'));
        $viewTypeMyKols	=   trim($this->input->post('viewTypeMyKols'));
        $regionType 	= 	trim($this->input->post('region_type_id'));
        
        $arrPubDegrees	=	explode(",",$this->input->post('map_degrees'));
        
        $kolId = $kolIdPassed;
        if($kolId == null){
            $kolName		= $this->input->post('influence_kol_name');
            //$value1=str_replace(" ","",$kolName);
            $kolId=$this->kol->getKolId($kolName);
        }
        $kolName = $this->kol->getKolName($kolId);
        //$arrPubDegrees = ('trial');
        $arrCountries	=	$this->input->post('countries');
        if($arrCountries!='')
            $arrCountries	=explode(",",$arrCountries);
        if($country!='')
            $arrCountries[]	=	$country;
            $arrStates	=	$this->input->post('states');
        if($arrStates!='')
            $arrStates	=explode(",",$arrStates);
        if($state!='')
            $arrStates[]	=	$state;
            
            //echo $specialty;
            $arrSpecialties	=	$this->input->post('specialties');
        if($arrSpecialties!='')
            $arrSpecialties	=explode(",",$arrSpecialties);
            if($specialty!=''){
                $arrSpecialties[]	=	$specialty;
            }
            $arrOrganizations	=	$this->input->post('organizations');
        if($arrOrganizations!='')
            $arrOrganizations	=explode(",",$arrOrganizations);
            if($organization!=''){
                $arrOrganizations[]	=	$organization;
            }
            
            $arrEducations	=	$this->input->post('educations');
        if($arrEducations!='')
            $arrEducations	=explode(",",$arrEducations);
            if($education!=''){
                $arrEducations[]	=	$education;
            }
            
            $arrEvents	=	$this->input->post('events');
        if($arrEvents!='')
            $arrEvents	=explode(",",$arrEvents);
            if($eventName!=''){
                $arrEvents[]	=	$eventName;
            }
            
            $arrLists	=	$this->input->post('lists');
        if($arrLists!='')
            $arrLists	=explode(",",$arrLists);
            if($listName!=''){
                if(stripos($listName, '(')){
                    $arrListDetails=explode("(",$listName);
                    $listName=trim($arrListDetails[0]);
                    $categoryName=trim($arrListDetails[1],") ");
                    $listName=$this->My_list_kol->getListName($listName,$categoryName);
                }
                $arrLists[]	=	$listName;
            }
            
            $arrRegionTypes	=	$this->input->post('region_types');
        if($arrRegionTypes!='')
            $arrRegionTypes	=explode(",",$arrRegionTypes);
            if($regionType!=''){
                $arrRegionTypes[]	=	$regionType;
            }
            
            //Prepare array of filter fields, ehich will be used for querying
            $arrFilterFields['specialty']=$arrSpecialties;
            $arrFilterFields['country']=$arrCountries;
            $arrFilterFields['state']=$arrStates;
            $arrFilterFields['organization']=$arrOrganizations;
            //$arrFilterFields['education']=$this->kol->getInstituteId($education);
            //$arrFilterFields['event_id']=$this->kol->getEventLookupId($eventName);
            $arrFilterFields['education']=$arrEducations;
            $arrFilterFields['event_id']=$arrEvents;
            $arrFilterFields['list_id']=$arrLists;
            $arrFilterFields['event_name']=$eventName;
            $arrFilterFields['profile_type']=$profileType;
            $arrFilterFields['region'] 		= $arrRegionTypes;
            
            if($viewTypeMyKols == MY_RECORDS){
                $viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
                if(sizeof($viewMyKols) > 0){
                    $viewTypeMyKols = MY_RECORDS;
                    $arrFilterFields['viewType'] = $viewMyKols;
                }else{
                    $arrFilterFields['viewType'] = array(0);
                    $viewTypeMyKols = MY_RECORDS;
                }
            }else{
                $viewTypeMyKols = ALL_RECORDS;
            }
		$arrKolIds=array();
		$arrKeywords[0]=$name;
		$arrKolDetailResult=$this->kol->getKolsLike1($arrKeywords,$arrFilterFields,$limit,$startFrom,false,false,null,$arrKolIds,true);
		//pr($arrKolDetailResult);
		$arrKolDetails	=	array();
		foreach($arrKolDetailResult as $row){
			$arrKolDetails[$row['id']]=$row;
		}
// 		pr($arrKolDetails);
		$arrData=array();
		$arrPubKols=array();
		$arrEventKols=array();
		$arrAffKols=array();
		$arrEduKols=array();
		$arrOrgKols=array();
		$arrTrialKols=array();
		//$arrPubDegrees = array('trial');
		if(in_array('pub',$arrPubDegrees))
			$arrPubKols=$this->pubmed->getCoAuthoredKols($kolId,$arrFilterFields);
		if(in_array('event',$arrPubDegrees))
			$arrEventKols=$this->kol->getCoEventedKols($kolId,$arrFilterFields);
		if(in_array('aff',$arrPubDegrees))
			$arrAffKols=$this->kol->getCoAffiliatedKols($kolId,$arrFilterFields);
		if(in_array('edu',$arrPubDegrees))
			$arrEduKols=$this->kol->getCoEducatedKols($kolId,$arrFilterFields);
		if(in_array('org',$arrPubDegrees))
			$arrOrgKols=$this->kol->getCoOrganizedKols($kolId,$arrFilterFields);
		if(in_array('trial',$arrPubDegrees))
			$arrTrialKols=$this->clinical_trial->getCoTrialledKols($kolId,$arrFilterFields);
		$arrKols=$this->get_unique_kolids_with_weightages($arrPubKols,$arrEventKols,$arrAffKols,$arrEduKols,$arrOrgKols,$arrTrialKols);
		if(sizeof($arrKols)>0){
			$arrData=$arrKols;
				
		}
	
	
		$nodeData=array();

		$data=array();

		$data['id']=$kolId;
		if(($arrKolDetails[$kolId]['lat']==null || $arrKolDetails[$kolId]['lat'] == '') || ($arrKolDetails[$kolId]['lang']==null || $arrKolDetails[$kolId]['lang']  == '')){
		    $data['lat'] = 0;
		    $data['lang'] = 0;
		}else{
		    $data['lat'] = $arrKolDetails[$kolId]['lat'];
		    $data['lang'] = $arrKolDetails[$kolId]['lang'];
		}
		$data['name']=$kolName['first_name']." ".$kolName['middle_name']." ".$kolName['last_name'];
		$data['orgName']= $arrKolDetails[$kolId]['name'];
		$data['orgId']= $arrKolDetails[$kolId]['org_id'];
		$data['profileImage']= $arrKolDetails[$kolId]['profile_image'];
		$data['unique_id']= $arrKolDetails[$kolId]['unique_id'];
		$lats['lats'][]=$data['lat'];
		//pr($arrKolDetails);
// 		pr($arrData);exit;
		foreach($arrData as $key => $value){
			//echo "KolId : ".$key."<br>";
			$nodeData =array();
			if (!array_key_exists($key, $arrKolDetails)) {
				continue;
			}	
			$nodeDetails['id']=$key;
			$nodeDetails['name'] = $arrKolDetails[$key]['first_name']." ".$arrKolDetails[$key]['last_name'];
			$nodeDetails['orgName'] = $arrKolDetails[$key]['name'];
			$nodeDetails['orgId'] = $arrKolDetails[$key]['org_id'];
			$nodeDetails['profileImage'] = $arrKolDetails[$key]['profile_image'];
			$nodeDetails['unique_id']= $arrKolDetails[$key]['unique_id'];
			$nodeDetails['connections']=$value['count'];
				
			if($arrKolDetails[$key]['city']!=''){
				if(in_array($arrKolDetails[$key]['lat'],$lats['lats'])){
				    if(($arrKolDetails[$key]['lat']==null || $arrKolDetails[$key]['lat'] == '') || ($arrKolDetails[$key]['lang']==null || $arrKolDetails[$key]['lang']  == '')){
				        $lats['lats'][] = 0;
				        $lats['lags'][] = 0;
				    }else{
    					$val =mt_rand(1, 10);
    					$random_num_lat = .00065 * mt_rand(1, 10);
    					$random_num_lng = .00065 * mt_rand(1, 10);
    					$lat = $arrKolDetails[$key]['lat']+('0.00'.mt_rand(1, 10));
    					$lang =$arrKolDetails[$key]['lang']+('0.00'.mt_rand(1, 10));
    					$lats['lats'][] = $lat;
    					$lats['lags'][] = $lang;
				    }
					//$arrKeyAndLat[$kolId]['lat']=$lat;
					//$arrKeyAndLat[$kolId]['lang']=$lang;
				}else{
				    if(($arrKolDetails[$key]['lat']==null || $arrKolDetails[$key]['lat'] == '') || ($arrKolDetails[$key]['lang']==null || $arrKolDetails[$key]['lang']  == '')){
				        $lats['lats'][] = 0;
				        $lats['lags'][] = 0;
				    }else{
    					$lat = $arrKolDetails[$key]['lat'];
    					$lang = $arrKolDetails[$key]['lang'];
    					$lats['lats'][] = $lat;
    					$lats['lags'][] = $lang;
				    }
				}
			}else{
				$lat=0;
				$lang=0;
			}
				
				
				
			$nodeDetails['lat']  = $lat;
			$nodeDetails['lang']  = $lang;
			$data['children'][$key]=$nodeDetails;
		}
		//pr($data);
		$retunData['data'] = $data;

		//$retunData['kolName'] = $arrKolDetails[$kolId]['first_name']." ".$arrKolDetails[$kolId]['last_name'];
		//$retunData['kolId'] = $kolId;
// 		pr($retunData);exit;
		ob_start('ob_gzhandler');
		echo json_encode($retunData);
	}
	
	function kol_microview_min($kolId){
		$arrKol	= $this->kol->getKolMicroData($kolId);
		$arrSalutations							= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']					= $arrSalutations;
		$arrKol[0]['id'] = $kolId;
		$data['arrKol'] = $arrKol[0];		
		$this->load->view("kols/kol_microview_min",$data);
	}
	
}