<input type="hidden" id="kol_ids" name="kol_ids" value="<?php echo $kol_ids;?>"/>
<label><input type="radio" name="type" class="exportType" value="profile" checked="checked"> Profile</label>
<label><input type="radio" name="type" class="exportType" value="list">Mailing List</label><br/><br/>
<div style="text-align: center;"><input type="button" name="next" value="Export" id="next" onclick="showExportType();"></div>


<form action="" id="kolExcelExport" method="post">
</form>