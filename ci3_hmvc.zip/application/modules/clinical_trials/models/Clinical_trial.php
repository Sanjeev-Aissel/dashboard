<?php
class clinical_trial extends CI_Model {
	function listClinicalTrialsDetailsByType($kolId,$type = null,$ctsId = null){
		$roleId=$this->session->userdata('user_role_id');
		$clientId=$this->session->userdata('client_id');
		$arrClinicalTrials=array();
		$this->db->select(array('clinical_trials.*','kol_clinical_trials.client_id','kol_clinical_trials.user_id','kol_clinical_trials.id as asoc_id','client_users.first_name','client_users.last_name','kol_clinical_trials.data_type_indicator'));
		$this->db->from('clinical_trials');
		$this->db->join('kol_clinical_trials', 'kol_clinical_trials.cts_id = clinical_trials.id','left');
		$this->db->join('client_users', 'client_users.id = kol_clinical_trials.user_id','left');
		$this->db->where('kol_id', $kolId);
		if($ctsId != 0){
			$this->db->where('clinical_trials.id', $ctsId);
		}
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("(kol_clinical_trials.client_id=$clientId or kol_clinical_trials.client_id=".INTERNAL_CLIENT_ID.")");
		}
		if($type == null || $type == 'verified'){
			$this->db->where('is_verified', 1);
		}elseif ($type == 'unverified'){
			$this->db->where('is_verified', 0);
		}elseif ($type == 'deleted'){
			$this->db->where('is_deleted', 1);
		}
		$arrClinicalTrialsResult = $this->db->get();
// 		echo $this->db->last_query();
		foreach($arrClinicalTrialsResult->result_array() as $row){
			$arrClinicalTrials[]=$row;
		}
		return 	$arrClinicalTrials;
	}
	function countTrials($kolId) {
		$count = '';
		$this->db->where('kol_id', $kolId);
		$this->db->where('is_verified', 1);
		if ($count = $this->db->count_all_results('kol_clinical_trials')) {
			return $count;
		} else {
			return $count;
		}
	}
	function listCTSponsors($ctId){
		$arrSponsors=array();
		$this->db->select('cts_sponsers.*');
		$this->db->from('cts_sponsers');
		$this->db->join('ct_sponsers', 'ct_sponsers.sponser_id = cts_sponsers.id','left');
		$this->db->where('type', 'lead sponsor');
		$this->db->where('cts_id', $ctId);
		$arrSponsorsResult = $this->db->get();
		foreach($arrSponsorsResult->result_array() as $row){
			$arrSponsors[]=$row;
		}
		return 	$arrSponsors;
	}
	function listCTInterventions($ctId){
		$arrInterventions=array();
		$this->db->select('cts_interventions.*');
		$this->db->from('cts_interventions');
		$this->db->join('ct_interventions', 'ct_interventions.intervention_id = cts_interventions.id','left');
		$this->db->where('cts_id', $ctId);
		$arrInterventionsResult = $this->db->get();
		foreach($arrInterventionsResult->result_array() as $row){
			$arrInterventions[]=$row;
		}
		return 	$arrInterventions;
	}
	function listCTInvestigators($ctId){
		$arrInvestigators=array();
		$this->db->select('cts_investigators.*');
		$this->db->from('cts_investigators');
		$this->db->join('ct_investigators', 'ct_investigators.investigator_id = cts_investigators.id','left');
		$this->db->where('cts_id', $ctId);
		$arrInvestigatorsResult = $this->db->get();
		foreach($arrInvestigatorsResult->result_array() as $row){
			$arrInvestigators[]=$row;
		}
		return 	$arrInvestigators;
	}
	function listClinicalTrialsDetails($kolId,$limit=null,$startFrom=null){
		$clientId=$this->session->userdata('client_id');
		$arrClinicalTrials=array();
		$this->db->select(array('clinical_trials.*','kol_clinical_trials.client_id','kol_clinical_trials.user_id','kol_clinical_trials.id as asoc_id'));
		$this->db->join('kol_clinical_trials', 'kol_clinical_trials.cts_id = clinical_trials.id','left');
		$this->db->where('kol_id', $kolId);
		if($clientId!=INTERNAL_CLIENT_ID){
			$this->db->where("(kol_clinical_trials.client_id=$clientId or kol_clinical_trials.client_id=".INTERNAL_CLIENT_ID.")");
		}
		if($limit != null)
			$this->db->limit($limit,$startFrom);
		$this->db->where('is_verified', 1);
		$arrClinicalTrialsResult = $this->db->get('clinical_trials');
		foreach($arrClinicalTrialsResult->result_array() as $row){
			$arrClinicalTrials[]=$row;
		}
		return 	$arrClinicalTrials;
	}
	function getStatusNameById($statusId){
		$statusName='';
		$this->db->where('id',$statusId);
		$arrStatuses=$this->db->get('cts_statuses');
		if($arrStatuses->num_rows()!=0){
			$statusObj=$arrStatuses->first_row();
			$statusName=$statusObj->status;
		}
		return $statusName;
	}
	function listCTIKeyWords($ctId){
		$arrKeyWords=array();
		$this->db->select('cts_keywords.*');
		$this->db->from('cts_keywords');
		$this->db->join('ct_keywords', 'ct_keywords.keyword_id = cts_keywords.id','left');
		$this->db->where('cts_id', $ctId);
		$arrKeyWordsResult = $this->db->get();
		foreach($arrKeyWordsResult->result_array() as $row){
			$arrKeyWords[]=$row;
		}
		return 	$arrKeyWords;
	}
	function listCTMeshTerms($ctId){
		$arrMeshTerms=array();
		$this->db->select('cts_mesh_terms.*');
		$this->db->from('cts_mesh_terms');
		$this->db->join('ct_mesh_terms', 'ct_mesh_terms.term_id = cts_mesh_terms.id','left');
		$this->db->where('cts_id', $ctId);
		$arrMeshTermsResult = $this->db->get();
		foreach($arrMeshTermsResult->result_array() as $row){
			$arrMeshTerms[]=$row;
		}
		return 	$arrMeshTerms;
	}	
	function deleteClientClinicalTrial($ctsId){
		$this->db->select('kol_id');
		$this->db->where('cts_id',$ctsId);
		$queryRes = $this->db->get('kol_clinical_trials');
		$row = $queryRes->row();
		if (isset($row))
		{
			if($row->kol_id > 0){
				$transactionName = 'Delete Clinical trails';
				$kol_org_type = 'Kol';
				$kols_or_org_id = $row->kol_id;
				$parentObjectId = $row->kol_id;
			}
		}
		$this->db->where('cts_id', $ctsId);
		if($this->db->delete('kol_clinical_trials')){
			return true;
		}else{
			return false;
		}
	}
	function getCoTrialledKols($arrKolIds=null){
		//Old Querry
		$arrKols=array();
		$this->db->select("trial2.kol_id, COUNT(kol_clinical_trials.cts_id) as count");
		$this->db->join('kol_clinical_trials as trial2','kol_clinical_trials.cts_id=trial2.cts_id','inner');
		$this->db->join('kols','trial2.kol_id = kols.id','left');
		$this->db->where('kol_clinical_trials.kol_id',$arrKolIds);
		$this->db->where('trial2.kol_id !=',$arrKolIds);
		// 		$this->db->where('kols.status',COMPLETED);
		$client_id = $this->session->userdata('client_id');
		if($client_id !== INTERNAL_CLIENT_ID){
			$this->db->join('kols_client_visibility', 'kols_client_visibility.kol_id = kols.id', 'left');
			$this->db->where('kols_client_visibility.client_id', $client_id);
		}
		$this->db->where('(kols.imported_as IS NULL or kols.imported_as = 2 or kols.imported_as = 0 or kols.imported_as = 3)', null, false);
		$this->db->where('(kols.deleted_by is null or kols.deleted_by=0)','',false);
		$this->db->group_by('trial2.kol_id');
		$results=$this->db->get('kol_clinical_trials');
		foreach($results->result_array() as $row){
			$arrKols[]=$row;
		}
		return $arrKols;
	}
	function getClinicalTrial($ctId){
		$clinicalTrial=array();
		$this->db->where('id',$ctId);
		$clinicalTrial=$this->db->get('clinical_trials');
		$clinicalTrial=$clinicalTrial->row_array();
		return 	$clinicalTrial;
	}
	function updateClinicalTrialManual($arrClinicalTrial){
		$this->db->where('id',$arrClinicalTrial['id']);
		if($this->db->update('clinical_trials',$arrClinicalTrial)){
			return true;
		}else{
			return false;
		}
	}
	function updateCtSponcers($arrClinicalTrial){
		if($this->db->query("update clinical_trials
							LEFT JOIN ct_sponsers ON clinical_trials.id=ct_sponsers.cts_id
							LEFT JOIN cts_sponsers ON cts_sponsers.id=ct_sponsers.sponser_id
							set cts_sponsers.agency='".$arrClinicalTrial['agency']."'
							WHERE clinical_trials.id=".$arrClinicalTrial['id']." and cts_sponsers.id=".$arrClinicalTrial['sponsorId'])){
							return true;
		}else{
			return false;
		}
	}
	function deleteSponsersAssoc($ctId,$arrSponserToExclude){
		$this->db->where('cts_id',$ctId);
		$this->db->where_not_in('sponser_id',$arrSponserToExclude);
		if($this->db->delete('ct_sponsers')){
			return true;
		}else{
			return false;
		}
	}
	function updateCtIntervention($arrClinicalTrial){
		if($this->db->query("update clinical_trials
							LEFT JOIN ct_interventions ON clinical_trials.id=ct_interventions.cts_id
							LEFT JOIN cts_interventions ON cts_interventions.id=ct_interventions.intervention_id
							set cts_interventions.name='".$arrClinicalTrial['name']."'
							WHERE clinical_trials.id=".$arrClinicalTrial['id']." and cts_interventions.id=".$arrClinicalTrial['interventionId'])){
							return true;
		}else{
			return false;
		}
	}
	function deleteInterventionsAssoc($ctId,$arrInterventionToExclude){
		$this->db->where('cts_id',$ctId);
		$this->db->where_not_in('intervention_id',$arrInterventionToExclude);
		if($this->db->delete('ct_interventions')){
			return true;
		}else{
			return false;
		}
	}
	function updateCtInvestigator($arrClinicalTrial){
		if($this->db->query("update clinical_trials
							LEFT JOIN ct_investigators ON clinical_trials.id=ct_investigators.cts_id
							LEFT JOIN cts_investigators ON cts_investigators.id=ct_investigators.investigator_id
							set cts_investigators.last_name='".$arrClinicalTrial['last_name']."'
							WHERE clinical_trials.id=".$arrClinicalTrial['id']." and cts_investigators.id=".$arrClinicalTrial['investigatorId'])){
							return true;
		}else{
			return false;
		}
	}
	function deleteInvestigatorsAssoc($ctId,$arrInvestigatorsToExclude){
		$this->db->where('cts_id',$ctId);
		$this->db->where_not_in('investigator_id',$arrInvestigatorsToExclude);
		if($this->db->delete('ct_investigators')){
			return true;
		}else{
			return false;
		}
	}
	function getKeywordIdByKeyword($keyword){
		$this->db->select('id');
		$this->db->where('name',$keyword);
		$resultSet	= $this->db->get('cts_keywords');
		if($resultSet->num_rows()!=0){
			$ctKeywordObj	= $resultSet->first_row();
			return $ctKeywordObj->id;
		}
		return false;
	}
	function deleteKeywordsAssoc($ctId,$arrKeywordsToExclude){
		$this->db->where('cts_id',$ctId);
		$this->db->where_not_in('keyword_id',$arrKeywordsToExclude);
		if($this->db->delete('ct_keywords')){
			return true;
		}else{
			return false;
		}
	}
	function getMeshTermIdByMeshTerm($meshterm){
		$this->db->select('id');
		$this->db->where('term_name',$meshterm);
		$resultSet	= $this->db->get('cts_mesh_terms');
		if($resultSet->num_rows()!=0){
			$ctKeywordObj	= $resultSet->first_row();
			return $ctKeywordObj->id;
		}
		return false;
	}
	function deleteTermsAssoc($ctId,$arrTermsToExclude){
		$this->db->where('cts_id',$ctId);
		$this->db->where_not_in('term_id',$arrTermsToExclude);
		if($this->db->delete('ct_mesh_terms')){
			return true;
		}else{
			return false;
		}
	}
	function saveIntervention($intervention){
		$interventionId=false;
		$this->db->select('id');
		$this->db->where('name',$intervention['name']);
		$resultSet	= $this->db->get('cts_interventions');
		if($resultSet->num_rows()!=0){
			$ctObj			= $resultSet->first_row();
			$interventionId	= $ctObj->id;
		}else if($this->db->insert('cts_interventions',$intervention)){
			$interventionId=$this->db->insert_id();
		}else{
			
		}
		return $interventionId;
	}
	function saveCtIntervention($ctIntervention){
		$this->db->select('id');
		$this->db->where('cts_id',$ctIntervention['cts_id']);
		$this->db->where('intervention_id',$ctIntervention['intervention_id']);
		$resultSet	= $this->db->get('ct_interventions');
		if($resultSet->num_rows()!=0){
			return true;
		}else if($this->db->insert('ct_interventions',$ctIntervention)){
			return true;
		}else{
			return false;
		}
	}	
	function saveSponser($sponser){
		$sponserId='';
		if(!isset($sponser['type'])){
			$sponser['type'] = "lead sponsor";
		}
		$this->db->select('id');
		$this->db->where('type',$sponser['type']);
		$this->db->where('agency',$sponser['agency']);
		if(isset($sponser['agency_class'])){
			$this->db->where('agency_class',$sponser['agency_class']);
		}
		$resultSet	= $this->db->get('cts_sponsers');
		if($resultSet->num_rows()!=0){
			$ctObj		= $resultSet->first_row();
			$sponserId	= $ctObj->id;
		}else if($this->db->insert('cts_sponsers',$sponser)){
			$sponserId	= $this->db->insert_id();
		}else{
			return false;
		}
		return $sponserId;
	}
	function saveCtSponser($ctSponcer){
		$sponserId='';
		$this->db->select('id');
		$this->db->where('cts_id',$ctSponcer['cts_id']);
		$this->db->where('sponser_id',$ctSponcer['sponser_id']);
		$resultSet	= $this->db->get('ct_sponsers');
		if($resultSet->num_rows()!=0){
			$ctObj		= $resultSet->first_row();
			$sponserId	= $ctObj->id;
		}else if($this->db->insert('ct_sponsers',$ctSponcer)){
			$sponserId = $this->db->insert_id();
		}else{
		}
		return $sponserId;
	}
	function saveInvestigator($investigator){
		$investigatorId='';
		if($this->db->insert('cts_investigators',$investigator)){
			$investigatorId=$this->db->insert_id();
		}else{
			
		}
		return $investigatorId;
	}
	function saveCtInvestigator($ctInvestigator){
		if($this->db->insert('ct_investigators',$ctInvestigator)){
			return true;
		}else{
			return false;
		}
	}
	function saveKeyword($keyword){
		$keywordId='';
		$this->db->select('id');
		$this->db->where('name',$keyword['name']);
		$resultSet	= $this->db->get('cts_keywords');
		if($resultSet->num_rows()!=0){
			$ctObj		= $resultSet->first_row();
			$keywordId	= $ctObj->id;
		}else if($this->db->insert('cts_keywords',$keyword)){
			$keywordId=$this->db->insert_id();
		}else{
			
		}
		return $keywordId;
	}
	function updateCtKeyword($existingKeywordId,$arrAssociateKeyword){
		if($existingKeywordId!=''){
			if($this->db->query("update ct_keywords
								set keyword_id='".$arrAssociateKeyword['keyword_id']."'
								WHERE cts_id=".$arrAssociateKeyword['cts_id']." and keyword_id=".$existingKeywordId)){
								return true;
			}
			else return false;
		}else{
			return false;
		}
	}
	function getManualCtid(){
		$ctid='';
		$this->db->select('max(id) as ctId');
		$returndPmid=$this->db->get('clinical_trials');
		if($returndPmid->num_rows() == 0){
			$ctid = 'MANCT1';
		}else{
			foreach($returndPmid->result_array() as $arrRow){
				$ctid = 'MANCT'.($arrRow['ctId'] + 1);
			}
		}
		return $ctid;
	}
	function saveClinicalTrialsManualAndFlags($ctDetails, $kolId){
		$ctId=$this->saveClinicalTrials($ctDetails);
		$kolClinicalTrials=array();
		$kolClinicalTrials['kol_id']=$kolId;
		$kolClinicalTrials['cts_id']=$ctId;
		$kolClinicalTrials['is_deleted']='0';
		$kolClinicalTrials['is_verified']='1';
		$kolClinicalTrials['client_id'] = INTERNAL_CLIENT_ID;
		$kolClinicalTrials['user_id'] = INTERNAL_USER_ID;
		$isSaved=$this->saveKolClinicalTrials($kolClinicalTrials);
		return $ctId;
	}
	function saveClinicalTrials($ctDetails){
		$ctId='';
		if($this->db->insert('clinical_trials',$ctDetails)){
			$ctId=$this->db->insert_id();
		}else{
			return false;
		}
		return $ctId;
	}
	function saveKolClinicalTrials($kolClinicalTrials){
		$clientId = $this->session->userdata('client_id');
		$userId = $this->session->userdata('user_id');
		$dataType = 'User Added';
		if($clientId == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		$kolClinicalTrials['data_type_indicator']	= $dataType;
		$kolClinicalTrials['client_id']	= $this->session->userdata('client_id');
		$kolClinicalTrials['user_id']	= $this->session->userdata('user_id');
		$this->db->insert('kol_clinical_trials',$kolClinicalTrials);
		$lastInsertId = $this->db->insert_id();
		if($lastInsertId > 0){
			return true;
		}else{
			return false;
		}
	}
	function saveSponsers($arrSponsers, $ctId){
		$isSaved=false;
		foreach($arrSponsers as $sponser){
			if(!isset($sponser['type']) || empty($sponser['type'])){
				$sponser['type']	= 'lead sponsor';
			}
			$sponserId=$this->saveSponser($sponser);
			$ctSponcer=array();
			$ctSponcer['cts_id']=$ctId;
			$ctSponcer['sponser_id']=$sponserId;
			$isSaved=$this->saveCtSponser($ctSponcer);
		}
		return $isSaved;
	}
	function saveInterventions($arrIntervention, $ctId){
		$isSaved=false;
		foreach($arrIntervention as $intervention){
			$interventionId=$this->saveIntervention($intervention);
			$ctIntervention=array();
			$ctIntervention['cts_id']=$ctId;
			$ctIntervention['intervention_id']=$interventionId;
			$isSaved=$this->saveCtIntervention($ctIntervention);
		}
		return $isSaved;
	}
	function saveInvestigators($arrInvestigators, $ctId){
		$isSaved=false;
		foreach($arrInvestigators as $investigator){
			$investigatorId=$this->saveInvestigator($investigator);
			
			$ctInvestigator=array();
			$ctInvestigator['cts_id']=$ctId;
			$ctInvestigator['investigator_id']=$investigatorId;
			
			$isSaved=$this->saveCtInvestigator($ctInvestigator);
		}
		return $isSaved;
	}
	function saveCtKeyword($ctKeyword){
		$this->db->select('id');
		$this->db->where('cts_id',$ctKeyword['cts_id']);
		$this->db->where('keyword_id',$ctKeyword['keyword_id']);
		$resultSet	= $this->db->get('ct_keywords');
		
		if($resultSet->num_rows()!=0){
			return true;
		}else if($this->db->insert('ct_keywords',$ctKeyword)){
			return true;
		}else{
			return false;
		}
	}
	function saveMeshterms($meshterms){
		$meshtermId	= '';
		$this->db->select('id');
		$this->db->where('term_name',$meshterms['term_name']);
		$this->db->where('type',$meshterms['type']);
		$resultSet	= $this->db->get('cts_mesh_terms');
		if($resultSet->num_rows()>0){
			$ctObj=$resultSet->first_row();
			$meshtermId	= $ctObj->id;
		}else {
			if($this->db->insert('cts_mesh_terms',$meshterms)){
				$meshtermId	= $this->db->insert_id();
			}
		}
		return $meshtermId;
	}
	function UpdateCtMeshterms($existingTermId,$arrAssociateMeshTerm){
		if($existingKeywordId!=''){
			if($this->db->query("update ct_mesh_terms
							set term_id='".$arrAssociateMeshTerm['term_id']."'
							WHERE cts_id=".$arrAssociateMeshTerm['cts_id']." and term_id=".$existingTermId)){
							return true;
			}
			else return false;
		}else{
			return false;
		}
	}
	function saveCtMeshterms($ctMeshterms){
		$this->db->select('id');
		$this->db->where('cts_id',$ctMeshterms['cts_id']);
		$this->db->where('term_id',$ctMeshterms['term_id']);
		$resultSet	= $this->db->get('ct_mesh_terms');
		if($resultSet->num_rows()!=0){
			return true;
		}else if($this->db->insert('ct_mesh_terms',$ctMeshterms)){
			return true;
		}else{
			return false;
		}
	}	
	function getUnprocessedTrials($processedOrUnprocessed){
		$arrClinicalTrials=array();
		$this->db->distinct("clinical_trials.id");
		$this->db->select('clinical_trials.*');
		$this->db->join("kol_clinical_trials","kol_clinical_trials.cts_id=clinical_trials.id","left");
		$this->db->where('kol_clinical_trials.is_verified', 1);
		$this->db->from('clinical_trials');
		if($processedOrUnprocessed == 0)
			$this->db->where('is_industry_trial', $processedOrUnprocessed);
			else if($processedOrUnprocessed == 1)
				$this->db->where('is_industry_trial !=', 0);
				//		$this->db->limit(100);
				//		$this->db->where('kol_clinical_trials.kol_id', 711);
				$arrClinicalTrialsResult = $this->db->get();
				//		echo $this->db->last_query();
				//		exit;
				foreach($arrClinicalTrialsResult->result_array() as $row){
					$arrClinicalTrials[]=$row;
				}
				return 	$arrClinicalTrials;
	}
}
?>