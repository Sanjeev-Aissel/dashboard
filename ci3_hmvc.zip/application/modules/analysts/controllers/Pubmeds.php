<?php
/**
 * @Author : Sanjeev K
 * @Desc : Controller for Publications data manipulation 
 * @Since : KOLM_hmvc 1.0
 * @Package : application.controllers
 * @Created : 13-06-2018
 * @Refactored : 13-06-2018
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class Pubmeds extends MX_Controller {
	
	private $loggedUserId = null;
	
	//Constructor
	public function __construct()
	{
		parent::__construct();
		
		$this->load->model('analysts/pubmed');
		$this->load->model('analysts/kol');
		$this->load->model('analysts/organization');
		$this->load->model('align_users/align_user');
		
		//variables
		$this->loggedUserId = $this->session->userdata('user_id');
		$this->clientId		=$this->session->userdata('client_id');
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : view_publications
	 * @Param  : $kolId
	 * @return : loads pubmed with in publications view
	 */
	function view_publications($kolId) {
		$data['isClientView']	= false;
	
		// Get the KOL details
		$arrKolDetail 	= $this->kol->editKol($kolId);
		$data['arrKol']	= $arrKolDetail;
	
		$arrSalutations	= array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
	
	
		//Analyst App to be accessed by only Aissel users.
		$this->common_helper->checkUsers();
		//$this->load->view('publications/list_publications', $data);
		$data['contentPage'] = 'pubmeds/list_publications';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	
	
	/**
	 * @Author : Sanjeev K
	 * @Method : parse_pub_details
	 * @Param  : $indvisKolId
	 * @return : process publications
	 */
	function parse_pub_details($publication){
		$pubDetails=array();
	
		$pmid='';
		$pmIdVersion='';
		$dateCreated=array();
		$dateCompleted=array();
		$dateRevised=array();
		$pubModel='NA';
		$issnNumber='NA';
		$issnType='NA';
		$citedMedium='NA';
		$volume='NA';
		$pubDate=array();
		$journalName='';
		$isoAbbreviation='NA';
		$articleTitle='NA';
		$abstractText='NA';
		$pagination='NA';
		$affiliation='NA';
		$authListComplete='';
		$language='NA';
		$articleDate=array();
		$citationSubset='NA';
		$numberOfReferences='NA';
		$otherID='';
		$status='NA';
		$link='';
		$isDeleted=0;
	
		$medlineCitation= $publication->getElementsByTagName('MedlineCitation')->item(0);
		$pubmedData= $publication->getElementsByTagName('PubmedData')->item(0);
	
		//$journalName=$medlineCitation->getElementsByTagName('Title')->item(0)->nodeValue;
		//$articleName=$medlineCitation->getElementsByTagName('ArticleTitle')->item(0)->nodeValue;
		$pmidObj=$medlineCitation->getElementsByTagName('PMID')->item(0);
		if($pmidObj!=null){
			$pmid=$pmidObj->nodeValue;
			if($pmidObj->hasAttributes()){
				$pmIdVersion=$pmidObj->attributes->item(0)->value;
			}
		}
	
		//get the date created
	
		/*$dateCreatedObj=$medlineCitation->getElementsByTagName('DateCreated')->item(0);
			if($dateCreatedObj!=null){
			$dateCreated['day']=$dateCreatedObj->getElementsByTagName('Day')->item(0)->nodeValue;
			$dateCreated['month']=$dateCreatedObj->getElementsByTagName('Month')->item(0)->nodeValue;
			$dateCreated['year']=$dateCreatedObj->getElementsByTagName('Year')->item(0)->nodeValue;
			}*/
		$dateCreated = '';
		$dateCreatedObj = $this->parse_pub_history($publication);
		foreach($dateCreatedObj as $date_created){
			if($date_created['status']=='pubmed'){
				$dateCreated = $date_created['dateOnly'];
			}
		}
		//get the date completed
	
		$dateCompletedObj=$medlineCitation->getElementsByTagName('DateCompleted')->item(0);
		if($dateCompletedObj!=null){
			$dateCompleted['day']=$dateCompletedObj->getElementsByTagName('Day')->item(0)->nodeValue;
			$dateCompleted['month']=$dateCompletedObj->getElementsByTagName('Month')->item(0)->nodeValue;
			$dateCompleted['year']=$dateCompletedObj->getElementsByTagName('Year')->item(0)->nodeValue;
		}
		//get the date revised
	
		$dateRevisedObj=$medlineCitation->getElementsByTagName('DateRevised')->item(0);
		if($dateRevisedObj!=null){
			$dateRevised['day']=$dateRevisedObj->getElementsByTagName('Day')->item(0)->nodeValue;
			$dateRevised['month']=$dateRevisedObj->getElementsByTagName('Month')->item(0)->nodeValue;
			$dateRevised['year']=$dateRevisedObj->getElementsByTagName('Year')->item(0)->nodeValue;
		}
	
		// Start Parsing article related data
		$articleObj=$medlineCitation->getElementsByTagName('Article')->item(0);
		if($articleObj!=null){
			if($articleObj->hasAttributes()){
				$pubModel=$articleObj->attributes->item(0)->value;
			}
			$issnObj=$articleObj->getElementsByTagName('ISSN')->item(0);
			if($issnObj!=null){
				$issnNumber=$issnObj->nodeValue;
				if($issnObj->hasAttributes()){
					$issnType=$issnObj->attributes->item(0)->value;
				}
			}
			$journalIssueObj=$articleObj->getElementsByTagName('JournalIssue')->item(0);
			if($journalIssueObj!=null){
				if($journalIssueObj->hasAttributes()){
					$citedMedium=$journalIssueObj->attributes->item(0)->value;
					//echo " citedMedium:".$citedMedium;
				}
				$volumeObj=$journalIssueObj->getElementsByTagName('Volume')->item(0);
				if($volumeObj!=null)
					$volume=$volumeObj->nodeValue;
					//get the PubDate
	
					$pubDateObj=$journalIssueObj->getElementsByTagName('PubDate')->item(0);
					if($pubDateObj!=null){
						$dayObj=$pubDateObj->getElementsByTagName('Day')->item(0);
						$pubDate['day']='';
						if($dayObj!=null)
							$pubDate['day']=$dayObj->nodeValue;
							$monthObj=$pubDateObj->getElementsByTagName('Month')->item(0);
							$pubDate['month']='';
							if($monthObj!=null)
								$pubDate['month']=$monthObj->nodeValue;
								$yearObj=$pubDateObj->getElementsByTagName('Year')->item(0);
								$pubDate['year']='';
								if($yearObj!=null)
									$pubDate['year']=$yearObj->nodeValue;
					}
			}
			$journalNameObj=$articleObj->getElementsByTagName('Title')->item(0);
			if($journalNameObj!=null)
				$journalName=$journalNameObj->nodeValue;
				$isoAbbreviationObj=$articleObj->getElementsByTagName('ISOAbbreviation')->item(0);
				if($isoAbbreviationObj!=null)
					$isoAbbreviation=$isoAbbreviationObj->nodeValue;
					$articleTitleObj=$articleObj->getElementsByTagName('ArticleTitle')->item(0);
					if($articleTitleObj!=null)
						$articleTitle=$articleTitleObj->nodeValue;
						//get the Abstract text
						$abstractTextObj=$articleObj->getElementsByTagName('AbstractText')->item(0);
						if($abstractTextObj!=null)
							$abstractText=$abstractTextObj->nodeValue;
							$paginationObj=$articleObj->getElementsByTagName('MedlinePgn')->item(0);
							if($paginationObj!=null)
								$pagination=$paginationObj->nodeValue;
								$affiliationObj=$articleObj->getElementsByTagName('Affiliation')->item(0);
								if($affiliationObj!=null)
									$affiliation=$affiliationObj->nodeValue;
									$authorListObj=$articleObj->getElementsByTagName('AuthorList')->item(0);
									if($authorListObj1=null){
										if($authorListObj->hasAttributes()){
											$authListComplete=$authorListObj->attributes->item(0)->value;
											//echo $authListComplete;
										}
									}
									$languageObj=$articleObj->getElementsByTagName('Language')->item(0);
									if($languageObj!=null)
										$language=$languageObj->nodeValue;
	
										$articleDateObj=$articleObj->getElementsByTagName('ArticleDate')->item(0);
										if($articleDateObj!=null){
											$dayObj=$articleDateObj->getElementsByTagName('Day')->item(0);
											$articleDate['day']='';
											if($dayObj!=null)
												$articleDate['day']=$dayObj->nodeValue;
												$monthObj=$articleDateObj->getElementsByTagName('Month')->item(0);
												$articleDate['month']='';
												if($monthObj!=null)
													$articleDate['month']=$monthObj->nodeValue;
													$yearObj=$articleDateObj->getElementsByTagName('Year')->item(0);
													$articleDate['year']='';
													if($yearObj!=null)
														$articleDate['year']=$yearObj->nodeValue;
										}
		}
		// End Parsing article related data
		$citationSubsetObj=$articleObj->getElementsByTagName('CitationSubset')->item(0);
		if($citationSubsetObj!=null)
			$citationSubset=$citationSubsetObj->nodeValue;
			$numberOfReferencesObj=$articleObj->getElementsByTagName('NumberOfReferences')->item(0);
			if($numberOfReferencesObj!=null)
				$numberOfReferences=$numberOfReferencesObj->nodeValue;
				$otherIDObj=$articleObj->getElementsByTagName('OtherID')->item(0);
				if($otherIDObj!=null)
					$otherID=$otherIDObj->nodeValue;
					$link="http://www.ncbi.nlm.nih.gov/pubmed/".$pmid;
					$statusObj=$articleObj->getElementsByTagName('PublicationStatus')->item(0);
					if($statusObj!=null)
						$status=$statusObj->nodeValue;
	
						//Prepare array represinting Publication details
						$pubDetails['pmid']=$pmid;
						//echo "</br>PMID: ".$pmid."</br>";
						$pubDetails['pmid_version']=$pmIdVersion;
						$pubDetails['created_date']=$dateCreated;//$this->array_to_date($dateCreated);
						$pubDetails['completed_date']=$this->array_to_date($dateCompleted);
						$pubDetails['revised_date']=$this->array_to_date($dateRevised);
						$pubDetails['pub_model']=$pubModel;
						$pubDetails['issn_number']=$issnNumber;
						$pubDetails['issn_type']=$issnType;
						$pubDetails['cited_medium']=$citedMedium;
						$pubDetails['volume']=$volume;
						//save the JournalName and get it's id
						//echo "</br>Journal Name: ".$journalName."</br>";
						$pubDetails['journal_id']=$this->pubmed->savejournalName($journalName);
						$pubDetails['iso_abbreviation']=$isoAbbreviation;
						$pubDetails['pub_date']=$this->array_to_date($pubDate);
						$pubDetails['article_title']=$articleTitle;
						$pubDetails['abstract_text']=$abstractText;
						$pubDetails['pagination']=$pagination;
						$pubDetails['affiliation']=$affiliation;
						$pubDetails['auth_list_complete']=$authListComplete;
						$pubDetails['language']=$language;
						$pubDetails['article_date']=$this->array_to_date($articleDate);
						$pubDetails['citation_subset']=$citationSubset;
						$pubDetails['Num_of_references']=$numberOfReferences;
						$pubDetails['other_id']=$otherID;
						$pubDetails['status']=$status;
						$pubDetails['link']=$link;
						$pubDetails['is_deleted']=$isDeleted;
						//End of preparing array
	
						return $pubDetails;
	}
	

	/**
	 * @Author : Sanjeev K
	 * @Method : save_publications
	 * @Param  : $pubDetails, $kolId, $isVerified
	 * @return : $pubId
	 * @deprecated : replaced with generic function
	 */
	/*function save_publications($pubDetails, $kolId, $isVerified = 0){
		//save the publication and get the publication id
		$pubId=$this->pubmed->savePublication($pubDetails);
		//echo 'Publication with PMID:'.$pubDetails['pmid'].' Not exist and it is Saved and Associated to KolId :'.$kolId.'</br>';
		//prepare the kol-to-publication association object
		$kolPublication=array();
		$kolPublication['kol_id']=$kolId;
		$kolPublication['pub_id']=$pubId;
		$kolPublication['is_deleted']=0;
		$kolPublication['is_verified']= $isVerified;
	
		//save the kol-to-publication record
		$isSaved=$this->pubmed->saveKolPublication($kolPublication);
		//return the publication Id
		return $pubId;
	}*/
	
	/**
	 * @Author : Sanjeev K
	 * @Method : save_publications( generaic used for both kol and org profiles)
	 * @Param  : $pubDetails, $id, $isVerified, $type
	 * @return : $pubId
	 */
	function save_publications($type, $pubDetails, $id, $isVerified = 0){
		//save the publication and get the publication id
		$pubId=$this->pubmed->savePublication($pubDetails);
		//echo 'Publication with PMID:'.$pubDetails['pmid'].' Not exist and it is Saved and Associated to KolId :'.$kolId.'</br>';
		
		//prepare the kol-to-publication association object
		$detailsToStore=array();
		$detailsToStore['pub_id']=$pubId;
		$detailsToStore['is_deleted']=0;
		$detailsToStore['is_verified']= $isVerified;
		
		//save the kol-to-publication record
		switch($type){
			case 'kol':
				$detailsToStore['kol_id']=$id;
				$isSaved=$this->pubmed->saveKolPublication($detailsToStore);
				break;
				
			case 'org':
				$detailsToStore['org_id']=$id;
				$isSaved=$this->pubmed->saveOrgPublication($detailsToStore);
				break;
		}
		
		//return the publication Id
		return $pubId;
	}

	/**
	 * @Author : Sanjeev K
	 * @Method : parse_pub_authors
	 * @Param  : $indvisKolId
	 * @return : process publications
	 */
	function parse_pub_authors($publication){
		$arrAuthors=array();
		$medlineCitation= $publication->getElementsByTagName('MedlineCitation')->item(0);
		$authors=$medlineCitation->getElementsByTagName('Author');
		if($authors!=null){
			foreach($authors as $authorObj){
				if($authorObj!=null){
					$author=array();
					$lastName='Not Available';
					$foreName='Not Available';
					$initials='Not Available';
					$suffix='Not Available';
					$is_name_valid='';
						
					$lastNameObj=$authorObj->getElementsByTagName('LastName')->item(0);
					if($lastNameObj!=null)
						$lastName=$lastNameObj->nodeValue;
					$foreNameObj=$authorObj->getElementsByTagName('ForeName')->item(0);
					if($foreNameObj!=null)
						$foreName=$foreNameObj->nodeValue;
					$initialsObj=$authorObj->getElementsByTagName('Initials')->item(0);
					if($initialsObj!=null)
						$initials=$initialsObj->nodeValue;
					$suffixObj=$authorObj->getElementsByTagName('Suffix')->item(0);
					if($suffixObj!=null)
						$suffix=$suffixObj->nodeValue;
					if($authorObj->hasAttributes()){
						$is_name_valid=$authorObj->attributes->item(0)->value;
					}
					$author['last_name']=$lastName;
					$author['fore_name']=$foreName;
					$author['initials']=$initials;
					$author['suffix']=$suffix;
					$author['is_name_valid']=$is_name_valid;
					$arrAuthors[]=$author;
				}
			}
		}
		return $arrAuthors;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : save_pub_authors
	 * @Param  : $arrAuthors, $pubId
	 * @return : none
	 */
	function save_pub_authors($arrAuthors, $pubId){
		$position=1;
		//Insert batch of authors,  i.e bulk insert
		//$this->db->insert_batch('pubmed_authors', $arrAuthors);
		$query= array();
	
		foreach( $arrAuthors as $row ) {
			$query[] = '("'.$row['last_name'].'", "'.$row['fore_name'].'", "'.$row['initials'].'", "'.$row['suffix'].'", "'.$row['is_name_valid'].'")';
		}
		//pr($query);
		//pr(implode(',', $query));
		if(sizeof($query) == 0)
			return;
			if($this->db->query('INSERT INTO pubmed_authors (last_name, fore_name, initials, suffix, is_name_valid) VALUES '.implode(',', $query))){
					
				$result = $this->db->query("select max(id) as id from pubmed_authors");
				$result = $result->first_row();
				$authId=$result->id;
				$authId = $authId - (sizeof($arrAuthors)-1);
				$arrPubAuthors = array();
				foreach($arrAuthors as $author){
					$pubAuthor = array();
					$pubAuthor['pub_id']=$pubId;
					$pubAuthor['author_id']=$authId;
					$pubAuthor['position']=$position;
					$pubAuthor['alias_id']=$authId;
					$position++;
					$authId++;
					$arrPubAuthors[] = $pubAuthor;
				}
	
				//Insert batch of  pub authors,  i.e bulk insert
				//$this->db->insert_batch('publications_authors', $arrPubAuthors);
				$query= array();
				foreach( $arrPubAuthors as $row ) {
					$query[] = '('.$row['pub_id'].', '.$row['author_id'].', '.$row['position'].', '.$row['alias_id'].')';
				}
				//pr($query);exit;
				$this->db->query('INSERT INTO publications_authors (pub_id, author_id, position, alias_id) VALUES '.implode(',', $query));
			}
	
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : parse_pub_meshterms
	 * @Param  : $indvisKolId
	 * @return : process publications
	 */
	function parse_pub_meshterms($publication){
		$arrMeshTerms=array();
		$medlineCitation=$publication->getElementsByTagName('MedlineCitation')->item(0);
		$meshTerms=$medlineCitation->getElementsByTagName('MeshHeading');
		foreach($meshTerms as $meshTermObj){
			if($meshTermObj!=null){
				$meshTerm=array();
				$discriptNameObj=$meshTermObj->getElementsByTagName('DescriptorName')->item(0);
				if($discriptNameObj!=null){
					$discriptName=$discriptNameObj->nodeValue;
					if($discriptNameObj->hasAttributes()){
						$isMajor=$discriptNameObj->attributes->item(1)->value;
					}
					$meshTerm['term_name']=$discriptName;
					$meshTerm['is_major']=$isMajor;
				}
	
				$arrQualifier=array();
				$qualifierNames=$meshTermObj->getElementsByTagName('QualifierName');
				foreach($qualifierNames as $qualifierNameObj){
					$isMajor="";
					$arrQualifierNames[]=$qualifierNameObj->nodeValue;
					if($qualifierNameObj!=null){
						$qualifier=array();
						$qualifierName=$qualifierNameObj->nodeValue;
						if($qualifierNameObj->hasAttributes()){
							$isMajor=$qualifierNameObj->attributes->item(1)->value;
						}
						$qualifier['term_name']=$qualifierName;
						$qualifier['is_major']=$isMajor;
						$arrQualifier[]=$qualifier;
					}
				}
				$meshTerm['arr_qualifier']=$arrQualifier;
				$arrMeshTerms[]=$meshTerm;
			}
		}
		return $arrMeshTerms;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : save_pub_meshterms
	 * @Param  : $arrMeshTerms, $pubId
	 * @return : insert $arrMeshTerms
	 */
	function save_pub_meshterms($arrMeshTerms, $pubId){
		$query= array();
		foreach($arrMeshTerms as $meshTerm){
			if($meshTerm!=null){
				$termId=0;
				$term=array();
				$term['term_name']=$meshTerm['term_name'];
				$term['parent_id']=$termId;
				// save parent MeshTerm into pubmed_meshTerm
				$termId=$this->pubmed->savePubmedMeshTerm($term);
	
				$pubTerm=array();
				$pubTerm['pub_id']=$pubId;
				$pubTerm['term_id']=$termId;
				$pubTerm['is_major']=($meshTerm['is_major']=='Y') ? 1:0 ;
				$query[] = '('.$pubTerm['pub_id'].', '.$pubTerm['term_id'].', '.$pubTerm['is_major'].')';
	
				$arrQualifier=array();
				$arrQualifier=$meshTerm['arr_qualifier'];
				$parentId=$termId;
				foreach($arrQualifier as $qualifier){
					$term=array();
					$term['term_name']=$qualifier['term_name'];
					$term['parent_id']=$parentId;
					// save parent MeshTerm into pubmed_meshTerm
					$termId=$this->pubmed->savePubmedMeshTerm($term);
						
					$pubTerm=array();
					$pubTerm['pub_id']=$pubId;
					$pubTerm['term_id']=$termId;
					$pubTerm['is_major']=($qualifier['is_major']=='Y') ? 1:0 ;
					$query[] = '('.$pubTerm['pub_id'].', '.$pubTerm['term_id'].', '.$pubTerm['is_major'].')';
				}
			}
		}
	
		if(sizeof($query) > 0)
			$this->db->query('INSERT INTO publication_mesh_terms (pub_id, term_id, is_major) VALUES '.implode(',', $query));
	
	
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : parse_pub_substances
	 * @Param  : $publication
	 * @return : $arrSubstances
	 */
	function parse_pub_substances($publication){
		$medlineCitation=$publication->getElementsByTagName('MedlineCitation')->item(0);
		$arrSubstances=array();
		$substances=$medlineCitation->getElementsByTagName('Chemical');
		if($substances!=null){
			foreach($substances as $substanceObj){
				if($substanceObj!=null){
					$substance=array();
					$regNumObj=$substanceObj->getElementsByTagName('RegistryNumber')->item(0);
					if($regNumObj!=null)
						$regNum=$regNumObj->nodeValue;
						$substanceNameObj=$substanceObj->getElementsByTagName('NameOfSubstance')->item(0);
						if($substanceNameObj!=null)
							$substanceName=$substanceNameObj->nodeValue;
							$substance['reg_num']=$regNum;
							$substance['name']=	$substanceName;
							$arrSubstances[]=$substance;
				}
			}
		}
		return $arrSubstances;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : save_pub_substances
	 * @Param  : $arrSubstances, $pubId
	 * @return : insert $arrSubstances
	 */
	function save_pub_substances($arrSubstances, $pubId){
		$query= array();
		foreach($arrSubstances as $substance){
			if($substance!=null){
				$substanceId=$this->pubmed->savePubmedSubstance($substance);
	
				$pubSubstance=array();
				$pubSubstance['pub_id']=$pubId;
				$pubSubstance['substance_id']=$substanceId;
	
				$query[] = '('.$pubSubstance['pub_id'].', '.$pubSubstance['substance_id'].')';
			}
		}
		if(sizeof($query) > 0)
			$this->db->query('INSERT INTO publication_substances (pub_id, substance_id) VALUES '.implode(',', $query));
	
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : parse_pub_types
	 * @Param  : $publication
	 * @return : $arrPubTypes
	 */
	function parse_pub_types($publication){
		$medlineCitation=$publication->getElementsByTagName('MedlineCitation')->item(0);
		$arrPubTypes=array();
		$publicationTypes=$medlineCitation->getElementsByTagName('PublicationType');
		if($publicationTypes!=null){
			foreach($publicationTypes as $publicationType){
				if($publicationType!=null){
					$pubType=array();
					$pubType['type']=$publicationType->nodeValue;
					$arrPubTypes[]=$pubType;
				}
			}
		}
		return $arrPubTypes;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : save_pub_types
	 * @Param  : $arrPubTypes, $pubId
	 * @return : isnert $arrPubTypes
	 */
	function save_pub_types($arrPubTypes, $pubId){
		$query= array();
		foreach($arrPubTypes as $type){
			if($type!=null){
				$typeId=$this->pubmed->savePubmedPubType($type);
	
				$pubType=array();
				$pubType['pub_id']=$pubId;
				$pubType['pub_type_id']=$typeId;
	
				$query[] = '('.$pubType['pub_id'].', '.$pubType['pub_type_id'].')';
			}
		}
		if(sizeof($query) > 0)
			$this->db->query('INSERT INTO publications_types (pub_id, pub_type_id) VALUES '.implode(',', $query));
	
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : parse_pub_CC
	 * @Param  : $publication
	 * @return : $arrCC
	 */
	function parse_pub_CC($publication){
		$medlineCitation=$publication->getElementsByTagName('MedlineCitation')->item(0);
		$arrCC=array();
		$arrCCObj=$medlineCitation->getElementsByTagName('CommentsCorrections');
		if($arrCCObj!=null){
			foreach($arrCCObj as $ccObj){
				if($ccObj!=null){
					$cc=array();
					$reftype='';
					$refSource='';
					$ccPMID='';
					$ccPMIDVersion='';
					if($ccObj->hasAttributes()){
						$reftype=$ccObj->attributes->item(0)->value;
					}
					$refSourceObj=$ccObj->getElementsByTagName('RefSource')->item(0);
					if($refSourceObj!=null)
						$refSource=$refSourceObj->nodeValue;
						$ccPMIDObj=$ccObj->getElementsByTagName('PMID')->item(0);
						if($ccPMIDObj!=null){
							$ccPMID=$ccPMIDObj->nodeValue;
							if($ccPMIDObj->hasAttributes()){
								$ccPMIDVersion=$ccPMIDObj->attributes->item(0)->value;
							}
						}
						$cc['ref_type']=$reftype;
						$cc['ref_source']=$refSource;
						$cc['cc_pmid']=$ccPMID;
						$cc['cc_pmid_version']=$ccPMIDVersion;
						$arrCC[]=$cc;
				}
			}
		}
		return $arrCC;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : save_pub_CC
	 * @Param  : $arrCC, $pubId
	 * @return : insert pub CC
	 */
	function save_pub_CC($arrCC, $pubId){
		$query= array();
		foreach( $arrCC as $row ) {
			if($row!=null){
				$query[] = '("'.custom_escape_string($row['ref_type']).'", "'.$row['ref_source'].'", "'.$row['cc_pmid'].'", "'.$row['cc_pmid_version'].'")';
			}
		}
		if(sizeof($query) == 0)
			return;
			if($this->db->query('INSERT INTO pubmed_cc (ref_type, ref_source, cc_pmid, cc_pmid_version) VALUES '.implode(',', $query))){
					
				$result = $this->db->query("select max(id) as id from pubmed_cc");
				$result = $result->first_row();
				$ccId=$result->id;
				$ccId = $ccId - (sizeof($arrCC)-1);
					
				$arrPubCCs = array();
				foreach($arrCC as $cc){
					if($cc!=null){
						$pubCC=array();
						$pubCC['pub_id']=$pubId;
						$pubCC['cc_id']=$ccId;
						$arrPubCCs[] = $pubCC;
						$ccId++;
					}
				}
				$query= array();
				foreach( $arrPubCCs as $row ) {
					$query[] = '('.$row['pub_id'].', '.$row['cc_id'].')';
				}
				$this->db->query('INSERT INTO publications_cc (pub_id, cc_id) VALUES '.implode(',', $query));
					
			}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : parse_pub_history
	 * @Param  : $publication
	 * @return : $arrHistory
	 */
	function parse_pub_history($publication){
		$arrHistory=array();
		$pubmedData= $publication->getElementsByTagName('PubmedData')->item(0);
		$historyObj=$pubmedData->getElementsByTagName('History')->item(0);
		if($historyObj!=null){
			$histories=$historyObj->getElementsByTagName('PubMedPubDate');
			if($histories!=null){
				foreach($histories as $historyObj){
					if($historyObj!=null){
						$pubHistory=array();
						$status='';
						$arrDateTime=array();
						$arrDate=array();
						if($historyObj->hasAttributes()){
							$status=$historyObj->attributes->item(0)->value;
						}
						$yearObj=$historyObj->getElementsByTagName('Year')->item(0);
						if($yearObj!=null){
							$arrDateTime['year']=$yearObj->nodeValue;
							$arrDate['year']=$yearObj->nodeValue;
						}
						$monthObj=$historyObj->getElementsByTagName('Month')->item(0);
						if($monthObj!=null){
							$arrDateTime['month']=$monthObj->nodeValue;
							$arrDate['month']=$monthObj->nodeValue;
						}
						$dayObj=$historyObj->getElementsByTagName('Day')->item(0);
						if($dayObj!=null){
							$arrDateTime['day']=$dayObj->nodeValue;
							$arrDate['day']=$dayObj->nodeValue;
						}
						$hourObj=$historyObj->getElementsByTagName('Hour')->item(0);
						if($hourObj!=null)
							$arrDateTime['hour']=$hourObj->nodeValue;
							$minuteObj=$historyObj->getElementsByTagName('Minute')->item(0);
							if($minuteObj!=null)
								$arrDateTime['minute']=$minuteObj->nodeValue;
								$pubHistory['status']=$status;
								$pubHistory['dateOnly']=$this->array_to_date($arrDate);
								$pubHistory['date']=$this->array_to_dattime($arrDateTime);
								$arrHistory[]=$pubHistory;
					}
				}
			}
		}
		return $arrHistory;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : save_pub_history
	 * @Param  : $arrHistory, $pubId
	 * @return : insert pub history
	 */
	function save_pub_history($arrHistory, $pubId){
		$query= array();
		foreach($arrHistory as $pubHistory){
			if($pubHistory!=null){
				$query[] = '("'.custom_escape_string($pubId).'", "'.$pubHistory['status'].'", "'.$pubHistory['date'].'")';
			}
		}
		$this->db->query('INSERT INTO publication_history (pub_id, status, date) VALUES '.implode(',', $query));
	
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : parse_pub_article_ids
	 * @Param  : $publication
	 * @return : $arrPubArticleIds
	 */
	function parse_pub_article_ids($publication){
		$arrPubArticleIds=array();
		$pubmedData= $publication->getElementsByTagName('PubmedData')->item(0);
		$articleIds=$pubmedData->getElementsByTagName('ArticleId');
		foreach($articleIds as $articleIdObj){
			if($articleIdObj!=null){
				$PubArticleId=array();
				$type='';
				$idValue='';
				if($articleIdObj->hasAttributes()){
					$type=$articleIdObj->attributes->item(0)->value;
				}
				$idValue=$articleIdObj->nodeValue;
				$PubArticleId['type']=$type;
				$PubArticleId['id_value']=$idValue;
				$arrPubArticleIds[]=$PubArticleId;
			}
		}
		return $arrPubArticleIds;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : save_pub_article_ids
	 * @Param  : $arrPubArticleIds, $pubId
	 * @return : insert pub article
	 */
	function save_pub_article_ids($arrPubArticleIds, $pubId){
		$query= array();
		foreach( $arrPubArticleIds as $row ) {
			if($row!=null){
				$query[] = '("'.custom_escape_string($row['type']).'", "'.$row['id_value'].'")';
			}
		}
		if(sizeof($query) == 0)
			return;
			if($this->db->query('INSERT INTO pubmed_article_ids (type, id_value) VALUES '.implode(',', $query))){
					
				$result = $this->db->query("select max(id) as id from pubmed_article_ids");
				$result = $result->first_row();
				$id=$result->id;
				$id = $id - (sizeof($arrPubArticleIds)-1);
	
				$arrPublicationArticleIds =array();
				foreach($arrPubArticleIds as $articleId){
					if($articleId!=null){
						$PubArticleId=array();
						$PubArticleId['pub_id']=$pubId;
						$PubArticleId['pub_article_id']=$id;
						$id++;
							
						$arrPublicationArticleIds[] = $PubArticleId;
					}
				}
				$query= array();
				foreach( $arrPublicationArticleIds as $row ) {
					if($row!=null){
						$query[] = '('.$row['pub_id'].', '.$row['pub_article_id'].')';
					}
				}
				$this->db->query('INSERT INTO publication_article_ids (pub_id, pub_article_id) VALUES '.implode(',', $query));
					
			}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : array_to_date
	 * @Param  : $arrayDate
	 * @return : $date
	 */
	function array_to_date($arrayDate){
		if(isset($arrayDate['month']) && $arrayDate['month']!=null)
			$arrayDate['month']=$this->month_to_integer($arrayDate['month']);
			$date='';
			if($arrayDate!=null){
				$date=$arrayDate['year']."-".$arrayDate['month']."-".$arrayDate['day'];
			}
			return $date;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : array_to_dattime
	 * @Param  : $arrDateTime
	 * @return : $date
	 */
	function array_to_dattime($arrDateTime){
		$date='';
		if($arrDateTime!=null){
			$date=$arrDateTime['year']."-".$arrDateTime['month']."-".$arrDateTime['day']." 00:00:00";
		}
		return $date;
	}
	
	function month_to_integer($month){
		if($month=='Jan')
			return 1;
		if($month=='feb')
			return 2;
		if($month=='mar')
			return 3;
		if($month=='apr')
			return 4;
		if($month=='may')
			return 5;
		if($month=='jun')
			return 6;
		if($month=='jul')
			return 7;
		if($month=='aug')
			return 8;
		if($month=='sep')
			return 9;
		if($month=='oct')
			return 10;
		if($month=='nov')
			return 11;
		if($month=='dec')
			return 12;
								
		return (int)$month;
	}
	/**
	 * @Author : Sanjeev K
	 * @Method : process_pubmeds
	 * @Param  : $indvisKolId
	 * @return : process publications
	 */
	function process_pubmeds($indvisKolId = null){
		//Analyst App to be accessed by only Aissel users.
		//$this->common_helpers->checkUsers();
		$this->logFilePath=	$_SERVER['DOCUMENT_ROOT'].'/'.$this->logFilePath;
		// Open the LogFile to write
		$this->startTime	= microtime(true);
		$this->logFileName	=$this->logFilePath . "/" . "logfile_".date("d-m-Y")."_". $this->startTime . ".txt";
		$this->logFile	= fopen($this->logFileName, "w");
		$this->logText	= "Processing Started on: " . date("d-m-Y H:i:s") . "\r\n";
		//Log Activity
		/*$arrLogDetails = array(
				'type'=>CRON_JOBS,
				'description'=>$this->logText,
				'status' => STATUS_SUCCESS,
				'transaction_table_id'=>'',
				'transaction_name'=>'Crawling Started'
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null, true);*/
		fwrite($this->logFile, $this->logText);
	
		$this->logFileNamePmidSkipped	=$this->logFilePath . "/skipped/" . "pmids_skipped_orgs_".date("d-m-Y").".txt";
		$this->logFilePmidSkipped	= fopen($this->logFileNamePmidSkipped, "w");
		fwrite($this->logFilePmidSkipped, $this->logText);
	
		ini_set("max_execution_time",$this->maxScriptTime);
		//$this->maxScriptTime = ini_get("max_execution_time");
	
		//Process the last crawled PMID
		$lastPmid = file_get_contents($this->logFilePath . "/last_pmid.txt");
		if(isset($lastPmid) && $lastPmid != '') {
			echo "Processing last PMID : ".$lastPmid."<br>";
			flush();
			$this->logText	= "Processing last PMID : ".$lastPmid."\r\n";
			//Log Activity
			/*$arrLogDetails = array(
					'type'=>CRON_JOBS,
					'description'=>$this->logText,
					'status' => STATUS_SUCCESS,
					'transaction_table_id'=>'',
					'transaction_id' => $lastPmid,
					'transaction_name'=>'Processing last PMID'
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null, true);*/
			fwrite($this->logFile, $this->logText);
			$this->recrawl_pmid($lastPmid);
		}
		//$this->logLastPmidFile = fopen($this->logFilePath . "/last_pmid.txt", "w");
	
		$this->logText	= "Processing KOLs with status Recrawl..  \r\n";
		fwrite($this->logFile, $this->logText);
		$this->processPubmedRecrawlKols();
		$this->logText	= "Recrawl Status KOLs processing completed..  \r\n";
		//Log Activity
		/*$arrLogDetails = array(
				'type'=>CRON_JOBS,
				'description'=>$this->logText,
				'status' => STATUS_SUCCESS,
				'transaction_table_id'=>'',
				'transaction_name'=>'Processing KOLs with status Recrawl'
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null, true);*/
		fwrite($this->logFile, $this->logText);
	
		//get the PubmedUnprocessed kol's
		if($indvisKolId != null)
			$arrKolDetails[] = $this->kol->editKol($indvisKolId);
			else
				$arrKolDetails=$this->pubmed->getPubmedUnprocessedKols();
				if(sizeof($arrKolDetails)<1){
					$this->logText	= "There are No Unprocessed KOL ids, Terminating Process..  \r\n";
					//Log Activity
					/*$arrLogDetails = array(
							'type'=>CRON_JOBS,
							'description'=>$this->logText,
							'status' => STATUS_SUCCESS,
							'transaction_table_id'=>'',
							'transaction_name'=>'Get the PubmedUnprocessed KOL'
					);
					$this->config->set_item('log_details', $arrLogDetails);
					log_user_activity(null, true);*/
					fwrite($this->logFile, $this->logText);
					$this->send_status_mail($this->logText);
					die("Sorry! There are No Unprocessed KOL ids, Terminating Process..");
				}
				$this->logText	= "Following are the Unprocessed KOL ids  \r\n";
				fwrite($this->logFile, $this->logText);
				foreach($arrKolDetails as $arrKolDetail){
					$this->logText	= $arrKolDetail['id']."  \r\n";
					//Log Activity
					/*$arrLogDetails = array(
							'type'=>CRON_JOBS,
							'description'=>$this->logText,
							'status' => STATUS_SUCCESS,
							'transaction_table_id'=>'',
							'transaction_name'=>'Following are the Unprocessed KOL ids'
					);
					$this->config->set_item('log_details', $arrLogDetails);
					log_user_activity(null, true);*/
					fwrite($this->logFile, $this->logText);
				}
				$firstName='';
				$midleName='';
				$lastName='';
				$this->logText	= "--------------------------------------------------------------------------------------------- \r\n";
				fwrite($this->logFile, $this->logText);
				//Start of loop trought each kol, generate name combinations, gather PMID's, get publications, parse and save data
				foreach($arrKolDetails as $arrKolDetail){
					$kolStartTime=microtime(true);
					$this->logText	= "\r\nStarting pubmed processing for KolId ".$arrKolDetail['id']." \r\n";
					fwrite($this->logFile, $this->logText);
						
					// get the name details
					$firstName=$arrKolDetail['first_name'];
					$midleName=$arrKolDetail['middle_name'];
					$lastName=$arrKolDetail['last_name'];
					$kolId=$arrKolDetail['id'];
						
					//get the different combinations of names
					if($indvisKolId != null)
						$arrNameCombinations = $this->pubmed->getKolNameCombinations($kolId);
						else
							$arrNameCombinations=$this->pubmed->generate_name_combinations($firstName, $midleName, $lastName);
								
								
								
							$this->logText	= "Kol Name: ".$firstName." ".$midleName." ".$lastName."  \r\n";
							fwrite($this->logFile, $this->logText);
							$this->logText	= "Following are the Name combinations genarated  \r\n";
							fwrite($this->logFile, $this->logText);
							foreach($arrNameCombinations as $nameCombination){
								$this->logText	= $nameCombination."  \r\n";
								fwrite($this->logFile, $this->logText);
							}
								
							//Get the list of PubMed ID's for each possible Author name and store it in a array
							$this->logText	= "\r\nStarting getting pmid's  \r\n";
							fwrite($this->logFile, $this->logText);
							$arrPMIDs=array();
							$count=0;
							$gathPMIDTime=microtime(true);
							foreach($arrNameCombinations as $authName){
								//Notes about url
								//Whenewer you encounter a space in url, repalce space with special charecter '%20', otherwise you may get wrong results
								$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retstart=0&retmax=1000&usehistory=y&retmode=xml&term=".str_replace(" ", "%20", $authName)."[author";
	
								$response = $this ->retrieve_page_get($url);
								//Try once again if the response of the status is false
								if($response['status'] == false){
									//give 2 second delay
									sleep($this->sleepTime);
									$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
									//Log Activity
									/*$arrLogDetails = array(
											'type'=>CRON_JOBS,
											'description'=>$this->logText,
											'status' => STATUS_FAIL,
											'transaction_table_id'=>'',
											'transaction_name'=>'Pubmed Processing',
											'miscellaneous1'=>$url
									);
									$this->config->set_item('log_details', $arrLogDetails);
									log_user_activity(null, true);*/
									fwrite($this->logFile, $this->logText);
									//try once again
									$response = $this ->retrieve_page_get($url);
								}
								// Skipp this and log the details if still respons is false
								if($response['status'] == false){
									//log the details
									$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next name, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
									//Log Activity
									/*$arrLogDetails = array(
											'type'=>CRON_JOBS,
											'description'=>$this->logText,
											'status' => STATUS_FAIL,
											'transaction_table_id'=>'',
											'transaction_name'=>'Pubmed Processing',
											'miscellaneous1'=>$url
									);
									$this->config->set_item('log_details', $arrLogDetails);
									log_user_activity(null, true);*/
									fwrite($this->logFile, $this->logText);
										
									$this->logText = "Name Combination Crawl : KolId Id - ".$kolId."  : Name : ".$authName."\r\n";
									fwrite($this->logFilePmidSkipped, $this->logText);
									//continue to next step
									continue;
								}
									
								$this->logText	= "Url Created ".$url."\r\n";
								fwrite($this->logFile, $this->logText);
									
								$xml = new DOMDocument();
	
								if(!$xml->loadXML($response['response'])){
									$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
									//Log Activity
									/*$arrLogDetails = array(
											'type'=>CRON_JOBS,
											'description'=>$this->logText,
											'status' => STATUS_FAIL,
											'transaction_table_id'=>'',
											'transaction_name'=>'Pubmed Processing',
											'miscellaneous1'=>$url
									);
									$this->config->set_item('log_details', $arrLogDetails);
									log_user_activity(null, true);*/
									fwrite($this->logFile, $this->logText);
										
									$response = $this ->retrieve_page_get($url);
									//Try once again if the response of the status is false
									if($response['status'] == false){
										//give 2 second delay
										sleep($this->sleepTime);
										$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
										//Log Activity
										/*$arrLogDetails = array(
												'type'=>CRON_JOBS,
												'description'=>$this->logText,
												'status' => STATUS_FAIL,
												'transaction_table_id'=>'',
												'transaction_name'=>'Pubmed Processing',
												'miscellaneous1'=>$url
										);
										$this->config->set_item('log_details', $arrLogDetails);
										log_user_activity(null, true);*/
										fwrite($this->logFile, $this->logText);
										//try once again
										$response = $this ->retrieve_page_get($url);
									}
									// Skipp this and log the details if still respons is false
									if($response['status'] == false){
										//log the details
										$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next name, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
										//Log Activity
										/*$arrLogDetails = array(
												'type'=>CRON_JOBS,
												'description'=>$this->logText,
												'status' => STATUS_FAIL,
												'transaction_table_id'=>'',
												'transaction_name'=>'Pubmed Processing',
												'miscellaneous1'=>$url
										);
										$this->config->set_item('log_details', $arrLogDetails);
										log_user_activity(null, true);*/
										fwrite($this->logFile, $this->logText);
	
										$this->logText = "Name Combination Crawl : KolId Id - ".$kolId."  : Name : ".$authName."\r\n";
										fwrite($this->logFilePmidSkipped, $this->logText);
										//continue to next step
										continue;
									}
										
									if(!$xml->loadXML($response['response'])){
										//log the details and continue
										$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next name, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
										//Log Activity
										/*$arrLogDetails = array(
												'type'=>CRON_JOBS,
												'description'=>$this->logText,
												'status' => STATUS_FAIL,
												'transaction_table_id'=>'',
												'transaction_name'=>'Pubmed Processing',
												'miscellaneous1'=>$url
										);
										$this->config->set_item('log_details', $arrLogDetails);
										log_user_activity(null, true);*/
										fwrite($this->logFile, $this->logText);
	
										$this->logText = "Name Combination Crawl : KolId Id - ".$kolId."  : Name : ".$authName."\r\n";
										fwrite($this->logFilePmidSkipped, $this->logText);
										continue;
										//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
									}
								}
	
								$idListObj = $xml->getElementsByTagName('IdList')->item(0);
								$idList=$idListObj->getElementsByTagName('Id');
								foreach($idList as $idObj){
									$arrPMIDs[]=$idObj->nodeValue;
								}
								$this->logText	= "No of PMID's found for name '".$authName."': ".(sizeof($arrPMIDs)-$count)."\r\n";
								fwrite($this->logFile, $this->logText);
								$count=sizeof($arrPMIDs);
								sleep($this->sleepTime);
							}
							$this->logText	= "Total No of PMIDs found: ".sizeof($arrPMIDs)." \r\n";
							fwrite($this->logFile, $this->logText);
							$timeTaken=microtime(true)-$gathPMIDTime;
							$this->logText	= "Time taken to gather PMIDs: ".(microtime(true)-$gathPMIDTime)."\r\n";
							fwrite($this->logFile, $this->logText);
	
							$arrUniquePMIDs = array_unique($arrPMIDs);
							$arrUniquePMIDs=array_values($arrUniquePMIDs);
							$this->logText	= "\r\nTotal No of PMIDs found after removing duplicates: ".sizeof($arrUniquePMIDs)." \r\n";
							fwrite($this->logFile, $this->logText);
							//End of getting the PubMed ID's
							// Reconnect the Database, to ensure that the DB connection is alive
							// On Jan 26, 2012, we faced an issue where the Publications were not getting crawled
							// MySQL idel timeout is 15-20 seconds
							$this->db->close();
							$this->db->initialize();
							//Check for already existing publication's and associate them with kol
							$arrFilteredPMIDs=$this->pubmed->checkAndAssociateAlreadyExistPubs($arrUniquePMIDs, $kolId,$arrKolDetail);
							$this->logText	= "Total No of PMIDs found after removing already existing publication's in database: ".sizeof($arrFilteredPMIDs)." \r\n";
							fwrite($this->logFile, $this->logText);
							//End of checking and associating already existing publications
								
								
							//Get the Publication details for all the PubMEd ID's, 10 at a time
							$this->logText	= "\r\nStart of getting the Publication details for each PMID, Processing ".$this->pmidBatchSize." at a time \r\n";
							fwrite($this->logFile, $this->logText);
							for($i=0; $i<sizeof($arrFilteredPMIDs);$i=$i+10){
								//for($i=0; $i<20;$i=$i+$this->pmidBatchSize){
								$authListText='';
								$arrAuthList = array();
								for($j=$i; $j<$i+$this->pmidBatchSize; $j++){
									if( $arrFilteredPMIDs[$j]!='')
										$arrAuthList[] = $arrFilteredPMIDs[$j];
								}
								$authListText = implode(",",$arrAuthList);
	
								$pubFetchStartTime=microtime(true);
								$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$authListText;
								$this->logText	= "Url generated: ".$url."\r\n";
								fwrite($this->logFile, $this->logText);
	
								if($authListText!='')
									$response = $this ->retrieve_page_get($url);
									//Try once again if the response of the status is false
									if($response['status'] == false){
										//give 2 second delay
										sleep($this->sleepTime);
										$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
										fwrite($this->logFile, $this->logText);
										//try once again
										$response = $this ->retrieve_page_get($url);
									}
									// Skipp this and log the details if still respons is false
									if($response['status'] == false){
										//log the details
										$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
										//Log Activity
										/*$arrLogDetails = array(
												'type'=>CRON_JOBS,
												'description'=>$this->logText,
												'status' => STATUS_FAIL,
												'transaction_table_id'=>'',
												'transaction_name'=>'Pubmed Processing',
												'miscellaneous1'=>$url
										);
										$this->config->set_item('log_details', $arrLogDetails);
										log_user_activity(null, true);*/
										fwrite($this->logFile, $this->logText);
											
										$this->logText = "Name Combination Crawl : KolId Id - ".$kolId."  : Pmids : ".$authListText."\r\n";
										fwrite($this->logFilePmidSkipped, $this->logText);
										//continue to next step
										continue;
									}
	
									$timeTaken=microtime(true)-$pubFetchStartTime;
									$this->logText	= "Time taken to fetch ".$this->pmidBatchSize." publications : ".$timeTaken."\r\n";
									fwrite($this->logFile, $this->logText);
									$xml = new DOMDocument();
	
									if(!$xml->loadXML($response['response'])){
										$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
										//Log Activity
										/*$arrLogDetails = array(
												'type'=>CRON_JOBS,
												'description'=>$this->logText,
												'status' => STATUS_FAIL,
												'transaction_table_id'=>'',
												'transaction_name'=>'Pubmed Processing',
												'miscellaneous1'=>$url
										);
										$this->config->set_item('log_details', $arrLogDetails);
										log_user_activity(null, true);*/
										fwrite($this->logFile, $this->logText);
											
										$response = $this ->retrieve_page_get($url);
										//Try once again if the response of the status is false
										if($response['status'] == false){
											//give 2 second delay
											sleep($this->sleepTime);
											$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
											//Log Activity
											/*$arrLogDetails = array(
													'type'=>CRON_JOBS,
													'description'=>$this->logText,
													'status' => STATUS_FAIL,
													'transaction_table_id'=>'',
													'transaction_name'=>'Pubmed Processing',
													'miscellaneous1'=>$url
											);
											$this->config->set_item('log_details', $arrLogDetails);
											log_user_activity(null, true);*/
											fwrite($this->logFile, $this->logText);
											//try once again
											$response = $this ->retrieve_page_get($url);
										}
										// Skipp this and log the details if still respons is false
										if($response['status'] == false){
											//log the details
											$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
											//Log Activity
											/*$arrLogDetails = array(
													'type'=>CRON_JOBS,
													'description'=>$this->logText,
													'status' => STATUS_FAIL,
													'transaction_table_id'=>'',
													'transaction_name'=>'Pubmed Processing',
													'miscellaneous1'=>$url
											);
											$this->config->set_item('log_details', $arrLogDetails);
											log_user_activity(null, true);*/
											fwrite($this->logFile, $this->logText);
	
											$this->logText = "Name Combination Crawl : KolId Id - ".$kolId."  : Pmids : ".$authListText."\r\n";
											fwrite($this->logFilePmidSkipped, $this->logText);
											//continue to next step
											continue;
										}
											
										if(!$xml->loadXML($response['response'])){
											//log the details and continue
											$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
											//Log Activity
											/*$arrLogDetails = array(
													'type'=>CRON_JOBS,
													'description'=>$this->logText,
													'status' => STATUS_FAIL,
													'transaction_table_id'=>'',
													'transaction_name'=>'Pubmed Processing',
													'miscellaneous1'=>$url
											);
											$this->config->set_item('log_details', $arrLogDetails);
											log_user_activity(null, true);*/
											fwrite($this->logFile, $this->logText);
	
											$this->logText = "Name Combination Crawl : KolId Id - ".$kolId."  : Pmids : ".$authListText."\r\n";
											fwrite($this->logFilePmidSkipped, $this->logText);
											continue;
											//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
										}
									}
	
									//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
									$this->logText	= "Following Publications with PMID's are parsed and saved sucessfully\r\n ";
									fwrite($this->logFile, $this->logText);
									$publications = $xml->getElementsByTagName('PubmedArticle');
									foreach($publications as $publication){
										$timeElapsed = (microtime(true) - $this->startTime);
										$remTime	=$this->maxScriptTime-$timeElapsed;
										//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed
										if($remTime<$this->safeTime){
											$this->logText	= "Stopping the pubmed processing, Timelimit reached.\r\n ";
											fwrite($this->logFile, $this->logText);
											//die("Sorry! Stopping the pubmed processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);
											$this->send_status_mail($this->logText);
											redirect(base_url()."pubmeds_org/process_pubmeds");
										}
										$pubStartTime=microtime(true);
										//parse and save publication details
										$pubDetails=$this->parse_pub_details($publication);
										$pubId=$this->save_publications('kol', $pubDetails, $kolId);
										if($pubId!=null){
											//$this->logText	= "Publication with PMID:".$pubDetails['pmid']." parsed and saved sucessfully\r\n ";
											//fwrite($this->logFile, $this->logText);
										}else{
											$this->logText	= "Error in parsing and saving the Publication with PMID:".$pubDetails['pmid']." \r\n ";
											//Log Activity
											/*$arrLogDetails = array(
													'type'=>CRON_JOBS,
													'description'=>$this->logText,
													'status' => STATUS_FAIL,
													'transaction_table_id'=>'',
													'transaction_name'=>'Pubmed Processing',
													'miscellaneous1'=>$url
											);
											$this->config->set_item('log_details', $arrLogDetails);
											log_user_activity(null, true);*/
											fwrite($this->logFile, $this->logText);
											continue;
										}
										//log the last PMID parsed
										file_put_contents($this->logFilePath . "/last_pmid.txt",$pubDetails['pmid']);
											
										//parse and save 'publication-authors'
										$arrAuthors=$this->parse_pub_authors($publication);
										$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
											
										//Calculate Authorship position and save
										$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail);
										$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
											
										//parse and save MeshTerms
										$arrMeshTerms=$this->parse_pub_meshterms($publication);
										$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
											
										//parse and save 'Substances(chemicals)'
										$arrSubstances=$this->parse_pub_substances($publication);
										$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
											
										//parse and save 'Publication types'
										$arrPubTypes=$this->parse_pub_types($publication);
										$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
											
										//parse and save 'CommentsCorrections(CC)'
										$arrCC=$this->parse_pub_CC($publication);
										$isSaved=$this->save_pub_CC($arrCC, $pubId);
											
										//parse and save 'Pubmed History'
										$arrHistory=$this->parse_pub_history($publication);
										$isSaved=$this->save_pub_history($arrHistory, $pubId);
											
										//parse and save 'Publication Article IDs'
										$arrPubArticleIds=$this->parse_pub_article_ids($publication);
										$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
											
										$timeTaken=microtime(true)-$pubStartTime;
										$this->logText	= " PMID: '".$pubDetails['pmid']."'		Time taken : ".$timeTaken."\r\n";
										fwrite($this->logFile, $this->logText);
									}
									sleep($this->sleepTime);
							}
							//End of loop trough ecah publication, parsjing and saving
							$this->logText	= "End of Procesing all the PMID's \r\n";
							fwrite($this->logFile, $this->logText);
							echo "</br>Pubmed Processing of KolID :".$arrKolDetail['id']." is Completed sucessfully</br>";
							$arrKolDetail['is_pubmed_processed']=1;
							$this->pubmed->updatePubmedProcessedKol($arrKolDetail);
							$this->logText	= "Pubmed Processing of KolId :".$arrKolDetail['id']." is Completed sucessfully \r\n";
							//Log Activity
							/*$arrLogDetails = array(
									'type'=>CRON_JOBS,
									'description'=>$this->logText,
									'status' => STATUS_SUCCESS,
									'transaction_table_id'=>'',
									'transaction_name'=>'Pubmed Processing',
									'miscellaneous1'=>$url
							);
							$this->config->set_item('log_details', $arrLogDetails);*/
							fwrite($this->logFile, $this->logText);
							$timeTaken=microtime(true)-$kolStartTime;
							$this->logText	= "Total time taken: ".$timeTaken."\r\n";
							fwrite($this->logFile, $this->logText);
								
							$numRowsEffected = $this->pubmed->updateZeroAuthPosPubsAsDeleted($kolId);
							echo "Number of publications marked as deleted : ".$numRowsEffected."</br>";
							$this->logText	= "Number of publications marked as deleted : ".$numRowsEffected."\r\n";
							fwrite($this->logFile, $this->logText);
							$this->logText	= "--------------------------- \r\n";
							fwrite($this->logFile, $this->logText);
								
							$this->send_status_mail("Pubmed Processing of KolID :".$arrKolDetail['id']." is Completed sucessfully");
				}
	
				$this->send_status_mail("Pubmed Processing Ended");
				// End of loop trought each kol
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : recrawl_pmid
	 * @Param  : $pmid,$overidePublication
	 * @return : none
	 */
	function recrawl_pmid($pmid,$overidePublication=0){
		if($pmid != ''){
			$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$pmid;
				
			$response = $this ->retrieve_page_get($url);
			//Try once again if the response of the status is false
			if($response['status'] == false){
				//give 2 second delay
				sleep($this->sleepTime);
				$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
				fwrite($this->logFile, $this->logText);
				//try once again
				$response = $this ->retrieve_page_get($url);
			}
			// Skipp this and log the details if still respons is false
			if($response['status'] == false){
				//log the details
				$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
				fwrite($this->logFile, $this->logText);
	
				$this->logText = "Recralw : PMID : ".$pmid."\r\n";
				fwrite($this->logFilePmidSkipped, $this->logText);
				//continue to next step
				//continue;
			}
				
			$xml = new DOMDocument();
			if(!$xml->loadXML($response['response'])){
				$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
				fwrite($this->logFile, $this->logText);
	
				$response = $this ->retrieve_page_get($url);
				//Try once again if the response of the status is false
				if($response['status'] == false){
					//give 2 second delay
					sleep($this->sleepTime);
					$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
					fwrite($this->logFile, $this->logText);
					//try once again
					$response = $this ->retrieve_page_get($url);
				}
				// Skipp this and log the details if still respons is false
				if($response['status'] == false){
					//log the details
					$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next pmid, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
					fwrite($this->logFile, $this->logText);
						
					$this->logText = "Recralw : PMID : ".$pmid."\r\n";
					fwrite($this->logFilePmidSkipped, $this->logText);
					//continue to next step
					//continue;
				}
	
				if(!$xml->loadXML($response['response'])){
					//log the details and continue
					$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next pmid, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
					fwrite($this->logFile, $this->logText);
						
					$this->logText = "Recralw : PMID : ".$pmid."\r\n";
					fwrite($this->logFilePmidSkipped, $this->logText);
					//continue;
					//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
				}
			}
				
			//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
			$publications = $xml->getElementsByTagName('PubmedArticle');
			foreach($publications as $publication){
				//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed
				$pubId=$this->pubmed->checkPubExist($pmid);
				if($pubId ==null || $pubId == ''){
					//die("Publication with PMID:".$pmid."  not exist.\r\n");
					$this->logText	= "Publication with PMID:".$pmid."  not exist. \r\n";
					fwrite($this->logFile, $this->logText);
					continue;
				}else{
					if($overidePublication){
						$pubDetails=$this->parse_pub_details($publication);
						$publicationId=$this->pubmed->savePublication($pubDetails,$pubId);
						//     				    echo "<br/>recrawled pmid - ". $pmid . "  Pubid - ".$pubId;
						//     				    return true;
					}
				}
	
				//parse and save 'publication-authors'
				$arrAuthors=$this->parse_pub_authors($publication);
	
				$numAuthorsPresent = $this->pubmed->getNumberOfAuthors($pubId);;
				//Compare the number of authors for this pubid in data base, if mismatch then only proceed
				$this->logText	= "PMID : ".$pmid."	PubID :".$pubId." \r\n ";
				echo $this->logText."<br>";
				//fwrite($this->logFile, $this->logText);
				$this->logText	= "Total Authors : ".sizeof($arrAuthors)."	Authors Present in Database :".$numAuthorsPresent." \r\n ";
				echo $this->logText."<br>";
				//fwrite($this->logFile, $this->logText);
					
				//Delete all the initiall associations first
				$this->pubmed->deletePublicationAssociationDetails($pubId);
	
				//pr($arrAuthors);
				//$arrAuthors = array_slice($arrAuthors,0, 2);
				//pr($arrAuthors);
				$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
	
				//Calculate Authorship position and save
				//$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail);
				//$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
	
				//parse and save MeshTerms
				$arrMeshTerms=$this->parse_pub_meshterms($publication);
				$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
	
				//parse and save 'Substances(chemicals)'
				$arrSubstances=$this->parse_pub_substances($publication);
				$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
	
				//parse and save 'Publication types'
				$arrPubTypes=$this->parse_pub_types($publication);
				$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
	
				//parse and save 'CommentsCorrections(CC)'
				$arrCC=$this->parse_pub_CC($publication);
				$isSaved=$this->save_pub_CC($arrCC, $pubId);
	
				//parse and save 'Pubmed History'
				$arrHistory=$this->parse_pub_history($publication);
				$isSaved=$this->save_pub_history($arrHistory, $pubId);
	
				//parse and save 'Publication Article IDs'
				$arrPubArticleIds=$this->parse_pub_article_ids($publication);
				$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
			}
				
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : processPubmedRecrawlKols
	 * @Param  : none
	 * @return : none
	 */
	function processPubmedRecrawlKols(){
		ini_set("max_execution_time",$this->maxScriptTime);
		//Get all the KOLs having the pubmed status 'Recrawl'
		$arrKols = $this->pubmed->getPubmedRecrawlKols();
	
		//Loop trough each KOL
		foreach($arrKols as $arrKolDetail){
			$kolId = $arrKolDetail['id'];
			$this->logText	= "\r\nStarting pubmed processing for KolId ".$kolId." \r\n";
			fwrite($this->logFile, $this->logText);
				
			//Get the PMIDs for this KOL
			$arrPMIDs = $this->pubmed->getPMIDs($kolId);
			$this->logText	= "Total No of PMIDs found: ".sizeof($arrPMIDs)." \r\n";
			fwrite($this->logFile, $this->logText);
				
			//Check for already existing publication's and associate them with kol
			$arrFilteredPMIDs=$this->pubmed->checkAndAssociateAlreadyExistPubs($arrPMIDs, $kolId,$arrKolDetail,1);
			$this->logText	= "Total No of PMIDs found after removing already existing publication's in database: ".sizeof($arrFilteredPMIDs)." \r\n";
			fwrite($this->logFile, $this->logText);
			//End of checking and associating already existing publications
				
			//Get the Publication details for all the PubMEd ID's, 10 at a time
			$this->logText	= "\r\nStart of getting the Publication details for each PMID, Processing ".$this->pmidBatchSize." at a time \r\n";
			fwrite($this->logFile, $this->logText);
			for($i=0; $i<sizeof($arrFilteredPMIDs);$i=$i+10){
				//for($i=0; $i<20;$i=$i+$this->pmidBatchSize){
				$authListText='';
				$arrAuthList = array();
				for($j=$i; $j<$i+$this->pmidBatchSize; $j++){
					if( $arrFilteredPMIDs[$j]!='')
						$arrAuthList[] = $arrFilteredPMIDs[$j];
				}
				$authListText = implode(",",$arrAuthList);
	
				$pubFetchStartTime=microtime(true);
				$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$authListText;
				$this->logText	= "Url generated: ".$url."\r\n";
				fwrite($this->logFile, $this->logText);
				if($authListText!='')
					$response = $this ->retrieve_page_get($url);
					//Try once again if the response of the status is false
					if($response['status'] == false){
						//give 2 second delay
						sleep($this->sleepTime);
						$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
						fwrite($this->logFile, $this->logText);
						//try once again
						$response = $this ->retrieve_page_get($url);
					}
					// Skipp this and log the details if still respons is false
					if($response['status'] == false){
						//log the details
						$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						fwrite($this->logFile, $this->logText);
							
						$this->logText = "Recrawl : KolId Id - ".$kolId."  : Pmids : ".$authListText."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						//continue to next step
						continue;
					}
	
					$timeTaken=microtime(true)-$pubFetchStartTime;
					$this->logText	= "Time taken to fetch ".$this->pmidBatchSize." publications : ".$timeTaken."\r\n";
					fwrite($this->logFile, $this->logText);
					$xml = new DOMDocument();
	
					if(!$xml->loadXML($response['response'])){
						$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
						fwrite($this->logFile, $this->logText);
							
						$response = $this ->retrieve_page_get($url);
						//Try once again if the response of the status is false
						if($response['status'] == false){
							//give 2 second delay
							sleep($this->sleepTime);
							$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
							fwrite($this->logFile, $this->logText);
							//try once again
							$response = $this ->retrieve_page_get($url);
						}
						// Skipp this and log the details if still respons is false
						if($response['status'] == false){
							//log the details
							$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
							fwrite($this->logFile, $this->logText);
	
							$this->logText = "Recrawl : KolId Id - ".$kolId."  : Pmids : ".$authListText."\r\n";
							fwrite($this->logFilePmidSkipped, $this->logText);
							//continue to next step
							continue;
						}
							
						if(!$xml->loadXML($response['response'])){
							//log the details and continue
							$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
							fwrite($this->logFile, $this->logText);
	
							$this->logText = "Recrawl : KolId Id - ".$kolId."  : Pmids : ".$authListText."\r\n";
							fwrite($this->logFilePmidSkipped, $this->logText);
							continue;
							//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
						}
					}
	
					//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
					$this->logText	= "Following Publications with PMID's are parsed and saved sucessfully\r\n ";
					fwrite($this->logFile, $this->logText);
					$publications = $xml->getElementsByTagName('PubmedArticle');
					foreach($publications as $publication){
						$timeElapsed = (microtime(true) - $this->startTime);
						$remTime	=$this->maxScriptTime-$timeElapsed;
						//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed
						if($remTime<$this->safeTime){
							$this->logText	= "Stopping the pubmed processing, Timelimit reached.\r\n ";
							fwrite($this->logFile, $this->logText);
							$this->send_status_mail($this->logText);
							//die("Sorry! Stopping the pubmed processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);
							//redirect(base_url()."pubmeds_org/process_pubmeds");
						}
						$pubStartTime=microtime(true);
						//parse and save publication details
						$pubDetails=$this->parse_pub_details($publication);
						$pubId=$this->save_publications('kol', $pubDetails, $kolId, 1);
						if($pubId!=null){
							//$this->logText	= "Publication with PMID:".$pubDetails['pmid']." parsed and saved sucessfully\r\n ";
							//fwrite($this->logFile, $this->logText);
						}else{
							$this->logText	= "Error in parsing and saving the Publication with PMID:".$pubDetails['pmid']." \r\n ";
							fwrite($this->logFile, $this->logText);
							continue;
						}
						//log the last PMID parsed
						file_put_contents($this->logLastPmidFile,$pubDetails['pmid']);
							
						//parse and save 'publication-authors'
						$arrAuthors=$this->parse_pub_authors($publication);
						$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
							
						//Calculate Authorship position and save
						$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail);
						$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
							
						//parse and save MeshTerms
						$arrMeshTerms=$this->parse_pub_meshterms($publication);
						$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
							
						//parse and save 'Substances(chemicals)'
						$arrSubstances=$this->parse_pub_substances($publication);
						$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
							
						//parse and save 'Publication types'
						$arrPubTypes=$this->parse_pub_types($publication);
						$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
							
						//parse and save 'CommentsCorrections(CC)'
						$arrCC=$this->parse_pub_CC($publication);
						$isSaved=$this->save_pub_CC($arrCC, $pubId);
							
						//parse and save 'Pubmed History'
						$arrHistory=$this->parse_pub_history($publication);
						$isSaved=$this->save_pub_history($arrHistory, $pubId);
							
						//parse and save 'Publication Article IDs'
						$arrPubArticleIds=$this->parse_pub_article_ids($publication);
						$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
							
						$timeTaken=microtime(true)-$pubStartTime;
						$this->logText	= " PMID: '".$pubDetails['pmid']."'		Time taken : ".$timeTaken."\r\n";
						fwrite($this->logFile, $this->logText);
					}
					sleep($this->sleepTime);
			}
			//End of loop trough ecah publication, parsing and saving
			$this->logText	= "End of Procesing all the PMID's \r\n";
			fwrite($this->logFile, $this->logText);
			echo "</br>Pubmed Processing of KolID :".$arrKolDetail['id']." is Completed sucessfully</br>";
			$arrKolDetail['is_pubmed_processed']=1;
			$this->pubmed->updatePubmedProcessedKol($arrKolDetail);
			$this->logText	= "Pubmed Processing of KolID :".$arrKolDetail['id']." is Completed sucessfully \r\n";
			fwrite($this->logFile, $this->logText);
			$timeTaken=microtime(true)-$kolStartTime;
			$this->logText	= "Total time taken: ".$timeTaken."\r\n";
			fwrite($this->logFile, $this->logText);
				
			$numRowsEffected = $this->pubmed->updateZeroAuthPosPubsAsDeleted($kolId);
			echo "Number of publications marked as deleted : ".$numRowsEffected."</br>";
			$this->logText	= "Number of publications marked as deleted : ".$numRowsEffected."\r\n";
			fwrite($this->logFile, $this->logText);
			$this->logText	= "--------------------------- \r\n";
			fwrite($this->logFile, $this->logText);
				
			$this->send_status_mail("Pubmed Processing of KolID :".$arrKolDetail['id']." is Completed sucessfully");
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : send_status_mail
	 * @Param  : $message, $mailId
	 * @return : send mail
	 */
	private function send_status_mail($message, $mailId = null){
		$config['protocol'] 	= PROTOCOL;
		$config['smtp_host'] 	= HOST;
		$config['smtp_port'] 	= PORT;
		$config['smtp_user'] 	= USER;
		$config['smtp_pass'] 	= PASS;
		$config['mailtype']		= 'html';
	
		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear(true);
	
		if($mailId == null)
			$mailId = $this->observerEmailId;
				
			//Send mail to  User
			$this->email->subject($this->logFileName);
			$this->email->from(USER,"Pub Crawling");
			$this->email->message($message);
			$this->email->to($mailId);
			$this->email->attach($this->logFileName,'attachment');
			$this->email->attach($this->logFileNamePmidSkipped,'attachment');
			$this->email->send();
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : retrieve_page_get
	 * @Param  : $url
	 * @return : $data
	 */
	public function retrieve_page_get($url){
		if($_SERVER['SERVER_ADDR'] == '192.168.1.15'){
			$aContext = array(
					'http' => array(
							'proxy' => 'tcp://192.168.1.90:808',
							'request_fulluri' => true,
					),
			);
			$cxContext = stream_context_create($aContext);
				
			$res=null;
			//if(!$res = file_get_contents($url)){
			if(!$res = file_get_contents($url, false, $cxContext)){
				$this->logText	= "Error in connecting to url: ".$url." \r\nTerminating process..\r\n ";
				fwrite($this->logFile, $this->logText);
				die("Sorry! Coulndnot process, Error in connecting to url: ".$url.", LogPath: ".$this->logFilePath);
			}
			if(!$res)	echo 'Error in connecting to url'.$url;
			return $res;
		}else{
			$data = array();
			$res = null;
			$data['status'] = false;
			if(!$res = file_get_contents($url)){
				//$this->logText	= "Error in connecting to url: ".$url." \r\nTerminating process..\r\n ";
				//fwrite($this->logFile, $this->logText);
				//die("Sorry! Coulndnot process, Error in connecting to url: ".$url.", LogPath: ".$this->logFilePath);
				$data['status'] = false;
			}else{
				$data['status'] = true;
			}
			if(!$res){
				//echo 'Error in connecting to url'.$url;
				$data['status'] = false;
			}else{
				$data['status'] = true;
			}
				
			$data['response'] = $res;
			return $data;
		}
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : re_crawl_publications_types
	 * @Param  : none
	 * @return : re crawl status
	 */
	function re_crawl_publications_types(){
		ini_set("max_execution_time",0);
		ini_set('memory_limit', '-1');
		//Get all the publications ids with there reapecrive PMID
		$get = $this->db->query("SELECT publications.id,publications.pmid,publications_types.pub_type_id  FROM `publications`
                left join publications_types on publications.id=publications_types.pub_id
                WHERE publications_types.pub_type_id ='' or publications_types.pub_type_id is null
                and pmid>0");
		$pmids = '';
		$arrayPubIdsAll = array();
		foreach($get->result_array() as $row){
			//$pmids .=$row['pmid'].',';
			$arrayPubIdsAll[$row['id']] = $row['pmid'];
		}
		$splitArrayPubIds = array_chunk($arrayPubIdsAll, 100);
		$i=0;
		foreach($splitArrayPubIds as $arrayPubIds){
			// 	        pr($arrayPubIds);exit;
			$pmids = implode(',',$arrayPubIds);
			$pubFetchStartTime=microtime(true);
			//     	    echo $pmids;exit;
			$url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$pmids;
	
			if(sizeof($arrayPubIds)>0){
				$content = $this ->retrieve_page_get($url);
	
				if(!$content['response']){
					//pr($arrayPubIds);exit;
					return false;
				}else{
					//$timeTaken=microtime(true)-$pubFetchStartTime;
					$xml = new DOMDocument();
					if(!$xml->loadXML($content['response'])){
						//continue;
						 
						die("Sorry! Couldnot process, check the log for details");
					}
					//echo $content['response'];exit;
					$publications = $xml->getElementsByTagName('PubmedArticle');
					//     	        $arrayPublicationTypeDetails = array();
					 
					foreach($publications as $publication){
						$ptype = $this->parse_pub_types($publication);
						$pubDetails=$this->parse_pub_details($publication);
						$pubId =  array_search($pubDetails['pmid'], $arrayPubIdsAll);
						$arrayPublicationTypeDetails= array("pub_id"=>$pubId,
								"pub_type_id" => $this->pubmed->savePubmedPubType($ptype[0]));
						//pr($arrayPublicationTypeDetails);
						if($this->pubmed->SavePublicationType($arrayPublicationTypeDetails)){
							$i++;
						}
					}
	
				}
			}
		}
		 
		//Log Activity
		/* $arrLogDetails = array(
				'type'=>CRON_JOBS,
				'description'=> $i. " Publication Type Updated",
				'status' => STATUS_SUCCESS,
				'transaction_id'=>'',
				'transaction_name'=>'Crawling publication type',
				'miscellaneous1'=>$url
		);
		$this->config->set_item('log_details', $arrLogDetails); */
		echo $i. " Publication Type Updated";
		//  pr($arrayPublicationTypeDetails);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : add_publication
	 * @Param  : $kolId, $pubId
	 * @return : none
	 */
	function add_publication($kolId=null,$pubId=null){
		$publication=array();
		$data['arrMultipleAuthors']=array();
		if($pubId!=null){
			$publication=$this->pubmed->getPublicationDetail($pubId);
			$publication['journal_name']=$this->pubmed->getJournalNameById($publication['journal_id']);
			if($publication['pub_date']=='0000-00-00')
				$publication['pub_date']='';
				else
					$publication['pub_date']=sql_date_to_app_date($publication['pub_date']);
					$publication['created_date']=sql_date_to_app_date($publication['created_date']);
					$arrMultipleAuthors=$this->pubmed->listPublicationAuthors($pubId);
					// 			pr($pubId);
					// 			echo $this->db->last_query();
					// 			pr($arrMultipleAuthors);exit;
					$data['arrMultipleAuthors']=$arrMultipleAuthors;
		}
		$data['kolId']=$kolId;
		$data['publication']=$publication;
		$data['contentData']	=$data;
		$this->load->view('pubmeds/add_publications',$data);
	}
	
	/**
	 * Controller functions for Organization module Scripts Starts
	 * @Author : Sanjeev K
	 * @Method : list_publication_details_analyst
	 * @Param  : $type, $orgId
	 * @return : none
	 */
	function list_publication_details_analyst($type,$orgId){
		$page				= (int)$this->input->post('page'); // get the requested page
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$arrPublications 	= array();
		$data 				= array();
		$arrPublications	= array();
		if($arrPublicationsResults=$this->pubmed->listPublicationDetailsForAnalyst($orgId,$type)){
			foreach($arrPublicationsResults as $arrPublicationsResult){
				$arrPublication['id']			= $arrPublicationsResult['asoc_id'];
				$arrPublication['pub_id']		= $arrPublicationsResult['id'];
				$arrPublication['is_manual']	= $arrPublicationsResult['is_manual'];
				//$arrPublication['pmid']='<a href=\''. $arrPublicationsResult['link'].'\' target="_new">'.$arrPublicationsResult['pmid'].'</a>';
				if(isset($arrPublicationsResult['pmid']) && $arrPublicationsResult['pmid'] > 0)
					$arrPublication['pmid']		= '<a href=\'http://www.ncbi.nlm.nih.gov/pubmed/'. $arrPublicationsResult['pmid'].'\' target="_new">'.$arrPublicationsResult['pmid'].'</a>';
					else
						$arrPublication['pmid']		= '<a href=\''.base_url().'/pubmeds/view_publication/'.$arrPublicationsResult['id'].'\' target="_new">'.$arrPublicationsResult['pmid'].'</a>';
						$arrPublication['journal_name']	= $this->pubmed->getJournalNameById($arrPublicationsResult['journal_id']);
						//$arrPublication['article_title']=$arrPublicationsResult['article_title'];
						$arrPublication['article_title']= '<a target="_new" href=\''.base_url().'pubmeds/view_publication/'. $arrPublicationsResult['id'].'\'>'.$arrPublicationsResult['article_title'].'</a>';
						$arrPublication['affiliation']	= $arrPublicationsResult['affiliation'];
						$arrPublication['date']			= $arrPublicationsResult['created_date'];
						$arrPublication['authors']		= $this->get_pub_authors($arrPublicationsResult['id']);
						//$arrPublication['auth_pos']		= $arrPublicationsResult['auth_pos'];
						//$arrPublication['auth_pos']=$this->pubmed->calculateAuthorShipPosition($arrPublication['id'],$orgId,null);
						$arrPublication['subject']		= '';
						$arrPublications[]				= $arrPublication;
			}
			$count				= sizeof($arrPublications);
			if( $count >0 ){
				$total_pages	= ceil($count/$limit);
			}else{
				$total_pages 	= 0;
			}
			$data['records']	= $count;
			$data['total']		= $total_pages;
			$data['page']		= $page;
			$data['rows']		= $arrPublications;
		}
		ob_start('ob_gzhandler');
		echo json_encode($data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : add_publication
	 * @Param  : $orgId
	 * @return : none
	 */
	function add_org_publication($orgId){
		$arrPublicationDetails = array(	
				'id'                =>	'',
				'journal_name'		=>	'',
				'article_title'		=>	'',
				'created_date'	 	=> 	'',
				'abstract_text'		=> 	'',
				'link'	 			=> 	'');
		$manualAuthor['last_name']='';
		$manualAuthor['fore_name']='';
		$manualAuthor['initials']='';
		$manualAuthor['id'] = '';
		$arrPublicationDetails['no_of_authors'] = 1;
	
		$data['publication']=$arrPublicationDetails;
		$data['arrAuthors']=$manualAuthor;
		$data['orgId'] = $orgId;
		$this->load->view('pubmeds/add_org_publications',$data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : edit_publication_manual
	 * @Param  : $pubId,$orgId
	 * @return : Load add view with details to edit
	 */
	function edit_publication_manual($pubId,$orgId){
		$data['orgId'] = $orgId;
		
		$publication=$this->pubmed->getPublicationDetail($pubId);
		
		$publication['journal_name']=$this->pubmed->getJournalNameById($publication['journal_id']);
		$publication['created_date']=sql_date_to_app_date($publication['created_date']);
		$arrAuthors =$this->pubmed->listPublicationAuthors($pubId);
		$manualAuthor = array();
		$manualAuthor['last_name']='';
		$manualAuthor['fore_name']='';
		$manualAuthor['initials']='';
		$manualAuthor['id']='';
		$i=0;
		foreach ($arrAuthors as $author){
			$i++;
			if($i == 2)
				break;
			$manualAuthor = $author;
		}
		$publication['no_of_authors'] = (sizeof($arrAuthors) !=0) ? sizeof($arrAuthors):1;
		$data['publication']=$publication;
		$data['arrAuthors']=$manualAuthor;
		$data['arrMultipleAuthors']=$arrAuthors;
		$this->load->view('pubmeds/add_org_publications',$data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : delete_publication
	 * @Param  : $id
	 * @return : boolean value
	 */
	function delete_publication($id){
		$orgId	=	$this->input->post('org_id');
		$isDeleted=$this->pubmed->updatePublicationAsDeleted($id);
		//$this->update->deleteUpdateEntry(KOL_PROFILE_PUBLICATION_ADD, $id, MODULE_KOL_PUBLICATION);
		return true;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : un_verified_publications
	 * @Param  : none
	 * @return : json data : boolean type
	 */
	function un_verified_publications(){
		$selectedRows = $this->input->post('pub_id');
		//pr($selectedRows);
		$orgId	=	$this->input->post('org_id');
		foreach($selectedRows as $id){
			$orgPublication=array();
			$orgPublication['is_verified']=0;
			$orgPublication['is_deleted']=0;
			$isDeleted=$this->pubmed->updatePublicationAsVerified($id,$orgPublication);
		}
		$isDeleted=true;
		echo json_encode($isDeleted);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : verified_publications
	 * @Param  : none
	 * @return : json data : boolean type
	 */
	function verified_publications(){
		$selectedRows = $this->input->post('pub_id');
		$orgId	=	$this->input->post('org_id');
		foreach($selectedRows as $id){
			$orgPublication=array();			
			$orgPublication['is_verified']=1;
			$orgPublication['is_deleted']=0;
			$isDeleted=$this->pubmed->updatePublicationAsVerified($id,$orgPublication);			
		}		
		$isDeleted=true;
		echo json_encode($isDeleted);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : delete_publications
	 * @Param  : none
	 * @return : json data : boolean type
	 */
	function delete_publications(){
		$selectedRows =$this->input->post('pub_id');
		$orgId	=	$this->input->post('org_id');
		foreach($selectedRows as $id){
			$isDeleted=$this->pubmed->updatePublicationAsDeleted($id);
		}
		return true;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : get_unprocessed_co_authors_page
	 * @Param  : $orgId
	 * @return : load view for unprocessed co authors
	 */
	function get_unprocessed_co_authors_page($orgId){
		//Get all the co-authors of given kol id.
		$arrCoAuthos=$this->pubmed->getOrgCoAuthors($orgId);
		
		//To Hold all the Processed co-authors, all the co- authors of kol having alias id
		$arrProcessedCoAuths=array();
		
		// To hold all the un processed co-authoers, $arrUnProcessedCoAuths=$arrCoAuthos-$arrProcessedCoAuths
		$arrUnProcessedCoAuths=array();
		
		// To hold all the currently asigned alias authors
		$arrPresentAliasCoAuthos=array();
		
		//To hold all the possible alias co-authors for un processed co-authors, $arrPossibleAliasCoAuthors=$arrUnProcessedCoAuths+$arrPresentAliasCoAuthos;
		$arrPossibleAliasCoAuthors=array();
		
		
		$arrProcessedCoAuths=$this->pubmed->getOrgProcessedCoAuthors($orgId);
		
		//Prepare array of unprocessed co-authors, loop trough each kol co-authors,
		//check is it has a alias id, if not then it is still un processed, i.e all the kol co-authors which are un processed.
		//$arrUnProcessedCoAuths=$arrCoAuthos-$arrProcessedCoAuths
		foreach($arrCoAuthos as $key=>$value){
			if ( !array_key_exists($key, $arrProcessedCoAuths) ){
				//based on the name avilability, construct a proper name
				if($value['last_name']!='' && $value['fore_name']!='')
					$arrUnProcessedCoAuths[ucwords($value['last_name'])." ".$value['fore_name']]=$value;
				else if($value['fore_name']=='')
					$arrUnProcessedCoAuths[ucwords($value['last_name'])." ".$value['initials']]=$value;
				else if($value['last_name']=='')
					$arrUnProcessedCoAuths[ucwords($value['fore_name'])." ".$value['initials']]=$value;
			}
		}
		
		$arrPresentAliasCoAuthos = $this->pubmed->getAliasCoAuthors($orgId);
		
		//Prepare array of possible alias co-authors for un processed co-authors
		//$arrPossibleAliasCoAuthors=$arrUnProcessedCoAuths+$arrPresentAliasCoAuthos;
		//taking key as last name and first name in order to sort
		foreach($arrUnProcessedCoAuths as $key => $value){
			//$arrPossibleAliasCoAuthors[$value['last_name']." ".$value['fore_name']]=$value;
			//based on the name avilability, construct a proper name
			if($value['last_name']!='' && $value['fore_name']!='')
				$arrPossibleAliasCoAuthors[ucwords($value['last_name'])." ".$value['fore_name']]=$value;
			else if($value['fore_name']=='')
				$arrPossibleAliasCoAuthors[ucwords($value['last_name'])." ".$value['initials']]=$value;
			else if($value['last_name']=='')
				$arrPossibleAliasCoAuthors[ucwords($value['fore_name'])." ".$value['initials']]=$value;
		}
		//TODO What this loop does, write it
		foreach($arrPresentAliasCoAuthos as $key=>$value){
			//$arrPossibleAliasCoAuthors[$value['last_name']." ".$value['fore_name']]=$value;
			//based on the name avilability, construct a proper name
			if($value['last_name']!='' && $value['fore_name']!='')
				$arrPossibleAliasCoAuthors[ucwords($value['last_name'])." ".$value['fore_name']]=$value;
			else if($value['fore_name']=='')
				$arrPossibleAliasCoAuthors[ucwords($value['last_name'])." ".$value['initials']]=$value;
			else if($value['last_name']=='')
				$arrPossibleAliasCoAuthors[ucwords($value['fore_name'])." ".$value['initials']]=$value;
		}
		/*
		 * TODO Move all the logic of getting the UnProcessed and Alias Co-Authors to 'Model' in 2 different functions.
		 * 		Just with 2 function calls, the data should be returned from the MODEL functions
		 */
		ksort($arrPossibleAliasCoAuthors,SORT_STRING);
		
		//Filter the unprocessed co authors, find the similar names and exclude the name with no  similar names
		//$arrUnProcessedCoAuths=$this->pubmed->filterUnprocessedCoAuthors($arrUnProcessedCoAuths);
		//$arrUnProcessedCoAuths=$this->pubmed->filterUnprocessedCoAuthors($arrUnProcessedCoAuths,$arrPossibleAliasCoAuthors);
		ksort($arrUnProcessedCoAuths);
		$data['arrUnProcessedCoAuths']=$arrUnProcessedCoAuths;
		$data['arrAliasCoAuthos']=$arrPossibleAliasCoAuthors;
		$this->load->view('pubmeds/unprocessed_co_auths',$data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : get_processed_co_authors_page
	 * @Param  : $orgId
	 * @return : load view for processed co authors
	 */
	function get_processed_co_authors_page($orgId){
		$arrOrgProcessedCoAuths=$this->pubmed->getOrgProcessedCoAuthors($orgId);
		$data['arrOrgProcessedCoAuths']=$arrOrgProcessedCoAuths;
		$this->load->view('pubmeds/processed_co_auths',$data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : associate_co_authors
	 * @Param  : $orgId
	 * @return : true on is processed | false on failure 
	 */
	function associate_co_authors(){
		/**
		 * TODO Write the brief description about what happens, in single line.
		 * 		Move the logic to MODEL in seperate function. Just need to pass IDs and get the TRUE/FALSE
		 */
		//$arrCoAuthsIds are the id's of co authors which are needs to be replaced(associated to) by the co auther name of $aliasId
		//With each $arrCoAuthsIds, there will be as many co author entries as the number of publications co-authered with the same name, we have to get the authoer id's of those entries also
		//these id's will be stored in the '$matchingAuths' array, for all these co auther we have to update it's alias as $aliasId
		$arrCoAuthsIds	=$this->input->post('co_auths_ids');
		$aliasId		=$this->input->post('alias_id');
		
		$coAuthorDetails=$this->pubmed->getCoAuthorById($aliasId);
		$matchingAuths=$this->pubmed->getMatchingCoAuthors($arrCoAuthsIds,$orgId);
		$aliasDeails['alias_id']=$coAuthorDetails['id'];
		$aliasDeails['alias_last_name']=$coAuthorDetails['last_name'];
		$aliasDeails['alias_initials']=$coAuthorDetails['initials'];
		$aliasDeails['alias_fore_name']=$coAuthorDetails['fore_name'];
		
		$matchingAuths=array_keys($matchingAuths);
		$isProcessed=$this->pubmed->associateCoAuthors($matchingAuths,$aliasDeails);
		echo $isProcessed;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : disassociate_co_author
	 * @Param  : $orgId
	 * @return : true on is processed | false on failure
	 */
	function disassociate_co_author($orgId){
		$authorId[]		=$this->input->post('co_author_id');
		$matchingAuths=$this->pubmed->getMatchingCoAuthors($authorId,$orgId);
		$matchingAuths=array_keys($matchingAuths);
		//Disassociatein is same as associating the co auther with null values
		$aliasDeails['alias_id']=null;
		$aliasDeails['alias_last_name']=null;
		$aliasDeails['alias_initials']=null;
		$aliasDeails['alias_fore_name']=null;
		$isProcessed=$this->pubmed->disassociateCoAuthors($matchingAuths,$aliasDeails);
		echo $isProcessed;
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : process_pmids
	 * @Param  : $orgId
	 * @return : json data : $returnData
	 */
	function process_pmids($orgId){
			ini_set("max_execution_time",$this->maxScriptTime);
			$arrPMIDs = null;
			$returnData = array();
			$arrPMIDStatuses = array();
			if($arrPMIDs == null){
				$arrPMIDs = array();
				$arrPMIDs = $this->input->post('pmids');
			}
			$arrOrgDetail=$this->organization->editOrganization($orgId);
			$arrFilteredPMIDs=$this->pubmed->checkAndAssociateAlreadyExistPubs($arrPMIDs, $orgId,$arrOrgDetail);
			$associatedPmids = array_diff($arrPMIDs, $arrFilteredPMIDs);
			foreach ($associatedPmids as $pmid){
				$arrPMIDStatuses[$pmid] = 'exist';
			}
			$this->startTime	= microtime(true);
			$pmidsList = implode(',',$arrFilteredPMIDs);
			if($pmidsList != ''){
				$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$pmidsList;
				if($pmidsList!='')
					$response = $this ->retrieve_page_get($url);
				//Try once again if the response of the status is false	
				if($response['status'] == false){
					//give 2 second delay
					sleep($this->sleepTime);
					$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
					fwrite($this->logFile, $this->logText);
					//try once again
					$response = $this ->retrieve_page_get($url);
				}
				// Skipp this and log the details if still respons is false
				if($response['status'] == false){
					//log the details
					$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
					fwrite($this->logFile, $this->logText);
					
					$this->logText = "Recrawl : OrgId Id - ".$orgId."  : Pmids : ".$pmidsList."\r\n";
					fwrite($this->logFilePmidSkipped, $this->logText);
					//continue to next step
					//continue;
				}
					
				$xml = new DOMDocument();
				if(!$xml->loadXML($response['response'])){
					$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
					fwrite($this->logFile, $this->logText);	
					
					$response = $this ->retrieve_page_get($url);
					//Try once again if the response of the status is false	
					if($response['status'] == false){
						//give 2 second delay
						sleep($this->sleepTime);
						$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
						fwrite($this->logFile, $this->logText);
						//try once again
						$response = $this ->retrieve_page_get($url);
					}
					// Skipp this and log the details if still respons is false
					if($response['status'] == false){
						//log the details
						$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						fwrite($this->logFile, $this->logText);
						
						$this->logText = "Recrawl : OrgId Id - ".$orgId."  : Pmids : ".$pmidsList."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						//continue to next step
						//continue;
					}
					
					if(!$xml->loadXML($response['response'])){
						//log the details and continue
						$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						fwrite($this->logFile, $this->logText);	
						
						$this->logText = "Recrawl : OrgId Id - ".$orgId."  : Pmids : ".$pmidsList."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						//continue;
						//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
					}										
				}
		
				//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
				$publications = $xml->getElementsByTagName('PubmedArticle');				
				foreach($publications as $publication){
					$timeElapsed = (microtime(true) - $this->startTime);
					$remTime	=$this->maxScriptTime-$timeElapsed;
					//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
					if($remTime<$this->safeTime){
						$this->logText	= "Stopping the pubmed processing, Timelimit reached.\r\n ";
						fwrite($this->logFile, $this->logText);	
						die("Sorry! Stopping the pubmed processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
					}					
					$pubStartTime=microtime(true);	
					//parse and save publication details
					$pubDetails=$this->parse_pub_details($publication);	
					$pubId=$this->save_publications('org', $pubDetails, $orgId);
					if($pubId!=null){
						//$this->logText	= "Publication with PMID:".$pubDetails['pmid']." parsed and saved sucessfully\r\n ";
						//fwrite($this->logFile, $this->logText);	
					}else{
						$arrPMIDStatuses[$pubDetails['pmid']] = 'error';
						$this->logText	= "Error in parsing and saving the Publication with PMID:".$pubDetails['pmid']." \r\n ";
						fwrite($this->logFile, $this->logText);
						continue;
					}
					
					//parse and save 'publication-authors'
					$arrAuthors=$this->parse_pub_authors($publication);
					$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
					
					//Calculate Authorship position and save
					//$position=$this->pubmed->calculateAuthorShipPosition($pubId,$orgId,$arrOrgDetail);
					//$this->pubmed->updateAuthorshipPos($orgId,$pubId,$position);
					
					//parse and save MeshTerms
					$arrMeshTerms=$this->parse_pub_meshterms($publication);
					$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
					
					//parse and save 'Substances(chemicals)'
					$arrSubstances=$this->parse_pub_substances($publication);
					$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
					
					//parse and save 'Publication types'
					$arrPubTypes=$this->parse_pub_types($publication);
					$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
					
					//parse and save 'CommentsCorrections(CC)'
					$arrCC=$this->parse_pub_CC($publication);
					$isSaved=$this->save_pub_CC($arrCC, $pubId);
					
					//parse and save 'Pubmed History'
					$arrHistory=$this->parse_pub_history($publication);
					$isSaved=$this->save_pub_history($arrHistory, $pubId);
					
					//parse and save 'Publication Article IDs'
					$arrPubArticleIds=$this->parse_pub_article_ids($publication);
					$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
					
					$arrPMIDStatuses[$pubDetails['pmid']] = 'done';
				}
				sleep($this->sleepTime);
			}
		//$numRowsEffected = $this->pubmed->updateZeroAuthPosPubsAsDeleted($orgId);
		$returnData['status'] = true;
		$returnData['pmidstatuses'] = $arrPMIDStatuses;
		echo json_encode($returnData);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : get_name_combinations
	 * @Param  : none
	 * @return : 
	 */
	function get_name_combinations(){
		$arrNameCombinations = $this->pubmed->getOrgNameCombinations($orgId);
		$data = array();
		$data['arrNameCombinations'] = $arrNameCombinations;
		$data['orgId'] = $orgId;
		$this->load->view('pubmeds/org_name_combinations',$data);
	}
	
	/**
	 * @Author : Sanjeev K
	 * @Method : process_pubmeds_org
	 * @Param  : $indvisOrgId
	 * @return : none
	 */
	function process_pubmeds_org($indvisOrgId = null){
		//Analyst App to be accessed by only Aissel users.
		//$this->common_helpers->checkUsers();
		$this->logFilePath=	$_SERVER['DOCUMENT_ROOT'].'/'.$this->logFilePath;
		// Open the LogFile to write
		$this->startTime	= microtime(true);
		$this->logFileName	=$this->logFilePath . "/" . "logfile_".date("d-m-Y")."_". $this->startTime . ".txt";
		$this->logFile	= fopen($this->logFileName, "w");
		$this->logText	= "------------------------------Processing Started on: " . date("d-m-Y H:i:s") . "------------------------------------\r\n";
		//Log Activity
		/* $arrLogDetails = array(
				'type'=>CRON_JOBS,
				'description'=>$this->logText,
				'status' => STATUS_SUCCESS,
				'transaction_table_id'=>'',
				'transaction_name'=>'Crawling Started'
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null, true); */
		fwrite($this->logFile, $this->logText);
	
		$this->logFileNamePmidSkipped	=$this->logFilePath . "/skipped/" . "pmids_skipped_orgs_".date("d-m-Y").".txt";
		$this->logFilePmidSkipped	= fopen($this->logFileNamePmidSkipped, "w");
		fwrite($this->logFilePmidSkipped, $this->logText);
	
		ini_set("max_execution_time",$this->maxScriptTime);
		//$this->maxScriptTime = ini_get("max_execution_time");
	
		//Process the last crawled PMID
		$lastPmid = file_get_contents($this->logFilePath . "/last_pmid.txt");
		if(isset($lastPmid) && $lastPmid != '') {
			echo "Processing last PMID : ".$lastPmid."<br>";
			flush();
			$this->logText	= "Processing last PMID : ".$lastPmid."\r\n";
			//Log Activity
			/* $arrLogDetails = array(
					'type'=>CRON_JOBS,
					'description'=>$this->logText,
					'status' => STATUS_SUCCESS,
					'transaction_table_id'=>'',
					'transaction_id' => $lastPmid,
					'transaction_name'=>'Processing last PMID'
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null, true); */
			fwrite($this->logFile, $this->logText);
			$this->recrawl_pmid($lastPmid);
		}
		//$this->logLastPmidFile = fopen($this->logFilePath . "/last_pmid.txt", "w");
	
		$this->logText	= "Processing Organizations with status Recrawl..  \r\n";
		fwrite($this->logFile, $this->logText);
		$this->processPubmedRecrawlOrgs();
		$this->logText	= "Recrawl Status Organizations processing completed..  \r\n";
		//Log Activity
		/* $arrLogDetails = array(
				'type'=>CRON_JOBS,
				'description'=>$this->logText,
				'status' => STATUS_SUCCESS,
				'transaction_table_id'=>'',
				'transaction_name'=>'Processing Organizations with status Recrawl'
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null, true); */
		fwrite($this->logFile, $this->logText);
	
		//get the PubmedUnprocessed org's
		if($indvisOrgId != null)
			$arrOrgDetails[] = $this->organization->editOrganization($indvisOrgId);
			else
				$arrOrgDetails=$this->pubmed_org->getPubmedUnprocessedOrgs();
				if(sizeof($arrOrgDetails)<1){
					$this->logText	= "There are No Unprocessed Organization ids, Terminating Process..  \r\n";
					//Log Activity
					/* $arrLogDetails = array(
							'type'=>CRON_JOBS,
							'description'=>$this->logText,
							'status' => STATUS_SUCCESS,
							'transaction_table_id'=>'',
							'transaction_name'=>'Get the PubmedUnprocessed Orgs'
					);
					$this->config->set_item('log_details', $arrLogDetails);
					log_user_activity(null, true); */
					fwrite($this->logFile, $this->logText);
					$this->send_status_mail($this->logText);
					die("Sorry! There are No Unprocessed Organization ids, Terminating Process..");
				}
				$this->logText	= "Following are the Unprocessed Organization ids  \r\n";
				fwrite($this->logFile, $this->logText);
				foreach($arrOrgDetails as $arrOrgDetail){
					$this->logText	= $arrOrgDetail['id']."  \r\n";
					//Log Activity
					/* $arrLogDetails = array(
							'type'=>CRON_JOBS,
							'description'=>$this->logText,
							'status' => STATUS_SUCCESS,
							'transaction_table_id'=>'',
							'transaction_name'=>'Following are the Unprocessed Organization ids'
					);
					$this->config->set_item('log_details', $arrLogDetails);
					log_user_activity(null, true); */
					fwrite($this->logFile, $this->logText);
				}
				$this->logText	= "--------------------------------------------------------------------------------------------- \r\n";
				fwrite($this->logFile, $this->logText);
				//Start of loop trought each organization, generate name combinations, gather PMID's, get publications, parse and save data
				foreach($arrOrgDetails as $arrOrgDetail){
					$orgStartTime=microtime(true);
					$this->logText	= "\r\nStarting pubmed processing for OrgId ".$arrOrgDetail['id']." \r\n";
					fwrite($this->logFile, $this->logText);
						
					$orgId=$arrOrgDetail['id'];
					$arrNameCombinations = $this->pubmed_org->getOrgNameCombinations($orgId);
					$arrNameCombinations[]=$arrOrgDetail['name'];
						
					$this->logText	= "Org Name: ".$arrOrgDetail['name']."  \r\n";
					fwrite($this->logFile, $this->logText);
						
					$this->logText	= "Following are the Name combinations genarated  \r\n";
					fwrite($this->logFile, $this->logText);
					foreach($arrNameCombinations as $nameCombination){
						$this->logText	= $nameCombination."  \r\n";
						fwrite($this->logFile, $this->logText);
					}
						
						
					//Get the list of PubMed ID's for given organizaton name
					$this->logText	= "\r\nStarting getting pmid's  \r\n";
					fwrite($this->logFile, $this->logText);
					$arrPMIDs=array();
					$gathPMIDTime=microtime(true);
					$yearRange = "(2011[Date - Publication] %3A 3000[Date - Publication])";
					foreach($arrNameCombinations as $orgName){
						//Notes about url
						//Whenewer you encounter a space in url, repalce space with special charecter '%20', otherwise you may get wrong results
						//$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retstart=0&retmax=3000&usehistory=y&retmode=xml&term=(".str_replace(" ", "%20", $orgName)."[affiliation]) AND ".$yearRange;
						//Documentation link http://www.ncbi.nlm.nih.gov/books/NBK25499/
						//http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&reldate=100&datetype=pdat&retmax=100&usehistory=y&term=Advocate%20Christ%20Medical%20Center%20[affiliation]
						//$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&reldate=356&datetype=pdat&retmax=3000&usehistory=y&term=".str_replace(" ", "%20", $orgName)."[affiliation";
						$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&mindate=2011/01/01&maxdate=2050/12/31&datetype=pdat&retmax=5000&usehistory=y&term=".str_replace(" ", "%20", $orgName)."[affiliation";
	
						$response = $this ->retrieve_page_get($url);
						//Try once again if the response of the status is false
						if($response['status'] == false){
							//give 2 second delay
							sleep($this->sleepTime);
							$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
							//Log Activity
							/* $arrLogDetails = array(
									'type'=>CRON_JOBS,
									'description'=>$this->logText,
									'status' => STATUS_FAIL,
									'transaction_table_id'=>'',
									'transaction_name'=>'Pubmed Processing',
									'miscellaneous1'=>$url
							);
							$this->config->set_item('log_details', $arrLogDetails);
							log_user_activity(null, true); */
							fwrite($this->logFile, $this->logText);
							//try once again
							$response = $this ->retrieve_page_get($url);
						}
						// Skipp this and log the details if still respons is false
						if($response['status'] == false){
							//log the details
							$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next name, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
							//Log Activity
							/* $arrLogDetails = array(
									'type'=>CRON_JOBS,
									'description'=>$this->logText,
									'status' => STATUS_FAIL,
									'transaction_table_id'=>'',
									'transaction_name'=>'Pubmed Processing',
									'miscellaneous1'=>$url
							);
							$this->config->set_item('log_details', $arrLogDetails);
							log_user_activity(null, true); */
							fwrite($this->logFile, $this->logText);
	
							$this->logText = "Name Combination Crawl : OrgId Id - ".$orgId."  : Name : ".$orgName."\r\n";
							fwrite($this->logFilePmidSkipped, $this->logText);
							//continue to next step
							continue;
						}
	
						$this->logText	= "Url Created ".$url."\r\n";
						fwrite($this->logFile, $this->logText);
							
						$xml = new DOMDocument();
							
						if(!$xml->loadXML($response['response'])){
							$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
							//Log Activity
							/* $arrLogDetails = array(
									'type'=>CRON_JOBS,
									'description'=>$this->logText,
									'status' => STATUS_FAIL,
									'transaction_table_id'=>'',
									'transaction_name'=>'Pubmed Processing',
									'miscellaneous1'=>$url
							);
							$this->config->set_item('log_details', $arrLogDetails);
							log_user_activity(null, true); */
							fwrite($this->logFile, $this->logText);
	
							$response = $this ->retrieve_page_get($url);
							//Try once again if the response of the status is false
							if($response['status'] == false){
								//give 2 second delay
								sleep($this->sleepTime);
								$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
								//Log Activity
								/* $arrLogDetails = array(
										'type'=>CRON_JOBS,
										'description'=>$this->logText,
										'status' => STATUS_FAIL,
										'transaction_table_id'=>'',
										'transaction_name'=>'Pubmed Processing',
										'miscellaneous1'=>$url
								);
								$this->config->set_item('log_details', $arrLogDetails);
								log_user_activity(null, true); */
								fwrite($this->logFile, $this->logText);
								//try once again
								$response = $this ->retrieve_page_get($url);
							}
							// Skipp this and log the details if still respons is false
							if($response['status'] == false){
								//log the details
								$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next name, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
								//Log Activity
								/* $arrLogDetails = array(
										'type'=>CRON_JOBS,
										'description'=>$this->logText,
										'status' => STATUS_FAIL,
										'transaction_table_id'=>'',
										'transaction_name'=>'Pubmed Processing',
										'miscellaneous1'=>$url
								);
								$this->config->set_item('log_details', $arrLogDetails);
								log_user_activity(null, true); */
								fwrite($this->logFile, $this->logText);
									
								$this->logText = "Name Combination Crawl : OrgId Id - ".$orgId."  : Name : ".$orgName."\r\n";
								fwrite($this->logFilePmidSkipped, $this->logText);
								//continue to next step
								continue;
							}
	
							if(!$xml->loadXML($response['response'])){
								//log the details and continue
								$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next name, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
								//Log Activity
								/* $arrLogDetails = array(
										'type'=>CRON_JOBS,
										'description'=>$this->logText,
										'status' => STATUS_FAIL,
										'transaction_table_id'=>'',
										'transaction_name'=>'Pubmed Processing',
										'miscellaneous1'=>$url
								);
								$this->config->set_item('log_details', $arrLogDetails);
								log_user_activity(null, true); */
								fwrite($this->logFile, $this->logText);
									
								$this->logText = "Name Combination Crawl : OrgId Id - ".$orgId."  : Name : ".$orgName."\r\n";
								fwrite($this->logFilePmidSkipped, $this->logText);
								continue;
								//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
							}
						}
							
						$idListObj = $xml->getElementsByTagName('IdList')->item(0);
						$idList=$idListObj->getElementsByTagName('Id');
						foreach($idList as $idObj){
							$arrPMIDs[]=$idObj->nodeValue;
						}
					}
					$this->logText	= "Total No of PMIDs found: ".sizeof($arrPMIDs)." \r\n";
					fwrite($this->logFile, $this->logText);
					$timeTaken=microtime(true)-$gathPMIDTime;
					$this->logText	= "Time taken to gather PMIDs: ".(microtime(true)-$gathPMIDTime)."\r\n";
					fwrite($this->logFile, $this->logText);
	
					$arrUniquePMIDs = array_unique($arrPMIDs);
					$arrUniquePMIDs=array_values($arrUniquePMIDs);
					$this->logText	= "\r\nTotal No of PMIDs found after removing duplicates: ".sizeof($arrUniquePMIDs)." \r\n";
					fwrite($this->logFile, $this->logText);
					//End of getting the PubMed ID's
						
					// Reconnect the Database, to ensure that the DB connection is alive
					// On Jan 26, 2012, we faced an issue where the Publications were not getting crawled
					// MySQL idel timeout is 15-20 seconds
					$this->db->close();
					$this->db->initialize();
					//Check for already existing publication's and associate them with org
					$arrFilteredPMIDs=$this->pubmed_org->checkAndAssociateAlreadyExistPubs($arrUniquePMIDs, $orgId,$arrOrgDetail);
					$this->logText	= "Total No of PMIDs found after removing already existing publication's in database: ".sizeof($arrFilteredPMIDs)." \r\n";
					fwrite($this->logFile, $this->logText);
					//End of checking and associating already existing publications
						
						
					//Get the Publication details for all the PubMEd ID's, 10 at a time
					$this->logText	= "\r\nStart of getting the Publication details for each PMID, Processing ".$this->pmidBatchSize." at a time \r\n";
					fwrite($this->logFile, $this->logText);
					for($i=0; $i<sizeof($arrFilteredPMIDs);$i=$i+10){
						//for($i=0; $i<20;$i=$i+$this->pmidBatchSize){
						$authListText='';
						$arrAuthList = array();
						for($j=$i; $j<$i+$this->pmidBatchSize; $j++){
							if( $arrFilteredPMIDs[$j]!='')
								$arrAuthList[] = $arrFilteredPMIDs[$j];
						}
						$authListText = implode(",",$arrAuthList);
	
						$pubFetchStartTime=microtime(true);
						$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$authListText;
						$this->logText	= "Url generated: ".$url."\r\n";
						fwrite($this->logFile, $this->logText);
	
						if($authListText!='')
							$response = $this ->retrieve_page_get($url);
							//Try once again if the response of the status is false
							if($response['status'] == false){
								//give 2 second delay
								sleep($this->sleepTime);
								$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
								//Log Activity
								/* $arrLogDetails = array(
										'type'=>CRON_JOBS,
										'description'=>$this->logText,
										'status' => STATUS_FAIL,
										'transaction_table_id'=>'',
										'transaction_name'=>'Pubmed Processing',
										'miscellaneous1'=>$url
								);
								$this->config->set_item('log_details', $arrLogDetails);
								log_user_activity(null, true); */
								fwrite($this->logFile, $this->logText);
								//try once again
								$response = $this ->retrieve_page_get($url);
							}
							// Skipp this and log the details if still respons is false
							if($response['status'] == false){
								//log the details
								$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
								//Log Activity
								/* $arrLogDetails = array(
										'type'=>CRON_JOBS,
										'description'=>$this->logText,
										'status' => STATUS_FAIL,
										'transaction_table_id'=>'',
										'transaction_name'=>'Pubmed Processing',
										'miscellaneous1'=>$url
								);
								$this->config->set_item('log_details', $arrLogDetails);
								log_user_activity(null, true); */
								fwrite($this->logFile, $this->logText);
									
								$this->logText = "Name Combination Crawl : OrgId Id - ".$orgId."  : Pmids : ".$authListText."\r\n";
								fwrite($this->logFilePmidSkipped, $this->logText);
								//continue to next step
								continue;
							}
	
							$timeTaken=microtime(true)-$pubFetchStartTime;
							$this->logText	= "Time taken to fetch ".$this->pmidBatchSize." publications : ".$timeTaken."\r\n";
							fwrite($this->logFile, $this->logText);
							$xml = new DOMDocument();
	
							if(!$xml->loadXML($response['response'])){
								$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
								//Log Activity
								/* $arrLogDetails = array(
										'type'=>CRON_JOBS,
										'description'=>$this->logText,
										'status' => STATUS_FAIL,
										'transaction_table_id'=>'',
										'transaction_name'=>'Pubmed Processing',
										'miscellaneous1'=>$url
								);
								$this->config->set_item('log_details', $arrLogDetails);
								log_user_activity(null, true); */
								fwrite($this->logFile, $this->logText);
									
								$response = $this ->retrieve_page_get($url);
								//Try once again if the response of the status is false
								if($response['status'] == false){
									//give 2 second delay
									sleep($this->sleepTime);
									$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
									//Log Activity
									/* $arrLogDetails = array(
											'type'=>CRON_JOBS,
											'description'=>$this->logText,
											'status' => STATUS_FAIL,
											'transaction_table_id'=>'',
											'transaction_name'=>'Pubmed Processing',
											'miscellaneous1'=>$url
									);
									$this->config->set_item('log_details', $arrLogDetails);
									log_user_activity(null, true); */
									fwrite($this->logFile, $this->logText);
									//try once again
									$response = $this ->retrieve_page_get($url);
								}
								// Skipp this and log the details if still respons is false
								if($response['status'] == false){
									//log the details
									$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
									//Log Activity
									/* $arrLogDetails = array(
											'type'=>CRON_JOBS,
											'description'=>$this->logText,
											'status' => STATUS_FAIL,
											'transaction_table_id'=>'',
											'transaction_name'=>'Pubmed Processing',
											'miscellaneous1'=>$url
									);
									$this->config->set_item('log_details', $arrLogDetails);
									log_user_activity(null, true); */
									fwrite($this->logFile, $this->logText);
	
									$this->logText = "Name Combination Crawl : OrgId Id - ".$orgId."  : Pmids : ".$authListText."\r\n";
									fwrite($this->logFilePmidSkipped, $this->logText);
									//continue to next step
									continue;
								}
									
								if(!$xml->loadXML($response['response'])){
									//log the details and continue
									$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
									//Log Activity
									/* $arrLogDetails = array(
											'type'=>CRON_JOBS,
											'description'=>$this->logText,
											'status' => STATUS_FAIL,
											'transaction_table_id'=>'',
											'transaction_name'=>'Pubmed Processing',
											'miscellaneous1'=>$url
									);
									$this->config->set_item('log_details', $arrLogDetails);
									log_user_activity(null, true); */
									fwrite($this->logFile, $this->logText);
	
									$this->logText = "Name Combination Crawl : OrgId Id - ".$orgId."  : Pmids : ".$authListText."\r\n";
									fwrite($this->logFilePmidSkipped, $this->logText);
									continue;
									//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
								}
							}
	
							//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
							$this->logText	= "Following Publications with PMID's are parsed and saved sucessfully\r\n ";
							fwrite($this->logFile, $this->logText);
							$publications = $xml->getElementsByTagName('PubmedArticle');
							foreach($publications as $publication){
								$timeElapsed = (microtime(true) - $this->startTime);
								$remTime	=$this->maxScriptTime-$timeElapsed;
								//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed
								if($remTime<$this->safeTime){
									$this->logText	= "Restarting the pubmed processing, Timelimit reached.\r\n ";
									fwrite($this->logFile, $this->logText);
									//die("Sorry! Stopping the pubmed processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);
									$this->send_status_mail($this->logText);
									redirect(base_url()."pubmeds_org/process_pubmeds");
								}
								$pubStartTime=microtime(true);
								//parse and save publication details
								$pubDetails=$this->parse_pub_details($publication);
								$pubId=$this->save_publications('org', $pubDetails, $orgId);
								if($pubId!=null){
									//$this->logText	= "Publication with PMID:".$pubDetails['pmid']." parsed and saved sucessfully\r\n ";
									//fwrite($this->logFile, $this->logText);
								}else{
									$this->logText	= "Error in parsing and saving the Publication with PMID:".$pubDetails['pmid']." \r\n ";
									//Log Activity
									/* $arrLogDetails = array(
											'type'=>CRON_JOBS,
											'description'=>$this->logText,
											'status' => STATUS_FAIL,
											'transaction_table_id'=>'',
											'transaction_name'=>'Pubmed Processing',
											'miscellaneous1'=>$url
									);
									$this->config->set_item('log_details', $arrLogDetails);
									log_user_activity(null, true); */
									fwrite($this->logFile, $this->logText);
									continue;
								}
								//log the last PMID parsed
								file_put_contents($this->logFilePath . "/last_pmid.txt",$pubDetails['pmid']);
									
								//parse and save 'publication-authors'
								$arrAuthors=$this->parse_pub_authors($publication);
								$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
									
								//Calculate Authorship position and save
								//$position=$this->pubmed->calculateAuthorShipPosition($pubId,$orgId,$arrOrgDetail);
								//$this->pubmed->updateAuthorshipPos($orgId,$pubId,$position);
									
								//parse and save MeshTerms
								$arrMeshTerms=$this->parse_pub_meshterms($publication);
								$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
									
								//parse and save 'Substances(chemicals)'
								$arrSubstances=$this->parse_pub_substances($publication);
								$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
									
								//parse and save 'Publication types'
								$arrPubTypes=$this->parse_pub_types($publication);
								$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
									
								//parse and save 'CommentsCorrections(CC)'
								$arrCC=$this->parse_pub_CC($publication);
								$isSaved=$this->save_pub_CC($arrCC, $pubId);
									
								//parse and save 'Pubmed History'
								$arrHistory=$this->parse_pub_history($publication);
								$isSaved=$this->save_pub_history($arrHistory, $pubId);
									
								//parse and save 'Publication Article IDs'
								$arrPubArticleIds=$this->parse_pub_article_ids($publication);
								$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
									
								$timeTaken=microtime(true)-$pubStartTime;
								$this->logText	= " PMID: '".$pubDetails['pmid']."'		Time taken : ".$timeTaken."\r\n";
								fwrite($this->logFile, $this->logText);
							}
							sleep($this->sleepTime);
					}
					//End of loop trough ecah publication, parsjing and saving
					$this->logText	= "End of Procesing all the PMID's \r\n";
					fwrite($this->logFile, $this->logText);
					echo "</br>Pubmed Processing of OrgID :".$arrOrgDetail['id']." is Completed sucessfully</br>";
					$arrOrgDetail['is_pubmed_processed']=1;
					$this->pubmed_org->updatePubmedProcessedOrg($arrOrgDetail);
					$this->logText	= "Pubmed Processing of OrgID :".$arrOrgDetail['id']." is Completed sucessfully \r\n";
					//Log Activity
					/* $arrLogDetails = array(
							'type'=>CRON_JOBS,
							'description'=>$this->logText,
							'status' => STATUS_SUCCESS,
							'transaction_table_id'=>'',
							'transaction_name'=>'Pubmed Processing',
							'miscellaneous1'=>$url
					);
					$this->config->set_item('log_details', $arrLogDetails); */
					//log_user_activity(null, true);
					fwrite($this->logFile, $this->logText);
					$timeTaken=microtime(true)-$orgStartTime;
					$this->logText	= "Total time taken: ".$timeTaken."\r\n";
					fwrite($this->logFile, $this->logText);
						
					/*$numRowsEffected = $this->pubmed->updateZeroAuthPosPubsAsDeleted($orgId);
					 echo "Number of publications marked as deleted : ".$numRowsEffected."</br>";
					 $this->logText	= "Number of publications marked as deleted : ".$numRowsEffected."\r\n";
					 fwrite($this->logFile, $this->logText);*/
					$this->logText	= "--------------------------- \r\n";
					fwrite($this->logFile, $this->logText);
					$this->send_status_mail("Pubmed Processing of OrgID :".$arrOrgDetail['id']." is Completed sucessfully ");
						
				}
				$this->send_status_mail("Pubmed Processing Ended..");
				// End of loop trought each org
	}
}
