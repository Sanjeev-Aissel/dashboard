<script language="javascript" type="text/javascript"
	src="<?php echo base_url() ?>js/chosen.jquery.js"></script>
<script language="javascript" type="text/javascript"
	src="<?php echo base_url() ?>js/jquery/jquery.validate1.9.min.js"></script>
<link href="<?php echo base_url();?>css/chosen.css" media="screen"
	rel="stylesheet" />
<style type="text/css">
select.chosenMultipleSelect {
	width: 200px;
}

.show {
	display: block;
}

.hide {
	display: none;
}

.microView .ui-dialog-content {
	background-color: white;
}

.users {
	list-style-type: none;
	margin: 0;
	padding: 0
}

.users li {
	float: left;
}

.editIcon {
	margin-left: 3px;
}
</style>
<script type="text/javascript">
$(document).ready(function (){
	$('.chosenMultipleSelect').chosen({
		allow_single_deselect: true
	});
});
function validateImportForm(thisEle){
	if($(thisEle).val() =="Import"){

		if($('#masterImport').val()==''){
		jAlert("Please select the file to Import");
			
			return false;
		}else{
			var clientIds = $('#clientId').val();
			var clientId = new Array();
			if(clientIds == null){
				jAlert("Associate atleast one client");
				return;
			}
			var action ="<?php echo base_url()?>master_data_controller/upload_zip_file/";
			$('#masterImportForm').attr('action',action);
			$('#masterImportForm').submit();
		}
	}
}
</script>
<div class="importMasterData">
	<form
		action="<?php echo base_url();?>master_data_controller/upload_zip_file"
		name="masterImportForm" id="masterImportForm" method="post"
		enctype="multipart/form-data">
		<p>
		<table>
			<tr>
				<td><label><h4>Associate Clients:</h4></label></td>
				<td><select name="clientIds[]" multiple="multiple" id="clientId"
					class="chosenMultipleSelect" data-placeholder="Select Clients">
						<option disabled="disabled" value="">Select Clients</option>					
			            <?php foreach($arrClients as $clients){ ?>
			            <option value="<?php echo $clients['id'];?>"
							<?php if(in_array($clients['id'],$arrSelected)){ echo "selected = selected";} ?>><?php echo $clients['name']; ?></option>
			            <?php } ?>
            		</select>
            	</td>
			</tr>
		</table>
		</p>
		<p>
			<label>Import Master Data :</label> <input type="file"
				name="master_import" id="masterImport" />('.xls' files only)
		</p>
		<input type="button" value="Import" id="masterImportButton"
			onclick="validateImportForm(this)" />
	</form>
</div>
<!-- Modal content -->
<div id="specclientContainer" class="microViewLoading">
	<div class="addSpecclientContent"></div>
</div>
<div class="addClientsMsgBox"></div>