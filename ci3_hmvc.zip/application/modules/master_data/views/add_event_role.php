
<!-- <h1>Add Specialty</h1> -->
<div class="eventrolesMsgBox"></div>
<form>
	<div align="center">
		<caption><h4>Add/Edit Event Role</h4></caption>
	</div>
	<table class="anaylystForm eventTbl ">

		<br />
		<tr>
			<td><div align="center">
					<span id="responseMessage"></span>
				</div>
				<p>
					<input type="hidden" id="hiddenId" readonly>
				
				<div align="center">
				<label>Event Role:</label><input type="text" name="eventroles" id="eventroles"
						align="center" />
				</div>
				</p></td>
		</tr>
		<tr>
			<td>
				<div class="formButton" align="center">
					<input type="button" value="Save" name="submit"
						onclick="saveEventRole();"></input> <input type="button"
						value="Cancel" name="submit" onclick="closeModal();"></input>
				</div>
			</td>
		</tr>
	</table>
	<!-- End of Table -->
</form>
<!-- End of User Form -->
