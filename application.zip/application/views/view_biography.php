<?php
/**
 * Displays the Biography Information of KOLs
 *
 * Created By:
 * Created On:
 
 function listRecordsPerPage($maxRecords=100,$increament=10){
 $rowList="";
 for($i=10;$i<=$maxRecords;$i+=$increament){
 $rowList.=$i.",";
 }
 $rowList=substr($rowList,0,-1);
 return $rowList;
 }
 $isCustomerProfile	= 0;
 /*if($clientId!=INTERNAL_CLIENT_ID && ($arrKol['status']!=COMPLETED)){
 $isCustomerProfile = 1;
 }*/
?>
<?php
	// prepare array of JS files to insert into queue
	//$queued_js_scripts = array('kols/view_biography','highcharts 2.1.0','highchartsTheme','i18n/grid.locale-en','jquery.jqGrid.min','jquery.validate','jquery/jquery-ui-1.8.16.slider','jquery/jquery-ui-1.8.16.datepicket','jquery-ui-timepicker-addon 0.9.3');
	$queued_js_scripts = array('kols/view_biography',
           // 'highcharts2_2_2/highcharts3.0.5',
           // 'highcharts2_2_2/modules/exporting3.0.5',
            'i18n/grid.locale-en','jquery.jqGrid.min',
            'jquery/jquery.validate1.9.min',
            'jquery/jquery-ui-1.8.16.slider',
            'jquery/jquery-ui-1.8.16.datepicket',
            'jquery-ui-timepicker-addon 0.9.3',
            'CalendarControl',
            'chosen.jquery',
            'jit.forecedirected&rgraph_mix',
            'jquery.autocomplete');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));

$autoSearchOptions = "width: 278, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3,onSelect : function(event, ui) {doSearchFilter1(-1);}";

?>

<!--[if (IE)]>
	<script type="text/javascript">window['isIE'] = true;</script>
	<script language="javascript" type="text/javascript" src="<?php echo base_url()?>js/excanvas.js"></script>
<![endif]-->
	<!-- JQGrid Plugins -->
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
	
	<!-- Month Year Selection Calendar plugin -->
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/StyleCalender.css" />
	<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet" />
	
    	<!-- Load c3.css -->
    <link href="<?php echo base_url();?>c3js/c3.css" rel="stylesheet" type="text/css">
    
    <!-- Load d3.js and c3.js -->
    <script src="<?php echo base_url();?>c3js/d3.v3.min.js" charset="utf-8"></script>
    <script src="<?php echo base_url();?>c3js/c3.min.js"></script>    
    
<style type="text/css">   
	.spaceBtwList{
		height:20px;
	}
	
	/** One additional Row below the Title of Grid Header */
	.ui-jqgrid .ui-userdata {
		display:none;
	}
	
	.ui-jqgrid tr.jqgrow td{
		padding:6px 3px;
	}
	
	.pieCharts{
		clear: both;
	}
	
	.pieCharts div{
		width: 48%;
		float: left;
	}
	
	.barCharts{
		clear: both;
	}
	
	.barCharts div{
		width: 48%;
		float: left;
	}
	
	#meshTermsChart{
		
	}
	.savebtn{
	   background: none !important;
	   border: none;
	}
	.savebtn :HOVER{
	   background: none !important;
	   border: none;
	}
	
	#bio {
		-moz-border-radius-bottomleft:10px;
		-moz-border-radius-bottomright:10px;
		-moz-border-radius-topleft:10px;
		-moz-border-radius-topright:10px;
		border:1px solid #EEEEEE;
		padding:10px;
		background-image: url(images/header-bg.gif);
		margin-bottom: 5px;
		padding-bottom: 0px;
		padding-left: 10px;
		padding-right: 10px;
		padding-top: 10px;
		margin-bottom: 10px;
	}
	#addressBio{
		text-align:left;
	}
	#addressInfo .kolName{
		color:#000000;
		color:#333333;		
		font-size:15px;
		font-weight:bold;
		float: left;
	}
	
	#addressInfo .speciality{
		font-size: 10pt;
		font-size: 8pt;
  /*  	margin-left: 60px;
   	 	margin-top: -3px;*/
   	 	margin-top: 12px;
	}
	
	#addressInfo p{
		padding:0;
		margin:0;
		color:#666666;
		color:#626262;
		color:#333333;
		letter-spacing:1px;
	}
	
	#addressInfo p.addrHeading{
		text-transform: uppercase;
		font-weight: bold;
		margin-top:5px;
		letter-spacing:1px;
	}
	
	#addressInfo table{
		font-family: lucida grande, tahoma, verdana, helvetica, arial;
		color:#626262;
		margin-bottom: 0px;
	}
	
	.activityName{

	}	
	
	#activityInfo lable{
		padding-right:2px;
	}
	
	#activityInfo td{
		padding-left: 0px;
		color: #333333;
		letter-spacing: 1px;
	}
	
	#bio_research{
		border:0px solid red;
		height:auto;
		text-align: justify;
		
		color:#525252;
		font-family:georgia;
		font-size:95%;
		line-height:150%;
		text-align:justify;	
		
		border:0 solid red;
		color:#626262;
		font-family:tahoma;
		fona-family:lucida grande, tahoma, verdana, helvetica, arial;
		font-size:85%;
		font-size:12px;
		height:auto;
		line-height:150%;
		text-align:justify;		
	}
	
	#bio_research h1{
		text-transform: uppercase;
		font-weight: bold;
		font-size: 13px;
		border-bottom:1px solid black;
		padding-bottom:5px;
		letter-spacing: 1px;
	}
	
	table.eduList{
		border-left:1px solid #CCCCCC;
		border-bottom:1px solid #CCCCCC;
	}
	table.eduList caption{
		font-size:12pt;
		font-weight:bold;
		padding-bottom:5px;
		text-transform:uppercase;	
		background: none;
	}
	
	table.eduList tr, 	table.eduList tr.even td{
		background:transparent url(../../images/bg_td1.jpg) repeat-x scroll center top;	
	}
	
	table.eduList tr.odd td{
		background:transparent url(../../images/bg_td2.jpg) repeat-x scroll 0 0;
	}
	
	table.eduList th, table.eduList td{
		border-right:1px solid #DDDDDD;
		border-top:1px solid #FFCA5E;
		color:#777777;
		font-family:Arial,Helvetica,sans-serif;
		font-size:0.8em;
		line-height:1.4em;
		padding:10px 7px;
		text-align:left;	
	}
	
	#addressInfo p.kolTitleOrg{
		color:#626262;
		font-weight:bold;
		letter-spacing:1px;
	}
	
	#bioDetails a {
		color:#000099;
		text-decoration:underline;
	}
	.addLink label{
		float: none;
	}
	.ui-tabs-nav li a {
		text-decoration: none;	
		border:0px;
		border-collapse: collapse;
	}
	#interactionsByMonthChart,#interactionsByTypeChart,#paymentsByYearChart{
		margin-bottom: 5px;
	}
	#timeLineSliderContainer p {
		margin-top: 0px;
	}
	div.deleteIcon {
        margin-right: 10px;
    }
    div.actionIconsContainer{
		margin-left: 10px;
	}
	div.actionIconsContainer div.deleteIcon{
		margin-right: 0px;
	}
	
	#kolAdressInfo th, td, caption {
		padding: 4px 0 4px 5px;
	}
	.show_more:HOVER{
	background: #d3dfed;
    }
    .show_more{
    	height: 25px;
        line-height: 25px;
        text-align: center;	
    }
    .show_more a{
    	color: blue !important;
        display: block;
        width: 100%;
        text-decoration: underline !important;
    }
	.addLink{
		text-align: right;
		margin-right: 5px;
	}
	.gridWrapper{
		width: 100%;
	}
	div#contentHolder{
		width: auto !important;
		min-width: 260px;
		max-width: 600px;
	}
	.trOddRow{
		background-color: #DDDDDD;
	}
	.trEvenRow{
		background-color: #EAEAEA;
	}
	#assessmentRating select{
		width:200px;
	}
	#assessmentRating .evenRow{
		background-color: #F5F5F5;
	}
	#addInteractionContainer,#editInteractionContainer{
		display:none;
		min-height: 400px;
		min-width: 400px
	}
	.two-row{
/*		display:inline;
		float:left;
		height: 300px;
*/
	}
	#interactionsByTopicChart{
		float: left;
	    width: 100%;
	}
	.one-row .highcharts-container{
		margin:auto;
	}
	#view1Infovis {
	    position:relative;
	    width:400px;
	    height:320px;
	    margin:auto;
	    overflow:hidden;
	}
	#view1Infovis .name a{
		color: black !important;
		font-size:9px !important;
		text-decoration: none !important;
		font-family: "Droid Sans","Segoe UI",tahoma,arial,"Trebuchet Ms" !important;
	}
	#view1Infovis .node {
	    margin-top: -10px;
	}
	.map-header-label{
		font-size: 14px;
	    text-align: left;
	    width: 399px;
	    background-color: #eeeeee;
	    display:block;
	    height: 25px;
	    font-family: "Droid Sans","Segoe UI",tahoma,arial,"Trebuchet Ms" !important;
	    color: #333333;
	}
	#kolProfileScoreChart{
		width:400px;
		height:320px;
		margin:auto;
	}
	#kolProfileScoreChart #profileScoreReportLink, #kolProfileScoreChart #profileScoreHeading{
		display:none;
	}
	#kolProfileScoreChart #profileScoreReport{
		margin-top:50px;
	}
	#kolProfileScoreChart .map-header-label{
		
	}
	#dashboardTable td{
		padding:0px;
	}
/*	#dashboardTable td:HOVER{
		background-color: #F9F9F9;
	}
*/	.dashboardCharts > div{
		margin:auto;
	}
	.secondColumn{
		border-bottom:1px solid #eeeeee;
	}
	.firatColumn{
		border-right:1px solid #eeeeee;
		border-bottom:1px solid #eeeeee;
	}
	#kolProfileScoreChart .left{
		display:none;
	}
	#kolProfileScoreChart .progress{
		width:194px !important;
	}
	#bottomBar{
		
	}
	.chart-to-tab-links{
		background: none repeat scroll 0 0 #A3A3A3;
	    cursor: pointer;
	    display: block;
	    float: right;
	    font-size: 11px;
	    margin-left: 310px;
	    position: absolute;
	    text-align: center;
	    width: 80px;
	    margin-top: -19px;
    	padding-top: 1px !important;
    	height: 14px;
    	z-index: 1000;
	}
	.chart-to-tab-links a{
		 color: white;
		 text-decoration:none;
	}
	#kolProfileScoreChart table{
    	margin-top: 10px !important;
	}
	#kolProfileScoreChart #inner{
		border-bottom:1px solid #eeeeee;
		height: 100px;
	}
	#psrl{
		margin-left: 270px;
    	width: 120px;
	}
	#inner #profileScoreReport .right, #assessment #asmtScoreReport .alignRight{
		font-weight: normal !important;
		padding-right:2px;
	}
	.highcharts-container span {
		background-color: #ffffff;
	}
	#emailIdLink{
		display: block;
	    width: 250px !important;
	    word-wrap: break-word !important;
	}
	#interactionGridContainer{
		padding-top: 8px;
	}
	#kolProfileScoreChart td{
		border-right: 0px;
	}
	.rightBorder{
		border-collapse: separate;
		border-spacing: 1;
	}
	
	.editTextarea{
		width: 94% !important;
		/*height: 20px !important;*/
		margin-left: 0 !important;
    	margin-top: 0 !important;
	}
	div.saveIcon{
		/*background: url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat scroll -220px -30px transparent;*/
		/*background: url("<?php echo base_url();?>images/save_active.png") no-repeat scroll 0px 0px / 20px auto;*/
		background-image: url("<?php echo base_url();?>images/save_active.png");
	    background-position: 0 0 !important;
	    background-repeat: no-repeat !important;
	    background-size: 20px auto !important;
		
	}
	div.saveIcon:HOVER{
		/*background: url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat scroll -220px -30px transparent;*/
		background: url("<?php echo base_url();?>images/save_inactive.png") no-repeat scroll 0px 0px / 20px auto;
		
	}
	div.cancelIcon{
		/*background: url("<?php echo base_url();?>images/delete_active.png") no-repeat scroll 0px 0px / 20px auto;*/
		background-image: url("<?php echo base_url();?>images/delete_active.png");
	    background-position: 0 0 !important;
	    background-repeat: no-repeat !important;
	    background-size: 20px auto !important;
	    margin-left: 5px;
	}
	div.cancelIcon:HOVER{
		background: url("<?php echo base_url();?>images/delete_inactive.png") no-repeat scroll 0px 0px / 20px auto;
	}
	#user-notes h1{
		border-bottom: 1px solid black;
	    font-size: 13px;
	    font-weight: bold;
	    letter-spacing: 1px;
	    padding-bottom: 5px;
	    text-transform: uppercase;
	}
	#notes-container ul li div span{
		display: block;
    	width: 49%;
    	cursor: pointer;
    	word-wrap: break-word;
	}
	
	#user-notes h4{
	 	/*background:url("<?php echo base_url(); ?>images/kolm-sprite-image.png") repeat-x scroll -2px -236px transparent;*/
	 	font-size: 100%;
	    font-weight: bold;
	    margin-top: 20px;
	    margin-right: 5px;
	    padding: 6px;
	    
	    background: #ececec none repeat scroll 0 0;
	    /*border-bottom: 0 none;*/
	    box-shadow: 0 0 4px #d1d1d1 inset;
	    color:#111111;
	 }
	 #user-notes{
	 	position: relative;
	 }
	 #add-notes{
		position: absolute;
	    right: 5px;
	    top: 5px;	 	
	 }
	 div.editIcon {
	    margin-left: 10px;
	    margin-right: 2px;
	}
	div.downloadIcon {
        background-image: url("<?php echo base_url()?>images/download_btn_grey.png") !important;
        background-position: 20px 0px !important;
        background-repeat: no-repeat !important;
        background-size: 18px auto !important;
        margin-right: 410px;
        width: 80px;
        font-size: 10px;
    }
    div.downloadIcon:HOVER {
        background-image: url("<?php echo base_url()?>images/download_btn.png") !important;
        color: #2B9AF3;
    }
    #notes-container ul li{
    	padding-bottom: 5px;
    }
    #notes-container ul li:last-child{
    	padding-bottom: 10px;
    }
    .ui-th-ltr, .ui-jqgrid .ui-jqgrid-htable th.ui-th-ltr{
        padding: 3px 0;
    }
    #pageContentWrapper{
	padding: 0px 10px !important;
}
.dataTypeIndicator a{
    margin-left: 4px;
}
#JQBlistConferenceResultSet .dataTypeIndicator a, #trials .dataTypeIndicator a, #JQBlistAllResultSet .dataTypeIndicator a{
    margin-left: 0px;
}
</style>


<script type="text/javascript">
var additionalContact = "<?php echo lang('Overview.ADDITIONAL_CONTACT')?>";	
var educationCaption = "<?php echo lang('Overview.EDUCATION')?>";
var trainingCaption = "<?php echo lang('Overview.TRAINING')?>";
var boardCaption = "<?php echo lang('Overview.BOARDCERTIFICATION')?>";
var awardCaption = "<?php echo lang('Overview.HONORSANDAWARDS')?>";
var InteractionCaption = "<?php echo lang('Track.Interactions')?>";
var PaymentsCaption = "<?php echo lang('Overview.Payments')?>";
//var LocationsCaption = "<?php //echo lang('Overview.LOCATIONS')?>";
var clientKOLs	= '<?php echo $clientKols;?>';
var type ="<?php echo lang('Overview.Type')?>";
var address ="<?php echo lang('Overview.Address')?>";
var phone ="<?php echo lang('Overview.Phone')?>";
var institutionName ="<?php echo lang('Overview.InstitutionName')?>";
var degree="<?php echo lang('Overview.Degree')?>";
var specialty ="<?php echo lang('Overview.Specialty')?>";
var timeFrame ="<?php echo lang('Overview.TimeFrame')?>";
var action ="<?php echo lang('Overview.Action')?>";
var date ="<?php echo lang('Overview.Date')?>";
var recordedBy ="<?php echo lang('Overview.RecordedBy')?>";
var channel ="<?php echo lang('Overview.Channel')?>";
var product ="<?php echo lang('Overview.Product')?>";
var honorName ="<?php echo lang('Overview.HonourName')?>";
var requestedBy ="<?php echo lang('Overview.requestedBy')?>";
var paidBy ="<?php echo lang('Overview.paidBy')?>";
var amount ="<?php echo lang('Overview.amount')?>";
var organizationName ="<?php echo lang('Overview.OrganizationName')?>";
var department ="<?php echo lang('Overview.Department')?>";
var title = "Role / Purpose";//"<?php echo lang('Overview.title');?>";
var orgType ="<?php echo lang('Overview.OrgType')?>";
var engType ="<?php echo lang('Overview.engType')?>";
var allInteractions ="INTERACTIONS";
var allAffiliations ="AFFILIATIONS";
var sessionType = "<?php echo lang("Mykols.SessionType");?>";
var topic = "<?php echo lang("Overview.Topic");?>";
var role = "<?php echo lang("Mykols.Role");?>";
var articleTitle = "<?php echo lang("Overview.ArticleTitle");?>";
var journalName = "<?php echo lang("Overview.JournalName");?>";
var authPosition = "<?php echo lang("Mykols.AuthPosition");?>";
var trialName = "<?php echo lang("Overview.TrialName");?>";
var sponsors = "<?php echo lang("Overview.Sponsers");?>";
var condition = "<?php echo lang("Overview.Condition");?>";
var intervention = "<?php echo lang("Overview.Intervention");?>";
var phase = "<?php echo lang("Overview.Phase");?>";
jqgridIds	= new Array('JQBlistContactsResultSet','JQBlistEducationResultSet','JQBlistTrainingResultSet','JQBlistBoardResultSet','JQBlistAwardResultSet','listPaymentsResultSet');
var chartBackgroundColor	= 'transparent';
	if(window.isIE){
		chartBackgroundColor	= '#FFFFFF';
	}
	function rowList(Start,max){
		var rowlist=new Array();
		for(var i=Start;i<=max;i+=10){
			rowlist.push(i);
		}
		return rowlist;
	}
	var kolId="<?php echo $arrKol['id'];?>";
	var uniqueId="<?php echo $arrKol['unique_id'];?>";
	//Initiallize the Timeline slider
	<?php $date=date('Y');?>
	var minYear=<?php echo $arrYearRange['min_year'];?>;
	var maxYear=<?php echo $arrYearRange['max_year'];?>;
	
	var rangeValue1=minYear;
	var rangeValue2=maxYear;
	//Conditions data for Role based user
	var userRoleId 			=	'<?php echo $this->session->userdata('user_role_id');?>';
	var clientId 			=	'<?php echo $this->session->userdata('client_id');?>';
	var userId 				=	'<?php echo $this->session->userdata('user_id');?>';
	//Constants
	var INTERNAL_CLIENT_ID 	=	'<?php echo INTERNAL_CLIENT_ID?>';
	var ROLE_MANAGER 		=	'<?php echo ROLE_MANAGER ?>';
	var ROLE_ADMIN 	= '<?php echo ROLE_ADMIN?>';
	var ROLE_USER 			=	'<?php echo ROLE_USER ?>';
	var specialtyId 		= 	'<?php echo $arrKol['specialty'];?>';

	var base_url="<?php echo base_url()?>";

	//Hide the column recorded by if the logged in user role is not manager
	var userRole=<?php echo $this->session->userdata('user_role_id');?>	;
   	var managerRoleId=<?php echo ROLE_MANAGER;?>;
	var adminRoleId=<?php echo ROLE_ADMIN;?>;
   	var subContentPage	= '<?php echo $subContentPage;?>';
   	var subContentParam	= '<?php echo $subContentParam?>';
   	<?php if(isset($maxKolRatingScore)){?>
			var asmtScore = '<?php echo (array_sum($maxKolRatingScore)/array_sum($maxRatingScore))*100?>';
	<?php }else{?>
			var asmtScore=0;
	<?php }?>
	var isCustomerProfile=0;
	<?php if(!empty($isCustomerProfile)){?>
	var isCustomerProfile = <?php echo $isCustomerProfile;?>;
	<?php } ?>
</script>
	
	<input type="hidden" id=""></input>
	<div id="kolOverviewTernaryNav" class="span-20 last">
		<!--<ul class="span-3 append-1 ternaryNav" >
			<?php $this->load->view('elements/kol_short_details_client_view');?>
			<li><a href="#bioDetails">Biography</a></li>  
			<li><a href=#personalInfoContainer>Personal Info</a></li>                 
			<li><a href=#interaction id="interactionType">Interactions</a></li>                  
			<li ><a href="#kolPayments" id="payementType">Payments</a></li>
			<li><a href="#overviewDashBoard">Dashboard</a></li>                  
		</ul>
		
		-->
		<?php 
			switch($subContentPage){
						case 'personalinfo': 
		?>					<!-- Start of Personal Info Details -->
							<div id="personalInfoContainer">
								<?php
									$this->load->view('kols/view_personal_info',$personalData);
								?>
							</div>
							<!-- End of Personal Info Details -->
		<?php 
						break;	
				case 'view_interaction': 
		?>
							<div id="addEditInteractionWrapper">
								<div id="viewInteractionContainer"></div>
							</div>
		<?php 
						break;	
				case 'add_interaction': 
		?>
							<div id="addEditInteractionWrapper">
								<div id="addInteractionContainer" style="display: block;"></div>
								<div id="editInteractionContainer"></div>
							</div>
							<div id="interactionsContainer" style="display:none;">
								<p style="margin-bottom:5px;width:550px;vertical-align: middle;margin-top: -20px;float: left;">
									<label for=monthlyreport>Month From :</label>
									<input type="text" name="monthlyreport" id="monthlyreport" value="Click to select" placeholder="Click to select" onfocus="showCalendarControl(this.id);" />
									<label for=monthlyreport>To:</label>
									<input type="text" name="monthto" id="monthto" value="Click to select" placeholder="Click to select" onfocus="showCalendarControl(this.id);" />
									<input type="button" value="Apply Filter" id="filterbutton" onclick="listInteractions()" />
								</p>
								<!-- Start of Interaction Details -->
								<div id="interaction">
									<form action="<?php echo base_url()?>interactions/export_interaction_details/<?php echo $arrKol['id']?>" method='post' id="export">
										<input type="hidden" name="interaction_ids" value="" id='ids'></input>
										<input type="hidden" name="filters" id="excel-filters" />
									</form>
									<div class="addLink" style="padding-left:81%;padding-bottom:1px;"><label onclick="addInteraction();" id="addButton"><div class="actionIcon addIcon"></div>Add Interaction</label>
									<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="export_excel();" style="float:right">
										<a href="#" rel="tooltip" data-original-title="Export Interaction Detail into Excel format">&nbsp;</a>
									</div>
									</div>
									<div class="gridWrapper" id="interactionGridContainer">
										<div id="listInteractionsPage"></div>
										<table id="listInteractionsResultSet"></table>
									</div>
								</div>
							</div>
		<?php 
						break;
				case 'interaction':
		?>
							<div id="addEditInteractionWrapper">
								<div id="addInteractionContainer"></div>
								<div id="editInteractionContainer"></div>
								<div id="viewInteractionContainer"></div>
							</div>
							<div id="interactionsContainer">
								<div class="exportOptionsContainer">
									<ul class="pageRightOptions">
										<li>
											<label for=monthlyreport>Month From :</label>
											<input type="text" name="monthlyreport" id="monthlyreport" value="Click to select" placeholder="Click to select" onfocus="showCalendarControl(this.id);" />
											<label for=monthlyreport>To:</label>
											<input type="text" name="monthto" id="monthto" value="Click to select" placeholder="Click to select" onfocus="showCalendarControl(this.id);" />
											<input type="button" value="Apply Filter" id="filterbutton" onclick="listInteractions()" />
										</li>
										<li>
											<label class="link" onclick="addInteraction();" id="addButton"><div class="actionIcon addIcon"></div>Add Interaction</label>
										</li>
										<li>
											<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="export_excel();" style="float:right">
												<a href="#" rel="tooltip" data-original-title="Export Interaction Detail into Excel format">&nbsp;</a>
											</div>
										</li>
									</ul>
								</div>
							
							<!-- Start of Interaction Details -->
							<div id="interaction" class="clear">
								<form action="<?php echo base_url()?>interactions/export_interaction_details/<?php echo $arrKol['id']?>" method='post' id="export">
									<input type="hidden" name="interaction_ids" value="" id='ids'></input>
									<input type="hidden" name="filters" id="excel-filters" />
								</form>
								<div class="gridWrapper" id="interactionGridContainer">
									<div id="listInteractionsPage"></div>
									<table id="listInteractionsResultSet"></table>
								</div>
							</div>
							</div>
							<!-- End of Interaction Details -->
		<?php 
						break;	
				case 'payments':
		?>
							<div>
								<div class="exportOptionsContainer">
									<ul class="pageRightOptions">
										<li>
											<label for=monthlyreport>Month From :</label>
											<input type="text" name="monthlyreport" id="monthlyreport" value="Click to select" placeholder="Click to select" onfocus="showCalendarControl(this.id);" />
											<label for=monthlyreport>To:</label>
											<input type="text" name="monthto" id="monthto" value="Click to select" placeholder="Click to select" onfocus="showCalendarControl(this.id);" />
											<input type="button" value="Apply Filter" id="filterbutton" onclick="listPayments()" />
										</li>
										<li>
											<label class="link" onclick="addPayment();" id="addButton"><div class="actionIcon addIcon"></div>Add Payment</label>
										</li>
										<li>
											<div class="excelExportIcon sprite_iconSet tooltip-demo tooltop-left" onclick="export_excel();" style="float: right;">
												<a href="#" rel="tooltip" data-original-title="Export Payment Details into Excel format">&nbsp;</a>
											</div>
										</li>
									</ul>
								</div>
								<!-- Start of Payments Details -->
								<div id="kolPayments" class="clear">
									<!--Form to export payment details-->
									<form action="<?php echo base_url()?>payments/export_payment_details/<?php echo $arrKol['id']?>" method='post' id="export">
										<input type="hidden" name="payment_ids" value="" id='ids'></input>
										<input type="hidden" name="filters" id="excel-filters" />
									</form>
									<div class="gridWrapper" id="payementGridContainer">
										<div id="listPaymentsPage"></div>
										<table id="listPaymentsResultSet"></table>
									</div>
								</div>
								<!-- End of Payments Details -->
							</div>
		<?php 
						break;	
				case 'dashboard': 
		?>					
							<?php if($this->session->userdata('client_id') ==1 && $this->session->userdata('user_role_id')==2){ ?>
								<a style="display: block; clear: both; float: right; margin-top: -21px;" target="_new" href="<?php echo base_url();?>kols/calculate_dashboard_data/<?php echo $arrKol['id'];?>">Recalculate dashboard data</a>
							<?php }?>
							<!-- Start of Interaction Details -->
							<div id="overviewDashBoard">
								<table id="dashboardTable" class="tableSections">
									<tr class="tableHeader interactionChartsForDashboard">
        								<th class="rightBorder" colspan="2">Interactions By Topic <a class="blueButton" style="float: right;" href="<?php echo base_url();?>kols/view/<?php echo $arrKol['id'];?>/interaction_report" target="_NEW">Interactions</a></th>
        								
        								<th colspan="2">Interactions By Type <a class="blueButton" style="float: right;" href="<?php echo base_url();?>kols/view/<?php echo $arrKol['id'];?>/interaction_report" target="_NEW">Interactions</a></th>
        							</tr>
        							<tr>
        								<td class="rightBorder" colspan="2">
        									<div class="">
        										<div id="interactionsByTopic"></div>
        									</div>
        								</td>
        								<td colspan="2">
        									<div class="">
        										<div id="interactionByChannel"></div>
        									</div>
        								</td>
        							</tr>
									<tr class="tableHeader">
										<th><?php echo lang("Mykols.KOLRating");?></th>
										<th class="alignRight rightBorder"><a class="blueButton" href="<?php echo base_url();?>reports/view_reports/rating/<?php echo $arrKol['id'];?>/<?php echo $arrKol['specialty'];?>" target="_NEW">Profile Score Report</a></th>
										<th><?php echo lang("Mykols.KOLNetworkMap");?></th>
										<th class="alignRight">
											<!--?php $mobile = mobile_device_detect(); ?>
											<a class="blueButton" href="<?php echo base_url();?>maps/view_influence_map<?php echo (!isset($mobile[1]))?'':'_ipad'.'/'.$arrKol['id'];?>" target="_NEW">Net Map</a-->
											<?php $mobile = mobile_device_detect(); $infMApLinkPref = isset($mobile[1]) ? '_ipad' : '';?>
											<a class="blueButton" href="<?php echo base_url();?>maps/view_influence_map<?php echo $infMApLinkPref.'/'.$arrKol['id'];?>" target="_NEW">Net Map</a>
										</th>
									</tr>
									<tr>
										<td colspan="2" class="rightBorder">
											<div id="kolProfileScoreChart" class="dashboardCharts two-row">
												<label>Profile Score: <?php echo round($kolsPforfileScore);?>%</label>
												<div id="inner">
													&nbsp;
												</div>
												<?php if(ASSESSMENT_STATUS){ ?>
												<label>Assessment Score: <?php echo round($asmtPercentageScore);?>%</label>
												<div id="assessment">
													&nbsp;
												</div>
												<?php } ?>												
												<div id="recentInteraction" style="padding-bottom: 20px">
													
												</div>
											</div>
										</td>
										<td colspan="2"><div id="view1Infovis" class="dashboardCharts two-row"></div></td>
									</tr>
									<tr class="tableHeader">
										<th><?php echo lang("Mykols.AffiliationsByOrganizationType");?></th>
										<th class="alignRight rightBorder"><a class="blueButton" href="<?php echo base_url();?>kols/view_affiliations/<?php echo $arrKol['id'];?>" target="_NEW">Affiliations</a></th>
										<th><?php echo lang("Mykols.AffiliationsByEngagementType");?></th>
										<th class="alignRight"><a class="blueButton" href="<?php echo base_url();?>kols/view_affiliations/<?php echo $arrKol['id'];?>" target="_NEW">Affiliations</a></th>
									</tr>
									<tr>
										<td colspan="2" class="rightBorder" style="text-align: center;"><div id="affiliationsChartByOrgTypeNew" class="dashboardCharts two-row"></div></td>
										<td colspan="2" style="text-align: center;"><div id="affiliationsChartByEngTypeNew"></div></td>										
									</tr>
									<tr class="tableHeader">
										<th><?php echo lang("Mykols.EventsByYear");?></th>
										<th class="alignRight rightBorder"><a class="blueButton" href="<?php echo base_url();?>kols/view_events/<?php echo $arrKol['id'];?>" target="_NEW">Events</a></th>
										<th><?php echo lang("Mykols.EventsByTopic");?></th>
										<th class="alignRight"><a class="blueButton" href="<?php echo base_url();?>kols/view_events/<?php echo $arrKol['id'];?>" target="_NEW">Events</a></th>
									</tr>
									<tr>
										<td colspan="2" class="rightBorder" style="text-align: center;"><div id="eventsByTimelineNew" class="dashboardCharts two-row"></div></td>
										<td colspan="2" style="text-align: center;"><div id="eventsChartByTopicNew" class="dashboardCharts two-row"></div></td>
									</tr>
									<tr class="tableHeader">
										<th><?php echo lang("Mykols.PublicationsByYear");?></th>
										<th class="alignRight rightBorder"><a class="blueButton" href="<?php echo base_url();?>kols/view_publications/<?php echo $arrKol['id'];?>" target="_NEW">Publications</a></th>
										<th><?php echo lang("Mykols.PublicationsByAuthorshipPosition");?></th>
										<th class="alignRight"><a class="blueButton" href="<?php echo base_url();?>kols/view_publications/<?php echo $arrKol['id'];?>" target="_new">Publications</a></th>
									</tr>
									<tr>
										<td colspan="2" class="rightBorder" style="text-align: center;"><div id="pubsChartNew" class="dashboardCharts two-row"></div>
										</td>
										<td colspan="2" style="text-align: center;"><div id="pubAuthPosChartNew" class="dashboardCharts two-row"></div>
										</td>
									</tr>
								</table>
							</div>
							<!-- End of Interaction Details -->
		<?php 
						break;
		case 'assessment':
			?>
					<!-- Start of Assessment Rating -->
							<div id="assessmentRating">
								<?php 
								  if(isset($arrAsmtRatings)){
								?>
									<form name="asmtRatings" action="<?php echo base_url();?>kol_ratings/save_assessment_ratings" method="post">
									<input type="hidden" name="kol_id" value="<?php echo $arrKol['id'];?>" />
									<table>
										<tr class="tableHeader">
											<th><?php echo lang("Mykols.Category");?></th><th><?php echo lang("Mykols.Criteria");?></th><th><?php echo lang("Mykols.Rating");?></th>
										</tr>
								<?php 
									//pr($arrCriteriaRating);
									$altBgColorFlag	= 0;
									foreach($arrAsmtRatings as $categoryName=>$arrCriteria){
										$displayCatName	= 1;
										
										foreach($arrCriteria as $criteriaName=>$arrRatings){
											if($displayCatName){
												if($altBgColorFlag){
													$alternateBgColor	= ' class="evenRow"';
													$altBgColorFlag		= 0;
												}else{
													$alternateBgColor	= ' class="oddRow"';
													$altBgColorFlag		= 1;
												}
											}
											
								?>
												<tr<?php echo $alternateBgColor;?>>
													<td><?php if($displayCatName){
																	echo "<strong>".$categoryName."</strong>";
																	$displayCatName	= 0;
																}
														?></td>
													<td style="border-bottom:1px solid #fff;">
														<?php echo $criteriaName;?>
													</td>
													<td style="border-bottom:1px solid #fff;">
														<select name="<?php echo $arrRatings[0]['category_id'].'_'.$arrRatings[0]['criteria_id'];?>">
															<option value="">Select Rating</option>
														
														<?php 
															foreach($arrRatings as $key=>$row){
																$selectedValue	= '';
																if(isset($arrCriteriaRating[$row['criteria_id']]) && $arrCriteriaRating[$row['criteria_id']]==$row['rating_id']){
																	$selectedValue	= ' selected="selected"';
																}
																echo '<option value="'.$row['rating_id'].'"'.$selectedValue.'>'.$row['rating'].'</option>';
															}
														?>
														</select>
													</td>
												</tr>
								<?php 		
											}
										}
								?>
									<tr>
										<td colspan="3" style="text-align:center;">
											<input class="blueButton" type="button" value="Save" onclick="validateAsmtRating();" />
										</td>
									</tr>
									</form>
									</table>
								<?php 
								  }
								?>
							</div>
							<!-- End of Assessment Rating -->
		<?php 
						break;	
                                case 'details':
                        case 'edit':
                        case 'add':
                                	$this->load->view('kols/list_details',$data);
                        break;
                        case 'add_opt_in_form':
                            $this->load->view('kols/list_details_opt_in_out',$data);
                        break;
			?>
					<!-- Start of KOL details -->
							<!-- End of KOL details -->
		<?php 
				case 'survey_form':
		?>
		<?php 
				break;
				default:	
		?>
						<!-- Start of 'Biography' Information -->
							<div id="bioDetails" >
								<div id="addressBio">
									<!-- Start of Address Info -->
									<?php 
										if(!empty($arrKol['primary_phone']) && sizeof($arrKol['primary_phone'])>10){
											$arrKol['primary_phone']	= (($arrKol['primary_phone'][0]=="+")?'':'+').$arrKol['primary_phone'];
										}
										if(!empty($arrKol['fax']) && sizeof($arrKol['fax'])>10){
											$arrKol['fax']				= (($arrKol['fax'][0]=="+")?'':'+').$arrKol['fax'];
										}
										if($arrKol['salutation'] != 0)
											$salutation	= $arrSalutations[$arrKol['salutation']];
										else
											$salutation = "";
										
										$firstName	= $arrKol[FIRST_ORDER];
										$middleName	= $arrKol[SECOND_ORDER];
										$lastName	= $arrKol[THIRD_ORDER];
										
										$fullName	= $firstName;
										if(!empty($middleName))
											$fullName	.= ' '. $middleName;
										if(!empty($lastName))
											$fullName	.= ' '. $lastName;									
									?>
									
									<div id="addressInfo" class="span-6 last">
										<p class="kolName">
											<?php //echo $fullName;
									               echo $salutation.' '.$this->common_helpers->get_name_format($firstName,$middleName,$lastName);
											?><br />
										</p>
                                                                                
										<div class="speciality">(&nbsp;
											<?php 
												//echo $arrKol['suffix'];
												if($arrKol['suffix'] == '1')
													echo "Do";
												elseif($arrKol['suffix'] == '2')
													echo "IM";
												elseif($arrKol['suffix'] == '3')
													echo "PD";
												elseif($arrKol['suffix'] == '4')
													echo "MD";
												else
												    echo str_replace(",", ", ", $arrKol['suffix']);
												//$s = 'DVSc, Certified Nurse-Midwife, Master of Arts';
												//echo trim($s);
																?>
											&nbsp;)
										</div>
                                                                                <?php if($arrKol['do_not_call_flag'] == "1") { ?>
                                                                                <div><p style="color: red;font-size: 11px;margin: -4px 0px 0px 0px;">Do Not Call</p></div>
                                                                                <?php } ?>
										<table id="kolAdressInfo">
											<?php if($arrKol['specialty'] != ''){?>
											<tr>
												<th class="vAlignTop" style="width: 30px;"><div class="kolSpecialty sprite_iconSet"><a href="#" class="tooltipLink" rel='tooltip' title="Specialty" style="cursor: default;">&nbsp;</a></div></th>
												<th class="vAlignTop"><?php echo $arrSpecialties[$arrKol['specialty']];?><br/><span style="font-weight: normal;"><?php echo implode(", ",$arrSubSpecialties); ?></span></th>
											</tr>
											
											<?php }
												if($arrKol['title'] != ''){?>
													<tr>
														<th class="vAlignTop" style="width: 30px;"><div class="kolDesignation sprite_iconSet"><a href="#" class="tooltipLink" rel='tooltip' title="Position/Department" style="cursor: default;">&nbsp;</a></div></th>
														<th class="vAlignTop">
															<?php 
																//echo $arrKol['title'];
																if($arrKol['title'] == '1')
																	echo "Advocacy";
																elseif($arrKol['title'] == '2')
																	echo "C Suite CEO/CFO/COO";
																elseif($arrKol['title'] == '3')
																	echo "Case Manager";
																elseif($arrKol['title'] == '4')
																	echo "Chief Medical Officer/Clinical Affairs";
																elseif($arrKol['title'] == '5')
																	echo "Consultant";
																elseif($arrKol['title'] == '6')
																	echo "Dentist";
																else
																	echo $arrKol['title'];
																if($arrKol['division'] != '' && $arrKol['division'] != '0'){
																	echo '<br />'.$arrKol['division'];
																}
															?>
														</th>
													</tr>
											<?php }else if(!empty($arrKol['division']) && $arrKol['division'] != '0'){?>
											<tr>
														<th class="vAlignTop" style="width: 30px;"><div class="kolDesignation sprite_iconSet"><a href="#" class="tooltipLink" rel='tooltip' title="Position/Department" style="cursor: default;">&nbsp;</a></div></th>
														<th class="vAlignTop">
												<?php echo $arrKol['division'];?>
												</th>
													</tr>
												<?php 
											}
												if($arrKol['org_name'] != '' && $arrKol['org_id'] != ''){?>
													<tr>
														<th class="vAlignTop" style="width: 30px;"><div class="kolOrg sprite_iconSet"><a href="#" class="tooltipLink" rel='tooltip' title="Institution Name" style="cursor: default;">&nbsp;</a></div></th>
														<th class="vAlignTop">
														<?php if($this->organization->isOrgLinkAllowed($arrKol['org_id'])) { ?>
															<a href="<?php echo base_url() ?>organizations/view/<?php echo $arrKol['org_id']?>"><?php echo $arrKol['org_name'];?></a>
														<?php } else {?>
															<?php echo $arrKol['org_name'];?>
														<?php } ?>
														</th>
													</tr>
											<?php } else { ?>
                                                                                                        <tr>
														<th class="vAlignTop" style="width: 30px;"><div class="kolOrg sprite_iconSet"><a href="#" class="tooltipLink" rel='tooltip' title="Institution Name" style="cursor: default;">&nbsp;</a></div></th>
														<th class="vAlignTop"><?php echo $arrKol['private_practice'];?></th>
													</tr>
											<?php }
											?>
											
											<tr>
												<!--<td class="vAlignTop"><div class="kolLicense sprite_iconSet"></div></td>
												--><td colspan="2" class="vAlignTop">												
													<?php if($this->common_helpers->isActionAllowed('kol','edit',$arrKol)){ ?>
														<div class="tooltip-demo tooltop-bottom" style="float: right;">
															<a id="editKTL" style="text-decoration: none;" rel="tooltip" href="<?php echo base_url();?>kols/view/<?php echo $arrKol['unique_id'];?>/edit" class="blueButton" data-original-title="Edit Contact">Edit Contact</a>
														</div>
													<?php }
													/*if(!empty($arrKol['license'])) {?>
														<p class="addrHeading"><?php echo lang('Overview.License');?>#</p>
														<p><?php echo $arrKol['license'];?></p>
													<?php } */?>
												</td>
											</tr>
											<?php /*if(!empty($arrKol['npi_num'])) {?>
											<tr>
												<!--<td class="vAlignTop"><div class="kolLicense sprite_iconSet"></div></td>
												--><td colspan="2" class="vAlignTop">
													<p class="addrHeading"><?php echo lang("Mykols.NPINUMBER");?></p>
													<p><?php echo $arrKol['npi_num'];?></p>
												</td>
											</tr>
											<?php } */?>
											<?php if(CRM_LABEL){?>
												<?php if(!empty($arrKol['external_profile_id'])) {?>
												<tr>
													<!-- <td class="vAlignTop"><div class="faxNumber sprite_iconSet"></div></td> -->
													<td colspan="2" class="vAlignTop">
														<p class="addrHeading">CRM #</p>
														<p><?php echo $arrKol['external_profile_id'];?></p>
													</td>
												</tr>
												<?php } ?>
											<?php } ?>
											<tr>
												<!--<td class="vAlignTop"><div class="streetAddress sprite_iconSet"></div></td>
												--><td colspan="2" class="vAlignTop">
													<p class="addrHeading"><?php echo lang('Overview.Address');?></p>
													<?php
														if(!empty($arrKol['address1']) && isset($arrKol['address1'])) 
															echo "<p>".$arrKol['address1'].",</p>";
														if(!empty($arrKol['address2']) && isset($arrKol['address2']))
															echo "<p>".$arrKol['address2'].",</p>";
													 
													?>
													<p><?php
														if(isset($arrKol['city_name']))
															echo $arrKol['city_name'].', ';
															
																if($arrKol['country_name']=='Canada' || $arrKol['country_name']=='United States')
																	echo $stateCode[0]['state_code']. " ". $arrKol['postal_code'];
																else if($arrKol['state_name']!='' && $arrKol['postal_code']!='')
																	echo $arrKol['state_name']. " ". $arrKol['postal_code'];
																else
																	echo $arrKol['state_name'];
													?></p>
													<?php 
													if(isset($arrKol['country_name']))
														echo "<p>".$arrKol['country_name']."</p>";
											
													?>
												</td>
											</tr>
											<?php if(!empty($arrKol['primary_email'])) {?>
											<tr>
												<!--<td class="vAlignTop"><div class="emailId sprite_iconSet"></div></td>
												--><td colspan="2" class="vAlignTop">
													<p class="addrHeading"><?php echo lang('Overview.Email');?></p>
													<p><a id="emailIdLink" href="mailto:<?php echo $arrKol['primary_email'];?>"><?php echo $arrKol['primary_email'];?></a></p>
												</td>
											</tr>
											<?php }?>
											<?php if(!empty($arrKol['primary_phone'])) {?>
											<tr>
												<!--<td class="vAlignTop"><div class="contactNumber sprite_iconSet"></div></td>
												--><td colspan="2" class="vAlignTop">
													<p class="addrHeading"><?php echo lang('Overview.Phone');?></p>
													<p><?php echo '<a class="linkClickToCall" href="callto:'.$arrKol['primary_phone'].'" >'.$arrKol['primary_phone'].'</a>';?></p>
												</td>
											</tr>
											<?php } ?>
											<?php if(!empty($arrKol['fax'])) {?>
											<tr>
												<!-- <td class="vAlignTop"><div class="faxNumber sprite_iconSet"></div></td> -->
												<td colspan="2" class="vAlignTop">
													<p class="addrHeading"><?php echo lang('Overview.Fax');?></p>
													<p><?php echo '<a class="linkClickToCall" href="callto:'.$arrKol['fax'].'" >'.$arrKol['fax'].'</a>';?></p>
												</td>
											</tr>
											<?php } ?>
											
											<?php /*if(!$isCustomerProfile){?>
											<tr>
												<!--<td class="vAlignTop"><div class="kolActivity sprite_iconSet"></div></td>
												--><td colspan="2" class="vAlignTop">
													<p class="addrHeading"><?php echo lang('Overview.Activities');?></p>
													<table id="activityInfo">
														<tr>
															<td class="alignRight"><lable><?php echo lang('Overview.Affiliations');?></lable></td><td><lable>: <?php echo $noOfAffilitions;?></lable></td>
															<td class="alignRight"><lable><?php echo lang('Overview.Events');?></lable></td><td><lable>: <?php echo $noOfEvents;?></lable></td>
														</tr>
														<tr>
															<td class="alignRight"><lable><?php echo lang('Overview.Publications');?></lable></td><td><lable>: <?php echo $noOfPublications;?></lable></td>
															<td class="alignRight"><lable><?php echo lang('Overview.Trials');?></lable></td><td><lable>: <?php echo $noOfTrials;?></lable></td>
														</tr>
													</table>
												</td>
											</tr>
											<?php }*/?>
										</table>
									</div>
									<!-- End of Address Info -->
									<div id="bio_research" class="span-13 last">
											<div id="bio_border">
													<h1><?php echo lang('Overview.Biography');?></h1>
													<p>
														
												<?php  
												
												   // echo nl2br($arrKol['biography']);
												$this->load->view('kols/automated_biography',$data);
												/*
												?>
												<?php if($arrKol['research_interests'] != ''){?>	
											
												<p><label>Top Event Topics: </label>
												<?php if(count($biographyTextDetails['topEventsTopic']) > 0){ 
													$arrTopEvents = array_slice($biographyTextDetails['topEventsTopic'], 0, 3);
													foreach ($arrTopEvents as $event)
														$arrTopThreeEvents[] = '<a onclick="listKOLEvents(\'' .$event["name"].'\')" >' . $event["name"] . '</a>';
													echo implode($arrTopThreeEvents	," | ");
												}?>
												</br>
												<label>Top Publication Topics: </label>
												<?php if(count($biographyTextDetails['topPubMeshTerms']['categoryData']) > 0){
													$topPubMeshTerms = array_slice($biographyTextDetails['topPubMeshTerms']['categoryData'], 0, 3);
													foreach ($topPubMeshTerms as $pubTerms)
														$arrTopThreePubTerms[] =  '<a onclick="listKOLEvents(\'' .$event["name"].'\')" >' . $pubTerms["name"] . '</a>';
													echo implode($arrTopThreePubTerms," | ");
												}?>
												</p>
												<!--  <p><?php echo nl2br($arrKol['research_interests']);?></p> -->									
											
										<?php }
										*/
										?>
												</p>
											</div>
											
										
									</div>
									
									<div class="clear">&nbsp;</div>
								</div>
								
								<!--List Education details-->
								<!--  
								<div class="gridWrapper">
								<?php 
									if($arrEducationResults['noOfRecords'] > 0): ?>
										<table class="eduList">
											<caption>Education</caption>
											<tr>
												<th width="50%">Institution Name</th>
												<th width="20%">Degree</th>
												<th width="20%">Speciality</th>
												<th width="10%">TimeFrame</th>
											</tr>
											<?php
												$i = 0;
												$className	= 'even';
												foreach($arrEducationResults['rows'] as $row){
													if(($i%2) == 0) $className = 'even';
													else $className	 = 'odd';
													
													$i++;
													
													echo '<tr class="'.$className.'">'; 
														echo '<td>'.$row['institute_id'].'</td>';
														echo '<td>'.$row['degree'].'</td>';
														echo '<td>'.$row['specialty'].'</td>';
														
														$timeframe	= "";
														if($row['start_date'] != ''){
															$timeframe .= $row['start_date'];
														}
														if(($row['start_date'] != '') && ($row['end_date'] != '')){
															$timeframe .= ' - ';
														}
														
														if($row['start_date'] != ''){
															$timeframe .= $row['end_date'];
														}
														
														echo '<td>'.$timeframe.'</td>';
													echo '</tr>';
												}
											?>
										</table>
									<?php 
									endif;
								?>
								
								</div>
								-->							
								<div id="additional_contacts ">
									<div class="spaceBtwList">&nbsp;</div>
									
								<div id="user-notes" class="bio_border">
									<h4>User Notes</h4>								
									<div id="notes-container">
										<ul>
											<?php foreach($arrNotes as $note){?>
											<input type="hidden" name="orginal_doc_name" id="orginal_file_<?php echo $note['id'];?>" value="<?php echo $note['orginal_doc_name'] ?>" data-docname="<?php echo $note['document_name']?>"/>
											<li id="<?php echo $note['id'];?>">
												<div id="container-<?php echo $note['id'];?>">
													<?php if(strlen($note['note']) >= 400){?>
														<span class="<?php echo $note['id'];?> halftext"><?php echo substr($note['note'],0,400)."...";?></span>
														<span class="<?php echo $note['id'];?> fulltext a"><?php echo $note['note'];?></span>
													<?php }else{?>
														<span class="<?php echo $note['id'];?>"><?php echo $note['note'];?></span>
													<?php }?>
													<?php if($this->common_helpers->isActionAllowed("user_notes","edit",array("created_by"=>$note['created_by']))){?>
													<div class="notes-actions">
														<?php if($note['orginal_doc_name']!=''){ ?>
															<div class="actionIcon downloadIcon tooltip-demo tooltop-left"><a href="<?php echo base_url(); ?>kols/note_document_download/<?php echo $note['id'];?>" class="tooltipLink" rel="tooltip"></a>Download file</div>
														<?php } ?>
														<div class="actionIcon editIcon tooltip-demo tooltop-left" onclick="editNote(<?php echo $note['id'];?>); return false;"><a data-original-title="Edit" href="#" class="tooltipLink" rel="tooltip"></a></div>&nbsp;&nbsp;
														<div class="actionIcon deleteIcon tooltip-demo tooltop-left" onclick="deleteNote(<?php echo $note['id'];?>); return false;"><a href="#" class="tooltipLink" rel="tooltip" title="Delete"></a></div>
													</div>
													<?php }?>
												</div>
												<?php if($note['orginal_doc_name']!=''){ ?>
													<div class="notes-details">Uploaded document: <gg id="uploadedFile_<?php echo $note['id']; ?>"><?php echo $note['document_name']?></gg></div>
												<?php } ?>
												<?php if($note['modified_by'] > 0 && $note['modified_by'] != ''){?>
													<div class="notes-details">Modified by: <?php if($note['modif_id']!=INTERNAL_CLIENT_ID) echo $note['modified_by_first_name']." ".$note['modified_by_last_name']; else echo 'Aissel Analyst';?>, <?php echo date('d M Y, h:i A', strtotime($note['modified_on']));?></div>
												<?php }else{ 
												    if(KOL_CONSENT){?>	
													<div class="notes-details">Posted by: <?php if($note['is_from_opt_in'] == 0) { if($note['post_id']!=INTERNAL_CLIENT_ID) echo $note['first_name']." ".$note['last_name']; else echo 'Aissel Analyst';}else{ echo $arrKol['first_name']." ".$arrKol['last_name'];}?>, <?php echo date('d M Y, h:i A', strtotime($note['created_on'])); if($note['is_from_opt_in'] == 0) echo '';else echo 'via Opt-in';?></div>
												<?php }else {?>
													<div class="notes-details">Posted by: <?php if($note['post_id']!=INTERNAL_CLIENT_ID) echo $note['first_name']." ".$note['last_name']; else echo 'Aissel Analyst';?>, <?php echo date('d M Y, h:i A', strtotime($note['created_on']));?></div>
												<?php } }?>
											</li>
											<?php }?>
										</ul>
									</div>
									<form id="saveNote" method="post" action="#" >
    									<!-- a class="actionIcon addIcon" id="add-notes" href="#" onclick="$('#add-notes-area').fadeToggle('slow');return false;"><span></span>Add Note</a  -->
    									<div id="add-notes-area" >
    										<h5 style="margin-bottom: 0">Add Note</h5>
    										<textarea onKeyDown="limitText(this,'notesCountDown',200);" onKeyUp="limitText(this,'notesCountDown',200);" rows="3" cols="700" id="user-note" name="user_note" placeholder="Enter notes..."></textarea>
    										<div>You have <span id="notesCountDown">200</span> characters left. <font size="1">(Maximum characters: 200)</font></div>
    										<br>
    										<div class="subnotes" style="display: none;">
    											<label style="margin-left: 0 !important">Attach File: </label><input type="text" name="fileName" id="file_name" value="" placeholder="Enter file name"/>
                            					<!-- label for="contractRate" style="margin-left: 0 !important">Upload Doc:</label -->
                            					<input type="file" name="note_file" id="noteFile" value=""></input>
        										<button type="submit" id="saveBtn">Save</button>        										
    										</div>
    									</div>
    								</form>
    								<!--  List Interaction details -->
									<div class="clear" style="margin-bottom: 10px;">
										<div class="gridWrapper" id="allInteractionGridContainer">
											<table id="JQBlistAllInteractionResultSet"></table>
											<div id="listAllInteractionPager"></div>
										</div>		
									<!-- End of Table to listOthers -->
									</div>
									<?php $data['kol_id']=$arrKol['id'];?>
								<?php if($add_education && $this->common_helpers->isActionAllowed('kol_details', 'add', $data)){?>
    								<div class="addLink">									
    									<label class="link NewAddIcon" onclick="addClientEducation();" style="width: 80px;float: right;"><div class="actionIcon addIcon"></div>Add Data</label>									
    								</div>
								<?php } ?>
									<!-- Start of JQGrid based Table to list Additional Contacts  Results -->
									<div class="gridWrapper">
										<div id="listContacts "></div>
										<table id="JQBlistContactsResultSet"></table>
									</div>
								</div>
								
								<!--End of Additional Contacts details
								<div class="spaceBtwList">&nbsp;</div>	-->		
								<div id="allEduDetials">
									<!-- Start of JQGrid based Table to list Education Results -->
									<div class="gridWrapper">
										<div id="listAllEduPage"></div>
										<table id="JQBlistAllEduResultSet"></table>
									</div>
								</div>
								<div class="gridWrapper" id="gridEduContainer">
                                	<div id="listEducationDetailsPage"></div>
                                	<table id="JQBlistEducationDetails"></table>
                                </div>
                                <div class="spaceBtwList">&nbsp;</div>
                                <div class="gridWrapper" id="gridHonorsAwardsContainer">
                                	<div id="listHonorsAwardsDetailsPage"></div>
                                	<table id="JQBlistHonorsAwardsDetails"></table>
                                </div>
								<?php /*				
								<div id="education">
									<!-- Start of JQGrid based Table to list Education Results -->
									<div class="gridWrapper">
										<div id="listlistEducationPagea"></div>
										<table id="JQBlistEducationResultSet"></table>
									</div>
								</div>
								<!--End of Education details-->

								<div class="spaceBtwList">&nbsp;</div>

								<!--List Training details-->
								<div id="training">

									<!-- Start of JQGrid based Table to list Education Results -->
									<div class="gridWrapper">
										<table id="JQBlistTrainingResultSet"></table>
										<div id="listTrainingPagea"></div>
									</div>
								
								</div>
								<!--End of Training details-->	
								
								<div class="spaceBtwList">&nbsp;</div>
								
								<!-- List Board Certification details-->
								<div id="board">
									
									<!-- Start of JQGrid based Table to listBoard CertificationResults -->
									<div class="gridWrapper">
										<table id="JQBlistBoardResultSet"></table>
										<div id="listBoardPagea"></div>
									</div>

								</div>
								<!--End of Board Certification details-->	
								
								<div class="spaceBtwList">&nbsp;</div>

								<!--  List Honors and Awards details-->
								<div id="award">
									
									<!-- Start of JQGrid based Table to listBoard CertificationResults -->
									<div class="gridWrapper">
										<table id="JQBlistAwardResultSet"></table>
										<div id="listAwardPagea"></div>
									</div>
									
								</div>
								<!--End of Honors and Awards details-->	
                                                                
                                
								</div>
										
								<div class="clear">&nbsp;</div>
							*/	?>
							</div>
							<div class="spaceBtwList">&nbsp;</div>
								
								<!--  List Affiliation details -->
								<div class="clear">
									<div class="gridWrapper" id="allAfiliationGridContainer">
										<table id="JQBlistAllResultSet"></table>
										<div id="listAllPager"></div>
									</div>		
									<!-- End of Table to listOthers -->
								</div>
								<!--End of Honors and Awards details-->	
								<div class="spaceBtwList">&nbsp;</div>
								
								<!-- Add Conference Event Details -->
								<div id="conference">
									<div class="gridWrapper" id="confGridContainer">
										<table id="JQBlistConferenceResultSet"></table>
										<div id="listConferencePage"></div>
									</div>
								</div>
								<!-- End of Add Conference Event Details -->
								<div class="spaceBtwList">&nbsp;</div>
								
								<div id="publications">
									<div>
										<div class="gridWrapper" id="gridContainer1">
											<div id="serchPublicationPage"></div>
											<table id="JQBlistSearchResultSet"></table>
										</div>	
									</div>	
								</div>
								<div class="spaceBtwList">&nbsp;</div>
								
								<div id="trials" class="clear">
									<div class="gridWrapper clear" id="clinicalGridContainer">
									<?php if(HIDE_CLINICAL_TRIALS){?>
											<table id="JQBlistClinicalTrialsResultSet"></table>
											<div id="listlistClinicalTrialsPage"></div>
									<?php  }?>		
									</div>
								</div>
								<div class="spaceBtwList">&nbsp;</div>
							<!--  End of 'Biography' Information -->
							
							<!--  New Profile Request model box-->
							<div id="newKolProfile" class="microProfileDialogBox">
								<div class="newProfileContent profileContent"></div>
							</div>
		<?php 			
						break;	
			}
		?>
						
						
							
						</div>
						<!-- End of 'Horizontal Tabs' -->
						
					<!-- Container for the 'Client Education' modal box -->
					<div id="clientEduDailog">	
						<div id="clientEduAddContainer" class="microProfileDialogBox">
							<div class="profileContent" id="clientEduAddProfileContent"></div>
						</div>
					</div>
					<!--End of  Container for the 'Client Education' modal box -->
					
					<!-- Container for the 'Interaction Micro Profile' modal box -->
					<div id="dailog1">	
						<div id="interactionMicroProfile" class="microProfileDialogBox">
							<div class="profileContent"></div>
						</div>
					</div>
					<!--End of  Container for the 'Interaction Micro Profile' modal box -->
					<!-- Container for the 'Interaction Add' modal box -->
					<div id="dailog2">	
						<div id="interactionAddContainer" class="microProfileDialogBox">
							<div class="profileContent" id="interactinAddProfileContent"></div>
						</div>
					</div>
					<!--End of  Container for the 'Interaction Addd' modal box -->
					<!-- Container for the 'Interaction Micro Edit' modal box -->
					<div id="dailog3">	
						<div id="interactionEditContainer" class="microProfileDialogBox">
							<div class="profileContent" id="interactinEditProfileContent"></div>
						</div>
					</div>
					<!--End of  Container for the 'Interaction Edit' modal box -->
					
					<!-- Container for the 'Add Payments' modal box -->
					<div id="dailog4">	
						<div id="paymentAddContainer" class="microProfileDialogBox">
							<div class="profileContent" id="paymentAddProfileContent"></div>
						</div>
					</div>
					<!--End of  Container for the 'Add Payments' modal box -->
					<!-- Container for the 'Edit Payments' modal box -->
					<div id="dailog5">	
						<div id="paymentEditContainer" class="microProfileDialogBox">
							<div class="profileContent" id="paymentEditProfileContent"></div>
						</div>
					</div>
					<!--End of  Container for the 'Edit Payments' modal box -->
					
					<!-- Container for the View Payments' modal box -->
					<div id="dailog3">	
						<div id="paymentViewContainer" class="microProfileDialogBox">
							<div class="profileContent" id="paymentViewProfileContent"></div>
						</div>
					</div>
					
					<div>	
						<div id="addInfluencerForKols" class="microProfileDialogBox">
							<div class="profileContent" id="addInfluencerForKolsContent"></div>
						</div>
					</div>
                                        
                                        <div>	
						<div id="addLocationForKols" class="microProfileDialogBox">
							<div class="profileContent" id="addLocationForKolsContent"></div>
						</div>
					</div>
					<div>	
						<div id="addPhoneForKols" class="microProfileDialogBox">
							<div class="profileContent" id="addPhoneForKolsContent"></div>
						</div>
					</div>
					<div>	
						<div id="addStaffForKols" class="microProfileDialogBox">
							<div class="profileContent" id="addStaffForKolsContent"></div>
						</div>
					</div>
					<div>	
						<div id="addEmailForKols" class="microProfileDialogBox">
							<div class="profileContent" id="addEmailForKolsContent"></div>
						</div>
					</div>
					<div>	
						<div id="addAssignClientKols" class="microProfileDialogBox">
							<div class="profileContent" id="addAssignClientKolsContent"></div>
						</div>
					</div>
					<div>	
						<div id="addStateLicenseForKols" class="microProfileDialogBox">
							<div class="profileContent" id="addStateLicenseForKolsContent"></div>
						</div>
					</div>
					<!--End of  Container for the View  Payments' modal box -->
					<!-- Container for the 'Micro Profile'  box -->
					<div id="contentHolder" class="callOutTest microView" style="display: none;">
						<div>
							<a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeInteractionMicroProfile();" class="ui-icon ui-icon-closethick">close</span></a>
							<!--<img class="ui-icon ui-icon-closethick" alt="" src="" onclick="closeInteractionMicroProfile();" />
						--></div>
						<div class="profileContent"></div>
					</div>
					<div id="arraouHolder" class="callOutTest" style="display: none;"><div class="arrowMarkIcon"></div></div>
				
					<style>/*    Enable Verticle separator between content and side menu list  By Laxman   */
						#contentWrapper.span-23 {
							background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
						    background-position: 135px 50%;
						    background-repeat: repeat-y;
						}
						.ui-tabs-vertical .ui-tabs-nav {
					    	margin-left: 1px;
					    }
					   
					</style>
<div id="event"></div>