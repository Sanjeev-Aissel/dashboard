<?php
/**
 * This is HTML form for Adding or Editing the Interation details
 * 
 * @author Ramesh B
 * @Created on: 28-02-11
 * @since  1.5	
 */
?>
<script type="text/javascript">
<!--

//-->
	$(document).ready(function(){
		//Adds the another upload link below the current upload field //'not working here'
		$("#addMoreFile").click(function(){
			//jAlert('hi');
			var noOfFiles=0;
			noOfFiles=$("#noOfFiles").val();
			noOfFiles++;
			var newUpload="<p><label for=docName"+noOfFiles+">Doc Name:</label>	<input type=\"text\" name=\"doc_name"+noOfFiles+"\" id=\"docName"+noOfFiles+"\" /><label for=\"description"+noOfFiles+"\">Description:</label><input type=\"text\" name=\"description"+noOfFiles+"\" id=\"description"+noOfFiles+"\" /><label for=\"uploadFile"+noOfFiles+"\">Upload:</label><input type=\"file\" name=\"int_ref_file"+noOfFiles+"\" id=\"intRefFile"+noOfFiles+"\"></input></p>";
			$("#fileUploadContainer").append(newUpload);
			$("#noOfFiles").val(noOfFiles);
		});
	});

	//added this function in order to add another file upload field as the Jquerry 'click' function is not working here
	function addAnother(){
		//$("#date").val('temp val');
		var noOfFiles=document.getElementById("noOfFiles").value;
		noOfFiles++;
		/*
		var divContents=document.getElementById("fileUploadContainer").innerHTML;
		divContents=divContents+"<p><label for=docName"+noOfFiles+">Doc Name:</label>	<input type=\"text\" name=\"doc_name"+noOfFiles+"\" id=\"docName"+noOfFiles+"\" /><label for=\"description"+noOfFiles+"\">Description:</label><input type=\"text\" name=\"description"+noOfFiles+"\" id=\"description"+noOfFiles+"\" /><label for=\"uploadFile"+noOfFiles+"\">Upload:</label><input type=\"file\" name=\"int_ref_file"+noOfFiles+"\" id=\"intRefFile"+noOfFiles+"\"></input></p>";
		jAlert(divContents);
		document.getElementById("fileUploadContainer").innerHTML=divContents;
		document.getElementById("noOfFiles").value=noOfFiles;
		divContents=document.getElementById("fileUploadContainer").innerHTML;
		jAlert(divContents);
		*/
		//$("#interactionAddContainer").dialog("open");
		
		//jAlert('hi');
		/*
		var noOfFiles=0;
		noOfFiles=document.getElementById("noOfFiles").value;
		noOfFiles++;
		var myElement="<p><label for=docName"+noOfFiles+">Doc Name:</label>	<input type=\"text\" name=\"doc_name"+noOfFiles+"\" id=\"docName"+noOfFiles+"\" /><label for=\"description"+noOfFiles+"\">Description:</label><input type=\"text\" name=\"description"+noOfFiles+"\" id=\"description"+noOfFiles+"\" /><label for=\"uploadFile"+noOfFiles+"\">Upload:</label><input type=\"file\" name=\"int_ref_file"+noOfFiles+"\" id=\"intRefFile"+noOfFiles+"\"></input></p>";
		var myElement = document.createElement("<p><label for=docName"+noOfFiles+">Doc Name:</label>	<input type=\"text\" name=\"doc_name"+noOfFiles+"\" id=\"docName"+noOfFiles+"\" /><label for=\"description"+noOfFiles+"\">Description:</label><input type=\"text\" name=\"description"+noOfFiles+"\" id=\"description"+noOfFiles+"\" /><label for=\"uploadFile"+noOfFiles+"\">Upload:</label><input type=\"file\" name=\"int_ref_file"+noOfFiles+"\" id=\"intRefFile"+noOfFiles+"\"></input></p>");
		document.getElementById("fileUploadContainer").appendChild( myElement );
		document.getElementById("noOfFiles").value=noOfFiles;
		jAlert('end');
		*/

		var interactionId=document.getElementById("interactionId").value;
		if(interactionId=='')
			addInteractionReload(noOfFiles);
		else
			editInteractionReload(interactionId,noOfFiles);
	}
</script>
<div class="msgBoxContainer"><div class="eventMsgBox"></div></div>
<div>
	<form action="<?php echo base_url();?>interactions/save_interaction" id="interactionForm"  name="interactionForm" method="post" enctype="multipart/form-data" >
		<input type="hidden"  name="interaction_id" value="<?php if($interactionDetails!=null) echo $interactionDetails['id'];?>" id="interactionId">
		<table >
			<tr>
				<td>
					<p>
						<label for="kolName">KTL Name:</label>
						<select name="kol_id"  id="kolName">
							<?php foreach($arrKolDetails as $kolDetails){?>
								<option value="<?php echo $kolDetails['id'];?>" <?php if($interactionDetails!=null) if($kolDetails['id']==$interactionDetails['kol_id']) echo 'SELECTED';?>>
									<?php echo $kolDetails['last_name']." ".$kolDetails['middle_name']." ".$kolDetails['first_name'];?>
								</option>
							<?php }?>
						</select>
					</p>
				</td>
				<td>
					<p>
						<label for=date>Date:</label>
						<input type="text" name="date" value="<?php if($interactionDetails!=null) echo $interactionDetails['date'];?>" id="date"></input>
					</p>
				</td>
			</tr>
			<tr>
				<td>
					<p>
						<label for="time">Time:</label>
						<input type="text" name="time" value="<?php if($interactionDetails!=null) echo $interactionDetails['time'];?>" id="time"></input>
					</p>
				</td>
				<td>
					<p>
						<label for=mode>Mode:</label>
						<select name="mode"  id="mode">
							<?php foreach($arrModes as $mode){?>
								<option value="<?php echo $mode['id'];?>" <?php if($interactionDetails!=null) if($mode['id']==$interactionDetails['mode']) echo 'SELECTED';?>>
									<?php echo $mode['name'];?>
								</option>
							<?php }?>
						</select>
					</p>
				</td>
			</tr>
			<tr>
				<td>
					<p>
						<label for="intLocation">Location:</label>
						<input type="text" name="int_location" value="<?php if($interactionDetails!=null) echo $interactionDetails['location'];?>" id="intLocation"></input>
					</p>
				</td>
				<td>
					<p>
						<label for=topic>Topic:</label>
						<select name="topic"  id="topic">
							<?php foreach($arrTopics as $topic){?>
								<option value="<?php echo $topic['id'];?>" <?php if($interactionDetails!=null) if($topic['id']==$interactionDetails['topic']) echo 'SELECTED';?>>
									<?php echo $topic['name'];?>
								</option>
							<?php }?>
						</select>
					</p>
				</td>
			</tr>
			<tr>
				<td>
					<p>
						<label for="brand">Brand:</label>
						<select name="brand"  id="brand">
							<?php foreach($arrBrands as $brand){?>
								<option value="<?php echo $brand['id'];?>" <?php if($interactionDetails!=null) if($brand['id']==$interactionDetails['brand']) echo 'SELECTED';?>>
									<?php echo $brand['name'];?>
								</option>
							<?php }?>
						</select>
					</p>
				</td>
				<td>
					<p>
						<label for=role>Role:</label>
						<select name="role"  id="role">
							<?php foreach($arrRoles as $role){?>
								<option value="<?php echo $role['id'];?>" <?php if($interactionDetails!=null) if($role['id']==$interactionDetails['role']) echo 'SELECTED';?>>
									<?php echo $role['name'];?>
								</option>
							<?php }?>
						</select>
					</p>
				</td>
			</tr>
			<tr>
				<td>
					<p>
						<label for="followUpOn">Follow-Up On:</label>
						<input type="text" name="follow_up_on" value="<?php if($interactionDetails!=null) echo $interactionDetails['follow_up_on'];?>" id="followUpOn"></input>
					</p>
				</td>
				<td>
					<p>
						<label for=reminder>Reminder:</label>
						<input type="checkbox" name="reminder" value="1" id="reminder" <?php if($interactionDetails!=null && $interactionDetails['reminder']==1) echo "checked='checked'";?>></input>
					</p>
				</td>
			</tr>
			<tr>
				<td>
					<p>
						<label for="category">Category:</label>
						<select name="category"  id="category">
							<?php foreach($arrCategories as $category){?>
								<option value="<?php echo $category['id'];?>" <?php if($interactionDetails!=null) if($category['id']==$interactionDetails['category']) echo 'SELECTED';?>>
									<?php echo $category['name'];?>
								</option>
							<?php }?>
						</select>
					</p>
				</td>
				<td>
					<p>
						<label for=notes>Notes:</label>
						<input type="text" name="notes" value="<?php if($interactionDetails!=null) echo $interactionDetails['notes'];?>" id="notes"></input>
					</p>
				</td>
			</tr>
			<tr>
				<td>
					<p>
						<label for=therapeuticArea>Therapeutic Area:</label>
						<input type="text" name="therapeutic_area" value="<?php if($interactionDetails!=null) echo $interactionDetails['therapeutic_area'];?>" id="therapeuticArea"></input>
					</p>
				</td>
				</td>
			</tr>
		</table>
		<div id="fileUploadContainer">
			<input type="hidden" name="no_of_files" id="noOfFiles" value="<?php echo $noOfFiles;?>"/>
			<p> 
				<label for=docName1>Doc Name:</label>
				<input type="text" name="doc_name1" id="docName1" />
				<label for=description1>Description:</label>
				<input type="text" name="description1" id="description1" />
				<label for=uploadFile1>Upload:</label>
				<input type="file" name="int_ref_file1" id="intRefFile1" />
				<a href="#" id="addMoreFile" onclick="addAnother();"><img src="<?php echo base_url();?>images/bullet_add.png" alt="Add Anothr File" title="Add Anothr File"/></a>
			</p>
			<?php if($noOfFiles>1){?>
				<?php for($i=2;$i<=$noOfFiles;$i++){?>
					<p> 
						<label for=docName<?php echo $i;?>>Doc Name:</label>
						<input type="text" name="doc_name<?php echo $i;?>" id="docName<?php echo $i;?>" />
						<label for=description<?php echo $i;?>>Description:</label>
						<input type="text" name="description<?php echo $i;?>" id="description<?php echo $i;?>" />
						<label for=uploadFile<?php echo $i;?>>Upload:</label>
						<input type="file" name="int_ref_file<?php echo $i;?>" id="intRefFile<?php echo $i;?>" />
					</p>
				<?php }?>
			<?php }?>
		</div>
		<p>
			<input type="submit" name="saveInteraction" id="saveInteraction" value="save"/>
		</p>
	</form>
</div>