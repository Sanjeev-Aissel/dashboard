<?php
/**
*Controller for pubmed operations
*@author Ramesh B
*@since
*@package application.controllers	
*@created on 06-01-2011
*/

class Pubmeds extends Controller{

	var $maxScriptTime		= 86400;
	var $logFileName		= '';
	var $startTime			= '';
	var $logFile			= '';
	var $logText			= '';
	var $pmidBatchSize		= 10;
	var $sleepTime			= 2;
	var $safeTime			= 10;
	var $logLastPmidFile 	= '';
	
	var $logFileNamePmidSkipped		= '';
	var $logFilePmidSkipped			= '';
	var $observerEmailId	= ANALYST_EMAIL_ID;
	
	//Constructore
	function Pubmeds(){
		parent::Controller();
		$this->load->model('kol');
		$this->load->model('pubmed');
		$this->load->library("Ajax_pagination");
		$this->load->model('common_helpers');
		$this->logFilePath	= $this->config->item('app_folder_path').'system/logs/pubmed';
		//$this->load->libraries('');	
		//$this->_is_logged_in();	

		$observerEmail =  $this->input->post("observer_email");
		if($observerEmail != null && $observerEmail != '')
			$this->observerEmailId = $observerEmail;
		if($this->session->userdata('logged_in') == 1)
			$this->observerEmailId = $this->session->userdata('email');
	}
	
	
	/**
	 * Parse Publication details
	 * @ACL1-Alias Process
	 * @ACL1-Discription Parse Publication details
	 * @ACL1-Category Publications
	 * @ACL1-SubApp analyst
	 */
	function process_pubmeds($indvisKolId = null){
		//Analyst App to be accessed by only Aissel users. 
		//$this->common_helpers->checkUsers();
		$this->logFilePath=	$_SERVER['DOCUMENT_ROOT'].'/'.$this->logFilePath;	
		// Open the LogFile to write		
		$this->startTime	= microtime(true);
		$this->logFileName	=$this->logFilePath . "/" . "logfile_".date("d-m-Y")."_". $this->startTime . ".txt";
		$this->logFile	= fopen($this->logFileName, "w");
		$this->logText	= "Processing Started on: " . date("d-m-Y H:i:s") . "\r\n";
		//Log Activity
		$arrLogDetails = array(
				'type'=>CRON_JOBS,
				'description'=>$this->logText,
				'status' => STATUS_SUCCESS,
				'transaction_table_id'=>'',
				'transaction_name'=>'Crawling Started'
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null, true);
		fwrite($this->logFile, $this->logText);
		
		$this->logFileNamePmidSkipped	=$this->logFilePath . "/skipped/" . "pmids_skipped_orgs_".date("d-m-Y").".txt";
		$this->logFilePmidSkipped	= fopen($this->logFileNamePmidSkipped, "w");
		fwrite($this->logFilePmidSkipped, $this->logText);
		
		ini_set("max_execution_time",$this->maxScriptTime);
		//$this->maxScriptTime = ini_get("max_execution_time");

		//Process the last crawled PMID
		$lastPmid = file_get_contents($this->logFilePath . "/last_pmid.txt");
		if(isset($lastPmid) && $lastPmid != '') {
			echo "Processing last PMID : ".$lastPmid."<br>";
			flush(); 
			$this->logText	= "Processing last PMID : ".$lastPmid."\r\n";
			//Log Activity
			$arrLogDetails = array(
					'type'=>CRON_JOBS,
					'description'=>$this->logText,
					'status' => STATUS_SUCCESS,
					'transaction_table_id'=>'',
					'transaction_id' => $lastPmid,
					'transaction_name'=>'Processing last PMID'
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null, true);
			fwrite($this->logFile, $this->logText);
			$this->recrawl_pmid($lastPmid);
		}
		//$this->logLastPmidFile = fopen($this->logFilePath . "/last_pmid.txt", "w");
		
		$this->logText	= "Processing KOLs with status Recrawl..  \r\n";
		fwrite($this->logFile, $this->logText);
		$this->processPubmedRecrawlKols();
		$this->logText	= "Recrawl Status KOLs processing completed..  \r\n";
		//Log Activity
		$arrLogDetails = array(
				'type'=>CRON_JOBS,
				'description'=>$this->logText,
				'status' => STATUS_SUCCESS,
				'transaction_table_id'=>'',
				'transaction_name'=>'Processing KOLs with status Recrawl'
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null, true);
		fwrite($this->logFile, $this->logText);
		
		//get the PubmedUnprocessed kol's
		if($indvisKolId != null)
			$arrKolDetails[] = $this->kol->editKol($indvisKolId);
		else
			$arrKolDetails=$this->pubmed->getPubmedUnprocessedKols();
		if(sizeof($arrKolDetails)<1){
			$this->logText	= "There are No Unprocessed KOL ids, Terminating Process..  \r\n";
			//Log Activity
			$arrLogDetails = array(
					'type'=>CRON_JOBS,
					'description'=>$this->logText,
					'status' => STATUS_SUCCESS,
					'transaction_table_id'=>'',
					'transaction_name'=>'Get the PubmedUnprocessed KOL'
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null, true);
			fwrite($this->logFile, $this->logText);
			$this->send_status_mail($this->logText);
			die("Sorry! There are No Unprocessed KOL ids, Terminating Process..");
		}
		$this->logText	= "Following are the Unprocessed KOL ids  \r\n";
		fwrite($this->logFile, $this->logText);
		foreach($arrKolDetails as $arrKolDetail){
			$this->logText	= $arrKolDetail['id']."  \r\n";
			//Log Activity
			$arrLogDetails = array(
					'type'=>CRON_JOBS,
					'description'=>$this->logText,
					'status' => STATUS_SUCCESS,
					'transaction_table_id'=>'',
					'transaction_name'=>'Following are the Unprocessed KOL ids'
			);
			$this->config->set_item('log_details', $arrLogDetails);
			log_user_activity(null, true);
			fwrite($this->logFile, $this->logText);
		}		
		$firstName='';
		$midleName='';
		$lastName='';
		$this->logText	= "--------------------------------------------------------------------------------------------- \r\n";
		fwrite($this->logFile, $this->logText);	
		//Start of loop trought each kol, generate name combinations, gather PMID's, get publications, parse and save data			
		foreach($arrKolDetails as $arrKolDetail){
			$kolStartTime=microtime(true);			
			$this->logText	= "\r\nStarting pubmed processing for KolId ".$arrKolDetail['id']." \r\n";
			fwrite($this->logFile, $this->logText);		
			
			// get the name details			
			$firstName=$arrKolDetail['first_name'];
			$midleName=$arrKolDetail['middle_name'];
			$lastName=$arrKolDetail['last_name'];
			$kolId=$arrKolDetail['id'];
			
			//get the different combinations of names
			if($indvisKolId != null)
				$arrNameCombinations = $this->pubmed->getKolNameCombinations($kolId);
			else
				$arrNameCombinations=$this->pubmed->generate_name_combinations($firstName, $midleName, $lastName);
			
			
			
			$this->logText	= "Kol Name: ".$firstName." ".$midleName." ".$lastName."  \r\n";
			fwrite($this->logFile, $this->logText);
			$this->logText	= "Following are the Name combinations genarated  \r\n";
			fwrite($this->logFile, $this->logText);
			foreach($arrNameCombinations as $nameCombination){
				$this->logText	= $nameCombination."  \r\n";
				fwrite($this->logFile, $this->logText);
			}		
			
			//Get the list of PubMed ID's for each possible Author name and store it in a array
			$this->logText	= "\r\nStarting getting pmid's  \r\n";
			fwrite($this->logFile, $this->logText);
			$arrPMIDs=array();
			$count=0;	
			$gathPMIDTime=microtime(true);		
			foreach($arrNameCombinations as $authName){	
				//Notes about url
				//Whenewer you encounter a space in url, repalce space with special charecter '%20', otherwise you may get wrong results			
				$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retstart=0&retmax=1000&usehistory=y&retmode=xml&term=".str_replace(" ", "%20", $authName)."[author";
				
				$response = $this ->retrieve_page_get($url);
				//Try once again if the response of the status is false	
				if($response['status'] == false){
					//give 2 second delay
					sleep($this->sleepTime);
					$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
					//Log Activity
					$arrLogDetails = array(
							'type'=>CRON_JOBS,
							'description'=>$this->logText,
							'status' => STATUS_FAIL,
							'transaction_table_id'=>'',
							'transaction_name'=>'Pubmed Processing',
							'miscellaneous1'=>$url
					);
					$this->config->set_item('log_details', $arrLogDetails);
					log_user_activity(null, true);
					fwrite($this->logFile, $this->logText);
					//try once again
					$response = $this ->retrieve_page_get($url);
				}
				// Skipp this and log the details if still respons is false
				if($response['status'] == false){
					//log the details
					$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next name, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
					//Log Activity
					$arrLogDetails = array(
							'type'=>CRON_JOBS,
							'description'=>$this->logText,
							'status' => STATUS_FAIL,
							'transaction_table_id'=>'',
							'transaction_name'=>'Pubmed Processing',
							'miscellaneous1'=>$url
					);
					$this->config->set_item('log_details', $arrLogDetails);
					log_user_activity(null, true);
					fwrite($this->logFile, $this->logText);
					
					$this->logText = "Name Combination Crawl : KolId Id - ".$kolId."  : Name : ".$authName."\r\n";
					fwrite($this->logFilePmidSkipped, $this->logText);
					//continue to next step
					continue;
				}
			
				$this->logText	= "Url Created ".$url."\r\n";
				fwrite($this->logFile, $this->logText);
									
				$xml = new DOMDocument();
				
			if(!$xml->loadXML($response['response'])){
					$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
					//Log Activity
					$arrLogDetails = array(
							'type'=>CRON_JOBS,
							'description'=>$this->logText,
							'status' => STATUS_FAIL,
							'transaction_table_id'=>'',
							'transaction_name'=>'Pubmed Processing',
							'miscellaneous1'=>$url
					);
					$this->config->set_item('log_details', $arrLogDetails);
					log_user_activity(null, true);
					fwrite($this->logFile, $this->logText);	
					
					$response = $this ->retrieve_page_get($url);
					//Try once again if the response of the status is false	
					if($response['status'] == false){
						//give 2 second delay
						sleep($this->sleepTime);
						$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
						//Log Activity
						$arrLogDetails = array(
								'type'=>CRON_JOBS,
								'description'=>$this->logText,
								'status' => STATUS_FAIL,
								'transaction_table_id'=>'',
								'transaction_name'=>'Pubmed Processing',
								'miscellaneous1'=>$url
						);
						$this->config->set_item('log_details', $arrLogDetails);
						log_user_activity(null, true);
						fwrite($this->logFile, $this->logText);
						//try once again
						$response = $this ->retrieve_page_get($url);
					}
					// Skipp this and log the details if still respons is false
					if($response['status'] == false){
						//log the details
						$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next name, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						//Log Activity
						$arrLogDetails = array(
								'type'=>CRON_JOBS,
								'description'=>$this->logText,
								'status' => STATUS_FAIL,
								'transaction_table_id'=>'',
								'transaction_name'=>'Pubmed Processing',
								'miscellaneous1'=>$url
						);
						$this->config->set_item('log_details', $arrLogDetails);
						log_user_activity(null, true);
						fwrite($this->logFile, $this->logText);
						
						$this->logText = "Name Combination Crawl : KolId Id - ".$kolId."  : Name : ".$authName."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						//continue to next step
						continue;
					}
					
					if(!$xml->loadXML($response['response'])){
						//log the details and continue
						$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next name, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						//Log Activity
						$arrLogDetails = array(
								'type'=>CRON_JOBS,
								'description'=>$this->logText,
								'status' => STATUS_FAIL,
								'transaction_table_id'=>'',
								'transaction_name'=>'Pubmed Processing',
								'miscellaneous1'=>$url
						);
						$this->config->set_item('log_details', $arrLogDetails);
						log_user_activity(null, true);
						fwrite($this->logFile, $this->logText);	
						
						$this->logText = "Name Combination Crawl : KolId Id - ".$kolId."  : Name : ".$authName."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						continue;
						//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
					}										
				}
				
				$idListObj = $xml->getElementsByTagName('IdList')->item(0);
				$idList=$idListObj->getElementsByTagName('Id');
				foreach($idList as $idObj){
					$arrPMIDs[]=$idObj->nodeValue;
				}	
				$this->logText	= "No of PMID's found for name '".$authName."': ".(sizeof($arrPMIDs)-$count)."\r\n";
				fwrite($this->logFile, $this->logText);
				$count=sizeof($arrPMIDs);
				sleep($this->sleepTime);
			}
			$this->logText	= "Total No of PMIDs found: ".sizeof($arrPMIDs)." \r\n";
			fwrite($this->logFile, $this->logText);	
			$timeTaken=microtime(true)-$gathPMIDTime;
			$this->logText	= "Time taken to gather PMIDs: ".(microtime(true)-$gathPMIDTime)."\r\n";
			fwrite($this->logFile, $this->logText);
										
			$arrUniquePMIDs = array_unique($arrPMIDs);	
			$arrUniquePMIDs=array_values($arrUniquePMIDs);	
			$this->logText	= "\r\nTotal No of PMIDs found after removing duplicates: ".sizeof($arrUniquePMIDs)." \r\n";
			fwrite($this->logFile, $this->logText);					
			//End of getting the PubMed ID's
			// Reconnect the Database, to ensure that the DB connection is alive
	        // On Jan 26, 2012, we faced an issue where the Publications were not getting crawled
	        // MySQL idel timeout is 15-20 seconds
	        $this->db->close();
	        $this->db->initialize();
			//Check for already existing publication's and associate them with kol
			$arrFilteredPMIDs=$this->pubmed->checkAndAssociateAlreadyExistPubs($arrUniquePMIDs, $kolId,$arrKolDetail);
			$this->logText	= "Total No of PMIDs found after removing already existing publication's in database: ".sizeof($arrFilteredPMIDs)." \r\n";
			fwrite($this->logFile, $this->logText);							
			//End of checking and associating already existing publications
			
			
			//Get the Publication details for all the PubMEd ID's, 10 at a time	
			$this->logText	= "\r\nStart of getting the Publication details for each PMID, Processing ".$this->pmidBatchSize." at a time \r\n";
			fwrite($this->logFile, $this->logText);			
			for($i=0; $i<sizeof($arrFilteredPMIDs);$i=$i+10){
			//for($i=0; $i<20;$i=$i+$this->pmidBatchSize){
				$authListText='';
				$arrAuthList = array();
				for($j=$i; $j<$i+$this->pmidBatchSize; $j++){
					if( $arrFilteredPMIDs[$j]!='')
						$arrAuthList[] = $arrFilteredPMIDs[$j];
				}
				$authListText = implode(",",$arrAuthList);

				$pubFetchStartTime=microtime(true);				
				$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$authListText;
				$this->logText	= "Url generated: ".$url."\r\n";
				fwrite($this->logFile, $this->logText);	
				
				if($authListText!='')
					$response = $this ->retrieve_page_get($url);
				//Try once again if the response of the status is false	
				if($response['status'] == false){
					//give 2 second delay
					sleep($this->sleepTime);
					$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
					fwrite($this->logFile, $this->logText);
					//try once again
					$response = $this ->retrieve_page_get($url);
				}
				// Skipp this and log the details if still respons is false
				if($response['status'] == false){
					//log the details
					$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
					//Log Activity
					$arrLogDetails = array(
							'type'=>CRON_JOBS,
							'description'=>$this->logText,
							'status' => STATUS_FAIL,
							'transaction_table_id'=>'',
							'transaction_name'=>'Pubmed Processing',
							'miscellaneous1'=>$url
					);
					$this->config->set_item('log_details', $arrLogDetails);
					log_user_activity(null, true);
					fwrite($this->logFile, $this->logText);
					
					$this->logText = "Name Combination Crawl : KolId Id - ".$kolId."  : Pmids : ".$authListText."\r\n";
					fwrite($this->logFilePmidSkipped, $this->logText);
					//continue to next step
					continue;
				}
				
				$timeTaken=microtime(true)-$pubFetchStartTime;		
				$this->logText	= "Time taken to fetch ".$this->pmidBatchSize." publications : ".$timeTaken."\r\n";
				fwrite($this->logFile, $this->logText);	
				$xml = new DOMDocument();
				
				if(!$xml->loadXML($response['response'])){
					$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
					//Log Activity
					$arrLogDetails = array(
							'type'=>CRON_JOBS,
							'description'=>$this->logText,
							'status' => STATUS_FAIL,
							'transaction_table_id'=>'',
							'transaction_name'=>'Pubmed Processing',
							'miscellaneous1'=>$url
					);
					$this->config->set_item('log_details', $arrLogDetails);
					log_user_activity(null, true);
					fwrite($this->logFile, $this->logText);	
					
					$response = $this ->retrieve_page_get($url);
					//Try once again if the response of the status is false	
					if($response['status'] == false){
						//give 2 second delay
						sleep($this->sleepTime);
						$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
						//Log Activity
						$arrLogDetails = array(
								'type'=>CRON_JOBS,
								'description'=>$this->logText,
								'status' => STATUS_FAIL,
								'transaction_table_id'=>'',
								'transaction_name'=>'Pubmed Processing',
								'miscellaneous1'=>$url
						);
						$this->config->set_item('log_details', $arrLogDetails);
						log_user_activity(null, true);
						fwrite($this->logFile, $this->logText);
						//try once again
						$response = $this ->retrieve_page_get($url);
					}
					// Skipp this and log the details if still respons is false
					if($response['status'] == false){
						//log the details
						$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						//Log Activity
						$arrLogDetails = array(
								'type'=>CRON_JOBS,
								'description'=>$this->logText,
								'status' => STATUS_FAIL,
								'transaction_table_id'=>'',
								'transaction_name'=>'Pubmed Processing',
								'miscellaneous1'=>$url
						);
						$this->config->set_item('log_details', $arrLogDetails);
						log_user_activity(null, true);
						fwrite($this->logFile, $this->logText);
						
						$this->logText = "Name Combination Crawl : KolId Id - ".$kolId."  : Pmids : ".$authListText."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						//continue to next step
						continue;
					}
					
					if(!$xml->loadXML($response['response'])){
						//log the details and continue
						$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						//Log Activity
						$arrLogDetails = array(
								'type'=>CRON_JOBS,
								'description'=>$this->logText,
								'status' => STATUS_FAIL,
								'transaction_table_id'=>'',
								'transaction_name'=>'Pubmed Processing',
								'miscellaneous1'=>$url
						);
						$this->config->set_item('log_details', $arrLogDetails);
						log_user_activity(null, true);
						fwrite($this->logFile, $this->logText);	
						
						$this->logText = "Name Combination Crawl : KolId Id - ".$kolId."  : Pmids : ".$authListText."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						continue;
						//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
					}										
				}
				
				//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
				$this->logText	= "Following Publications with PMID's are parsed and saved sucessfully\r\n ";
				fwrite($this->logFile, $this->logText);
				$publications = $xml->getElementsByTagName('PubmedArticle');				
				foreach($publications as $publication){
					$timeElapsed = (microtime(true) - $this->startTime);
					$remTime	=$this->maxScriptTime-$timeElapsed;
					//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
					if($remTime<$this->safeTime){
						$this->logText	= "Stopping the pubmed processing, Timelimit reached.\r\n ";
						fwrite($this->logFile, $this->logText);	
						//die("Sorry! Stopping the pubmed processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);
						$this->send_status_mail($this->logText);
						redirect(base_url()."pubmeds_org/process_pubmeds");											
					}					
					$pubStartTime=microtime(true);	
					//parse and save publication details
					$pubDetails=$this->parse_pub_details($publication);	
					$pubId=$this->save_publications($pubDetails, $kolId);
					if($pubId!=null){
						//$this->logText	= "Publication with PMID:".$pubDetails['pmid']." parsed and saved sucessfully\r\n ";
						//fwrite($this->logFile, $this->logText);	
					}else{
						$this->logText	= "Error in parsing and saving the Publication with PMID:".$pubDetails['pmid']." \r\n ";
						//Log Activity
						$arrLogDetails = array(
								'type'=>CRON_JOBS,
								'description'=>$this->logText,
								'status' => STATUS_FAIL,
								'transaction_table_id'=>'',
								'transaction_name'=>'Pubmed Processing',
								'miscellaneous1'=>$url
						);
						$this->config->set_item('log_details', $arrLogDetails);
						log_user_activity(null, true);
						fwrite($this->logFile, $this->logText);
						continue;
					}
					//log the last PMID parsed
					file_put_contents($this->logFilePath . "/last_pmid.txt",$pubDetails['pmid']);
					
					//parse and save 'publication-authors'
					$arrAuthors=$this->parse_pub_authors($publication);
					$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
					
					//Calculate Authorship position and save
					$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail);
					$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
					
					//parse and save MeshTerms
					$arrMeshTerms=$this->parse_pub_meshterms($publication);
					$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
					
					//parse and save 'Substances(chemicals)'
					$arrSubstances=$this->parse_pub_substances($publication);
					$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
					
					//parse and save 'Publication types'
					$arrPubTypes=$this->parse_pub_types($publication);
					$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
					
					//parse and save 'CommentsCorrections(CC)'
					$arrCC=$this->parse_pub_CC($publication);
					$isSaved=$this->save_pub_CC($arrCC, $pubId);
					
					//parse and save 'Pubmed History'
					$arrHistory=$this->parse_pub_history($publication);
					$isSaved=$this->save_pub_history($arrHistory, $pubId);
					
					//parse and save 'Publication Article IDs'
					$arrPubArticleIds=$this->parse_pub_article_ids($publication);
					$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
					
					$timeTaken=microtime(true)-$pubStartTime;
					$this->logText	= " PMID: '".$pubDetails['pmid']."'		Time taken : ".$timeTaken."\r\n";
					fwrite($this->logFile, $this->logText);
				}
				sleep($this->sleepTime);
			}
			//End of loop trough ecah publication, parsjing and saving
			$this->logText	= "End of Procesing all the PMID's \r\n";
			fwrite($this->logFile, $this->logText);			
			echo "</br>Pubmed Processing of KolID :".$arrKolDetail['id']." is Completed sucessfully</br>";
			$arrKolDetail['is_pubmed_processed']=1;
			$this->pubmed->updatePubmedProcessedKol($arrKolDetail);	
			$this->logText	= "Pubmed Processing of KolId :".$arrKolDetail['id']." is Completed sucessfully \r\n";
			//Log Activity
			$arrLogDetails = array(
					'type'=>CRON_JOBS,
					'description'=>$this->logText,
					'status' => STATUS_SUCCESS,
					'transaction_table_id'=>'',
					'transaction_name'=>'Pubmed Processing',
					'miscellaneous1'=>$url
			);
			$this->config->set_item('log_details', $arrLogDetails);
			fwrite($this->logFile, $this->logText);
			$timeTaken=microtime(true)-$kolStartTime;	
			$this->logText	= "Total time taken: ".$timeTaken."\r\n";
			fwrite($this->logFile, $this->logText);
			
			$numRowsEffected = $this->pubmed->updateZeroAuthPosPubsAsDeleted($kolId);
			echo "Number of publications marked as deleted : ".$numRowsEffected."</br>";
			$this->logText	= "Number of publications marked as deleted : ".$numRowsEffected."\r\n";
			fwrite($this->logFile, $this->logText);
			$this->logText	= "--------------------------- \r\n";
			fwrite($this->logFile, $this->logText);	
			
			$this->send_status_mail("Pubmed Processing of KolID :".$arrKolDetail['id']." is Completed sucessfully");
		}
		
		$this->send_status_mail("Pubmed Processing Ended");
		// End of loop trought each kol	
	}	
	
	
	/**
	 * Parses the publication details from XML Object and returns publication details in an array
	 * @param $publication, XML Object
	 * @return Array
	 */	
	function parse_pub_details($publication){
		$pubDetails=array();
		
		$pmid='';
		$pmIdVersion='';
		$dateCreated=array();
		$dateCompleted=array();
		$dateRevised=array();
		$pubModel='NA';
		$issnNumber='NA';
		$issnType='NA';
		$citedMedium='NA';
		$volume='NA';
		$pubDate=array();
		$journalName='';
		$isoAbbreviation='NA';
		$articleTitle='NA';
		$abstractText='NA';
		$pagination='NA';
		$affiliation='NA';
		$authListComplete='';
		$language='NA';
		$articleDate=array();
		$citationSubset='NA';
		$numberOfReferences='NA';
		$otherID='';
		$status='NA';		
		$link='';
		$isDeleted=0;		
		
		$medlineCitation= $publication->getElementsByTagName('MedlineCitation')->item(0);
		$pubmedData= $publication->getElementsByTagName('PubmedData')->item(0);
	
		//$journalName=$medlineCitation->getElementsByTagName('Title')->item(0)->nodeValue;		
		//$articleName=$medlineCitation->getElementsByTagName('ArticleTitle')->item(0)->nodeValue;	
		$pmidObj=$medlineCitation->getElementsByTagName('PMID')->item(0);
		if($pmidObj!=null){
		$pmid=$pmidObj->nodeValue;
		if($pmidObj->hasAttributes()){			
			$pmIdVersion=$pmidObj->attributes->item(0)->value;
			}	
		}
		
		//get the date created
		
		/*$dateCreatedObj=$medlineCitation->getElementsByTagName('DateCreated')->item(0);	
		if($dateCreatedObj!=null){
			$dateCreated['day']=$dateCreatedObj->getElementsByTagName('Day')->item(0)->nodeValue;
			$dateCreated['month']=$dateCreatedObj->getElementsByTagName('Month')->item(0)->nodeValue;
			$dateCreated['year']=$dateCreatedObj->getElementsByTagName('Year')->item(0)->nodeValue;
		}*/
		$dateCreated = '';
		$dateCreatedObj = $this->parse_pub_history($publication);
		foreach($dateCreatedObj as $date_created){
		    if($date_created['status']=='pubmed'){
		        $dateCreated = $date_created['dateOnly'];
		    }
		}
		//get the date completed
		
		$dateCompletedObj=$medlineCitation->getElementsByTagName('DateCompleted')->item(0);	
		if($dateCompletedObj!=null){
			$dateCompleted['day']=$dateCompletedObj->getElementsByTagName('Day')->item(0)->nodeValue;
			$dateCompleted['month']=$dateCompletedObj->getElementsByTagName('Month')->item(0)->nodeValue;
			$dateCompleted['year']=$dateCompletedObj->getElementsByTagName('Year')->item(0)->nodeValue;
		}
		//get the date revised
		
		$dateRevisedObj=$medlineCitation->getElementsByTagName('DateRevised')->item(0);	
		if($dateRevisedObj!=null){
			$dateRevised['day']=$dateRevisedObj->getElementsByTagName('Day')->item(0)->nodeValue;
			$dateRevised['month']=$dateRevisedObj->getElementsByTagName('Month')->item(0)->nodeValue;
			$dateRevised['year']=$dateRevisedObj->getElementsByTagName('Year')->item(0)->nodeValue;
		}
		
		// Start Parsing article related data
		$articleObj=$medlineCitation->getElementsByTagName('Article')->item(0);
		if($articleObj!=null){
			if($articleObj->hasAttributes()){			
				$pubModel=$articleObj->attributes->item(0)->value;
				}
			$issnObj=$articleObj->getElementsByTagName('ISSN')->item(0);	
			if($issnObj!=null){	
			$issnNumber=$issnObj->nodeValue;
			if($issnObj->hasAttributes()){			
				$issnType=$issnObj->attributes->item(0)->value;
				}
			}
			$journalIssueObj=$articleObj->getElementsByTagName('JournalIssue')->item(0);
			if($journalIssueObj!=null){
				if($journalIssueObj->hasAttributes()){			
					$citedMedium=$journalIssueObj->attributes->item(0)->value;
					//echo " citedMedium:".$citedMedium;   		 
					}
				$volumeObj=$journalIssueObj->getElementsByTagName('Volume')->item(0);
				if($volumeObj!=null)
					$volume=$volumeObj->nodeValue;
				//get the PubDate
				
				$pubDateObj=$journalIssueObj->getElementsByTagName('PubDate')->item(0);
				if($pubDateObj!=null){
					$dayObj=$pubDateObj->getElementsByTagName('Day')->item(0);
					$pubDate['day']='';
					if($dayObj!=null)
						$pubDate['day']=$dayObj->nodeValue;
					$monthObj=$pubDateObj->getElementsByTagName('Month')->item(0);
					$pubDate['month']='';
					if($monthObj!=null)
						$pubDate['month']=$monthObj->nodeValue;
					$yearObj=$pubDateObj->getElementsByTagName('Year')->item(0);
					$pubDate['year']='';
					if($yearObj!=null)
						$pubDate['year']=$yearObj->nodeValue;
				}
			}			
			$journalNameObj=$articleObj->getElementsByTagName('Title')->item(0);
			if($journalNameObj!=null)
				$journalName=$journalNameObj->nodeValue;
			$isoAbbreviationObj=$articleObj->getElementsByTagName('ISOAbbreviation')->item(0);
			if($isoAbbreviationObj!=null)
				$isoAbbreviation=$isoAbbreviationObj->nodeValue;
			$articleTitleObj=$articleObj->getElementsByTagName('ArticleTitle')->item(0);
			if($articleTitleObj!=null)
				$articleTitle=$articleTitleObj->nodeValue;			
			//get the Abstract text
			$abstractTextObj=$articleObj->getElementsByTagName('AbstractText')->item(0);
			if($abstractTextObj!=null)
				$abstractText=$abstractTextObj->nodeValue;					
			$paginationObj=$articleObj->getElementsByTagName('MedlinePgn')->item(0);
			if($paginationObj!=null)
				$pagination=$paginationObj->nodeValue;					
			$affiliationObj=$articleObj->getElementsByTagName('Affiliation')->item(0);
			if($affiliationObj!=null)
				$affiliation=$affiliationObj->nodeValue;				
			$authorListObj=$articleObj->getElementsByTagName('AuthorList')->item(0);
			if($authorListObj1=null){
				if($authorListObj->hasAttributes()){			
					$authListComplete=$authorListObj->attributes->item(0)->value;
					//echo $authListComplete;   		 
				}
			}
			$languageObj=$articleObj->getElementsByTagName('Language')->item(0);
			if($languageObj!=null)
				$language=$languageObj->nodeValue;	

			$articleDateObj=$articleObj->getElementsByTagName('ArticleDate')->item(0);
			if($articleDateObj!=null){
					$dayObj=$articleDateObj->getElementsByTagName('Day')->item(0);
					$articleDate['day']='';
					if($dayObj!=null)
						$articleDate['day']=$dayObj->nodeValue;
					$monthObj=$articleDateObj->getElementsByTagName('Month')->item(0);
					$articleDate['month']='';
					if($monthObj!=null)
						$articleDate['month']=$monthObj->nodeValue;
					$yearObj=$articleDateObj->getElementsByTagName('Year')->item(0);
					$articleDate['year']='';
					if($yearObj!=null)
						$articleDate['year']=$yearObj->nodeValue;
			}
		}
		// End Parsing article related data
		$citationSubsetObj=$articleObj->getElementsByTagName('CitationSubset')->item(0);
			if($citationSubsetObj!=null)
				$citationSubset=$citationSubsetObj->nodeValue;
		$numberOfReferencesObj=$articleObj->getElementsByTagName('NumberOfReferences')->item(0);
			if($numberOfReferencesObj!=null)
				$numberOfReferences=$numberOfReferencesObj->nodeValue;	
		$otherIDObj=$articleObj->getElementsByTagName('OtherID')->item(0);
			if($otherIDObj!=null)
				$otherID=$otherIDObj->nodeValue;			
		$link="http://www.ncbi.nlm.nih.gov/pubmed/".$pmid;
		$statusObj=$articleObj->getElementsByTagName('PublicationStatus')->item(0);
			if($statusObj!=null)
				$status=$statusObj->nodeValue;		
		
		//Prepare array represinting Publication details	
		$pubDetails['pmid']=$pmid;
		//echo "</br>PMID: ".$pmid."</br>";
		$pubDetails['pmid_version']=$pmIdVersion;
        $pubDetails['created_date']=$dateCreated;//$this->array_to_date($dateCreated);
		$pubDetails['completed_date']=$this->array_to_date($dateCompleted);
		$pubDetails['revised_date']=$this->array_to_date($dateRevised);
		$pubDetails['pub_model']=$pubModel;
		$pubDetails['issn_number']=$issnNumber;
		$pubDetails['issn_type']=$issnType;
		$pubDetails['cited_medium']=$citedMedium;
		$pubDetails['volume']=$volume;
		//save the JournalName and get it's id
		//echo "</br>Journal Name: ".$journalName."</br>";
		$pubDetails['journal_id']=$this->pubmed->savejournalName($journalName);
		$pubDetails['iso_abbreviation']=$isoAbbreviation;
		$pubDetails['pub_date']=$this->array_to_date($pubDate);
		$pubDetails['article_title']=$articleTitle;
		$pubDetails['abstract_text']=$abstractText;
		$pubDetails['pagination']=$pagination;
		$pubDetails['affiliation']=$affiliation;
		$pubDetails['auth_list_complete']=$authListComplete;
		$pubDetails['language']=$language;
		$pubDetails['article_date']=$this->array_to_date($articleDate);
		$pubDetails['citation_subset']=$citationSubset;
		$pubDetails['Num_of_references']=$numberOfReferences;
		$pubDetails['other_id']=$otherID;
		$pubDetails['status']=$status;
		$pubDetails['link']=$link;		
		$pubDetails['is_deleted']=$isDeleted;	
		//End of preparing array 
		
		return $pubDetails;
	}
	
	/**
	 * Saves the Publication and returns the id of it
	 * @param Array $pubDetails
	 * @param Integer $kolId
	 * @return Integer $pubId
	 */
	function save_publications($pubDetails, $kolId, $isVerified = 0){					
		//save the publication and get the publication id
		$pubId=$this->pubmed->savePublication($pubDetails);
		//echo 'Publication with PMID:'.$pubDetails['pmid'].' Not exist and it is Saved and Associated to KolId :'.$kolId.'</br>';		
		//prepare the kol-to-publication association object
		$kolPublication=array();
		$kolPublication['kol_id']=$kolId;
		$kolPublication['pub_id']=$pubId;
		$kolPublication['is_deleted']=0;	
		$kolPublication['is_verified']= $isVerified;
										
		//save the kol-to-publication record
		$isSaved=$this->pubmed->saveKolPublication($kolPublication);
		$this->update->insertUpdateEntry(KOL_PROFILE_PUBLICATION_ADD, $pubId, MODULE_KOL_PUBLICATION, $kolId);
		//return the publication Id	
		return $pubId;
	}
	
	
	/**
	 * Parses the publication Authors details from XML Object and returns Authors details in an array
	 * @param XML Object $publication
	 * @param Integer $pubId
	 * @return Array
	 */
	function parse_pub_authors($publication){		
		$arrAuthors=array();	
		$medlineCitation= $publication->getElementsByTagName('MedlineCitation')->item(0);
		$authors=$medlineCitation->getElementsByTagName('Author');
		if($authors!=null){
			foreach($authors as $authorObj){
				if($authorObj!=null){
					$author=array();
					$lastName='Not Available';
					$foreName='Not Available';
					$initials='Not Available';
					$suffix='Not Available';
					$is_name_valid='';
					
					$lastNameObj=$authorObj->getElementsByTagName('LastName')->item(0);
					if($lastNameObj!=null)
						$lastName=$lastNameObj->nodeValue;
					$foreNameObj=$authorObj->getElementsByTagName('ForeName')->item(0);
					if($foreNameObj!=null)
						$foreName=$foreNameObj->nodeValue;
					$initialsObj=$authorObj->getElementsByTagName('Initials')->item(0);
					if($initialsObj!=null)
						$initials=$initialsObj->nodeValue;
					$suffixObj=$authorObj->getElementsByTagName('Suffix')->item(0);
					if($suffixObj!=null)
						$suffix=$suffixObj->nodeValue;
					if($authorObj->hasAttributes()){			
						$is_name_valid=$authorObj->attributes->item(0)->value;
					}
					$author['last_name']=$lastName;
					$author['fore_name']=$foreName;
					$author['initials']=$initials;
					$author['suffix']=$suffix;
					$author['is_name_valid']=$is_name_valid;
					$arrAuthors[]=$author;	
				}	
			}	
		}
		return $arrAuthors;
	}
	
	/**
	 * Saves the array of authers one by one
	 * @param Array $arrAuthors
	 * @param Integer $pubId
	 * @return boolean
	 */
	function save_pub_authors($arrAuthors, $pubId){
		$position=1;
		//Insert batch of authors,  i.e bulk insert
		//$this->db->insert_batch('pubmed_authors', $arrAuthors);
		$query= array(); 
	
		foreach( $arrAuthors as $row ) {
		    $query[] = '("'.$row['last_name'].'", "'.$row['fore_name'].'", "'.$row['initials'].'", "'.$row['suffix'].'", "'.$row['is_name_valid'].'")';
		}
		//pr($query);
		//pr(implode(',', $query));
		if(sizeof($query) == 0)
			return;
		if($this->db->query('INSERT INTO pubmed_authors (last_name, fore_name, initials, suffix, is_name_valid) VALUES '.implode(',', $query))){
			
			$result = $this->db->query("select max(id) as id from pubmed_authors");
			$result = $result->first_row();
			$authId=$result->id;
			$authId = $authId - (sizeof($arrAuthors)-1);
			$arrPubAuthors = array();
			foreach($arrAuthors as $author){
				$pubAuthor = array();			
				$pubAuthor['pub_id']=$pubId;
				$pubAuthor['author_id']=$authId;
				$pubAuthor['position']=$position;
				$pubAuthor['alias_id']=$authId;
				$position++;
				$authId++;
				$arrPubAuthors[] = $pubAuthor;
			}
	
			//Insert batch of  pub authors,  i.e bulk insert
			//$this->db->insert_batch('publications_authors', $arrPubAuthors);
			$query= array(); 
			foreach( $arrPubAuthors as $row ) {
			    $query[] = '('.$row['pub_id'].', '.$row['author_id'].', '.$row['position'].', '.$row['alias_id'].')';
			}
			//pr($query);exit;
			$this->db->query('INSERT INTO publications_authors (pub_id, author_id, position, alias_id) VALUES '.implode(',', $query));			
		}
		
	}
	
	/**
	 * Parses the publication MeshTerms  from XML Object and returns MeshTerms in an array
	 * @param XML Object $publication
	 * @return Array, 
	 */
	function parse_pub_meshterms($publication){
		$arrMeshTerms=array();	
		$medlineCitation=$publication->getElementsByTagName('MedlineCitation')->item(0); 
		$meshTerms=$medlineCitation->getElementsByTagName('MeshHeading'); 
		foreach($meshTerms as $meshTermObj){
			if($meshTermObj!=null){
				$meshTerm=array();
				$discriptNameObj=$meshTermObj->getElementsByTagName('DescriptorName')->item(0);
				if($discriptNameObj!=null){
					$discriptName=$discriptNameObj->nodeValue;
					if($discriptNameObj->hasAttributes()){			
						$isMajor=$discriptNameObj->attributes->item(1)->value;												   		 
					}
					$meshTerm['term_name']=$discriptName;
					$meshTerm['is_major']=$isMajor;
				}
				
				$arrQualifier=array();
				$qualifierNames=$meshTermObj->getElementsByTagName('QualifierName');				
				foreach($qualifierNames as $qualifierNameObj){
					$isMajor="";
					$arrQualifierNames[]=$qualifierNameObj->nodeValue;				
					if($qualifierNameObj!=null){
						$qualifier=array();					
						$qualifierName=$qualifierNameObj->nodeValue;
						if($qualifierNameObj->hasAttributes()){			
							$isMajor=$qualifierNameObj->attributes->item(1)->value;												   		 
						}
						$qualifier['term_name']=$qualifierName;
						$qualifier['is_major']=$isMajor;
						$arrQualifier[]=$qualifier;
					}														
				}	
				$meshTerm['arr_qualifier']=$arrQualifier;	
				$arrMeshTerms[]=$meshTerm;		
			}			
		}
		return $arrMeshTerms;
	}
	
	/**
	 * saves the array of MeshTerms one by one
	 * @param $arrMeshTerms
	 * @param $pubId
	 * @return boolean
	 */
	function save_pub_meshterms($arrMeshTerms, $pubId){
		$query= array();
		foreach($arrMeshTerms as $meshTerm){
			if($meshTerm!=null){
				$termId=0;
				$term=array();
				$term['term_name']=$meshTerm['term_name'];
				$term['parent_id']=$termId;
				// save parent MeshTerm into pubmed_meshTerm
				$termId=$this->pubmed->savePubmedMeshTerm($term);
				
				$pubTerm=array();
				$pubTerm['pub_id']=$pubId;
				$pubTerm['term_id']=$termId;
				$pubTerm['is_major']=($meshTerm['is_major']=='Y') ? 1:0 ;
				$query[] = '('.$pubTerm['pub_id'].', '.$pubTerm['term_id'].', '.$pubTerm['is_major'].')';
				
				$arrQualifier=array();
				$arrQualifier=$meshTerm['arr_qualifier'];
				$parentId=$termId;
				foreach($arrQualifier as $qualifier){										
					$term=array();
					$term['term_name']=$qualifier['term_name'];
					$term['parent_id']=$parentId;
					// save parent MeshTerm into pubmed_meshTerm
					$termId=$this->pubmed->savePubmedMeshTerm($term);
					
					$pubTerm=array();
					$pubTerm['pub_id']=$pubId;
					$pubTerm['term_id']=$termId;
					$pubTerm['is_major']=($qualifier['is_major']=='Y') ? 1:0 ;
					$query[] = '('.$pubTerm['pub_id'].', '.$pubTerm['term_id'].', '.$pubTerm['is_major'].')';					
				}				
			}		
		}
		
		if(sizeof($query) > 0)
			$this->db->query('INSERT INTO publication_mesh_terms (pub_id, term_id, is_major) VALUES '.implode(',', $query));
		
		
	}
	
	/**
	 * Parses the publication Substance details from XML Object and returns Substances in an array
	 * @param XML Object $publication
	 * @return Array
	 */
	function parse_pub_substances($publication){
		$medlineCitation=$publication->getElementsByTagName('MedlineCitation')->item(0);
		$arrSubstances=array();	
		$substances=$medlineCitation->getElementsByTagName('Chemical'); 
		if($substances!=null){
			foreach($substances as $substanceObj){
				if($substanceObj!=null){
					$substance=array();
					$regNumObj=$substanceObj->getElementsByTagName('RegistryNumber')->item(0);
					if($regNumObj!=null)
						$regNum=$regNumObj->nodeValue;
					$substanceNameObj=$substanceObj->getElementsByTagName('NameOfSubstance')->item(0);
					if($substanceNameObj!=null)
						$substanceName=$substanceNameObj->nodeValue;
					$substance['reg_num']=$regNum;
					$substance['name']=	$substanceName;
					$arrSubstances[]=$substance;	
				}	
			}
		}
		return $arrSubstances;
	}
	
	/**
	 * saves the array of Substances one by one
	 * @param $arrSubstances
	 * @param $pubId
	 * @return boolean
	 */
	function save_pub_substances($arrSubstances, $pubId){
		$query= array();
		foreach($arrSubstances as $substance){
			if($substance!=null){
				$substanceId=$this->pubmed->savePubmedSubstance($substance);
				
				$pubSubstance=array();
				$pubSubstance['pub_id']=$pubId;
				$pubSubstance['substance_id']=$substanceId;
				
				$query[] = '('.$pubSubstance['pub_id'].', '.$pubSubstance['substance_id'].')';
			}
		}
		if(sizeof($query) > 0)
			$this->db->query('INSERT INTO publication_substances (pub_id, substance_id) VALUES '.implode(',', $query));
		
	}
	
	/**
	 * Parses the Publication types from XML Object and returns Publication types in an array
	 * @param XML Object $publication
	 * @return Array
	 */
	function parse_pub_types($publication){
		$medlineCitation=$publication->getElementsByTagName('MedlineCitation')->item(0);
		$arrPubTypes=array();	
		$publicationTypes=$medlineCitation->getElementsByTagName('PublicationType'); 
		if($publicationTypes!=null){
			foreach($publicationTypes as $publicationType){				
				if($publicationType!=null){
					$pubType=array();
					$pubType['type']=$publicationType->nodeValue;	
					$arrPubTypes[]=$pubType;	
				}	
			}	
		}
		return $arrPubTypes;
	}
	
	/**
	 * saves the array of Publication types one by one
	 * @param Array $arrPubTypes
	 * @param Integer $pubId
	 * @return boolean
	 */
	function save_pub_types($arrPubTypes, $pubId){
		$query= array();
		foreach($arrPubTypes as $type){
			if($type!=null){
				$typeId=$this->pubmed->savePubmedPubType($type);
				
				$pubType=array();
				$pubType['pub_id']=$pubId;
				$pubType['pub_type_id']=$typeId;
				
				$query[] = '('.$pubType['pub_id'].', '.$pubType['pub_type_id'].')';
			}			
		}
		if(sizeof($query) > 0)
			$this->db->query('INSERT INTO publications_types (pub_id, pub_type_id) VALUES '.implode(',', $query));
				
	}
	
	/**
	 * Parses the Comments and Corrections from XML Object and returns Comments and Corrections in an array
	 * @param XML Object $publication
	 * @return Array
	 */
	function parse_pub_CC($publication){
		$medlineCitation=$publication->getElementsByTagName('MedlineCitation')->item(0);
		$arrCC=array();
		$arrCCObj=$medlineCitation->getElementsByTagName('CommentsCorrections'); 
		if($arrCCObj!=null){
			foreach($arrCCObj as $ccObj){
				if($ccObj!=null){
					$cc=array();
					$reftype='';
					$refSource='';
					$ccPMID='';
					$ccPMIDVersion='';
					if($ccObj->hasAttributes()){			
						$reftype=$ccObj->attributes->item(0)->value;												   		 
					}
					$refSourceObj=$ccObj->getElementsByTagName('RefSource')->item(0); 
					if($refSourceObj!=null)
						$refSource=$refSourceObj->nodeValue;
					$ccPMIDObj=$ccObj->getElementsByTagName('PMID')->item(0); 
					if($ccPMIDObj!=null){
						$ccPMID=$ccPMIDObj->nodeValue;
						if($ccPMIDObj->hasAttributes()){			
							$ccPMIDVersion=$ccPMIDObj->attributes->item(0)->value;												   		 
						}
					}
					$cc['ref_type']=$reftype;
					$cc['ref_source']=$refSource;
					$cc['cc_pmid']=$ccPMID;
					$cc['cc_pmid_version']=$ccPMIDVersion;
					$arrCC[]=$cc;
				}
			}
		}
		return $arrCC;
	}
	
	/**
	 * saves the array of Comments and Corrections one by one
	 * @param $arrCC
	 * @param $pubId
	 * @return boolean
	 */
	function save_pub_CC($arrCC, $pubId){
		$query= array(); 
		foreach( $arrCC as $row ) {
			if($row!=null){
		   		$query[] = '("'.custom_escape_string($row['ref_type']).'", "'.$row['ref_source'].'", "'.$row['cc_pmid'].'", "'.$row['cc_pmid_version'].'")';
			}
		}
		if(sizeof($query) == 0)
			return;
		if($this->db->query('INSERT INTO pubmed_cc (ref_type, ref_source, cc_pmid, cc_pmid_version) VALUES '.implode(',', $query))){
			
			$result = $this->db->query("select max(id) as id from pubmed_cc");
			$result = $result->first_row();
			$ccId=$result->id;
			$ccId = $ccId - (sizeof($arrCC)-1);
			
			$arrPubCCs = array();
			foreach($arrCC as $cc){
				if($cc!=null){
					$pubCC=array();
					$pubCC['pub_id']=$pubId;
					$pubCC['cc_id']=$ccId;
					$arrPubCCs[] = $pubCC;
					$ccId++;
				}			
			}
			$query= array();
			foreach( $arrPubCCs as $row ) {
			    $query[] = '('.$row['pub_id'].', '.$row['cc_id'].')';
			}
			$this->db->query('INSERT INTO publications_cc (pub_id, cc_id) VALUES '.implode(',', $query));
			
		}		
	}
	
	/**
	 * 
	 * @param unknown_type $publication
	 * @return unknown_type
	 */
	function parse_pub_history($publication){
		$arrHistory=array();
		$pubmedData= $publication->getElementsByTagName('PubmedData')->item(0);
		$historyObj=$pubmedData->getElementsByTagName('History')->item(0);
		if($historyObj!=null){
			$histories=$historyObj->getElementsByTagName('PubMedPubDate');
			if($histories!=null){
				foreach($histories as $historyObj){
					if($historyObj!=null){
						$pubHistory=array();
						$status='';
						$arrDateTime=array();
						$arrDate=array();
						if($historyObj->hasAttributes()){			
							$status=$historyObj->attributes->item(0)->value;												   		 
						}
						$yearObj=$historyObj->getElementsByTagName('Year')->item(0);
						if($yearObj!=null){
							$arrDateTime['year']=$yearObj->nodeValue;
							$arrDate['year']=$yearObj->nodeValue;
						}
						$monthObj=$historyObj->getElementsByTagName('Month')->item(0);
						if($monthObj!=null){
							$arrDateTime['month']=$monthObj->nodeValue;
							$arrDate['month']=$monthObj->nodeValue;
						}	
						$dayObj=$historyObj->getElementsByTagName('Day')->item(0);
						if($dayObj!=null){
							$arrDateTime['day']=$dayObj->nodeValue;
							$arrDate['day']=$dayObj->nodeValue;
				    	}
						$hourObj=$historyObj->getElementsByTagName('Hour')->item(0);
						if($hourObj!=null)
							$arrDateTime['hour']=$hourObj->nodeValue;
						$minuteObj=$historyObj->getElementsByTagName('Minute')->item(0);
						if($minuteObj!=null)
							$arrDateTime['minute']=$minuteObj->nodeValue;
						$pubHistory['status']=$status;
						$pubHistory['dateOnly']=$this->array_to_date($arrDate);
						$pubHistory['date']=$this->array_to_dattime($arrDateTime);
						$arrHistory[]=$pubHistory;
					}
				}
			}
		}
		return $arrHistory;
	}
	
	/**
	 * 
	 * @param $arrHistory
	 * @param $pubId
	 * @return unknown_type
	 */
	function save_pub_history($arrHistory, $pubId){
		$query= array(); 
		foreach($arrHistory as $pubHistory){
			if($pubHistory!=null){	
				$query[] = '("'.custom_escape_string($pubId).'", "'.$pubHistory['status'].'", "'.$pubHistory['date'].'")';
			}			
		}
		$this->db->query('INSERT INTO publication_history (pub_id, status, date) VALUES '.implode(',', $query));
		
	}
	
	/**
	 * 
	 * @param $publication
	 * @return unknown_type
	 */
	function parse_pub_article_ids($publication){
		$arrPubArticleIds=array();
		$pubmedData= $publication->getElementsByTagName('PubmedData')->item(0);
		$articleIds=$pubmedData->getElementsByTagName('ArticleId');
		foreach($articleIds as $articleIdObj){
			if($articleIdObj!=null){
				$PubArticleId=array();
				$type='';
				$idValue='';
				if($articleIdObj->hasAttributes()){			
					$type=$articleIdObj->attributes->item(0)->value;												   		 
				}
				$idValue=$articleIdObj->nodeValue;
				$PubArticleId['type']=$type;
				$PubArticleId['id_value']=$idValue;
				$arrPubArticleIds[]=$PubArticleId;
			}
		}
		return $arrPubArticleIds;
	}
				
	/**
	 * 
	 * @param $arrPubArticleIds
	 * @param $pubId
	 * @return unknown_type
	 */		
	function save_pub_article_ids($arrPubArticleIds, $pubId){
		$query= array(); 
		foreach( $arrPubArticleIds as $row ) {
			if($row!=null){
		   		$query[] = '("'.custom_escape_string($row['type']).'", "'.$row['id_value'].'")';
			}
		}
		if(sizeof($query) == 0)
			return;
		if($this->db->query('INSERT INTO pubmed_article_ids (type, id_value) VALUES '.implode(',', $query))){
			
			$result = $this->db->query("select max(id) as id from pubmed_article_ids");
			$result = $result->first_row();
			$id=$result->id;
			$id = $id - (sizeof($arrPubArticleIds)-1);
		
			$arrPublicationArticleIds =array();
			foreach($arrPubArticleIds as $articleId){
				if($articleId!=null){
					$PubArticleId=array();
					$PubArticleId['pub_id']=$pubId;
					$PubArticleId['pub_article_id']=$id;
					$id++;
					
					$arrPublicationArticleIds[] = $PubArticleId;
				}
			}
			$query= array();
			foreach( $arrPublicationArticleIds as $row ) {
				if($row!=null){
			   		$query[] = '('.$row['pub_id'].', '.$row['pub_article_id'].')';
				}
			}
			$this->db->query('INSERT INTO publication_article_ids (pub_id, pub_article_id) VALUES '.implode(',', $query));
			
		}
	}
	
	/**
	 * coverts the date in array format to sql date
	 * @param $arrayDate
	 * @return unknown_type
	 */
	function array_to_date($arrayDate){	
		if(isset($arrayDate['month']) && $arrayDate['month']!=null)	
			$arrayDate['month']=$this->month_to_integer($arrayDate['month']);
		$date='';
		if($arrayDate!=null){
			$date=$arrayDate['year']."-".$arrayDate['month']."-".$arrayDate['day'];			
		}			
		return $date;
	}	
	
	function array_to_dattime($arrDateTime){
		$date='';
		if($arrDateTime!=null){
			$date=$arrDateTime['year']."-".$arrDateTime['month']."-".$arrDateTime['day']." 00:00:00";			
		}	
		return $date;
	}
	
	
	/**
	 * Prepares the data required to display the Publication page and redirects to 'view_publications'
	 * @return unknown_type
	 * //TODO Need to pass the KOLID, like how it is done for the other methods
	 */
	function view_publications($kolId){
	
		$data['isClientView']	= false;
		
		// Get the KOL details
      	$arrKolDetail 	= $this->kol->editKol($kolId);
    	$data['arrKol']	= $arrKolDetail;

    	$arrSalutations	= array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$data['arrSalutations']	= $arrSalutations;
		
	
		//Analyst App to be accessed by only Aissel users. 
		$this->common_helpers->checkUsers();
		//$this->load->view('publications/list_publications', $data);
		$data['contentPage'] 	=	'publications/list_publications';
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited List Publications Page",
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
				'kols_or_org_id' => $kolId,
				'transaction_name' => "View List Publications"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('layouts/analyst_view',$data);
		
	}
	
	/**
	 * returns the list of publications belongs to perticular kolId
	 * @return unknown_type
	 */
	function list_publication_details(){
		$page				= (int)$this->input->post('page'); // get the requested page 
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$arrPublications 	= array();
		$data 				= array();
		$kolId				= $this->session->userdata('kolId');
		$arrPublications	= array();
		if($arrPublicationsResults=$this->pubmed->listPublicationDetails($kolId)){			
			foreach($arrPublicationsResults as $arrPublicationsResult){
				$arrPublication['id']			= $arrPublicationsResult['asoc_id'];
				$arrPublication['pmid']			= '<a href=\''. $arrPublicationsResult['link'].'\' target="_new">'.$arrPublicationsResult['pmid'].'</a>';			
				$arrPublication['journal_name']	= $this->pubmed->getJournalNameById($arrPublicationsResult['journal_id']);
				$arrPublication['article_title']= '<a target="_new" href=\''.base_url().'pubmeds/view_publication/'. $arrPublicationsResult['id'].'\'>'.$arrPublicationsResult['article_title'].'</a>';
				$arrPublication['affiliation']	= $arrPublicationsResult['affiliation'];
				$arrPublication['date']			= $arrPublicationsResult['created_date'];
				$arrPublication['authors']		= $this->get_pub_authors($arrPublicationsResult['id']);
				$arrPublication['auth_pos']		= $arrPublicationsResult['auth_pos'];
				$arrPublication['subject']		= '';
				$arrPublications[]				= $arrPublication;
			}
			$count=sizeof($arrPublications);				
			if( $count >0 ){ 
				$total_pages 	= ceil($count/$limit); 
			}else{ 
				$total_pages	= 0; 
			} 
			$data['records']	= $count;
			$data['total']		= $total_pages;
			$data['page']		= $page;				
			$data['rows']		= $arrPublications;  
		}
		echo json_encode($data);
	}
	
	
	/**
	 * returns the list of publications belongs to perticular kolId
	 * @return unknown_type
	 */
	function list_publication_details_analyst($type,$kolId){
		$page				= (int)$this->input->post('page'); // get the requested page 
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$arrPublications 	= array();
		$data 				= array();
		$arrPublications	= array();
		if($arrPublicationsResults=$this->pubmed->listPublicationDetailsForAnalyst($kolId,$type)){			
			foreach($arrPublicationsResults as $arrPublicationsResult){
				$arrPublication['id']			= $arrPublicationsResult['asoc_id'];
				$arrPublication['pub_id']		= $arrPublicationsResult['id'];
				$arrPublication['is_manual']	= $arrPublicationsResult['is_manual'];
				//$arrPublication['pmid']='<a href=\''. $arrPublicationsResult['link'].'\' target="_new">'.$arrPublicationsResult['pmid'].'</a>';
				if(isset($arrPublicationsResult['pmid']) && $arrPublicationsResult['pmid'] > 0)
					$arrPublication['pmid']		= '<a href=\'http://www.ncbi.nlm.nih.gov/pubmed/'. $arrPublicationsResult['pmid'].'\' target="_new">'.$arrPublicationsResult['pmid'].'</a>';
				else
					$arrPublication['pmid']		= '<a href=\''.base_url().'/pubmeds/view_publication/'.$arrPublicationsResult['id'].'\' target="_new">'.$arrPublicationsResult['pmid'].'</a>';			
				$arrPublication['journal_name']	= $this->pubmed->getJournalNameById($arrPublicationsResult['journal_id']);
				//$arrPublication['article_title']=$arrPublicationsResult['article_title'];
				$arrPublication['article_title']= '<a target="_new" href=\''.base_url().'pubmeds/view_publication/'. $arrPublicationsResult['id'].'\'>'.$arrPublicationsResult['article_title'].'</a>';
				$arrPublication['affiliation']	= $arrPublicationsResult['affiliation'];
				$arrPublication['date']			= $arrPublicationsResult['created_date'];
				$arrPublication['authors']		= $this->get_pub_authors($arrPublicationsResult['id']);
				$arrPublication['auth_pos']		= $arrPublicationsResult['auth_pos'];
				//$arrPublication['auth_pos']=$this->pubmed->calculateAuthorShipPosition($arrPublication['id'],$kolId,null);
				$arrPublication['subject']		= '';
				$arrPublications[]				= $arrPublication;
			}
			$count				= sizeof($arrPublications);				
			if( $count >0 ){ 
				$total_pages	= ceil($count/$limit); 
			}else{ 
				$total_pages 	= 0; 
			} 
			$data['records']	= $count;
			$data['total']		= $total_pages;
			$data['page']		= $page;				
			$data['rows']		= $arrPublications;  
		}
		ob_start('ob_gzhandler');
		echo json_encode($data);
	}
	
	
	/**
	 * Deletes the publications, serves the delete from JqGrid, takes post parameters
	 * @return unknown_type
	 */
	function delete_publications(){
		$selectedRows =$this->input->post('pub_id');
		$kolId	=	$this->input->post('kol_id');
		foreach($selectedRows as $id){			
			$isDeleted=$this->pubmed->updatePublicationAsDeleted($id);
			//$this->update->insertUpdateEntry(KOL_PROFILE_PUBLICATION_DELETE, $id, MODULE_KOL_PUBLICATION, $kolId);
		}		
		return true;
	}
	
	/**
	 * Deletes the publications, serves the delete from JqGrid, takes post parameters
	 * @return unknown_type
	 */
	function delete_publication($id){		
		$kolId	=	$this->input->post('kol_id');	
		$isDeleted=$this->pubmed->updatePublicationAsDeleted($id);
		$this->update->deleteUpdateEntry(KOL_PROFILE_PUBLICATION_ADD, $id, MODULE_KOL_PUBLICATION);
		return true;
	}
	
	public function retrieve_page_get($url){
		if($_SERVER['SERVER_ADDR'] == '192.168.1.15'){
			$aContext = array(
			    'http' => array(
			        'proxy' => 'tcp://192.168.1.90:808',
			        'request_fulluri' => true,
			    ),
			);		
			$cxContext = stream_context_create($aContext);
			
			$res=null;
			//if(!$res = file_get_contents($url)){
			if(!$res = file_get_contents($url, false, $cxContext)){
				$this->logText	= "Error in connecting to url: ".$url." \r\nTerminating process..\r\n ";
						fwrite($this->logFile, $this->logText);	
						die("Sorry! Coulndnot process, Error in connecting to url: ".$url.", LogPath: ".$this->logFilePath);										
			}			
			if(!$res)	echo 'Error in connecting to url'.$url;
			return $res;
		}else{
			$data = array();
			$res = null;
			$data['status'] = false;
			if(!$res = file_get_contents($url)){
				//$this->logText	= "Error in connecting to url: ".$url." \r\nTerminating process..\r\n ";
				//fwrite($this->logFile, $this->logText);	
				//die("Sorry! Coulndnot process, Error in connecting to url: ".$url.", LogPath: ".$this->logFilePath);
				$data['status'] = false;											
			}else{
				$data['status'] = true;
			}			
			if(!$res){	
				//echo 'Error in connecting to url'.$url;
				$data['status'] = false;
			}else{
				$data['status'] = true;
			}
			
			$data['response'] = $res;
			return $data;
		}
	}
	
	function get_pub_authors($pubId){		
		$authNames='';
		$arrAuthors=$this->pubmed->listPublicationAuthors($pubId);
		foreach($arrAuthors as $author){
			$authName=$author['last_name']." ".$author['initials'];
			if($authNames==''){
				$authNames=$authName;
			} else{
			$authNames=$authNames.",".$authName;
			}
		}		
		return $authNames;	
	}
	
	function view_publication($pubId){				
		$publication=$this->pubmed->getPublicationDetail($pubId);
			$publication['journal_name']=$this->pubmed->getJournalNameById($publication['journal_id']);
			if($publication['pub_date']=='0000-00-00' || $publication['pub_date']=='')	
				$publication['pub_date']='';
			else				
				$publication['pub_date']=sql_date_to_app_date($publication['pub_date']);
			if($publication['article_date'] != '')
			$publication['article_date']=sql_date_to_app_date($publication['article_date']);
		$arrAuthors=$this->pubmed->listPublicationAuthors($pubId);
		$arrMeshTerms=array();
		$arrMeshTermsResults=$this->pubmed->listPublicationMeshTerms($pubId);
			foreach($arrMeshTermsResults as $meshTerm){
				$termName='';
				$parentId=$meshTerm['parent_id'];
				if($parentId!=0 && $parentId!=null){
					$parentName=$this->pubmed->getMeshTermName($parentId);
					$termName=$parentName."/".$meshTerm['term_name'];
				}else{
					$termName=$meshTerm['term_name'];
				}
				if($meshTerm['is_major']==1)
					$termName=$termName."*";
				$arrMeshTerms[]=$termName;
			}
		$arrSubstances=$this->pubmed->listPublicationSubstances($pubId);
		$arrPubTypes=$this->pubmed->listPublicationPubTypes($pubId);

		$data['publication']=$publication;
		$data['arrAuthors']=$arrAuthors;
		$data['arrMeshTerms']=$arrMeshTerms;
		$data['arrSubstances']=$arrSubstances;
		$data['arrPubTypes']=$arrPubTypes;
		
		$data['contentPage'] 	=	'publications/view_publication';
		//$this->load->view('layouts/kol_profile',$data);
		$this->load->view('publications/view_publication',$data);		
	}
	
	function month_to_integer($month){		
		if($month=='Jan')
			return 1;		
		if($month=='feb')
			return 2;
		if($month=='mar')
			return 3;
		if($month=='apr')
			return 4;
		if($month=='may')
			return 5;	
		if($month=='jun')
			return 6;
		if($month=='jul')
			return 7;
		if($month=='aug')
			return 8;
		if($month=='sep')
			return 9;
		if($month=='oct')
			return 10;
		if($month=='nov')
			return 11;
		if($month=='dec')
			return 12;		
			
		return (int)$month;
	}
	
		
  	/**
	 * Searches the meshTerm Names and returns meshTerm Names matched
	 * 
	 * @param String	$meshTermName
	 * @return unknown_type
	 */
	function get_mesh_terms_name($meshTermName){
		
		$arrMeshTerms = $this->pubmed->getPubMeshTermsName($meshTermName);
		
		$arrReturnData['query'] = $meshTermName;
		$arrReturnData['suggestions']	= $arrMeshTerms;
		echo json_encode($arrReturnData);
	}
	
  	/**
	 * Searches the Journal Name and returns Journal Names matched
	 * 
	 * @param String	$journalName
	 * @return unknown_type
	 */
	function get_journals_name($journalName){
		
		$arrJournalName = $this->pubmed->getPubJournalsName($journalName);
		
		$arrReturnData['query'] = $journalName;
		$arrReturnData['suggestions']	= $arrJournalName;
		echo json_encode($arrReturnData);
	}
	
  	/**
	 * Searches the Affiliation Name and returns Affiliation Names matched
	 * 
	 * @param String	$affiliationName
	 * @return unknown_type
	 */
	function get_affiliations_name($affiliationName){
		
		$arrAffiliationName = $this->pubmed->getPubAffiliationsName($affiliationName);
		
		$arrReturnData['query'] = $affiliationName;
		$arrReturnData['suggestions']	= $arrAffiliationName;
		echo json_encode($arrReturnData);
	}
	
  	/**
	 * Searches the Substances Name and returns Substances Names matched
	 * 
	 * @param String	$substancesName
	 * @return unknown_type
	 */
	function get_substances_name($substancesName){
		
		$arrSubstancesName = $this->pubmed->getPubSubstancesName($substancesName);
		
		$arrReturnData['query'] = $substancesName;
		$arrReturnData['suggestions']	= $arrSubstancesName;
		echo json_encode($arrReturnData);
	}
	
	
	//-----Start of search function for "publications"
	/**
	 *  returns the simple search results for publications, matching the keyword with Article Name
	 *  
	 * @return unknown_type
	 */
	function search_publications(){
		$count=30;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=0;
		$category		=	$this->input->post('category');
		$keyword		=	trim($this->input->post('keyword'));
		$searchType		= 	'simple';
		$arrPublications		=	array();
	
		
		$arrPublicationsResultSet	=$this->pubmed->getMatchingPublications($keyword,$limit,$startFrom,false);
		$count						=$this->pubmed->getMatchingPublications($keyword,$limit,$startFrom,true);
		foreach ($arrPublicationsResultSet as $arrPublicationsResult){
			$arrPublicationsResult['date']			=	$this->kol->convertDateToMM_DD_YYYY($arrPublicationsResult['created_date']);
			$arrPublications[]						=	$arrPublicationsResult;
		}
	
		$filterData['keyword']				=	$keyword;
		$filterData['searchType']			= 	$searchType;
		$filterData['arrFilterFields']		= 	"";
		$filterData['arrAdvSearchFields']	= 	"";
		$pubsResultsData['pubsCount']=$count;
		$pubsResultsData['arrPublications']=$arrPublications;
		$pubsResultsData['searchType']="simple";
		$pubsResultsData['msg']=$this->common_helpers->genSearchResMsgs($startFrom,$limit,$count,$keyword);
		$details['pubsResultsPage']	=	'search/pubs_search_results';
		$details['pubsResultsData']	=	$pubsResultsData;
		
		$details['arrPublications']			=	$arrPublications;
		$details['filterPage']				=	'search/pubs_filters';
		$details['filterData']				=	$filterData;
		$data['data']						=	$details;
		$data['contentPage'] 				=	'search/pubs_results';
		$this->load->view('layouts/client_view',$data);
		
	}
	
	function view_pubs_adv_search(){
		$data['contentPage'] 	=	'search/pubs_adv_search';
		$this->load->view('layouts/client_view',$data);
	}
	/**
	 * returns the "advance"  search results for Publications
	 * @author 	Ambarish N
	 * @since	2.4
	 * @created June-07-2011
	 * @return unknown_type
	 */
	function adv_search_publications(){
		$count=0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=0;
		$arrPublications	=	array();
		$arrFilterFields['journal']='';
		$arrFilterFields['affiliation']='';
		$arrFilterFields['meshterm']='';
		$arrFilterFields['substance']='';
		$searchType	=	$this->input->post('search_type');
		
		// Getting the POST details of Trials Advance search
		$arrAdvSearchFields = array('keyword'		=>	trim($this->input->post('keyword')),
									'journals'  	=>	'',
									'affiliations' 	=> 	'',
									'pubKeywords'   =>	trim($this->input->post('pubKeywords')),
									'authors' 		=> 	trim($this->input->post('authors')),
									'mesh_term'		=>	trim($this->input->post('mesh_term')),
									'substances'	=> 	trim($this->input->post('substances')),
									'article_title'	=> 	trim($this->input->post('article_title')
										));
		
		$arrPublicationsResultSet	= $this->pubmed->getAdvSearchMatchingPublications($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false);
		$count						= $this->pubmed->getAdvSearchMatchingPublications($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,true);
		
		//Get count of Publications grouping by category(for each category)
		$arrPublicationsByJournalCount		= $this->pubmed->getAdvSearchMatchingPublications($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false,true,'journal');
		$arrPublicationsByAffiliationCount	= $this->pubmed->getAdvSearchMatchingPublications($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false,true,'affiliation');
		$arrPublicationsByMeshtermCount		= $this->pubmed->getAdvSearchMatchingPublications($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false,true,'meshterm');
		$arrPublicationsBySubstanceCount	= $this->pubmed->getAdvSearchMatchingPublications($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false,true,'substance');
		
		//Preparing the Publications by category results as required by the filter page and aso getting the total count for category
		$allJournalCount=0;
		$assoArrPublicationsByJournalCount=array();
		foreach($arrPublicationsByJournalCount as $row){
			$row['journal'] = $row['journal_name'];
			$assoArrPublicationsByJournalCount[$row['journal_name']]=$row;
			$allJournalCount+=$row['count'];
		}
		$allAffiliationCount=0;
		$assoArrPublicationsByAffiliationCount=array();
		foreach($arrPublicationsByAffiliationCount as $row){
			$assoArrPublicationsByAffiliationCount[$row['affiliation']]=$row;
			$allAffiliationCount+=$row['count'];
		}
		$allMeshtermCount=0;
		$assoArrPublicationsByMeshtermCount=array();
		foreach($arrPublicationsByMeshtermCount as $row){
			$assoArrPublicationsByMeshtermCount[$row['meshterm']]=$row;
			$allMeshtermCount+=$row['count'];
		}
		
		$allSubstanceCount=0;
		$assoArrPublicationsBySubstanceCount=array();
		foreach($arrPublicationsBySubstanceCount as $row){
			$assoArrPublicationsBySubstanceCount[$row['substance']]=$row;
			$allSubstanceCount+=$row['count'];
		}
		
		foreach ($arrPublicationsResultSet as $arrPublicationsResult){
			$arrPublicationsResult['date']		=	sql_date_to_app_date($arrPublicationsResult['created_date']);
			$arrPublications[]					=	$arrPublicationsResult;
		}
		
		//Setting all the required data and forwording in to respective page
		$filterData['allJournalCount']=$allJournalCount;
		$filterData['allAffiliationCount']=$allAffiliationCount;
		$filterData['allMeshtermCount']=$allMeshtermCount;
		$filterData['allSubstanceCount']=$allSubstanceCount;
		
		$filterData['arrPublicationsByJournalCount']=$assoArrPublicationsByJournalCount;
		$filterData['arrPublicationsByAffiliationCount']=$assoArrPublicationsByAffiliationCount;
		$filterData['arrPublicationsByMeshtermCount']=$assoArrPublicationsByMeshtermCount;
		$filterData['arrPublicationsBySubstanceCount']=$assoArrPublicationsBySubstanceCount;
		
		$filterData['keyword']				=	$arrAdvSearchFields['keyword'];
		$filterData['searchType']			= 	$searchType;
		$filterData['arrFilterFields']		= 	"";
		$filterData['arrAdvSearchFields']	= 	$arrAdvSearchFields;
		$pubsResultsData['pubsCount']=$count;
		$pubsResultsData['arrPublications']=$arrPublications;
		$pubsResultsData['searchType']="simple";
		$pubsResultsData['msg']=$this->common_helpers->genSearchResMsgs($startFrom,$limit,$count,$arrAdvSearchFields);
		$details['pubsResultsPage']	=	'search/pubs_search_results';
		$details['pubsResultsData']	=	$pubsResultsData;
		
		$details['arrPublications']			=	$arrPublications;
		$details['filterPage']				=	'search/pubs_filters';
		$details['filterData']				=	$filterData;
		$data['data']						=	$details;
		$data['contentPage'] 				=	'search/pubs_results';
		$this->load->view('layouts/client_view',$data);
		
	}
	
	function filter_search_publications(){
		$page=$this->input->post('page');
		$count=30;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		$arrPublications	=	array();
		$searchType	=	$this->input->post('search_type');
		
		// Getting the POST details of Trials Advance search
		$arrFilterSearchFields = array(	'keyword'		=>	trim($this->input->post('keyword')),
										'journals'  	=>	trim($this->input->post('journals')),
										'affiliations' 	=> 	trim($this->input->post('affiliations')),
										'mesh_term'		=>	trim($this->input->post('mesh_term')),
										'substances'	=> 	trim($this->input->post('substances')));
		
		$arrPublicationsResultSet	=$this->pubmed->getFilterSearchMatchingPublications($arrFilterSearchFields,$limit,$startFrom,false);
		$count						=$this->pubmed->getFilterSearchMatchingPublications($arrFilterSearchFields,$limit,$startFrom,true);
		foreach ($arrPublicationsResultSet as $arrPublicationsResult){
			$arrPublicationsResult['date']		=	sql_date_to_app_date($arrPublicationsResult['created_date']);
			$arrPublications[]					=	$arrPublicationsResult;
		}
		
		$filterData['keyword']				=	$arrFilterSearchFields['keyword'];
		$filterData['searchType']			= 	$searchType;
		$filterData['arrFilterFields']		= 	$arrFilterSearchFields;
		$filterData['arrAdvSearchFields']	= 	"";
		$pubsResultsData['pubsCount']=$count;
		$pubsResultsData['arrPublications']=$arrPublications;
		$pubsResultsData['searchType']="simple";
		$pubsResultsData['msg']=$this->common_helpers->genSearchResMsgs($startFrom,$limit,$count,$arrFilterSearchFields);
		$details['pubsResultsPage']	=	'search/pubs_search_results';
		$details['pubsResultsData']	=	$pubsResultsData;
		
		$details['arrPublications']			=	$arrPublications;
		$details['filterPage']				=	'search/pubs_filters';
		$details['filterData']				=	$filterData;
		$data['data']						=	$details;
		$data['contentPage'] 				=	'search/pubs_results';
		$this->load->view('search/pubs_search_results',$pubsResultsData);
		
	}
	/**
	 * returns the "advance"  filter search results for Publications
	 * @author 	Ambarish N
	 * @since	2.4
	 * @created June-07-2011
	 * @return unknown_type
	 */
	function filter_adv_search_publications(){
		$page=$this->input->post('page');
		$count=0;
		$noOfRecordsPerPage	= $this->uri->segment(3);
		if(!empty($noOfRecordsPerPage)){
			$this->ajax_pagination->set_records_per_page($noOfRecordsPerPage);
		}
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
			
		$arrPublications	=	array();
		$searchType			=	'addvanced';
		if((int)$page>-1){
			$keyword=trim($this->session->userdata('keyword'));	
			$arrFilterFields=$this->session->userdata('arrFilterFields');	
		}else{
			$searchType=$this->input->post('search_type');
			$keyword=trim($this->session->userdata('keyword'));
			
			$journal		=	trim($this->input->post('journal'));	
			$affiliation	=	trim($this->input->post('affiliation'));
			$meshterm		=	trim($this->input->post('meshterm'));
			$substance		=	trim($this->input->post('substance'));
			
			$arrJournals	=	$this->input->post('journals');
			if($arrJournals!='')
				$arrJournals	=explode(",",$arrJournals);
			if($journal!=''){
				$arrJournals[]	=	$journal;
			}
			
			$arrAffiliations	=	$this->input->post('affiliations');
			if($arrAffiliations!='')
				$arrAffiliations	=explode(",",$arrAffiliations);
			if($affiliation!=''){
				$arrAffiliations[]	=	$affiliation;
			}
			
			$arrMeshterms	=	$this->input->post('meshterms');
			if($arrMeshterms!='')
				$arrMeshterms	=explode(",",$arrMeshterms);
			if($meshterm!=''){
				$arrMeshterms[]	=	$meshterm;
			}
			
			$arrSubstances	=	$this->input->post('substances');
			if($arrSubstances!='')
				$arrSubstances	=explode(",",$arrSubstances);
			if($substance!=''){
				$arrSubstances[]	=	$substance;
			}
			
			$arrFilterFields['journal']=$arrJournals;	
			$arrFilterFields['affiliation']=$arrAffiliations;	
			$arrFilterFields['meshterm']=$arrMeshterms;	
			$arrFilterFields['substance']=$arrSubstances;
		}
		// Getting the POST details of Trials Advance search
		$arrAdvSearchFields = array('keyword'		=>	trim($this->input->post('keyword')),
									'journals'   	=>	'',
									'affiliations' 	=> 	'',
									'pubKeywords'   =>	trim($this->input->post('pubKeywords')),
									'authors' 		=> 	trim($this->input->post('pubAuthors')),
									'mesh_term'		=>	trim($this->input->post('pubMesh_term')),
									'substances'	=> 	trim($this->input->post('pubSubstances')));
		
		$arrPublicationsResultSet	=$this->pubmed->getAdvSearchMatchingPublications($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false);
		$count						=$this->pubmed->getAdvSearchMatchingPublications($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,true);
		
		foreach ($arrPublicationsResultSet as $arrPublicationsResult){
			$arrPublicationsResult['date']		=	sql_date_to_app_date($arrPublicationsResult['created_date']);
			$arrPublications[]					=	$arrPublicationsResult;
		}

		
		$filterData['keyword']				=	$arrAdvSearchFields['keyword'];
		$filterData['searchType']			= 	$searchType;
		$filterData['arrFilterFields']		= 	$arrAdvSearchFields;
		$filterData['arrAdvSearchFields']	= 	$arrAdvSearchFields;
		$pubsResultsData['pubsCount']=$count;
		$pubsResultsData['arrPublications']=$arrPublications;
		$pubsResultsData['searchType']="simple";
		$pubsResultsData['msg']=$this->common_helpers->genSearchResMsgs($startFrom,$limit,$count,$arrAdvSearchFields);
		$details['pubsResultsPage']	=	'search/pubs_search_results';
		$details['pubsResultsData']	=	$pubsResultsData;
		
		$details['arrPublications']			=	$arrPublications;
		$details['filterPage']				=	'search/pubs_filters';
		$details['filterData']				=	$filterData;
		$data['data']						=	$details;
		$data['contentPage'] 				=	'search/pubs_results';
		$this->load->view('search/pubs_search_results',$pubsResultsData);
		
	}
	
	/**
	 * Retrives the data required for the Publication checkbox's kind of filters
	 * @author 	Ambarish N
	 * @since	2.4
	 * @return 
	 * @created June-07-2011
	 */
	function reload_pub_filters(){
		$arrFilterFields=array();
		$page=$this->input->post('page');
		$count =0;
		$limit=$this->ajax_pagination->per_page;
		$startFrom=$page;
		if($startFrom==-1)
			$startFrom=0;
		$searchType='';
		$keyword='';
		
		$arrConditions	=array();
		$arrSpecialties	=array();
			
		if((int)$page>-1){
			$keyword=trim($this->session->userdata('keyword'));	
			$arrFilterFields=$this->session->userdata('arrFilterFields');	
		}
		else{
			$searchType=$this->input->post('search_type');
			$keyword=trim($this->session->userdata('keyword'));
			
			$journal		=	trim($this->input->post('journal'));		
			$affiliation	=	trim($this->input->post('affiliation'));
			$intervention	=	trim($this->input->post('intervention'));
			$meshterm		=	trim($this->input->post('meshterm'));
			$substance		=	trim($this->input->post('substance'));
			$listName		=	trim($this->input->post('list_name'));
			
			$arrJournals	=	$this->input->post('journals');
			if($arrJournals!='')
				$arrJournals	=explode(",",$arrJournals);
			if($journal!=''){
				$arrJournals[]	=	$journal;
			}
			
			$arrAffiliations	=	$this->input->post('affiliations');
			if($arrAffiliations!='')
				$arrAffiliations	=explode(",",$arrAffiliations);
			if($affiliation!=''){
				$arrAffiliations[]	=	$affiliation;
			}
			
			$arrMeshterms	=	$this->input->post('meshterms');
			if($arrMeshterms!='')
				$arrMeshterms	=explode(",",$arrMeshterms);
			if($meshterm!=''){
				$arrMeshterms[]	=	$meshterm;
			}
			
			$arrSubstances	=	$this->input->post('substances');
			if($arrSubstances!='')
				$arrSubstances	=explode(",",$arrSubstances);
			if($substance!=''){
				$arrSubstances[]	=	$substance;
			}
			
			//Prepare array of filter fields, ehich will be used for querying
			$arrFilterFields['journal']=$arrJournals;		
			$arrFilterFields['affiliation']=$arrAffiliations;	
			$arrFilterFields['meshterm']=$arrMeshterms;	
			$arrFilterFields['substance']=$arrSubstances;
		}
		
		//Split the keyword by 'comma' or '+' or 'space'	
		$arrKeywords=explode("+",$keyword);	
		
		// We can modify the below logic so as to use the single 'or' and 'and' methods by 
		//sending the array of keyword names and enbling the where condition based on the 
		//size of the array in those methods
		if(sizeof($arrKeywords)==1){
			$name=$keyword;
			
			// Getting the POST details of Trials Advance search
			$arrAdvSearchFields = array('keyword'		=>	trim($this->input->post('keyword')),
										'journals'   	=>	'',
										'affiliations' 	=> 	'',
										'pubKeywords'   =>	trim($this->input->post('pubKeywords')),
										'authors' 		=> 	trim($this->input->post('pubAuthors')),
										'mesh_term'		=>	trim($this->input->post('pubMesh_term')),
										'substances'	=> 	trim($this->input->post('pubSubstances')));
			
			$arrPublicationsByJournalCount =$this->pubmed->getAdvSearchMatchingPublications($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false,true,'journal');
			$arrPublicationsByAffiliationCount=$this->pubmed->getAdvSearchMatchingPublications($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false,true,'affiliation');
			$arrPublicationsByMeshtermCount=$this->pubmed->getAdvSearchMatchingPublications($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false,true,'meshterm');
			$arrPublicationsBySubstanceCount=$this->pubmed->getAdvSearchMatchingPublications($arrAdvSearchFields,$arrFilterFields,$limit,$startFrom,false,true,'substance');
			
		}
		
		//pr($arrAdvSearchFields);
		//Save the search keyword and arrFilter fileds in order to use them when request comes for different page results(pagination)
		$this->session->set_userdata('keyword',$keyword);
		$this->session->set_userdata('arrFilterFields',$arrFilterFields);
		$arrSalutations	= array(0 => '','Dr.', 'Prof.', 'Mr.', 'Ms.');
		
		//Preparing the kols by category results as required by the filter page and aso getting the total count for category
		$allJournalCount=0;
		$assoArrPublicationsByJournalCount=array();
		foreach($arrPublicationsByJournalCount as $row){
			$row['journal'] = $row['journal_name'];
			$assoArrPublicationsByJournalCount[$row['journal_name']]=$row;
			$allJournalCount+=$row['count'];
		}
		$allAffiliationCount=0;
		$assoArrPublicationsByAffiliationCount=array();
		foreach($arrPublicationsByAffiliationCount as $row){
			$assoArrPublicationsByAffiliationCount[$row['affiliation']]=$row;
			$allAffiliationCount+=$row['count'];
		}
		
		$allMeshtermCount=0;
		$assoArrPublicationsByMeshtermCount=array();
		foreach($arrPublicationsByMeshtermCount as $row){
			$assoArrPublicationsByMeshtermCount[$row['meshterm']]=$row;
			$allMeshtermCount+=$row['count'];
		}
		$allSubstanceCount=0;
		$assoArrPublicationsBySubstanceCount=array();
		foreach($arrPublicationsBySubstanceCount as $row){
			$assoArrPublicationsBySubstanceCount[$row['substance']]=$row;
			$allSubstanceCount+=$row['count'];
		}
		
		//Setting all the required data and forwording in to respective page
		$filterData['allJournalCount']=$allJournalCount;
		$filterData['allAffiliationCount']=$allAffiliationCount;
		$filterData['allMeshtermCount']=$allMeshtermCount;
		$filterData['allSubstanceCount']=$allSubstanceCount;
		
		$filterData['arrPublicationsByJournalCount']=$assoArrPublicationsByJournalCount;
		$filterData['arrPublicationsByAffiliationCount']=$assoArrPublicationsByAffiliationCount;
		$filterData['arrPublicationsByMeshtermCount']=$assoArrPublicationsByMeshtermCount;
		$filterData['arrPublicationsBySubstanceCount']=$assoArrPublicationsBySubstanceCount;
		
		$filterData['selectedJournals']=$arrJournals;
		$filterData['selectedAffiliations']=$arrAffiliations;
		$filterData['selectedMeshterms']=$arrMeshterms;
		$filterData['selectedSubstances']=$arrSubstances;
		
		$filterData['keyword']=$keyword;
		$filterData['arrAdvSearchFields']=$arrAdvSearchFields;
		$filterData['arrFilterFields']=$arrFilterFields;
		$filterData['searchType']=$searchType;
		$kolResultsData['arrSalutations']=$arrSalutations;
		$kolResultsData['searchType']="simple";
		$kolResultsData['eventsCount']=$count;
		$kolResultsData['msg']=$this->common_helpers->genSearchResMsgs($startFrom,$limit,$count,$keyword);
		$details['filterPage']	=	'pubs_filters';
		$details['kolResultsPage']	=	'search/pubs_search_results';
		$details['kolResultsData']	=	$kolResultsData;
		$details['filterData']	= $filterData;
		$data['data']=$details;
		$data['contentPage'] 	=	'search/pubs_results';
		//echo json_encode($data);
		$this->load->view('search/pubs_filters',$filterData);
	}
	//-----End of search function for "publications"
	
	function view_micro_pub($pubId){
		$publication=$this->pubmed->getPublicationDetail($pubId);
			$publication['journal_name']=$this->pubmed->getJournalNameById($publication['journal_id']);
			if($publication['pub_date']=='0000-00-00')	
				$publication['pub_date']='';
			else				
				$publication['pub_date']=sql_date_to_app_date($publication['pub_date']);
			$publication['created_date']=sql_date_to_app_date($publication['created_date']);
		$arrAuthors=$this->pubmed->listPublicationAuthors($pubId);
		$arrMeshTerms=array();
		$arrMeshTermsResults=$this->pubmed->listPublicationMeshTerms($pubId);
			foreach($arrMeshTermsResults as $meshTerm){
				$parentId=$meshTerm['parent_id'];
				if($parentId!=0 && $parentId!=null){
					$parentName=$this->pubmed->getMeshTermName($parentId);
					$termName=$parentName."/".$meshTerm['term_name'];
				}else{
					$termName=$meshTerm['term_name'];
				}
				if($meshTerm['is_major']==1)
					$termName=$termName."*";
				$arrMeshTerms[]=$termName;
			}
		$data['publication']=$publication;
		$data['arrAuthors']=$arrAuthors;
		$data['arrMeshTerms']=$arrMeshTerms;
		$this->load->view('publications/view_pub_micro_profile',$data);
	}
	
	/**
	 * Calculate the authorship Positions of each kols for each publication
	 * This function is writen to inorder to update the Auth function in kol_publications instead
	 * of saving in Pubmed_Authors table
	 * @author 	Ramesh B
	 * @Created on: 22-02-11
	 * @since 1.4.4
	 * @return unknown_type
	 */
	function update_auth_pos_temp_fun($kolId){
		ini_set("max_execution_time",$this->maxScriptTime);	
		//$arrKolDetailResult = $this->kol->getKolDetail();
		//$arrKolDetailResult=array(3,5,7,30,32,33,41,43,45,51,71,74,75,76,77,79,81,84,85,86,87,88,89,90,91,92,93,94,95,96,100);
		$arrKolDetailResult=array($kolId);
		foreach($arrKolDetailResult as $kolId){
			$arrKolDetail=$this->pubmed->getKolDetail($kolId);
		//	pr($arrKolDetail);
			$arrPublicationsResults=$this->pubmed->listPublicationDetails($kolId);
			foreach($arrPublicationsResults as $pub){
			echo $pub['id']." :Id<br />";
				//$pos=$this->pubmed->get_authorship_pos($pub['id'],$kolId,$arrKolDetail);
				//echo $pub['id']." :Id<br />";
				$pos=$this->pubmed->calculateAuthorShipPosition($pub['id'],$kolId,$arrKolDetail);
				$this->pubmed->updateAuthorshipPos($kolId,$pub['id'],$pos);
			//echo $pos." :Position<br />";
			}
			//echo $kolId."Complete <br />";
		}
	}
	
	/**
	 * Returns the json data repersenting the kol pubs count by authorship position
	 * @author 	Ramesh B
	 * @Created on: 23-02-11
	 * @since 1.4.4
	 * @return Json
	 */
	function get_kol_auth_pos_chart_data($kolId,$start,$end){
		$keyWord = $this->input->post('keyWord');
		
		$this->session->set_userdata('kolKeyWords',$keyWord);
		$keyWord = $this->session->userdata('kolKeyWords');
		
		$arrSingleAuthPubs		=	$this->pubmed->getKolPubsWithSingleAuthor($kolId,$start,$end,0,0,0,0,$keyWord);
		$arrFirstAuthPubs		=	$this->pubmed->getKolPubsWithFirstAuthorship($kolId,$start,$end,0,0,0,0,$keyWord);
		$arrLastAuthPubs		=	$this->pubmed->getKolPubsWithLastAuthorship($kolId,$start,$end,0,0,0,0,$keyWord);
		$arrMiddleAuthPubs		=	$this->pubmed->getKolPubsWithMiddleAuthorship($kolId,$start,$end,0,0,0,0,$keyWord);
		
		$arrSingleAuthPubsCount		=	sizeof($arrSingleAuthPubs);
		$arrFirstAuthPubsCount		=	sizeof($arrFirstAuthPubs);
		$arrLastAuthPubsCount		=	0;
		$arrMiddleAuthPubsCount		=	0;
		
		foreach($arrLastAuthPubs as $lastAuthPub){
			if($lastAuthPub['auth_pos']==$lastAuthPub['max_pos'] && $lastAuthPub['max_pos']!=1)
				$arrLastAuthPubsCount++;
		}
		
		foreach($arrMiddleAuthPubs as $middleAuthPub){
			if($middleAuthPub['auth_pos']!=$middleAuthPub['max_pos'])
				$arrMiddleAuthPubsCount++;
		}
		$arrSectors=array(
							array("First Authorship",(int)$arrFirstAuthPubsCount),
							array("Single Authorship",(int)$arrSingleAuthPubsCount),
							array("Middle Authorship",(int)$arrMiddleAuthPubsCount),
							array("Last Authorship",(int)$arrLastAuthPubsCount),
							);
		$arrSectorsData=array();				
		foreach($arrSectors as $sector){
			if($sector[1]!=0)
				$arrSectorsData[]=$sector;
		}
		
		echo json_encode($arrSectorsData);
	}

	/**
	 * Returns the json data repersenting the kol pubs year range
	 * @author 	Ramesh B
	 * @Created on: 23-02-11
	 * @since 1.4.4
	 * @return Json
	 */
	function get_kol_pubs_years_range($kolId){
		$arrYears=$this->pubmed->getKolPubsYearsRange($kolId);
		echo json_encode($arrYears);
	}
	
	
	/**
	 * Display the publication details for passed year
	 * @return unknown_type
	 * @author Ambarish
	 * @since 1.4.4
	 * @Created-on 22/02/2011
	 */
	function view_publications_by_year($kol_id, $year, $reportFilters = '',$viewTypeMyKols){
		if($viewTypeMyKols == MY_RECORDS){
			$viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
			if(sizeof($viewMyKols) > 0){
				$viewType = $viewMyKols;
				$viewTypeMyKols = MY_RECORDS;
			}else{
				$viewTypeMyKols = ALL_RECORDS;
			}
		}else{
			$viewTypeMyKols = ALL_RECORDS;
		}
		
		$filters = array();
		$filters = $this->filters_to_array($reportFilters);
//		if($filters['kol_id'][0]!=''){
//			$filters['kol_id'] = $this->getKolIds($filters['kol_id']);
//		}
		
		$filters['keyword'] = $this->session->userdata('kolKeyWords');
		$arrPublications = $this->pubmed->getYearPublications($kol_id, $year, $filters, $viewType);	
//		echo $this->db->last_query();
		$data['arrPublications']			= $arrPublications;
		$data['filterType']					= 'Publications By Year';
		$data['filterValue']				= $year;
		$data['fromYear']					= '';
		$data['toYear']						= '';
		if($kol_id != 0){
			$koldetails = $this->kol->getKolName($kol_id);
			$data['first_name']		= $koldetails['first_name'];
			$data['middle_name']	= $koldetails['middle_name'];
			$data['last_name']		= $koldetails['last_name'];
		}
		$this->load->view('publications/view_publications_by_parameters',$data);
	} 
	function get_auth_by_pub_id($pubId){	   
	    $data['arrKols'] = $this->pubmed->getAuthBypubId($pubId);	    
	    $this->load->view('publications/publications_authors', $data);
	}

	
	/**
	 * Counts the number of minor Meshterm for one kol
	 * 
	 * @return unknown_type
	 * @author Ambarish
	 * @since 1.4.4
	 * @Created-on 22/02/2011
	 * @param unknown_type $kolId,$fromYear,$toYear
	 * @return unknown_type
	 */
	function view_pub_minor_meshterm_chart($kolId=null, $fromYear, $toYear){
		$arrMinorMeshterm = $this->pubmed->getPubMinorMeshTermChart($kolId, $fromYear, $toYear);
		//pr($arrMajorMeshterm);
		$meshTerms=array();
		$count=array();
		$arrIds = array();
		foreach($arrMinorMeshterm as $meshterm){
			$meshTerms[]=ucwords($meshterm['mesh_term']);
			$count[]=(int)$meshterm['count'];
			$arrIds[]=$meshterm['id'];
		}
		$data[]=$meshTerms;
		$data[]=$count;
		$data[]=$arrIds;
		echo json_encode($data);
		//echo json_encode($arrMajorMeshterm);
	}
	
	/**
	 * Counts the number of minor Substances for one kol
	 * 
	 * @author Ambarish
	 * @since 1.4.4
	 * @Created-on 22/02/2011
	 * 
	 * @param $kolId
	 * @param $fromYear
	 * @param $toYear
	 * @return unknown_type
	 */
	function view_pub_substances_chart($kolId=null, $fromYear, $toYear){
		$keyWord = $this->input->post('keyWord');
		
		$this->session->set_userdata('kolKeyWords',$keyWord);
		$keyWord = $this->session->userdata('kolKeyWords');
		$arrSubstances = $this->pubmed->getPubSubstancesChart($kolId, $fromYear, $toYear,$keyWord);
		//pr($arrSubstances);
		$substances=array();
		$count=array();
		$arrIds=array();
		foreach($arrSubstances as $substance){
			$substances[]=ucwords($substance['name']);
			$count[]=(int)$substance['count'];
			$arrIds[] = $substance['id'];
		}
		$data[]=$substances;
		$data[]=$count;
		$data[]=$arrIds;
		echo json_encode($data);
		//echo json_encode($arrSubstances);
	}
	
	/**
	 * Display the publication details for passed $substanceName with the year range
	 * @return unknown_type
	 * @author Ambarish
	 * @since 1.4.4
	 * @Created-on 22/02/2011
	 * 
	 * @param unknown_type $substanceName
	 * @param unknown_type $kolId
	 * @param unknown_type $fromYear
	 * @param unknown_type $toYear
	 * @return unknown_type
	 */
	function view_publications_by_substances($substanceName, $kol_id, $fromYear, $toYear, $reportFilters = '',$viewTypeMyKols){
		if($viewTypeMyKols == MY_RECORDS){
			$viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
			if(sizeof($viewMyKols) > 0){
				$viewType = $viewMyKols;
				$viewTypeMyKols = MY_RECORDS;
			}else{
				$viewTypeMyKols = ALL_RECORDS;
			}
		}else{
			$viewTypeMyKols = ALL_RECORDS;
		}
		$filters = array();
		$filters = $this->filters_to_array($reportFilters);
//		if($filters['kol_id'][0]!=''){
//			$filters['kol_id'] = $this->getKolIds($filters['kol_id']);
//		}
		$arrPublications = $this->pubmed->getSubstancesPublications($substanceName, $kol_id, $fromYear, $toYear, $filters, $viewType);
		$substanceName = $this->pubmed->getSubstanceNameById($substanceName);	
		
		$data['arrPublications']			= $arrPublications;
		$data['filterType']					= 'Publications By Substances';
		$data['filterValue']				= $substanceName;
		$data['fromYear']					= $fromYear;
		$data['toYear']						= $toYear;
		if($kol_id != 0){
			$koldetails = $this->kol->getKolName($kol_id);
			$data['first_name']		= $koldetails['first_name'];
			$data['middle_name']	= $koldetails['middle_name'];
			$data['last_name']		= $koldetails['last_name'];
		}
		$this->load->view('publications/view_publications_by_parameters',$data);
	} 
	
	/**
	 * Display the publication details for the passed Minor meshterm with the year range
	 * 
	 * @author Ambarish
	 * @since 1.4.4
	 * @Created-on 22/02/2011
	 * 
	 * @param unknown_type $meshterm
	 * @param unknown_type $kolId
	 * @param unknown_type $fromYear
	 * @param unknown_type $toYear
	 * @return unknown_type
	 */
	function view_publications_by_minor_meshterm($meshterm, $kol_id, $fromYear, $toYear){
		$arrPublications = $this->pubmed->getMinorMeshtermPublications($meshterm, $kol_id, $fromYear, $toYear);	
		$meshterm = $this->pubmed->getMeshTermName($meshterm);
		$data['arrPublications']			= $arrPublications;
		$data['filterType']					= 'Publications By Minor Keywords';
		$data['filterValue']				= $meshterm;
		$data['fromYear']					= $fromYear;
		$data['toYear']						= $toYear;
		$koldetails = $this->kol->getKolName($kol_id);
		$data['first_name']		= $koldetails['first_name'];
		$data['middle_name']	= $koldetails['middle_name'];
		$data['last_name']		= $koldetails['last_name'];
		$this->load->view('publications/view_publications_by_parameters',$data);
	} 


	/**
	 * returns the list of publications belongs to perticular kolId,
	 * @return unknown_type
	 * @author Vinayak
	 * @since KOL 1.5
	 * Created-on 22/2/11
	 */
	function list_publications_by_year_range($fromYear,$toYear,$kolId){
		$page				= (int)$this->input->post('page'); // get the requested page 
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$arrPublications	= array();
		$data 				= array();
		$arrPublications	= array();
		if($arrPublicationsResults=$this->pubmed->listPublicationsByYearRange($kolId,$fromYear,$toYear)){			
			foreach($arrPublicationsResults as $arrPublicationsResult){
				//$arrPublication['micro']='<a href=\''.'#'.'\' onClick="viewPubMicroProfile('.$arrPublicationsResult['id'].');"><img class="micro_view_icon" src="\''.base_url().'\'images/user3.png" /></a>';
				$arrPublication['micro']			= '<label onClick="viewPubMicroProfile('.$arrPublicationsResult['id'].');"><img class="micro_view_icon" src="\''.base_url().'\'images/user3.png" /></label>';
				$arrPublication['is_manual']		= $arrPublicationsResult['is_manual'];
				$arrPublication['client_id']		= $arrPublicationsResult['client_id'];
				$arrPublication['id']				= $arrPublicationsResult['id'];
				$arrPublication['pmid']				= '<a href=\''. $arrPublicationsResult['link'].'\' target="_new">'.$arrPublicationsResult['pmid'].'</a>';			
				$arrPublication['journal_name']		= $arrPublicationsResult['journal_name'];
				//$arrPublication['article_title']=$arrPublicationsResult['article_title'];
				if(isset($arrPublicationsResult['pmid']) && $arrPublicationsResult['pmid'] > 0)
//					$arrPublication['article_title']= '<a href=\'http://www.ncbi.nlm.nih.gov/pubmed/'. $arrPublicationsResult['pmid'].'\' target="_new">'.$arrPublicationsResult['article_title'].'</a>';
					$arrPublication['linkForArticle'] = 'pmid';
				else{
					if($arrPublicationsResult['link'] != null && $arrPublicationsResult['link'] != "")
						//$arrPublication['article_title']='<a href=\''.$arrPublicationsResult['link'].'\' target="_new">'.$arrPublicationsResult['article_title'].'</a>';
						$arrPublication['linkForArticle'] = 'link';
				else
						$arrPublication['linkForArticle'] = 'manual';
					//$arrPublication['article_title']= '<a href=\''.base_url().'/pubmeds/view_publication/'.$arrPublicationsResult['id'].'\' target="_new">'.$arrPublicationsResult['article_title'].'</a>';
				}
				$arrPublication['article_title'] = $arrPublicationsResult['article_title'];
				$arrPublication['pmid1'] = $arrPublicationsResult['pmid'];
				$arrPublication['link'] = $arrPublicationsResult['link'];
				$arrPublication['affiliation']		= $arrPublicationsResult['affiliation'];
				$arrPublication['date']				= sql_date_to_app_date($arrPublicationsResult['created_date']);
				//$arrPublication['authors']=$this->get_pub_authors($arrPublication['id']);
				$arrPublication['auth_pos']			= $arrPublicationsResult['auth_pos'];
				//$arrPublication['auth_pos']=$this->pubmed->calculateAuthorShipPosition($arrPublication['id'],$kolId,null);
				//$arrPublication['subject']='';
				$arrPublication['user_id']			= $arrPublicationsResult['user_id'];
				$arrPublication['kp_id']			= $arrPublicationsResult['kp_id'];
				$arrPublications[]					= $arrPublication;
			}
			//pr($arrPublication);
			$count				= sizeof($arrPublications);				
			if( $count >0 ){ 
				$total_pages	= ceil($count/$limit); 
			}else{ 
				$total_pages	= 0; 
			} 
			$data['records']	= $count;
			$data['total']		= $total_pages;
			$data['page']		= $page;				
			$data['rows']		= $arrPublications;  
		}
		//ob_start('ob_gzhandler');
		echo json_encode($data);
	}


	/**
	 * Returns the list of publications belongs to perticular MeshTerm KOl_Id,Time Range,
	 * @return unknown_type
	 * @author Vinayak Malladad
	 * @since 1.4.4
	 * Created-on 22/2/11
	 */
	function view_publications_by_keywords($kol_id, $fromYear,$toYear,$parentId=null,$termId=null, $reportFilters = '',$viewTypeMyKols){
		if($viewTypeMyKols == MY_RECORDS){
			$viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
			if(sizeof($viewMyKols) > 0){
				$viewType = $viewMyKols;
				$viewTypeMyKols = MY_RECORDS;
			}else{
				$viewTypeMyKols = ALL_RECORDS;
			}
		}else{
			$viewTypeMyKols = ALL_RECORDS;
		}
		
		$filters = array();
		$filters = $this->filters_to_array($reportFilters);
//		if($filters['kol_id'][0]!=''){
//			$filters['kol_id'] = $this->getKolIds($filters['kol_id']);
//		}
		$completeTerm = '';
		if($parentId != 0)
			$completeTerm .= $this->pubmed->getMeshTermName($parentId)."/";	
		$completeTerm .= $this->pubmed->getMeshTermName($termId);
		$filters['keyword'] = $this->session->userdata('kolKeyWords');
		$arrMeshTermPublications = $this->pubmed->getMajorMeshtermPublications($parentId,$termId,$kol_id, $fromYear, $toYear, $filters, $viewType);	
		$data['filterType'] 	='Publications by Keywords';
		$data['filterValue']	= $completeTerm;
		$data['fromYear']		= $fromYear;
		$data['toYear']			= $toYear;
		$data['arrPublications']= $arrMeshTermPublications;
		if($kol_id != 0){
		$koldetails = $this->kol->getKolName($kol_id);
			$data['first_name']		= $koldetails['first_name'];
			$data['middle_name']	= $koldetails['middle_name'];
			$data['last_name']		= $koldetails['last_name'];
		}
		$this->load->view('publications/view_publications_by_parameters',$data);
	
	} 
	
	/**
	 * Returns the list of publications belongs to perticular Co-author KOl_Id,Time Range,
	 * @return unknown_type
	 * @author Vinayak Malladad
	 * @since 1.4.4
	 * Created-on 22/2/11
	 */
	function view_publications_by_coauthor($coAuthId,$kol_id, $fromYear,$toYear){
		$coAuthDetails=$this->pubmed->getCoAuthorById($coAuthId);
		$coAuthName=$coAuthDetails['last_name']." ".$coAuthDetails['fore_name'];
		$keyword = $this->session->userdata('kolKeyWords');
		$arrCoAuthPublications = $this->pubmed->getPublicationsByCoauthor($coAuthName,$kol_id, $fromYear,$toYear,$keyword);
		
		//based on the name avilability, construct a proper name, to show in the view page
		if($coAuthDetails['last_name']!='' && $coAuthDetails['fore_name']!='')
			$coAuthName=$coAuthDetails['last_name']." ".$coAuthDetails['fore_name'];
		else if($coAuthDetails['fore_name']=='')
			$coAuthName=$coAuthDetails['last_name']." ".$coAuthDetails['initials'];
		else if($coAuthDetails['last_name']=='')
			$coAuthName=$coAuthDetails['fore_name']." ".$coAuthDetails['initials'];
			
		$data['arrPublications']	= $arrCoAuthPublications;
		$data['filterType']					= 'Publications By Co-author';
		$data['filterValue']				= $coAuthName;
		$data['fromYear']					= $fromYear;
		$data['toYear']						= $toYear;
		$koldetails = $this->kol->getKolName($kol_id);
		$data['first_name']		= $koldetails['first_name'];
		$data['middle_name']	= $koldetails['middle_name'];
		$data['last_name']		= $koldetails['last_name'];
		$this->load->view('publications/view_publications_by_parameters',$data);
	} 

	/**
	 * Returns the Top journals 0f  to perticula KOl_Id,Time Range,
	 * @return unknown_type
	 * @author Vinayak Malladad
	 * @since 1.4.4
	 * Created-on 23/2/11
	 */
	function view_pub_journals_chart($kolId,$fromYear,$toYear){
		
		$keyWord = $this->input->post('keyWord');
		
		$this->session->set_userdata('kolKeyWords',$keyWord);
		$keyWord = $this->session->userdata('kolKeyWords');
		$arrJournals= $this->pubmed->getPubJournalsChart($kolId,$fromYear,$toYear,$keyWord);
		$name		= array();
		$count		= array();
		$arrIds		= array();
		foreach($arrJournals as $row){
			$name[] = $row['name'];
			$count[]= (int)$row['count'];
			$arrIds[]=$row['id'];			
		}
		$data[]=$name;	
		$data[]=$count;
		$data[]=$arrIds;
		echo json_encode($data);
	}
	
	/**
	 * Returns the list of Publication details of Particular Journal Name,KOl_Id,Time Range
	 * @return unknown_type
	 * @author Vinayak Malladad
	 * @since 1.4.4
	 * Created-on 23/2/11
	 */
	function view_publications_by_journals($journalName,$kol_id, $fromYear,$toYear, $reportFilters = '',$viewTypeMyKols){
		if($viewTypeMyKols == MY_RECORDS){
			$viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
			if(sizeof($viewMyKols) > 0){
				$viewType = $viewMyKols;
				$viewTypeMyKols = MY_RECORDS;
			}else{
				$viewTypeMyKols = ALL_RECORDS;
			}
		}else{
			$viewTypeMyKols = ALL_RECORDS;
		}
		$filters = array();
		$filters = $this->filters_to_array($reportFilters);
		if($filters['kol_id'][0]!=''){
			$filters['kol_id'] = $this->getKolIds($filters['kol_id']);
		}
		$filters['keyword'] = $this->session->userdata('kolKeyWords');
		$arrJournalPublications = $this->pubmed->getPublicationsByJournals($journalName,$kol_id, $fromYear,$toYear,$filters,$viewType);
		$journalName = $this->pubmed->getJournalNameById($journalName);
		$data['arrPublications']	= $arrJournalPublications;
		$data['filterType']					= 'Publications By Journals';
		$data['filterValue']				= $journalName;
		$data['fromYear']					= $fromYear;
		$data['toYear']						= $toYear;
		if($kol_id != 0){
			$koldetails = $this->kol->getKolName($kol_id);
			$data['first_name']		= $koldetails['first_name'];
			$data['middle_name']	= $koldetails['middle_name'];
			$data['last_name']		= $koldetails['last_name'];
		}
		$this->load->view('publications/view_publications_by_parameters',$data);
	} 

	/**
	 * Returns the list of Publication details of Particular Authorship position sector
	 *@author 	Ramesh B
	 * @Created on: 03-03-11
	 * @since	1.5
	 * @return 
	 */
	function view_pubs_by_kol_auth_pos($kolId,$start,$end,$pos){
		$keyword = $this->session->userdata('kolKeyWords');
		$arrPubIds=array();
		$arrAuthPubs=array();
		switch($pos){
			case 'sa':$arrAuthPubs=$this->pubmed->getKolPubsWithSingleAuthor($kolId,$start,$end,0,0,0,0,$keyword);
									foreach($arrAuthPubs as $authPub){
											$arrPubIds[]=$authPub['pub_id'];
									}
									break;
			case 'fa':$arrAuthPubs=$this->pubmed->getKolPubsWithFirstAuthorship($kolId,$start,$end,0,0,0,0,$keyword);
									foreach($arrAuthPubs as $authPub){
											$arrPubIds[]=$authPub['pub_id'];
									}
									break;
			case 'ma':$arrAuthPubs=$this->pubmed->getKolPubsWithMiddleAuthorship($kolId,$start,$end,0,0,0,0,$keyword);
									foreach($arrAuthPubs as $authPub){
										if($authPub['auth_pos']!=$authPub['max_pos'])
											$arrPubIds[]=$authPub['pub_id'];
									}
									break;
			case 'la':$arrAuthPubs=$this->pubmed->getKolPubsWithLastAuthorship($kolId,$start,$end,0,0,0,0,$keyword);;
									foreach($arrAuthPubs as $authPub){
										if($authPub['auth_pos']==$authPub['max_pos'] && $authPub['max_pos']!=1)
											$arrPubIds[]=$authPub['pub_id'];
									}
									break;
		}
		$arrPublications=$this->pubmed->getPubsIdsDetails($arrPubIds,$kolId);
		if($pos == 'fa')
			$pos = "First Authorship";
		if($pos == 'sa')
			$pos = "Single Authorship";
		if($pos == 'ma')
			$pos = "Middle Authorship";
		if($pos == 'la')
			$pos = "Last Authorship";
		
		$data['arrPublications']			= $arrPublications;
		$data['filterType']					= 'Publications By Authorship Position';
		$data['filterValue']				= $pos;
		$data['fromYear']					= $start;
		$data['toYear']						= $end;
		$koldetails = $this->kol->getKolName($kolId);
		$data['first_name']		= $koldetails['first_name'];
		$data['middle_name']	= $koldetails['middle_name'];
		$data['last_name']		= $koldetails['last_name'];
		
		$this->load->view('publications/view_publications_by_parameters',$data);
	}

	/**
	 * Deletes the publications, serves the delete from JqGrid, takes post parameters
	 * @return unknown_type
	 * @author Vinayak
	 * @since 1.5.1
	 * @created on 21/3/2011
	 */
	function verified_publications(){
		$selectedRows = $this->input->post('pub_id');
		$kolId	=	$this->input->post('kol_id');
		foreach($selectedRows as $id){
			$kolPublication=array();			
			$kolPublication['is_verified']=1;
			$kolPublication['is_deleted']=0;
			$isDeleted=$this->pubmed->updatePublicationAsVerified($id,$kolPublication);
			$this->update->insertUpdateEntry(KOL_PROFILE_PUBLICATION_VERIFY, $id, MODULE_KOL_PUBLICATION, $kolId);			
		}		
		$isDeleted=true;
		echo json_encode($isDeleted);
	}
	
	/**
	 * Deletes the publications, serves the delete from JqGrid, takes post parameters
	 * @return unknown_type
	 * @author Vinayak
	 * @since 1.5.1
	 * @created on 21/3/2011
	 */
	function un_verified_publications(){
		$selectedRows = $this->input->post('pub_id');
		//pr($selectedRows);
		$kolId	=	$this->input->post('kol_id');
		foreach($selectedRows as $id){
			$kolPublication=array();			
			$kolPublication['is_verified']=0;
			$kolPublication['is_deleted']=0;
			$isDeleted=$this->pubmed->updatePublicationAsVerified($id,$kolPublication);
			$this->update->insertUpdateEntry(KOL_PROFILE_PUBLICATION_UNVERIFY, $id, MODULE_KOL_PUBLICATION, $kolId);
		}		
		$isDeleted=true;
		echo json_encode($isDeleted);
	}
	
	/**
	 * gets the all the kol co-authors and the unprocessed coauthors and send this data to the unporce_co_auth page
	 * @author 	Ramesh B
	 * @since	
	 * @return unknown_type
	 * @created 16-02-11
	 * //TODO Rename the method to 'view_unprocessed_co_authors' by Passing the KOLID
	 */
	function get_unprocessed_co_authors_page($kolId){
		$arrKolName = $this->kol->getKolName($kolId);
		//Get all the co-authors of given kol id.
		$arrCoAuthos=$this->pubmed->getKolCoAuthors($kolId,$arrKolName);
		
		//TODO Change the name of the variables and write the description about their usage
		//To Hold all the Processed co-authors, all the co- authors of kol having alias id
		$arrProcessedCoAuths=array();
		// To hold all the un processed co-authoers, $arrUnProcessedCoAuths=$arrCoAuthos-$arrProcessedCoAuths
		$arrUnProcessedCoAuths=array();
		// To hold all the currently asigned alias authors
		$arrPresentAliasCoAuthos=array();
		//To hold all the possible alias co-authors for un processed co-authors, $arrPossibleAliasCoAuthors=$arrUnProcessedCoAuths+$arrPresentAliasCoAuthos;
		$arrPossibleAliasCoAuthors=array();
		
		
		$arrProcessedCoAuths=$this->pubmed->getKolProcessedCoAuthors($kolId);
		
		//TODO What this loop does, write it
		//Prepare array of unprocessed co-authors, loop trough each kol co-authors, 
		//check is it has a alias id, if not then it is still un processed, i.e all the kol co-authors which are un processed.
		//$arrUnProcessedCoAuths=$arrCoAuthos-$arrProcessedCoAuths
		foreach($arrCoAuthos as $key=>$value){
			if ( !array_key_exists($key, $arrProcessedCoAuths) ){
				//based on the name avilability, construct a proper name
				if($value['last_name']!='' && $value['fore_name']!='')
					$arrUnProcessedCoAuths[ucwords($value['last_name'])." ".$value['fore_name']]=$value;
				else if($value['fore_name']=='')
					$arrUnProcessedCoAuths[ucwords($value['last_name'])." ".$value['initials']]=$value;
				else if($value['last_name']=='')
					$arrUnProcessedCoAuths[ucwords($value['fore_name'])." ".$value['initials']]=$value;
			}
		}
		
		$arrPresentAliasCoAuthos=$this->pubmed->getAliasCoAuthors($kolId);
		
		//TODO What this loop does, write it
		//Prepare array of possible alias co-authors for un processed co-authors
		//$arrPossibleAliasCoAuthors=$arrUnProcessedCoAuths+$arrPresentAliasCoAuthos;
		//taking key as last name and first name in order to sort
		foreach($arrUnProcessedCoAuths as $key => $value){
			//$arrPossibleAliasCoAuthors[$value['last_name']." ".$value['fore_name']]=$value;
			//based on the name avilability, construct a proper name
			if($value['last_name']!='' && $value['fore_name']!='')
				$arrPossibleAliasCoAuthors[ucwords($value['last_name'])." ".$value['fore_name']]=$value;
			else if($value['fore_name']=='')
				$arrPossibleAliasCoAuthors[ucwords($value['last_name'])." ".$value['initials']]=$value;
			else if($value['last_name']=='')
				$arrPossibleAliasCoAuthors[ucwords($value['fore_name'])." ".$value['initials']]=$value;
		}		
		//TODO What this loop does, write it
		foreach($arrPresentAliasCoAuthos as $key=>$value){
			//$arrPossibleAliasCoAuthors[$value['last_name']." ".$value['fore_name']]=$value;
			//based on the name avilability, construct a proper name
			if($value['last_name']!='' && $value['fore_name']!='')
				$arrPossibleAliasCoAuthors[ucwords($value['last_name'])." ".$value['fore_name']]=$value;
			else if($value['fore_name']=='')
				$arrPossibleAliasCoAuthors[ucwords($value['last_name'])." ".$value['initials']]=$value;
			else if($value['last_name']=='')
				$arrPossibleAliasCoAuthors[ucwords($value['fore_name'])." ".$value['initials']]=$value;
		}
		
		/*
		 * TODO Move all the logic of getting the UnProcessed and Alias Co-Authors to 'Model' in 2 different functions.
		 * 		Just with 2 function calls, the data should be returned from the MODEL functions
		 */
		ksort($arrPossibleAliasCoAuthors,SORT_STRING);
		//Filter the unprocessed co authors, find the similar names and exclude the name with no  similar names
		//$arrUnProcessedCoAuths=$this->pubmed->filterUnprocessedCoAuthors($arrUnProcessedCoAuths);
		//$arrUnProcessedCoAuths=$this->pubmed->filterUnprocessedCoAuthors($arrUnProcessedCoAuths,$arrPossibleAliasCoAuthors);
		ksort($arrUnProcessedCoAuths);
		$data['arrUnProcessedCoAuths']=$arrUnProcessedCoAuths;
		$data['arrAliasCoAuthos']=$arrPossibleAliasCoAuthors;
		$this->load->view('publications/unprocessed_co_auths',$data);
	}
	
	/**
	 * prepare data required to show the kol processed coAuthors
	 * @author 	Ramesh B
	 * @since	2.0
	 * @return unknown_type
	 * @created 07-04-11
	 * //TODO Change the function to 'view_processed_co_authors' and pass the KOL ID.
	 */
	function get_processed_co_authors_page($kolId){
		$arrKolProcessedCoAuths=$this->pubmed->getKolProcessedCoAuthors($kolId);
		$data['arrKolProcessedCoAuths']=$arrKolProcessedCoAuths;
		$this->load->view('publications/processed_co_auths',$data);
	}

	
	/**
	 * Gets co Authors ids and alias id and associates them and returns true or false
	 * @author 	Ramesh B
	 * @since	2.0
	 * @return Json
	 * @created 08-04-11
	 */
	function associate_co_authors($kolId){
		/**
		 * TODO Write the brief description about what happens, in single line.
		 * 		Move the logic to MODEL in seperate function. Just need to pass IDs and get the TRUE/FALSE
		 */
		//$arrCoAuthsIds are the id's of co authors which are needs to be replaced(associated to) by the co auther name of $aliasId
		//With each $arrCoAuthsIds, there will be as many co author entries as the number of publications co-authered with the same name, we have to get the authoer id's of those entries also
		//these id's will be stored in the '$matchingAuths' array, for all these co auther we have to update it's alias as $aliasId
		$arrCoAuthsIds	=$this->input->post('co_auths_ids');
		$aliasId		=$this->input->post('alias_id');
		
		$coAuthorDetails=$this->pubmed->getCoAuthorById($aliasId);
		$matchingAuths=$this->pubmed->getMatchingCoAuthors($arrCoAuthsIds,$kolId);
		$aliasDeails['alias_id']=$coAuthorDetails['id'];
		$aliasDeails['alias_last_name']=$coAuthorDetails['last_name'];
		$aliasDeails['alias_initials']=$coAuthorDetails['initials'];
		$aliasDeails['alias_fore_name']=$coAuthorDetails['fore_name'];
		//foreach($arrCoAuthsIds as $authId)
			//$matchingAuths[$authId]=$authId;
		$matchingAuths=array_keys($matchingAuths);
		$isProcessed=$this->pubmed->associateCoAuthors($matchingAuths,$aliasDeails);
		echo $isProcessed;
	}
	
	/**
	 * Gets co Author id and disassociate it with other co author by setting all the alias details as null
	 * @author 	Ramesh B
	 * @since	2.0
	 * @return Json
	 * @created 08-04-11
	 */
	function disassociate_co_author($kolId){
		$authorId[]		=$this->input->post('co_author_id');
		$matchingAuths=$this->pubmed->getMatchingCoAuthors($authorId,$kolId);
		$matchingAuths=array_keys($matchingAuths);
		//Disassociatein is same as associating the co auther with null values
		$aliasDeails['alias_id']=null;
		$aliasDeails['alias_last_name']=null;
		$aliasDeails['alias_initials']=null;
		$aliasDeails['alias_fore_name']=null;
		$isProcessed=$this->pubmed->disassociateCoAuthors($matchingAuths,$aliasDeails);
		echo $isProcessed;
	}	
	
	/**
	 * Display the page to Add Publications manually
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 * 
	 * @return unknown_type
	 */
	function add_publication($kolId){
		$arrPublicationDetails = array(	'id'                =>	'',
										'journal_name'		=>	'',
										'article_title'		=>	'',
										'created_date'	 	=> 	'',
										'abstract_text'		=> 	'',
										'link'	 			=> 	'');
		$manualAuthor['last_name']='';
		$manualAuthor['fore_name']='';
		$manualAuthor['initials']='';
		$manualAuthor['id'] = '';
		$arrPublicationDetails['no_of_authors'] = 1;
		
		$data['publication']=$arrPublicationDetails;
		$data['arrAuthors']=$manualAuthor;
		$data['kolId'] = $kolId;
		//Add Log activity
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited Add Publications Page",
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
				'kols_or_org_id' => $kolId,
				'transaction_name' => "View Add Publications"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		$this->load->view('publications/add_publications',$data);
	}
	
	/**
	 * Display the page to Add Publications manually
	 * @author Ambarish
	 * @since 2.2
	 * @Created-on 05-May-11
	 * 
	 * @return unknown_type
	 */
	function add_client_publication($kolId){
		$arrPublicationDetails = array(	'id'                =>	'',
										'journal_name'		=>	'',
										'article_title'		=>	'',
										'created_date'	 	=> 	'',
										'abstract_text'		=> 	'',
										'link'	 			=> 	'');
		$manualAuthor['last_name']='';
		$manualAuthor['fore_name']='';
		$manualAuthor['initials']='';
		$manualAuthor['id'] = '';
		$arrPublicationDetails['no_of_authors'] = 1;
		
		$data['publication']=$arrPublicationDetails;
		$data['arrAuthors']=$manualAuthor;
		$data['kolId'] = $kolId;
		$arrLogDetails = array(
				'type' => VIEW_RECORD,
				'description' => "Visited ".lang('HCP')."Add Publication Page",
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
				'kols_or_org_id' => $kolId,
				'transaction_name' => "View ".lang('HCP')."Add Publication Page"
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null,true);
		$this->load->view('publications/add_publications',$data);
	}
	
	
	
	/**
	 * Saves the Manual Publication Detail to DB 
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 * 
	 * @return unknown_type
	 */
	function save_publication_manual($ipad=0){
		$arrLastName  =	$this->input->post('last_name');
		$arrForeName  =	$this->input->post('fore_name');
		$arrInitials  =	$this->input->post('initials');
		$dataType = 'User Added';
		$client_id =$this->session->userdata('client_id');
		if($client_id == INTERNAL_CLIENT_ID){
		    $dataType = 'Aissel Analyst';
		}
		// Getting the POST details of Publication
		$arrPublicationDetails = array(	
										'article_title'		=>	ucwords(trim($this->input->post('article_title'))),
										'created_date'	 	=> 	app_date_to_sql_date($this->input->post('created_date')),
										'abstract_text'		=> 	ucwords(trim($this->input->post('abstract_text'))),
										'link'	 			=> 	$this->input->post('link'));
		
		//Save journal name
		$journalName = ucwords(trim($this->input->post('journal_name')));
		if($journalName != ''){
			$arrPublicationDetails['journal_id'] = 	$this->pubmed->savejournalName($journalName);
		}
		
		$kolId			=	$this->input->post('kol_id');	
		//Generate Pmid manually 
		$arrPublicationDetails['pmid']= $this->pubmed->getManualPmid();
		$arrPublicationDetails['is_manual']= 1;
		$arrPublicationDetails['data_type_indicator']= $dataType;
		//Save Publication data
		$pubId=$this->pubmed->savePublicationsManualAndFlags($arrPublicationDetails , $kolId);
		//$this->update->insertUpdateEntry(KOL_PROFILE_PUBLICATION_ADD,$pubId, MODULE_KOL_PUBLICATION, $kolId);
		$arrLogDetails = array(
		        'controller' => 'kols',
				'type' => ADD_RECORD,
		        'description' => 'New Publications',
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
				'kols_or_org_id' => $kolId,
		        'transaction_id' => $pubId,
		        'transaction_table_id' => KOL_PUBLICATIONS,
		        'transaction_name' => 'New Publications',
		        'form_data' => json_encode($arrPublicationDetails),
		        'parent_object_id' => $kolId,
		);		
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null, true);
		
		$isSaved = false;
		if($pubId){
			$isSaved  = true;
		}
		/*
		//For Authors
		$lastName  =	ucwords(trim($this->input->post('last_name')));
		$foreName  =	ucwords(trim($this->input->post('fore_name')));
		$initials  =	ucwords(trim($this->input->post('initials')));
		*/
		
		//parse and save 'publication-authors'
		$firstAuthor = array();
		if($arrLastName[0] != '' || $arrForeName[0] !='' || $arrInitials[0] !=''){
			$firstAuthor = $this->parse_authors_manually($arrLastName[0],$arrForeName[0],$arrInitials[0]);
		}
		$arrAuthors = array();
		$secondAuthors = array();
		$arrSecondAuthors = array();
		//$i=2;
		$noOfAuthors=sizeof($arrLastName);
		for($i=1;$i<=$noOfAuthors;$i++){
			$lastName  =	$arrLastName[$i];
			$foreName  =	$arrForeName[$i];
			$initials  =	$arrInitials[$i];
			
			//parse and save 'publication-authors'
			if($lastName != '' || $foreName !='' || $initials !=''){
				$secondAuthors = $this->parse_authors_manually($lastName,$foreName,$initials);
				$arrSecondAuthors[] = $secondAuthors;
			}
		}
		foreach ($firstAuthor as $author){
			$arrAuthors[] = $author;
		}
		foreach ($arrSecondAuthors as $arrSecondAuthor){
			foreach ($arrSecondAuthor as $author){
				$arrAuthors[] = $author;
			}
		}
		//Save array of Authors
		if(sizeof($arrAuthors)>=1){
			$this->save_pub_authors($arrAuthors, $pubId);
		}
		//Calculate Authorship position and save
		$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,null);
		$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
		
		// Create an array to return the result
		$arrResult = array();
		
		if($isSaved){
			$arrResult['saved']			= true;
			$arrResult['lastInsertId']	= $pubId;
			$arrResult['msg']			= "Successfully saved the Publication details";
		}else{
			$arrResult['saved']			= false;
			$arrResult['msg']			= "Sorry! Error in Saving";
		}
		
		//	echo json_encode($arrResult);
		$currentMethod	= $this->input->post('methodName');
		$kolId = $this->kol->getUniqueIdByKolId($kolId);
	     if($currentMethod == 'add_client_publication'){
			//For client appplication
			//redirect('kols/view_publications/'.$this->session->userdata('kolId'));
			if($ipad){
			  $data['kolId']=$kolId;
			  $data['status']='success';
			  echo json_encode($data);
			}else{
		      redirect('kols/view_publications/'.$kolId);
			}
		}else{
			//For analyst appplication
			//Ajax Saving is Done But Listing is not hapening automatically
			//Currently Redircting to Ajax tab 
			//redirect('kols/edit_kol/'.$this->session->userdata('kolId').'#ui-tabs-5');
			$isClientView = false;
			if($ipad){
			    $data['kolId']=$kolId;
			    $data['status']='success';
			    echo json_encode($data);
			}else{
			    redirect('pubmeds/view_publications/'.$kolId);
			}
		}
		
	}
	
	/**
	 * Updates the Manual Publication Detail to DB 
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 * 
	 * @return unknown_type
	 */
	function update_publication_manual(){
		
// 		pr($_POST);exit;
		$arrAuthId  =	$this->input->post('authId');
		$arrLastName  =	$this->input->post('last_name');
		$arrForeName  =	$this->input->post('fore_name');
		$arrInitials  =	$this->input->post('initials');
		// Getting the POST details of Publication
		$arrPublicationDetails = array(	'id'                =>	$this->input->post('id'),
										'article_title'		=>	ucwords(trim($this->input->post('article_title'))),
										'created_date'	 	=> 	app_date_to_sql_date($this->input->post('created_date')),
										'abstract_text'		=> 	ucwords(trim($this->input->post('abstract_text'))),
										'link'	 			=> 	$this->input->post('link'));
			
		// Create an array to return the result
		$arrResult = array();
		$kolId			=	$this->input->post('kol_id');	
		$pubId = $arrPublicationDetails['id'];
		$isSaved=$this->pubmed->updatePublicationManual($arrPublicationDetails);
		//$this->update->insertUpdateEntry(KOL_PROFILE_PUBLICATION_UPDATE, $arrPublicationDetails['id'], MODULE_KOL_PUBLICATION, $kolId);
		$arrLogDetails = array(
		        'controller' => 'kols',
				'type' => EDIT_RECORD,
				'description' => 'Update Publications',
				'status' => STATUS_SUCCESS,
				'kols_or_org_type' => 'Kol',
				'kols_or_org_id' => $kolId,
				'transaction_id' => $pubId,
				'transaction_table_id' => KOL_PUBLICATIONS,
				'transaction_name' => 'Update Publications',
				'form_data' => json_encode($arrPublicationDetails),
				'parent_object_id' => $kolId,
		);
		$this->config->set_item('log_details', $arrLogDetails);
		log_user_activity(null, true);
		//Get journal name
		$arrPublicationDetails['journal_name'] = ucwords(trim($this->input->post('journal_name')));
		//get Author name
		$arrPublicationDetails['last_name']  =	$arrLastName[0];
		$arrPublicationDetails['fore_name']  =	$arrForeName[0];
		$arrPublicationDetails['initials']   =	$arrInitials[0];
		$arrPublicationDetails['authId']	 = 	$arrAuthId[0];
		
		//update journal 
		$isSaved = 	$this->pubmed->updatePublicationJournalManual($arrPublicationDetails);
		
		//update Authors
		/* if($arrPublicationDetails['authId'] !=''){
			$isSaved = 	$this->pubmed->updatePublicationAuthorsManual($arrPublicationDetails);
		} */
		//$i=1;
		$noOfAuthors=$this->input->post('no_of_authors');
		$beforenoOfAuthors=$this->input->post('before_no_of_authors');
		
		//echo $noOfAuthors;exit;
		
// 		$noOfAuthors=sizeof($arrLastName)-1;
		$this->db->delete("publications_authors",array("pub_id"=>$pubId));
		$position = 1;
		for($i=0;$i<=$noOfAuthors;$i++){
			$lastName  =	$arrLastName[$i];
			$foreName  =	$arrForeName[$i];
			$initials  =	$arrInitials[$i];
			
		    //parse and save 'publication-authors'
			$arrSecondAuthors = array();
		    if($lastName != '' || $foreName !='' || $initials !=''){
		        $secondAuthors = $this->parse_authors_manually($lastName,$foreName,$initials);
		        $arrSecondAuthors[] = $secondAuthors;
		    }	
// 		    pr($arrSecondAuthors);
		    $arrAuthors = array();
		    foreach ($arrSecondAuthors as $arrSecondAuthor){
		    	foreach ($arrSecondAuthor as $author){
		    		$arrAuthors[] = $author;
		    	}
		    }
// 		    pr($arrAuthors);
		    //Save array of Authors
		    if(sizeof($arrAuthors)>=1){
		    	$this->update_pub_authors($arrAuthors, $pubId, '',$position);
		    }
		    $position++;
		    //exit;
		}
		//exit;
	
		//pr($arrAuthors);exit;
		//Calculate Authorship position and save
		$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,null);
		$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
		//pr($this->db->last_query());
		// Create an array to return the result
		$arrResult = array();
		
		if($isSaved){
			$arrResult['saved']			= true;
			$arrResult['lastInsertId']	= $arrPublicationDetails['id'];
			$arrResult['msg']			= "Successfully Updated the Publication details";
		}else{
			$arrResult['saved']			= false;
			$arrResult['msg']			= "Sorry! Error in Updating";
		}
		//echo json_encode($arrResult);
		$isClientView = false;
		//redirect('pubmeds/view_publications/'.$kolId);
		$kolId = $this->kol->getUniqueIdByKolId($kolId);
		redirect('kols/view_publications/'.$kolId);
	}
	
	/**
	 * Populates the $pubId Data to the Manual form
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 * 
	 * @param unknown_type $pubId
	 * @return unknown_type
	 */
	function edit_publication_manual($pubId,$kolId){
		$data['kolId'] = $kolId;
	
		$publication=$this->pubmed->getPublicationDetail($pubId);
		
		$publication['journal_name']=$this->pubmed->getJournalNameById($publication['journal_id']);
		$publication['created_date']=sql_date_to_app_date($publication['created_date']);
		$arrAuthors =$this->pubmed->listPublicationAuthors($pubId);
		$manualAuthor = array();
		$manualAuthor['last_name']='';
		$manualAuthor['fore_name']='';
		$manualAuthor['initials']='';
		$manualAuthor['id']='';
		$i=0;
		foreach ($arrAuthors as $author){
			$i++;
			if($i == 2)
				break;
			$manualAuthor = $author;
		}
		$publication['no_of_authors'] = (sizeof($arrAuthors) !=0) ? sizeof($arrAuthors):1;
		$data['publication']=$publication;
		$data['arrAuthors']=$manualAuthor;
		$data['arrMultipleAuthors']=$arrAuthors;
		$this->load->view('publications/add_publications',$data);
	}
	
	/**
	 * Parse the Manual Entry Authors data and returns an Array
	 * @author Ambarish
	 * @since 2.0
	 * @Created-on 07-04-11
	 *	
	 * @param $lastName
	 * @param $foreName
	 * @param $initials
	 * @return unknown_type
	 */
	function parse_authors_manually($lastName,$foreName,$initials){
		$arrAuthors = array();
		$author 	= array();
		
		$author['last_name']= ($lastName != '') ? $lastName:$lastName;
		$author['fore_name']= ($foreName != '') ? $foreName:$foreName;
		$author['initials']	= ($initials != '') ? $initials:$initials;
		$author['suffix']	= 'Not Available';
		$author['is_name_valid']	= 0;
		$arrAuthors[]=$author;	
		
		return $arrAuthors;
	}
	
	/**
	 * Deletes all the publications and there related data of all the given kol id's
	 * @author 	Ramesh B
	 * @since	
	 * @return unknown_type
	 * @created 16-02-11
	 */
	function delete_kols_all_publications(){
		$arrKolIds=array(256,257,258,259);
		foreach($arrKolIds as $kolId){
			$this->pubmed->deleteKolPublications($kolId);
		}
	}
	
	function delete_duplicate_publications(){
		$this->pubmed->deleteDuplicatePublications();
	}

	/**
	 * Search the Publication By passed parameteres
	 * @author 	Vinayak 
	 * @since	3.7
	 * @return unknown_type
	 * @created 3-5-12
	 */
	function search_publicatios_by_parameters($kolId){
		$page			= (int)$this->input->post('page'); // get the requested page 
		$limit			= (int)$this->input->post('rows'); // get how many rows we want to have into the grid     	
		$substance		= $this->input->post('substances');
		$author			= $this->input->post('author');
		$meshTerm		= $this->input->post('meshTerm');
		$keyWord		= $this->input->post('keywords');
		$articleName	= $this->input->post('article');
		$fromYear		= $this->input->post('fromYear');
		$toYear			= $this->input->post('toYear');
		
		//$this->session->sess_destroy();
	
			$this->session->set_userdata('kolKeyWords',$keyWord);
		
		$keyWord = $this->session->userdata('kolKeyWords');
		$arrResult		= $this->pubmed->searchPublicationsByParameters($substance,$author,$meshTerm,$keyWord,$articleName,$kolId,$fromYear,$toYear);
		$arrPublications= array();
		foreach($arrResult as $arrPublicationsResult){
			//$arrPublication['micro']='<a href=\''.'#'.'\' onClick="viewPubMicroProfile('.$arrPublicationsResult['id'].');"><img class="micro_view_icon" src="\''.base_url().'\'images/user3.png" /></a>';
			$arrPublication['micro']		= '<label onClick="viewPubMicroProfile('.$arrPublicationsResult['id'].');"><img class="micro_view_icon" src="'.base_url().'images/user3.png" /></label>';
			$arrPublication['is_manual']	= $arrPublicationsResult['is_manual'];
			$arrPublication['id']			= $arrPublicationsResult['id'];
			$arrPublication['kol_pub_id']			= $arrPublicationsResult['kol_pub_id'];
			$arrPublication['kol_id']			= $arrPublicationsResult['kol_id'];
			//$arrPublication['pmid']='<a href=\''. $arrPublicationsResult['link'].'\' target="_new">'.$arrPublicationsResult['pmid'].'</a>';			
			$arrPublication['journal_name']	= $arrPublicationsResult['journal_name'];
			//$arrPublication['article_title']=$arrPublicationsResult['article_title'];
			//$arrPublication['article_title']='<a href=\''. $arrPublicationsResult['link'].'\' target="_new">'.$arrPublicationsResult['article_title'].'</a>';
			if(isset($arrPublicationsResult['pmid']) && $arrPublicationsResult['pmid'] > 0){
//				$arrPublication['article_title']= '<a href=\'http://www.ncbi.nlm.nih.gov/pubmed/'. $arrPublicationsResult['pmid'].'\' target="_new">'.$arrPublicationsResult['article_title'].'</a>';
				$arrPublication['linkForArticle'] = 'pmid';
			}else{
//				$arrPublication['article_title']= '<a href=\''.base_url().'/pubmeds/view_publication/'.$arrPublicationsResult['id'].'\' target="_new">'.$arrPublicationsResult['article_title'].'</a>';
				$arrPublication['linkForArticle'] = 'link';
			}
			$arrPublication['article_title'] = $arrPublicationsResult['article_title'];
			$arrPublication['pmid1'] = $arrPublicationsResult['pmid'];
			$arrPublication['link'] = $arrPublicationsResult['link'];	 
			$arrPublication['affiliation']	= $arrPublicationsResult['affiliation'];
			$arrPublication['date']			= sql_date_to_app_date($arrPublicationsResult['created_date']);
			//$arrPublication['authors']=$this->get_pub_authors($arrPublication['id']);
			$arrPublication['auth_pos']		= $arrPublicationsResult['auth_pos'];
			
			//$arrPublication['auth_pos']=$this->pubmed->calculateAuthorShipPosition($arrPublication['id'],$kolId,null);
			//$arrPublication['subject']='';
			$arrPublication['client_id']=$arrPublicationsResult['client_id'];
			$arrPublication['user_id']=$arrPublicationsResult['user_id'];
			$arrPublication['is_analyst']=$arrPublicationsResult['is_analyst'];
			$arrPublication['first_name']=$arrPublicationsResult['first_name'];
			$arrPublication['last_name']=$arrPublicationsResult['last_name'];
			$arrPublication['data_type_indicator'] = $arrPublicationsResult['data_type_indicator'];
			$arrPublication['eAllowed'] =  $this->common_helpers->isActionAllowed('kol_details', 'edit', $arrPublication);
			$arrPublications[]				= $arrPublication;
		}
		$count=sizeof($arrPublications);				
			if( $count >0 ){ 
				$total_pages = ceil($count/$limit); 
			}else{ 
				$total_pages = 0; 
			} 
			$data['records'] = $count;
			$data['total']   = $total_pages;
			$data['page']    = $page;				
			$data['rows']    = $arrPublications; 
		echo json_encode($data);
	}
	
	/*
	 * Update the PubMed authors table by fetching data from original journal
	 * whose author position is '0' or publication has only one author
	 * @author Laxman K
	 * @since 3.5.2
	 * @param 	$updateFor = 1 indicates get pub ids whose author count is 1 i.e only one author
	 * 			$updateFor = 0 indicates get pub ids whose author position is zero 
	 *  @param 	$is_verfied = 1 indicates get pub ids whose author position is zero and publication is verfied
	 * 			$is_verfied = 0 indicates get pub ids whose author position is zero and publication is not verfied
	 */
	function update_pubmed_author_position_by_crawling($updateFor=1, $is_verfied=1){
		//$this->pmidBatchSize = 20;
		date_default_timezone_set('Asia/Calcutta');
		ini_set("max_execution_time",$this->maxScriptTime);
		$this->logFilePath	= $_SERVER['DOCUMENT_ROOT'].'/'.$this->logFilePath.'/assoc_authors';
		$this->startTime	= microtime(true);
		$this->logText		= "Processing Started on: " . date("d-m-Y H:i:s") . "\r\n";
		$skippedTitle		= "File contains information of skipped Authors who is single author for that particular Publication \r\n";
		$processedTitle		= "File contains information of Processed publications and Authors \r\n";
		
		// Open the LogFile to write		
		$this->lastProcessedPubFileName	= $this->logFilePath . "/" . "last_Pub_Processed_logfile.txt";
		$this->logFileName				= $this->logFilePath . "/" . "pubmed_skipped_logfile_".date("d-m-Y")."_". $this->startTime . ".txt";
		$this->logFileNamePUBprocessed	= $this->logFilePath . "/" . "pubmed_processed_logfile_".date("d-m-Y")."_". $this->startTime . ".txt";
		$this->logFile					= fopen($this->logFileName, "w");
		$this->logFilePUBprocessed		= fopen($this->logFileNamePUBprocessed, "w");
		
		$this->logFilelastProcessedPub	= fopen($this->lastProcessedPubFileName, "r");
		$contents = fread($this->logFilelastProcessedPub, 100);
		$startFromPublicationId	= str_replace('PUB ID = ','',$contents);
		if(empty($startFromPublicationId) || $startFromPublicationId=='' || sizeof($startFromPublicationId)==0){
			$startFromPublicationId = '1';
		}
	}
	
	/**
	 * Chamges the kol pubmed processing status to given status
	 * @author 	Ramesh B 
	 * @since	4.2
	 * @return text
	 * @created 15-06-2012
	 */
	function chnage_kol_pubmed_status(){
		$kolId = $this->input->post('id');
		$status = $this->input->post('pubmed_processed');
		$isUpdated = $this->pubmed->changeKolPubmedStatus($kolId, $status);
		if($isUpdated)
			echo "true";
		else
			echo "false";
	}

	function view_auth_affiliation($kolId,$authId){
		$affiliationText = '';
		$affiliationData = $this->pubmed->getCoAuthorAffiliationData($kolId, $authId);
		$affiliationText = '<label><b>'.$affiliationData['last_name'].' '.$affiliationData['initials'].'</b></label><br>';
		$arrAffiliationData = explode(",",$affiliationData['affiliation']);
		foreach ($arrAffiliationData as $text)
			$affiliationText .=$text."<br>";
		echo $affiliationText;
	}
	
	
	function re_crawl_mesh_terms($lastPubIdProcessed = null){
		ini_set("max_execution_time",$this->maxScriptTime);
		$this->startTime	= microtime(true);		
		//Get all the publications ids with there reapecrive PMID
		$arrResultData = $this->pubmed->getAllPublicationIdsWithPMID($lastPubIdProcessed);
		//pr($arrResultData);
		$arrPMIDs = $arrResultData['arrPMIDs'];
		$arrPubIdsWithPMID = $arrResultData['arrPubIdsWithPMID'];
		
		$lastPubIdProcessed = '';
		//Loop trough publication ids and crawl publication data, extract meshterms and store in to database
		for($i=0; $i<sizeof($arrPMIDs);$i=$i+10){
			$authListText='';
			for($j=$i; $j<$i+$this->pmidBatchSize; $j++){
				if( $arrPMIDs[$j]!=''){
				$authListText=$authListText."".$arrPMIDs[$j];
				if($j!=$i+9 )
					$authListText=$authListText.",";
				}else{
					$lastPubIdProcessed = $arrPubIdsWithPMID[$arrPMIDs[$i-10]];
				}
			}				
			$pubFetchStartTime=microtime(true);				
			$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$authListText;
			if($authListText!='')
				$content = $this ->retrieve_page_get($url);	
			if(!$content['response'])	return false;
			$timeTaken=microtime(true)-$pubFetchStartTime;		
			$xml = new DOMDocument();
			if(!$xml->loadXML($content['response'])){
				//continue;
				die("Sorry! Couldnot process, check the log for details, Last Publication Id Processed: ".$lastPubIdProcessed." <a href='".base_url()."/pubmeds/re_crawl_mesh_terms/".$lastPubIdProcessed."'>restart process</a>");										
			}

			//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
			$publications = $xml->getElementsByTagName('PubmedArticle');				
			foreach($publications as $publication){
				$timeElapsed = (microtime(true) - $this->startTime);
				$remTime	=$this->maxScriptTime-$timeElapsed;
				//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
				if($remTime<$this->safeTime){
					die("Sorry! Stopping the pubmed processing, Timelimit reached, ,Last Publication Id Processed: ".$lastPubIdProcessed." <a href='".base_url()."/pubmeds/re_crawl_mesh_terms/".$lastPubIdProcessed."'>restart process</a>");									
				}					
				$pubStartTime=microtime(true);	
				
				$pubDetails=$this->parse_pub_details($publication);	
				$pubId = $arrPubIdsWithPMID[$pubDetails['pmid']];
				
				//parse and save MeshTerms
				$arrMeshTerms=$this->parse_pub_meshterms($publication);
				$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
				
				$timeTaken=microtime(true)-$pubStartTime;
				echo "Last Publication Id Processed: ".$pubId." <a href='".base_url()."/pubmeds/re_crawl_mesh_terms/".$pubId."'>restart process</a><br>";
			}
			sleep($this->sleepTime);
		}
		
		echo "Processing completed...";
		
	} 
	
	/**
	 * 
	 * @author 	Ramesh B 
	 * @since	1.0.4
	 * @return 
	 * @created 08 Nov 2012
	 */
	function filters_to_array($reportFilters){
		$filters = array();
		if($reportFilters != ''){
			$reportFiltersElements = explode(':',$reportFilters);
			foreach ($reportFiltersElements as $filterElement){
				$filterElements = explode('=',$filterElement);
				$filterName = $filterElements[0];
				$filterValues = array();
				if($filterElements[1] != ''){
					$arrFilterValues = explode(',',$filterElements[1]);
					$filterValues = $arrFilterValues;
				}
				if(sizeof($filterValues) > 0)
					$filters[$filterName] = $filterValues;
			}
		}
		return $filters;
	}
	
	function getKolIds($kolNames){
		
		$kolIds = array();
		
		foreach($kolNames as $key=>$kolname){
			$kolIds[] = $this->kol->getKolId($kolname);
		}
		return $kolIds;
	}
	
	function update_kol_pubmed_status(){
		$status = $this->input->post('status');
		$arrKolIds = $this->input->post('kolId');
		
		foreach($arrKolIds as $kolId){
			$isUpdated = $this->pubmed->changeKolPubmedStatus($kolId, $status);			
		}
		
		if($isUpdated)
			echo "true";
		else
			echo "false";
	}
	
	function processPubmedRecrawlKols(){
		ini_set("max_execution_time",$this->maxScriptTime);
		//Get all the KOLs having the pubmed status 'Recrawl'
		$arrKols = $this->pubmed->getPubmedRecrawlKols();
		
		//Loop trough each KOL
		foreach($arrKols as $arrKolDetail){
			$kolId = $arrKolDetail['id'];
			$this->logText	= "\r\nStarting pubmed processing for KolId ".$kolId." \r\n";
			fwrite($this->logFile, $this->logText);	
			
			//Get the PMIDs for this KOL
			$arrPMIDs = $this->pubmed->getPMIDs($kolId);
			$this->logText	= "Total No of PMIDs found: ".sizeof($arrPMIDs)." \r\n";
			fwrite($this->logFile, $this->logText);	
			
			//Check for already existing publication's and associate them with kol
			$arrFilteredPMIDs=$this->pubmed->checkAndAssociateAlreadyExistPubs($arrPMIDs, $kolId,$arrKolDetail,1);
			$this->logText	= "Total No of PMIDs found after removing already existing publication's in database: ".sizeof($arrFilteredPMIDs)." \r\n";
			fwrite($this->logFile, $this->logText);							
			//End of checking and associating already existing publications
			
			//Get the Publication details for all the PubMEd ID's, 10 at a time	
			$this->logText	= "\r\nStart of getting the Publication details for each PMID, Processing ".$this->pmidBatchSize." at a time \r\n";
			fwrite($this->logFile, $this->logText);			
			for($i=0; $i<sizeof($arrFilteredPMIDs);$i=$i+10){
			//for($i=0; $i<20;$i=$i+$this->pmidBatchSize){
				$authListText='';
				$arrAuthList = array();
				for($j=$i; $j<$i+$this->pmidBatchSize; $j++){
					if( $arrFilteredPMIDs[$j]!='')
						$arrAuthList[] = $arrFilteredPMIDs[$j];
				}
				$authListText = implode(",",$arrAuthList);
								
				$pubFetchStartTime=microtime(true);				
				$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$authListText;
				$this->logText	= "Url generated: ".$url."\r\n";
				fwrite($this->logFile, $this->logText);	
				if($authListText!='')
					$response = $this ->retrieve_page_get($url);
				//Try once again if the response of the status is false	
				if($response['status'] == false){
					//give 2 second delay
					sleep($this->sleepTime);
					$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
					fwrite($this->logFile, $this->logText);
					//try once again
					$response = $this ->retrieve_page_get($url);
				}
				// Skipp this and log the details if still respons is false
				if($response['status'] == false){
					//log the details
					$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
					fwrite($this->logFile, $this->logText);
					
					$this->logText = "Recrawl : KolId Id - ".$kolId."  : Pmids : ".$authListText."\r\n";
					fwrite($this->logFilePmidSkipped, $this->logText);
					//continue to next step
					continue;
				}
				
				$timeTaken=microtime(true)-$pubFetchStartTime;		
				$this->logText	= "Time taken to fetch ".$this->pmidBatchSize." publications : ".$timeTaken."\r\n";
				fwrite($this->logFile, $this->logText);	
				$xml = new DOMDocument();
				
				if(!$xml->loadXML($response['response'])){
					$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
					fwrite($this->logFile, $this->logText);	
					
					$response = $this ->retrieve_page_get($url);
					//Try once again if the response of the status is false	
					if($response['status'] == false){
						//give 2 second delay
						sleep($this->sleepTime);
						$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
						fwrite($this->logFile, $this->logText);
						//try once again
						$response = $this ->retrieve_page_get($url);
					}
					// Skipp this and log the details if still respons is false
					if($response['status'] == false){
						//log the details
						$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						fwrite($this->logFile, $this->logText);
						
						$this->logText = "Recrawl : KolId Id - ".$kolId."  : Pmids : ".$authListText."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						//continue to next step
						continue;
					}
					
					if(!$xml->loadXML($response['response'])){
						//log the details and continue
						$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next set of pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
						fwrite($this->logFile, $this->logText);	
						
						$this->logText = "Recrawl : KolId Id - ".$kolId."  : Pmids : ".$authListText."\r\n";
						fwrite($this->logFilePmidSkipped, $this->logText);
						continue;
						//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
					}										
				}

				//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
				$this->logText	= "Following Publications with PMID's are parsed and saved sucessfully\r\n ";
				fwrite($this->logFile, $this->logText);
				$publications = $xml->getElementsByTagName('PubmedArticle');				
				foreach($publications as $publication){
					$timeElapsed = (microtime(true) - $this->startTime);
					$remTime	=$this->maxScriptTime-$timeElapsed;
					//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
					if($remTime<$this->safeTime){
						$this->logText	= "Stopping the pubmed processing, Timelimit reached.\r\n ";
						fwrite($this->logFile, $this->logText);	
						$this->send_status_mail($this->logText);
						//die("Sorry! Stopping the pubmed processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);
						//redirect(base_url()."pubmeds_org/process_pubmeds");										
					}					
					$pubStartTime=microtime(true);	
					//parse and save publication details
					$pubDetails=$this->parse_pub_details($publication);	
					$pubId=$this->save_publications($pubDetails, $kolId, 1);
					if($pubId!=null){
						//$this->logText	= "Publication with PMID:".$pubDetails['pmid']." parsed and saved sucessfully\r\n ";
						//fwrite($this->logFile, $this->logText);	
					}else{
						$this->logText	= "Error in parsing and saving the Publication with PMID:".$pubDetails['pmid']." \r\n ";
						fwrite($this->logFile, $this->logText);
						continue;
					}
					//log the last PMID parsed
					file_put_contents($this->logLastPmidFile,$pubDetails['pmid']);
					
					//parse and save 'publication-authors'
					$arrAuthors=$this->parse_pub_authors($publication);
					$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
					
					//Calculate Authorship position and save
					$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail);
					$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
					
					//parse and save MeshTerms
					$arrMeshTerms=$this->parse_pub_meshterms($publication);
					$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
					
					//parse and save 'Substances(chemicals)'
					$arrSubstances=$this->parse_pub_substances($publication);
					$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
					
					//parse and save 'Publication types'
					$arrPubTypes=$this->parse_pub_types($publication);
					$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
					
					//parse and save 'CommentsCorrections(CC)'
					$arrCC=$this->parse_pub_CC($publication);
					$isSaved=$this->save_pub_CC($arrCC, $pubId);
					
					//parse and save 'Pubmed History'
					$arrHistory=$this->parse_pub_history($publication);
					$isSaved=$this->save_pub_history($arrHistory, $pubId);
					
					//parse and save 'Publication Article IDs'
					$arrPubArticleIds=$this->parse_pub_article_ids($publication);
					$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
					
					$timeTaken=microtime(true)-$pubStartTime;
					$this->logText	= " PMID: '".$pubDetails['pmid']."'		Time taken : ".$timeTaken."\r\n";
					fwrite($this->logFile, $this->logText);
				}
				sleep($this->sleepTime);
			}
			//End of loop trough ecah publication, parsing and saving
			$this->logText	= "End of Procesing all the PMID's \r\n";
			fwrite($this->logFile, $this->logText);			
			echo "</br>Pubmed Processing of KolID :".$arrKolDetail['id']." is Completed sucessfully</br>";
			$arrKolDetail['is_pubmed_processed']=1;
			$this->pubmed->updatePubmedProcessedKol($arrKolDetail);	
			$this->logText	= "Pubmed Processing of KolID :".$arrKolDetail['id']." is Completed sucessfully \r\n";
			fwrite($this->logFile, $this->logText);
			$timeTaken=microtime(true)-$kolStartTime;	
			$this->logText	= "Total time taken: ".$timeTaken."\r\n";
			fwrite($this->logFile, $this->logText);
			
			$numRowsEffected = $this->pubmed->updateZeroAuthPosPubsAsDeleted($kolId);
			echo "Number of publications marked as deleted : ".$numRowsEffected."</br>";
			$this->logText	= "Number of publications marked as deleted : ".$numRowsEffected."\r\n";
			fwrite($this->logFile, $this->logText);
			$this->logText	= "--------------------------- \r\n";
			fwrite($this->logFile, $this->logText);	
			
			$this->send_status_mail("Pubmed Processing of KolID :".$arrKolDetail['id']." is Completed sucessfully");
		}
	}
	
	function process_pmids($kolId){
		ini_set("max_execution_time",$this->maxScriptTime);
		$arrPMIDs = null;
		$returnData = array();
		$arrPMIDStatuses = array();
		if($arrPMIDs == null){
			$arrPMIDs = array();
			$arrPMIDs = $this->input->post('pmids');
		}
		$arrKolDetail=$this->pubmed->getKolDetail($kolId);
		$arrFilteredPMIDs=$this->pubmed->checkAndAssociateAlreadyExistPubs($arrPMIDs, $kolId,$arrKolDetail);
		$associatedPmids = array_diff($arrPMIDs, $arrFilteredPMIDs);
		foreach ($associatedPmids as $pmid){
			$arrPMIDStatuses[$pmid] = 'exist';
		}
		$this->startTime	= microtime(true);
		$pmidsList = implode(',',$arrFilteredPMIDs);
		if($pmidsList != ''){
			$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$pmidsList;
			if($pmidsList!='')
				$content = $this ->retrieve_page_get($url);	
			if(!$content['response'])	return false;
			$xml = new DOMDocument();
			if(!$xml->loadXML($content['response'])){
				$this->logText	= "Error in Loading XML, Illigal format received\r\nTerminating process..\r\n ";
				fwrite($this->logFile, $this->logText);	
				//continue;
				die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
			}
	
			//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
			$publications = $xml->getElementsByTagName('PubmedArticle');				
			foreach($publications as $publication){
				$timeElapsed = (microtime(true) - $this->startTime);
				$remTime	=$this->maxScriptTime-$timeElapsed;
				//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
				if($remTime<$this->safeTime){
					$this->logText	= "Stopping the pubmed processing, Timelimit reached.\r\n ";
					fwrite($this->logFile, $this->logText);	
					die("Sorry! Stopping the pubmed processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
				}					
				$pubStartTime=microtime(true);	
				//parse and save publication details
				$pubDetails=$this->parse_pub_details($publication);	
				$pubId=$this->save_publications($pubDetails, $kolId);
				if($pubId!=null){
					//$this->logText	= "Publication with PMID:".$pubDetails['pmid']." parsed and saved sucessfully\r\n ";
					//fwrite($this->logFile, $this->logText);	
				}else{
					$arrPMIDStatuses[$pubDetails['pmid']] = 'error';
					$this->logText	= "Error in parsing and saving the Publication with PMID:".$pubDetails['pmid']." \r\n ";
					fwrite($this->logFile, $this->logText);
					continue;
				}
				
				//parse and save 'publication-authors'
				$arrAuthors=$this->parse_pub_authors($publication);
				$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
				
				//Calculate Authorship position and save
				$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail);
				$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
				
				//parse and save MeshTerms
				$arrMeshTerms=$this->parse_pub_meshterms($publication);
				$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
				
				//parse and save 'Substances(chemicals)'
				$arrSubstances=$this->parse_pub_substances($publication);
				$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
				
				//parse and save 'Publication types'
				$arrPubTypes=$this->parse_pub_types($publication);
				$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
				
				//parse and save 'CommentsCorrections(CC)'
				$arrCC=$this->parse_pub_CC($publication);
				$isSaved=$this->save_pub_CC($arrCC, $pubId);
				
				//parse and save 'Pubmed History'
				$arrHistory=$this->parse_pub_history($publication);
				$isSaved=$this->save_pub_history($arrHistory, $pubId);
				
				//parse and save 'Publication Article IDs'
				$arrPubArticleIds=$this->parse_pub_article_ids($publication);
				$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
				
				$arrPMIDStatuses[$pubDetails['pmid']] = 'done';
			}
			sleep($this->sleepTime);
		}
		$numRowsEffected = $this->pubmed->updateZeroAuthPosPubsAsDeleted($kolId);
		$returnData['status'] = true;
		$returnData['pmidstatuses'] = $arrPMIDStatuses;
		echo json_encode($returnData);
	}
	
	function get_name_combinations($kolId){
		$arrNameCombinations = $this->pubmed->getKolNameCombinations($kolId);
		$data = array();
		$data['arrNameCombinations'] = $arrNameCombinations;
		$data['kolId'] = $kolId;
		$this->load->view('publications/kol_name_combinations',$data);
	}
	
	function save_name_combinations(){
		$nameCombinationText = $this->input->post('name_combinations');
		$kolId = $this->input->post('kol_id');
		$nameCombinations = explode(",",$nameCombinationText);
		foreach ($nameCombinations as $name){
			$name = trim($name);
			if($name != ''){
				$rowData = array();
				$rowData['kol_id'] = $kolId;
				$rowData['name'] = $name; 
				$isSaved = $this->pubmed->saveNameCombination($rowData);
			}
		}
	}
	
	function delete_name_combinations(){
		$name = $this->input->post('name_combination');
		$kolId = $this->input->post('kol_id');
		$isDeleted = $this->pubmed->deleteNameCombination($name,$kolId);
	}
	
	function multi_segment_kol_name_authorship_pos($kolId = null){
		$arrKolIds = array();
		if($kolId != null)
			$arrKolIds[] = $kolId;
		else
			$arrKolIds = $this->pubmed->getKolIdsWithNameCombinations();
			
		foreach($arrKolIds as $kolId){
			//Get KOL name combinations from the database
			$arrNameCombinations = $this->pubmed->getKolNameCombinations($kolId);
			//Get the kol publications with the authorship position '0'
			$arrPubsWithAuthPosZero = $this->pubmed->getPubsWithAuthPosZero($kolId);
			foreach($arrPubsWithAuthPosZero as $pubId){
				//Get the authorship position 
				$position = $this->pubmed->getAuthorshipPositionGivenAllNameCombinations($kolId,$pubId);
				//$arrNameCombinations = "'Ongür D','Öngür D'";
				//$position = $this->pubmed->getAuthorshipPositionGivenAllNameCombinations2($kolId,$pubId,$arrNameCombinations);
				echo "<br>PubId : ".$pubId." 	&nbsp;&nbsp;&nbsp;&nbsp;Pos : ".$position;
				echo "<br>";
				//Save the authorship position if its not '0'
				if($position != '' && $position != 0)
					$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
			}
		}
	}
	
	//Delete the associations of the PMId and recrawl the details and save the associations
function recrawl_pmid($pmid,$overidePublication=0){
		if($pmid != ''){
			$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$pmid;
			
			$response = $this ->retrieve_page_get($url);
			//Try once again if the response of the status is false	
			if($response['status'] == false){
				//give 2 second delay
				sleep($this->sleepTime);
				$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
				fwrite($this->logFile, $this->logText);
				//try once again
				$response = $this ->retrieve_page_get($url);
			}
			// Skipp this and log the details if still respons is false
			if($response['status'] == false){
				//log the details
				$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next pmids, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
				fwrite($this->logFile, $this->logText);
				
				$this->logText = "Recralw : PMID : ".$pmid."\r\n";
				fwrite($this->logFilePmidSkipped, $this->logText);
				//continue to next step
				//continue;
			}
			
			$xml = new DOMDocument();
			if(!$xml->loadXML($response['response'])){
				$this->logText	= "Error in Loading XML, Illigal format received\r\n Trying to get the data once again\r\n ";
				fwrite($this->logFile, $this->logText);	
				
				$response = $this ->retrieve_page_get($url);
				//Try once again if the response of the status is false	
				if($response['status'] == false){
					//give 2 second delay
					sleep($this->sleepTime);
					$this->logText = "Error in Connecting to url :".$url."\r\n Trying to connect once again after 2 second sleep \r\n";
					fwrite($this->logFile, $this->logText);
					//try once again
					$response = $this ->retrieve_page_get($url);
				}
				// Skipp this and log the details if still respons is false
				if($response['status'] == false){
					//log the details
					$this->logText = "Still Error in Connecting to url :".$url."\r\n Skipping this and moving to next pmid, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
					fwrite($this->logFile, $this->logText);
					
					$this->logText = "Recralw : PMID : ".$pmid."\r\n";
					fwrite($this->logFilePmidSkipped, $this->logText);
					//continue to next step
					//continue;
				}
				
				if(!$xml->loadXML($response['response'])){
					//log the details and continue
					$this->logText	= "Error in Loading XML, Illigal format received\r\n Skipping this and moving to next pmid, details are logged in the file ".$this->logFileNamePmidSkipped." \r\n";
					fwrite($this->logFile, $this->logText);	
					
					$this->logText = "Recralw : PMID : ".$pmid."\r\n";
					fwrite($this->logFilePmidSkipped, $this->logText);
					//continue;
					//die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);
				}										
			}
			
			//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
			$publications = $xml->getElementsByTagName('PubmedArticle');				
			foreach($publications as $publication){
				//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
				$pubId=$this->pubmed->checkPubExist($pmid);
				if($pubId ==null || $pubId == ''){
					//die("Publication with PMID:".$pmid."  not exist.\r\n");	
					$this->logText	= "Publication with PMID:".$pmid."  not exist. \r\n";
					fwrite($this->logFile, $this->logText);										
					continue;
				}else{
				    if($overidePublication){
    				    $pubDetails=$this->parse_pub_details($publication);
    				    $publicationId=$this->pubmed->savePublication($pubDetails,$pubId);
//     				    echo "<br/>recrawled pmid - ". $pmid . "  Pubid - ".$pubId;
//     				    return true;
				    }
				}
				
				//parse and save 'publication-authors'
				$arrAuthors=$this->parse_pub_authors($publication);
				
				$numAuthorsPresent = $this->pubmed->getNumberOfAuthors($pubId);;
				//Compare the number of authors for this pubid in data base, if mismatch then only proceed
				$this->logText	= "PMID : ".$pmid."	PubID :".$pubId." \r\n ";
				echo $this->logText."<br>";
				//fwrite($this->logFile, $this->logText);
				$this->logText	= "Total Authors : ".sizeof($arrAuthors)."	Authors Present in Database :".$numAuthorsPresent." \r\n ";
				echo $this->logText."<br>";
				//fwrite($this->logFile, $this->logText);
					
				//Delete all the initiall associations first
				$this->pubmed->deletePublicationAssociationDetails($pubId);
				
				//pr($arrAuthors);
				//$arrAuthors = array_slice($arrAuthors,0, 2);
				//pr($arrAuthors);
				$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
				
				//Calculate Authorship position and save
				//$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail);
				//$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
				
				//parse and save MeshTerms
				$arrMeshTerms=$this->parse_pub_meshterms($publication);
				$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
				
				//parse and save 'Substances(chemicals)'
				$arrSubstances=$this->parse_pub_substances($publication);
				$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
				
				//parse and save 'Publication types'
				$arrPubTypes=$this->parse_pub_types($publication);
				$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
				
				//parse and save 'CommentsCorrections(CC)'
				$arrCC=$this->parse_pub_CC($publication);
				$isSaved=$this->save_pub_CC($arrCC, $pubId);
				
				//parse and save 'Pubmed History'
				$arrHistory=$this->parse_pub_history($publication);
				$isSaved=$this->save_pub_history($arrHistory, $pubId);
				
				//parse and save 'Publication Article IDs'
				$arrPubArticleIds=$this->parse_pub_article_ids($publication);
				$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
			}
			
		}
	}
	
	
	//Identify the partially crawled publications and recrawl them
	function recrawl_partial_pmids(){
		$this->startTime	= microtime(true);
		$this->logFilePath=	$_SERVER['DOCUMENT_ROOT'].'/'.$this->logFilePath;	
		$this->logFileName	=$this->logFilePath . "/" . "logfile_partial_pmids_".date("d-m-Y")."_". $this->startTime . ".txt";
		$this->logFile	= fopen($this->logFileName, "w");
		
		$this->logLastPmidFile = fopen($this->logFilePath . "/last_pmid.txt", "w");
		
		//Get all the pmids from given date and greater than given publication id
		$arrPMIDs = array();
		$arrPMIDs[] = '22566560';
		for($i=0; $i<sizeof($arrPMIDs);$i=$i+10){
			$authListText='';
			$arrAuthList = array();
			for($j=$i; $j<$i+$this->pmidBatchSize; $j++){
				if( $arrPMIDs[$j]!='')
					$arrAuthList[] = $arrPMIDs[$j];
			}
			$authListText = implode(",",$arrAuthList);
							
			$pubFetchStartTime=microtime(true);				
			$url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$authListText;
			$this->logText	= "Url generated: ".$url."\r\n";
			fwrite($this->logFile, $this->logText);	
			if($authListText!='')
				$content = $this ->retrieve_page_get($url);	
			if(!$content['response'])	return false;
			$timeTaken=microtime(true)-$pubFetchStartTime;		
			$this->logText	= "Time taken to fetch ".$this->pmidBatchSize." publications : ".$timeTaken."\r\n";
			fwrite($this->logFile, $this->logText);	
			$xml = new DOMDocument();
			if(!$xml->loadXML($content['response'])){
				$this->logText	= "Error in Loading XML, Illigal format received\r\nTerminating process..\r\n ";
				fwrite($this->logFile, $this->logText);	
				//continue;
				die("Sorry! Couldnot process, check the log for details, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
			}

			//Start Loop trough each PubMed Publication, i.e for each PubMed id there will be one Publication"
			$this->logText	= "Following Publications with PMID's are parsed and saved sucessfully\r\n ";
			fwrite($this->logFile, $this->logText);
			$publications = $xml->getElementsByTagName('PubmedArticle');				
			foreach($publications as $publication){
				$timeElapsed = (microtime(true) - $this->startTime);
				$remTime	=$this->maxScriptTime-$timeElapsed;
				//Stop processing if the remaining time is less then the safe time i.e if the Maximum execution time is elapsed 
				/*if($remTime<$this->safeTime){
					$this->logText	= "Stopping the pubmed processing, Timelimit reached.\r\n ";
					fwrite($this->logFile, $this->logText);	
					die("Sorry! Stopping the pubmed processing, Timelimit reached, LogPath: ".$this->logFilePath."\/".$this->logFileName);										
				}*/					
				$pubStartTime=microtime(true);	
				//parse and save publication details
				$pubDetails=$this->parse_pub_details($publication);	
				$pubId=$this->pubmed->checkPubExist($pubDetails['pmid']);
				if($pubId!=null){
					//$this->logText	= "Publication with PMID:".$pubDetails['pmid']." parsed and saved sucessfully\r\n ";
					//fwrite($this->logFile, $this->logText);	
				}else{
					$this->logText	= "Error in parsing and saving the Publication with PMID:".$pubDetails['pmid']." \r\n ";
					fwrite($this->logFile, $this->logText);
					continue;
				}
				//log the last PMID parsed
				file_put_contents($this->logFilePath . "/last_pmid.txt",$pubDetails['pmid']);
				
				//parse 'publication-authors'
				$arrAuthors=$this->parse_pub_authors($publication);
				$numAuthorsPresent = $this->pubmed->getNumberOfAuthors($pubId);;
				//Compare the number of authors for this pubid in data base, if mismatch then only proceed
				echo $numAuthorsPresent;
				if(sizeof($arrAuthors) > $numAuthorsPresent){
					$this->logText	= "PMID : ".$pubDetails['pmid']."	PubID :".$pubId." \r\n ";;
					fwrite($this->logFile, $this->logText);
					$this->logText	= "Total Authors : ".sizeof($arrAuthors)."	Authors Present in Database :".$numAuthorsPresent." \r\n ";;
					fwrite($this->logFile, $this->logText);
					
					//Delete all the initiall associations first
					$this->pubmed->deletePublicationAssociationDetails($pubId);
					pr($arrAuthors);
					//Save the authors
					$isSaved=$this->save_pub_authors($arrAuthors, $pubId);
					
					//Get the associated KOLs detais in order to calculate the authorship position
					$arrAssociatedKols = $this->pubmed->getAssociatedKols($pubId);
					$textKolsAssociatedAndPosition = "KOLs Associated and there Positions[kolid,position] : ";
					foreach($arrAssociatedKols as $arrKolDetail){
						pr($arrKolDetail);
						$kolId = $arrKolDetail['id'];
						//Calculate Authorship position and save
						$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,$arrKolDetail);
						echo "<br>Position".$position;
						$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
						$textKolsAssociatedAndPosition .= " [".$kolId.",".$position."]";
					}
					$textKolsAssociatedAndPosition .= " \r\n ";
					fwrite($this->logFile, $textKolsAssociatedAndPosition);
					
					//parse and save MeshTerms
					$arrMeshTerms=$this->parse_pub_meshterms($publication);
					$isSaved=$this->save_pub_meshterms($arrMeshTerms, $pubId);
					
					//parse and save 'Substances(chemicals)'
					$arrSubstances=$this->parse_pub_substances($publication);
					$isSaved=$this->save_pub_substances($arrSubstances, $pubId);
					
					//parse and save 'Publication types'
					$arrPubTypes=$this->parse_pub_types($publication);
					$isSaved=$this->save_pub_types($arrPubTypes, $pubId);
					
					//parse and save 'CommentsCorrections(CC)'
					$arrCC=$this->parse_pub_CC($publication);
					$isSaved=$this->save_pub_CC($arrCC, $pubId);
					
					//parse and save 'Pubmed History'
					$arrHistory=$this->parse_pub_history($publication);
					$isSaved=$this->save_pub_history($arrHistory, $pubId);
					
					//parse and save 'Publication Article IDs'
					$arrPubArticleIds=$this->parse_pub_article_ids($publication);
					$isSaved=$this->save_pub_article_ids($arrPubArticleIds, $pubId);
					
					$this->logText	= "------------------------------------------ \r\n";
					fwrite($this->logFile, $this->logText);
				}
			}
			sleep($this->sleepTime);
		}
		$this->logText	= "Partial PMIDs processing completed  \r\n";
		fwrite($this->logFile, $this->logText);
	}
	
	private function send_status_mail($message, $mailId = null){
		$config['protocol'] 	= PROTOCOL;
		$config['smtp_host'] 	= HOST;         
		$config['smtp_port'] 	= PORT;
		$config['smtp_user'] 	= USER;
		$config['smtp_pass'] 	= PASS;
		$config['mailtype']		= 'html';

		$this->load->library('email', $config);
		$this->email->set_newline("\r\n");
		$this->email->initialize($config);
		$this->email->clear(true);
		
		if($mailId == null)
			$mailId = $this->observerEmailId;
			
		//Send mail to  User
        $this->email->subject($this->logFileName);
        $this->email->from(USER,"Pub Crawling");
		$this->email->message($message);
        $this->email->to($mailId);
		$this->email->attach($this->logFileName,'attachment');
		$this->email->attach($this->logFileNamePmidSkipped,'attachment');
        $this->email->send();
	}
	
	/**
	 * Returns the Top journals 0f  to perticula KOl_Id,Time Range,
	 * @return unknown_type
	 * @author Vinayak Malladad
	 * @since 1.4.4
	 * Created-on 23/2/11
	 */
	function view_pub_type_chart($kolId,$fromYear,$toYear){
		$keyWord = $this->input->post('keyWord');
		
		$this->session->set_userdata('kolKeyWords',$keyWord);
		$keyWord = $this->session->userdata('kolKeyWords');
		$arrJournals= $this->pubmed->getPubTypeData($kolId,$fromYear,$toYear,$keyWord);
		//echo $this->db->last_query();
		$name		= array();
		$count		= array();
		$arrIds		= array();
		foreach($arrJournals as $row){
			$name[] = $row['type'];
			$count[]= (int)$row['count'];
			$arrIds[]=$row['id'];			
		}
		$data[]=$name;	
		$data[]=$count;
		$data[]=$arrIds;
		echo json_encode($data);
	}
	
	/**
	 * Returns the list of Publication details of Particular Journal Name,KOl_Id,Time Range
	 * @return unknown_type
	 * @author Vinayak Malladad
	 * @since 1.4.4
	 * Created-on 23/2/11
	 */
	function view_publications_by_type($typeId,$kol_id, $fromYear,$toYear, $reportFilters = ''){
		$filters = array();
		$filters = $this->filters_to_array($reportFilters);
		if($filters['kol_id'][0]!=''){
			$filters['kol_id'] = $this->getKolIds($filters['kol_id']);
		}
		$filters['keyword'] = $this->session->userdata('kolKeyWords');
		$arrJournalPublications = $this->pubmed->getPublicationsByType($typeId,$kol_id, $fromYear,$toYear,$filters);
		//$journalName = $this->pubmed->getJournalNameById($journalName);
		$data['arrPublications']	= $arrJournalPublications;
		$data['filterType']					= 'Publications By Type';
		$data['filterValue']				= $arrJournalPublications[0]['type'];
		$data['fromYear']					= $fromYear;
		$data['toYear']						= $toYear;
		if($kol_id != 0){
			$koldetails = $this->kol->getKolName($kol_id);
			$data['first_name']		= $koldetails['first_name'];
			$data['middle_name']	= $koldetails['middle_name'];
			$data['last_name']		= $koldetails['last_name'];
		}
		$this->load->view('publications/view_publications_by_parameters',$data);
	} 

	function view_all_publications_by_type($typeId,$kol_id, $fromYear,$toYear, $reportFilters = '',$viewTypeMyKols) {
		if($viewTypeMyKols == MY_RECORDS){
			$viewMyKols = $this->kol->getMyKolsView($this->session->userdata('user_id'));
			if(sizeof($viewMyKols) > 0){
				$viewType = $viewMyKols;
				$viewTypeMyKols = MY_RECORDS;
			}else{
				$viewTypeMyKols = ALL_RECORDS;
			}
		}else{
			$viewTypeMyKols = ALL_RECORDS;
		}
		$filters = array();
		$filters = $this->filters_to_array($reportFilters);
//		if($filters['kol_id'][0]!=''){
//			$filters['kol_id'] = $this->getKolIds($filters['kol_id']);
//		}
		$arrPublicationsType = $this->pubmed->getPublicationsByType($typeId,$kol_id, $fromYear,$toYear,$filters,$viewType);
		//$journalName = $this->pubmed->getJournalNameById($journalName);
		$data['arrPublications']	= $arrPublicationsType;
		$data['filterType']					= 'Publications By Type';
		$data['filterValue']				= $arrPublicationsType[0]['type'];
		$data['fromYear']					= $fromYear;
		$data['toYear']						= $toYear;
		if($kol_id != 0){
			$koldetails = $this->kol->getKolName($kol_id);
			$data['first_name']		= $koldetails['first_name'];
			$data['middle_name']	= $koldetails['middle_name'];
			$data['last_name']		= $koldetails['last_name'];
		}
		$this->load->view('publications/view_publications_by_parameters',$data);
	}
	
        
        function view_pubs_by_top_concepts($kolId,$fromYear,$toYear,$termName,$keyword){
		$arrPublications = $this->pubmed->viewPubsByTopConcepts($kolId,$fromYear,$toYear,$termName,$keyword);
//		echo $this->db->last_query();
//		$substanceName = $this->pubmed->getSubstanceNameById($substanceName);	
		
		$data['arrPublications']			= $arrPublications;
		$data['filterType']					= 'Publications By Concepts';
		$data['filterValue']				= $termName;
		$data['fromYear']					= $fromYear;
		$data['toYear']						= $toYear;
		if($kolId != 0){
			$koldetails = $this->kol->getKolName($kolId);
			$data['first_name']		= $koldetails['first_name'];
			$data['middle_name']	= $koldetails['middle_name'];
			$data['last_name']		= $koldetails['last_name'];
		}
		$this->load->view('publications/view_publications_by_parameters',$data);
	}
	
	function edit_client_publication($kolId,$pubId){
		$publication=$this->pubmed->getPublicationDetail($pubId);
			$publication['journal_name']=$this->pubmed->getJournalNameById($publication['journal_id']);
			if($publication['pub_date']=='0000-00-00')	
				$publication['pub_date']='';
			else				
				$publication['pub_date']=sql_date_to_app_date($publication['pub_date']);
			$publication['created_date']=sql_date_to_app_date($publication['created_date']);
		$arrMultipleAuthors=$this->pubmed->listPublicationAuthors($pubId);
		$arrMeshTerms=array();
		$arrMeshTermsResults=$this->pubmed->listPublicationMeshTerms($pubId);
			foreach($arrMeshTermsResults as $meshTerm){
				$parentId=$meshTerm['parent_id'];
				if($parentId!=0 && $parentId!=null){
					$parentName=$this->pubmed->getMeshTermName($parentId);
					$termName=$parentName."/".$meshTerm['term_name'];
				}else{
					$termName=$meshTerm['term_name'];
				}
				if($meshTerm['is_major']==1)
					$termName=$termName."*";
				$arrMeshTerms[]=$termName;
			}
		$data['publication']=$publication;
		$data['arrMultipleAuthors']=$arrMultipleAuthors;
		$data['arrMeshTerms']=$arrMeshTerms;
		$data['kolId']=$kolId;
		$this->load->view('publications/add_publications',$data);
	}
	function deleteAuthorOfPublication($kolId,$pubId,$autId){
	    $res = $this->pubmed->delete_author_publication($pubId,$autId);
	    $data['status'] = "failure";
	    if($res){
	        $data['status'] = "success";
	        //Calculate Authorship position and save
			$position=$this->pubmed->calculateAuthorShipPosition($pubId,$kolId,array());
			$this->pubmed->updateAuthorshipPos($kolId,$pubId,$position);
	    }
	    echo json_encode($data);
	}
	function re_crawl_publications_types(){
	    ini_set("max_execution_time",0);
	    ini_set('memory_limit', '-1');
	    //Get all the publications ids with there reapecrive PMID
	    $get = $this->db->query("SELECT publications.id,publications.pmid,publications_types.pub_type_id  FROM `publications`
                left join publications_types on publications.id=publications_types.pub_id
                WHERE publications_types.pub_type_id ='' or publications_types.pub_type_id is null
                and pmid>0");
	    /*$get = $this->db->query("SELECT publications.id,publications.pmid,publications_types.pub_type_id  FROM `publications`
	     left join publications_types on publications.id=publications_types.pub_id
	     left join kol_publications on kol_publications.pub_id=publications.id
	     WHERE kol_id=566"); */ //for speciic kol
	    $pmids = '';
	    $arrayPubIdsAll = array();
	    foreach($get->result_array() as $row){
	        //$pmids .=$row['pmid'].',';
	        $arrayPubIdsAll[$row['id']] = $row['pmid'];
	    }
	    $splitArrayPubIds = array_chunk($arrayPubIdsAll, 100);
	    /*  $splitArrayPubIds  = array('26240216','26343451');
	     $url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=27392131";
	     echo $url;
	     $content = $this ->retrieve_page_get($url);
	     pr($content);
	     exit; */
	    $i=0;
	    foreach($splitArrayPubIds as $arrayPubIds){
	        // 	        pr($arrayPubIds);exit;
	        $pmids = implode(',',$arrayPubIds);
	        $pubFetchStartTime=microtime(true);
	        //     	    echo $pmids;exit;
	        $url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$pmids;
	        	
	        if(sizeof($arrayPubIds)>0){
	            $content = $this ->retrieve_page_get($url);
	
	            if(!$content['response']){
	                //pr($arrayPubIds);exit;
	                return false;
	            }else{
	                //$timeTaken=microtime(true)-$pubFetchStartTime;
	                $xml = new DOMDocument();
	                if(!$xml->loadXML($content['response'])){
	                    //continue;
	                    
	                    die("Sorry! Couldnot process, check the log for details");
	                }
	                //echo $content['response'];exit;
	                $publications = $xml->getElementsByTagName('PubmedArticle');
	                //     	        $arrayPublicationTypeDetails = array();
	                
	                foreach($publications as $publication){
	                    $ptype = $this->parse_pub_types($publication);
	                    $pubDetails=$this->parse_pub_details($publication);
	                    $pubId =  array_search($pubDetails['pmid'], $arrayPubIdsAll);
	                    $arrayPublicationTypeDetails= array("pub_id"=>$pubId,
	                            "pub_type_id" => $this->pubmed->savePubmedPubType($ptype[0]));
	                    //pr($arrayPublicationTypeDetails);
	                    if($this->pubmed->SavePublicationType($arrayPublicationTypeDetails)){
	                        $i++;
	                    }
	                }
	               
	            }
	        }
	    }
	    
	    //Log Activity
	    $arrLogDetails = array(
	    		'type'=>CRON_JOBS,
	    		'description'=> $i. " Publication Type Updated",
	    		'status' => STATUS_SUCCESS,
	    		'transaction_id'=>'',
	    		'transaction_name'=>'Crawling publication type',
	    		'miscellaneous1'=>$url
	    );
	    $this->config->set_item('log_details', $arrLogDetails);
	    echo $i. " Publication Type Updated";
	    //  pr($arrayPublicationTypeDetails);
	}
	
	function update_pub_authors($arrAuthors, $pubId, $authId,$position){
// 		pr($arrAuthors);exit;
		//echo 'INSERT INTO pubmed_authors (last_name, fore_name, initials, suffix, is_name_valid) VALUES ("'.$arrAuthors[0]['last_name'].'","'.$arrAuthors[0]['fore_name'].'","'.$arrAuthors[0]['initials'].'","'.$arrAuthors[0]['suffix'].'","'.$arrAuthors[0]['is_name_valid'].'")';
		//echo 'Auth Id '.$authId.'<br/>';
		$query1 = $this->db->query("select id from publications_authors where pub_id='".$pubId."' and author_id='".$authId."'");
		$result1 = $query1->first_row();
		$publications_authors_id = $result1->id;
// 		echo 'publication auth id '.$publications_authors_id.'<br/>';
		$query2 = $this->db->query("select id from pubmed_authors where id='".$authId."'");
		$result2 = $query2->first_row();
		$pubmed_authors_id = $result2->id;
// 		echo 'pubmed auth id '.$pubmed_authors_id.'<br/>';
		if($publications_authors_id=='' && $pubmed_authors_id==''){
			if($this->db->query('INSERT INTO pubmed_authors (last_name, fore_name, initials, suffix, is_name_valid) VALUES ("'.$arrAuthors[0]['last_name'].'","'.$arrAuthors[0]['fore_name'].'","'.$arrAuthors[0]['initials'].'","'.$arrAuthors[0]['suffix'].'","'.$arrAuthors[0]['is_name_valid'].'")')){
				$authId = $this->db->insert_id();
				$this->db->query('INSERT INTO publications_authors (pub_id, author_id, position, alias_id) VALUES ("'.$pubId.'","'.$authId.'","'.$position.'","'.$authId.'")');
			}
		}
	}
	
	function list_publication_by_kol($kolId){
	    $page = $_REQUEST['page']; // get the requested page
	    $limit = $_REQUEST['rows']; // get how many rows we want
	    $sidx = $_REQUEST['sidx']; // get index row - i.e. user click to sort
	    $sord = $_REQUEST['sord']; // get the direction
	    if (!$sidx)
	        $sidx = 1;

        if (isset($_REQUEST['filters'])) {
            $filterData = $_REQUEST['filters'];
            $arrFilter = array();
            $arrFilter = json_decode(stripslashes($filterData));
            $field = 'field';
            $op = 'op';
            $data = 'data';
            $groupOp = 'groupOp';
            $searchGroupOperator = $this->common_helpers->search_nested_arrays($arrFilter, $groupOp);
            $searchString = $this->common_helpers->search_nested_arrays($arrFilter, $data);
            $searchOper = $this->common_helpers->search_nested_arrays($arrFilter, $op);
            $searchField = $this->common_helpers->search_nested_arrays($arrFilter, $field);
            $whereResultArray = array();
            foreach ($searchField as $key => $val) {
                $whereResultArray[$val] = $searchString[$key];
            }
            $searchGroupOperator = $searchGroupOperator[0];
            $searchResults = array();
        }
        $count = count($this->pubmed->getKolPublications($kolId,$limit='All', 0, $sidx, $sord, $whereResultArray=array()));
        $limit = $_REQUEST['rows']; // get how many rows we want
        if ($count > 0) {
            $total_pages = ceil($count / $limit);
        } else {
            $total_pages = 0;
        }
        if ($page > $total_pages || $page=='NaN')
            $page = $total_pages;
            $start = $limit * $page - $limit; // do not put $limit*($page - 1)
            if ($start < 0)
                $start = 0;
                $limit = $_REQUEST['rows'];
                if($limit==0){
                    $limit='All';
                }
	    $arrPublications = $this->pubmed->getKolPublications($kolId,$limit, $start, $sidx, $sord, $whereResultArray);
	    $arrPublicationsDetail=array();
	    foreach ($arrPublications as $row){
	        if(isset($row['pmid']) && $row['pmid'] > 0){
	            $row['linkForArticle'] = 'pmid';
	        }else{
	            $row['linkForArticle'] = 'link';
	        }
	        $arrPublicationsDetail[]=$row;
	    }
	    $data1['records'] = $count;
	    $data1['total'] = $total_pages;
	    $data1['page'] = $page;
	    $data1['rows'] = $arrPublicationsDetail;
	    echo json_encode($data1);
	}
	// Excel Activity by Publication
	function export_list_publication_by_kol_details($kolId,$fileName){
		$data = $this->pubmed->getKolPublications($kolId,0,0,0,0,0);
		//pr($data);exit;
		$startTime = microtime(true);
		ini_set('memory_limit', "-1");
		ini_set("max_execution_time", 0);
		$this->load->plugin('php_excel/Classes/PHPExcel.php');
		//header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		$objPHPExcel = new PHPExcel();
		$arrExcelData = array();
		//New Worksheet
		$objWorksheet = new PHPExcel_Worksheet($objPHPExcel);
		$objWorksheet->setTitle($fileName);
		
		//Add header
		
 		$objWorksheet->setCellValue('A1', 'PMID')
		->setCellValue('B1', 'Article Title')
		->setCellValue('C1', 'Journal Name')
		->setCellValue('D1', 'Created Date')
		->setCellValue('E1', 'Number of Authors');
		 
		$i = 2;
		foreach ($data as $records) {
			
			$objWorksheet->setCellValue('A'.$i, (isset($records['pmid'])?$records['pmid']:''))
			->setCellValue('B'.$i, (isset($records['article_title'])?$records['article_title']:''))
			->setCellValue('C'.$i, (isset($records['journal_name'])?$records['journal_name']:''))
			->setCellValue('D'.$i, (isset($records['created_date'])?$records['created_date']:''))
			->setCellValue('E'.$i, (isset($records['authcount'])?$records['authcount']:''));
			
			$i++;
		}
		
		$objPHPExcel->addSheet($objWorksheet);
		$styleArray = array(
				'borders' => array(
						'bottom' => array(
								'style' => PHPExcel_Style_Border::BORDER_THICK,
								'color' => array('argb' => '0000000'),
						),
				),
		);
		
		$arrStyles = array(
				'font' => array(
						'bold' => true,
						'italic' => false
				),
				'borders' => array(
						'bottom' => array(
								'style' => PHPExcel_Style_Border::BORDER_THICK,
								'color' => array(
										'rgb' => '000000'
								)
						),
						'quotePrefix' => true
				)
		);
		$objPHPExcel->removeSheetByIndex(0);
		
		foreach ($objPHPExcel->getWorksheetIterator() as $sheet) {
			
			$objPHPExcel->setActiveSheetIndexByName($sheet->getTitle());
			
			foreach (range('A', 'F') as $columnID) {
				$objPHPExcel->getActiveSheet()->getColumnDimension($columnID)->setWidth(30);
			}
			
			$objPHPExcel->getActiveSheet()->getStyle('A1:F1')->applyFromArray($arrStyles);
			
		}
		
		$objPHPExcel->setActiveSheetIndex(0);
		//$fileName = "Activity_Reports_".date("m-d-Y_His");
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		ob_end_clean();
		//header('Content-type: application/vnd.ms-excel');
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment; filename=' . $fileName. '.xlsx');
		$objWriter->save('php://output');
		exit;
	}
	function re_crawl_publications_date(){
	    ini_set("max_execution_time",0);
	    ini_set('memory_limit', '-1');
	    //Get all the publications ids with there reapecrive PMID
	    $get = $this->db->query("SELECT publications.id,publications.pmid,publications.created_date  FROM `publications`
                WHERE (publications.created_date = 0 or publications.created_date is null)
                and pmid>0");
	    $pmids = '';
	    $arrayPubIdsAll = array();
	    foreach($get->result_array() as $row){
	        //$pmids .=$row['pmid'].',';
	        $arrayPubIdsAll[$row['id']] = $row['pmid'];
	    }
	    echo "Totla publiction with zero date - ".count($arrayPubIdsAll);
	    echo "<br/>";
	    $arrUpdatePmid= array();
	    $arrFailedPmid= array();
	    $splitArrayPubIds = array_chunk($arrayPubIdsAll, 100);
	    foreach($splitArrayPubIds as $arrayPubIds){
	        // 	        pr($arrayPubIds);exit;
	        $pmids = implode(',',$arrayPubIds);
	        $pubFetchStartTime=microtime(true);
	        //     	    echo $pmids;exit;
	        $url = "http://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=".$pmids;
	        if(sizeof($arrayPubIds)>0){
	            $content = $this ->retrieve_page_get($url);
	            if(!$content['response']){
	                //pr($arrayPubIds);exit;
	                return false;
	            }else{
	                //$timeTaken=microtime(true)-$pubFetchStartTime;
	                $xml = new DOMDocument();
	                if(!$xml->loadXML($content['response'])){
	                    //continue;
	                    die("Sorry! Couldnot process, check the log for details");
	                }
	                //echo $content['response'];exit;
	                $publications = $xml->getElementsByTagName('PubmedArticle');
	                //     	        $arrayPublicationTypeDetails = array();
	                $i=0;
	                foreach($publications as $publication){
	                    $pubDetails=$this->parse_pub_details($publication);
	                    $pubId =  array_search($pubDetails['pmid'], $arrayPubIdsAll);
	                    $dateCreated = '';
	                    $dateCreatedObj = $this->parse_pub_history($publication);
	                    foreach($dateCreatedObj as $date_created){
	                        if($date_created['status']=='pubmed'){
	                            $dateCreated = $date_created['dateOnly'];
	                        }
	                    }
	                    if($dateCreated!=''){
	                        $this->db->update("publications",array("created_date"=>$dateCreated),array("id"=>$pubId));
	                        $arrUpdatePmid[]=$pubDetails['pmid'];
	                    }else{
	                        $arrFailedPmid[]=$pubDetails['pmid'];
	                    }
	                     
	                }
	            }
	        }
	    }
	    echo  count($arrUpdatePmid)."-Sucessfull PMIDS</br>";
	    echo implode(",",$arrUpdatePmid);
	    echo  count($arrFailedPmid)."-<br/>Failed PMIDS</br>";
	    echo implode(",",$arrFailedPmid);
	}
	function recrawl_pmid_and_update_master_publication(){
	    ini_set("max_execution_time",0);
	    ini_set('memory_limit', '-1');
	    //Get all the publications ids with there reapecrive PMID
	    $get = $this->db->query("SELECT publications.id,publications.pmid,publications.created_date  FROM `publications`
                WHERE (publications.created_date = 0 or publications.created_date is null)
                and pmid>0"); 
	    /*$get = $this->db->query("select * from publications                         
                        left join kol_publications on kol_publications.pub_id = publications.id
                        where kol_id in (2494) and publications.pmid>0
                        group by publications.pmid");*/
	    $pmids = '';
	    // 	    pr($get->result_array());exit;
	    foreach($get->result_array() as $row){
	        $this->recrawl_pmid($row['pmid'],1);
	    }
	}
	
}
