<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/ui.jqgrid.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>jqgrid/css/jqgrid.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>modules/kols/css/requested_kols.css" />
<link rel="stylesheet" href="<?php echo base_url().ASSETS;?>alerts/jquery.alerts.css" media="screen" />

<form action="<?php echo base_url()?>kols/requested_kols/export_kol_detail" method="post" id="exportClientRequestDetail">
		<input type="hidden" value="" name="exportIds" id="exportIds" />
		<input type="hidden" value="" name="filters" id="filters" />
		<input type="hidden" value="" name="type" id="type" />
</form>

<div id="listKols">
	<div id="msg"></div>
	<div id="listKolsTbl"></div>
</div>
<div class="gridWrapper" id="myPendingApprovals">
	<table id="myPendingApprovalstResultSet"></table>
	<div id="myPendingApprovalstPager"></div>
</div>
<div class="gridWrapper" id="allProfileRequestsGridContainer">
	<table id="allProfileRequestsResultSet"></table>
	<div id="allProfileRequestsPager"></div>
</div>
<?php
$queued_js_scripts = array('jqgrid/i18n/grid.locale-en',
		'jqgrid/jquery.jqGrid.min_3.8',
		'modules/kols/js/requested_kols',
		'alerts/jquery.alerts');    
$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
$autoApproveRequest	= IS_APPROVER;
?>	
<script>
var urlFilters = null;
<?php if(isset($urlString)){?>
urlFilters = <?php echo $urlString ?>;
<?php }?>
var KOL								='<?php echo lang("KOL"); ?>'; 
var autoApproveRequest				= '<?php echo $autoApproveRequest;?>';
var myPendingApprovalsTitle 		= "<?php echo lang("ProfileRequest.PendingApprovals");?>";
var requestTypeHeader				= "<?php echo lang("ProfileRequest.RequestType");?>";
var organizationHeader 				= "<?php echo lang("Surveys.Organization");?>";
var statusHeader 					= "<?php echo lang("Overview.Status");?>";
var nameHeader 						= "<?php echo lang("Organizations.Name");?>";
var createdByHeader 				= "<?php echo lang("Surveys.CreatedBy");?>";
var actionHeader 					= "<?php echo lang("Overview.Action");?>";
var approverHeader 					= "<?php echo lang("ProfileRequest.Approver");?>";
var allProfRequestTitle 			= "<?php echo lang("ProfileRequest.ProfileRequests");?>";
jqgridIds							= new Array('myPendingApprovalsResultSet','allProfileRequestsResultSet');
$(document).ready(function(){
	myPendingApprovals();
	allProfileRequests();
});
function myPendingApprovals(){
	$("#myPendingApprovals").html("");
	$("#myPendingApprovals").html('<table id="myPendingApprovalsResultSet"></table><div id="myPendingApprovalsPager"></div>');
	var type='pending';
	jQuery("#myPendingApprovalsResultSet").jqGrid({
	   	url:'<?php echo base_url()?>kols/requested_kols/list_user_requests/'+type,
		datatype: "json",
		colNames:['Id','','','',statusHeader,nameHeader,requestTypeHeader,organizationHeader,createdByHeader,"Requested On","Approved / Rejected On",actionHeader,"approve_allow"],
	   	colModel:[
					{name:'id',index:'id', hidden:true},
					{name:'created_by',index:'created_by', hidden:true},
					{name:'kol_id',index:'kol_id', hidden:true},
					{name:'micro',index:'micro',width:30, search:false },
					<?php //if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN){
						if($autoApproveRequest){
					?>
					{name:'status',index:'status',width:80, resizable:false},
					<?php }else{ ?>
					{name:'status',index:'status',width:100, resizable:false},
					<?php } ?>
					{name:'kol_name',index:'kol_name',width:190 },
					{name:'request_type',index:'request_type',width:100 },
					{name:'org_name',index:'org_name',width:220},
			   		{name:'user_full_name',index:'user_full_name',width:120, resizable:false},
			   		{name:'requested_on',index:'requested_on',width:100 },
					{name:'rej_or_appr_on',index:'rej_or_appr_on',hidden:true},
			   		{name:'act',resizable:true,search:false,width:100,align:'center',title:false,sortable:false},
					{name:'approve_allow',index:'approve_allow', hidden:true}
	   	],
	   	rowNum:10,
	   	rownumbers: true,
		//rownumWidth: 60,
	   	<?php //if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN){
	   	if($autoApproveRequest){
	   	?>
		multiselect: true,
		<?php } ?>
		autowidth: true, 
	   	loadonce:false,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",	
	   	width:"100%",
	   	resizable:true,
	   	shrinkToFit: true,
	   	pager: '#myPendingApprovalsPager',
	   	mtype: "POST",
	   	sortname: 'requested_on',
	    viewrecords: true,
	    sortorder: "desc",
	    jsonReader: { repeatitems : false, id: "0" }, 
	    caption:myPendingApprovalsTitle,
	   	rowList:[10,20,50,100],
	    gridComplete: function(){
			var userId = <?php echo $this->session->userdata('user_id')?>;
	   		var ids = jQuery("#myPendingApprovalsResultSet").jqGrid('getDataIDs'); 
    		for(var i=0;i < ids.length;i++){ 
		    	var arrId = jQuery('#myPendingApprovalsResultSet').jqGrid ('getRowData', ids[i]);
    			var cl = arrId.id;
		    	var rowData = jQuery("#myPendingApprovalsResultSet").jqGrid('getRowData', ids[i]);
		    	if(autoApproveRequest){
					be = "<div class='approve-reject'><a onclick='approveRequestedKols(" + cl + "," + ids[i] + ")' href='#' class='approve_reject approve' rel='tooltip' title=\"Approve profile request\">&nbsp;</a></div> <div class='tooltip-demo tooltop-left approve-reject'><a onclick='showRejectBox(" + cl + "," + ids[i] + ")' href='#' class='approve_reject reject' rel='tooltip' title=\"Reject profile request\">&nbsp;</a></div>";
		    	}else{
		    		be = "<div style='margin-right: 10px;'><label><div class='actionIcon deleteIcon tooltip-demo tooltop-left' onclick=\"deleteRequsetedKol('" + cl + "','" + ids[i] + "'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\">&nbsp;</a></div></label></div>";
			    }
		    	jQuery("#myPendingApprovalsResultSet").jqGrid('setRowData',ids[i],{act:be});
		    	
				microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewKolMicroProfile(this,'"+rowData.kol_id+"'); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Profile Snapshot\">&nbsp;</a></div></label>";
		    	jQuery("#myPendingApprovalsResultSet").jqGrid('setRowData',ids[i],{micro:microviewLink}); 
	    	}
    	jQuery("#myPendingApprovalsResultSet").jqGrid('navGrid','hideCol',"id"); 
    	},
    	onSelectAll: function(aRowids,status){
    		var ids = jQuery("#myPendingApprovalsResultSet").jqGrid('getDataIDs'); 
    		for(var i=0;i < ids.length;i++){ 
    			var arrId = jQuery('#myPendingApprovalsResultSet').jqGrid ('getRowData', ids[i]);
    			var cl = arrId.id;
    			var rowData = jQuery("#myPendingApprovalsResultSet").jqGrid('getRowData', ids[i]);
		    	if(rowData.status=='Approved' || rowData.status=='Profiling' || rowData.status=='Review'){
		    		  var cbs = $("tr.jqgrow > td > input.cbox:disabled",jQuery("#myPendingApprovalsResultSet")[0]);
		                cbs.removeAttr("checked");
		                //modify the selarrrow parameter
		                jQuery("#myPendingApprovalsResultSet")[0].p.selarrrow = jQuery("#myPendingApprovalsResultSet").find("tr.jqgrow:has(td > input.cbox:checked)")
		                    .map(function() { return this.id; }) // convert to set of ids
		                    .get(); // convert to instance of Array
				}
	    	} 
        }
	});
	jQuery("#myPendingApprovalsResultSet").jqGrid('navGrid','#myPendingApprovalsPager',{edit:false,add:false,del:false,search:false,refresh:false});
	jQuery("#myPendingApprovalsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn",beforeSearch: function(){
	},afterSearch:function(){
	}}); 
	if(autoApproveRequest){
   		$('#jqgh_myPendingApprovalsResultSet_rn').html('All');
   		$("#jqgh_myPendingApprovalsResultSet_rn").css("margin-right","-2px");
   		$("#jqgh_myPendingApprovalsResultSet_rn").css("margin-top","4px");
   		$("#jqgh_myPendingApprovalsResultSet_rn").css("text-align","right");
   	}
	//Add action button in the title bar
	if(autoApproveRequest){
		var buttonsText = "<div class='title-bar-actions'>";
			buttonsText += "<a type='button' class='btn custom-btn approve-button tooltipLink' href='#' onclick='approveRequestedKols()' rel='tooltip' title='Approve profile request(s)'>Approve</a>";
			buttonsText += "<a  type='button' class='btn custom-btn  reject-button tooltipLink' href='#' onclick='showRejectBox()' rel='tooltip' title='Reject profile request(s)'>Reject</a>";
			buttonsText += "<div class='excelExportIcon sprite_iconSet tooltip-demo' onclick='export_excel(1)'> <a rel='tooltip' href='#' title='Export'>&nbsp;</a></div>";
			buttonsText += "</div>";
		$("#myPendingApprovals .ui-jqgrid-titlebar").append(buttonsText);
	}else{
		//Add action button in the title bar
		var buttonsText = "<div class='title-bar-actions'>";
			buttonsText += "<div class='excelExportIcon sprite_iconSet tooltip-demo' onclick='export_excel(1)'> <a rel='tooltip' href='#' title='Export'>&nbsp;</a></div>";
			buttonsText += "</div>";
		$("#myPendingApprovals .ui-jqgrid-titlebar").append(buttonsText); 
	}
}
function allProfileRequests(){
	jqgridMaxWidth	= 1305;
	$("#allProfileRequests").html("");
	$("#allProfileRequests").html('<table id="allProfileRequestsResultSet"></table><div id="allProfileRequestsPager"></div>');
var type='all';
	jQuery("#allProfileRequestsResultSet").jqGrid({
	   	url:'<?php echo base_url()?>kols/requested_kols/list_user_requests/',
		datatype: "json",
	 	colNames:['Id','','','',statusHeader,nameHeader,requestTypeHeader,organizationHeader,createdByHeader,'',"Requested On",approverHeader,"Approved / Rejected On"],
	   	colModel:[
					{name:'id',index:'id', hidden:true},
					{name:'created_by',index:'created_by', hidden:true},
					{name:'kol_id',index:'kol_id', hidden:true},
					{name:'micro',index:'micro',width:30, search:false },
					{name:'status',index:'status',width:100, resizable:false,title: false},
					{name:'kol_name',index:'kol_name',width:150 },
					{name:'request_type',index:'request_type',width:100},
					{name:'org_name',index:'org_name',width:200},
			   		{name:'user_full_name',index:'user_full_name',width:120, resizable:false},
					{name:'comments',index:'comments',width:100,hidden:true },
					{name:'requested_on',index:'requested_on',width:100 },
					{name:'approver_rejector',index:'approver_rejector',width:150, resizable:false},
					{name:'approved_rejected_on',index:'approved_rejected_on',width:150 }
	   	],
	   	rowNum:10,
	   	rownumbers: true,
		//rownumWidth: 60,
		multiselect: false,
		autowidth: true, 
	   	loadonce:false,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",	
	   	width:"100%",
	   	resizable:true,
	   	shrinkToFit: true,
	   	pager: '#allProfileRequestsPager',
	   	mtype: "POST",
	   	sortname: 'rej_or_appr_on',
	    viewrecords: true,
	    sortorder: "desc",
	    jsonReader: { repeatitems : false, id: "0" }, 
	    caption:allProfRequestTitle,
	   	rowList:[10,20,50,100],
	   	afterInsertRow: function(rowid, aData) {
		   	if(aData.status == 'Rejected'){
		   		jQuery("#allProfileRequestsResultSet").setCell(rowid, 'status', '', '',{ title: "Click to View Reason" });
		   		jQuery("#allProfileRequestsResultSet").setCell(rowid, 'status', '', '',{ onclick: "showRejectREason(this,'"+aData.comments+"');" });
		   	}
		   	else
	    		jQuery("#allProfileRequestsResultSet").setCell(rowid, 'status', '', '',{ title: aData.status });
	    },
	    gridComplete: function(){
	    	var ids = jQuery("#allProfileRequestsResultSet").jqGrid('getDataIDs'); 
    		for(var i=0;i < ids.length;i++){ 
		    	var cl = ids[i];				    	
		    	var rowData = jQuery("#allProfileRequestsResultSet").jqGrid('getRowData', cl);
				    	
		    	microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewKolMicroProfile(this,'"+rowData.kol_id+"',true); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Profile Snapshot\">&nbsp;</a></div></label>";
		    	jQuery("#allProfileRequestsResultSet").jqGrid('setRowData',cl,{micro:microviewLink});
    		} 
	    	jQuery("#allProfileRequestsResultSet").jqGrid('navGrid','hideCol',"id"); 
    	},
    	onSelectAll: function(aRowids,status) {
    		var ids = jQuery("#allProfileRequestsResultSet").jqGrid('getDataIDs'); 
    		for(var i=0;i < ids.length;i++){ 
    			var arrId = jQuery('#allProfileRequestsResultSet').jqGrid ('getRowData', ids[i]);
    			var cl = arrId.id;
    			var rowData = jQuery("#allProfileRequestsResultSet").jqGrid('getRowData', ids[i]);
		    	if(rowData.status=='Approved' || rowData.status=='Profiling' || rowData.status=='Review'){
		    		  var cbs = $("tr.jqgrow > td > input.cbox:disabled",jQuery("#allProfileRequestsResultSet")[0]);
		                cbs.removeAttr("checked");
		                //modify the selarrrow parameter
		                jQuery("#allProfileRequestsResultSet")[0].p.selarrrow = jQuery("#allProfileRequestsResultSet").find("tr.jqgrow:has(td > input.cbox:checked)")
		                    .map(function() { return this.id; }) // convert to set of ids
		                    .get(); // convert to instance of Array
				}
	    	} 
        }
	});
	jQuery("#allProfileRequestsResultSet").jqGrid('navGrid','#allProfileRequestsPager',{edit:false,add:false,del:false,search:false,refresh:false});
	jQuery("#allProfileRequestsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn",beforeSearch: function(){
		$(".ui-search-toolbar input[type='text']").each(function(){
			if($(this).val() == 'Search')
				$(this).val("");
	    });
	},afterSearch:function(){
	}});
	//Add action button in the title bar
	var buttonsText = "<div class='title-bar-actions'>";
		buttonsText += "<div class='excelExportIcon sprite_iconSet' onclick='export_excel(2)' >	<a rel='tooltip' href='#' title='Export'>&nbsp;</a>	</div>";
		buttonsText += "</div>";
	$("#allProfileRequestsGridContainer .ui-jqgrid-titlebar").append(buttonsText); 		
}
</script>