<?php
/**
 * @Desc : Model functions to manipulate database quires from analyst app
 * @Author : Sanjeev K
 * @Since : HMVC Kolm 1.0
 * @Package : application.models
 * @Created : 07-04-2018
 * @Refactored : 08-04-2018
 */
class Master_data_model extends CI_Model {
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : getTitles()
	 * @Action : returns records of 'Titles' Entity
	 */
	function getTitles($limit = null, $startFrom = null, $doCount = null, $sidx = '', $sord = '', $where = '') {
		if (! $doCount) {
			$this->db->select ( array (
					'titles.*' 
			) );
		}
		// Add the where conditions for any jqgrid filters
		if (! $this->common_helper->isDataNull ( $where ['title'] )) {
			$this->db->where ( "(titles.title LIKE '%" . $where ['title'] . "%')" );
		}
		if (! $this->common_helper->isDataNull ( $where ['abbr'] )) {
			$this->db->like ( 'titles.abbr', $where ['abbr'] );
		}
		if (! $this->common_helper->isDataNull ( $where ['client_id'] )) {
			$this->db->like ( 'titles.client_id', $where ['client_id'] );
		}
		if (! $this->common_helper->isDataNull ( $where ['status'] )) {
			$this->db->like ( 'titles.status', $where ['status'] );
		}
		if ($doCount) {
			$this->db->distinct ();
			$count = $this->db->count_all_results ( 'titles' );
			return $count;
		} else {
			if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
				switch ($sidx) {
					case 'title' :
						$this->db->order_by ( "titles.title", $sord );
						break;
					case 'abbr' :
						$this->db->order_by ( "titles.abbr", $sord );
						break;
					case 'client_id' :
						$this->db->order_by ( "titles.client_id", $sord );
						break;
					case 'status' :
						$this->db->order_by ( "titles.status", $sord );
						break;
				}
			}
			$this->db->order_by ( 'title', 'asc' );
			$arrTitleDetail = $this->db->get ( 'titles', $limit, $startFrom );
			return $arrTitleDetail;
		}
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : getTitleDetailsById()
	 * @Action : returns records of 'Titles' Entity where id matches
	 */
	function getTitleDetailsById($id) {
		return $this->db->get_where ( "titles", array (
				"id" => $id 
		) );
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : smartMergeTitle()
	 * @Action : Inserts / Updates 'Titles'
	 */
	function smartMergeTitle($data) {
		$retValue = 0;
		if ($data ['id'] > 0) {
			$this->db->where ( 'id', $data ['id'] );
			$this->db->update ( 'titles', $data );
			$retValue = $data ['id'];
		} else {
			$this->db->insert ( 'titles', $data );
			$retValue = $this->db->insert_id ();
		}
		return $retValue;
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : deleteTitle()
	 * @Action : Deletes 'Titles'
	 */
	function deleteTitle($id) {
		$this->db->where ( 'id', $id );
		return $this->db->delete ( 'titles' );
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : getArrClientIds()
	 * @Action : Returns array of ClientIDS from 'Title Client Mappings' where titleId matches
	 */
	function getArrClientIds($titleId) {
		$this->db->select ( 'group_concat(client_id) as client_ids' );
		$this->db->where ( 'title_id', $titleId );
		$this->db->group_by ( 'title_id' );
		return $this->db->get ( 'title_client_mappings' );
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : getClientDetails()
	 * @Action : Returns Client Details from 'Clients' (if 'id' metches : matched records, else : all records)
	 */
	function getClientDetails($id = null) {
		if (! $this->common_helper->isDataNull ( $id )) {
			$this->db->where ( 'id', $id );
		}
		$resultSet = $this->db->get ( 'clients' );
		return $resultSet->result_array ();
	}
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : saveTitleClientMappings()
	 * @Action : Inserts 'Title Client Mappings' on creating new 'Titles'
	 */
	function saveTitleClientMappings($data) {
		return $this->db->insert ( 'title_client_mappings', $data );
	}
	
	/*
	 * @Author : Kishan Ravindra (00001111)
	 * @Method : deleteTitleClientMappings()
	 * @Action : Removes 'Title Client Mappings' on creating new 'Titles'
	 */
	function deleteTitleClientMappings($data) {
		$this->db->where ( $data );
		return $this->db->delete ( 'title_client_mappings' );
	}
	
	// @Author : Kumaresh
	function checkSpecialty($specialty) {
		$retFlag = false;
		$this->db->where ( 'specialties.specialty', $specialty );
		$query = $this->db->get ( 'specialties' );
		if ($query->num_rows () > 0) {
			$retFlag = true;
		}
		return $retFlag;
	}
	function getSpecClients($specId) {
		$this->db->select ( 'specialty_client_association.client_id' );
		$this->db->where ( 'specialty_client_association.specialty_id', $specId );
		$arrClientsResult = $this->db->get ( 'specialty_client_association' );
		return $arrClientsResult->result_array ();
	}
	function getProductClients($specId) {
		$this->db->select ( 'products_client_visibility.client_id' );
		$this->db->where ( 'products_client_visibility.products_id', $specId );
		$arrClientsResult = $this->db->get ( 'products_client_visibility' );
		return $arrClientsResult->result_array ();
	}
	function getPhoneTypeClients($specId) {
		$this->db->select ( 'phone_type_client_visibility.client_id' );
		$this->db->where ( 'phone_type_client_visibility.phone_type_id', $specId );
		$arrClientsResult = $this->db->get ( 'phone_type_client_visibility' );
		return $arrClientsResult->result_array ();
	}
	function getEmailTypeClients($specId) {
		$this->db->select ( 'emails_client_visibility.client_id' );
		$this->db->where ( 'emails_client_visibility.emails_id', $specId );
		$arrClientsResult = $this->db->get ( 'emails_client_visibility' );
		return $arrClientsResult->result_array ();
	}
	function getDiscussionTypeClients($specId) {
		$this->db->select ( 'interaction_types_client_visibility.client_id' );
		$this->db->where ( 'interaction_types_client_visibility.interaction_types_id', $specId );
		$arrClientsResult = $this->db->get ( 'interaction_types_client_visibility' );
		return $arrClientsResult->result_array ();
	}
	function getTopicClients($specId) {
		$this->db->select ( 'interactions_topics_client_visibility.client_id' );
		$this->db->where ( 'interactions_topics_client_visibility.interactions_topics_id', $specId );
		$arrClientsResult = $this->db->get ( 'interactions_topics_client_visibility' );
		return $arrClientsResult->result_array ();
	}
	function getModeClients($specId) {
		$this->db->select ( 'interactions_modes_client_visibility.client_id' );
		$this->db->where ( 'interactions_modes_client_visibility.interactions_modes_id', $specId );
		$arrClientsResult = $this->db->get ( 'interactions_modes_client_visibility' );
		return $arrClientsResult->result_array ();
	}
	function getLocationTypeClients($specId) {
		$this->db->select ( 'interaction_location_types_client_visibility.client_id' );
		$this->db->where ( 'interaction_location_types_client_visibility.interaction_location_types_id', $specId );
		$arrClientsResult = $this->db->get ( 'interaction_location_types_client_visibility' );
		return $arrClientsResult->result_array ();
	}
	function getRequestedByClients($specId) {
		$this->db->select ( 'payments_requested_by_client_visibility.client_id' );
		$this->db->where ( 'payments_requested_by_client_visibility.requested_by_id', $specId );
		$arrClientsResult = $this->db->get ( 'payments_requested_by_client_visibility' );
		return $arrClientsResult->result_array ();
	}
	function getPaidByClients($specId) {
		$this->db->select ( 'payments_paid_by_client_visibility.client_id' );
		$this->db->where ( 'payments_paid_by_client_visibility.paid_by_id', $specId );
		$arrClientsResult = $this->db->get ( 'payments_paid_by_client_visibility' );
		return $arrClientsResult->result_array ();
	}
	function getPaymentTypeClients($specId) {
		$this->db->select ( 'payment_types_client_visibility.client_id' );
		$this->db->where ( 'payment_types_client_visibility.payment_type', $specId );
		$arrClientsResult = $this->db->get ( 'payment_types_client_visibility' );
		return $arrClientsResult->result_array ();
	}
	function getPaymentCurrencyClients($specId) {
		$this->db->select ( 'payments_currency_client_visibility.client_id' );
		$this->db->where ( 'payments_currency_client_visibility.currency_name', $specId );
		$arrClientsResult = $this->db->get ( 'payments_currency_client_visibility' );
		return $arrClientsResult->result_array ();
	}
	function saveClientSpecialty($table, $data) {
		
		return $status = $this->db->insert ($table, $data);
		//pr($this->db->last_query());exit;
	}
	function deleteClientSpecialty($specialty, $table) {
		switch ($table) {
			case 'specialty_client_association' :
				return $this->db->delete ( $table, array (
						"specialty_id" => $specialty 
				) );
				break;
			case 'products_client_visibility' :
				return $this->db->delete ( $table, array (
						"products_id" => $specialty 
				) );
				break;
			case 'phone_type_client_visibility' :
				return $this->db->delete ( $table, array (
						"phone_type_id" => $specialty 
				) );
				break;
			case 'emails_client_visibility' :
				return $this->db->delete ( $table, array (
						"emails_id" => $specialty 
				) );
				break;
			case 'interaction_types_client_visibility' :
				return $this->db->delete ( $table, array (
						"interaction_types_id" => $specialty 
				) );
				break;
			case 'interactions_topics_client_visibility' :
				return $this->db->delete ( $table, array (
						"interactions_topics_id" => $specialty 
				) );
				break;
			case 'interactions_modes_client_visibility' :
				return $this->db->delete ( $table, array (
						"interactions_modes_id" => $specialty 
				) );
				break;
			case 'interaction_location_types_client_visibility' :
				return $this->db->delete ( $table, array (
						"interaction_location_types_id" => $specialty 
				) );
				break;
			case 'payments_requested_by_client_visibility' :
				return $this->db->delete ( $table, array (
						"requested_by_id" => $specialty 
				) );
				break;
			case 'payments_paid_by_client_visibility' :
				return $this->db->delete ( $table, array (
						"paid_by_id" => $specialty 
				) );
				break;
			case 'payment_types_client_visibility' :
				return $this->db->delete ( $table, array (
						"payment_type" => $specialty 
				) );
				break;
			case 'payments_currency_client_visibility' :
				return $this->db->delete ( $table, array (
						"currency_name" => $specialty 
				) );
				break;
		}
	}
	function specialtyClientAssociation() {
		$clientId = $this->session->userdata ( "client_id" );
		$this->db->select ( 'specialties.specialty' );
		if ($clientId != INTERNAL_CLIENT_ID) {
			$this->db->join ( 'specialty_client_association', 'specialties.id = specialty_client_association.specialty_id', 'inner' );
			$this->db->where ( 'specialty_client_association.client_id', $clientId );
		}
		return $this->db->get ( 'specialties' );
	}
	function getSpecialtyDetails($limit, $startFrom, $sidx = '', $sord = '') {
		$this->db->select ( 'specialties.*' );
		if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
			$this->db->order_by ( "specialties.specialty", $sord );
		}
		$this->db->order_by ( 'specialties.specialty', 'asc' );
		$arrSpecialtyDetails = $this->db->get ( 'specialties', $limit, $startFrom );
		return $arrSpecialtyDetails->result_array ();
	}
	
	/**
	 *
	 * @author : Soumya R S
	 *         @Created : 27-07-2017
	 *        
	 */
	
    // to get list of countries with jqgrid filters applied
    function getCountriesList($start, $limit, $sidx, $sord, $arrFilter, $isCount = false) {
        $this->db->select ( '*' );
        $this->db->from ( 'countries' );
        if (! $this->common_helper->isDataNull ( $arrFilter ['Country'] )) {
            $this->db->like ( 'Country', $arrFilter ['Country'] );
        }
        if (! $this->common_helper->isDataNull ( $arrFilter ['Capital'] )) {
            $this->db->like ( 'Capital', $arrFilter ['Capital'] );
        }
        if (! $this->common_helper->isDataNull ( $arrFilter ['NationalitySingular'] )) {
            $this->db->like ( 'NationalitySingular', $arrFilter ['NationalitySingular'] );
        }
        if (! $this->common_helper->isDataNull ( $arrFilter ['NationalityPlural'] )) {
            $this->db->like ( 'NationalityPlural', $arrFilter ['NationalityPlural'] );
        }
        if (! $this->common_helper->isDataNull ( $arrFilter ['Currency'] )) {
            $this->db->like ( 'Currency', $arrFilter ['Currency'] );
        }
        //$this->db->limit ( $limit );
        $this->db->order_by ( 'CountryId', $sord );
        if (! $isCount) {
            $query = $this->db->get ( '', $limit, $start );
            return $query->result ();
        }
        $query = $this->db->get ();        
        return $query->num_rows ();
    }
	
	// to get list of states with jqgrid filters applied
	function getStatesList($start, $limit, $sidx, $sord, $countryId, $whereResultArray, $isCount = false) {
		$this->db->select ( '*' );
		$this->db->from ( 'regions' );
		if (! $this->common_helper->isDataNull ( $whereResultArray ['Region'] )) {
			$this->db->like ( 'Region', $whereResultArray ['Region'] );
		}
		if (! $this->common_helper->isDataNull ( $whereResultArray ['Code'] )) {
			$this->db->like ( 'Code', $whereResultArray ['Code'] );
		}
		$this->db->where ( 'CountryID', $countryId );
		$this->db->order_by ( 'RegionID', $sord );
		if (! $isCount) {
			$query = $this->db->get ( '', $limit, $start );
			return $query->result ();
		}
		$query = $this->db->get ();
		return $query->num_rows ();
	}
	
// to get list of cities with jqgrid filters applied.
    function getCitiesList($start, $limit, $sidx, $sord, $RegionID, $whereResultArray, $isCount = false) {
        $this->db->select ( '*' );
        $this->db->from ( 'cities' );
        //$this->db->limit ( $limit );
        $this->db->where ( 'RegionID', $RegionID );
        if (! $this->common_helper->isDataNull ( $whereResultArray ['City'] )) {
            $this->db->like ( 'City', $whereResultArray ['City'] );
        }
        if (! $this->common_helper->isDataNull ( $whereResultArray ['Latitude'] )) {
            $this->db->like ( 'Latitude', $whereResultArray ['Latitude'] );
        }
        if (! $this->common_helper->isDataNull ( $whereResultArray ['Longitude'] )) {
            $this->db->like ( 'Longitude', $whereResultArray ['Longitude'] );
        }
        if (! $this->common_helper->isDataNull ( $whereResultArray ['TimeZone'] )) {
            $this->db->like ( 'TimeZone', $whereResultArray ['TimeZone'] );
        }
        if (! $this->common_helper->isDataNull ( $whereResultArray ['Code'] )) {
            $this->db->like ( 'Code', $whereResultArray ['Code'] );
        }
        $this->db->order_by ( 'RegionID', 'ASC' );
        if (! $isCount) {
            $query = $this->db->get ( '', $limit, $start );
            return $query->result ();
        }
        $query = $this->db->get ();
        //pr($this->db->last_query());exit;
        return $query->num_rows ();
    }
	
	// get details of a particular Country,by CountryId.
	function getDetailsById($table, $column_name, $id) {
		$this->db->select ( '*' );
		$this->db->from ( $table );
		$this->db->where ( $column_name, $id );
		$this->db->limit ( 1 );
		$query = $this->db->get ();
		return $query->row ();
	}
	
	// adds a new country details into db
	function checkCountryIfExistElseAdd($arrCountry) {
		$this->db->select ( 'CountryId' );
		$this->db->where ( 'Country', $arrCountry ['Country'] );
		$this->db->limit ( 1 );
		$query = $this->db->get ( 'countries' );
		$result = $query->result_array ();
		$retFlag = false;
		if ($this->common_helper->isDataNull ( $result ['0'] ['CountryId'] )) {
			$retFlag = $this->db->insert ( 'countries', $arrCountry );
		}
		return $retFlag;
	}
	
	// adds state into db
	function checkStateIfExistElseAdd($state, $country, $code = null) {
		$this->db->select ( 'RegionID' );
		$this->db->where ( 'Region', $state );
		$this->db->limit ( 1 );
		$query = $this->db->get ( 'regions' );
		$result = $query->result_array ();
		$retFlag = false;
		if ($this->common_helper->isDataNull ( $result ['0'] ['RegionID'] )) {
			$data = array (
					'CountryID' => $country,
					'Region' => $state,
					'Code' => $code 
			);
			$retFlag = $this->db->insert ( 'regions', $data );
		}
		return $retFlag;
	}
	
	// adds a new city details into db
	function addCity($arrCity) {
		$retFlag = false;
		$this->db->select ( 'CityId' );
		$this->db->where ( 'City', $arrCity ['City'] );
		$this->db->limit ( 1 );
		$query = $this->db->get ( 'cities' );
		$result = $query->result_array ();
		if ($this->common_helper->isDataNull ( $result ['0'] ['CityId'] )) {
			$retFlag = $this->db->insert ( 'cities', $arrCity );
		}
		return $retFlag;
	}
	
	// updates a City/state/country details by its Id
	function update($table, $column_name, $column_value, $arrDetails) {
		$this->db->where ( $column_name, $arrDetails [$column_name] );
		return $this->db->update ( $table, $arrDetails );
	}
	
	// deletes a City/state/country by its Id
	function delete($arraydetails) {
		$this->db->where ( $arraydetails ['column_name'], $arraydetails ['column_value'] );
		return $this->db->delete ( $arraydetails ['table_name'] );
	}
	/**
	 *
	 * @author :kumaresh B
	 *         Returns all Organization Types from 'organization_types' Table
	 */
	function getAllOrganizationTypes($limit, $startFrom, $sidx = '', $sord = '') {
		$this->db->select ( 'organization_types.*' );
		if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
			$this->db->order_by ( "organization_types.type", $sord );
		}
		$this->db->order_by ( 'organization_types.type', 'asc' );
		$arrOrganizationTypesResult = $this->db->get ( 'organization_types', $limit, $startFrom );
		return $arrOrganizationTypesResult->result_array ();
	}
	function checkOrgType($type) {
		$this->db->where ( 'organization_types.type', $type );
		$query = $this->db->get ( 'organization_types' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	function getAllEngagementTypes($limit, $startFrom, $sidx = '', $sord = '') {
		$this->db->select ( 'engagement_types.*' );
		if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
			$this->db->order_by ( "engagement_types.engagement_type", $sord );
		}
		$this->db->order_by ( 'engagement_types.engagement_type', 'asc' );
		$arrEngagementTypesResult = $this->db->get ( 'engagement_types', $limit, $startFrom );
		return $arrEngagementTypesResult->result_array ();
	}
	function checkEngType($type) {
		$this->db->where ( 'engagement_types.engagement_type', $type );
		$query = $this->db->get ( 'engagement_types' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	// merge specialties--------------------------------------------------------------------------------------------
	function mergeSpecialty($old_specialty_id, $new_specialty_id) {
		// pr($old_specialty_id);exit;
		foreach ( $old_specialty_id as $key => $value ) {
			$this->db->set ( 'kols.specialty', $new_specialty_id );
			$this->db->where ( 'kols.specialty', $value ["specialty_id"] );
			$status = $this->db->update ( "kols" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		
		foreach ( $old_specialty_id as $key => $value ) {
			$this->db->set ( 'specialty_client_association.specialty_id', $new_specialty_id );
			$this->db->where ( 'specialty_client_association.specialty_id', $value ["specialty_id"] );
			$status = $this->db->update ( "specialty_client_association" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		
		foreach ( $old_specialty_id as $key => $value ) {
			$this->db->set ( 'kol_sub_specialty.kol_sub_specialty_id', $new_specialty_id );
			$this->db->where ( 'kol_sub_specialty.kol_sub_specialty_id', $value ["specialty_id"] );
			$status = $this->db->update ( "kol_sub_specialty" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		
		foreach ( $old_specialty_id as $key => $value ) {
			$this->db->set ( 'organizations.specialty', $new_specialty_id );
			$this->db->where ( 'organizations.specialty', $value ["specialty_id"] );
			$status = $this->db->update ( "organizations" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		
		foreach ( $old_specialty_id as $key => $value ) {
			$this->db->set ( 'interactions_other_attendees.specialty_id', $new_specialty_id );
			$this->db->where ( 'interactions_other_attendees.specialty_id', $value ["specialty_id"] );
			$status = $this->db->update ( "interactions_other_attendees" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		
		foreach ( $old_specialty_id as $key => $value ) {
			$this->db->set ( 'interactions_attendees.specialty_id', $new_specialty_id );
			$this->db->where ( 'interactions_attendees.specialty_id', $value ["specialty_id"] );
			$status = $this->db->update ( "interactions_attendees" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		
		foreach ( $old_specialty_id as $key => $value ) {
			$this->db->set ( 'event_topics.specialty_id', $new_specialty_id );
			$this->db->where ( 'event_topics.specialty_id', $value ["specialty_id"] );
			$status = $this->db->update ( "event_topics" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		
		foreach ( $old_specialty_id as $key => $value ) {
			$this->db->set ( 'coachings.specialty', $new_specialty_id );
			$this->db->where ( 'coachings.specialty', $value ["specialty_id"] );
			$status = $this->db->update ( "coachings" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		
		foreach ( $old_specialty_id as $key => $value ) {
			
			$this->db->set ( 'additional_contacts.specialty_id', $new_specialty_id );
			$this->db->where ( 'additional_contacts.specialty_id', $value ["specialty_id"] );
			$status = $this->db->update ( "additional_contacts" );
			// echo $this->db->last_query();
			
			if (! $status)
				return false;
		}
		return true;
	}
	function setMerging($old_specialty_id) {
		foreach ( $old_specialty_id as $key => $value ) {
			$this->db->set ( 'specialties.keys_merged', 'YES' );
			$this->db->where ( 'specialties.id', $value ["specialty_id"] );
			$status = $this->db->update ( "specialties" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergeOrgTypes($old_orgtype_id) {
		foreach ( $old_orgtype_id as $key => $value ) {
			$this->db->set ( 'organization_types.keys_merged', 'YES' );
			$this->db->where ( 'organization_types.id', $value ["orgtype_id"] );
			$status = $this->db->update ( "organization_types" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergeEngTypes($old_engtype_id) {
		foreach ( $old_engtype_id as $key => $value ) {
			$this->db->set ( 'engagement_types.keys_merged', 'YES' );
			$this->db->where ( 'engagement_types.id', $value ["engtype_id"] );
			$status = $this->db->update ( "engagement_types" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergeEventTopics($old_eventtopic_id) {
		foreach ( $old_eventtopic_id as $key => $value ) {
			$this->db->set ( 'event_topics.keys_merged', 'YES' );
			$this->db->where ( 'event_topics.id', $value ["eventtopic_id"] );
			$status = $this->db->update ( "event_topics" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergeEventOrganizerTypes($old_eventorgtype_id) {
		foreach ( $old_eventorgtype_id as $key => $value ) {
			$this->db->set ( 'event_organizer_types.keys_merged', 'YES' );
			$this->db->where ( 'event_organizer_types.id', $value ["eventorgtype_id"] );
			$status = $this->db->update ( "event_organizer_types" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergeEventRoles($old_eventrole_id) {
		foreach ( $old_eventrole_id as $key => $value ) {
			$this->db->set ( 'event_roles.keys_merged', 'YES' );
			$this->db->where ( 'event_roles.id', $value ["eventrole_id"] );
			$status = $this->db->update ( "event_roles" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergeTitles($old_title_id) {
		foreach ( $old_title_id as $key => $value ) {
			$this->db->set ( 'titles.keys_merged', 'YES' );
			$this->db->where ( 'titles.id', $value ["title_id"] );
			$status = $this->db->update ( "titles" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergeProducts($old_product_id) {
		foreach ( $old_product_id as $key => $value ) {
			$this->db->set ( 'products.keys_merged', 'YES' );
			$this->db->where ( 'products.id', $value ["product_id"] );
			$status = $this->db->update ( "products" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergePhoneTypes($old_phonetype_id) {
		foreach ( $old_phonetype_id as $key => $value ) {
			$this->db->set ( 'phone_type.keys_merged', 'YES' );
			$this->db->where ( 'phone_type.id', $value ["phonetype_id"] );
			$status = $this->db->update ( "phone_type" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergeEmailTypes($old_emailType_id) {
		foreach ( $old_emailType_id as $key => $value ) {
			$this->db->set ( 'emails.keys_merged', 'YES' );
			$this->db->where ( 'emails.id', $value ["emailtype_id"] );
			$status = $this->db->update ( "emails" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergeDiscussionTypes($old_discussionType_id) {
		foreach ( $old_discussionType_id as $key => $value ) {
			$this->db->set ( 'interaction_types.keys_merged', 'YES' );
			$this->db->where ( 'interaction_types.id', $value ["discussion_type_id"] );
			$status = $this->db->update ( "interaction_types" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergeTopics($old_topic_id) {
		foreach ( $old_topic_id as $key => $value ) {
			$this->db->set ( 'interactions_topics.keys_merged', 'YES' );
			$this->db->where ( 'interactions_topics.id', $value ["topic_id"] );
			$status = $this->db->update ( "interactions_topics" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergeInteractionTypes($old_interactionType_id) {
		foreach ( $old_interactionType_id as $key => $value ) {
			$this->db->set ( 'interactions_modes.keys_merged', 'YES' );
			$this->db->where ( 'interactions_modes.id', $value ["interactin_type_id"] );
			$status = $this->db->update ( "interactions_modes" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergeInteractionLocation($old_interactionLocation_id) {
		foreach ( $old_interactionLocation_id as $key => $value ) {
			$this->db->set ( 'interaction_location_types.keys_merged', 'YES' );
			$this->db->where ( 'interaction_location_types.id', $value ["interactin_location_id"] );
			$status = $this->db->update ( "interaction_location_types" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergePaymentRequestedBy($old_requestedBy_id) {
		foreach ( $old_requestedBy_id as $key => $value ) {
			$this->db->set ( 'payments_requested_by.keys_merged', 'YES' );
			$this->db->where ( 'payments_requested_by.id', $value ["requested_by_id"] );
			$status = $this->db->update ( "payments_requested_by" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergePaymentPaidBy($old_paidBy_id) {
		foreach ( $old_paidBy_id as $key => $value ) {
			$this->db->set ( 'payments_paid_by.keys_merged', 'YES' );
			$this->db->where ( 'payments_paid_by.id', $value ["paid_by_id"] );
			$status = $this->db->update ( "payments_paid_by" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergePaymentType($old_paymentType_id) {
		foreach ( $old_paymentType_id as $key => $value ) {
			$this->db->set ( 'payment_types.keys_merged', 'YES' );
			$this->db->where ( 'payment_types.id', $value ["type_id"] );
			$status = $this->db->update ( "payment_types" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergePaymentCurrency($old_currency_id) {
		foreach ( $old_currency_id as $key => $value ) {
			$this->db->set ( 'payments_currency.keys_merged', 'YES' );
			$this->db->where ( 'payments_currency.id', $value ["currency_id"] );
			$status = $this->db->update ( "payments_currency" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergeEventTypes($old_eventType_id) {
		foreach ( $old_eventType_id as $key => $value ) {
			$this->db->set ( 'conf_event_types.keys_merged', 'YES' );
			$this->db->where ( 'conf_event_types.id', $value ["event_type_id"] );
			$status = $this->db->update ( "conf_event_types" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergeSponsorTypes($old_sponsorType_id) {
		foreach ( $old_sponsorType_id as $key => $value ) {
			$this->db->set ( 'event_sponsor_types.keys_merged', 'YES' );
			$this->db->where ( 'event_sponsor_types.id', $value ["sponsor_type_id"] );
			$status = $this->db->update ( "event_sponsor_types" );
			if (! $status)
				return false;
		}
		return true;
	}
	function setMergeSessionTypes($old_sessionType_id) {
		foreach ( $old_sessionType_id as $key => $value ) {
			$this->db->set ( 'conf_session_types.keys_merged', 'YES' );
			$this->db->where ( 'conf_session_types.id', $value ["session_type_id"] );
			$status = $this->db->update ( "conf_session_types" );
			if (! $status)
				return false;
		}
		return true;
	}
	// save multiple clients
	function saveMultipleClients($arrData, $table) {
		// pr($arrData);exit;
		foreach ( $arrData as $data ) {
			$status = $this->db->insert ( $table, $data );
		}
		return $status;
	}
	// get all event topics
	function getAllEventTopics($limit, $startFrom, $sidx = '', $sord = '') {
		$this->db->select ( 'event_topics.*' );
		if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
			$this->db->order_by ( "event_topics.name", $sord );
		}
		$this->db->order_by ( 'event_topics.name', 'asc' );
		$arrEventTopicsResult = $this->db->get ( 'event_topics', $limit, $startFrom );
		return $arrEventTopicsResult->result_array ();
	}
	// check the event_topic is present or not
	function checkEventTopics($topic) {
		$this->db->where ( 'event_topics.name', $topic );
		$query = $this->db->get ( 'event_topics' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	// get all event organizer_types
	function getAllEventOrganizerTypes($limit, $startFrom, $sidx = '', $sord = '') {
		$this->db->select ( 'event_organizer_types.*' );
		if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
			$this->db->order_by ( "event_organizer_types.type", $sord );
		}
		$this->db->order_by ( 'event_organizer_types.type', 'asc' );
		$arrEventTopicsResult = $this->db->get ( 'event_organizer_types', $limit, $startFrom );
		return $arrEventTopicsResult->result_array ();
	}
	// check the event organizer_type is present or not
	function checkEventOrgTypes($type) {
		$this->db->where ( 'event_organizer_types.type', $type );
		$query = $this->db->get ( 'event_organizer_types' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	// get all event roles
	function getAllEventRoles($limit, $startFrom, $sidx = '', $sord = '') {
		$this->db->select ( 'event_roles.*' );
		if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
			$this->db->order_by ( "event_roles.role", $sord );
		}
		$this->db->order_by ( 'event_roles.role', 'asc' );
		$arrEventTopicsResult = $this->db->get ( 'event_roles', $limit, $startFrom );
		return $arrEventTopicsResult->result_array ();
	}
	// check the event role is present or not
	function checkEventRole($role) {
		$this->db->where ( 'event_roles.role', $role );
		$query = $this->db->get ( 'event_roles' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	// block the user
	function blockUser($id) {
		$this->db->where_in ( "id", $id );
		$this->db->set ( "client_users.failed_attempts", 9 );
		if ($this->db->update ( "client_users" ))
			return true;
		else
			return false;
	}
	// unblock the user
	function unBlockUser($id) {
		$this->db->where_in ( "id", $id );
		$this->db->set ( "client_users.failed_attempts", 0 );
		if ($this->db->update ( "client_users" ))
			return true;
		else
			return false;
	}
	function getStatus($id) {
		$this->db->select ( "client_users.failed_attempts" );
		$this->db->where_in ( "id", $id );
		$arr = $this->db->get ( "client_users" );
		return $arr->result_array ();
	}
	function getSpec($new_specialty_id) {
		$this->db->select ( 'specialties.specialty' );
		$this->db->where ( 'specialties.id', $new_specialty_id );
		$spec = $this->db->get ( "specialties" );
		return $spec;
	}
	// load different pages such as Specialties , Organization_Types etc
	function loadTypes($arrData) {
		// pr($arrData);exit;
		$arrReturnData = array ();
		switch ($arrData ['type']) {
			case 'Specialties' :
				$this->db->select ( 'specialties.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "specialties.specialty", $sord );
				}
				$this->db->order_by ( 'specialties.specialty', 'asc' );
				$arrReturnData = $this->db->get ( 'specialties', $limit, $startFrom );
				// return $arrSpecialtyDetails->result_array();
				break;
			case 'Organization_Types' :
				$this->db->select ( 'organization_types.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "organization_types.type", $sord );
				}
				$this->db->order_by ( 'organization_types.type', 'asc' );
				$arrReturnData = $this->db->get ( 'organization_types', $limit, $startFrom );
				break;
			case 'Engagement_Types' :
				$this->db->select ( 'engagement_types.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "engagement_types.engagement_type", $sord );
				}
				$this->db->order_by ( 'engagement_types.engagement_type', 'asc' );
				$arrReturnData = $this->db->get ( 'engagement_types', $limit, $startFrom );
				break;
			case 'Event_Topics' :
				$this->db->select ( 'event_topics.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "event_topics.name", $sord );
				}
				$this->db->order_by ( 'event_topics.name', 'asc' );
				$arrReturnData = $this->db->get ( 'event_topics', $limit, $startFrom );
				break;
			case 'Event_Org_Types' :
				$this->db->select ( 'event_organizer_types.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "event_organizer_types.type", $sord );
				}
				$this->db->order_by ( 'event_organizer_types.type', 'asc' );
				$arrReturnData = $this->db->get ( 'event_organizer_types', $limit, $startFrom );
				break;
			case 'Event_Roles' :
				$this->db->select ( 'event_roles.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "event_roles.role", $sord );
				}
				$this->db->order_by ( 'event_roles.role', 'asc' );
				$arrReturnData = $this->db->get ( 'event_roles', $limit, $startFrom );
				break;
			case 'Titles' :
				$this->db->select ( 'titles.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "titles.title", $sord );
				}
				$this->db->order_by ( 'titles.title', 'asc' );
				$arrReturnData = $this->db->get ( 'titles', $limit, $startFrom );
				break;
			case 'Phone_Type' :
				$this->db->select ( 'phone_type.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "phone_type.name", $sord );
				}
				$this->db->order_by ( 'phone_type.name', 'asc' );
				$arrReturnData = $this->db->get ( 'phone_type', $limit, $startFrom );
				break;
			case 'Product' :
				$this->db->select ( 'products.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "products.name", $sord );
				}
				$this->db->order_by ( 'products.name', 'asc' );
				$arrReturnData = $this->db->get ( 'products', $limit, $startFrom );
				break;
			case 'Email_Type' :
				$this->db->select ( 'emails.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "emails.type", $sord );
				}
				$this->db->order_by ( 'emails.type', 'asc' );
				$arrReturnData = $this->db->get ( 'emails', $limit, $startFrom );
				break;
			case 'Discussion_Type' :
				$this->db->select ( 'interaction_types.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "interaction_types.name", $sord );
				}
				$this->db->order_by ( 'interaction_types.name', 'asc' );
				$arrReturnData = $this->db->get ( 'interaction_types', $limit, $startFrom );
				break;
			case 'Topics' :
				$this->db->select ( 'interactions_topics.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "interactions_topics.name", $sord );
				}
				$this->db->order_by ( 'interactions_topics.name', 'asc' );
				$arrReturnData = $this->db->get ( 'interactions_topics', $limit, $startFrom );
				break;
			case 'Interaction_Type' :
				$this->db->select ( 'interactions_modes.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "interactions_modes.name", $sord );
				}
				$this->db->order_by ( 'interactions_modes.name', 'asc' );
				$arrReturnData = $this->db->get ( 'interactions_modes', $limit, $startFrom );
				break;
			case 'Interaction_Location' :
				$this->db->select ( 'interaction_location_types.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "interaction_location_types.name", $sord );
				}
				$this->db->order_by ( 'interaction_location_types.name', 'asc' );
				$arrReturnData = $this->db->get ( 'interaction_location_types', $limit, $startFrom );
				break;
			case 'Requested_By' :
				$this->db->select ( 'payments_requested_by.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "payments_requested_by.requested_by", $sord );
				}
				$this->db->order_by ( 'payments_requested_by.requested_by', 'asc' );
				$arrReturnData = $this->db->get ( 'payments_requested_by', $limit, $startFrom );
				break;
			case 'Paid_By' :
				$this->db->select ( 'payments_paid_by.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "payments_paid_by.paid_by", $sord );
				}
				$this->db->order_by ( 'payments_paid_by.paid_by', 'asc' );
				$arrReturnData = $this->db->get ( 'payments_paid_by', $limit, $startFrom );
				break;
			case 'Payment_Type' :
				$this->db->select ( 'payment_types.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "payment_types.name", $sord );
				}
				$this->db->order_by ( 'payment_types.name', 'asc' );
				$arrReturnData = $this->db->get ( 'payment_types', $limit, $startFrom );
				break;
			case 'Payment_Currency' :
				$this->db->select ( 'payments_currency.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "payments_currency.currency_name", $sord );
				}
				$this->db->order_by ( 'payments_currency.currency_name', 'asc' );
				$arrReturnData = $this->db->get ( 'payments_currency', $limit, $startFrom );
				break;
			case 'conf_event_types' :
				$this->db->select ( 'conf_event_types.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "conf_event_types.event_type", $sord );
				}
				$this->db->order_by ( 'conf_event_types.event_type', 'asc' );
				$arrReturnData = $this->db->get ( 'conf_event_types', $limit, $startFrom );
				break;
			case 'event_sponsor_types' :
				$this->db->select ( 'event_sponsor_types.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "event_sponsor_types.type", $sord );
				}
				$this->db->order_by ( 'event_sponsor_types.type', 'asc' );
				$arrReturnData = $this->db->get ( 'event_sponsor_types', $limit, $startFrom );
				break;
			case 'conf_session_types' :
				$this->db->select ( 'conf_session_types.*' );
				if (! $this->common_helper->isDataNull ( $sidx ) && ! $this->common_helper->isDataNull ( $sord )) {
					$this->db->order_by ( "conf_session_types.session_type", $sord );
				}
				$this->db->order_by ( 'conf_session_types.session_type', 'asc' );
				$arrReturnData = $this->db->get ( 'conf_session_types', $limit, $startFrom );
				break;
		}
		return $arrReturnData->result_array ();
	}
	// merge organization types
	function mergeOrgTypes($old_orgtype_id, $new_orgtype_id) {
		// pr($new_orgtype_id);exit;
		foreach ( $old_orgtype_id as $key => $value ) {
			$this->db->set ( 'organizations.type_id', $new_orgtype_id );
			$this->db->where ( 'organizations.type_id', $value ["orgtype_id"] );
			$status = $this->db->update ( "organizations" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		return true;
	}
	
	// merge engagement types
	function mergeEngTypes($old_engtype_id, $new_engtype_id) {
		// pr($old_engtype_id);exit;
		foreach ( $old_engtype_id as $key => $value ) {
			$this->db->set ( 'kol_memberships.engagement_id', $new_engtype_id );
			$this->db->where ( 'kol_memberships.engagement_id', $value ["engtype_id"] );
			$status = $this->db->update ( "kol_memberships" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		return true;
	}
	
	// merge event topics
	function mergeEventTopics($old_eventtopic_id, $new_eventtopic_id) {
		// pr($old_eventtopic_id);exit;
		foreach ( $old_eventtopic_id as $key => $value ) {
			$this->db->set ( 'kol_events.topic', $new_eventtopic_id );
			$this->db->where ( 'kol_events.topic', $value ["eventtopic_id"] );
			$status = $this->db->update ( "kol_events" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		return true;
	}
	// merge event organizer type
	function mergeEventOrganizerTypes($old_eventorgtype_id, $new_eventorgtype_id) {
		// pr($old_eventorgtype_id);exit;
		foreach ( $old_eventorgtype_id as $key => $value ) {
			$this->db->set ( 'kol_events.organizer_type', $new_eventorgtype_id );
			$this->db->where ( 'kol_events.organizer_type', $value ["eventorgtype_id"] );
			$status = $this->db->update ( "kol_events" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		return true;
	}
	// merge event role
	function mergeEventRoles($old_eventrole_id, $new_eventrole_id) {
		// pr($old_eventrole_id);exit;
		foreach ( $old_eventrole_id as $key => $value ) {
			$this->db->set ( 'key_peoples.role_id', $new_eventrole_id );
			$this->db->where ( 'key_peoples.role_id', $value ["eventrole_id"] );
			$status = $this->db->update ( "key_peoples" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		return true;
	}
	// merge title
	function mergeTitles($old_title_id, $new_title_id) {
		// pr($old_title_id);exit;
		foreach ( $old_title_id as $key => $value ) {
			$this->db->set ( 'kol_locations.title', $new_title_id );
			$this->db->where ( 'kol_locations.title', $value ["title_id"] );
			$status = $this->db->update ( "kol_locations" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		
		foreach ( $old_title_id as $key => $value ) {
			$this->db->set ( 'title_client_mappings.title_id', $new_title_id );
			$this->db->where ( 'title_client_mappings.title_id', $value ["title_id"] );
			$status = $this->db->update ( "title_client_mappings" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		return true;
	}
	function getAllTitles() {
		$this->db->select ( "titles.*" );
		$arr = $this->db->get ( "titles" );
		return $arr->result_array ();
	}
	// check the product is present or not
	function checkProduct($product) {
		$this->db->where ( 'products.name', $product );
		$query = $this->db->get ( 'products' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	// check the phone type is present or not
	function checkPhoneType($phoneType) {
		$this->db->where ( 'phone_type.name', $phoneType );
		$query = $this->db->get ( 'phone_type' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	// check the email type is present or not
	function checkEmailType($emailType) {
		$this->db->where ( 'emails.type', $emailType );
		$query = $this->db->get ( 'emails' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	// get all products
	function getAllProducts() {
		$this->db->select ( "products.*" );
		$arr = $this->db->get ( "products" );
		return $arr->result_array ();
	}
	// check the discussion type is present or not
	function checkDiscussionType($discussionType) {
		$this->db->where ( 'interaction_types.name', $discussionType );
		$query = $this->db->get ( 'interaction_types' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	// check the topic is present or not
	function checkTopic($topic) {
		$this->db->where ( 'interactions_topics.name', $topic );
		$query = $this->db->get ( 'interactions_topics' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	// check the interaction type is present or not
	function checkInteractionType($interactionType) {
		$this->db->where ( 'interactions_modes.name', $interactionType );
		$query = $this->db->get ( 'interactions_modes' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	// check the interaction location is present or not
	function checkInteractionLocation($interactionLocation) {
		$this->db->where ( 'interaction_location_types.name', $interactionLocation );
		$query = $this->db->get ( 'interaction_location_types' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	// check the requested by is present or not
	function checkRequestedBy($requestedBy) {
		$this->db->where ( 'payments_requested_by.requested_by', $requestedBy );
		$query = $this->db->get ( 'payments_requested_by' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	// check the payment paid by is present or not
	function checkPaidBy($paidBy) {
		$this->db->where ( 'payments_paid_by.paid_by', $paidBy );
		$query = $this->db->get ( 'payments_paid_by' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	// check the payment type is present or not
	function checkPaymentType($paymentType) {
		$this->db->where ( 'payment_types.name', $paymentType );
		$query = $this->db->get ( 'payment_types' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	// check the payment currency is present or not
	function checkPaymentCurrency($paymentCurrency) {
		$this->db->where ( 'payments_currency.currency_name', $paymentCurrency );
		$query = $this->db->get ( 'payments_currency' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	// save data
	function saveMasterData($table, $data) {
		// pr($data);exit;
		$status = false;
		if ($data ['id'] > 0) {
			$this->db->where ( "id", $data ['id'] );
			$status = $this->db->update ( $table, $data );
		} else {
			$this->db->insert ( $table, $data );
			$status = $this->db->insert_id ();
		}
		return $status;
	}
	// delete data
	function deleteMasterData($table, $id) {
		return $this->db->delete ( $table, array (
				"id" => $id 
		) );
	}
	// merge products
	function mergeProducts($old_product_id, $new_product_id) {
		// pr($new_product_id);exit;
		foreach ( $old_product_id as $key => $value ) {
			$this->db->set ( 'ol_speaker_product.product_id', $new_product_id );
			$this->db->where ( 'ol_speaker_product.product_id', $value ["product_id"] );
			$status = $this->db->update ( "ol_speaker_product" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_product_id as $key => $value ) {
			$this->db->set ( 'kol_products.product_id', $new_product_id );
			$this->db->where ( 'kol_products.product_id', $value ["product_id"] );
			$status = $this->db->update ( "kol_products" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_product_id as $key => $value ) {
			$this->db->set ( 'topics_by_prod_type$.product_id', $new_product_id );
			$this->db->where ( 'topics_by_prod_type$.product_id', $value ["product_id"] );
			$status = $this->db->update ( "topics_by_prod_type$" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_product_id as $key => $value ) {
			$this->db->set ( 'interaction_type_by_product.product_id', $new_product_id );
			$this->db->where ( 'interaction_type_by_product.product_id', $value ["product_id"] );
			$status = $this->db->update ( "interaction_type_by_product" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_product_id as $key => $value ) {
			$this->db->set ( 'interaction_topics_by_type.product_id', $new_product_id );
			$this->db->where ( 'interaction_topics_by_type.product_id', $value ["product_id"] );
			$status = $this->db->update ( "interaction_topics_by_type" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_product_id as $key => $value ) {
			$this->db->set ( 'interaction_sub_topics_association.product_id', $new_product_id );
			$this->db->where ( 'interaction_sub_topics_association.product_id', $value ["product_id"] );
			$status = $this->db->update ( "interaction_sub_topics_association" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_product_id as $key => $value ) {
			$this->db->set ( 'interactions_discussion_topic_mapped_data.product_id', $new_product_id );
			$this->db->where ( 'interactions_discussion_topic_mapped_data.product_id', $value ["product_id"] );
			$status = $this->db->update ( "interactions_discussion_topic_mapped_data" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_product_id as $key => $value ) {
			$this->db->set ( 'interactions_topic_mapped_data.product_id', $new_product_id );
			$this->db->where ( 'interactions_topic_mapped_data.product_id', $value ["product_id"] );
			$status = $this->db->update ( "interactions_topic_mapped_data" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_product_id as $key => $value ) {
			$this->db->set ( 'interaction_topic_mapping.product_id', $new_product_id );
			$this->db->where ( 'interaction_topic_mapping.product_id', $value ["product_id"] );
			$status = $this->db->update ( "interaction_topic_mapping" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_product_id as $key => $value ) {
			$this->db->set ( 'products_client_visibility.products_id', $new_product_id );
			$this->db->where ( 'products_client_visibility.products_id', $value ["product_id"] );
			$status = $this->db->update ( "products_client_visibility" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		return true;
	}
	// merge phone type
	function mergePhoneTypes($old_phonetype_id, $new_phonetype_id) {
		// pr($new_phonetype_id);exit;
		foreach ( $old_phonetype_id as $key => $value ) {
			$this->db->set ( 'staffs.phone_type', $new_phonetype_id );
			$this->db->where ( 'staffs.phone_type', $value ["phonetype_id"] );
			$status = $this->db->update ( "staffs" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_phonetype_id as $key => $value ) {
			$this->db->set ( 'phone_type_client_visibility.phone_type_id', $new_phonetype_id );
			$this->db->where ( 'phone_type_client_visibility.phone_type_id', $value ["phonetype_id"] );
			$status = $this->db->update ( "phone_type_client_visibility" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		return true;
	}
	// merge email type
	function mergeEmailTypes($old_emailType_id, $new_emailType_id) {
		// pr($old_emailType_id);exit;
		foreach ( $old_emailType_id as $key => $value ) {
			$this->db->set ( 'contact_restrictions.email', $new_emailType_id );
			$this->db->where ( 'contact_restrictions.email', $value ["emailtype_id"] );
			$status = $this->db->update ( "contact_restrictions" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_emailType_id as $key => $value ) {
			$this->db->set ( 'emails_client_visibility.emails_id', $new_emailType_id );
			$this->db->where ( 'emails_client_visibility.emails_id', $value ["emailtype_id"] );
			$status = $this->db->update ( "emails_client_visibility" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		return true;
	}
	// merge discussion type
	function mergeDiscussionTypes($old_discussionType_id, $new_discussionType_id) {
		// pr($new_discussionType_id);exit;
		foreach ( $old_discussionType_id as $key => $value ) {
			$this->db->set ( 'interaction_sub_topics_association.type_id', $new_discussionType_id );
			$this->db->where ( 'interaction_sub_topics_association.type_id', $value ["discussion_type_id"] );
			$status = $this->db->update ( "interaction_sub_topics_association" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_discussionType_id as $key => $value ) {
			$this->db->set ( 'topics_by_prod_type$.type_id', $new_discussionType_id );
			$this->db->where ( 'topics_by_prod_type$.type_id', $value ["discussion_type_id"] );
			$status = $this->db->update ( "topics_by_prod_type$" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_discussionType_id as $key => $value ) {
			$this->db->set ( 'interaction_topics_by_type.type_id', $new_discussionType_id );
			$this->db->where ( 'interaction_topics_by_type.type_id', $value ["discussion_type_id"] );
			$status = $this->db->update ( "interaction_topics_by_type" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_discussionType_id as $key => $value ) {
			$this->db->set ( 'interaction_topic_mapping.interaction_type_id', $new_discussionType_id );
			$this->db->where ( 'interaction_topic_mapping.interaction_type_id', $value ["discussion_type_id"] );
			$status = $this->db->update ( "interaction_topic_mapping" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_discussionType_id as $key => $value ) {
			$this->db->set ( 'interaction_type_by_product.type_id', $new_discussionType_id );
			$this->db->where ( 'interaction_type_by_product.type_id', $value ["discussion_type_id"] );
			$status = $this->db->update ( "interaction_type_by_product" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_discussionType_id as $key => $value ) {
			$this->db->set ( 'interactions_discussion_topic_mapped_data.interaction_type', $new_discussionType_id );
			$this->db->where ( 'interactions_discussion_topic_mapped_data.interaction_type', $value ["discussion_type_id"] );
			$status = $this->db->update ( "interactions_discussion_topic_mapped_data" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_discussionType_id as $key => $value ) {
			$this->db->set ( 'interaction_types_client_visibility.interaction_types_id', $new_discussionType_id );
			$this->db->where ( 'interaction_types_client_visibility.interaction_types_id', $value ["discussion_type_id"] );
			$status = $this->db->update ( "interaction_types_client_visibility" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		return true;
	}
	// merge interaction topics
	function mergeTopics($old_topic_id, $new_topic_id) {
		// pr($old_topic_id);exit;
		foreach ( $old_topic_id as $key => $value ) {
			$this->db->set ( 'interactions_about.topic_id', $new_topic_id );
			$this->db->where ( 'interactions_about.topic_id', $value ["topic_id"] );
			$status = $this->db->update ( "interactions_about" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_topic_id as $key => $value ) {
			$this->db->set ( 'interactions_discussion_topic_mapped_data.topic_id', $new_topic_id );
			$this->db->where ( 'interactions_discussion_topic_mapped_data.topic_id', $value ["topic_id"] );
			$status = $this->db->update ( "interactions_discussion_topic_mapped_data" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_topic_id as $key => $value ) {
			$this->db->set ( 'interactions_topic_mapped_data.topic_id', $new_topic_id );
			$this->db->where ( 'interactions_topic_mapped_data.topic_id', $value ["topic_id"] );
			$status = $this->db->update ( "interactions_topic_mapped_data" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_topic_id as $key => $value ) {
			$this->db->set ( 'interaction_sub_topics_association.topic_id', $new_topic_id );
			$this->db->where ( 'interaction_sub_topics_association.topic_id', $value ["topic_id"] );
			$status = $this->db->update ( "interaction_sub_topics_association" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_topic_id as $key => $value ) {
			$this->db->set ( 'interaction_topics_by_type.topic_id', $new_topic_id );
			$this->db->where ( 'interaction_topics_by_type.topic_id', $value ["topic_id"] );
			$status = $this->db->update ( "interaction_topics_by_type" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_topic_id as $key => $value ) {
			$this->db->set ( 'interaction_topic_mapping.topic_id', $new_topic_id );
			$this->db->where ( 'interaction_topic_mapping.topic_id', $value ["topic_id"] );
			$status = $this->db->update ( "interaction_topic_mapping" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_topic_id as $key => $value ) {
			$this->db->set ( 'topics_by_prod_type$.topic_id', $new_topic_id );
			$this->db->where ( 'topics_by_prod_type$.topic_id', $value ["topic_id"] );
			$status = $this->db->update ( "topics_by_prod_type$" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_topic_id as $key => $value ) {
			$this->db->set ( 'interactions_topics_client_visibility.interactions_topics_id', $new_topic_id );
			$this->db->where ( 'interactions_topics_client_visibility.interactions_topics_id', $value ["topic_id"] );
			$status = $this->db->update ( "interactions_topics_client_visibility" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		return true;
	}
	// merge interaction type
	function mergeInteractionTypes($old_interactionType_id, $new_interactionType_id) {
		// pr($old_interactionType_id);exit;
		foreach ( $old_interactionType_id as $key => $value ) {
			$this->db->set ( 'interactions.mode', $new_interactionType_id );
			$this->db->where ( 'interactions.mode', $value ["interactin_type_id"] );
			$status = $this->db->update ( "interactions" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_interactionType_id as $key => $value ) {
			$this->db->set ( 'interactions_modes_client_visibility.interactions_modes_id', $new_interactionType_id );
			$this->db->where ( 'interactions_modes_client_visibility.interactions_modes_id', $value ["interactin_type_id"] );
			$status = $this->db->update ( "interactions_modes_client_visibility" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		return true;
	}
	// merge interaction location
	function mergeInteractionLocation($old_interactionLocation_id, $new_interactionLocation_id) {
		// pr($old_interactionLocation_id);exit;
		foreach ( $old_interactionLocation_id as $key => $value ) {
			$this->db->set ( 'interactions.location_type', $new_interactionLocation_id );
			$this->db->where ( 'interactions.location_type', $value ["interactin_location_id"] );
			$status = $this->db->update ( "interactions" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_interactionLocation_id as $key => $value ) {
			$this->db->set ( 'interaction_location_types_client_visibility.interaction_location_types_id', $new_interactionLocation_id );
			$this->db->where ( 'interaction_location_types_client_visibility.interaction_location_types_id', $value ["interactin_location_id"] );
			$status = $this->db->update ( "interaction_location_types_client_visibility" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		return true;
	}
	// merge payment requested by
	function mergePaymentRequestedBy($old_requestedBy_id, $new_requestedBy_id) {
		// pr($new_requestedBy_id);exit;
		foreach ( $old_requestedBy_id as $key => $value ) {
			$this->db->set ( 'payments.requested_by', $new_requestedBy_id );
			$this->db->where ( 'payments.requested_by', $value ["requested_by_id"] );
			$status = $this->db->update ( "payments" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_requestedBy_id as $key => $value ) {
			$this->db->set ( 'payments_requested_by_client_visibility.requested_by_id', $new_requestedBy_id );
			$this->db->where ( 'payments_requested_by_client_visibility.requested_by_id', $value ["requested_by_id"] );
			$status = $this->db->update ( "payments_requested_by_client_visibility" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		return true;
	}
	// merge payment paid by
	function mergePaymentPaidBy($old_paidBy_id, $new_paidBy_id) {
		// pr($old_paidBy_id);exit;
		foreach ( $old_paidBy_id as $key => $value ) {
			$this->db->set ( 'payments.paid_by', $new_paidBy_id );
			$this->db->where ( 'payments.paid_by', $value ["paid_by_id"] );
			$status = $this->db->update ( "payments" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_paidBy_id as $key => $value ) {
			$this->db->set ( 'payments_paid_by_client_visibility.paid_by_id', $new_paidBy_id );
			$this->db->where ( 'payments_paid_by_client_visibility.paid_by_id', $value ["paid_by_id"] );
			$status = $this->db->update ( "payments_paid_by_client_visibility" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		return true;
	}
	// merge payment type
	function mergePaymentType($old_paymentType_id, $new_paymentType_id) {
		// pr($old_paymentType_id);exit;
		foreach ( $old_paymentType_id as $key => $value ) {
			$this->db->set ( 'payments.type_id', $new_paymentType_id );
			$this->db->where ( 'payments.type_id', $value ["type_id"] );
			$status = $this->db->update ( "payments" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_paymentType_id as $key => $value ) {
			$this->db->set ( 'payment_split.type', $new_paymentType_id );
			$this->db->where ( 'payment_split.type', $value ["type_id"] );
			$status = $this->db->update ( "payment_split" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_paymentType_id as $key => $value ) {
			$this->db->set ( 'payment_types_client_visibility.payment_type', $new_paymentType_id );
			$this->db->where ( 'payment_types_client_visibility.payment_type', $value ["type_id"] );
			$status = $this->db->update ( "payment_types_client_visibility" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		return true;
	}
	// merge payment currency
	function mergePaymentCurrency($old_currency_id, $new_currency_id) {
		// pr($old_currency_id);exit;
		foreach ( $old_currency_id as $key => $value ) {
			$this->db->set ( 'payment_split.currency', $new_currency_id );
			$this->db->where ( 'payment_split.currency', $value ["currency_id"] );
			$status = $this->db->update ( "payment_split" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		foreach ( $old_currency_id as $key => $value ) {
			$this->db->set ( 'payments_currency_client_visibility.currency_name', $new_currency_id );
			$this->db->where ( 'payments_currency_client_visibility.currency_name', $value ["currency_id"] );
			$status = $this->db->update ( "payments_currency_client_visibility" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		return true;
	}
	//merge Event Types
	function mergeEventTypes($old_eventType_id, $new_eventType_id) {
		foreach ( $old_eventType_id as $key => $value ) {
			$this->db->set ( 'kol_events.event_type', $new_eventType_id);
			$this->db->where ( 'kol_events.event_type', $value ["event_type_id"] );
			$status = $this->db->update ( "kol_events" );
			// echo $this->db->last_query();
			if (! $status)
				return false;
		}
		return true;
	}
	//merge Sponsor Types
	function mergeSponsorTypes($old_sponsorType_id, $new_sponsorType_id) {
		foreach ( $old_sponsorType_id as $key => $value ) {
			$this->db->set ( 'kol_events.sponsor_type', $new_sponsorType_id);
			$this->db->where ( 'kol_events.sponsor_type', $value ["sponsor_type_id"] );
			$status = $this->db->update ( "kol_events" );
			if (! $status)
				return false;
		}
		return true;
	}
	function mergeSessionTypes($old_sessionType_id, $new_sessionType_id) {
		foreach ( $old_sessionType_id as $key => $value ) {
			$this->db->set ( 'kol_events.session_type', $new_sessionType_id);
			$this->db->where ( 'kol_events.session_type', $value ["session_type_id"] );
			$status = $this->db->update ( "kol_events" );
			if (! $status)
				return false;
		}
		return true;
	}
	function getAllPhoneType() {
		$this->db->select ( "phone_type.*" );
		$arr = $this->db->get ( "phone_type" );
		return $arr->result_array ();
	}
	function getAllEmails() {
		$this->db->select ( 'emails.*' );
		$arr = $this->db->get ( 'emails' );
		return $arr->result_array ();
	}
	function getAllDiscussionTypes() {
		$this->db->select ( 'interaction_types.*' );
		$arr = $this->db->get ( 'interaction_types' );
		return $arr->result_array ();
	}
	function getAllInteractionsTopics() {
		$this->db->select ( 'interactions_topics.*' );
		$arr = $this->db->get ( 'interactions_topics' );
		return $arr->result_array ();
	}
	function getAllInteractionsTypes() {
		$this->db->select ( 'interactions_modes.*' );
		$arr = $this->db->get ( 'interactions_modes' );
		return $arr->result_array ();
	}
	function getAllInteractionLocations() {
		$this->db->select ( 'interaction_location_types.*' );
		$arr = $this->db->get ( 'interaction_location_types' );
		return $arr->result_array ();
	}
	function getAllPaymentRequestedBy() {
		$this->db->select ( 'payments_requested_by.*' );
		$arr = $this->db->get ( 'payments_requested_by' );
		return $arr->result_array ();
	}
	function getAllPaymentPaidBy() {
		$this->db->select ( 'payments_paid_by.*' );
		$arr = $this->db->get ( 'payments_paid_by' );
		return $arr->result_array ();
	}
	function getAllPaymentType() {
		$this->db->select ( 'payment_types.*' );
		$arr = $this->db->get ( 'payment_types' );
		return $arr->result_array ();
	}
	function getAllPaymentCurrency() {
		$this->db->select ( 'payments_currency.*' );
		$arr = $this->db->get ( 'payments_currency' );
		return $arr->result_array ();
	}
	function getAllEventTypes() {
		$this->db->select ( 'conf_event_types.*' );
		$arr = $this->db->get ( 'conf_event_types' );
		return $arr->result_array ();
	}
	function getAllSponsorTypes() {
		$this->db->select ( 'event_sponsor_types.*' );
		$arr = $this->db->get ( 'event_sponsor_types' );
		return $arr->result_array ();
	}
	function getAllSessionTypes() {
		$this->db->select ( 'conf_session_types.*' );
		$arr = $this->db->get ( 'conf_session_types' );
		return $arr->result_array ();
	}
	// check the associated master data
	function checkAssociation($id, $table) {
		switch ($table) {
			case 'specialties' :
				$this->db->select("(count(DISTINCT kols.id)+COUNT(DISTINCT specialty_client_association.id)+COUNT(DISTINCT organizations.id)+COUNT(DISTINCT kol_sub_specialty.id)+COUNT(DISTINCT interactions_other_attendees.id)+count(DISTINCT interactions_attendees.id)+COUNT(DISTINCT event_topics.id)+COUNT(DISTINCT coachings.id)+COUNT(DISTINCT additional_contacts.id)) as cnt");
				$this->db->join('kols','kols.specialty = specialties.id','left');
				$this->db->join('specialty_client_association','specialty_client_association.specialty_id = specialties.id','left');
				$this->db->join('organizations','organizations.specialty = specialties.id','left');
				$this->db->join('kol_sub_specialty','kol_sub_specialty.kol_sub_specialty_id = specialties.id','left');
				$this->db->join('interactions_other_attendees','interactions_other_attendees.specialty_id = specialties.id','left');
				$this->db->join('interactions_attendees','interactions_attendees.specialty_id = specialties.id','left');
				$this->db->join('event_topics','event_topics.specialty_id = specialties.id','left');
				$this->db->join('coachings','coachings.specialty = specialties.id','left');
				$this->db->join('additional_contacts','additional_contacts.specialty_id = specialties.id','left');
				$this->db->where('specialties.id',$id);
				$this->db->group_by('specialties.id');
				$arrResult = $this->db->get('specialties');
				break;
			case 'interactions_topics' :
				$this->db->select("(COUNT(DISTINCT interactions_about.id)+COUNT(DISTINCT interactions_discussion_topic_mapped_data.id)+COUNT(DISTINCT interactions_topic_mapped_data.id)+COUNT(DISTINCT interaction_sub_topics_association.topic_id)+COUNT(DISTINCT interaction_topics_by_type.id)+COUNT(DISTINCT interaction_topic_mapping.id)+COUNT(DISTINCT interactions_topics_client_visibility.id)) as cnt");
				$this->db->join('interactions_about','interactions_about.topic_id = interactions_topics.id','left');
				$this->db->join('interactions_discussion_topic_mapped_data','interactions_discussion_topic_mapped_data.topic_id = interactions_topics.id','left');
				$this->db->join('interactions_topic_mapped_data','interactions_topic_mapped_data.topic_id = interactions_topics.id','left');
				$this->db->join('interaction_sub_topics_association','interaction_sub_topics_association.topic_id = interactions_topics.id','left');
				$this->db->join('interaction_topics_by_type','interaction_topics_by_type.topic_id = interactions_topics.id','left');
				$this->db->join('interaction_topic_mapping','interaction_topic_mapping.topic_id = interactions_topics.id','left');
				$this->db->join('interactions_topics_client_visibility','interactions_topics_client_visibility.interactions_topics_id = interactions_topics.id','left');
				$this->db->where('interactions_topics.id',$id);
				$this->db->group_by('interactions_topics.id');
				$arrResult = $this->db->get('interactions_topics');
				break;
			case 'products' :
				$this->db->select("(COUNT(DISTINCT products_client_visibility.id)+COUNT(DISTINCT ol_speaker_product.id)+COUNT(DISTINCT kol_products.id)+COUNT(DISTINCT interaction_type_by_product.id)+COUNT(DISTINCT interaction_topics_by_type.id)+COUNT(DISTINCT interaction_sub_topics_association.product_id)+COUNT(DISTINCT interactions_discussion_topic_mapped_data.id)+COUNT(DISTINCT interactions_topic_mapped_data.id)+COUNT(DISTINCT interaction_topic_mapping.id)) as cnt");
				$this->db->join('products_client_visibility','products_client_visibility.products_id = products.id','left');
				$this->db->join('ol_speaker_product','ol_speaker_product.product_id = products.id','left');
				$this->db->join('kol_products','kol_products.product_id = products.id','left');
				$this->db->join('interaction_type_by_product','interaction_type_by_product.product_id = products.id','left');
				$this->db->join('interaction_topics_by_type','interaction_topics_by_type.product_id = products.id','left');
				$this->db->join('interaction_sub_topics_association','interaction_sub_topics_association.product_id = products.id','left');
				$this->db->join('interactions_discussion_topic_mapped_data','interactions_discussion_topic_mapped_data.product_id = products.id','left');
				$this->db->join('interactions_topic_mapped_data','interactions_topic_mapped_data.product_id = products.id','left');
				$this->db->join('interaction_topic_mapping','interaction_topic_mapping.product_id = products.id','left');
				$this->db->where('products.id',$id);
				$this->db->group_by('products.id');
				$arrResult = $this->db->get('products');
				break;
			case 'emails' :
				$this->db->select("(COUNT(DISTINCT emails_client_visibility.id)+COUNT(DISTINCT contact_restrictions.id)) as cnt");
				$this->db->join('emails_client_visibility','emails_client_visibility.emails_id = emails.id','left');
				$this->db->join('contact_restrictions','contact_restrictions.email = emails.id','left');
				$this->db->where('emails.id',$id);
				$this->db->group_by('emails.id');
				$arrResult = $this->db->get('emails');
				break;
			case 'phone_type' :
				$this->db->select("(COUNT(DISTINCT phone_type_client_visibility.id)+COUNT(DISTINCT staffs.id)+COUNT(DISTINCT phone_numbers.id)) as cnt");				
				$this->db->join('phone_type_client_visibility','phone_type_client_visibility.phone_type_id = phone_type.id','left');
				$this->db->join('staffs','staffs.phone_type = phone_type.id','left');
				$this->db->join('phone_numbers','phone_numbers.type = phone_type.id','left');
				$this->db->where('phone_type.id',$id);
				$this->db->group_by('phone_type.id');
				$arrResult = $this->db->get('phone_type');
				break;
			case 'interaction_types' :
				$this->db->select("(COUNT(DISTINCT interaction_sub_topics_association.type_id)+COUNT(DISTINCT interaction_topics_by_type.id)+COUNT(DISTINCT interaction_topic_mapping.id)+COUNT(DISTINCT interaction_type_by_product.id)+COUNT(DISTINCT interactions_discussion_topic_mapped_data.id)+COUNT(DISTINCT interaction_types_client_visibility.id)) as cnt");
				$this->db->join('interaction_sub_topics_association','interaction_sub_topics_association.type_id = interaction_types.id','left');
				$this->db->join('interaction_topics_by_type','interaction_topics_by_type.type_id = interaction_types.id','left');
				$this->db->join('interaction_topic_mapping','interaction_topic_mapping.interaction_type_id = interaction_types.id','left');
				$this->db->join('interaction_type_by_product','interaction_type_by_product.type_id = interaction_types.id','left');
				$this->db->join('interaction_types_client_visibility','interaction_types_client_visibility.interaction_types_id = interaction_types.id','left');
				$this->db->join('interactions_discussion_topic_mapped_data','interactions_discussion_topic_mapped_data.interaction_type = interaction_types.id','left');
				$this->db->where('interaction_types.id',$id);
				$this->db->group_by('interaction_types.id');
				$arrResult = $this->db->get('interaction_types');
				break;
			case 'interactions_modes' :
				$this->db->select("(COUNT(DISTINCT interactions.id)+COUNT(DISTINCT interactions_modes_client_visibility.id)) as cnt");
				$this->db->join('interactions','interactions.mode = interactions_modes.id','left');
				$this->db->join('interactions_modes_client_visibility','interactions_modes_client_visibility.interactions_modes_id = interactions_modes.id','left');
				$this->db->where('interactions_modes.id',$id);
				$this->db->group_by('interactions_modes.id');
				$arrResult = $this->db->get('interactions_modes');
				break;
			case 'interaction_location_types' :
				$this->db->select("(COUNT(DISTINCT interactions.id)+COUNT(DISTINCT interaction_location_types_client_visibility.id)) as cnt");
				$this->db->join('interactions','interactions.location_category = interaction_location_types.id','left');
				$this->db->join('interaction_location_types_client_visibility','interaction_location_types_client_visibility.interaction_location_types_id = interaction_location_types.id','left');
				$this->db->where('interaction_location_types.id',$id);
				$this->db->group_by('interaction_location_types.id');
				$arrResult = $this->db->get('interaction_location_types');
				break;
			case 'payments_requested_by' :
				$this->db->select("(COUNT(DISTINCT payments.id)+COUNT(DISTINCT payments_requested_by_client_visibility.id)) as cnt");
				$this->db->join('payments','payments.requested_by = payments_requested_by.id','left');
				$this->db->join('payments_requested_by_client_visibility','payments_requested_by_client_visibility.requested_by_id = payments_requested_by.id','left');
				$this->db->where('payments_requested_by.id',$id);
				$this->db->group_by('payments_requested_by.id');
				$arrResult = $this->db->get('payments_requested_by');
				break;
			case 'payments_paid_by' :
				$this->db->select("(COUNT(DISTINCT payments.id)+COUNT(DISTINCT payments_paid_by_client_visibility.id)) as cnt");
				$this->db->join('payments','payments.paid_by = payments_paid_by.id','left');
				$this->db->join('payments_paid_by_client_visibility','payments_paid_by_client_visibility.paid_by_id = payments_paid_by.id','left');
				$this->db->where('payments_paid_by.id',$id);
				$this->db->group_by('payments_paid_by.id');
				$arrResult = $this->db->get('payments_paid_by');
				break;
			case 'payment_types' :
				$this->db->select("(COUNT(DISTINCT payments.id)+COUNT(DISTINCT payment_split.id)+COUNT(DISTINCT payment_types_client_visibility.id)) as cnt");
				$this->db->join('payments','payments.type_id = payment_types.id','left');
				$this->db->join('payment_split','payment_split.type = payment_types.id','left');
				$this->db->join('payment_types_client_visibility','payment_types_client_visibility.payment_type = payment_types.id','left');
				$this->db->where('payment_types.id',$id);
				$this->db->group_by('payment_types.id');
				$arrResult = $this->db->get('payment_types');
				break;
			case 'payments_currency' :
				$this->db->select("(COUNT(DISTINCT payments_currency_client_visibility.id)+COUNT(DISTINCT payment_split.id)) as cnt");
				$this->db->join('payments_currency_client_visibility','payments_currency_client_visibility.currency_name = payments_currency.id','left');
				$this->db->join('payment_split','payment_split.currency = payments_currency.id','left');
				$this->db->where('payments_currency.id',$id);
				$this->db->group_by('payments_currency.id');
				$arrResult = $this->db->get('payments_currency');
				break;
			case 'titles' :
				$this->db->select("(COUNT(DISTINCT kol_locations.id)+COUNT(DISTINCT title_client_mappings.id)) as cnt");
				$this->db->join('kol_locations','kol_locations.title = titles.id','left');
				$this->db->join('title_client_mappings','title_client_mappings.title_id = titles.id','left');
				$this->db->where('titles.id',$id);
				$this->db->group_by('titles.id');
				$arrResult = $this->db->get('titles');
				break;
			case 'organization_types' :
				$this->db->select("(COUNT(DISTINCT organizations.id)) as cnt");
				$this->db->join('organizations','organizations.type_id = organization_types.id','left');
				$this->db->where('organization_types.id',$id);
				$this->db->group_by('organization_types.id');
				$arrResult = $this->db->get('organization_types');
				break;
			case 'engagement_types' :
				$this->db->select("(COUNT( DISTINCT kol_memberships.id)) as cnt");
				$this->db->join('kol_memberships','kol_memberships.engagement_id = engagement_types.id','left');
				$this->db->where('engagement_types.id',$id);
				$this->db->group_by('engagement_types.id');
				$arrResult = $this->db->get('engagement_types');
				break;
			case 'event_topics' :
				$this->db->select("(COUNT( DISTINCT kol_events.id)) as cnt");
				$this->db->join('kol_events','kol_events.topic = event_topics.id','left');
				$this->db->where('event_topics.id',$id);
				$this->db->group_by('event_topics.id');
				$arrResult = $this->db->get('event_topics');
				break;
			case 'event_organizer_types' :
				$this->db->select("(COUNT(DISTINCT kol_events.id)) as cnt");
				$this->db->join('kol_events','kol_events.organizer_type = event_organizer_types.id','left');
				$this->db->where('event_organizer_types.id',$id);
				$this->db->group_by('event_organizer_types.id');
				$arrResult = $this->db->get('event_organizer_types');
				break;
			case 'event_roles' :
				$this->db->select("(COUNT( DISTINCT key_peoples.id)+COUNT(DISTINCT kol_events.id)) as cnt");
				$this->db->join('key_peoples','key_peoples.role_id = event_roles.id','left');
				$this->db->join('kol_events','kol_events.role = event_roles.role','left');
				$this->db->where('event_roles.id',$id);
				$this->db->group_by('event_roles.id');
				$arrResult = $this->db->get('event_roles');
				break;
			case 'countries' :
				$this->db->select("(COUNT(DISTINCT cities.CityId)+COUNT(DISTINCT regions.RegionID)+COUNT(DISTINCT city_dist.CityId)+COUNT(DISTINCT dmas.CountryId)+COUNT(DISTINCT subnets.CountryId)+COUNT(DISTINCT kol_locations.id)+COUNT(DISTINCT kol_events.id)) as cnt");
				$this->db->join('cities','cities.CountryID = countries.CountryId','left');
				$this->db->join('regions','regions.CountryID = countries.CountryId','left');
				$this->db->join('city_dist','city_dist.CountryID = countries.CountryId','left');
				$this->db->join('dmas','dmas.CountryId = countries.CountryId','left');
				$this->db->join('subnets','subnets.CountryId = countries.CountryId','left');
				$this->db->join('kol_locations','kol_locations.country_id = countries.CountryId','left');
				$this->db->join('kol_events','kol_events.country_id = countries.CountryId','left');
				$this->db->where('countries.CountryId',$id);
				$this->db->group_by('countries.CountryId');
				$arrResult = $this->db->get('countries');
				break;
			case 'states' :
				$this->db->select("(COUNT(DISTINCT cities.RegionID)+COUNT(DISTINCT subnets.RegionId)+COUNT(DISTINCT kol_locations.id)+COUNT(DISTINCT kol_events.id)) as cnt");
				$this->db->join('cities','cities.RegionID = regions.RegionID','left');
				$this->db->join('subnets','subnets.RegionId = regions.RegionID','left');
				$this->db->join('kol_locations','kol_locations.state_id = regions.RegionID','left');
				$this->db->join('kol_events','kol_events.state_id = regions.RegionID','left');
				$this->db->where('regions.RegionID',$id);
				$this->db->group_by('regions.RegionID');
				$arrResult = $this->db->get('regions');
				break;
			case 'cities' :
				$this->db->select("(COUNT(DISTINCT nbc.CityId)+COUNT(DISTINCT proxynetworks.CityId)+COUNT(DISTINCT city_dist.CityId)+COUNT(DISTINCT kol_locations.id)+COUNT(DISTINCT subnets.CityId)+COUNT(DISTINCT kol_events.id)) as cnt");
				$this->db->join('nbc','nbc.CityId = cities.CityId','left');
				$this->db->join('proxynetworks','proxynetworks.CityId = cities.CityId','left');
				$this->db->join('city_dist','city_dist.CityId = cities.CityId','left');
				$this->db->join('subnets','subnets.CityId = cities.CityId','left');
				$this->db->join('kol_locations','kol_locations.city_id = cities.CityId','left');
				$this->db->join('kol_events','kol_events.city_id = cities.CityId','left');
				$this->db->where('cities.CityId',$id);
				$this->db->group_by('cities.CityId');
				$arrResult = $this->db->get('cities');
				break;
			case 'conf_event_types' :
				$this->db->select("(COUNT(DISTINCT kol_events.event_type)) as cnt");				
				$this->db->join('kol_events','kol_events.event_type = conf_event_types.id','left');
				$this->db->where('conf_event_types.id',$id);
				$this->db->group_by('conf_event_types.id');
				$arrResult = $this->db->get('conf_event_types');
				break;
			case 'event_sponsor_types' :
				$this->db->select("(COUNT(DISTINCT kol_events.sponsor_type)) as cnt");
				$this->db->join('kol_events','kol_events.sponsor_type = event_sponsor_types.id','left');
				$this->db->where('event_sponsor_types.id',$id);
				$this->db->group_by('event_sponsor_types.id');
				$arrResult = $this->db->get('event_sponsor_types');
				break;
			case 'conf_session_types' :
				$this->db->select("(COUNT(DISTINCT kol_events.session_type)) as cnt");
				$this->db->join('kol_events','kol_events.session_type = conf_session_types.id','left');
				$this->db->where('conf_session_types.id',$id);
				$this->db->group_by('conf_session_types.id');
				$arrResult = $this->db->get('conf_session_types');
				break;
		}	
		if ($arrResult->result_array() > 0) {
			foreach ($arrResult->result_array() as $key => $value) {
			return  $value['cnt'];
			}
		} else {
			return false;
		}
	}
	// check the country is present or not
	function checkCountry($country) {
		$this->db->where ( 'countries.Country', $country);
		$query = $this->db->get ( 'countries' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	// check the state is present or not
	function checkState($state) {
		$this->db->where ( 'regions.Region', $state);
		$query = $this->db->get ( 'regions' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	// check the city is present or not
	function checkCity($city) {
		$this->db->where ( 'cities.City', $city);
		$query = $this->db->get ( 'cities' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	//get the details of categories
	function getCategoryDetailsByName($catNames,$ids){
		//$value	= explode(",",$ids);
		//pr($ids);exit;
		$tableName	= $catNames;
		//foreach ( $arrIds as $key => $value ) {
			switch ($catNames) {
				case "titles" :
					$this->db->select ( 'titles.title' );
					$this->db->where_in( 'title_client_mappings.client_id', $ids);
					$this->db->join ( 'title_client_mappings', 'titles.id = title_client_mappings.title_id', 'left' );
					$this->db->group_by('titles.id');
					//$arrCategoryDetails = $this->db->get ( 'titles' );
					break;
				case "interactions_topics" :
					$this->db->select ( 'interactions_topics.*' );
					$this->db->where_in( 'interactions_topics_client_visibility.client_id', $ids);
					$this->db->join ( 'interactions_topics_client_visibility', 'interactions_topics.id = interactions_topics_client_visibility.interactions_topics_id', 'left' );
					$this->db->group_by('interactions_topics.id');
					//$arrCategoryDetails = $this->db->get ( 'interactions_topics' );
					break;
				case "products" :
					$this->db->select ( 'products.*' );
					$this->db->where_in( 'products_client_visibility.client_id', $ids);
					$this->db->join ( 'products_client_visibility', 'products.id = products_client_visibility.products_id', 'left' );
					$this->db->group_by('products.id');
					//$arrCategoryDetails = $this->db->get ( 'products' );
					break;
				case "emails" :
					$this->db->select ( 'emails.*' );
					$this->db->where_in( 'emails_client_visibility.client_id', $ids);
					$this->db->join ( 'emails_client_visibility', 'emails.id = emails_client_visibility.emails_id', 'left' );
					$this->db->group_by('emails.id');
					//$arrCategoryDetails = $this->db->get ( 'emails' );
					break;
				case "phone_type" :
					$this->db->select ( 'phone_type.*' );
					$this->db->where_in( 'phone_type_client_visibility.client_id', $ids);
					$this->db->join ( 'phone_type_client_visibility', 'phone_type.id = phone_type_client_visibility.phone_type_id', 'left' );
					$this->db->group_by('phone_type.id');
					//$arrCategoryDetails = $this->db->get ( 'phone_type' );
					break;
				case "specialties" :
					$this->db->select ( 'specialties.*' );
					$this->db->where_in( 'specialty_client_association.client_id', $ids);
					$this->db->join ( 'specialty_client_association', 'specialties.id = specialty_client_association.specialty_id', 'left' );
					$this->db->group_by('specialties.id');
					//$arrCategoryDetails = $this->db->get ( 'specialties' );
					break;
				case "event_roles" :
					$this->db->select ( 'event_roles.*' );
					//$arrCategoryDetails = $this->db->get ( 'event_roles' );
					break;
				case "event_topics" :
					$this->db->select ( 'event_topics.*' );
					//$arrCategoryDetails = $this->db->get ( 'event_topics' );
					break;
				case "event_organizer_types" :
					$this->db->select ( 'event_organizer_types.*' );
					//$arrCategoryDetails = $this->db->get ( 'event_organizer_types' );
					break;
				case "interaction_types" :
					$this->db->select ( 'interaction_types.*' );
					$this->db->where_in( 'interaction_types_client_visibility.client_id', $ids);
					$this->db->join ( 'interaction_types_client_visibility', 'interaction_types.id = interaction_types_client_visibility.interaction_types_id', 'left' );
					$this->db->group_by('interaction_types.id');
					//$arrCategoryDetails = $this->db->get ( 'interaction_types' );
					break;
				case "interactions_modes" :
					$this->db->select ( 'interactions_modes.*' );
					$this->db->where_in( 'interactions_modes_client_visibility.client_id', $ids);
					$this->db->join ( 'interactions_modes_client_visibility', 'interactions_modes.id = interactions_modes_client_visibility.interactions_modes_id', 'left' );
					$this->db->group_by('interactions_modes.id');
					//$arrCategoryDetails = $this->db->get ( 'interactions_modes' );
					break;
				case "interaction_location_types" :
					$this->db->select ( 'interaction_location_types.*' );
					$this->db->where_in( 'interaction_location_types_client_visibility.client_id', $ids);
					$this->db->join ( 'interaction_location_types_client_visibility', 'interaction_location_types.id = interaction_location_types_client_visibility.interaction_location_types_id', 'left' );
					$this->db->group_by('interaction_location_types.id');
					//$arrCategoryDetails = $this->db->get ( 'interaction_location_types' );
					break;
				case "engagement_types" :
					$this->db->select ( 'engagement_types.*' );
					//$arrCategoryDetails = $this->db->get ( 'engagement_types' );
					break;
				case "organization_types" :
					$this->db->select ( 'organization_types.*' );
					//$arrCategoryDetails = $this->db->get ( 'organization_types' );
					break;
				case "payments_requested_by" :
					$this->db->select ( 'payments_requested_by.*' );
					$this->db->where_in( 'payments_requested_by_client_visibility.client_id', $ids);
					$this->db->join ( 'payments_requested_by_client_visibility', 'payments_requested_by.id = payments_requested_by_client_visibility.requested_by_id', 'left' );
					$this->db->group_by('payments_requested_by.id');
					//$arrCategoryDetails = $this->db->get ( 'payments_requested_by' );
					break;
				case "payments_paid_by" :
					$this->db->select ( 'payments_paid_by.*' );
					$this->db->where_in( 'payments_paid_by_client_visibility.client_id', $ids);
					$this->db->join ( 'payments_paid_by_client_visibility', 'payments_paid_by.id = payments_paid_by_client_visibility.paid_by_id', 'left' );
					$this->db->group_by('payments_paid_by.id');
					//$arrCategoryDetails = $this->db->get ( 'payments_paid_by' );
					break;
				case "payment_types" :
					$this->db->select ( 'payment_types.*' );
					$this->db->where_in( 'payment_types_client_visibility.client_id', $ids);
					$this->db->join ( 'payment_types_client_visibility', 'payment_types.id = payment_types_client_visibility.payment_type', 'left' );
					$this->db->group_by('payment_types.id');
					//$arrCategoryDetails = $this->db->get ( 'payment_types' );
					break;
				case "payments_currency" :
					$this->db->select ( 'payments_currency.*' );
					$this->db->where_in( 'payments_currency_client_visibility.client_id', $ids);
					$this->db->join ( 'payments_currency_client_visibility', 'payments_currency.id = payments_currency_client_visibility.currency_name', 'left' );
					$this->db->group_by('payments_currency.id');
					//$arrCategoryDetails = $this->db->get ( 'payments_currency' );
					break;
				case "cities" :
					$this->db->select ( 'countries.Country,regions.Region,cities.City' );
					$this->db->join ( 'regions', 'regions.CountryID=countries.CountryId', 'left' );
					$this->db->join ( 'cities', 'countries.CountryId=cities.CountryID and regions.RegionID=cities.RegionID', 'left' );					
					//$arrCategoryDetails = $this->db->get ( 'countries' );
					$tableName	= "countries";
					break;
				case "event_type" :
					$this->db->select ( 'conf_event_types.*' );
					//$arrCategoryDetails = $this->db->get ( 'conf_event_types' );
					$tableName	= "conf_event_types";
					break;
				case "sponsor_type" :
					$this->db->select ( 'event_sponsor_types.*' );
					//$arrCategoryDetails = $this->db->get ( 'event_sponsor_types' );
					$tableName	= "event_sponsor_types";
					break;
				case "session_type" :
					$this->db->select ( 'conf_session_types.*' );
					//$arrCategoryDetails = $this->db->get ( 'conf_session_types' );
					$tableName	= "conf_session_types";
					break;
			}
			$arrCategoryDetails = $this->db->get ($tableName);
// 			pr($this->db->last_query());exit;
		//}
// 		pr($arrCategoryDetails->result_array ());exit;
		return $arrCategoryDetails->result_array ();
	}
	// check the event type is present or not
	function checkEventType($eventType) {
		$this->db->where ( 'conf_event_types.event_type', $eventType);
		$query = $this->db->get ( 'conf_event_types' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	// check the sponsor type is present or not
	function checkSponsorType($sponsorType) {
		$this->db->where ( 'event_sponsor_types.type', $sponsorType);
		$query = $this->db->get ( 'event_sponsor_types' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
	// check the Session type is present or not
	function checkSessionType($sessionType) {
		$this->db->where ( 'conf_session_types.session_type', $sessionType);
		$query = $this->db->get ( 'conf_session_types' );
		if ($query->num_rows () > 0) {
			return true;
		} else {
			return false;
		}
	}
}
?>