<?php
class Speciality extends CI_Model {
	function getAllSpecialties($contentPage=""){
		$arrSpecialties	= array();
		$clientId = $this->session->userdata('client_id');
		$this->db->select('specialty_client_association.id,specialties.specialty');
		$this->db->join('specialty_client_association','specialties.id = specialty_client_association.specialty_id','left');
// 		 if($clientId != INTERNAL_CLIENT_ID && $this->session->userdata('user_role_id') != ROLE_ADMIN){
// 		 	if($clientId ==CUSTOMER_CLIENT_ID){
		 		$this->db->where('specialty_client_association.client_id',$clientId);
// 		 	}else{
// 		 		$this->db->where('all',1);
// 		 	}
// 		 }
		 
		 $arrSpecialtiesResult = $this->db->get('specialties');
		 foreach($arrSpecialtiesResult->result_array() as $arrSpecialty){
		 	$arrSpecialties[$arrSpecialty['id']]	= $arrSpecialty['specialty'];
		 }
		 $key = array_search('Non-medical / Others',$arrSpecialties);
		 unset($arrSpecialties[$key]);
		 if($clientId == INTERNAL_CLIENT_ID && $this->session->userdata('user_role_id') != ROLE_ADMIN)
		 	$arrSpecialties1[$key] = 'Non-medical / Others';
	 	foreach($arrSpecialties as $key1=>$value1){
	 		$arrSpecialties1[$key1] = $value1;
	 	}
	 	return $arrSpecialties1;
	}
	function getSpecialtyById($specialtyId){
		$this->db->where('specialty_client_association.id', $specialtyId);
		$this->db->select('specialties.specialty');
		$this->db->join('specialty_client_association','specialties.id = specialty_client_association.specialty_id','left');
		$results	= $this->db->get('specialties');
		foreach($results->result_array() as $row){
			$specialty=$row['specialty'];
		}
		return $specialty;
	}
	function getAllKolSubSpecialties($kolId){
		$this->db->select('kol_sub_specialty.kol_sub_specialty_id as id,specialties.specialty');
		$this->db->join('specialty_client_association','specialty_client_association.id = kol_sub_specialty.kol_sub_specialty_id','left');
		$this->db->join('specialties','specialties.id = specialty_client_association.specialty_id','left');
		$this->db->where_in('kol_sub_specialty.kol_id', $kolId);
		$arrkolSubSpecialtyResult = $this->db->get('kol_sub_specialty');
		$arrKolSubSpecialties	= array();
		foreach($arrkolSubSpecialtyResult->result_array() as $arrSubSpecialty){
			if($arrSubSpecialty['id']==0){
				$arrKolSubSpecialties[$arrSubSpecialty['id']]	= 'Non-medical / Others';
				continue;
			}
			$arrKolSubSpecialties[$arrSubSpecialty['id']]	= $arrSubSpecialty['specialty'];
		}
		return $arrKolSubSpecialties;
	}
	function getSpecialtiesById($arrId){
		$arrSpecialties	= array();
		$this->db->select('specialty_client_association.id,specialties.specialty');
		$this->db->join('specialty_client_association','specialties.id = specialty_client_association.specialty_id','left');
		$this->db->where_in('specialty_client_association.id', $arrId);
		$results	= $this->db->get('specialties');
		foreach($results->result_array() as $row){
			$arrSpecialties[$row['id']]=$row['specialty'];
		}
		return $arrSpecialties;
	}
}
?>