<style>
#toggleView {
    width: 37px;
    margin-right: 5px;
    margin-left: 8px;
}
#toggleViewIcon {
    /* background: url(../images/toggle_view.png) no-repeat scroll 0 3px transparent; */
    background: url(../../assets/modules/organizations/images/toggle_list.svg) no-repeat scroll;
    width: 42px;
    margin-top: 4px;
}
#toggleViewIcon.listView {
    /* background: url(../images/toggle_view.png) no-repeat -41px 3px transparent; */
    background: url(../../assets/modules/organizations/images/toggle_detailed_view.svg) no-repeat scroll;
}


#toggleViewIcon a {
    text-decoration: none;
    display: block;
}
.alignToUsersIcon {
    /* background-position: -267px -388px; */
    background-image: url(../../assets/modules/organizations/images/assign_profile_inactive.svg);
    background-position: 0 5px !important;
    background-repeat: no-repeat;
    background-size: 20px auto;
}
.exportOptionsContainer {
    overflow: visible;
}
.exportOptionsContainer ul:first-child, .exportOptionsContainer ul.pageRightOptions {
    margin: 0px;
    padding: 0px;
    float: left;
}
.exportOptionsContainer ul:first-child li, .exportOptionsContainer ul.pageRightOptions li {
    list-style: none;
    padding: 2px 3px;
    float: left;
    height: 25px;
    line-height: 25px;
}
.sprite_iconSet {
   /*  background: url(../assets/modules/organizations/images/all_icons.png); */
    float: left;
    height: 25px;
    width: 20px;
    margin-left: 5px;
    margin-right: 5px;
    cursor: pointer;
    margin-top: -3px;
}
</style>
<script>
function toggleListingView() {
    $('.tooltip.in').hide();
    if (viewType == 'list') {
        viewType = 'tabular';
        $('#toggleViewIcon').removeClass('listView');
    } else {
        viewType = 'list';
        $('#toggleViewIcon').addClass('listView');
    }
}
</script>
<div class="row row_padding">
			<div class="col-sm-6 exportOptionsContainer">
			<ul>
			<li>
				<div id="toggleView" class="tooltip-demo tooltop-right">
                            <div id="toggleViewIcon" class=""><a rel="tooltip" href="#" onclick="toggleListingView();
                                                return false;" data-original-title="Change View">&nbsp;</a></div>
                        </div>
            </li><li>            
                        <div class="alignToUsersIcon sprite_iconSet" onclick="alignOrgUsers();"><a rel="tooltip" href="#" data-original-title="Assign Profiles">&nbsp;</a></div>
				</li>
			</ul>
			</div>
			<div class="col-sm-6">
				<div class="pull-right ">
            		<a class="btn custom-btn btn-default" href="<?php echo base_url(); ?>organizations/add_org/institution" rel="tooltip" data-original-title="Add Organization"><span></span>Add Organization</a>
            		<button type="button" class="btn custom-btn btn-default">Hide Sidebar</button>
            	</div>
            </div>		
		</div>
		<div class="row">
			<table class="table">
			        <tr>
				        <?php echo $this->load->view(CUSTOM_APP_CACHE.strtolower($this->session->userdata('client_name')).'/'.'navigations/secondary_navigation',$data);?>
			            <th>
				            <div id="pageContentWrapper" class="col-md-9">
								<div id="searchContainer">
									<div id="searchTopMenus"></div>
									<div id="searchResultsContainer" class="maxWidth">
										<?php 
										echo $this->load->view($orgResultsPage, $dataorgResultsData);?>
									</div>
								</div>
				            </div>
				            <div id="pageSidebar" class="col-md-3"><?php echo $this->load->view($sidebar, $filterData); ?>
			            </th>
			        </tr>
			 </table>
		</div>
		