<?php
/**
 * File to 'view' kols Social media details
 *
 * @author: Ambarish
 * @created on: 22-12-10
 * @package application.views.kols
 */

?>
<head>
    	<style type="text/css">
		#contentWrapper.span-23 {
			background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
		    background-position: 135px 50%;
		    background-repeat: repeat-y;
	
		}
		
		#mediaLinks a p{
			text-decoration:none;
			text-align:left;
			color: #000099;
			width: 780px;
			word-wrap: break-word;
		}

	#kolSocialMedia > div{
		border: 5px solid #EEEEEE;
	    float: left;
	    margin-bottom: 11px;
	    margin-left: 5px;
	    width: 383px;
	}
	#kolSocialMedia > div > label{
		float:left;
	}
	#kolSocialMedia > div > h5{
		margin-bottom:5px;
		font-size:16px;
	}
	#kolSocialMedia > div > ul{
		border-top: 1px solid #EBEBEB;
	    list-style: none outside none;
	    margin-left: 20px;
    	margin-right: 20px;
	    padding-left: 0;
	    height: 500px;
	    overflow-y: scroll;
	}
	#kolSocialMedia > div > ul li{
		border-bottom: 1px solid #EBEBEB;
		overflow:hidden;
		position: relative;
		min-height: 50px;
		padding-bottom: 32px;
    	padding-top: 7px;
	}
	
	#kolSocialMedia > div > ul li:HOVER{
		background-color:#eeeeee;
	}
	#kolSocialMedia > div > ul li > p{
		margin-bottom:0px;
		overflow: hidden;
	}
	#kolSocialMedia span.human-time{
		bottom: 10px;
	    color: green;
	    float: right;
	    position: absolute;
	    right: 0;
	}
	#latest-facebook-updates li .storylink{
	    display: block;
	    padding-bottom: 5px;
	}
	#latest-facebook-updates li .storylink a{
		color: #3B5998;
		font-size: 11px;
		font-weight: bold;
	}
	#latest-facebook-updates li > div img{
		float: left;
	    margin-right: 5px;
	   	width: 130px;
	   	cursor:pointer;
	}
	#latest-facebook-updates li >div p{
		margin-bottom:0px;
	}
	#kolSocialMedia > div > ul li > div{
		overflow: hidden;
	}
	.additinal-links{
		bottom: 10px;
	    left: 0;
	    position: absolute;
	    width: 100%;
	}
	.sharesIcon {
	   	background-image: url("<?php echo base_url()?>images/fb-shares.png");
	    background-position: -4px -3px;
	    background-repeat: no-repeat;
	    display: inline-block;
	    height: 13px;
	    margin-bottom: -2px;
	    margin-left: 5px;
	    width: 12px;
	}
	.commentsIcon {
	    background-image: url("<?php echo base_url()?>images/ZztFj_dOML8.png");
	    background-position: 0 -14px;
	    background-repeat: no-repeat;
	    display: inline-block;
	    height: 16px;
	    width: 16px;
	}
	.likesIcon {
	   	background-image: url("<?php echo base_url()?>images/ZztFj_dOML8.png");
	    background-position: 0 -53px;
	    background-repeat: no-repeat;
	    display: inline-block;
	    height: 12px;
	    width: 14px;
	}
	#latest-youtube-updates ul{
		margin-left: 10px !important;
    	margin-right: 10px !important;
	}
	#latest-youtube-updates li{
		margin-bottom: 10px;
    	padding-bottom: 20px !important;
	}
	#fbImageContainer{
		text-align: center;
	}
	#latest-youtube-updates li a{
		font-weight:bold;
	}
	div.mediaIcon {
	    margin-left: 6px;
    	margin-right: 2px;
	}
	#latest-youtube-updates div.mediaIcon{
		margin-left: 10px;
	}
	#latest-youtube-updates ul li img{
		cursor: pointer;
	}
	#latest-youtube-updates ul li img{
		opacity:0.7;
		margin: 28px auto auto 42px;
	}
	#latest-youtube-updates ul li img:HOVER{
		opacity:1;
	}
/*	.ui-widget-overlay {
	    background: url("images/ui-bg_flat_0_aaaaaa_40x100.png") repeat-x scroll 50% 50% #000000;
	    opacity: 0.75;
	}
*/
	.start-from{
		display:none;
	}
	.load-more {
	    color: mediumturquoise;
	    cursor: pointer;
	    font-weight: bold;
	    margin-top: -15px;
	    padding-bottom: 4px;
	    text-align: center;
	}
	#latest-facebook-updates .additinal-links a{
		display: block;
	    height: 100%;
	    width: 100%;
	}
	#latest-youtube-updates{
		width:100% !important;
	}
	#latest-youtube-updates li .video-thumb{
		height: 111px;
	    width: 160px;
	    float:left;
	    margin-right: 5px;
	    background-size: 149px auto; 
	    background-repeat: no-repeat;
	}
	#latest-youtube-updates li a{
		color: #3B5998 !important;
	}
	#latest-youtube-updates .additinal-links{
		margin-left: 165px;
	}
	#latest-youtube-updates .additinal-links a{
		color: green !important;
	    font-size: 11px;
	    font-weight: normal;
	    text-decoration: none;
	}
	#latest-youtube-updates p.author{
		font-style: italic;
	}
	#latest-youtube-updates li .duration{
		background-color: black;
	    color: white;
	    left: 2px;
	    position: absolute;
	}
	div.loading{
		background-image: url("../../../images/ajax-loader-4.gif");
	    background-position: center center;
	    background-repeat: no-repeat;
	}
/*	.microView {
		padding:0px !important;
		border-radius:0px !important;
	}
*/
	#fbImageContainer{
		padding:0px !important;
	}
/*	.ui-dialog{
		padding:0px !important;
	}
*/
	#fbImageContainer object{
		display: block;
    	overflow: hidden;
	}
	.ui-dialog .ui-dialog-titlebar-close {
		width:17px !important;
	}
	div.facebookIcon {
	    background-position: -140px -88px;
	}
	div.youtubeIcon {
	    background-position: -248px -89px;
	}
        .bkmakr_container{
        float:left;
        font-weight: bold;
        color:#000;
    }
   
    .ignore_message{
          margin-top: 53px;
  margin-right: 22px;
    }
    
    .ignore_list{
        border:1px solid;
          margin-top: 48px;
    }
    #table_entity_val{
         float: left;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    width: 100%;
    }
    .entity_mouse_hover{
        background-color: #BEBDBD;
    }
    .bkmakr_container{
        float:left;
        //font-weight: bold;
        color:#5F5C5C;
    }
    .book_mark_hide{
        color:#fff;
        border-color: #fff;
    }
/*    label:hover{
        background-color: #898989;
    }*/
    
    .display_more_entities{
       // overflow-y: auto;
        height:auto;
        border:1px solid #D0CCC9;
        border-color: #D0CCC9;
      
        width:600px;
    }
    .entity_highlight{
        background-color: #898989;
    }
    .sel_option{
        margin:0px;
        float:left;
        margin-left:34px;
        width:130px;
    }
    select{
        margin: 0px;
        //font-weight: bold;
        color:#000;
        
    }
    .pople_disease_top_border
    {
        border-top: 1px solid;
  border-color: #C3B8B0;
    }
    h2{
        margin:0;
    }
    #entity_name{
        float:left;
        margin:2px;
    }
    #entity_image{
        float:left;
        margin:4px;
    }
    #entity_val{
        float:left;
        
        
    }
    .book_img{
        float:right;
       // margin-left:20px;
         margin-top: 2px;
  margin-right: 3px;
    }
     .do_not_show_img{
        float:left;
        cursor:pointer;
        margin-left:27px;
        margin-top: 3px;
        
    }
    #entity_count{
        float: left;
  /* margin: 2px; */
  width: 77px;
  /* margin-left: 10px; */
  margin-right: -39px;
  margin-left: 43px;
   color: #847B7B;

    }
    
    .article_image{
         border-style: ridge;
       margin-right:16px;
       // margin:4px;
        width:100px;
        height:100px;
        border-color:#D0CCC9;
    }
    .entities_list{
        color:#000;
        
    }
    .fav_image{
        margin-right:5px;
        
    }
    #hyper{
        font-size: 15px;
    }
    .rss_feed{
        
       width:1327px;
       
        height:auto;
      
        margin-top:30px;
      
        
    }
    .refined_more_entities{
        border:1px solid;
        margin-top: 48px;
        
    }
    h5{
        cursor:pointer;
        margin:4px;
        float:left;
        color:#0000FF;
    }
    .filters{
        margin-left:21px;
        float:left;
        width:1251px;
    }
    .category_group{
        min-height:283px;
        height:auto;
        
        overflow: auto;
    }
    .book_mark{
       float:left;
       margin:10px;
         //width:620px;
        margin-left:15px;
       min-height:1000px;
        height:auto;
        margin-top:-59px;
        border-color:#D0CCC9;
     
    }
    .left_content{
        float:left;
        margin:10px;
         //width:620px;
         margin-top:9px;
        border-style: ridge;
        //border:2px solid #898989 ;
        height:auto;
      
        border-color:#D0CCC9;
        margin-left:20px;
    }
    .show_more{
        cursor: pointer;
        background-color: #D0CCC9;
       
        height:30px;
        text-align:center;
        margin:10px;
         border-style: ridge;
        
       
    }
    label{
        cursor: pointer;
        font-weight: normal;
              margin: 3px;
    }
    .showmore_table_header{
          margin-left: 370px;
    }
    .feed_url{
        margin:10px;
      
        border-bottom: 1px solid;
         border-color:#D0CCC9;
         text-wrap: normal;
         height:auto;
    }
    .article_content{
        height:auto;
        min-height: 150px;
    }
/*    .product{
        float:left;
        width:250px;
        height: 283px;
         border:2px solid #898989 ;
         border-color:#D0CCC9;
         margin:10px;
    }*/
/*    .people{
        float:left;
        width:250px;
        height:auto;
        min-height: 283px;
         border:2px solid #898989 ;
         border-color:#D0CCC9;
         margin:10px;
    }*/
   .cat_class {
  float: left;
  width: 286px;
  height: auto;
  min-height: 283px;
  /* border: 2px solid #898989; */
  /* border-bottom: rgb(186, 169, 147); */
  border-bottom: 1px solid;
  //border-top: 1px solid;
  border-color: #C3B8B0;
  margin: 10px;
}
/*     .disease{
        float:left;
        width:250px;
        height:auto;
        min-height: 283px;
         border:2px solid #898989 ;
         border-color:#D0CCC9;
         margin:10px;
    }
     .organization{
        float:left;
        width:250px;
        height: 283px;
         border:2px solid #898989 ;
         border-color:#D0CCC9;
         margin:10px;
    }
    .companies{
        float:left;
        width:250px;
        height: 283px;
         border:2px solid #898989 ;
         border-color:#D0CCC9;
         margin:10px;
    }
    .technology{
        float:left;
        width:250px;
        height: 283px;
         border:2px solid #898989 ;
         border-color:#D0CCC9;
         margin:10px;
    }*/
    .cat_name{
        cursor: pointer;
        color:#000;
        margin:5px;
        height:22px;
    }
    #count{
        float:right;
    }
    
    #rssfeed_content{
        border:1px solid #1A5C76;
        border-top:5px solid #1A5C76;
        padding-left:10px;
    }
    
    #tabs1 a{
        display:block;
        width:100px;
        float:left;
        border:1px solid #D0CCC9;
        text-align: center;
        margin-right:5px;
        background-color: #EFEFEF;
        padding: 5px 0;
        text-decoration: none;
        margin-right:0px;
        cursor: pointer;
    }
    
    #tabs1 div.divider{
        display: inline;
        width: 3px;
        border: 0px;
        border-bottom: 1px solid #D0CCC9;
        display: block;
        float: left;
        height: 29px;
    }
    #tabs1 a.current{
        background-color: #FFFFFF;
        border-bottom:1px solid #FFFFFF;
        z-index: 100;
        color:#1A5C76;
        font-weight: bold;
    }
/*    #tabs1 div.lastRight{
        width: 188px;
    }
*/
    #tabs1 div.firstRight{
        width: 20px;
    }
    #tabs1{
        padding-left:20px;
        z-index: 1;
        padding-bottom: 29px;
        border-bottom: 1px solid #D0CCC9;
        color:#898989;
        float: left;
        padding-bottom: 0px;
        border-bottom: 0px;
        padding-left:0px;
    }
    #rssfeed_content1 p{
        display: none;
    }
    #rssfeed_content1 ul{
        padding-left: 5px;
        list-style: none;
    }
    #rssfeed_content1 ul{
        list-style: none;
    }
    #rssfeed_content1{
        min-height: 300px;
    }
    
    .rssFeed{
        border:1px solid #D0CCC9;
        border-top:0px;
        padding-left:20px;
        padding-top: 10px;
    }
    #RSSFEED4 map img{
        display: none;
    }
        .submit{
            float:left;
            display:inline-block;
        }
        .date_picker1 label,.date_picker1 input{
            float:left;
            width:130px;
            
            display:inline-block;
           
        }
        .date_picker2 label,.date_picker2 input{
           float: left;
            margin-left: 0px;
            width: 130px;
            display: inline-block;
        }
       .date_picker1 label{
            margin:0px;
            width:50px;
           font-weight: bold;
        }
        .date_picker2 label{
            margin:0px;
            width:50px;
            margin-left:10px;
            font-weight: bold;
        }
        .load_more_entity{
         cursor: pointer;
        background-color: #D0CCC9;
       height:25px;
        margin:10px;
        margin-top:39px;
        text-align:center;
       
         border-style: ridge;
      
        }
           .load_more_user_entity{
         cursor: pointer;
        background-color: #D0CCC9;
        border-color: #1A5C76;
        margin:10px;
        margin-top:166px;
        text-align:center;
       
         border-style: ridge;
        border:2px solid #1A5C76 ;
        }
        h6{
            margin:0;
        }
        #book_mark_content{
        height:600px;
          margin-top: 49px;
        }
        textarea{
            margin:2px;
            resize: vertical;
            
           width: 579px;
        }
        .previous_comments
        {   margin:8px;
            margin-left:5px;
             width: 579px;
             height:auto;
             border:1px solid;
             min-height: 50px;
             border-color: #D0CCC9;
        }
        .comments{
            display:none;
            
        }
        #comment_click{
            cursor:pointer;
            font-size: 15px;
             color: #ABABBD;
               margin-left: 13px;
        }
        #comment_submit{
            
            position:relative;
        }
        .comment_info{
            font-size: 10px;
            color: #898989;
            margin-top:28px;
        }
         .comment_info b{
            font-size: 10px;
            color: #1A5C76;
           
        }
        .selected_entity{
              background-color: rgb(209, 220, 234);
           
        }
        .arrowMarkIcon{
            transform: rotate(180deg);
        }
         .arrowMarkIconTags{
            transform: rotate(90deg);
        }
        .ignore_settings{
            float:left;
            margin-left:580px;
        }
        .tags:hover{
            cursor:pointer;
            color: #0000FF;
        }
        .applied_filters{
           width: 623px;
            margin-top: 14px;
            min-height: 27px;
            margin-bottom: -10px;
            margin-left: 20px;
            color: #C8BFBF;
           border-bottom: 2px solid;
          
            
        }
        .arrowMarkIconTags {
        background: url("../images/kolm-sprite-image.png") repeat scroll -86px -87px transparent;
        width: 23px;
        height: 30px;
      }
      #statForm{
          height:auto;
      }
      a{
          cursor:pointer;
      }
      .show_tags tr{
           border:1px solid greenyellow;
           border-style: ridge;
           
           color:#000;
      }
      .bk_horizontal_line {
  width: 601px;
  height: 2px;
  background-color: #C8BFBF;
    
}
.table_entity_name {
   display: inline-block;
   width: 420px;;
   text-wrap: normal;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
    margin: -3px;
  margin-left: 2px;
  margin-top:1px;
}


.table_entity_count {
    color:#847B7B;
   display: inline-block;
   width: 52px;
}
.entity_name {
   display: inline-block;
   width: 142px;;
   text-wrap: normal;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
    margin: -3px;
  margin-left: 2px;
  margin-top:1px;
}


.entity_count {
    color:#847B7B;
   display: inline-block;
   width: 52px;
}
.cat_show_more{
    margin-top:3px;
    font-weight: normal;
    display:inline-table;
    margin-right: 28px;
}
</style>
</head>
<script src="<?php echo base_url();?>js/chosen.jquery.js"></script>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet" />
<div style="margin:5px;border:1px solid;border-color: #C3B8B0">
  <div style="text-align: center"><b >Medical News tailored to your interests</b></div>
    <div><img style='margin:5px;' alt='Medical News tailored to your interests' src="<?php echo base_url()?>images/aissel.png" style='' /></div><hr/>
  

<p style='margin:5px;'>Hi <?php echo ucfirst($userName)?>,</p><br/>
<!--<p><b><?php echo $date ?></b><br/><nr/>-->
<table style="width: 100%; font-size:13px;word-wrap:break-word;
              table-layout: fixed;"><tr><td >
<div style='margin:5px;'>In the news today: <br/><br/>
  
    <?php
    $i=1;
  
    $peoplText='';
    $diseaseText='';
    $organizationText='';
    $technologyText='';
    $productText='';
    $companyText='';
   
    foreach($topPeople as $people)
         $peoplText .=$people.",&nbsp;";
    if(!empty($topPeople) && $i<=3)
    {
          echo "<b style='margin:5px;'>People:</b>&nbsp;&nbsp;";
        $i++;
     echo substr($peoplText, 0, -7);
      echo "<br/><br/>";
    }
   
    
     foreach($topDiseases as $disease)
        $diseaseText.= $disease.",&nbsp;";
     if(!empty($diseaseText) && $i<=3)
    {
          echo "<b style=' word-break:break-all;margin:5px;'>Disease:</b>";
         $i++;
      echo substr($diseaseText, 0, -7);
        echo "<br/><br/>";
    }
    
  
     foreach($topOrganization as $organization)
        $organizationText.=$organization.",&nbsp;";
      if(!empty($organizationText) && $i<=3)
    {  echo "<b style='margin:5px;'>Organization:</b>";
         $i++;
   echo substr($organizationText, 0, -7);
     echo "<br/><br/>";
    }
   
   foreach($topTechnology as $technology)
        $technologyText.=$technology.",&nbsp;";
    if(!empty($technologyText) && $i<=3)
    {echo "<b style='margin:5px;'>Technology:</b>";
         $i++;
   echo substr($technologyText, 0, -7);
     echo "<br/><br/>";
    }
   foreach($topProduct as $product)
         $productText.=$product.",&nbsp;";
      if(!empty($productText) && $i<=3)
    {
          echo "<b style='margin:5px;'>Product:</b>";
         $i++;
   echo substr($productText, 0, -7);
     echo "<br/><br/>";
    }
   foreach($topCompany as $company)
         $companyText.=$company.",&nbsp;";
      if(!empty($companyText) && $i<=3)
    {echo "<b style='margin:5px;'>Company:</b>";
         $i++;
   echo substr($companyText, 0, -7);
   
    }
    ?>
    </div>
        </td></tr></table>
   <hr/>

 <div >
                <?php
                $commentFlag=0;
                $base=base_url();
               
                    foreach($resutlArticles as $value)
                    {

                        $old_date_timestamp = strtotime($value['date']);
                    $new_date = date('M d,Y ', $old_date_timestamp);  
                    echo "<table ><tr><td style=\"font-family: sans-serif;font-size:13px\" width='100%'>";
                    
                    echo "<div >";
                    echo "<img  src=".$value["img_url"]." align=\"left\" height=\"68\" width=\"108\" border=\"0\" hspace=\"5\" vspace=\"5\"   />";
                    
                    
                    echo "<div style=' height:auto;
        min-height: 76px;'>";
                    echo "<a style='font-size:13px' id=\"hyper\" target=\"_blank\" href=".$value["rss_feed_url"]."><b>".$value['title']."</b></a><br/>";
                    echo "<b>".$value["publisher"].":</b> ".$new_date."<br/>";
                    echo "<p><b></b>".strip_tags($value["description"])."</p>";
                    echo "</div>";
                   
                  
                    echo " </div>";
                  
                    echo "</td></tr></table>";
                    echo "<hr style='  border-color: #D2C8C8 !important;
  display: block;
  height: 1px;
  border: 0;
  border-top: 1px solid #C3AFAF;
  /* margin: 1em 0; */
  padding: 0;' />";
                    //echo "<hr/>";
                    $commentFlag=0;
                
                }
               
                ?>
                
         <h4 style='text-align: center'><a href='<?php echo base_url()?>medintel/1'>View more news online</a></h4>
         <p style='text-align:center;font-size:12px;color:#849187'>You have received this news alert as a user of KOLM. To change the preferences of the topics in the news that you want to track, login to KOLM and click on the topics as favourites.<br/>
             To login to KOLM:<a href="<?php echo base_url()?>medintel"> <?php echo base_url()?>medintel</a><br/>
MedIntel, the Medical News Intelligence and Tracking;  Powered by Aissel</p><br/>
            </div>
</div>


