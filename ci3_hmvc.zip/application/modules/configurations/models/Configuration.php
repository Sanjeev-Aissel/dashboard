<?php
class Configuration extends CI_Model {
	function getClientModules($start,$limit,$sidx,$sord,$arrFilter,$count=false){
		$client_id=$arrFilter['client_id'];
		unset($arrFilter['client_id']);
		if (array_key_exists('module_name', $arrFilter)) {
			$arrFilter['module_details.module_name']	= $arrFilter['module_name'];
			unset($arrFilter['module_name']);
		}
		$this->db->select("module_details.*,(CASE WHEN  id in (select distinct module_id from client_module_visibilities where client_id=$client_id AND visibility=1 )THEN '1' ELSE '0' END) assigned");
		foreach($arrFilter as $columnName=>$columnValue){
			$this->db->like($columnName,$columnValue);
		}
		if($count)
		{
			$query = $this->db->get('module_details');
			return $query->num_rows();
		}
		else
		{
			$this->db->limit($limit);
			$this->db->order_by($sidx,$sord);
			return $this->db->get('module_details',$limit,$start);
		}
	}
	function associateOrDissociateModuleToClient($arrData) {
		$module_ids=explode(',',$arrData['module_id']);
		if(!(is_numeric($module_ids[0]))){
			array_shift($module_ids);
		}
		$details['modified_by']=$this->session->userdata('user_id');
		$details['modified_on']=date('Y-m-d H:i:s');
		$details['visibility']=$arrData['is_associate'];
		$details['client_id']=$arrData['client_id'];
		
		foreach ($module_ids as $key=>$module_id){
			$num=0;
			$details['module_id']=$module_id;
			$this->db->select('id');
			$this->db->where('client_id',$arrData['client_id']);
			$this->db->where('module_id',$module_id);
			$query = $this->db->get('client_module_visibilities');
			$num = $query->num_rows();
			if($num==1){
				$this->db->where('client_id',$details['client_id']);
				$this->db->where_in('module_id',$details['module_id']);
				$this->db->update('client_module_visibilities',$details);
			}
			else {
				$this->db->insert('client_module_visibilities', $details);
			}
		}
		$is_updated=$this->db->affected_rows();
		//Hide/show menues of that client-Module
		$this->db->select('id');
		$this->db->where('client_id',$arrData['client_id']);
		$this->db->where_in('module_id',$module_ids);
		$arrMenuIds = $this->db->get('client_menu_visibilities');
		foreach($arrMenuIds->result_array() as $menu_id)
			$menu_ids[]=$menu_id['id'];
		$hideMenuDetails['visibility_id']=$arrData['is_associate'];
		$hideMenuDetails['ids']=implode(',', $menu_ids);
		if(sizeof($menu_ids)>0){
			$this->updateMenuVisibility($hideMenuDetails);
		}
		return ($is_updated > 0) ? TRUE : FALSE;
	}
	function listClientMenuesJqgrid($start,$limit,$sidx,$sord,$arrFilter,$count=false)
	{
		$client_id=$arrFilter['client_id'];
		unset($arrFilter['client_id']);
		if (array_key_exists('module_name', $arrFilter)) {
			$arrFilter['module_details.module_name']	= $arrFilter['module_name'];
			unset($arrFilter['module_name']);
		}
		if (array_key_exists('is_visible', $arrFilter)) {
			$pattern = '/'.$arrFilter['is_visible'].'/i';
			if(preg_match($pattern, "no")) {
				$arrFilter['client_menu_visibilities.is_visible']	= 0;
			}else if(preg_match($pattern, "yes")) {
				$arrFilter['client_menu_visibilities.is_visible']	= 1;
			}else{
				$arrFilter['client_menu_visibilities.is_visible']	= -1;
			}
			unset($arrFilter['is_visible']);
		}
		if (array_key_exists('primaryName', $arrFilter)) {
			$arrFilter['primary_name.label']	= $arrFilter['primaryName'];
			unset($arrFilter['primaryName']);
		}
		if (array_key_exists('secondaryName', $arrFilter)) {
			$arrFilter['primary_name.label']	= $arrFilter['secondaryName'];
			unset($arrFilter['secondaryName']);
		}
		if (array_key_exists('label', $arrFilter)) {
			$arrFilter['client_menu_visibilities.label']	= $arrFilter['label'];
			unset($arrFilter['label']);
		}
		$this->db->select('client_menu_visibilities.*,module_details.module_name,primary_name.label as primaryName,primary_name.parent_id as prim_parent_id,secondary_name.label as secondaryName,secondary_name.parent_id as sec_parent_id');
		$this->db->join('client_menu_visibilities as primary_name','primary_name.id=client_menu_visibilities.parent_id','left');
		$this->db->join('client_menu_visibilities as secondary_name','secondary_name.id=primary_name.parent_id','left');
		$this->db->join('module_details','module_details.id=client_menu_visibilities.module_id','left');
		$this->db->where('client_menu_visibilities.client_id',$client_id);
		if (array_key_exists('is_primary', $arrFilter)) {
			$pattern = '/'.$arrFilter['is_primary'].'/i';
			if(preg_match($pattern, "no")) {
				$this->db->where('client_menu_visibilities.parent_id>',0,false);
			}else if(preg_match($pattern, "yes")) {
				$this->db->where('client_menu_visibilities.parent_id','0');
			}else{
				$this->db->where('client_menu_visibilities.parent_id','-1');
			}
			unset($arrFilter['is_primary']);
		}
		foreach($arrFilter as $columnName=>$columnValue){
			$this->db->like($columnName,$columnValue);
		}
		if($count)
		{
			$query = $this->db->get('client_menu_visibilities');
// 			echo $this->db->last_query();exit;
			return $query->num_rows();
		}
		else
		{
			$this->db->limit($limit);
			$this->db->order_by($sidx,$sord);
			return $this->db->get('client_menu_visibilities',$limit,$start);
		}
	}
	function menuListing($client_id=null){
		$this->db->select('client_menu_visibilities.*,primary_name.label as primaryName,primary_name.parent_id as prim_parent_id,secondary_name.label as secondaryName,secondary_name.parent_id as sec_parent_id');
		$this->db->join('client_menu_visibilities as primary_name','primary_name.id=client_menu_visibilities.parent_id','left');
		$this->db->join('client_menu_visibilities as secondary_name','secondary_name.id=primary_name.parent_id','left');
		if($client_id!=null){
			$this->db->where('client_menu_visibilities.client_id',$client_id);
		}
		$this->db->where('client_menu_visibilities.is_visible',1);
		$query=$this->db->get('client_menu_visibilities');
		$result = $query->result_array();
		$arrModuleId=array();
		foreach($result as $key=>$value){
			if($value['parent_id']==0){
				$arrModuleId[$value['label']][]=$value['url'];
			}
			else if(($value['parent_id']!=0) && ($value['prim_parent_id']==0)){
				$arrModuleId[$value['primaryName']][$value['label']][]=$value['url'];
			}
			else if(($value['parent_id']!=0) && ($value['prim_parent_id']!=0) && ($value['sec_parent_id']==0)){
				$arrModuleId[$value['secondaryName']][$value['primaryName']][$value['label']][]=$value['url'];
			}
		}
		return $arrModuleId;
	}
	function getUnassignedModulesOfClient($client_id)
	{
		$modules=array();
		$this->db->select("id");
		$this->db->where("id IN (select distinct module_id from client_module_visibilities where client_id=$client_id AND visibility=0)");
		$arrModuleIds = $this->db->get('module_details');
		foreach($arrModuleIds->result_array() as $module_id)
			$modules[]=$module_id['id'];
		return $modules;
	}
	function getModulesList()
	{
		$modules=array();
		$this->db->select("id,module_name");
		$arrModuleDetails = $this->db->get('module_details');
		$arrModuleId=$arrModuleDetails->result_array ();
		foreach($arrModuleId as $module)
			$modules[$module['id']]=$module['module_name'];
		return $modules;
	}
	function getMenuDeatilsByMenuId($menuId){
		$this->db->select('client_menu_visibilities.*,prim_menu_level.parent_id as prim_parent');
		$this->db->join('client_menu_visibilities as prim_menu_level','client_menu_visibilities.parent_id=prim_menu_level.id','left');
		$this->db->where('client_menu_visibilities.id',$menuId);
		$this->db->limit(1);
		$query=$this->db->get('client_menu_visibilities');
		$result = $query->result_array();
		return $result[0];
	}
	function markAsLandingPage($arrDetails){
		$menu_id=$arrDetails['menu_id'];
		$client_id=$arrDetails['client_id'];
		$this->db->where('client_id',$client_id);
		$this->db->update('client_menu_visibilities',array('is_landing_page' => '0'));
		$this->db->where('id',$menu_id);
		$id=$this->db->update('client_menu_visibilities',array('is_landing_page' => '1'));
		return $id;
	}
	function deleteMenuById($id)
	{
		$deleteQuery	= "DELETE ca
		FROM    client_menu_visibilities ca
		LEFT JOIN
		client_menu_visibilities as cb
		ON     ca.parent_id=cb.id
		WHERE ca.id  =$id
		OR ca.parent_id =$id
		OR cb.parent_id  =$id";
		$this->db->query($deleteQuery);
		if ($this->db->affected_rows() > 0)
			return TRUE;
		else
			return FALSE;
	}
	function updateMenuVisibility($arrData) {
		$menu_ids= "'".str_replace(",","','",$arrData['ids'])."'";
		$updateQuery	= "UPDATE client_menu_visibilities ca
							left JOIN client_menu_visibilities cb
							ON ca.parent_id=cb.id
							SET `ca`.`is_visible` =".$arrData['visibility_id']."
							WHERE `ca`.`id` IN($menu_ids)
							OR `ca`.`parent_id` IN($menu_ids)
							OR `cb`.`parent_id` IN($menu_ids)
							";
		$this->db->query($updateQuery);
		if ($this->db->affected_rows() > 0)
			return TRUE;
		else
			return FALSE;
	}
	function insertOrUpdatemenu($arrDetails){
		$id = $arrDetails['id'];
		if($id>0)
		{
			$arrDetails['modified_by']=$this->session->userdata('user_id');
			$arrDetails['modified_on']=date('Y-m-d H:i:s');
			$this->db->where('id',$id);
			$a=$this->db->update('client_menu_visibilities',$arrDetails);
			if($id)
				return $id;
			else
				return false;
		}
		else
		{
			$arrDetails['created_by']=$this->session->userdata('user_id');
			$arrDetails['created_on']=date('Y-m-d H:i:s');
			$arrDetails['id']=NULL;
			$this->db->insert('client_menu_visibilities',$arrDetails);
			$id=$this->db->insert_id();
			return $id;
		}
	}
	function insertOrUpdateModule($arrDetails){
		$this->db->where('module_name',$arrDetails['module_name']);
// 		$this->db->where('version',$arrDetails['version']);
		$query = $this->db->get('module_details');
		if($query->num_rows()>0)
		{
			$arrDetails['modified_by']=$this->session->userdata('user_id');
			$arrDetails['modified_on']=date('Y-m-d H:i:s');
			$this->db->where('module_name',$arrDetails['module_name']);
			$this->db->update('module_details',$arrDetails);
			if ($this->db->affected_rows() > 0)
				return TRUE;
			else
				return FALSE;
		}
		$arrDetails['created_by']=$this->session->userdata('user_id');
		$arrDetails['created_on']=date('Y-m-d H:i:s');
		$this->db->insert('module_details',$arrDetails);
		$id=$this->db->insert_id();
		if ($id >= 0)
			return TRUE;
		else
			return FALSE;
	}
	function getMenusOfClient($client_id,$prim_menu_id=0){
		$arrModuleId=array();
		$menu=array();
			$this->db->select('*');
			$this->db->where('parent_id',$prim_menu_id);
			$this->db->where('client_id',$client_id);
			$query=$this->db->get('client_menu_visibilities');
			$result = $query->result_array();
			if($prim_menu_id==0){
				$arrModuleId[0]='None';
				foreach($result as $key=>$value){
					$arrModuleId[$value['id']]=$value['label'];
				}
			}
			else{
				foreach($result as $key=>$value){
					$menu['id']= $value['id'];
					$menu['label']= $value['label'];
					$arrModuleId[]=$menu;
				}
			}
		return $arrModuleId;
	}
	function listClientRoles($start,$limit,$sidx,$sord,$arrFilter,$count=false)//to get list of countries with jqgrid filters applied
	{
		$client_id=$arrFilter['client_id'];
		unset($arrFilter['client_id']);
		$this->db->select("roles.*,(CASE WHEN  id in (select distinct role_id from client_roles where client_id=$client_id AND is_associated=1 )THEN '1' ELSE '0' END) assigned");
		foreach($arrFilter as $columnName=>$columnValue){
			$this->db->like($columnName,$columnValue);
		}
		if($count)
		{
			$query = $this->db->get('roles');
			return $query->num_rows();
		}
		else
		{
			$this->db->limit($limit);
			$this->db->order_by($sidx,$sord);
			return $this->db->get('roles',$limit,$start);
		}
	}
	function associateOrDissociateRoleToClient($arrData) {
		$role_ids=explode(',',$arrData['role_ids']);
		if(!(is_numeric($role_ids[0]))){
			array_shift($role_ids);
		}
		$details['modified_by']=$this->session->userdata('user_id');
		$details['modified_on']=date('Y-m-d H:i:s');
		$details['is_associated']=$arrData['is_associate'];
		$details['client_id']=$arrData['client_id'];
		foreach ($role_ids as $key=>$role_id){
			$num=0;
			$details['role_id']=$role_id;
			$this->db->select('id');
			$this->db->where('client_id',$arrData['client_id']);
			$this->db->where('role_id',$role_id);
			$query = $this->db->get('client_roles');
			$num = $query->num_rows();
			if($num==1){
				$this->db->where('client_id',$details['client_id']);
				$this->db->where_in('role_id',$details['role_id']);
				$this->db->update('client_roles',$details);
			}
			else {
				$this->db->insert('client_roles', $details);
			}
		}
		return ($this->db->affected_rows() > 0) ? TRUE : FALSE;
	}
	function listRoles($role_id=NULL){ //for cloning role permission ,we neeed list of role names,except present role,which we are editing
		$this->db->select('*');
		if($role_id!=NULL){
			$this->db->where('id!=',$role_id,false);
		}
		$this->db->order_by('id','asc');
		$arrModuleDetails = $this->db->get('roles');
		return $arrModuleDetails->result_array ();
	}
	function insertOrUpdateRole($arrDetails){
		$id = $arrDetails['id'];
		if($id>0)
		{
			$arrDetails['modified_by']=$this->session->userdata('user_id');
			$arrDetails['modified_on']=date('Y-m-d H:i:s');
			$this->db->where('id',$id);
			$a=$this->db->update('roles',$arrDetails);
			if($id)
				return $id;
			else
				return 0;
		}
		else
		{
			$arrDetails['created_by']=$this->session->userdata('user_id');
			$arrDetails['created_on']=date('Y-m-d H:i:s');
			$arrDetails['id']=NULL;
			$this->db->insert('roles',$arrDetails);
			$role_id=$this->db->insert_id();
			
			$this->db->select('id');
			$query=$this->db->get('clients');
			$array1=$query->result_array();
			$arrClientIds = array_map (function($value){
				return $value['id'];
			},$array1);
			$associationDetails['role_id']=$role_id;
			$associationDetails['is_associated']=0;
			foreach ($arrClientIds as $client_id){
				$associationDetails['client_id']=$client_id;
				$this->db->insert('client_roles',$associationDetails);
			}
			return $role_id;//returns role_id
		}
	}
	function listRoleActions(){
		$this->db->select('name');
		$query=$this->db->get('role_actions');
		$array1=$query->result_array();
		$arrActionNames = array_map (function($value){
			return $value['name'];
		},$array1);
		return $arrActionNames;
	}
}