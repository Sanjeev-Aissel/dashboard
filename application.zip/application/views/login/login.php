<style>
.logo {
    background: rgba(0, 0, 0, 0) url(<?php echo base_url();?>/images/colgate_logo.jpg) no-repeat scroll 20px 0 / 150px auto; 
}
</style>
	<div  class="container">
		<table style="width:100%;border-collapse: collapse;">
			<!-- <tr>
				<td colspan="2" class="productNameContainer"><h2 class="productName"><?php echo PRODUCT_NAME;?></h2></td>
			</tr> -->
			<tr>
				<td style="padding:10% 0 0% 10%;">
					<div class="logo"></div>
				</td>
				<td style="padding:10% 0% 0% 0%;">
					<div id="loginContainer">
					<div id="loginWrapper">
					<div  title="Login" id="loginFormContainer">
					<form action="<?php echo base_url()?>login/do_login" method="post" id="loginForm" autocomplete="off">
						<table width="100%" border="0" cellspacing="4" cellpadding="3" style="padding: 15px;">
							<tr> 
								<td colspan="2" style="color:#FF0000;text-align: center;"><?php if(isset($error_message)){echo $error_message;}?></td>
							</tr>
							<tr>
								<td>Username</td>
								<td><input type="text" name="userid" class="textBox"  /></td>
							</tr>
							<tr>
								<td>Password</td>
								<td><input type="password" name="password" class="textBox" /></td>
							</tr>
							<tr>
								<td></td>
								<td align="center"><input type="submit" name="submit" value="Login" class="submitBtn"/> &nbsp;<input type="reset" value="Cancel" class="submitBtn" /></td>
							</tr>
							<tr>
								<td></td>
								<td align="center"><a href="<?php echo base_url();?>login/show_forgot_password_page">Forgot my password</a></td>
							</tr>
						</table>
					</form>
					</div>
					</div>
					</div>
				</td>
			</tr>
			<tr>
				<td colspan="2" style="padding: 0 0 10% 10%;">
					<table style="width:50%">
						<tr>
							<th style="text-align: left;text-decoration: underline;">Contact Helpdesk</th>
							<!-- <th style="text-align: left;text-decoration: underline;">Helpdesk Hours</th>  -->
						</tr>
						<caption></caption>
						<tr>
							<td></td>
							<td>
								
							</td>
						</tr>
						<tr>
							<td valign="top">
								<!-- Phone: +1-877-232-4234<br />  -->
								Email: support@aissel.com</td>
							<!-- <td>
								Mon - Fri  7.00 AM to Midnight<br />
								Sun - 2.00 PM to 10.00 PM<br />
								Saturday Closed
							</td>  -->
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</div>
</body>
</html>