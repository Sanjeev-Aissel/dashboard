<?php
/*
 * To add surveys
 *  
 * @Author		: Laxman K
 * @since 		: KOLM v5.5 Otsuka 1.0.11
 * Created on	: 30-03-2013
 *  
 */
?>
<style type="text/css">
	#contentWrapper.span-23 {
		background-image: url("<?php echo base_url();?>images/verticlesep_terNav.jpg");
	    background-position: 135px 50%;
	    background-repeat: repeat-y;
	}
	#surveyContainer caption{
		font-weight: bold;
		background: -moz-linear-gradient(center top , #ffffff 0%, #E6E6E6 100%) repeat scroll 0 0 transparent;
		background: -webkit-gradient(linear,left top,left bottom,color-stop(0%,#ffffff),color-stop(100%,#E6E6E6));
		background: -webkit-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		background: -o-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		background: -ms-linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#ffffff,endColorstr=#E6E6E6,GradientType=0);
		background: linear-gradient(top,#ffffff 0%,#E6E6E6 100%);
		border: 1px solid #333;
		color:#333;
		margin-bottom: 10px;
	}
	#surveyContainer th{
		background-color: #eee;
		border: 1px solid #aaa;
	}
	#surveyContainer th.number{
		background-color: #aaa;
		color:#333;
		text-align: justify;
		width:10px;
	}
	.addLink{
		text-align: right;
	}
	.buttonsWarpper{
		padding-bottom: 5px;
	}
	#surveyContainer{
		border-bottom: 1px solid #aaa;
		position: relative;
	}
	#tooltip-active-surveys{
		left: 130px;
    	position: absolute;
    	top: 8px;
	}
	.tooltip.in {
	    opacity: 1.00 !important;
	}
	#surveyContainer .blueButton{
		display: block;
	}
</style>
<script type="text/javascript">
var customOk = "Yes";
var customCancel = "No";
var is_disclaimer = parseInt(<?php echo $disc;?>);
//	$(document).ready(function (){
//		if(is_disclaimer == 1){
//			jAlert("<div style='border-bottom: 1px solid #1b1b1b;text-align:center;'>Disclaimer</div><div style='text-align:left;'> NOTICE: Data shown in the iMap tool are for internal Otsuka use only and are not to be shared outside of Otsuka. The data in this tool may be used for promotional speaker program development. This tool is not intended for call plan development; healthcare professionals appearing in this tool may not be on your call plan and may not be appropriate for call activity based on the product you promote. Existing call plan development and targeting policies and procedures must be followed at all times. Off-label promotion is prohibited.</div>");
//		}
//	});

	<?php if($withinProfile){?>
	var kolId = <?php echo $this->uri->segment(3)?>;
	function isKolAlreadySurvey(surveyId,thisEle){
//		alert("dd");
		var urlString = $(thisEle).attr("href");
		$.ajax({
			url:'<?php echo base_url()?>surveys/check_kol_already_survey/'+surveyId+'/'+kolId,
			type:'post',
			dataType:'json',
			success: function(returnData){
				if(returnData.status=='exists'){
					jConfirm(returnData.recent_user+" Interacted with "+returnData.respoName+"</br> on "+returnData.created_on+"</br> Would you like to continue?","Please confirm",function(r){
						if(r){
							window.location.replace(urlString);
//							return true;
						}else{
							return false;							
						}
					});
				}else{
					window.location.replace(urlString);
//					return true;
				}
			}
		});
	}
	<?php }?>
</script>
<?php $helpLink = "<a class='help-link' href='".getSSOUrl($this->session->userdata('user_full_name'), $this->session->userdata('email'))."&redirect_to=/support/solutions/articles/134479-filling-in-the-peer-nomination-survey-responses' target='_new'>View Additional Help</a>"; ?>
<div id="container">
<div id="surveyContainer">
	<!--<div class="buttonsWarpper">
		<div class="addLink">
			<a class="blueButton" href="<?php base_url();?>surveys/list_surveys">Surveys List</a>
		</div>
	</div>-->
	<table>
		<caption>Influencer Surveys</caption>
		<span id="tooltip-active-surveys" class="map-info tooltop-bottom"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>These are the surveys that are live and in active status. You can submit a response to these surveys by clicking on Start Response.<?php echo $helpLink;?></span>">&nbsp;</a></span>
	<?php
		$i	= 0; 
//		pr($arrSurveys);
		foreach($arrSurveys as $index=>$arrRow){
	?>
			<tr>
				<th class="number"><?php echo ++$i;?></th>
				<th colspan="2"><?php echo $arrRow['name'];?></th>
			</tr>
			<tr>
				<td></td>
				<td>
					<?php echo (!empty($arrRow['description']))?$arrRow['description'].'<br />':'';?>
					<?php /*if(isset($arrRow['end_date'])){
						echo '<strong>Survey Ends on <span class="endDate">'.$arrRow['end_date'].'</span></strong>';
					}*/?>
				</td>
				<?php if($withinProfile){?>
					<td width="105px" style="padding-right:0px;"><a onclick="isKolAlreadySurvey(<?php echo $arrRow['id'];?>,this);return false;" class="blueButton" href="<?php echo base_url();?>surveys/survey_form/<?php echo $arrRow['id'];?>">Start</a></td>
				<?php }else{?>
					<td width="105px" style="padding-right:0px;"><a class="blueButton" href="<?php echo base_url();?>surveys/survey_form/<?php echo $arrRow['id'];?>">Start</a></td>
				<?php }?>
			</tr>
	<?php }?>
	</table>
	<!-- 
	 <div>
		<div><label>REMEMBER:</label> Before asking your Target HCP questions remember to state that: "Dr. I wanted to get your thoughts on whom you deem to be influential nationally and locally. This will help us understand the healthcare environment in which you work and help me bring relevant information to you and your practice."</div>
		<div><label>NOTE:</label>The iMAP tool does not change or up-date your call plan or change the target review and approval process.</div>
		<div>Follow all Otsuka policies and your training before, during and after calling on or otherwise communicating with HCPs who appear in the iMAP application.</div>
	</div>
	 -->
	<center><span id="startSurveyForHints" style="padding-bottom: 15px;"></span></center>
</div>
</div>