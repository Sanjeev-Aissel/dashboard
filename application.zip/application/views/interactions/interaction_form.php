<?php
/**
 * This is HTML form for Adding or Editing the Interation details
 * 
 * @author Ramesh B
 * @Created on: 28-02-11
 * @since  1.5	
 * @package application.views.interactions
 */
$interactionKolAutoCompleteOptions = "width: 300, delimiter: /(,|;)\s*/, deferRequestBy: 200, noCache: true, minChars: 3";
?>
<link href="<?php echo base_url();?>css/chosen.css" media="screen" rel="stylesheet">
<!--<script type="text/javascript" src="<?php echo base_url();?>js/chosen.jquery.js"></script>
--><style type="text/css">
	.interactionAddModalContainer .ui-dialog-titlebar{
	    float: right;
	    height: 20px;
	    margin-bottom: -44px;
	    width: 25px;
	    z-index: 100;
	}
	.interactionAddModalContainer .analystForm td{
		padding-bottom:0px;
	}
	.interactionAddModalContainer .formHeader{
		padding-bottom: 12px;
	}
	#interactionForm textarea{
		width: 90%;
	}
	#notesLable{
		width: 12%;
	}
	label span.mandatory{
		color:red;
	}
	.interactionAddModalContainer .analystForm label {
		width: 25%;
 		margin: 0.2em 0;	
 	}
	#clientInteractionNotes table.jqTransformTextarea{
		width:80%;
	}
	#clientInteractionNotes table.jqTransformTextarea td{
		border:0px solid red;
	}	
	#clientInteractionNotes table.jqTransformTextarea td#jqTransformTextarea-tl{
		width:1% !important;
		background-position:2px top;		
	}
	#clientInteractionNotes table.jqTransformTextarea td#jqTransformTextarea-ml{
		width:1% !important;
		background-position: 2px top;
	}
	#clientInteractionNotes table.jqTransformTextarea td#jqTransformTextarea-bl{
		width:1% !important;
		background-position: 2px top;
	}
	#clientInteractionNotes table.jqTransformTextarea td#jqTransformTextarea-mr{
		width:1% !important;
	}
	#clientInteractionNotes table.jqTransformTextarea td#jqTransformTextarea-tr{
		width:1% !important;
	}
	#clientInteractionNotes table.jqTransformTextarea td#jqTransformTextarea-br{
		width:1% !important;
	}
/*	
	#interactionForm input, #interactionForm select, #interactionForm textarea{
		padding:3px;	
	}
*/
	#interactionForm input[type="text"]{
		width:167px;	
	}
	#interactionForm select{
		width:175px;	
	}
	#interactionForm .error {
		background-color: #FFFFFF;
		border: 1px solid #BBBBBB;
		background-image: none;;
		padding: 0px;
		color: gray;
		border: 1px solid red;
	}
	#interactionForm label.error{ 
		float: none; 
		color: red; 
		padding-left: .5em; 
		vertical-align: top; 
		border: 0px;
		padding: 0px;
		font-weight: normal;
	}
	#interactionForm p{
		float: none;
		margin-bottom: 0px;
	}
	#addMoreFile img{
		vertical-align: top;
	}
	.timePicker{
		width: 25px !important;
	}
	.timeap{
		width: 50px !important;
	}
	#interactionForm table.analystForm{
		margin-bottom: 0px;
	}
	#interactionForm input[type="text"], #interactionForm input.text, 
	#interactionForm input.title, #interactionForm textarea, #interactionForm select{
		margin: 0.2em 0;
	}
	#importOrgContainer .profileContent .microViewLoading {
		background-image: url("../images1/ajax-loader-round.gif") !important;
		background-position: center center;
		background-repeat: no-repeat;
		height: 0px !important;
		margin-top: 0px !important;
		text-align: center !important;
	}
	#docsList p span{
		display: block;
	    float: left;
	    margin-left: 2px;
	    width: 177px;
	}
	#docsList p label {
		float: left;
	}
	fieldset{
		padding: 4px !important;
		margin-bottom: 15px;
	}
	legend{
		color: #626262;
		font-size: 12px;
		padding: 0px 5px;
	}
	.chzn-choices{
		height:60px;
		width:100%;
	}
	#interactionForm table tr th,#interactionForm table tr td{
		padding-right:1px;
		padding-bottom:1px;
	}
	#interactionForm table.highlightHeadings tr th{
		background-color: #eee;
	}
	#interactionForm table tr th label{
		font-size: 11px;
		color: #626262;
	}
	#interactionForm #date, #interactionForm #followUpOn,#interactionForm #anttendies{
		width:80px;
	}
	#interactionForm #mode{
		width:150px;
	}
	#interactionForm #intLocation{
		width: 270px;
	}
	#interactionForm .arrKolNames{
		width:168px;
	}
/*	#interactionForm input, #interactionForm select, #interactionForm textarea{
		padding: 0px;
	}
*/
	.ui-dialog .ui-dialog-content{
		overflow: visible;
	}
	.microView .profileContent{
		margin-top: 0px;
		padding: 4px 6px 6px;
	}
	.formHeader {
	    margin-top: 0px;
	    margin-bottom:0px;
	    width: 200px;
	    padding-bottom: 5px;
  		padding-top: 0;
	}
	td.TextAlignCenter{
		text-align: center;
	}
	#interactionForm input.kolSpecialty{
		width: 150px;
	}
	
	#suggestions1 {
	    background-color: #999999;
	    border-radius: 0 0 5px 5px;
	    height: auto;
	    margin-top: -4px;
	    position: absolute;
	    display: none;
	    z-index: 1;
	    border: 1px solid #999999;
	}
	
	#suggestions2 {
	    background-color: #999999;
	    border-radius: 0 0 5px 5px;
	    height: auto;
	    margin-top: -4px;
	    margin-left: 31px;
	    position: absolute;
	    display: none;
	    z-index: 1;
	    border: 1px solid #999999;
	}
	
	.searchterm {
		clear: both;
	    display: block;
	    float: left;
	    text-align: center;
	    width: 25px;
	    cursor: default;
	}
	.searchterm:HOVER, .selectedData {
		background-color: white;
	}
	.chzn-container{
		width: 400px !important;
	}
	table.tabularGrid caption{
		background:url("<?php echo base_url();?>images/kolm-sprite-image.png") repeat-x scroll -2px -236px transparent;
	}
	.interactionWrapper{
		padding-left: 10px;
	    padding-right: 10px;
    }
    h5.heading{
    	background: none repeat scroll 0 0 #D8E5F4;
	    color: #2D53AF;
	    margin-bottom: 2px;
	    padding: 5px;
    }
   #interactionForm p.kolName, #interactionForm p#kolName{
    	float:left !important;
    }
    .microViewIcon{
    	display: inline;
    	float:left;
    }
</style>


<script type="text/javascript">

var kolAutoCompleteId ='';
var globalId='';
	var interactionKolAutoCompleteOptions = {
			<?php 
			if(KOL_CONSENT){?>
			serviceUrl: '<?php echo base_url();?>interactions/get_all_kol_names_for_autocomplete/0/1',
			<?php }else{ ?>
			serviceUrl: '<?php echo base_url();?>interactions/get_all_kol_names_for_autocomplete',
			<?php } ?>
			<?php echo $interactionKolAutoCompleteOptions;?>,
			onSelect : function(event, ui) {
				var kolId = $(event).children('.id1').html();
				var selText = $(event).children('.kolName').html();
				selText=selText.replace(/\&amp;/g,'&');
				$('#'+globalId).val(selText);
				$('#'+globalId).prev('input').prev('input').val(selText);
				$('#'+globalId).prev('input').val(kolId);
				//jAlert($('#'+globalId).parent().toSource());
				$('#'+globalId).parent().parent().find('.microViewIcon').show().attr('onclick','showMicroProfile("'+kolId+'"); return false;');
				getKolSpecialty();
			 }
		};

	$('#date').datepicker({
		changeMonth: true,
     changeYear: true,
		dateFormat: 'mm/dd/yy'
	});

	$('#followUpOn').datepicker({
		changeMonth: true,
     changeYear: true,
		dateFormat: 'mm/dd/yy'
	});

	$(document).ready(function(){

		var addNewKol = {
				title: "Add KOL",
				modal: true,
				autoOpen: false,
				width: 400,
				draggable:false,
				dialogClass: "microView",
				open: function() {
					//display correct dialog content
				}
		};
		$("#micro").dialog(addNewKol);



	
		var interactionKolAutoComplete	= $('#kolName').autocomplete(interactionKolAutoCompleteOptions);
		
		//Adds the another upload link below the current upload field //'not working here'
		$("#addMoreFile").click(function(){
			//jAlert('hi');
			var noOfFiles=0;
			noOfFiles=$("#noOfFiles").val();
			noOfFiles++;
		//	var newUpload="<p id='docContainer"+noOfFiles+"'><label for=docName"+noOfFiles+"> Doc name:</label>	<input type=\"text\" name=\"doc_name"+noOfFiles+"\" id=\"docName"+noOfFiles+"\" /><label for=\"description"+noOfFiles+"\"> Description: </label><input type=\"text\" name=\"description"+noOfFiles+"\" id=\"description"+noOfFiles+"\" /><label for=\"uploadFile"+noOfFiles+"\"> Upload: </label><input type=\"file\" name=\"int_ref_file"+noOfFiles+"\" id=\"intRefFile"+noOfFiles+"\"></input><label onclick='cancelFileUpload("+noOfFiles+");'><img src='<?php echo base_url();?>images/delete.png' alt='Cancel' title='Cancel'/></label></p>";
			var newUpload	= "<tr id=docContainer"+noOfFiles+"><td><input type=text name=doc_name"+noOfFiles+" id=docName"+noOfFiles+" /></td><td><input type=text name=description"+noOfFiles+" id=description"+noOfFiles+" /></td><td><input type=file name=int_ref_file"+noOfFiles+" id=intRefFile"+noOfFiles+" /></td><td class=TextAlignCenter><label onclick='cancelFileUpload("+noOfFiles+");'><img src='<?php echo base_url();?>images/delete.png' alt='Delete' title='Delete'/></label></td></tr>";
			$("#fileUploadContainer").append(newUpload);
			$("#noOfFiles").val(noOfFiles);
			//var interactionKolAutoComplete	= $('#kolName').autocomplete(interactionKolAutoCompleteOptions);
		});

		/*$('#date').datepicker({
			dateFormat: 'mm/dd/yy'
		});*/
		$('#date').focus(function(){
			$('table.ui-datepicker-calendar').show();
		});

		/*$('#followUpOn').datepicker({
			dateFormat: 'mm/dd/yy'
		});*/
		$('#followUpOn').focus(function(){
			$('table.ui-datepicker-calendar').show();
		});

		
		//Validate the interactions form using jquery plugin
		$("#addPlansForm").validate({
			debug:true,
			onkeyup:true
		});
		
		
		$("#interactionForm").validate();

		
		$("#timefmhr").focus(function(){
			$("#suggestions1").show();
			$("#suggestions2").hide();
	     });
             
	      $("#timefmmin").focus(function(){
	    	  $("#suggestions2").show();
	    	  $("#suggestions1").hide();
	      });

	   
		$("#interactionForm input").focus(function(){
			var selId = $(this).attr('id');
			if(selId != 'timefmhr' && selId != 'timefmmin'){
				$("#suggestions1").hide();
				$("#suggestions2").hide();
			}
	     });
		$("#interactionForm select").focus(function(){
			var selId = $(this).attr('id');
			if(selId != 'timefmhr' && selId != 'timefmmin'){
				$("#suggestions1").hide();
				$("#suggestions2").hide();
			}
	     });

		$('html').click(function() {
	    	  $("#suggestions1").hide();
	    	  $("#suggestions2").hide();
	 	 });

	 	 $('#suggestions1 .searchterm').click(function(event){
		 	 var selectedVal = $(this).html();
		 	 $("#timefmhr").val(selectedVal);
		 	 $("#suggestions1").hide();
		 	$("#suggestions1 .searchterm").removeClass("selectedData");
			$(this).addClass("selectedData");
	 	     event.stopPropagation();
	 	 }); 
	 	$('#suggestions2 .searchterm').click(function(event){
	 		 var selectedVal = $(this).html();
	 		 $("#timefmmin").val(selectedVal);
		 	 $("#suggestions2").hide();
		 	$("#suggestions2 .searchterm").removeClass("selectedData");
			$(this).addClass("selectedData");
	 	     event.stopPropagation();
	 	 });
	 	$('#timefmhr').click(function(event){
	 		$("#suggestions2").hide();
	 	     event.stopPropagation();
	 	 });
	 	$('#timefmmin').click(function(event){
	 		$("#suggestions1").hide();
	 	     event.stopPropagation();
	 	 });  

	 	$('#timefmhr').keydown(function(event) {
	 		$("#suggestions1").show();
		 	var selectedObj = $("#suggestions1 .selectedData");
	 		if (event.keyCode === 40) { //Down arrow
		 		if(selectedObj != null){
					var nextObj = $(selectedObj).next();
					if($(nextObj).hasClass("searchterm")){
						$(selectedObj).removeClass("selectedData");
						$(nextObj).addClass("selectedData");
						$(this).val($(nextObj).html());
					}else{
						var firstObj = $("#suggestions1 .searchterm:first");
						var lastObj = $("#suggestions1 .searchterm:last");
						$(lastObj).removeClass("selectedData");
						$(firstObj).addClass("selectedData");
						$(this).val($(firstObj).html());
					}
			 	}
	 		}	 	       
	 		else if (event.keyCode === 38) { //Up arrow
	 			if(selectedObj != null){
					var prevObj = $(selectedObj).prev();
					if($(prevObj).hasClass("searchterm")){
						$(selectedObj).removeClass("selectedData");
						$(prevObj).addClass("selectedData");
						$(this).val($(prevObj).html());
					}else{
						var firstObj = $("#suggestions1 .searchterm:first");
						var lastObj = $("#suggestions1 .searchterm:last");
						$(lastObj).addClass("selectedData");
						$(firstObj).removeClass("selectedData");
						$(this).val($(lastObj).html());
					}
			 	}
	 		}else if (event.keyCode === 13){
	 			$(this).val($(selectedObj).html());
	 			$("#suggestions1").hide();
	 			event.stopPropagation();
		 	}
	 	});

	 	$('#timefmmin').keydown(function(event) {
	 		$("#suggestions2").show();
		 	var selectedObj = $("#suggestions2 .selectedData");
	 		if (event.keyCode === 40) { //Down arrow
		 		if(selectedObj != null){
					var nextObj = $(selectedObj).next();
					if($(nextObj).hasClass("searchterm")){
						$(selectedObj).removeClass("selectedData");
						$(nextObj).addClass("selectedData");
						$(this).val($(nextObj).html());
					}else{
						var firstObj = $("#suggestions2 .searchterm:first");
						var lastObj = $("#suggestions2 .searchterm:last");
						$(lastObj).removeClass("selectedData");
						$(firstObj).addClass("selectedData");
						$(this).val($(firstObj).html());
					}
			 	}
	 		}	 	       
	 		else if (event.keyCode === 38) { //Up arrow
	 			if(selectedObj != null){
					var prevObj = $(selectedObj).prev();
					if($(prevObj).hasClass("searchterm")){
						$(selectedObj).removeClass("selectedData");
						$(prevObj).addClass("selectedData");
						$(this).val($(prevObj).html());
					}else{
						var firstObj = $("#suggestions2 .searchterm:first");
						var lastObj = $("#suggestions2 .searchterm:last");
						$(lastObj).addClass("selectedData");
						$(firstObj).removeClass("selectedData");
						$(this).val($(lastObj).html());
					}
			 	}
	 		}else if (event.keyCode === 13){
	 			$(this).val($(selectedObj).html());
	 			$("#suggestions2").hide();
	 			event.stopPropagation();
		 	}
	 	});
});


	function showMicroProfile(kolId){

		$(".microViewProfile").html("<div class='microViewLoading'>Loading...</div>");
		$("#micro").dialog("open");
		$(".microViewProfile").load(base_url+'kols/view_kol_micro/'+kolId);
		return false;	
	}
		
	//deletes the document with given document id
	function deleteDocument(documentId){
		$.ajax({
			url:'<?php echo base_url();?>interactions/delete_document/'+documentId,
			dataType:'json',
			success:function(returnData){
				if(returnData==true)
					$("#doc"+documentId).remove();
			}
		});
	}

	$(".test1").live("focus",function(){
		 kolAutoCompleteId = $(this).attr('id');
		//jAlert(id);
	});

	$(".test1").live("focus",function(){
		 globalId = $(this).attr('id');

		 var kolName = $(this).val();
		 var hiddenKolName = $(this).prev('input').prev('input').val();
		 if(kolName!=hiddenKolName){
			 $(this).next('img').hide();
		 }
		//jAlert(id);
	});

	$(".test1").live("blur",function(){
		
		 var kolName = $(this).val();
		 var hiddenKolName = $(this).prev('input').prev('input').val();
		 if(kolName!=hiddenKolName){
			 $(this).next('img').hide();
		 }
		//jAlert(id);
	});
	
	//get the kol specialty and make it as selected in thereapetic are.
	function getKolSpecialty(){
		var kolId	= $("#"+kolAutoCompleteId).prev().val();
		var kolName=$("#"+kolAutoCompleteId).val();
		var data = {};
		data['kol_name'] = kolName;
		
		
		if(kolName!=''){
			$.ajax({
				url:'<?php echo base_url()?>kols/get_kol_specialty_id/'+kolId,
				type:'post',
				data:data,
				dataType:"json",
				success:function(returndData){
					var speccialtyId=returndData.specialtyId;
					var specialtyName=returndData.specialtyName;
					$("#"+kolAutoCompleteId).parent().parent().parent().find('td').eq(1).find('input').val(specialtyName);
				}
			});
			if(kolAutoCompleteId=='kolName1'){
			$.ajax({
				url:'<?php echo base_url()?>interactions/getLocationDetails/'+kolId,
				type:'post',
				dataType:'json',
				success:function(returnData){
					var appendTr='';
					appendTr+="<tr>";
					appendTr+='<th></th>';
					appendTr+='<th>Location</th>';
					appendTr+='<th>Address1</th>';
					appendTr+='<th>Country</th>';
					appendTr+='<th>State</th>';
					appendTr+='<th>City</th>';
					appendTr+="</tr>";	
					$.each(returnData.kolLocations,function(key,value){
						
						
							appendTr+="<tr>";
							appendTr+='<td><input type="radio" name="selectedLocation" value="-1"/></td>';
							appendTr+='<td>'+value.location+'</td>';
							appendTr+='<td>'+value.address+'</td>';
							appendTr+='<td>'+value.country+'</td>';
							appendTr+='<td>'+value.state+'</td>';
							appendTr+='<td>'+value.city+'</td>';
							appendTr+="</tr>";	
							
							

					});
					
					$('#location').html(appendTr);
				}
				

				})
			}
		}else{
			$("#therapeuticArea").val("");
		}
	}

	//Validates the interaction form using jquery plugin
	function validateAndSubmitInteractionForm(){
		$.each($('.checkAboveInputValue'),function(){
			var kolName =$(this).val();
			var  mainkol=$(this).next('input').next('input').val();
			//jAlert(kolName);
		
			if(kolName != mainkol){
				$(this).next('input').val('');
			}
		});
	
		if(!$("#interactionForm").validate().form()){
			return false;
		}else{
			var status;
			$.each($('.test1'),function(){
				
				var kolName = $(this).val();
				kolName = $.trim(kolName);
				if(kolName.indexOf(' ')>=1){
				}else if(kolName.indexOf(',')>=1){
				}else{
					status='False';
					jAlert('Single word <?php echo lang('KOL'); ?> not allowed, please enter first and last name');
					return false;
				}
				
			});
			if(status=='False'){
				return false;
			}
			var noOfattndis = $('#anttendies').val();
			var noOfKols  =0;
			$.each($('.test1'),function(){
				noOfKols=parseInt(noOfKols)+1;
			});
		
			var noOfUsers=0;
			$.each($('.chosenMultipleSelect option:selected'),function(){
				noOfUsers=parseInt(noOfUsers)+1;
			});
			var totlAttendis = parseInt(noOfUsers)+parseInt(noOfKols);

			/*if(totlAttendis!=noOfattndis){
				jAlert('No of Attendees and No of names entered do not match');
				return false;
			}*/
			
			if(validateToFromTime())
				return true;
			else{
				return false;
			}

				//$.ajax({
				//	url:'<?php echo base_url();?>interactions/save_interaction',
				//	type:"post",
				///	data:$('#interactionForm').serialize()
				//});
				//return false;
			}
	}

	function validateToFromTime(){

		//Validate for time boudaries
		var fromHr=$( "#timefmhr" ).val();
		var fromMin=$( "#timefmmin" ).val();
		var toHr=$( "#timetohr" ).val();
		var toMin=$( "#timetomin" ).val();
		var timefmap = $('#timefmap').val();
		var timetoap = $('#timetoap').val();

		//validate hour bondries
		if(fromHr < 0 || fromHr > 12){
			jAlert("Invalid time");
			return false;
		}

		if(fromHr < 0 || fromHr > 12){
			jAlert("Invalid time");
		}

		//Validate for reqired
		if($( "#timefmhr" ).hasClass("required")){
			if(fromHr == "00" && toHr == "00"){
				if(fromMin == "00" && toMin == "00"){
					jAlert("time required");
					return false;
				}
			}
			
		}
		
		if(fromHr > toHr && timefmap == timetoap){
			jAlert("you can't end interaction before interaction starts. So enter interaction end time properly.");
			return false;
		}
		if((fromHr == toHr && timefmap == timetoap )&& fromMin > toMin){
			jAlert("you can't end interaction before interaction starts. So enter interaction end time properly.");
			return false;
		}

		//Validate for interaction date and folloupdate
		var interactionDate = new Date();
		var interactionDateText = $('#date').val();
		var followUpdate=new Date();
		var followUpdateText = $('#followUpOn').val();
		if(followUpdateText != ''){
			interactionDate.setFullYear(interactionDateText.split("/")[2], interactionDateText.split("/")[0], interactionDateText.split("/")[1])
			followUpdate.setFullYear(followUpdateText.split("/")[2], followUpdateText.split("/")[0], followUpdateText.split("/")[1])
			if(interactionDate > followUpdate){
				jAlert('Follow up date should be greater than Interaction date');
				return false;
			}
		}
		
		return true;
	}
	
	//If remindme is checked the add required for 'time' and 'followupon' else remove the same fro those
	function modifyValidations(){
		var reminder=$("#reminder:checked").val();
		if(reminder==1){
			//add required
			$("#timefmhr").addClass('required');
			$("#followUpOn").addClass('required');
			$("label[for='time']").append('<span class="required">*</span>');
			$("label[for='followUpOn']").append('<span class="required">*</span>');
			
		}else{
			//remove required
			$("#timefmhr").removeClass('required');
			$("#followUpOn").removeClass('required');
			$("label[for='time'] span").remove();
			$("label[for='followUpOn'] span").remove();
		}
	}

	//Removes the file upload row of the given row number
	function cancelFileUpload(fileNumber){
		$('#docContainer'+fileNumber).remove();
	}

	function getStatesByCountryId(){
		// Show the Loading Image
		$("#loadingStates").show();
		
		var countryId=$('#country_id').val();
		var params = "country_id="+countryId;	
		$("#state_id").html("<option value=''>-- Select State --</option>");
		$("#city_id").html("<option value=''>-- Select City --</option>");
		var states = document.getElementById('state_id');
		$.ajax({
			url: "<?php echo base_url()?>country_helpers/get_states_by_countryid/",
			dataType: "json",
			data: params,
			type: "POST",
			success: function(responseText){					
				$.each(responseText, function(key, value) {					
					var newState = document.createElement('option');
					newState.text = value.state_name;
					newState.value = value.state_id;
					 var prev = states.options[states.selectedIndex];
					 states.add(newState, prev);				
					});
				var lastOPtion = $('#state_id option:last').val();
				if(lastOPtion==''){
					$('#state_id option:last').remove();
					$('#state_id').prepend("<option value='' selected='selected'>-- Select State --</option>");
				}
				
			},
			complete: function(){
				$("#loadingStates").hide();
			}
		});		
	}
	
	/**
	* Returns the list of Cities of the Selected State
	*/
	function getCitiesByStateId(){
		// Show the Loading Image
		$("#loadingCities").show();
		
		var stateId=$('#state_id').val();
		$("#city_id").html("<option value=''>Select City</option>");	
		var cities = document.getElementById('city_id');
		var params = "state_id="+stateId;	
		if(stateId == ''){
			$("#loadingCities").hide();
			return false;
		}
		$.ajax({
			url: "<?php echo base_url()?>country_helpers/get_cities_by_stateid/",
			dataType: "json",
			data: params,
			type: "POST",
			success: function(responseText){					
				$.each(responseText, function(key, value) {	
							
				var newCity = document.createElement('option');
				newCity.text = value.city_name;
				newCity.value = value.city_id;
				 var prev = cities.options[cities.selectedIndex];
				 cities.add(newCity, prev);				
				});
                                $("#city_id option[value='']").remove();
                    $("#city_id").prepend("<option value=''>-- Select City --</option>");
                    $("#city_id").val("");
				
			},
			complete: function(){
				$("#loadingCities").hide();
			}		
		});		
		
	}
	function addMoreKols(){
		var kolSHtml = 	$('#kols').html();
		$('#kolsTable').append("<tr>"+kolSHtml+"</tr>");
		var noofKols = $('#noOfKols').val();
		var noOfFields = parseInt(noofKols)+1;
		$('#noOfKols').val(noOfFields);
		var kolFieldName = 'kol_name'+noOfFields;
		var kolFieldId = 'kolName'+noOfFields;
		$('#kolsTable tr:last td:eq(0) input:last').val('');
		$('#kolsTable tr:last td:eq(0) input:last').attr('name',kolFieldName);
		$('#kolsTable tr:last td:eq(0) input:last').attr('id',kolFieldId);
		$('#kolsTable tr:last td:eq(0) input:last').addClass('test1 autocompleteInputBox');

		$('#kolsTable tr:last td:eq(0) input:last').prev('input').prev('input').attr('id','kolNameAuto'+noOfFields).val('');
		$('#kolsTable tr:last td:eq(0) input:last').prev('input').prev('input').attr('name','kol_name_auto'+noOfFields);
		$('#kolsTable tr:last td:eq(0) input:last').prev('input').attr('name','kol_id_auto'+noOfFields);
		$('#kolsTable tr:last td:eq(0) input:last').prev('input').attr('id','kolIdAuto'+noOfFields).val('');
		//Hide the image
	//	$('#kolsTable tr:last td:eq(0) input:last').next('img').hide();
	//	$('#kolsTable tr:last td:eq(0) input:last').next('img').removeAttr('onClick');
		$('#kolsTable tr:last td:eq(0)').find('.microViewIcon').hide();
		$('#kolsTable tr:last td:eq(0)').find('.microViewIcon').removeAttr('onClick');
		

		var therapeutic_area = 'therapeutic_area'+noOfFields;
		$('#kolsTable tr:last td:eq(1) p input').attr('name',therapeutic_area);
		$('#kolsTable tr:last td:eq(1) p input').attr('id',therapeutic_area).val('');

		var attendee_note = 'attendee_note'+noOfFields;
		$('#kolsTable tr:last td:eq(2) p textarea').attr('name',attendee_note);
		$('#kolsTable tr:last td:eq(2) p textarea').attr('id',attendee_note);
		
		var interactionKolAutoComplete	= $('#'+kolFieldId).autocomplete(interactionKolAutoCompleteOptions);
		//$("#"+kolFieldId).parent().parent().parent().find('td').eq(1).find('input').val('');
		if(noofKols>0){
			$('#kolsTable tr:last td:eq(3) label').html("<img title='Delete' alt='Delete' src='<?php echo base_url()?>/images/delete.png' onclick='deleteRow(this)'>");
		}
	}
	$(document).ready(function(){
	/*	$('#addMoreKols').click(function(){
			var kolSHtml = 	$('#kols').html();
			$('#kolsTable').append("<tr>"+kolSHtml+"</tr>");
			var noofKols = $('#noOfKols').val();
			var noOfFields = parseInt(noofKols)+1;
			$('#noOfKols').val(noOfFields);
			var kolFieldName = 'kol_name'+noOfFields;
			var kolFieldId = 'kolName'+noOfFields;
			$('#kolsTable tr:last td:eq(0) input:last').val('');
			$('#kolsTable tr:last td:eq(0) input:last').attr('name',kolFieldName);
			$('#kolsTable tr:last td:eq(0) input:last').attr('id',kolFieldId);
			$('#kolsTable tr:last td:eq(0) input:last').addClass('autocompleteInputBox');
	
			$('#kolsTable tr:last td:eq(0) input:last').prev('input').prev('input').attr('id','kolNameAuto'+noOfFields).val('');
			$('#kolsTable tr:last td:eq(0) input:last').prev('input').prev('input').attr('name','kol_name_auto'+noOfFields);
			$('#kolsTable tr:last td:eq(0) input:last').prev('input').attr('name','kol_id_auto'+noOfFields);
			$('#kolsTable tr:last td:eq(0) input:last').prev('input').attr('id','kolIdAuto'+noOfFields).val('');
			//Hide the image
			$('#kolsTable tr:last td:eq(0) input:last').next('img').hide();
			$('#kolsTable tr:last td:eq(0) input:last').next('img').removeAttr('onClick');
			

			var therapeutic_area = 'therapeutic_area'+noOfFields;
			$('#kolsTable tr:last td:eq(1) p input').attr('name',therapeutic_area);
			$('#kolsTable tr:last td:eq(1) p input').attr('id',therapeutic_area).val('');
	
			var attendee_note = 'attendee_note'+noOfFields;
			$('#kolsTable tr:last td:eq(2) p textarea').attr('name',attendee_note);
			$('#kolsTable tr:last td:eq(2) p textarea').attr('id',attendee_note);
			
			var interactionKolAutoComplete	= $('#'+kolFieldId).autocomplete(interactionKolAutoCompleteOptions);
			//$("#"+kolFieldId).parent().parent().parent().find('td').eq(1).find('input').val('');
			if(noofKols>0){
				$('#kolsTable tr:last td:eq(3) label').html("<img title='Delete' alt='Delete' src='<?php echo base_url()?>/images/delete.png' onclick='deleteRow(this)'>");
			}
		});

*/
		$('#addMoreObjectives').click(function(){
			
			var kolSHtml = 	$('#objective').html();
		
			$('#objectiveTable').append("<tr>"+kolSHtml+"</tr>");
			var noofKols = $('#noOfObjectives').val();
			var noOfFields = parseInt(noofKols)+1;
			$('#noOfObjectives').val(noOfFields);

			var order = 'product'+noOfFields;
			$('#objectiveTable tr:last td:eq(0) select').attr('name',order);
			$('#objectiveTable tr:last td:eq(0) select').attr('id',order);

			$('#objectiveTable tr:last td:eq(0) select option:first').attr('selected','selected').val('').text('Select');
			
			var objectFieldName = 'objective'+noOfFields;
			$('#objectiveTable tr:last td:eq(1) select').attr('name',objectFieldName);
			$('#objectiveTable tr:last td:eq(1) select').attr('id',objectFieldName);
			$('#objectiveTable tr:last td:eq(1) select option:first').attr('selected','selected').val('').text('Select');
			
			var topic = 'topic'+noOfFields;
			$('#objectiveTable tr:last td:eq(2) select').attr('name',topic);
			$('#objectiveTable tr:last td:eq(2) select').attr('id',topic);
			$('#objectiveTable tr:last td:eq(2) select option:first').attr('selected','selected').val('').text('Select');

			var product = 'subtopic'+noOfFields;
			$('#objectiveTable tr:last td:eq(3) select').attr('name',product);
			$('#objectiveTable tr:last td:eq(3) select').attr('id',product);
			$('#objectiveTable tr:last td:eq(3) select option:first').attr('selected','selected').val('').text('Select');
			
		//	var brand = 'brand'+noOfFields;
		//	$('#objectiveTable tr:last td:eq(3) select').attr('name',brand);
		//	$('#objectiveTable tr:last td:eq(3) select').attr('id',brand);

			$('#objectiveTable tr:last td:eq(5) label').html("<img title='Delete' alt='Delete' src='<?php echo base_url()?>/images/delete.png' onclick='deleteRow(this)'>");
			

		});


		<?php if($interactionDetails!=''){?>

		var noOfKols = $('#noOfKols').val();
		for(var i=1;i<=noOfKols;i++){
			var interactionKolAutoComplete	= $('#kolName'+i).autocomplete(interactionKolAutoCompleteOptions);
		}
		<?php }?>
	});

	function getBrandName(proObject){
		var pId = $(proObject).val();
	
		var brandId = $(proObject).parent().parent().parent().find('td').eq(3).find('select').attr('id');
		$.ajax({
			url:'<?php echo base_url()?>/interactions/get_brands_by_product/'+pId,
			dataType:'json',
			success:function(returndata){
			
				$('#'+brandId+" option" ).remove();
				$('#'+brandId).append('<option value="">Select</option>');
				// .each loops through the array
				$.each(returndata.arrProducts, function(key,value){
				
		  				  $('#'+brandId).append($("<option></option>")
			                    .attr("value",key)
			                    .text(value));
			
				});
			}
		});
	}
	function getProduct(proObject){
		//$('#loadingProduct').show();
		$('#'+topicId+" option" ).remove();
		$('#'+topicId).append('<option value="">Select</option>');
		var typeId = $(proObject).val();
	
		var productId = $(proObject).parent().parent().parent().find('td').eq(2).find('select').attr('id');

		var topicId = $(proObject).parent().parent().parent().find('td').eq(3).find('select').attr('id');
		$.ajax({
			url:'<?php echo base_url()?>/interactions/get_product_by_type/'+typeId,
			dataType:'json',
			success:function(returndata){
				$('#'+topicId+" option" ).remove();
				$('#'+topicId).append('<option value="">Select</option>');
				$('#'+productId+" option" ).remove();
				$('#'+productId).append('<option value="">Select</option>');
				// .each loops through the array
				$.each(returndata.arrProducts, function(key,value){
				
		  				  $('#'+productId).append($("<option></option>")
			                    .attr("value",key)
			                    .text(value));
			
				});
			},
			complete:function(){
			//	$('#loadingProduct').hide();
				}
		});
	}

	function getTopic(proObject){
		//$('#loadingTopic').show();
		var productId = $(proObject).parent().parent().parent().find('td').eq(0).find('select').val();

		var groupId =  $('#grouping').val();
		//var typeId = $(proObject).parent().parent().parent().find('td').eq(1).find('select').val();
		var typeId = $(proObject).val();	
		var topicId = $(proObject).parent().parent().parent().find('td').eq(2).find('select').attr('id');
		$.ajax({
			url:'<?php echo base_url()?>/interactions/get_topic_by_product/'+groupId+'/'+productId+'/'+typeId,
			dataType:'json',
			success:function(returndata){
			
				$('#'+topicId+" option" ).remove();
				$('#'+topicId).append('<option value="">Select</option>');
				// .each loops through the array
				$.each(returndata.arrTopics, function(key,value){
				
		  				  $('#'+topicId).append($("<option></option>")
			                    .attr("value",key)
			                    .text(value));
			
				});
			},
			complete:function(){
			//	$('#loadingTopic').hide();
				}
		});
	}
	function deleteRow(thisObj){
		$(thisObj).parent().parent().parent().remove();
	}
	function toggleLocation(thisObj){
				if($(thisObj).val()!=1){
			$('#locationContainer').hide();
		}else{
			$('#locationContainer').show();
		}
	}
	function restrictAttendees(thisObj){
		if($(thisObj).val()!=1){
			$('#kolsTable tr:last td:eq(3) label').show();
			$('#anttendies').removeAttr('readonly');
		}else{
			$('#kolsTable tr:last td:eq(3) label').hide();
			$('#anttendies').val('1').attr('readonly','readonly');
		}
	}
	$(document).ready(function(){
		var groupingObj	= $('#grouping');
		var modeObj	= $('#mode');
		<?php if($interactionDetails==''){?>
		addMoreKols();
		//$('.initialKol').remove();
		$('.initialKol').find('input:eq(3)').removeClass('test1');
		<?php }?>
		restrictAttendees(groupingObj);
		toggleLocation(modeObj);
	 	$('.chosenSelect').chosen({allow_single_deselect: true});
	    $('.chosenMultipleSelect').chosen({
				placeholder_text : "Click to Select Non Profiled Attendees",
				allow_single_deselect: true
	    });
	    $('table.tabularGrid caption div.collapseSlider').click(function (){
        	if($(this).attr('class')!="collapseSlider"){
        		$(this).parent().parent().find('tr').hide();
        		$(this).find('a').attr('data-original-title','Expand');
	        }else{
    	    	$(this).parent().parent().find('tr').show();
        		$(this).find('a').attr('data-original-title','Collapse');
        	}
	        $(this).toggleClass('expandSlider');
    	});
    });
</script>
<div  class="interactionWrapper">
<div class="msgBoxContainer"><div class="eventMsgBox"></div></div>
<div class="formHeader">
	<!--<button>Record Interaction</button>
--></div>
<div>
	<h5 class="heading">Record Interaction</h5>
	<form action="<?php echo base_url();?>interactions/save_interaction" id="interactionForm"  name="interactionForm" method="post" enctype="multipart/form-data" onsubmit="return validateAndSubmitInteractionForm();">
		<input type="hidden"  name="is_from" value="track" />
		<input type="hidden"  name="interaction_id" value="<?php if($interactionDetails!=null) echo $interactionDetails['id'];?>" id="interactionId">
		<input type="hidden"  name="calendar_event_id" value="<?php if($interactionDetails!=null) echo $interactionDetails['calendar_event_id'];?>" id="calendarEventId">
		<div>
		<table  id="paymentTbl1" class="analystForm1 tabularGrid">
			<caption>
				<strong>Interaction Details</strong>
				<div id="collapseExpandButton" class="expandSlider collapseSlider">
					<a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
				</div>
			</caption>
			<tr>
				<th class="alignRight"><label for="grouping">Interaction Category:<span class="required">*</span></label></th>
				<td>
					<select name="grouping"  id="grouping" class="required" onchange="restrictAttendees(this);">
						<!--<option value="">Select Category</option>
						--><?php foreach($arrGroupings as $row){?>
							<option value="<?php echo $row['id'];?>" <?php if($interactionDetails!=null) if($row['id']==$interactionDetails['grouping']) echo 'SELECTED';?>>
								<?php echo $row['name'];?>
							</option>
						<?php }?>
					</select>
				</td>
				<th class="alignRight"><label for=mode>Interaction Type:<span class="required">*</span></label></th>
				<td>
					<input type="hidden" name="reminder" value="1" id="reminder" ></input>
					<select name="mode"  id="mode" class="required" onchange="toggleLocation(this);">
						<option value="">Select</option>
						<?php foreach($arrModes as $mode){?>
							<option value="<?php echo $mode['id'];?>" <?php if($interactionDetails!=null) if($mode['id']==$interactionDetails['mode']) echo 'SELECTED';?>>
								<?php echo $mode['name'];?>
							</option>
						<?php }?>
					</select>
				</td>
			</tr>
			<tr>
				<th class="alignRight"><label for=date>Date:<span class="required">*</span></label></th>
				<td>
					<input type="text" name="date" value="<?php $this->load->model('common_helpers'); if($interactionDetails!=null && $interactionDetails['date']!='0000-00-00') echo $this->common_helpers->convertDateToMM_DD_YYYY($interactionDetails['date']);?>" id="date" class="required"></input>
				</td>
				<th class="alignRight"><label for="followUpOn">Follow-Up On:<?php if($interactionDetails!=null && $interactionDetails['reminder']==1) echo "<span class='required'>*</span>";?></label></th>
				<td>
					<input type="text" name="follow_up_on" value="<?php if($interactionDetails!=null && $interactionDetails['follow_up_on']!='0000-00-00') echo $this->common_helpers->convertDateToMM_DD_YYYY($interactionDetails['follow_up_on']);?>" id="followUpOn" <?php if($interactionDetails!=null && $interactionDetails['reminder']==1) echo "class='required'";?>></input>
				</td>
			</tr>
			<tr>
				<th class="alignRight"><label for=time>Start Time:<?php if($interactionDetails!=null && $interactionDetails['reminder']==1) echo "<span class='required'>*</span>";?></label></th>
				<td width="130">
						<!--<input type="text" name="time" value="<?php if($interactionDetails!=null && $interactionDetails['fromtime']!='00:00:00') echo $interactionDetails['fromtime'];?>" id="time" <?php if($interactionDetails!=null && $interactionDetails['reminder']==1) echo "class='required'";?>></input>-->
						<input type="text" name="timefmhr" id="timefmhr" class="timePicker <?php if($interactionDetails!=null && $interactionDetails['reminder']==1) echo "required";?>" value="<?php if($interactionDetails!=null && $interactionDetails['fromtime']!='00:00:00') echo substr($interactionDetails['fromtime'],0,2); else echo "00";?>"/>
						<div id="suggestions1">
							<span class="searchterm selectedData">00</span>
							<span class="searchterm">01</span>
							<span class="searchterm">02</span>
							<span class="searchterm">03</span>
							<span class="searchterm">04</span>
							<span class="searchterm">05</span>
							<span class="searchterm">06</span>
							<span class="searchterm">07</span>
							<span class="searchterm">08</span>
							<span class="searchterm">09</span>
							<span class="searchterm">10</span>
							<span class="searchterm">11</span>
							<span class="searchterm">12</span>
						</div>
						<input type="text" name="timefmmin" id="timefmmin" class="timePicker" value="<?php if($interactionDetails!=null && $interactionDetails['fromtime']!='00:00:00') echo substr($interactionDetails['fromtime'],3,2); else echo "00";?>"/>
						<div id="suggestions2">
							<span class="searchterm">00</span>
							<span class="searchterm">05</span>
							<span class="searchterm">10</span>
							<span class="searchterm">15</span>
							<span class="searchterm">20</span>
							<span class="searchterm">25</span>
							<span class="searchterm">30</span>
							<span class="searchterm">35</span>
							<span class="searchterm">40</span>
							<span class="searchterm">45</span>
							<span class="searchterm">50</span>
							<span class="searchterm">55</span>
						</div>
						<select name="timefmap" id="timefmap" class="timeap">
							<option value="AM" <?php if($interactionDetails!=null && $interactionDetails['fromtime']!='00:00:00' && substr($interactionDetails['fromtime'],6,2) == 'AM') echo "selected='selected'";?> >AM</option>
							<option value="PM"  <?php if($interactionDetails!=null && $interactionDetails['fromtime']!='00:00:00' && substr($interactionDetails['fromtime'],6,2) == 'PM') echo "selected='selected'";?> >PM</option>
						</select>
				</td>
				<th class="alignRight"><label for=anttendies>No Of Attendees:<span class="required">*</span></label></th>
				<td>
					<input type="text" name="total_attendies" value="<?php if($interactionDetails!=null) echo $interactionDetails['total_attendies']?>" id="anttendies" class="required"></input>
				</td>

			</tr>
			<tr>
				<th class="alignRight"><label for=mirf_case_num>MIRF Case #:</label></th>
				<td>
					<input type="text" name="mirf_case_num" value="<?php if($interactionDetails!=null) echo $interactionDetails['mirf_case_num']?>" id="mirf_case_num"></input>
				</td>
			</tr>
		</table>
		<table id="objectiveTable" class="highlightHeadings tabularGrid">
			<caption>Topic
				<div id="collapseExpandButton" class="expandSlider collapseSlider">
					<a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
				</div>
			</caption>
			<tr>
				<th class="alignCenter"><label for="product">Product<span class="required">*</span></label></th>
				<th class="alignCenter"><label for="objective">Type<span class="required">*</span></label></th>
				<th class="alignCenter"><label for=topic>Topic<span class="required">*</span></label></th>
				<th class="alignCenter"><label for="subtopic">Sub Topic</label></th>
				<th></th>
				<th>&nbsp;</th>
			</tr>
			<?php if($interactionDetails==''){	?>
			<input type="hidden" id="noOfObjectives" value="0" name="noOfObjectives"></input>
				<tr id="objective">
					<td>
						<p>
							<select name="product"  id="product" class="required">
								<option value="">Select</option>
								<option value="1">Abilify</option>
							</select>
							<img id="loadingProduct" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
						</p>
					</td>
					<td>
						<p>
							<select name="objective"  id="objective"  onchange="getTopic(this)" class="required">
								<option value="">Select</option>	
								<?php foreach($arrType as $row){?>
									<option value="<?php echo $row['id'];?>" <?php if($interactionDetails!=null) if($row['id']==$interactionDetails['type_id']) echo 'SELECTED';?>>
										<?php echo $row['name'];?>
									</option>
								<?php }?>
							</select>
						</p>
					</td>
					<td>
						<p>
							<select name="topic"  id="topic" class="required">
								<option value="">Select</option>	
							</select>
							<img id="loadingTopic" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
						</p>
					</td>
					<td>
						<p>
							<select name="subtopic"  id="subtopic">
								<option value="">Select</option>
								<option value="1">Disease State</option>
								<option value="2">MML</option>
								<option value="3">Frameworks</option>	
							</select>
							<img id="loadingTopic" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
						</p>
					</td>
					<td>
						<p></p>
					</td>
					<td class="TextAlignCenter">
						<label id="addMoreObjectives"><img src="<?php echo base_url();?>images/bullet_add.png" alt="Add" title="Add"/></label>
					</td>
				</tr>
			<?php }else{?>
				<input type="hidden" id="noOfObjectives" value="<?php echo $interactionDetails['noOfObjectives']?>" name="noOfObjectives"></input>
				<?php  $objectiveNo='';
				foreach($interactionDetails['arrSelectedTopics'] as $topicKey=>$topics){?>
				<tr id="objective">
					<td>
						<p>
							<select name="product<?php echo $objectiveNo?>"  id="product<?php echo $objectiveNo?>" class="required">
									<option value="">Select</option>	
								<?php foreach($arrProduct as $product){?>
									<option value="<?php echo $product['id'];?>" <?php  if($product['id']==$topics['product_id']) echo 'SELECTED';?>>
										<?php echo $product['name'];?>
									</option>
								<?php }?>
							</select>
							<img id="loadingProduct" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
						</p>
					</td>
					<td><p>
							<select name="objective<?php echo $objectiveNo?>"  id="objective<?php echo $objectiveNo?>"  onchange="getTopic(this)" class="required">
									<option value="">Select</option>	
								<?php  foreach($arrType as $key=>$objective){?>
									<option value="<?php echo $objective['id'];?>" <?php if($objective['id']==$topics['objective_id']) echo 'SELECTED';?>>
										<?php echo $objective['name']?>
									</option>
								<?php }?>
							</select>
						</p>
					</td>
					<td>
						<p>
							<select name="topic<?php echo $objectiveNo?>"  id="topic<?php echo $objectiveNo?>" class="required">
									<option value="">Select</option>	
								<?php foreach($topics['topics'] as $key=>$value){?>
									<option value="<?php echo $key;?>" <?php  if($key==$topics['topic_id']) echo 'SELECTED';?>>
										<?php echo $value;?>
									</option>
								<?php }?>
							</select>
							<img id="loadingTopic" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
						</p>
					</td>
					<td><p>
							<select style="width: 100px;" name="subtopic<?php echo $objectiveNo?>"  id="subtopic<?php echo $objectiveNo?>">
								<option value="">Select</option>
								<option value="1" <?php if($topics['sub_topic_id'] == '1') echo "selected='selected'";?>>Disease State</option>
								<option value="2" <?php if($topics['sub_topic_id'] == '2') echo "selected='selected'";?>>MML</option>
								<option value="3" <?php if($topics['sub_topic_id'] == '3') echo "selected='selected'";?>>Frameworks</option>	
							</select>
						</p>
					</td>
					<td>
						<p></p>
					</td>
					<td class="TextAlignCenter">
					<?php if($topicKey==0){?>
								<label id="addMoreObjectives"><img src="<?php echo base_url();?>images/bullet_add.png" alt="Add" title="Add"/></label>
							<?php }else{?>
								<label id="deleteMoreObjectives"><img src="<?php echo base_url();?>images/delete.png" alt="Delete" title="Delete" onclick="deleteRow(this)"></label>
						<?php }?>
					</td>
				</tr>
			<?php $objectiveNo++;}
			}?>
		</table>
		<table id="kolsTable" class="highlightHeadings tabularGrid">
			<caption>Attendees
				<div id="collapseExpandButton" class="expandSlider collapseSlider">
					<a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
				</div>
			</caption>
			<tr>
				<th class="alignCenter">
					<label for="kolName"><?php echo lang("KOL");?> Name<span class="required">*</span>
						<span id="tooltip-about-name-format" class="map-info tooltop-bottom"><a href="#" class="tooltipLink" rel='tooltip' title="<span class='tttext'>Enter <?php echo lang("KOL");?> name in the format of First_name Middle_name Last_name</span>">&nbsp;</a></span>
					</label>
				</th>
				<th class="alignCenter"><label for=therapeuticArea>Specialty</label></th>
				<th class="alignCenter"><label for=attendee_note>Note</label></th>
				<th>&nbsp;</th>
			</tr>
			<?php if($interactionDetails==''){?>
			<input type="hidden" id="noOfKols" value="0" name="noOfKols"></input>
			<tr id="kols" class="initialKol" style="display:none">
				<td>
					<p id="kolName">
						<input type="hidden" name="kol_id" value="" id="kolId" class="test">
						<input type="hidden" name="kol_name_auto" value="" id="kolNameAuto" class="checkAboveInputValue"></input>
						<input type="hidden" name="kol_id_auto" value="" id="kolIdAuto"  ></input>
						<input type="text" name="kol_name" value="" id="kolName" class="required test1"></input>
						<!--<img class="image" src="<?php echo base_url();?>images/i_icon.png" title="KOL Profile Snapshot" alt="profile" onclick="showMicroProfile('')"></img>
						--><label><div class='tooltip-demo tooltop-right microViewIcon' onclick="showMicroProfile(''); return false;" ><a href="#" class="tooltipLink" rel='tooltip' title="Profile Snapshot">&nbsp;</a></div></label>
					</p>
				</td>
				<td>
					<p>
						<input class="kolSpecialty" type="text" readonly="readonly" name="therapeutic_area" id="therapeuticArea" value="<?php echo $kolSpecialty1;?>" />
					</p>
				</td>
				<td>
					<p>
						<textarea name="attendee_note" id="attendee_note" style="height: 16px;"></textarea>
					</p>
				</td>
				<td class="TextAlignCenter">
					<label id="addMoreKols"><img onclick="addMoreKols();" src="<?php echo base_url();?>images/bullet_add.png" alt="Add" title="Add" /></label>
				</td>
			</tr>
			<?php }else{?>
					<input type="hidden" id="noOfKols" value="<?php echo $interactionDetails['noOfKols']?>" name="noOfKols"></input>
					<?php
					$no		= 0; 
					$arr	= array();
					foreach($interactionDetails['attendies'] as $id=>$value){
					?>
						<tr id="kols">
						<input type="hidden" name="kol_id" value="<?php echo $value['kol_id'];?>" id="kolId"/>
						<td>
							<p class="kolName">
								<input type="hidden" name="kol_name_auto<?php echo $no;?>" value="<?php echo $value['first_name']." ".$value['middle_name']." ".$value['last_name'];?>" id="kolNameAuto<?php echo $no?>" class="checkAboveInputValue"></input>
								<input type="hidden" name="kol_id_auto<?php echo $no;?>" value="<?php echo $value['kol_id'];?>" id="kolIdAuto<?php echo $no?>"  ></input>
								<input type="text" class="required test1 autocompleteInputBox" name="kol_name<?php echo $no?>" value="<?php echo $value['first_name']." ".$value['middle_name']." ".$value['last_name'];?>" id="kolName<?php echo $no;?>"></input>
								<!--<img class="image" src="<?php echo base_url();?>images/i_icon.png" title="KOL Profile Snapshot" alt="Snapshot" onclick="showMicroProfile('<?php echo $value['kol_id'];?>')"></img>
								--><label><div class='tooltip-demo tooltop-right microViewIcon' onclick="showMicroProfile('<?php echo $value['kol_id'];?>'); return false;" ><a href="#" class="tooltipLink" rel='tooltip' title="Profile Snapshot">&nbsp;</a></div></label>
							</p>
						</td>
						<td>
							<p>
								<input class="kolSpecialty" type="text" readonly="readonly" name="therapeutic_area" id="therapeuticArea" value="<?php echo $value['specialty'];?>" />
							</p>
						</td>
						<td>
							<p>
								<textarea name="attendee_note<?php echo $no?>"  id="attendee_note<?php echo $no?>" style="height: 16px;"><?php echo $value['note'];?></textarea>
							</p>
						</td>
						<td class="TextAlignCenter">
							<?php if($no==0){?>
								<label id="addMoreKols"><img onclick="addMoreKols();" src="<?php echo base_url();?>images/bullet_add.png" alt="Add" title="Add"/></label>
							<?php }else{?>
								<label id="deleteMoreKols"><img src="<?php echo base_url();?>images/delete.png" alt="Delete" title="Delete" onclick="deleteRow(this)"></label>
								<?php }?>
						</td>
					</tr>
					<?php
						$no++;
					 }
					/*
					if(sizeOf($interactionDetails['attendies'])>1){
						foreach($interactionDetails['attendies'] as $id=>$value){
							if($value['kol_id'] ==$kolId1){
								$arr = $interactionDetails['attendies'][$id];
								unset($interactionDetails['attendies'][$id]);
								break;
							}
						}
						$interactionDetails['attendies'][]=$arr;
						$interactionDetails['attendies'] = array_reverse($interactionDetails['attendies']);
					}
					foreach($interactionDetails['attendies'] as $key1=>$kols){
					?>
					<tr id="kols" style="display:none">
						<input type="hidden" name="kol_id" value="<?php echo $kolId1;?>" id="kolId"/>
						<td>
							<p id="kolName">
								<?php
								 foreach($arrKolDetails as $kolDetails){?>
									<?php if ($kolDetails['id']==$kols['kol_id']){?>
										<input type="hidden" name="kol_name_auto<?php echo $no?>" value="<?php echo $kolDetails['first_name']." ".$kolDetails['middle_name']." ".$kolDetails['last_name'];?>" id="kolNameAuto<?php echo $no?>" class="checkAboveInputValue"></input>
										<input type="hidden" name="kol_id_auto<?php echo $no?>" value="<?php echo $kolDetails['id'];?>" id="kolIdAuto<?php echo $no?>"  ></input>
										<input type="text" class="required test1" name="kol_name<?php echo $no?>" value="<?php echo $kolDetails['first_name']." ".$kolDetails['middle_name']." ".$kolDetails['last_name'];?>" id="kolName<?php echo $no;?>"></input>
										<img class="image" src="<?php echo base_url();?>images/i_icon.png" title="KOL Profile Snapshot" alt="profile" onclick="showMicroProfile('<?php echo $kolDetails['id'];?>')"></img>
									<?php }?>
								<?php }?>
							</p>
						
						</td>
						<td>
							<p>
								<input class="kolSpecialty" type="text" readonly="readonly" name="therapeutic_area" id="therapeuticArea" value="<?php echo $kols['specialty'];?>" />
							</p>
						</td>
						<td>
							<p>
								<textarea name="attendee_note<?php echo $no?>"  id="attendee_note<?php echo $no?>" style="height: 16px;"><?php echo $kols['note'];?></textarea>
							</p>
						</td>
						<td class="TextAlignCenter">
							<?php if($key1==0){?>
								<label id="addMoreKols"><img onclick="addMoreKols();" src="<?php echo base_url();?>images/bullet_add.png" alt="Add" title="Add"/></label>
							<?php }else{?>
								<label id="deleteMoreKols"><img src="<?php echo base_url();?>images/delete.png" alt="Delete" title="Delete" onclick="deleteRow(this)"></label>
								<?php }?>
						</td>
					</tr>
			<?php 
					$no++;}
			*/
			}
			?>
		</table>
		<table class="tabularGrid">
			<caption>Non-Profiled Attendees
				<div id="collapseExpandButton" class="expandSlider collapseSlider">
					<a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
				</div>
			</caption>
			<tr>
				<td>
					<select class="chosenMultipleSelect" style="width: 50%;height:60px; display: none;" multiple="multiple"  name="users[]">
								<?php $userId = $this->session->userdata['user_id'];
								if($interactionDetails==''){
									
									foreach($arrUsers as $key=>$user){
									if($userId==$key){
										?>
										<option value="<?php echo $key;?>" selected="selected"><?php echo $user;?></option>
										
								<?php unset($arrUsers[$key]);}}
								}else{
									foreach($arrUsers as $key=>$user){
										foreach($internalUsers as $user1){?>
										
												<?php if($user1==$key){?>
														<option value="<?php echo $user1;?>"  selected="selected"><?php echo $user;?></option>
														<?php unset($arrUsers[$key])?>
											
											<?php }
										}?>
									
								<?php 	}}?>
										
									<?php foreach($arrUsers as $key=>$user){?>
											<option value="<?php echo $key;?>" ><?php echo $user;?></option>
											
									<?php }?>
						
					</select>
				</td>
			</tr>
		</table>
		<table id="locationContainer" class="tabularGrid">
			<caption>Location
				<div id="collapseExpandButton" class="expandSlider collapseSlider">
					<a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
				</div>
			</caption>
			<tr>
				<td style="padding:0px;">
					<table class="highlightHeadings" id="location">
						<tr>
							<th></th>
							<th>Location</th>
							<th>Address</th>
							<th>Country</th>
							<th>City</th>
							<th>State</th>
						</tr>
						<?php 
							
								foreach($kolLocations as $key=>$row){ 
									$selectedLocation	= '';
									if($interactionDetails['location_type']==$row['id']){
										$selectedLocation	= ' checked="checked"';
									}
								?>
									<tr>
										<td><input type="radio" name="selectedLocation" value="<?php echo $row['id'];?>" <?php echo $selectedLocation;?> /> </td>
										<?php 
											echo '<td>'.$row['location'].'</td>';
											echo '<td>'.$row['address'].'</td>';
											echo '<td>'.$row['country'].'</td>';
											echo '<td>'.$row['state'].'</td>';
											echo '<td>'.$row['city'].'</td>';
										?>
									</tr>
								<?php }
							
						?>
					</table>
				</td>
			</tr>
			<tr>
				<td style="padding:0px;">
					<?php 
						$selectedLocation	= '';
						if($interactionDetails['location_type']==0){
								$selectedLocation	= ' checked="checked"';
						}
					?>
					<table>
						<caption style="background: #eee;line-height: 15px;">Other</caption>
						<tr>
							<td><input type="radio" name="selectedLocation" value="0" <?php echo $selectedLocation;?> /></td>
							<th class="alignRight"><label>Address1:</label></th>
							<td><input name="location_name" type="text" value="<?php echo (isset($interactionDetails['location'])?$interactionDetails['location']:'');?>" /></td>
							<th class="alignRight"><label>Country:</label></th>
							<td>
								<select name="country_id" id="country_id" onchange="getStatesByCountryId();" class="required">
									<option value="">-- Select Country--</option>
									<?php 
									foreach( $arrCountry as $country){
																		if($country['country_id'] == $interactionDetails['country_id']){?>
																		<option value="<?php echo $country['country_id']?>" selected="selected"><?php echo $country['country_name']?></option>;
																		<?php }else{ ?>
																			<option value="<?php echo $country['country_id']?>" <?php if($arrKols=='' && $country['country_id']==254){?> selected="selected" <?php }?>><?php echo $country['country_name']?></option>;
																	<?php }}?>
																
								</select>
							<img id="loadingStates" src="<?php echo base_url()?>/images/ajax_loader_black.gif" style="display:none"/>
						</td>
						</tr>
						<tr>
							<td></td>
							<th class="alignRight"><label>Address2:</label></th>
							<td><input name="address" type="text" value="<?php echo (isset($interactionDetails['address'])?$interactionDetails['address']:'');?>" /></td>
							<th class="alignRight"><label>State:</label></th>
							<td>
								<select name="state" id="state_id" onchange="getCitiesByStateId();">
									<option value="">Select State</option>
									<?php 
										foreach($arrStates as $key=>$row){
											$selected	= '';
											if($interactionDetails['state_id']==$row['state_id']){
												$selected	= ' selected="selected"';
											}
											echo '<option value="'.$row['state_id'].'"'.$selected.'>'.$row['state_name'].'</option>';
										}
									?>
								</select>
							</td>
						</tr>
						<tr>
							<td></td>
							<th class="alignRight"><label>Postal Code:</label></th>
							<td><input name="postal_code" type="text" value="<?php echo (isset($interactionDetails['postal_code'])?$interactionDetails['postal_code']:'');?>" /></td>
							<th class="alignRight"><label>City:</label></th>
							<td>
								<select name="city" id="city_id">
									<?php 
										if(isset($arrCities)){
											foreach($arrCities as $key=>$row){
												$selected	= '';
												if($interactionDetails['city_id']==$row['city_id']){
													$selected	= ' selected="selected"';
												}
												echo '<option value="'.$row['city_id'].'"'.$selected.'>'.$row['city_name'].'</option>';
											}
										}
									?>
								</select>
								<img id="loadingCities" src="<?php echo base_url()?>images/ajax_loader_black.gif" style="display:none"/>
							</td>
							<td></td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		<!--<table id="fileUploadContainer" class="highlightHeadings tabularGrid">
			<input type="hidden" name="no_of_files" id="noOfFiles" value="1" />
			<caption>Attach Document(s)
				<div id="collapseExpandButton" class="expandSlider collapseSlider">
					<a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
				</div>
			</caption>
			<tr>
				<th class="alignCenter"><label for=docName1>Document Name</label></th>
				<th class="alignCenter"><label for=description1>Description</label></th>
				<th class="alignCenter"><label for=intRefFile1>File</label></th>
				<th>&nbsp;</th>
			</tr>
			<?php if(isset($arrDocs) && sizeof($arrDocs)>=1){?>
				<div id="docsList">
					<?php foreach($arrDocs as $doc){?>
					 	<tr id="doc<?php echo $doc['id'];?>">
							<td><span><a href="<?php echo base_url();?>interactions/download_doc/<?php echo $doc['id'];?>"><?php if($doc['name'] != '') echo $doc['name']; else echo 'File'.$doc['name'];?></a></span></td>
							<td><span><?php echo $doc['description'];?></span></td>
							<td class="TextAlignCenter"><a href="#" onclick="deleteDocument(<?php echo $doc['id'];?>);">remove</a></td>
						</tr>
					<?php }?>
				</div>
			<?php }?>
				<tr id="docContainer1">
					<td><input type="text" name="doc_name1" id="docName1" /></td>
					<td><input type="text" name="description1" id="description1" /></td>
					<td><input type="file" name="int_ref_file1" id="intRefFile1" /></td>
					<td class="TextAlignCenter"><label id="addMoreFile"><img src="<?php echo base_url();?>images/bullet_add.png" alt="Add" title="Add"/></label></td>
				</tr>
		</table>
		--><table class="tabularGrid">
			<caption>Notes
				<div id="collapseExpandButton" class="expandSlider collapseSlider">
					<a onclick="return false;" href="#" class="tooltipLink" rel='tooltip' title="Collapse">&nbsp;</a>
				</div>
			</caption>
			<tr>
				<td>
					<textarea cols=""  rows="2" name="notes"  id="notes"><?php if($interactionDetails!=null) echo $interactionDetails['notes'];?></textarea>
				</td>
			</tr>
		</table>
		<p style="float: right;">
			<label for="kolName">Recorded By:
				<?php if($interactionDetails!=null) echo $interactionDetails['user_name']; else echo $this->session->userdata('user_full_name');?>
			</label>
		</p>
		<div class="formButtons">
			<input type="submit" name="saveInteraction" id="saveInteraction" value="Save" />
			<input type="button" name="cancelInteraction" value="Cancel" onclick="cancelAddInteraction();" />
		</div>
</div>
		
	</form>
</div>
</div>

<div id="micro" class="microProfileDialogBox">
		<div class="microViewProfile profileContent"></div>
	</div>