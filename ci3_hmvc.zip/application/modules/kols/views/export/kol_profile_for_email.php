<?php
/**
 * Sowing KOL Deatils In Html Format and used to send this Html to Email
 *
 * @package		application.views.kols.email
 * @author		Vinayak M
 * @copyright	Copyright (c) 2012, Bilva Solutions <www.bilva.co.in>
 * @link		http://www.bilva.co.in
 * @version		Version 3.9
 * @since		April 5, 2012
 *
 *
 *
 *      Used to display the short information of the KOL Profile
 */
$salutation = "";
if($arrKol['salutation'] != 0){
	$salutation	= $arrSalutations[$arrKol['salutation']];
}

$firstName	= $arrKol['first_name'];
$middleName	= htmlspecialchars( $arrKol['middle_name']);
$lastName	= htmlspecialchars( $arrKol['last_name'],ENT_QUOTES,'UTF-8');
$fullName 	= $this->common_helper->get_name_format($firstName,$middleName,$lastName);

function data_uri($file, $mime)
{
	$contents = file_get_contents($file);
	$base64   = base64_encode($contents);
	return ('data:' . $mime . ';base64,' . $base64);
}
?>	
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	</head>
<body>
	<div class="header1" style="width:91%;margin-left:18px;">
 		<table width="100%">
 			<tr>
 				<td class="bgColorGray" style="font-size:9pt">
 					<?php //echo $salutation . ' ' . $fullName ;?>
 				</td>
 				<td align="right" style="vertical-align:top ">
	 				<?php 
						// Define the Variables to construct the ACTUAL BASE PATH of the image
	 					$rootFolder	=$_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path');
						$logoPath	= $rootFolder."images/logo/kolm_logo_beta.png";
					?>
					<img src="<?php echo data_uri($logoPath,'image/png');?>" alt="Aisselsdfsd" />
					
				</td>
 			</tr>
 		</table>	
	</div>
	
	<div class="footer"></div>
	<!-- Start of overviewDetails Table -->
	<table cellspacing="5" cellpadding="5" style="width:100%;border-collapse:collapse;">
		<tr>
			<td style="font-size:11px;color:gray;">Profile Type :
			<?php if($arrKol['profile_type']!='Full Profile' && ($arrKol['imported_as']=='1' || $arrKol['imported_as']=='2' || $arrKol['imported_as']=='3')){
					$profilType = DISCOVERY;
				}else{
					switch ($arrKol['profile_type']){
						case 'Full Profile':$profilType = 'Full';
											break;
						case 'Basic Plus':$profilType = 'Basic +';
											break;
						case 'Basic':$profilType = 'Basic';
											break;
						case 'User Added':$profilType = 'User Added';
											break;
						case 'Legacy':$profilType = 'Legacy';
											break;
					}
				}
			echo $profilType;?>
			</td>
		</tr>
		<tr>
			<td width="20%">
				<?php 
					// Define the Variables to construct the ACTUAL BASE PATH of the image
					$imageFolder	= $rootFolder."images/kol_images/resized/".$arrKol['profile_image'];
					$kol_images=$rootFolder.'assets/modules/kols/images/';
					if($arrKol['profile_image']!=''){	
						$kolImg = explode("/",$imageFolder);
						$kolImgType = explode(".",$kolImg['8']);
				?>						
					<img src="<?php echo data_uri($rootFolder.'images/kol_images/resized'.$kolImg['8'],'image/'.$kolImgType); ?>" alt="KOL Profile Image" />
				<?php }else{?>
					<?php if($arrKol['gender'] == 'Male'){?>
					<img src="<?php echo data_uri($kol_images.'male_doc_full.png','image/png'); ?>" alt="KOL Profile Image" />
					<?php }?>
					<?php if($arrKol['gender'] == 'Female'){?>
						<img src="<?php echo data_uri($kol_images.'female_doc_full.png','image/png'); ?>" alt="KOL Profile Image" />
					<?php }?>
					<?php if($arrKol['gender'] == ''){?>
						<img src="<?php echo data_uri($kol_images.'user_doctor.jpg','image/png'); ?>" alt="KOL Profile Image" />
					<?php }?>
				<?php }?>
			</td>
			<td width="100%">
				<p style="margin-bottom:0px;font-weight:bold;font-size:1.2em;"><?php echo $salutation . ' ' . $fullName ?> <sub id="sub" style="vertical-align:bottom;font-weight:normal;font-size:8px;" style=""><?php echo $arrKol['suffix'];?></sub></p>
				<p style="margin-bottom:0px;margin-top:0px;color: gray;font-size: 10pt;font-weight: bold;"><?php echo $arrKol['title'];?> </p>
				<p style="margin-bottom:0px;margin-top:0px;color: gray;font-size: 10pt;font-weight: bold;"><?php echo $arrKol['division'];?> </p>
				<p style="margin-bottom:0px;margin-top:0px;color: gray;font-size: 10pt;font-weight: bold;"><?php echo $arrKol['org_name'];?> </p>
				<p style="margin-bottom:0px;margin-top:0px;color: gray;font-size: 10pt;font-weight: bold;"><?php if($arrKol['country_id']!='0') echo $arrKol['country_id']; else echo '';?></p>
			</td>
			<td align="right" >
			</td>
		</tr>
		<tr>
			<td rowspan="2">
					<h4 style="color: gray;font-family: tahoma;font-size: 12px;font-weight: bold;margin-top: 10px;text-transform: uppercase; margin-bottom:0px">SPECIALTY</h4>
					<p  style="color:gray;margin-top:0px"><?php echo $arrKol['specialtyName'];?></p>
					
					<h4 style="margin-bottom:0px;color: gray;font-family: tahoma;font-size: 12px;font-weight:bold;margin-top: 10px;text-transform: uppercase;">SUB-SPECIALTY</h4>
					<p  style="color:gray;margin-top:0px;"><?php if($arrKol['sub_specialty']!='') echo implode(", ",$arrKol['sub_specialty']);else '';?></p>
					
					<h4 style="margin-bottom:0px;color: gray;font-family: tahoma;font-size: 12px;font-weight: bold;margin-top: 10px;text-transform: uppercase;">ADDRESS</h4>
					<?php if(!empty($arrKol['address1']) && isset($arrKol['address1'])) 
							echo "<p  style='color:gray;margin-top:0px;margin-bottom:0px'>".$arrKol['address1'].",</p>";
						  if(!empty($arrKol['address2']) && isset($arrKol['address2']))
							echo "<p  style='color:gray;margin-top:0px;margin-bottom:0px'>".$arrKol['address2'].",</p>";?>
						<p style="color:gray;margin-top:0px;margin-bottom:0px">
							<?php	if(!empty($arrKol['city_id']))
										echo $arrKol['city_id'].', ';
									if($arrKol['state_id']!='' && $arrKol['postal_code']!='')
										echo $arrKol['state_id']. " ". $arrKol['postal_code'];
									else
										echo $arrKol['state_id'];
							?>
						</p>
					<?php if(!empty($arrKol['country_id']))
							echo "<p class='bgColorGray' style='color:gray;margin-top:0px;margin-bottom:0px'>".$arrKol['country_id']."</p>";?>
					<h4 style="margin-bottom:0px;color: gray;font-family: tahoma;font-size: 12px;font-weight: bold;margin-top: 10px;text-transform: uppercase;">PHONE</h4>
					<p style="color:gray;margin-top:0px;"><?php echo $arrKol['primary_phone'];?></p>
					
					<h4 style="margin-bottom:0px;color: gray;font-family: tahoma;font-size: 12px;font-weight: bold;margin-top: 10px;text-transform: uppercase;"> FAX</h4>
					<p style="color:gray;margin-top:0px;"><?php echo $arrKol['fax'];?></p>
					
					<h4 style="margin-bottom:0px;color: gray;font-family: tahoma;font-size: 12px;font-weight: bold;margin-top: 10px;text-transform: uppercase;">Email</h4>
					<p  style="color:gray;margin-top:0px;">
						<?php if(isset($arrKol['primary_email'])){
									echo $arrKol['primary_email'];
						}else{
							echo '&nbsp;';
						}?>
					</p>
			</td>
			<td colspan="2">
				<h1  style="text-align: justify;font-family: Tahoma;font-size: 14px;font-weight: bold;" >Profile Summary</h1>
				<p  style="text-align: justify;color:gray;" ><?php echo $arrKol['biography'];?></p>
			</td>
		</tr>
		<?php if(HIDE_CLINICAL_RESERCH_INTERESTS){?>
		<tr>
			<td colspan="2">
				<h1 style="font-family: Tahoma;font-size: 14px;font-weight: bold;">CLINICAL RESEARCH INTERESTS</h1>
				<p  style="color:gray;"><?php echo $arrKol['research_interests'];?></p>
			</td>
		</tr>
		<?php }?>
	</table>
	<!-- End of overview Details Table -->
	
	<!-- Start of Educations  Details Table -->
	<h1 style="background-color: #CCCCCC;font-family: Tahoma;font-size: 12px;font-weight:bold;padding: 4px;text-transform: uppercase;letter-spacing: 1px;">EDUCATION & TRAINING</h1>	
	<?php 
	$education='';	
	foreach($arrEducation as $result):
		if($result['type']=='education'):
			$education='';	
			$education=$result['type'];
		endif;
	endforeach;
	if($education=='education'){?>
		<h4 class="header" style="margin-top:2px; border-bottom:1px solid black;font-size:11pt;font-stretch:ultra-expanded;font-weight:bold;margin-bottom:5px;padding-bottom:2px;text-align:left;width:100%;">Education</h4>
	<?php }?>
	<table  style="width:100%;page-break-after:auto;">
		<tbody>
			<?php foreach($arrEducation as $result):
					if($result['type']=='education'):?>
						<tr>
							<td colspan="3" style="color:black"><?php echo $result['institute_id']; ?></td>
						</tr>
						<tr>	
							<td  style="color:gray;"> <?php echo $result['specialty']; ?></td>
							<td  align="center" style="color:gray;"> <?php echo $result['degree']; ?></td>
							<td  align="right" style="color:gray;"> <?php echo $result['date']; ?></td>
						</tr>								
			<?php   endif; 
	 		endforeach;?>
		</tbody>
	</table>
	<!-- End of Educations  Details Table -->
    <?php 
		$training='';	
		foreach($arrEducation as $result):			
			if($result['type']=='training'):
				$training='';	
				$training=$result['type'];
			endif;
		endforeach;
		if($training=='training'){
	?>
		<h4 class="header" style="border-bottom:1px solid black;font-size:11pt;font-stretch:ultra-expanded;font-weight:bold;margin-bottom:5px;padding-bottom:2px;text-align:left;width:100%;">Training</h4>
	<?php } ?>
	<!-- Start of Training  Details Table -->	       
	<table  style="width:100%;page-break-after:auto;">
		<tbody>
			<?php foreach($arrEducation as $result):
					if($result['type']=='training'):?>
					<tr>
						<td colspan="3" style="color:black"> <?php echo $result['institute_id']; ?></td>
					</tr>
					<tr>	
						<td  style="color:gray;"> <?php echo $result['specialty']; ?></td>
						<td  align="center" style="color:gray;"> <?php echo $result['degree']; ?></td>
						<td  align="right" style="color:gray;"> <?php echo $result['date']; ?></td>
					</tr>
			<?php endif;
			endforeach;?>
		</tbody>
	</table>
	<!-- End of Training  Details Table -->		

	<?php 
		$board='';	
		foreach($arrEducation as $result):			
			if($result['type']=='board_certification'):
				$board='';	
				$board=$result['type'];
			endif;
		endforeach;?>
	<?php if($board=='board_certification'){?>
		<h4  style="border-bottom:1px solid black;font-size:11pt;font-stretch:ultra-expanded;font-weight:bold;margin-bottom:5px;padding-bottom:2px;text-align:left;width:100%;">Board Certification</h4>
	<?php }?>
	<!-- Start of Board Certification  Details Table -->
	<table  style="width:100%;page-break-after:auto;">
		<tbody>
			<?php foreach($arrEducation as $result):
					if($result['type']=='board_certification'):?>
					<tr>
						<td colspan="3" style="color:black"> <?php echo $result['institute_id']; ?></td>
					</tr>
					<tr>	
						<td  style="color:gray;"> <?php echo $result['specialty']; ?></td>
						<td  align="center" style="color:gray;"> <?php echo $result['degree']; ?></td>
						<td  align="right" style="color:gray;"> <?php echo $result['date']; ?></td>
					</tr>
			<?php endif;
			 endforeach; ?>
		</tbody>
	</table>
	<!-- End of Board Certification  Details Table -->			
	<?php 
	$honors='';	
	foreach($arrEducation as $result):		
		if($result['type']=='honors_awards'):
			$honors='';	
			$honors=$result['type'];
		endif;
	endforeach;
	?>
	<?php if($honors=='honors_awards'){?>
			<h4 class="header" style="border-bottom:1px solid black;font-size:11pt;font-stretch:ultra-expanded;font-weight:bold;margin-bottom:5px;padding-bottom:2px;text-align:left;width:100%;">Honors and Awards</h4>
	<?php }?>			
	<!-- Start of Honors  Awards  Details Table -->		
	<table  style="width:100%;page-break-after:auto;">
		<tbody>
			<?php 
				// Variable used to display the Number
				$honourNum	= 1; 
				foreach($arrEducation as $result):
					if($result['type']=='honors_awards'):?>
						<tr>
							<td width="2px"><?php echo $honourNum++ . '.'?></td>
							<td>&nbsp;<?php echo $result['honor_name']; ?></td>
							<td align="right" style="color:gray;">&nbsp;<?php echo $result['date']; ?></td>
						</tr>
			<?php  endif;
		 		endforeach;?>
		</tbody>
	</table>
	<!-- End of Honors  Awards  Details Table -->
	<!-- END OF Education & Traning -->
	
	<!-- START OF PROFESSIONAL AFFILIATIONS -->
	<h1  style="background-color: #CCCCCC;font-family: Tahoma;font-size: 12px;font-weight:bold;padding: 4px;text-transform: uppercase;letter-spacing: 1px;">PROFESSIONAL AFFILIATIONS</h1>
	<?php 
			$university='';
			foreach($arrMembership as $result):					
				if($result['type']=='university'):						
					$university=$result['type'];
				endif;
			endforeach;?>
	<?php  	if($university=='university'){?>
		<h4 class="header" style="margin-top:2px; border-bottom:1px solid black;font-size:11pt;font-stretch:ultra-expanded;font-weight:bold;margin-bottom:5px;padding-bottom:2px;text-align:left;width:100%;">University / Hospitals</h4>
	<?php }?>
		
	<!-- Start OF University / Hospitals Table-->
	<table  style="width:100%;page-break-after:auto;">
		<tbody>
			<?php   
				foreach($arrMembership as $result):
					if($result['type']=='university'):?>
						<tr>
							<td  width="65px" style="color:black;"> <?php echo $result['engagement_type']; ?></td>
							<td  width="500px" style="color:black;"> <?php echo $result['institute_id'];if($result['department']!='')echo ", ".$result['department']; ?></td>
							<td width="65px">&nbsp;</td>
						</tr>
						<tr>
							<td>&nbsp;</td>
							<td align="left" style="color:gray;"> <?php echo $result['role']; ?></td>
							<td align="right"  style="color:gray;"> <?php echo $result['date']; ?></td>
						</tr>							
			<?php endif;
				 endforeach;?>
		</tbody>
	</table>
	<!-- ENd OF University / Hospitals Table-->
	<p>&nbsp;</p>
	<?php 
			$association='';
			foreach($arrMembership as $result):				
				if($result['type']=='association'):
					$association=$result['type'];
				endif;
			endforeach;?>
	<?php  	if($association=='association'){?>
		<h4 class="header" style="border-bottom:1px solid black;font-size:11pt;font-stretch:ultra-expanded;font-weight:bold;margin-bottom:5px;padding-bottom:2px;text-align:left;width:100%;">Associations / Societies</h4>
	<?php }?>
	<!-- Start OF Associations / Societies Table-->
	<table class="records" style="width:100%;page-break-after:auto;">
		<tbody>
			<?php foreach($arrMembership as $result):
					if($result['type']=='association'):?>	
					<tr>
						<td  width="65px" style="color:black;"> <?php echo $result['engagement_type']; ?></td>
						<td  width="500px" style="color:black;"> <?php echo $result['institute_id'];if($result['department']!='')echo ", ".$result['department']; ?></td>
						<td width="65px">&nbsp;</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td align="left"  style="color:gray;"> <?php echo $result['role']; ?></td>
						<td align="right"  style="color:gray;"> <?php echo $result['date']; ?></td>
					</tr>
			<?php endif;
				endforeach;?>
		</tbody>						
	</table>
	<?php 
	$reullt1='';
	foreach($arrMembership as $result):
		if($result['type']=='industry'):							
			$reullt1=$result['type'];
		endif;
	endforeach;
	?>
	<?php if($reullt1=='industry'){?>
		<h4  style="border-bottom:1px solid black;font-size:11pt;font-stretch:ultra-expanded;font-weight:bold;margin-bottom:5px;padding-bottom:2px;text-align:left;width:100%;">Industry</h4>
	<?php }?>
	<!-- Start OF Industry Table-->
	<table class="records" style="width:100%;page-break-after:auto;">
		<tbody>
			<?php foreach($arrMembership as $result):								
				if($result['type']=='industry'):?>
					<tr>
						<td  width="65px" style="color:black;"> <?php echo $result['engagement_type']; ?></td>
						<td  width="500px" style="color:black;"> <?php echo $result['institute_id'];if($result['department']!='')echo ", ".$result['department']; ?></td>
						<td width="65px">&nbsp;</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td align="left" style="color:gray;" style="color:gray;"> <?php echo $result['role']; ?></td>
						<td align="right" style="color:gray;" style="color:gray;"> <?php echo $result['date']; ?></td>
					</tr>							
			<?php endif;
				 endforeach;?>
		</tbody>
	</table>
	<!-- ENd OF Industry Table-->
			
	<?php $government='';	
		 	foreach($arrMembership as $result):
				if($result['type']=='government'):
					$government='';	
					$government=$result['type'];
				endif;
			endforeach;?>
	<?php if($government=='government'){ ?>
		<h4 class="header" style="border-bottom:1px solid black;font-size:11pt;font-stretch:ultra-expanded;font-weight:bold;margin-bottom:5px;padding-bottom:2px;text-align:left;width:100%;">Government</h4>
	<?php }	?>
	<!-- Start OF Government Table-->
	<table class="records" style="width:100%;page-break-after:auto;">
		<tbody>
			<?php 
			foreach($arrMembership as $result):
				if($result['type']=='government'):?>
					<tr>
						<td  width="65px" style="color:black;"> <?php echo $result['engagement_type']; ?></td>
						<td  width="500px" style="color:black;"> <?php echo $result['institute_id'];if($result['department']!='')echo ", ".$result['department']; ?></td>
						<td width="65px">&nbsp;</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td align="left" style="color:gray;"> <?php echo $result['role']; ?></td>
						<td align="right" style="color:gray;"> <?php echo $result['date']; ?></td>
					</tr>
			<?php endif;
				 endforeach;?>
		</tbody>
	</table>
	<!-- ENd OF Government Table-->
	<?php 
	$others='';	
	foreach($arrMembership as $result):
		if($result['type']=='others'):
			$others='';	
			$others=$result['type'];
		endif;
	endforeach;?>
	<?php if($others=='others'){ ?>
			<h4 class="header" style="border-bottom:1px solid black;font-size:11pt;font-stretch:ultra-expanded;font-weight:bold;margin-bottom:5px;padding-bottom:2px;text-align:left;width:100%;">Others</h4>
	<?php } ?>
	<!-- Start OF Others Table-->
	<table class="records" style="width:100%;page-break-after:auto;">
		<tbody>
			<?php foreach($arrMembership as $result):
					if($result['type']=='others'):?>
					<tr>
						<td  width="65px" style="color:black;"> <?php echo $result['engagement_type']; ?></td>
						<td  width="500px" style="color:black;"> <?php echo $result['institute_id'];if($result['department']!='')echo ", ".$result['department']; ?></td>
						<td width="65px">&nbsp;</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td align="left" style="color:gray;"> <?php echo $result['role']; ?></td>
						<td align="right" style="color:gray;"> <?php echo $result['date']; ?></td>
					</tr>						
			<?php endif;
				 endforeach;?>
		</tbody>
	</table>
	<!-- ENd OF Others Table-->
			
	<!-- START OF Events -->
	<h1 class="mainHeading" style="background-color: #CCCCCC;font-family: Tahoma;font-size: 12px;font-weight:bold;padding: 4px;text-transform: uppercase;letter-spacing: 1px;">EVENTS</h1>
 	<?php  if(!(empty($arrEvent))){?>
		<h4 class="header" style="border-bottom:1px solid black;font-size:11pt;font-stretch:ultra-expanded;font-weight:bold;margin-bottom:5px;padding-bottom:2px;text-align:left;width:100%;">Congresses / Conferences</h4>
	<?php }?>
	<!-- Start OF Congresses / Conferences Table-->
	<table class="records" style="width:100%;page-break-after:auto;">
		<tbody>
			<?php foreach($arrEvent as $result):						
				if($result['type']=='conference'):?>
					<tr>
						<td  width="80px" style="color:black;"><?php echo $result['session_type']; ?></td>
						<td colspan="3" width="550px" style="color:black;"><?php echo $result['name']?></td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td colspan="3" style="color:gray;"><?php echo $result['session_name']?></td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td style="color:gray;"><?php echo $result['role']?></td>
						<td align="center" style="color:gray;"><?php echo $result['Country']?></td>
						<td style="color:gray;" align="right"><?php echo $result['date']?></td>
					</tr>
			<?php endif;
				endforeach;?>
		</tbody>
	</table>
	<!-- End OF Congresses / Conferences Table-->	
			
	<h1 class="mainHeading2" style="background-color: #CCCCCC;font-family: Tahoma;font-size: 12px;font-weight:bold;padding: 4px;text-transform: uppercase;letter-spacing: 1px;">PUBLICATIONS (Recent 20 only)</h1>
	<?php if(isset($arrPublications)):
			echo '<ol>';
		foreach($arrPublications as $result):?>
		<li>
			<p style="margin-bottom:0px;margin-top:0px;color:black;"><?php echo $result['article_title'];?></p>
			<p style="color:gray;margin-bottom:0px;margin-top:0px;"><?php echo $result['authors'];?></p> 
			<p style="color:gray;margin-bottom:0px;margin-top:0px;"><?php echo $result['journal_name'];
	
			                          if($result['date']!='')echo '; '.$result['date'];
			                          
			                          if($result['volume']!='')echo '; '.$result['volume'].'('.$result['issn_number'].')';?></p>
		</li>
		<?php endforeach;
			echo '</ol>';
		endif;?>
		<?php if($arrMajorTerms!=''){?>
			<h1  style="background-color: #CCCCCC;font-family: Tahoma;font-size: 12px;font-weight:bold;padding: 4px;text-transform: uppercase;letter-spacing: 1px;">KEYWORDS IN PUBLICATIONS</h1>
			<p>&nbsp;</p>
			<p style="color:gray;" style="text-align: justify;"><?php echo $arrMajorTerms;?></p>	
			<p>&nbsp;</p>	
		<?php }?>
		<p>&nbsp;</p>
		<?php if(HIDE_CLINICAL_TRIALS){?>
			<h1  style="background-color: #CCCCCC;font-family: Tahoma;font-size: 12px;font-weight:bold;padding: 4px;text-transform: uppercase;letter-spacing: 1px;">CLINICAL TRIALS</h1>
			<?php if(isset($arrClinicalTrials)):?>
				<ol>
				<?php foreach($arrClinicalTrials as $result): ?>	
					<li>
						<p style="margin-bottom:0px;margin-top:0px;color:black;"><b><?php echo $result['trial_name'];?></b><?php if($result['date']!=' ') echo ', '.$result['date'];?></p>
						<p style="margin-bottom:0px;margin-top:0px;color:gray;"><b>Official Title: </b><?php echo $result['official_title'];?></p>
						<p style="margin-bottom:0px;margin-top:0px;color:gray;"><b>URL: </b><?php echo $result['url'];?></p>
						<p style="margin-bottom:0px;margin-top:0px;color:gray;"><b>Study Type: </b><?php echo $result['study_type'];?></p>
						<p style="margin-bottom:0px;margin-top:0px;color:gray;"><b>Sponsor: </b><?php echo $result['sponsors'];?></p>
						<p style="margin-bottom:0px;margin-top:0px;color:gray;"><b>Condition: </b><?php echo $result['condition'];?></p>
						<p style="margin-bottom:0px;margin-top:0px;color:gray;"><b>Phase:</b><?php echo $result['phase'];?></p>
						<p style="margin-bottom:0px;margin-top:0px;color:gray;"><b>Purpose: </b><?php echo $result['purpose'];?></p>	 
						<p style="margin-bottom:0px;margin-top:0px;color:gray;"><b>Date: </b><?php echo 'Starts from '.$result['start_date'].' to '.$result['end_date'];?></p>	 
						<p style="margin-bottom:0px;margin-top:0px;color:gray;"><b>Age: </b><?php echo $result['min_age'].' to '.$result['max_age'];?></p> 
						<p style="margin-bottom:0px;margin-top:0px;color:gray;"><b>Gender: </b><?php echo $result['gender'];?></p>
						<p style="margin-bottom:0px;margin-top:0px;color:gray;"><b>Role: </b><?php echo $result['kol_role'];?></p>
						<p style="margin-bottom:0px;margin-top:0px;color:gray;"><b>No of Enrollees: </b><?php echo $result['no_of_enrollees'];?> </p>
						<p style="margin-bottom:0px;margin-top:0px;color:gray;"><b>No of Trial Sites: </b><?php echo $result['no_of_trial_sites'];?></p>
						<p style="margin-bottom:0px;margin-top:0px;color:gray;"><b>Collaborator: </b><?php echo $result['collaborator'];?></p>
						<p style="margin-bottom:0px;margin-top:0px;color:gray;"><b>Intervention: </b><?php echo $result['interventions'];?></p>
						<p style="margin-bottom:0px;margin-top:0px;color:gray;"><b>Keywords: </b><?php echo $result['keywords'];?></p>
						<p style="margin-bottom:0px;margin-top:0px;color:gray;"><b>MeSh Terms: </b><?php echo $result['mesh_terms'];?></p>
						<p style="margin-bottom:0px;margin-top:0px;color:gray;"><b>Investigators: </b><?php echo $result['investigators'];?></p>
				</li>
			<?php endforeach;?>
			</ol>
	<?php endif;	
	} ?>
				
	<!-- START OF Details -->
	<h1 class="mainHeading" style="background-color: #CCCCCC;font-family: Tahoma;font-size: 12px;font-weight:bold;padding: 4px;text-transform: uppercase;letter-spacing: 1px;">DETAILS</h1>
 	<?php  if(!(empty($locationData))){?>
	<h4 class="header" style="border-bottom:1px solid black;font-size:11pt;font-stretch:ultra-expanded;font-weight:bold;margin-bottom:5px;padding-bottom:2px;text-align:left;width:100%;">Location</h4>
	<?php } if(sizeof($locationData) > 0){?>
	<!-- Start OF Congresses / Conferences Table-->
	<table class="records" style="width:100%;page-break-after:auto;">
		<tbody>
			<?php foreach($locationData as $result):
					if($result['is_primary']=='Yes'){
						$type = ' (Primary)';
					}else{
						$type = '';
					}?>
					<tr>
						<td colspan="4" style="color:black;"><?php echo $result['org_name'].$type?></td>
					</tr>
					<tr>
						<td colspan="4" style="color:gray;"><?php echo $result['address1'].', '.$result['address2'].', '.$result['City'].', '.$result['Region'].', '.$result['Country'].', '.$result['postal_code'];?></td>
					</tr>
					<tr>
						<td colspan="4">&nbsp;</td>
					</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<?php } ?>
			
	<!-- Phone -->
	<?php  if(!(empty($phoneData))){?>
	<h4 class="header" style="border-bottom:1px solid black;font-size:11pt;font-stretch:ultra-expanded;font-weight:bold;margin-bottom:5px;padding-bottom:2px;text-align:left;width:100%;">Phone</h4>
	<?php } if(sizeof($phoneData) > 0){?>
	<!-- Start OF Congresses / Conferences Table-->
	<table class="records" style="width:100%;page-break-after:auto;">
		<tbody>
			<?php   foreach($phoneData as $result):
						if($result['is_primary']=='Yes'){
							$type = ' (Primary)';
						}else{
							$type = '';
						}?>
						<tr>
							<td colspan="4" style="color:black;"><?php echo $result['org_name'].$type?></td>
						</tr>
						<tr>
							<td colspan="4" style="color:gray;"><?php echo $result['name'].' : '.$result['number'];?></td>
						</tr>
						<tr>
							<td colspan="4">&nbsp;</td>
						</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<?php } ?>
			
	<!-- Email -->
	<?php  if(!(empty($emailData))){?>
	<h4 class="header" style="border-bottom:1px solid black;font-size:11pt;font-stretch:ultra-expanded;font-weight:bold;margin-bottom:5px;padding-bottom:2px;text-align:left;width:100%;">Email</h4>
	<?php } if(sizeof($emailData) > 0){?>
	<!-- Start OF Congresses / Conferences Table-->
	<table class="records" style="width:100%;page-break-after:auto;">
		<tbody>
			<?php foreach($emailData as $result):?>
				<tr>
					<td colspan="4"style="color:black;"><?php echo $result['type'].' : '.$result['email'];?></td>
				</tr>
				<tr>
					<td colspan="4">&nbsp;</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<?php } ?>
			
	<!-- License -->
	<?php if(KOLS_STATE_LICENSE){ ?>
		<?php  if(!(empty($licenseData))){?>
			<h4 class="header" style="border-bottom:1px solid black;font-size:11pt;font-stretch:ultra-expanded;font-weight:bold;margin-bottom:5px;padding-bottom:2px;text-align:left;width:100%;">License</h4>
		<?php } 
		if(sizeof($licenseData) > 0){?>
		<!-- Start OF Congresses / Conferences Table-->
		<table class="records" style="width:100%;page-break-after:auto;">
			<tbody>
				<?php   
					foreach($licenseData as $result):
					$type = '';
					if($result['is_primary']=='Yes'){
						$type = ' (Primary)';
					}
					?>
					<tr>
						<td style="color:black;" colspan="1"><?php echo $result['state_license']; ?></td>
						<td colspan="3" style="color:gray;"><?php echo $result['Region'].', '.$result['Country'].$type;?></td>
					</tr>
					<tr>
						<td colspan="4">&nbsp;</td>
					</tr>
				<?php endforeach;?>
			</tbody>
		</table>
		<?php } ?>
	<?php }?>
			
	<!-- Specialty -->
	<?php  if(!(empty($specialtyData))){?>
	<h4 class="header" style="border-bottom:1px solid black;font-size:11pt;font-stretch:ultra-expanded;font-weight:bold;margin-bottom:5px;padding-bottom:2px;text-align:left;width:100%;">Specialty</h4>
	<?php } if(sizeof($specialtyData) > 0){?>
	<!-- Start OF Congresses / Conferences Table-->
	<table class="records" style="width:100%;page-break-after:auto;">
		<tbody>
			<?php   
				$arrSubSpecialty = '';
				foreach($specialtyData as $result):
					if($result['priority'] == 'Sub-Specialty'){
						$arrSubSpecialty.= $result['specialty'].', ';
					}else{ ?>
					<tr>
						<td colspan="4" style="color:black;"><?php echo $result['priority'].' : '.$result['specialty'];?></td>
					</tr>
					<tr>
						<td colspan="4">&nbsp;</td>
					</tr>
				<?php }
				endforeach;
				if(!empty($arrSubSpecialty)){ ?>
					 <tr>
						<td colspan="4" style="color:black;"><?php echo 'Sub-Specialty : '.rtrim($arrSubSpecialty,",");?></td>
					 </tr>
					 <tr>
						<td colspan="4">&nbsp;</td>
					 </tr>
			<?php } ?>
		</tbody>
	</table>
	<?php } ?>
			
	<!-- Staff -->
	<?php  if(!(empty($staffData))){?>
	<h4 class="header" style="border-bottom:1px solid black;font-size:11pt;font-stretch:ultra-expanded;font-weight:bold;margin-bottom:5px;padding-bottom:2px;text-align:left;width:100%;">Staff</h4>
	<?php } 
	if(sizeof($staffData) > 0){?>
	<!-- Start OF Congresses / Conferences Table-->
	<table class="records" style="width:100%;page-break-after:auto;">
		<tbody>
			<?php foreach($staffData as $result): ?>
			<tr>
				<td colspan="4" style="color:black;"><?php echo $result['org_name']?></td>
			</tr>
			<tr>
				<td colspan="4" style="color:gray;"><?php echo $result['staff_title'].', '.$result['phone_type'].' : '.$result['phone_number'].', '.$result['email'].', '.$result['address1'].', '.$result['address2'].', '.$result['City'].', '.$result['Region'].', '.$result['Country'].', '.$result['postal_code'];?></td>
			</tr>
			<tr>
				<td colspan="4">&nbsp;</td>
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<?php } ?>
	
	</body>
</html>