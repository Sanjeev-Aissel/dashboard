create database if not exists `kolm`;

USE `kolm`;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


/*Table structure for table `access_objects` */
 /**
 * @table access_objects
 * @description Holds the 'access objects' master records
 * @author Laxman K
 * @since 
 * @version 3.5
 * @modified  - Updated table Collation  CHARSET to utf 8 to all tables
 */
DROP TABLE IF EXISTS `access_objects`;
CREATE TABLE `access_objects` (
  `id` int(40) NOT NULL auto_increment,
  `name` varchar(250) character set latin1 NOT NULL,
  `alias` varchar(250) character set latin1 NOT NULL,
  `parent_id` int(11) default NULL,
  `is_deleted` tinyint(4) default NULL,
  `deleted_by` varchar(40) character set latin1 default NULL,
  `deleted_on` datetime default NULL,
  `created_by` varchar(40) character set latin1 NOT NULL,
  `created_on` datetime NOT NULL,
  `modified_by` varchar(40) character set latin1 default NULL,
  `modified_on` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




/*Table structure for table `cities` */
 /**
 * @table access_cities
 * @description  Holds the 'cities' master records, this structures is taken from googles 'GeoWorldMap' plugin
 * @author Laxman K
 * @since 
 * @version3.5.1
 */

DROP TABLE IF EXISTS `cities`;
CREATE TABLE `cities` (
  `CityId` int(11) NOT NULL auto_increment,
  `CountryID` smallint(6) NOT NULL,
  `RegionID` smallint(6) NOT NULL,
  `City` varchar(45) character set latin1 NOT NULL,
  `Latitude` float NOT NULL,
  `Longitude` float NOT NULL,
  `TimeZone` varchar(10) character set latin1 NOT NULL,
  `DmaId` smallint(6) default NULL,
  `County` varchar(25) character set latin1 default NULL,
  `Code` varchar(4) character set latin1 default NULL,
  PRIMARY KEY  (`CityId`),
  KEY `RegionID` (`RegionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `countries` */
 /**
 * @table access_countries
 * @description Holds the 'countries' master records, this structures is taken from googles 'GeoWorldMap' plugin
 * @author Laxman K
 * @since 
 * @version3.5.1
 */

DROP TABLE IF EXISTS `countries`;
CREATE TABLE `countries` (
  `CountryId` smallint(6) NOT NULL auto_increment,
  `Country` varchar(50) character set latin1 NOT NULL,
  `FIPS104` varchar(2) character set latin1 NOT NULL,
  `ISO2` varchar(2) character set latin1 NOT NULL,
  `ISO3` varchar(3) character set latin1 NOT NULL,
  `ISON` varchar(4) character set latin1 NOT NULL,
  `Internet` varchar(2) character set latin1 NOT NULL,
  `Capital` varchar(25) character set latin1 default NULL,
  `MapReference` varchar(50) character set latin1 default NULL,
  `NationalitySingular` varchar(35) character set latin1 default NULL,
  `NationalityPlural` varchar(35) character set latin1 default NULL,
  `Currency` varchar(30) character set latin1 default NULL,
  `CurrencyCode` varchar(3) character set latin1 default NULL,
  `Population` bigint(20) default NULL,
  `Title` varchar(50) character set latin1 default NULL,
  `Comment` varchar(255) character set latin1 default NULL,
  PRIMARY KEY  (`CountryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table  dmas` */
 /**
 * @table access_dmas
 * @description Holds the countries 'dmas' master records, this structures is taken from googles 'GeoWorldMap' plugin
 */

DROP TABLE IF EXISTS `dmas`;
CREATE TABLE `dmas` (
  `DmaId` smallint(6) NOT NULL,
  `CountryId` smallint(6) default NULL,
  `DMA` varchar(3) character set latin1 default NULL,
  `Market` varchar(50) character set latin1 default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `imported_kols` */
 /**
 * @table imported_kols
 * @description 
 * @author 
 * @since 
 * @version
 * @modified  - 

DROP TABLE IF EXISTS `imported_kols`;
CREATE TABLE `imported_kols` (
  `id` int(11) NOT NULL auto_increment,
  `first_name` varchar(250) character set latin1 default NULL,
  `middle_name` varchar(150) character set latin1 default NULL,
  `last_name` varchar(250) character set latin1 default NULL,
  `org_name` varchar(255) character set latin1 default NULL,
  `city_id` int(5) default NULL,
  `state_id` int(5) default NULL,
  `country_id` int(5) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*Table structure for table ' kol_additional_contacts`*/
 /**
 * @table  kol_additional_contacts
 * @description  Holds the kols 'additional contacts' records, one kol can have many additional contacts
 * @author 
 * @since 
 * @version
 * @modified  - Modified on Dec 23rd, 2010 - Added 3 more fields - url1, url2, notes


CREATE TABLE `kol_additional_contacts` (
  `id` int(11) NOT NULL auto_increment,
  `kol_id` int(11) default NULL,
  `related_to` varchar(250) character set latin1 default NULL,
  `phone` varchar(15) character set latin1 default NULL,
  `email` varchar(150) character set latin1 default NULL,
  `url1` text character set latin1,
  `url2` text character set latin1,
  `notes` text character set latin1,
  `created_by` varchar(40) character set latin1 NOT NULL,
  `created_on` datetime NOT NULL,
  `modified_by` varchar(40) character set latin1 default NULL,
  `modified_on` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*Table structure for table `kol_educations` */
 /**
 * @table `kol_educations
 * @description Holds the kols 'Education' records, one kol can have many 'education' records
 * @author  Laxman K
 * @since 
 * @version3.5.1
 * @ Modified on Dec 23rd, 2010 - Added 3 more fields - url1, url2, notes 
 *@ Modified on Dec 29th, 2010 - Changed `institute_name` field to `institute_id` integer,Changed   `year` field to integer(11) NULL, Added 1 more field - honor_name
 *@ Added index on column (type, kol_id)

CREATE TABLE `kol_educations` (
  `id` int(11) NOT NULL auto_increment,
  `kol_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `institute_id` int(50) NOT NULL,
  `degree` varchar(50) default NULL,
  `start_date` char(4) default NULL,
  `end_date` char(4) default NULL,
  `specialty` varchar(250) NOT NULL,
  `honor_name` varchar(250) NOT NULL,
  `year` int(11) default NULL,
  `url1` mediumtext,
  `url2` mediumtext,
  `notes` mediumtext,
  `created_by` varchar(40) NOT NULL,
  `created_on` datetime NOT NULL,
  `modified_by` varchar(40) default NULL,
  `modified_on` datetime default NULL,
  `client_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `institute_id` (`institute_id`),
  KEY `education_fk_kol_id` (`kol_id`),
  KEY `koledu_type_kol_id` (`type`,`kol_id`),
  CONSTRAINT `education_fk_kol_id` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*Table structure for table `kol_events` */
 /**
 * @table kol_events
 * @description Holds the kols 'Event' records, one kol can have many 'event' records
 * @author 
 * @since 
 * @version 
 * @modified  - Modified on Dec 26th, 2010 - As per the CR New fields for the Events table is added
 * @ Modified on Dec 29th, 2010 - Changed   `event_name` field to `event_id`
 */

DROP TABLE IF EXISTS `kol_events`;
CREATE TABLE `kol_events` (
  `id` int(11) NOT NULL auto_increment,
  `kol_id` int(11) NOT NULL,
  `type` varchar(50) default NULL,
  `event_type` int(50) NOT NULL,
  `event_id` int(50) NOT NULL,
  `session_type` int(50) NOT NULL,
  `session_name` varchar(250) default NULL,
  `role` varchar(250) default NULL,
  `topic` int(50) NOT NULL,
  `start` date NOT NULL,
  `end` date default NULL,
  `organizer` varchar(250) NOT NULL,
  `location` varchar(250) NOT NULL,
  `address` varchar(255) default NULL,
  `city_id` int(5) default NULL,
  `state_id` int(5) default NULL,
  `country_id` int(5) default NULL,
  `postal_code` varchar(15) default NULL,
  `subject` varchar(250) default NULL,
  `url1` mediumtext,
  `url2` mediumtext,
  `notes` mediumtext,
  `created_by` varchar(40) NOT NULL,
  `created_on` datetime NOT NULL,
  `modified_by` varchar(40) default NULL,
  `modified_on` datetime default NULL,
  `client_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `event_id` (`event_id`),
  KEY `session_name` (`session_name`),
  KEY `events_fk_kol_id` (`kol_id`),
  CONSTRAINT `events_fk_kol_id` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;    



/*Table structure for table `kol_memberships` */
 /**
 * @table kol_memberships
 * @description  Holds the kols 'Membership(Affiliation)' records, one kol can have many 'Membership(Affiliation)' records
 * @author 
 * @version 
 * @Modified on Dec 23rd, 2010 - Added 3 more fields - url1, url2, notes 
 * @Modified on Dec 26rd, 2010 - Added 1 more fields - engagement_id 
 * @Modified on Dec 30rd, 2010 - Modified 'name' field to 'institute_id'
 * @Modified on JAn 5rd, 2010 - Modified 'type' field 'int' to' varchar(250) NOT NULL,
 * @Modified on JAn 5rd, 2010 - Modified 'start_date' field 'datetime' to varchar(11) NOT NULL,
 * @Modified on JAn 5rd, 2010 - Modified 'end_date' field 'datetime' to varchar(11) NOT NULL,
 */

DROP TABLE IF EXISTS `kol_memberships`;
CREATE TABLE `kol_memberships` (
  `id` int(11) NOT NULL auto_increment,
  `kol_id` int(11) NOT NULL,
  `type` varchar(250) NOT NULL,
  `institute_id` int(50) NOT NULL,
  `department` varchar(250) default NULL,
  `title` varchar(250) default NULL,
  `start_date` varchar(11) NOT NULL,
  `end_date` varchar(11) NOT NULL,
  `committee` varchar(250) default NULL,
  `role` varchar(250) default NULL,
  `division` varchar(250) default NULL,
  `purpose` varchar(250) default NULL,
  `amount` decimal(10,0) default NULL,
  `url1` mediumtext,
  `url2` mediumtext,
  `notes` mediumtext,
  `engagement_id` int(50) NOT NULL,
  `created_by` varchar(40) default NULL,
  `created_on` datetime default NULL,
  `modified_by` varchar(40) default NULL,
  `modified_on` datetime default NULL,
  `client_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `title` (`title`),
  KEY `institute_id` (`institute_id`),
  KEY `membership_fk_kol_id` (`kol_id`),
  CONSTRAINT `membership_fk_kol_id` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `kols` */
 /**
 * @table kols
 * @description Holds the kol records, this is the core kol table which holds all primary details related to kol and this table is master table for many of the other tables
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `kols`;
CREATE TABLE `kols` (
  `id` int(11) NOT NULL auto_increment,
  `salutation` tinyint(3) NOT NULL,
  `first_name` varchar(250) NOT NULL,
  `middle_name` varchar(250) NOT NULL,
  `last_name` varchar(250) NOT NULL,
  `suffix` varchar(250) default NULL,
  `specialty` tinyint(5) NOT NULL,
  `sub_specialty` varchar(50) default NULL,
  `dob` date default NULL,
  `gender` varchar(6) NOT NULL,
  `org_id` varchar(250) NOT NULL,
  `title` varchar(250) default NULL,
  `division` varchar(250) default NULL,
  `primary_phone` varchar(15) default NULL,
  `primary_email` varchar(250) default NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city_id` int(5) NOT NULL,
  `state_id` int(5) NOT NULL,
  `country_id` int(5) NOT NULL,
  `postal_code` varchar(50) NOT NULL,
  `fax` varchar(15) default NULL,
  `research_interests` mediumtext NOT NULL,
  `license` varchar(50) default NULL,
  `biography` mediumtext NOT NULL,
  `notes` mediumtext,
  `profile_image` varchar(255) default NULL,
  `url` mediumtext,
  `blog` mediumtext,
  `linked_in` mediumtext,
  `facebook` mediumtext,
  `twitter` mediumtext,
  `myspace` mediumtext,
  `you_tube` mediumtext,
  `created_by` varchar(40) NOT NULL,
  `created_on` datetime NOT NULL,
  `modified_by` varchar(40) default NULL,
  `modified_on` datetime default NULL,
  `is_pubmed_processed` tinyint(1) default NULL,
  `is_clinical_trial_processed` tinyint(1) NOT NULL,
  `pin` varchar(50) NOT NULL default '0',
  `is_imported` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `nbc` */
 /**
 * @table access_objects
 * @description Holds the cities 'nbc' master records, this structures is taken from googles 'GeoWorldMap' plugin
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `nbc`;
CREATE TABLE `nbc` (
  `PrimaryCityId` int(11) NOT NULL,
  `CityId` int(11) NOT NULL,
  `Distance` smallint(6) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `permissions` */
 /**
 * @table permissions
 * @description Holds the 'permissions' records, this defines the 'permissions' to each role with respect to 'access objects'
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `acc_obj_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `is_allowed` tinyint(4) default '0',
  PRIMARY KEY  (`acc_obj_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `privateaddresses` */
 /**
 * @table privateaddresses
 * @description Holds the 'privateaddresses' master records, this structures is taken from googles 'GeoWorldMap' plugin
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `privateaddresses`;
CREATE TABLE `privateaddresses` (
  `AddressPrefix` varchar(11) character set latin1 NOT NULL,
  PRIMARY KEY  (`AddressPrefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `proxynetworks` */
 /**
 * @table access_objects
 * @description  Holds the cities 'proxynetworks' master records, this structures is taken from googles 'GeoWorldMap' plugin
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `proxynetworks`;
CREATE TABLE `proxynetworks` (
  `SubnetAddress` varchar(11) character set latin1 default NULL,
  `Network` varchar(50) character set latin1 default NULL,
  `CityId` int(11) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*Table structure for table `regions` */
 /**
 * @table regions
 * @description Holds the 'regions' master records, this structures is taken from googles 'GeoWorldMap' plugin
 * @author Laxman K
 * @version 3.5.1
 * @modified  -Added index on column CountryID
 */

DROP TABLE IF EXISTS `regions`;
CREATE TABLE `regions` (
  `RegionID` smallint(6) NOT NULL auto_increment,
  `CountryID` smallint(6) NOT NULL,
  `Region` varchar(45) character set latin1 NOT NULL,
  `Code` varchar(8) character set latin1 NOT NULL,
  `ADM1Code` char(4) character set latin1 NOT NULL,
  PRIMARY KEY  (`RegionID`),
  KEY `regions_country_id` (`CountryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `roles` */
 /**
 * @table roles
 * @description Holds the 'roles' master records
 * @author 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(40) NOT NULL auto_increment,
  `name` varchar(250) character set latin1 NOT NULL,
  `parent_id` int(40) default NULL,
  `is_deleted` tinyint(4) default NULL,
  `deleted_by` varchar(40) character set latin1 default NULL,
  `deleted_on` datetime default NULL,
  `created_by` varchar(40) character set latin1 NOT NULL,
  `created_on` datetime NOT NULL,
  `modified_by` varchar(40) character set latin1 default NULL,
  `modified_on` datetime default NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `specialties` */
 /**
 * @table specialties
 * @description Holds the 'specialties' master records
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `specialties`;
CREATE TABLE `specialties` (
  `id` int(11) NOT NULL auto_increment,
  `specialty` varchar(250) character set latin1 NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `subnets` */
 /**
 * @table subnets
 * @description Holds the 'subnets' master records, this structures is taken from googles 'GeoWorldMap' plugin
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `subnets`;
CREATE TABLE `subnets` (
  `SubNetAddress` varchar(11) character set latin1 NOT NULL,
  `Certainty` smallint(6) default NULL,
  `CityId` int(11) default NULL,
  `RegionId` int(11) default NULL,
  `CountryId` int(11) default NULL,
  `DmaId` smallint(6) default NULL,
  `RegionCertainty` smallint(6) default NULL,
  `CountryCertainty` smallint(6) default NULL,
  PRIMARY KEY  (`SubNetAddress`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `users` */
 /**
 * @table users
 * @description 
 * @author 
 * @since 
 * @version 
 * @modified  -
 *

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL auto_increment,
  `user_email` varchar(150) character set latin1 default NULL,
  `user_pass` varchar(150) character set latin1 default NULL,
  `user_date` int(11) default NULL,
  `user_full_name` varchar(150) character set latin1 default NULL,
  `user_address` varchar(150) character set latin1 default NULL,
  `employee_id` varchar(150) character set latin1 default NULL,
  `office_extn` varchar(150) character set latin1 default NULL,
  `user_phone_number` varchar(20) character set latin1 default NULL,
  `created` datetime default NULL,
  `user_modified` datetime default NULL,
  `user_role` varchar(150) character set latin1 default NULL,
  `user_last_login` datetime default NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*Table structure for table `events` */
 /**
 * @table events 
 * @description Holds the kols 'events' master records
 * @author 
 * @since 
 * @version 
 * @modified  -Modified on Dec 29th, 2010 - Added 1 more field - category
 *

DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `id` int(11) NOT NULL auto_increment,
  `category` varchar(255) NOT NULL,
  `name` varchar(255) default NULL,
  `notes` varchar(255) default NULL,
  `created_by` varchar(40) default NULL,
  `created_on` datetime default NULL,
  `modified_by` varchar(40) default NULL,
  `modified_on` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `event_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*Table structure for table `institutions` */
 /**
 * @table institutions
 * @description Holds the 'institutions' master records, this may be affiliated institute, education institute etc
 * @author 
 * @since 
 * @version 
 * @modified  -Modified on Dec 29th, 2010 - changed the 'name' field as not null
 * @ Modified Name column to unique
 *


DROP TABLE IF EXISTS `institutions`;
CREATE TABLE `institutions` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `notes` varchar(255) default NULL,
  `created_by` varchar(40) default NULL,
  `created_on` datetime default NULL,
  `modified_by` varchar(40) default NULL,
  `modified_on` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `institute_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*Table structure for table `conf_event_types` */
 /**
 * @table conf_event_types
 * @description  master table, holds the 'confurence' event 'types'
 * @author Ambarish N.
 * @since 28 Dec, 2010
 * @version 
 * @modified  -As per the new CR, the Events subsection has been changed. New fields have been added which acts as lookup values
 */

DROP TABLE IF EXISTS `conf_event_types`;
CREATE TABLE `conf_event_types` (
  `id` int(11) NOT NULL auto_increment,
  `event_type` varchar(255) character set latin1 NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `conf_session_types` */
 /**
 * @table conf_session_types
 * @description  master table, holds the 'confurence' session 'types'
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `conf_session_types`;
CREATE TABLE `conf_session_types` (
  `id` int(11) NOT NULL auto_increment,
  `session_type` varchar(255) character set latin1 NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `online_event_types` */
 /**
 * @table online_event_types
 * @description master table, holds the 'online' event 'types'
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `online_event_types`;
CREATE TABLE `online_event_types` (
  `id` int(11) NOT NULL auto_increment,
  `event_type` varchar(255) character set latin1 NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `engagement_types` */
 /**
 * @table engagement_types
 * @description master table, holds the different 'Engagement Types'
 * @author Vinayak N.
 * @since 28 Dec, 2010
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `engagement_types`;
CREATE TABLE `engagement_types` (
  `id` int(11) NOT NULL auto_increment,
  `engagement_type` varchar(255) character set latin1 NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;      




/*Table structure for table `kol_publications` */
 /**
 * @table kol_publications
 * @description Holds the ' Many to Many'  associations between the KOLs and the Publications
 * @author Laxman K
 * @since 
 * @version  3.5.1
 * @modified  -Added index on column (is_deleted, is_verified, kol_id)
 * @ Added unique constraint for(kol_id, pub_id)
 * @ Added on delete cascade on kol_id
 */

DROP TABLE IF EXISTS `kol_publications`;
CREATE TABLE `kol_publications` (
  `id` int(50) NOT NULL auto_increment,
  `kol_id` int(11) NOT NULL,
  `pub_id` int(50) default NULL,
  `is_deleted` tinyint(1) default NULL,
  `is_verified` tinyint(1) NOT NULL default '0',
  `auth_pos` int(10) NOT NULL,
  `client_id` int(11) default NULL,
  `user_id` int(10) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `kolpub_pub_kol_id` (`kol_id`,`pub_id`),
  KEY `FK_kols_publications` (`pub_id`),
  KEY `kolpub_isdel_isver_kol_id` (`is_deleted`,`is_verified`,`kol_id`),
  CONSTRAINT `FK_kols_publications` FOREIGN KEY (`pub_id`) REFERENCES `publications` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `publication_fk_kol_id` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;                                                                        


/*Table structure for table `publication_article_ids` */
 /**
 * @table publication_article_ids
 * @description  Holds publications article id records, one publication can have many 'article ids'
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `publication_article_ids`;
CREATE TABLE `publication_article_ids` (
  `id` int(50) NOT NULL auto_increment,
  `pub_id` int(50) default NULL,
  `pub_article_id` int(50) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_publication_article_ids` (`pub_id`),
  KEY `FK_pubmed_article_ids` (`pub_article_id`),
  CONSTRAINT `FK_publication_article_ids` FOREIGN KEY (`pub_id`) REFERENCES `publications` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_pubmed_article_ids` FOREIGN KEY (`pub_article_id`) REFERENCES `pubmed_article_ids` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `publication_history` */
 /**
 * @table publication_history
 * @description  Holds publications 'history' records, one publication can have many 'history' records
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `publication_history`;
CREATE TABLE `publication_history` (
  `id` int(50) NOT NULL auto_increment,
  `pub_id` int(50) default NULL,
  `status` varchar(50) character set latin1 default NULL,
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  KEY `FK_pubmed_history` (`pub_id`),
  CONSTRAINT `FK_pubmed_history` FOREIGN KEY (`pub_id`) REFERENCES `publications` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*Table structure for table `publication_mesh_terms` */
 /**
 * @table `publication_mesh_terms
 * @description  Holds many to many association between the 'publications' and it's 'mesh terms'
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `publication_mesh_terms`;
CREATE TABLE `publication_mesh_terms` (
  `id` int(50) NOT NULL auto_increment,
  `pub_id` int(50) default NULL,
  `term_id` int(50) default NULL,
  `is_major` tinyint(1) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_publication_mesh_terms` (`pub_id`),
  KEY `FK_pubmed_mesh_terms` (`term_id`),
  CONSTRAINT `FK_publication_mesh_terms` FOREIGN KEY (`pub_id`) REFERENCES `publications` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_pubmed_mesh_terms` FOREIGN KEY (`term_id`) REFERENCES `pubmed_mesh_terms` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `publication_substances` */
 /**
 * @table publication_substances
 * @description Holds many to many association between the 'publications' and it's 'substances'
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `publication_substances`;
CREATE TABLE `publication_substances` (
  `id` int(50) NOT NULL auto_increment,
  `pub_id` int(50) default NULL,
  `substance_id` int(50) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_publication_substances` (`pub_id`),
  KEY `FK_pubmed_substances` (`substance_id`),
  CONSTRAINT `FK_publication_substances` FOREIGN KEY (`pub_id`) REFERENCES `publications` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_pubmed_substances` FOREIGN KEY (`substance_id`) REFERENCES `pubmed_substances` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `publications` */
 /**
 * @table publication_substances
 * @description Holds the 'Publications' master records, it's the core table for publications, which holds the primary details of the publications
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `publications`;
CREATE TABLE `publications` (
  `id` int(50) NOT NULL auto_increment,
  `pmid` int(50) default NULL,
  `pmid_version` int(10) default NULL,
  `created_date` date default NULL,
  `completed_date` date default NULL,
  `revised_date` date default NULL,
  `pub_model` varchar(50) character set latin1 default NULL,
  `issn_number` varchar(50) character set latin1 default NULL,
  `issn_type` varchar(50) character set latin1 default NULL,
  `cited_medium` varchar(50) character set latin1 default NULL,
  `volume` varchar(50) character set latin1 default NULL,
  `journal_id` int(10) default NULL,
  `iso_abbreviation` varchar(100) character set latin1 default NULL,
  `pub_date` date default NULL,
  `article_title` text character set latin1,
  `abstract_text` text character set latin1,
  `pagination` varchar(50) character set latin1 default NULL,
  `affiliation` text character set latin1,
  `auth_list_complete` tinyint(1) default NULL,
  `language` varchar(20) character set latin1 default NULL,
  `article_date` varchar(50) character set latin1 default NULL,
  `citation_subset` varchar(50) character set latin1 default NULL,
  `Num_of_references` varchar(50) character set latin1 default NULL,
  `other_id` int(50) default NULL,
  `status` varchar(25) character set latin1 default NULL,
  `link` text character set latin1,
  `is_deleted` tinyint(1) default NULL,
  `is_manual` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `pmid` (`pmid`),
  KEY `FK_kol_journals_publications` (`journal_id`),
  CONSTRAINT `FK_kol_journals_publications` FOREIGN KEY (`journal_id`) REFERENCES `pubmed_journals` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `publications_authors` */
 /**
 * @table publications_authors
 * @description  Holds many to many association between the 'publications' and it's 'authors'
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `publications_authors`;
CREATE TABLE `publications_authors` (
  `id` int(50) NOT NULL auto_increment,
  `pub_id` int(50) default NULL,
  `author_id` int(50) default NULL,
  `position` int(10) default NULL,
  `alias_id` int(50) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_publications_authors` (`pub_id`),
  KEY `FK_pubmed_authors` (`author_id`),
  CONSTRAINT `FK_publications_authors` FOREIGN KEY (`pub_id`) REFERENCES `publications` (`id`) ON UPDATE NO ACTION,
  CONSTRAINT `FK_pubmed_authors` FOREIGN KEY (`author_id`) REFERENCES `pubmed_authors` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `publications_authors` */
 /**
 * @table publications_authors
 * @description  Holds many to many association between the 'publications' and it's 'corrections corellations'
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `publications_authors`;
CREATE TABLE `publications_cc` (
  `id` int(50) NOT NULL auto_increment,
  `pub_id` int(50) default NULL,
  `cc_id` int(50) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_publications_cc` (`pub_id`),
  KEY `FK_pubmed_cc` (`cc_id`),
  CONSTRAINT `FK_publications_cc` FOREIGN KEY (`pub_id`) REFERENCES `publications` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_pubmed_cc` FOREIGN KEY (`cc_id`) REFERENCES `pubmed_cc` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `publications_types` */
 /**
 * @table publications_types
 * @description  Holds many to many association between the 'publications' and it's 'Publication Types'
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `publications_types`;
CREATE TABLE `publications_types` (
  `id` int(50) NOT NULL auto_increment,
  `pub_id` int(50) default NULL,
  `pub_type_id` int(50) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_publications_types` (`pub_id`),
  KEY `FK_pubmed_types` (`pub_type_id`),
  CONSTRAINT `FK_publications_types` FOREIGN KEY (`pub_id`) REFERENCES `publications` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_pubmed_types` FOREIGN KEY (`pub_type_id`) REFERENCES `pubmed_publications_types` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `pubmed_article_ids` */
 /**
 * @table pubmed_article_ids
 * @description Holds publications 'article ids' master records
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `pubmed_article_ids`;
CREATE TABLE `pubmed_article_ids` (
  `id` int(50) NOT NULL auto_increment,
  `type` varchar(50) character set latin1 default NULL,
  `id_value` varchar(100) character set latin1 default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `pubmed_authors` */
 /**
 * @table pubmed_authors
 * @descriptionHolds publications 'authors' master records, eventhou this is master table it has duplicate records, as the 2 or more authors can have the same name
 * @author 
 * @since 
 * @version 
 * @modified  -
 */
DROP TABLE IF EXISTS `pubmed_authors`;
CREATE TABLE `pubmed_authors` (
  `id` int(50) NOT NULL auto_increment,
  `last_name` varchar(150) character set latin1 default NULL,
  `fore_name` varchar(150) character set latin1 default NULL,
  `initials` varchar(50) character set latin1 default NULL,
  `suffix` varchar(50) character set latin1 default NULL,
  `is_name_valid` tinyint(1) default NULL,
  `alias_id` int(50) default NULL,
  `alias_last_name` varchar(150) character set latin1 default NULL,
  `alias_initials` varchar(50) character set latin1 default NULL,
  `alias_fore_name` varchar(150) character set latin1 default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `pubmed_cc` */
 /**
 * @table pubmed_cc
 * @description  Holds publications 'corrections and correlations' master records
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `pubmed_cc`;
CREATE TABLE `pubmed_cc` (
  `id` int(50) NOT NULL auto_increment,
  `ref_type` varchar(100) character set latin1 default NULL,
  `ref_source` varchar(200) character set latin1 default NULL,
  `cc_pmid` int(50) default NULL,
  `cc_pmid_version` int(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `pubmed_journals` */
 /**
 * @table `pubmed_journals`
 * @description master table, holds the publications 'journal' names
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `pubmed_journals`;
CREATE TABLE `pubmed_journals` (
  `id` int(50) NOT NULL auto_increment,
  `name` varchar(255) character set utf8 collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

/*Table structure for table `pubmed_mesh_terms` */
 /**
 * @table `pubmed_mesh_terms`
 * @description  master table, holds the publications 'mesh terms'
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `pubmed_mesh_terms`;
CREATE TABLE `pubmed_mesh_terms` (
  `id` int(50) NOT NULL auto_increment,
  `term_name` varchar(255) character set latin1 default NULL,
  `parent_id` int(50) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_parent_mesh_terms` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `pubmed_publications_types` */
 /**
 * @table `pubmed_publications_types`
 * @description  master table, holds the publications 'publications types' names
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `pubmed_publications_types`;
CREATE TABLE `pubmed_publications_types` (
  `id` int(50) NOT NULL auto_increment,
  `type` varchar(50) character set latin1 default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `pubmed_substances` */
 /**
 * @table `pubmed_substances`
 * @description master table, holds the publications 'substances'
 * @author 
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `pubmed_substances`;
CREATE TABLE `pubmed_substances` (
  `id` int(50) NOT NULL auto_increment,
  `reg_num` varchar(100) character set latin1 default NULL,
  `name` varchar(255) character set latin1 default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
      

/*Table structure for table `clinical_trials` */
 /**
 * @table `clinical_trials`
 * @description  This is the master Table holds all "Clinical Trials table"
 * @author Ramesh
 * @since 
 * @version 
 * @modified  -
 */

DROP TABLE IF EXISTS `clinical_trials`;
CREATE TABLE `clinical_trials` (
  `id` int(50) NOT NULL auto_increment,
  `trial_name` text character set latin1,
  `status_id` int(10) default NULL,
  `ct_id` varchar(50) character set latin1 default NULL,
  `purpose` text character set latin1,
  `condition` varchar(100) character set latin1 default NULL,
  `phase` varchar(100) character set latin1 default NULL,
  `official_title` text character set latin1,
  `study_type` varchar(100) character set latin1 default NULL,
  `start_date` varchar(25) character set latin1 default NULL,
  `end_date` varchar(25) character set latin1 default NULL,
  `link` text character set latin1,
  `is_manual` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `FK_clinical_trials` (`status_id`),
  CONSTRAINT `FK_clinical_trials` FOREIGN KEY (`status_id`) REFERENCES `cts_statuses` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `ct_interventions` */
 /**
 * @table `ct_interventions`
 * @description- table Holds many to one association with "cts_interventions".
 * @author -	Ramesh
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `ct_interventions`;
CREATE TABLE `ct_interventions` (
  `id` int(50) NOT NULL auto_increment,
  `cts_id` int(50) default NULL,
  `intervention_id` int(50) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_ct_ interventions` (`cts_id`),
  KEY `FK_cts_ interventions` (`intervention_id`),
  CONSTRAINT `FK_cts_ interventions` FOREIGN KEY (`intervention_id`) REFERENCES `cts_interventions` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_ct_ interventions` FOREIGN KEY (`cts_id`) REFERENCES `clinical_trials` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `ct_keywords` */
 /**
 * @table `ct_keywords`
 * @description-  table Holds many to one association with "cts_keywords".
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */
DROP TABLE IF EXISTS `ct_keywords`;
CREATE TABLE `ct_keywords` (
  `id` int(50) NOT NULL auto_increment,
  `cts_id` int(50) default NULL,
  `keyword_id` int(50) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_cts_ keywords` (`keyword_id`),
  KEY `FK_ct_ keywords` (`cts_id`),
  CONSTRAINT `FK_cts_ keywords` FOREIGN KEY (`keyword_id`) REFERENCES `cts_keywords` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_ct_ keywords` FOREIGN KEY (`cts_id`) REFERENCES `clinical_trials` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `ct_mesh_terms` */
 /**
 * @table `ct_mesh_terms`
 * @description-  table Holds many to one association with "cts_mesh_terms"
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `ct_mesh_terms`;
CREATE TABLE `ct_mesh_terms` (
  `id` int(50) NOT NULL auto_increment,
  `cts_id` int(50) default NULL,
  `term_id` int(50) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_ct_mesh_terms` (`cts_id`),
  KEY `FK_cts_mesh_terms` (`term_id`),
  CONSTRAINT `FK_cts_mesh_terms` FOREIGN KEY (`term_id`) REFERENCES `cts_mesh_terms` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_ct_mesh_terms` FOREIGN KEY (`cts_id`) REFERENCES `clinical_trials` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `ct_sponsers` */
 /**
 * @table `ct_sponsers`
 * @description- table Holds many to one association with "cts_sponsers"
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `ct_sponsers`;
CREATE TABLE `ct_sponsers` (
  `id` int(50) NOT NULL auto_increment,
  `cts_id` int(50) default NULL,
  `sponser_id` int(50) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_ct_sponsers` (`cts_id`),
  KEY `FK_cts_sponsers` (`sponser_id`),
  CONSTRAINT `FK_cts_sponsers` FOREIGN KEY (`sponser_id`) REFERENCES `cts_sponsers` (`id`) ON UPDATE NO ACTION,
  CONSTRAINT `FK_ct_sponsers` FOREIGN KEY (`cts_id`) REFERENCES `clinical_trials` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `cts_interventions` */
 /**
 * @table `cts_interventions`
 * @description- This is master table Holds :"Clinical trials interventions" details
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */
DROP TABLE IF EXISTS `cts_interventions`;
CREATE TABLE `cts_interventions` (
  `id` int(50) NOT NULL auto_increment,
  `type` varchar(50) character set latin1 default NULL,
  `name` varchar(255) character set latin1 default NULL,
  `description` varchar(255) character set latin1 default NULL,
  `arm_group_label` varchar(50) character set latin1 default NULL,
  `other_name` varchar(100) character set latin1 default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*Table structure for table `cts_keywords` */
 /**
 * @table `cts_keywords`
 * @description-  This is master table Holds :"Clinical trials keywords" details
 * @author -	Ramesh
 * @since -
 * @version- 
 * @modified  -
 */
DROP TABLE IF EXISTS `cts_keywords`;
CREATE TABLE `cts_keywords` (
  `id` int(50) NOT NULL auto_increment,
  `name` varchar(100) character set latin1 default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*Table structure for table `cts_mesh_terms` */
 /**
 * @table `cts_mesh_terms`
 * @description- This is master table Holds :"Clinical trials meshterms" details
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `cts_mesh_terms`;
CREATE TABLE `cts_mesh_terms` (
  `id` int(50) NOT NULL auto_increment,
  `type` varchar(100) character set latin1 default NULL,
  `term_name` varchar(100) character set latin1 default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `cts_sponsers` */
 /**
 * @table `cts_sponsers`
 * @description- This is master table Holds clinical_trials sponsers details
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `cts_sponsers`;
CREATE TABLE `cts_sponsers` (
  `id` int(50) NOT NULL auto_increment,
  `type` varchar(25) character set latin1 default NULL,
  `agency` varchar(100) character set latin1 default NULL,
  `agency_class` varchar(100) character set latin1 default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `cts_statuses` */
 /**
 * @table `cts_statuses`
 * @description-  Holds clinical_trials statuses details
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `cts_statuses`;
CREATE TABLE `cts_statuses` (
  `id` int(10) NOT NULL auto_increment,
  `status` varchar(100) character set latin1 default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `kol_clinical_trials` */
 /**
 * @table `kol_clinical_trials`
 * @description-  Holds many to amny association between KOLS and clinical_trials table
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `kol_clinical_trials`;
CREATE TABLE `kol_clinical_trials` (
  `id` int(50) NOT NULL auto_increment,
  `kol_id` int(11) default NULL,
  `cts_id` int(50) default NULL,
  `client_id` int(11) default NULL,
  `user_id` int(10) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_kol_clinical_trials` (`cts_id`),
  CONSTRAINT `FK_kol_clinical_trials` FOREIGN KEY (`cts_id`) REFERENCES `clinical_trials` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*Table structure for table `cts_investigators` */
 /**
 * @table `cts_investigators`
 * @description- This is the Master Table holds "Clincal trials investigators " details .
 * @author -	Ramesh
 * @since -
 * @version- 
 * @modified  -
 */
DROP TABLE IF EXISTS `cts_investigators`;
CREATE TABLE `cts_investigators` (
  `id` int(50) NOT NULL auto_increment,
  `last_name` varchar(150) character set latin1 default NULL,
  `role` varchar(50) character set latin1 default NULL,
  `affiliation` text character set latin1,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `ct_investigators` */
 /**
 * @table access_objects
 * @description- holds "Clincal investigators Id" and refers to "cts_investigators" table which is the master table.
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `cts_investigators`;
CREATE TABLE `ct_investigators` (
  `id` int(50) NOT NULL auto_increment,
  `cts_id` int(50) default NULL,
  `investigator_id` int(50) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_ct_investigators` (`cts_id`),
  KEY `FK_cts_investigators` (`investigator_id`),
  CONSTRAINT `FK_cts_investigators` FOREIGN KEY (`investigator_id`) REFERENCES `cts_investigators` (`id`) ON UPDATE NO ACTION,
  CONSTRAINT `FK_ct_investigators` FOREIGN KEY (`cts_id`) REFERENCES `clinical_trials` (`id`) ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `key_people_roles` */
 /**
 * @table `key_people_roles`
 * @description-  holds "key_people_roles" details.
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `key_people_roles`;
CREATE TABLE `key_people_roles` (
  `id` int(50) NOT NULL auto_increment,
  `role` varchar(150) character set latin1 NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `key_peoples` */
 /**
 * @table `key_peoples`
 * @description-   holds "key_peoples" Details where 1 Organizations has many Key Peoples
 * @author -	Ramesh
 * @since -
 * @version- 
 * @modified  -
 */


DROP TABLE IF EXISTS `key_peoples`;
CREATE TABLE `key_peoples` (
  `id` int(50) NOT NULL auto_increment,
  `org_id` int(50) NOT NULL,
  `role_id` int(50) NOT NULL,
  `salutation` tinyint(3) NOT NULL,
  `first_name` varchar(250) character set latin1 default NULL,
  `middle_name` varchar(100) character set latin1 default NULL,
  `last_name` varchar(250) character set latin1 default NULL,
  `title` varchar(250) character set latin1 default NULL,
  `email` varchar(250) character set latin1 default NULL,
  `created_by` varchar(40) character set latin1 NOT NULL,
  `created_on` datetime NOT NULL,
  `modified_by` varchar(40) character set latin1 default NULL,
  `modified_on` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `keypeople_fk_org_id` (`org_id`),
  CONSTRAINT `keypeople_fk_org_id` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*Table structure for table `org_additional_contacts` */
 /**
 * @table `org_additional_contacts`
 * @description-  holds "org_additional_contacts" Details where 1 Organizations has many Additional Cotacts
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `org_additional_contacts`;
CREATE TABLE `org_additional_contacts` (
  `id` int(11) NOT NULL auto_increment,
  `org_id` int(11) default NULL,
  `related_to` varchar(250) character set latin1 default NULL,
  `phone` varchar(15) character set latin1 default NULL,
  `email` varchar(150) character set latin1 default NULL,
  `created_by` varchar(40) character set latin1 NOT NULL,
  `created_on` datetime NOT NULL,
  `modified_by` varchar(40) character set latin1 default NULL,
  `modified_on` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `organization_types` */
 /**
 * @table `organization_types`
 * @description-  This is master Table holds "organizations Types" Details.
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `organization_types`;
CREATE TABLE `organization_types` (
  `id` int(50) NOT NULL auto_increment,
  `type` varchar(250) character set latin1 NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `organizations` */
 /**
 * @table `organizations`
 * @description- this is the Master table holds "organizations" Details.
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */


DROP TABLE IF EXISTS `organizations`;
CREATE TABLE `organizations` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(150) default NULL,
  `type_id` int(50) NOT NULL,
  `company_logo` varchar(255) NOT NULL,
  `founded` varchar(50) default NULL,
  `background` mediumtext,
  `mission_vision` mediumtext,
  `products_services` mediumtext,
  `headquarters` mediumtext,
  `website` mediumtext,
  `address` varchar(255) default NULL,
  `phone` varchar(15) default NULL,
  `fax` varchar(20) default NULL,
  `city_id` int(5) default NULL,
  `state_id` int(5) default NULL,
  `country_id` int(5) default NULL,
  `postal_code` varchar(15) default NULL,
  `blog` mediumtext,
  `facebook` mediumtext,
  `twitter` mediumtext,
  `youtube` mediumtext,
  `linkedin` mediumtext,
  `created_by` varchar(40) default NULL,
  `created_on` datetime default NULL,
  `modified_by` varchar(40) default NULL,
  `modified_on` datetime default NULL,
  `cin_num` varchar(50) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `client_users` */
 /**
 * @table `client_users`
 * @description- this is the Master table holds "Usres" Details for Paricular Client
 * @author -Vinayak
 * @since -
 * @version- 
 * @modified  - 9-5-2012 added column mic_pic
 */

DROP TABLE IF EXISTS `client_users`;
CREATE TABLE `client_users` (
  `id` int(11) NOT NULL auto_increment,
  `client_id` int(11) default NULL,
  `user_name` varchar(255) character set latin1 default NULL,
  `password` varchar(255) character set latin1 default NULL,
  `email` varchar(255) character set latin1 default NULL,
  `contact` varchar(255) character set latin1 default NULL,
  `is_analyst` tinyint(11) default '0',
  `user_role_id` int(11) default '1',
  `user_last_login` datetime default NULL,
  `created_by` varchar(40) character set latin1 default NULL,
  `created_on` datetime default NULL,
  `modified_by` varchar(40) character set latin1 default NULL,
  `modified_on` datetime default NULL,
  `first_name` varchar(250) character set latin1 NOT NULL,
  `last_name` varchar(250) character set latin1 NOT NULL,
  `title` varchar(250) character set latin1 NOT NULL,
  `company_name` varchar(250) character set latin1 NOT NULL,
  `phone` varchar(250) character set latin1 NOT NULL,
  `mem_pic` varchar(200) DEFAULT NULL,
  `country` int(11) NOT NULL,
  `manager_id` int(11) default NULL,
  `territory` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `user_name_uk` (`client_id`,`user_name`),
  KEY `FK_manager_id` (`manager_id`),
  CONSTRAINT `FK_manager_id` FOREIGN KEY (`manager_id`) REFERENCES `client_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;    



/*Table structure for table `clients` */
 /**
 * @table `clients`
 * @description- 
 * @author -Vinayak
 * @since -
 * @version- 
 * @modified  -this is the Master table holds "clients" Details 

 */
DROP TABLE IF EXISTS `clients`;
CREATE TABLE `clients` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `notes` varchar(255) default NULL,
  `created_by` int(11) default NULL,
  `created_on` datetime default NULL,
  `modified_by` varchar(40) default NULL,
  `modified_on` datetime default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name_uk` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*Table structure for table `interactions` */
 /**
 * @table `interactions`
 * @description- this is the Master table holds "Interactions" Details for particular Cilent and Kol.
 * @author -	Ramesh
 * @since -
 * @version- 
 * @modified  -modified on 12 Apr 2012 by Ramesh B - changed the column name 'time' to 'fromtime' and added a new column 'totime'
 */


DROP TABLE IF EXISTS `interactions`;
CREATE TABLE `interactions` (
  `id` int(50) NOT NULL auto_increment,
  `client_id` int(50) default NULL,
  `kol_id` int(11) NOT NULL,
  `date` date default NULL,
  `fromtime` time default NULL,
  `mode` int(50) default NULL,
  `location` varchar(250) character set latin1 default NULL,
  `topic` int(50) default NULL,
  `brand` int(50) default NULL,
  `role` int(50) default NULL,
  `follow_up_on` date default NULL,
  `reminder` tinyint(1) default NULL,
  `category` int(50) default NULL,
  `notes` text character set latin1,
  `therapeutic_area` int(50) default NULL,
  `created_by` int(50) NOT NULL,
  `created_on` date NOT NULL,
  `modified_by` int(50) NOT NULL,
  `modified_on` date NOT NULL,
  `calendar_event_id` int(10) default '0',
  `objective_id` int(10) default NULL,
  `totime` time default NULL,
  PRIMARY KEY  (`id`),
  KEY `interaction_fk_kol_id` (`kol_id`),
  CONSTRAINT `interaction_fk_kol_id` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `interaction_docs` */
 /**
 * @table `interaction_docs`
 * @description- this table holds "interaction_documents" Details for particular Cilent.
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `interaction_docs`;
CREATE TABLE `interaction_docs` (
  `id` int(50) NOT NULL auto_increment,
  `interaction_id` int(50) default NULL,
  `name` varchar(250) character set latin1 default NULL,
  `description` text character set latin1,
  `doc_path` text character set latin1,
  `created_by` int(50) default NULL,
  `created_on` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*Table structure for table `interactions_brands` */
 /**
 * @table `interactions_brands`
 * @description- this table holds "interactions_brands" Details for particular Cilent.
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `interactions_brands`;
CREATE TABLE `interactions_brands` (
  `id` int(50) NOT NULL auto_increment,
  `name` varchar(150) character set latin1 default NULL,
  `client_id` int(50) default NULL,
  `created_by` int(50) default NULL,
  `Created_on` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `interactions_categories` */

##----------------------------
##-- interactions_categories table
##-  @author 	Ramesh
## - Since 
## - 
## - @description  -this table holds "interactions_categories" Details for particular Cilent.


/*Table structure for table `interactions_categories` */
 /**
 * @table `interactions_categories`
 * @description- -this table holds "interactions_categories" Details for particular Cilent.
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -

 */


DROP TABLE IF EXISTS `interactions_categories`;
CREATE TABLE `interactions_categories` (
  `id` int(50) NOT NULL auto_increment,
  `name` varchar(150) character set latin1 default NULL,
  `client_id` int(50) default NULL,
  `created_by` int(50) default NULL,
  `Created_on` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `interactions_modes` */
 /**
 * @table `interactions_modes`
 * @description- this table holds "interactions_modes" Details for particular Cilent.
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `interactions_modes`;
CREATE TABLE `interactions_modes` (
  `id` int(50) NOT NULL auto_increment,
  `name` varchar(150) character set latin1 default NULL,
  `client_id` int(50) default NULL,
  `created_by` int(50) default NULL,
  `Created_on` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*Table structure for table `interactions_roles` */
 /**
 * @table `interactions_roles`
 * @description- this table holds "interactions_roles" Details for particular Cilent.
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `interactions_roles`;
CREATE TABLE `interactions_roles` (
  `id` int(50) NOT NULL auto_increment,
  `name` varchar(150) character set latin1 default NULL,
  `client_id` int(50) default NULL,
  `created_by` int(50) default NULL,
  `Created_on` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




/*Table structure for table `interactions_topics` */
 /**
 * @table `interactions_topics`
 * @description- this table holds "interactions_topics" Details for particular Cilent.
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */
DROP TABLE IF EXISTS `interactions_topics`;
CREATE TABLE `interactions_topics` (
  `id` INT(50) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(150) DEFAULT NULL,
  `client_id` INT(50) DEFAULT NULL,
  `created_by` INT(50) DEFAULT NULL,
  `Created_on` DATE DEFAULT NULL,
  `modified_by` INT(12) DEFAULT NULL,
  `modified_on` DATE DEFAULT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `unique_client_topic` (`name`, `client_id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;


/*Table structure for table `interactions_therapeutic_areas` */
 /**
 * @table `interactions_therapeutic_areas`
 * @description- this table holds interactions_therapeutic_area Details for particular Cilent.
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */
DROP TABLE IF EXISTS `interactions_therapeutic_areas`;
CREATE TABLE `interactions_therapeutic_areas` (
  `id` int(50) NOT NULL auto_increment,
  `name` varchar(150) character set latin1 default NULL,
  `client_id` int(50) default NULL,
  `created_by` int(50) default NULL,
  `Created_on` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*Table structure for table `payment_types` */
 /**
 * @table `payment_types`
 * @description- this table holds type of Payement Details for particular Cilent.
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */
DROP TABLE IF EXISTS `payment_types`;
CREATE TABLE `payment_types` (
  `id` int(11) NOT NULL auto_increment,
  `client_id` int(11) NOT NULL,
  `name` varchar(255) character set latin1 default NULL,
  `notes` varchar(255) character set latin1 default NULL,
  `created_by` varchar(50) character set latin1 default NULL,
  `created_on` datetime default NULL,
  `modified_by` varchar(50) character set latin1 default NULL,
  `modified_on` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*Table structure for table `payments` */
 /**
 * @table `payments`
 * @description- This is master table holds Kol Payement Details for particular Cilent.
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL auto_increment,
  `kol_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `reason` varchar(255) character set latin1 default NULL,
  `payment` decimal(10,2) default NULL,
  `rate` decimal(10,2) default NULL,
  `duration` time NOT NULL,
  `interaction_id` int(11) NOT NULL,
  `created_by` varchar(50) character set latin1 default NULL,
  `created_on` datetime default NULL,
  `modified_by` varchar(50) character set latin1 default NULL,
  `modified_on` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `payments_fk_kol_id` (`kol_id`),
  CONSTRAINT `payments_fk_kol_id` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;    


/*Table structure for table `payment_threshholds` */
 /**
 * @table `payment_threshholds`
 * @description- This table holds Payement threshhold rate Details  for assigned KOl
 * @author -Ramesh
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `payment_threshholds`;
CREATE TABLE `payment_threshholds` (
  `id` int(11) NOT NULL auto_increment,
  `kol_id` int(11) NOT NULL,
  `threshhold_rate` decimal(10,2) default NULL,
  `created_by` varchar(50) character set latin1 default NULL,
  `created_on` datetime default NULL,
  `modified_by` varchar(50) character set latin1 default NULL,
  `modified_on` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `payment_threshholds_fk_kol_id` (`kol_id`),
  CONSTRAINT `payment_threshholds_fk_kol_id` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8; 




/*Table structure for table `clients_kols` */
 /**
 * @table `clients_kols`
 * @description- This table holds Kols associated to Particular Client 
 * @author -Vinayak
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `clients_kols`;
CREATE TABLE `clients_kols` (
  `id` int(11) NOT NULL auto_increment,
  `kol_id` int(11) NOT NULL,
  `client_id` varchar(40) character set latin1 NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_kol_id` (`kol_id`),
  CONSTRAINT `fk_kol_id` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;                                                             

/*Table structure for table `list_categories` */
 /**
 * @table list_categories
 * @description- This table holds Categories associated to Particular User 
 * @author -Vinayak
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `list_categories`;
CREATE TABLE `list_categories` (
  `id` int(11) NOT NULL auto_increment,
  `category` varchar(255) character set latin1 default NULL,
  `user_id` int(11) default NULL,
  `client_id` int(11) default NULL,
  `is_public` int(11) default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `category_uk` (`category`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
   

/*Table structure for table `list_kols` */
 /**
 * @table list_kols
 * @description- This table holds Kol_id associated to Particular user and list name
 * @author -Vinayak
 * @since -
 * @version- 
 * @modified  -
 */


DROP TABLE IF EXISTS `list_kols`;
CREATE TABLE `list_kols` (
  `id` int(11) NOT NULL auto_increment,
  `list_name_id` int(11) default NULL,
  `kol_id` int(11) NOT NULL,
  `user_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `list_name_id_uk` (`list_name_id`,`kol_id`),
  KEY `list_kols_fk_kol_id` (`kol_id`),
  CONSTRAINT `list_kols_fk_kol_id` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;  



/*Table structure for table `list_names` */
 /**
 * @table list_names
 * @description- This table holds all The List Names associated to Particular User and category
 * @author -Vinayak
 * @since -
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `list_names`;
CREATE TABLE `list_names` (
  `id` int(11) NOT NULL auto_increment,
  `list_name` varchar(255) character set latin1 default NULL,
  `category_id` int(11) default NULL,
  `user_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `list_name_uk` (`list_name`,`category_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;   


/*Table structure for table `kol_personal_info` */
 /**
 * @table kol_personal_info
 * @description- This table holds all kols personal info, separate record for each client
 * @author -Ramesh B
 * @since -05-05-2011
 * @version- 2.2
 * @modified  -
 */


DROP TABLE IF EXISTS `kol_personal_info`;
CREATE TABLE `kol_personal_info` (
  `id` int(15) NOT NULL auto_increment,
  `kol_id` int(11) NOT NULL,
  `client_id` int(15) default NULL,
  `gender` varchar(6) character set latin1 default NULL,
  `home_town` varbinary(250) default NULL,
  `birthday` date default NULL,
  `languages` varchar(250) character set latin1 default NULL,
  `spouse_name` varchar(250) character set latin1 default NULL,
  `anniversary` date default NULL,
  `children` varchar(250) character set latin1 default NULL,
  `pets` varchar(250) character set latin1 default NULL,
  `home_phone` varchar(250) character set latin1 default NULL,
  `cell_phone` varchar(250) character set latin1 default NULL,
  `IM_screen_name1` varchar(250) character set latin1 default NULL,
  `IM_screen_name2` varchar(250) character set latin1 default NULL,
  `special_interests` varchar(250) character set latin1 default NULL,
  `music` varchar(250) character set latin1 default NULL,
  `books` varchar(250) character set latin1 default NULL,
  `journals` varbinary(250) default NULL,
  `sports` varchar(250) character set latin1 default NULL,
  `activities` varchar(250) character set latin1 default NULL,
  `vacation` varchar(250) character set latin1 default NULL,
  `magazines` varchar(250) character set latin1 default NULL,
  `created_by` int(15) default NULL,
  `created_date` date default NULL,
  `modified_by` int(15) default NULL,
  `modified_date` date default NULL,
  `birthday_event_id` int(10) default '0',
  `anniversary_event_id` int(10) default '0',
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `NewIndex1` (`kol_id`,`client_id`),
  CONSTRAINT `personlainfo_fk_kol_id` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `personal_info_docs` */
 /**
 * @table personal_info_doc
 * @description- This table holds documents belongs to pertiular kol personal info 
 * @author -Ramesh B
 * @since -05-05-2011
 * @version- 2.2
 * @modified  -
 */


DROP TABLE IF EXISTS `personal_info_docs`;
CREATE TABLE `personal_info_docs` (
  `id` int(50) NOT NULL auto_increment,
  `personal_info_id` int(50) default NULL,
  `doc_name` varchar(250) character set latin1 default NULL,
  `description` text character set latin1,
  `doc_path` text character set latin1,
  `created_by` int(50) default NULL,
  `created_on` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `calendar_events` */
 /**
 * @table calendar_events
 * @description- This table holds clint user calendar events
 * @author -Ramesh B
 * @since 13-05-2011
 * @version- 2.3
 * @modified  -
 */

DROP TABLE IF EXISTS `calendar_events`;
CREATE TABLE `calendar_events` (
  `Id` int(10) NOT NULL auto_increment,
  `Subject` varchar(1000) default NULL,
  `Location` varchar(200) default NULL,
  `Description` varchar(255) default NULL,
  `StartTime` datetime default NULL,
  `EndTime` datetime default NULL,
  `IsAllDayEvent` smallint(6) NOT NULL,
  `Color` varchar(200) default NULL,
  `RecurringRule` varchar(500) default NULL,
  `client_id` int(11) default NULL,
  `created_by` int(11) default NULL,
  `created_on` datetime default NULL,
  `modified_by` int(11) default NULL,
  `Modified_on` datetime default NULL,
  `event_type` varchar(50) character set latin1 default 'EVENT_TYPE_GENERAL',
  PRIMARY KEY  (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/*Table structure for table `event_topics` */
 /**
 * @table event_topics
 * @description- This table holds topics belogs to each specialty
 * @author -Ramesh B
 * @since 01-07-2011
 * @version- 2.5
 * @modified  -
 */

DROP TABLE IF EXISTS `event_topics`;
CREATE TABLE `event_topics` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(255) character set latin1 default NULL,
  `specialty_id` int(10) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_event_specialty_topic` (`specialty_id`),
  CONSTRAINT `FK_event_specialty_topic` FOREIGN KEY (`specialty_id`) REFERENCES `specialties` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `users_analytics` */
 /**
 * @table users_analytics
 * @description- This table holds users alanytics data like login and logout time
 * @author -Ramesh B
 * @since 16-08-2011
 * @version- 3.0
 * @modified Apr 20, 2012 by Ramesh B - Added a another column 'is_login_failed'
 */

DROP TABLE IF EXISTS `users_analytics`;
CREATE TABLE `users_analytics` (
  `id` int(10) NOT NULL auto_increment,
  `user_id` int(10) NOT NULL,
  `login_time` datetime default NULL,
  `logout_time` datetime default NULL,
  `is_login_failed` tinyint(1) default '0',
  PRIMARY KEY  (`id`),
  KEY `FK_user_id` (`user_id`),
  CONSTRAINT `FK_user_id` FOREIGN KEY (`user_id`) REFERENCES `client_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `objectives` */
 /**
 * @table objectives
 * @description- This table holds Plans obejctives
 * @author -Vinayak
 * @since 10-09-2011
 * @version- 3.1
 * @modified  -
 */

DROP TABLE IF EXISTS `objectives`;
CREATE TABLE `objectives` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) character set latin1 default NULL,
  `description` text character set latin1,
  `client_id` int(11) default NULL,
  `created_by` varchar(40) character set latin1 default NULL,
  `created_on` date default NULL,
  `modified_by` varchar(40) character set latin1 default NULL,
  `modified_on` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;     


/*Table structure for table `plans` */
 /**
 * @table plans
 * @description- This table holds plans details related to 'Users','Kols','Objects'
 * @author -Vinayak
 * @since 10-09-2011
 * @version- 3.1
 * @modified  -
 */

DROP TABLE IF EXISTS `plans`;
CREATE TABLE `plans` (
  `id` int(10) NOT NULL auto_increment,
  `objective_id` int(10) NOT NULL,
  `user_id` int(10) default NULL,
  `kol_id` int(11) default NULL,
  `targets` int(10) default NULL,
  `plan_date` date default NULL,
  `client_id` int(10) default NULL,
  `created_by` int(10) NOT NULL,
  `created_on` datetime default NULL,
  `modified_by` int(11) default NULL,
  `modified_on` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8; 


/*Table structure for table `client_events` */
 /**
 * @table client_events
 * @description- Table to store monthly events report of respective clients
 * @author -Laxman K
 * @since 
 * @version- 3.4
 * @modified  -
 */

DROP TABLE IF EXISTS `client_events`;
CREATE TABLE `client_events` (
  `id` int(11) NOT NULL auto_increment,
  `client_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `region_country` varchar(255) default NULL,
  `event_date` date default NULL,
  `presenter` varchar(255) default NULL,
  `meeting_type` varchar(255) default NULL,
  `no_of_attendees` int(11) default NULL,
  `events_month_year` varchar(255) default NULL,
  `topics` varchar(255) default NULL,
  `feedback` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_eventclient_id` (`client_id`),
  KEY `fk_eventuser_id` (`user_id`),
  CONSTRAINT `fk_eventclient_id` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_eventuser_id` FOREIGN KEY (`user_id`) REFERENCES `client_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8; 

/*Table structure for table `contracts` */
 /**
 * @table contracts
 * @description- Table to store Contract detalis;
 * @author -vinayak
 * @since 
 * @version- 3.4
 * @modified  -
 */

DROP TABLE IF EXISTS `contracts`;
CREATE TABLE `contracts` (
  `id` int(11) NOT NULL auto_increment,
  `contract_name` varchar(255) default NULL,
  `kol_name` varchar(255) default NULL,
  `start_date` date default NULL,
  `end_date` date default NULL,
  `contract_description` text,
  `contract_file` text,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8; 


/*Table structure for table `contracts` */
 /**
 * @table contracts
 * @description- holds the Permissoion Related data.
 * @author -vinayak
 * @since 
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `access_permissions`;
CREATE TABLE `access_permissions` (         
  `id` int(11) NOT NULL auto_increment,     
  `access_object_id` int(11) default NULL,  
  `role_id` int(11) default NULL,           
  `is_allowed` int(11) default '0',         
  PRIMARY KEY  (`id`)                       
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8; 

/*Table structure for table `access_objects` */
 /**
 * @table access_objects
 * @description- Holds the all 'Controler Name' and 'Method Name' used in Application
 * @author -vinayak
 * @since 
 * @version- 
 * @modified  -
 */

DROP TABLE IF EXISTS `access_objects`;
CREATE TABLE `access_objects` (                       
                  `id` int(11) NOT NULL auto_increment,               
                  `controller` varchar(255) default NULL,             
                  `method` varchar(255) default NULL,                 
                  `alias` varchar(255) default NULL,                  
                  `desc` varchar(255) default NULL,                   
                  `category` varchar(255) default NULL,               
                  `sub_app` varchar(255) default NULL,                
                  `parent` varchar(255) default NULL,                 
                  PRIMARY KEY  (`id`),                                
                  UNIQUE KEY `controller_ck` (`controller`,`method`)  
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `id_analysis` */
 /**
 * @table id_analysis
 * @description- 
 * @author -Laxman K
 * @since 
 * @version-3.8 
 * @modified  -
 */

DROP TABLE IF EXISTS `id_analysis`;

CREATE TABLE `id_analysis` (
  `id` int(11) NOT NULL auto_increment,
  `project_id` int(11) default '0',
  `query_id` int(11) default '0',
  `author_id` int(11) default '0',
  `pmid` int(11) default '0',
  `auth_count` int(11) default '0',
  `pubs_count` int(11) default '0',
  PRIMARY KEY  (`id`),
  KEY `FK_id_analysis_input_query` (`author_id`),
  KEY `FK_id_analysis_authors` (`query_id`),
  KEY `FK_id_analysis_pubsprocessed` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `id_processed_pubs` */
 /**
 * @table id_processed_pubs
 * @description- Table structure for table id_processed_pubs
 * @author -Laxman K
 * @since 
 * @version-
 * @modified  -
 */

DROP TABLE IF EXISTS `id_processed_pubs`;

CREATE TABLE `id_processed_pubs` (
  `unique_pmid` int(11) NOT NULL,
  `is_processed` tinyint(1) default '0',
  PRIMARY KEY  (`unique_pmid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `id_project` */
 /**
 * @table `id_project`
 * @description- Table structure for table id_project
 * @author -Laxman K
 * @since 
 * @version-
 * @modified  -
 */

DROP TABLE IF EXISTS `id_project`;

CREATE TABLE `id_project` (
  `id` int(11) NOT NULL auto_increment,
  `project_name` varchar(255) default NULL,
  `created_on` datetime default NULL,
  `created_by` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*Table structure for table `id_project_inputs` */
 /**
 * @table id_project_inputs
 * @description- Table structure for table id_project_inputs
 * @author -Laxman K
 * @since 
 * @version-
 * @modified  -
 */

DROP TABLE IF EXISTS `id_project_inputs`;

CREATE TABLE `id_project_inputs` (
  `id` int(11) NOT NULL auto_increment,
  `project_id` int(11) NOT NULL,
  `input_query` varchar(255) default NULL,
  `total_pmids` int(11) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `id_unique_authors` */
 /**
 * @table id_unique_authors
 * @description- Table to store Unique Authors.
 * @author -Laxman K
 * @since 
 * @version-
 * @modified  -
 */

DROP TABLE IF EXISTS `id_unique_authors`;

CREATE TABLE `id_unique_authors` (
  `id` int(11) NOT NULL auto_increment,
  `last_name` varchar(255) default NULL,
  `fore_name` varchar(255) default NULL,
  `initials` varchar(255) default NULL,
  `is_profiled` tinyint(1) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table  */
 /**
 * @table 
 * @description- Table to Store User_roles(Ex:Admin)
 * @author -vinayak
 * @since 
 * @version-
 * @modified  -
 */

CREATE TABLE `user_roles` (              
              `id` int(11) NOT NULL auto_increment,  
              `role` varchar(255) default NULL,      
              PRIMARY KEY  (`id`),                   
              UNIQUE KEY `role_UK` (`role`)          
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8;  
            
/*Table structure for table `id_project_name_combinations` */
 /**
 * @table id_project_name_combinations
 * @description- Table for ID project  which stores author name combinations 
 * @author -Laxman K
 * @since 06 March 2012
 * @version-3.7
 * @modified  -
 */

CREATE TABLE `id_project_name_combinations` (  
            `id` int(11) NOT NULL auto_increment,        
            `project_id` int(11) default NULL,           
            `input_query_id` int(11) default NULL,       
            `combination` varchar(255) default NULL,     
            `pubs_count` int(11) default '0',            
            PRIMARY KEY  (`id`)                          
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8; 
          


 /**
 * @table kol_activities_count
 * @description - Table for kol_activities_count project  which stores kols avtivites count
 * @author - Vinayak
 * @since  - 05 May 2012
 * @version 3.10
 */
DROP TABLE IF EXISTS `kol_activities_count`;
 CREATE TABLE `kol_activities_count` (             
    `id` int(11) NOT NULL auto_increment,           
    `kol_id` int(11) default NULL,                  
    `affCount` int(11) default NULL,                
    `pubsCount` int(11) default NULL,               
    `eventsCount` int(11) default NULL,             
    `totalScore` int(11) default NULL,              
    `practiseCount` int(11) default NULL,           
    `teachingCount` int(11) default NULL,           
    `socialComitteCount` int(11) default NULL,      
    `socialBoardCount` int(11) default NULL,        
    `guidelineCount` int(11) default NULL,          
    `governmentCount` int(11) default NULL,         
    `totalProfessionalCount` int(11) default NULL,  
    `executiveCount` int(11) default NULL,          
    `speakingCount` int(11) default NULL,           
    `facultyCount` int(11) default NULL,            
    `panelistCount` int(11) default NULL,           
    `totalEvents` int(11) default NULL,             
    `authPosCount` int(11) default NULL,            
    `trialCount` int(11) default NULL,              
    `totalResearch` int(11) default NULL,           
    `totalAllScore` int(11) default NULL,           
    PRIMARY KEY  (`id`)                             
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;                 
  
  
/*Table structure for table `wallcomments` */
 /**
 * @table wallcomments
 * @description - wallcomments
 * @author - Vinayak
 * @since  - 05 May 2012
 * @version 3.10
 */
DROP TABLE IF EXISTS `wallcomments`;

CREATE TABLE `wallcomments` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `comments` text NOT NULL,
  `date_created` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `clikes` int(11) NOT NULL,
  `uip` varchar(222) NOT NULL,
  `tagedpersons` varchar(255) NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;


/*Table structure for table `walllikes_track` */

 /**
 * @table walllikes_track
 * @description - walllikes_track
 * @author - Vinayak
 * @since  - 05 May 2012
 * @version 3.10
 */
DROP TABLE IF EXISTS `walllikes_track`;

CREATE TABLE `walllikes_track` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Table structure for table `wallposts` */
 /**
 * @table wallposts
 * @description - wallposts
 * @author - Vinayak
 * @since  - 05 May 2012
 * @version 3.10
 */
DROP TABLE IF EXISTS `wallposts`;

CREATE TABLE `wallposts` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT,
  `cl_id` int(11) NOT NULL,
  `post` text NOT NULL,
  `type` varchar(55) NOT NULL,
  `value` int(11) NOT NULL,
  `date_created` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `posted_by` int(11) NOT NULL,
  `likes` int(11) NOT NULL,
  `media` int(11) NOT NULL,
  `uip` varchar(222) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `url` text NOT NULL,
  `cur_image` text NOT NULL,
  `post_type` tinyint(1) NOT NULL,
  `youtube` text NOT NULL,
  `tagedpersons` varchar(255) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;



/*Table structure for table `updates` */  
CREATE TABLE `updates` (
  `id` int(15) NOT NULL auto_increment,
  `update_type_id` int(4) default NULL COMMENT 'Defines what type of update it is, like add. update, delete etc',
  `object_id` int(15) default NULL COMMENT 'Id of the entity which is being updated',
  `parent_object_id` int(15) default NULL COMMENT 'Parent entity id of the entity being updated',
  `module_id` tinyint(3) default NULL COMMENT 'Represents the module to which this entity/update belongs to',
  `created_by` int(11) default NULL COMMENT 'User who is responsibale for this update',
  `created_time` timestamp NOT NULL default CURRENT_TIMESTAMP COMMENT 'When this update happened',
  `status_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_created_by` (`created_by`),
  CONSTRAINT `FK_created_by` FOREIGN KEY (`created_by`) REFERENCES `client_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/**
 * @table event_roles
 * @description - 
 * @author - Vinayak
 * @since  - 10 july 2012
 * @version 4.5
 */
 CREATE TABLE `event_roles` (             
   `id` int(11) NOT NULL auto_increment,  
   `role` varchar(255) default NULL,      
   PRIMARY KEY  (`id`)                    
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8;      

      
/**
 * @table event_roles
 * @description - 
 * @author - Vinayak
 * @since  - 27 july 2012
 * @version 4.7
 */       
/*Table structure for table `payments_paid_by` */

DROP TABLE IF EXISTS `payments_paid_by`;

CREATE TABLE `payments_paid_by` (
  `id` int(11) NOT NULL auto_increment,
  `paid_by` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



/**
 * @table event_roles
 * @description - 
 * @author - Vinayak
 * @since  - 27 july 2012
 * @version 4.7
 */
/*Table structure for table `payments_requested_by` */

DROP TABLE IF EXISTS `payments_requested_by`;

CREATE TABLE `payments_requested_by` (
  `id` int(11) NOT NULL auto_increment,
  `requested_by` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
  
 /**
 * @table payment_split
 * @description - Holds the each payment amout split records
 * @author - Ramesh B
 * @since  - 25 july 2012
 * @version 4.7
 */           
 /*Table structure for table `payment_split` */
DROP TABLE IF EXISTS payment_split;

CREATE TABLE `payment_split` (
  `id` INT(12) NOT NULL AUTO_INCREMENT,
  `payment_id` INT(12) NOT NULL,
  `type` INT(12) NOT NULL,
  `amount` DECIMAL(10,0) DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_payment_id` (`payment_id`),
  KEY `FK_payment_type` (`type`),
  CONSTRAINT `FK_payment_type` FOREIGN KEY (`type`) REFERENCES `payment_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_payment_id` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=INNODB DEFAULT CHARSET=utf8;


 /**
 * @table client_event_payments
 * @description - Holds the each client events payments association
 * @author - Ramesh B
 * @since  - 25 july 2012
 * @version 4.7
 */ 
/*Table structure for table `client_event_payments` */
DROP TABLE IF EXISTS client_event_payments;

CREATE TABLE `client_event_payments` (
  `id` INT(12) NOT NULL AUTO_INCREMENT,
  `client_event_id` INT(12) NOT NULL,
  `payment_id` INT(12) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_client_event_id` (`client_event_id`),
  KEY `FK_client_event_payment_id` (`payment_id`),
  CONSTRAINT `FK_client_event_payment_id` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_client_event_id` FOREIGN KEY (`client_event_id`) REFERENCES `client_events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=INNODB DEFAULT CHARSET=utf8;     

 /**
 * @table for interaction products
 * @description - products for interaction
 * @author - Laxman K
 * @since  - 09th Aug 2012
 * @version 4.9
 */
 
 
DROP TABLE IF EXISTS `interactions_products`;
create table `interactions_products` (
  `id` int (11) NOT NULL AUTO_INCREMENT , 
  `product_name` varchar (255) , 
  PRIMARY KEY (`id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;
/*Table structure for table `interactions_about` */

DROP TABLE IF EXISTS `interactions_about`;

CREATE TABLE `interactions_about` (
  `id` int(11) NOT NULL auto_increment,
  `interaction_id` int(11) default NULL,
  `objective_id` int(11) default NULL,
  `topic_id` int(11) default NULL,
  `product_id` int(11) default NULL,
  `brand_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `interactions_attendees` */

DROP TABLE IF EXISTS `interactions_attendees`;

CREATE TABLE `interactions_attendees` (
  `id` int(11) NOT NULL auto_increment,
  `interaction_id` int(11) default NULL,
  `kol_id` int(11) default NULL,
  `specialty_id` int(11) default NULL,
  `category_id` int(11) default NULL,
  `role_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `interaction_internal_users`;
CREATE TABLE `interaction_internal_users` (  
  `id` int(11) NOT NULL auto_increment,      
  `interaction_id` int(11) default NULL,     
  `user_id` int(11) default NULL,            
  PRIMARY KEY  (`id`)                        
) ENGINE=InnoDB DEFAULT CHARSET=utf8; 

DROP TABLE IF EXISTS `interactions`;
CREATE TABLE `interactions` (               
                `id` int(50) NOT NULL auto_increment,     
                `client_id` int(50) default NULL,         
                `date` date default NULL,                 
                `fromtime` time default NULL,             
                `mode` int(50) default NULL,              
                `location` varchar(250) default NULL,     
                `follow_up_on` date default NULL,         
                `reminder` tinyint(1) default NULL,       
                `notes` mediumtext,                       
                `created_by` int(50) NOT NULL,            
                `created_on` date NOT NULL,               
                `modified_by` int(50) NOT NULL,           
                `modified_on` date NOT NULL,              
                `calendar_event_id` int(10) default '0',  
                `totime` time default NULL,               
                `total_attendies` int(11) default NULL,   
                `grouping` int(11) default NULL,
                PRIMARY KEY  (`id`)                       
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;
              
                  
/**
 * @table `feedbacks`
 * @description - Holds the feedback values
 * @author - Vineet k
 * @since  - 23 Aug 2012
 * @version 5.0
 */ 

CREATE TABLE `feedbacks` (
  `id` int(11) NOT NULL auto_increment,
  `type_id` int(11) default NULL,
  `client_id` int(11) default NULL,
  `subject` varchar(255) default NULL,
  `description` text,
  `file_name` varchar(255) default NULL,
  `file_type` varchar(255) default NULL,
  `file_path` varchar(255) default NULL,
  `created_on` datetime default NULL,
  `created_by` int(11) default NULL,
  `modified_on` datetime default NULL,
  `modified_by` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




 /**
 * @table `feedback_types`
 * @description - Holds the `feedback_types` values
 * @author - Vineet k
 * @since  - 23 Aug 2012
 * @version 5.0
 */ 

CREATE TABLE `feedback_types` (
  `id` int(11) NOT NULL,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


 /**
 * @table structure for `assessment module`
 * @description - structure for assessment module
 * @author - Laxman K
 * @since  - 22 Sep 2012
 * @version 5.3
 */
DROP TABLE IF EXISTS `asmt_categories`;
CREATE TABLE `asmt_categories` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `asmt_criteria`;
CREATE TABLE `asmt_criteria` (
  `id` int(11) NOT NULL auto_increment,
  `criteria` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `asmt_kols_rating` */
DROP TABLE IF EXISTS `asmt_kols_rating`;
CREATE TABLE `asmt_kols_rating` (
  `kol_id` int(11) default NULL,
  `category_id` int(11) default NULL,
  `criteria_id` int(11) default NULL,
  `rating_id` int(11) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `asmt_ratings` */
DROP TABLE IF EXISTS `asmt_ratings`;
CREATE TABLE `asmt_ratings` (
  `id` int(11) NOT NULL auto_increment,
  `rating` varchar(256) default NULL,
  `rating_score` varchar(256) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `asmt_rules` */
DROP TABLE IF EXISTS `asmt_rules`;
CREATE TABLE `asmt_rules` (
  `id` int(11) NOT NULL auto_increment COMMENT 'assessment rule id',
  `kol_id` int(11) default NULL COMMENT 'kol id',
  `category_id` int(11) default NULL COMMENT 'assessment category id',
  `criteria_id` int(11) default NULL COMMENT 'assessment criteria id',
  `rating_id` int(11) default NULL COMMENT 'assessment rating id',
  `order_no` int(11) default NULL COMMENT 'order to display',
  `country_id` int(11) default NULL COMMENT 'country id',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


 /**
 * @table structure for `interaction grouping`
 * @description - specific changes for interaction
 * @author - Laxman K
 * @since  - 22 Sep 2012
 * @version Otsuka 1.0 
 */
CREATE TABLE `interaction_grouping` (
  `id` int (11) NOT NULL AUTO_INCREMENT , 
  `name` varchar (255) ,client_id` int (11)  NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8; 

CREATE TABLE `interaction_topic_mapping` (
  `id` int(11) NOT NULL auto_increment,
  `grouping_id` int(11) default NULL,
  `interaction_type_id` int(11) default NULL,
  `product_id` int(11) default NULL,
  `topic_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `interactions_topic_mapped_data` (
  `id` int(11) NOT NULL auto_increment,
  `interaction_id` int(11) NOT NULL,
  `objective_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_interactions_topic_mapped_data` (`interaction_id`),
  CONSTRAINT `FK_interactions_topic_mapped_data` FOREIGN KEY (`interaction_id`) REFERENCES `interactions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `coachings`  */
DROP TABLE IF EXISTS `coachings` ;
CREATE TABLE `coachings` (
  `id` int(11) NOT NULL auto_increment,
  `username` int(11) default NULL,
  `specialty` int(11) default NULL,
  `status` varchar(255) default NULL,
  `date` date default NULL,
  `kol_id` varchar(255) default NULL,
  `evaluated_by` int(11) default NULL,
  `plan_topic1` int(11) default NULL,
  `plan_topic2` int(11) default NULL,
  `plan_topic3` int(11) default NULL,
  `plan_topic4` int(11) default NULL,
  `open_topic1` int(11) default NULL,
  `open_topic2` int(11) default NULL,
  `med_topic1` int(11) default NULL,
  `med_topic2` int(11) default NULL,
  `med_topic3` int(11) default NULL,
  `med_topic4` int(11) default NULL,
  `med_topic5` int(11) default NULL,
  `wrap_topic1` int(11) default NULL,
  `wrap_topic2` int(11) default NULL,
  `wrap_topic3` int(11) default NULL,
  `wrap_topic4` int(11) default NULL,
  `planscore` decimal(11,2) default NULL,
  `openscore` decimal(11,2) default NULL,
  `medscore` decimal(11,2) default NULL,
  `wrapscore` decimal(11,2) default NULL,
  `totalscore` decimal(11,2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `additionalcontacts`  */
DROP TABLE IF EXISTS `additionalcontacts` ;
CREATE TABLE `additionalcontacts` (
  `id` int(11) NOT NULL auto_increment,
  `type` int(5) default NULL,
  `location` varchar(255) default NULL,
  `org_id` varchar(255) default NULL,
  `title` varchar(250) default NULL,
  `division` varchar(250) default NULL,
  `address` varchar(255) default NULL,
  `fax` varchar(15) default NULL,
  `phone` varchar(15) default NULL,
  `email` varchar(250) default NULL,
  `country_id` int(5) default NULL,
  `state_id` int(5) default NULL,
  `city_id` int(5) default NULL,
  `kol_id` int(11) default NULL,
  `is_primary` int(1) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

 /**
 * @table structure for `json_store`
 * @description - specific changes for interaction
 * @author - Ramesh B
 * @since  - 31 Oct 2012
 * @version Otsuka 1.0 
 */
CREATE TABLE `json_store` (
  `id` int(12) NOT NULL auto_increment,
  `ref_id` int(5) NOT NULL,
  `json_data` blob,
  `filter` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


 /**
 * @table structure for `kol_pmids`
 * @description - specific changes for publication crawling with given PMIDs
 * @author - Ramesh B
 * @since  - 06 Dec 2012
 * @version Otsuka 1.0.6 
 */
CREATE TABLE `kol_pmids` (
  `id` int(50) NOT NULL auto_increment,
  `kol_id` int(12) default NULL,
  `pmid` int(50) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `kol_pmid` (`kol_id`,`pmid`),
  CONSTRAINT `FK_kol` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

 /**
 * @table structure for `kol_ctids`
 * @description - specific changes for clinical trials crawling with given CTIDs
 * @author - Ramesh B
 * @since  - 06 Dec 2012
 * @version Otsuka 1.0.6 
 */
CREATE TABLE `kol_ctids` (
  `id` int(50) NOT NULL auto_increment,
  `kol_id` int(12) default NULL,
  `ctid` varchar(50) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `kol_ctid` (`kol_id`,`ctid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


 /**
 * @table structure for `user_requests`
 * @description - specific changes for otsuka users profile requests
 * @author - Ramesh B
 * @since  - 20 Dec 2012
 * @version Otsuka 1.0.8 
 */
CREATE TABLE `user_requests` (
  `id` int(12) NOT NULL auto_increment,
  `kol_id` int(12) default NULL,
  `requested_by` int(12) default NULL,
  `requested_on` datetime default NULL,
  `status` varchar(255) default NULL,
  `request_for` varchar(255) default NULL,
  `profile_type` varchar(255) default NULL,
  `rej_or_appr_by` int(12) default NULL,
  `rej_or_appr_on` datetime default NULL,
  `comments` text,
  `assigned_to` int(12) default NULL,
  `assigned_on` datetime default NULL,
  `completed_on` datetime default NULL,
  `is_re_request` tinyint(2) default '0',
  PRIMARY KEY  (`id`),
  KEY `FK_requested_kol` (`kol_id`),
  KEY `FK_requested_user` (`requested_by`),
  CONSTRAINT `FK_requested_kol` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_requested_user` FOREIGN KEY (`requested_by`) REFERENCES `client_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/**
 * @table structure for `user_org_requests`
 * @description - specific changes for otsuka users organization profile requests
 * @author - Ramesh B
 * @since  - 28 Dec 2012
 * @version Otsuka 1.0.9 
 */
CREATE TABLE `user_org_requests` (
  `id` int(12) NOT NULL auto_increment,
  `org_id` int(12) default NULL,
  `requested_by` int(12) default NULL,
  `requested_on` datetime default NULL,
  `status` varchar(255) default NULL,
  `rej_or_appr_by` int(12) default NULL,
  `rej_or_appr_on` datetime default NULL,
  `comments` text,
  `assigned_to` int(12) default NULL,
  `assigned_on` datetime default NULL,
  `completed_on` datetime default NULL,
  `is_re_request` tinyint(2) default '0',
  PRIMARY KEY  (`id`),
  KEY `FK_requested_kol` (`org_id`),
  KEY `FK_requested_user` (`requested_by`),
  CONSTRAINT `FK_org_requested_user` FOREIGN KEY (`requested_by`) REFERENCES `client_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_requested_org` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/**
 * @table structure for `kol_name_combinations`
 * @description - table to hold the kol different name combinations, which are used for calculating the authorship position
 * @author - Ramesh B
 * @since  - 02 Jan 2013
 * @version Otsuka 1.0.9 
 */
CREATE TABLE `kol_name_combinations` (
  `id` int(15) NOT NULL auto_increment,
  `kol_id` int(15) default NULL,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_kol_name_combinations` (`kol_id`),
  CONSTRAINT `FK_kol_name_combinations` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/**
 * @table structures for Survey Mapping
 * @author - Laxman K
 * @since  - 14 Apr 2013
 * @version Otsuka 1.0.11 
 */
 
 DROP TABLE IF EXISTS `survey_answers`;

CREATE TABLE `survey_answers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) DEFAULT NULL,
  `kol_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_on` timestamp NULL DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_on` timestamp NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `country` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `state` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `city` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `postal` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `nominee_id` int(11) DEFAULT NULL,
  `nominee_org_id` int(11) DEFAULT NULL,
  `respondent_id` int(11) DEFAULT NULL,
  `respondent_org_id` int(11) DEFAULT NULL,
  `respondent_country` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `respondent_state` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `respondent_city` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `respondent_postal` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `survey_id` int(11) DEFAULT NULL,
  `is_submitted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `survey_categories` */

DROP TABLE IF EXISTS `survey_categories`;

CREATE TABLE `survey_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `survey_kol_names` */

DROP TABLE IF EXISTS `survey_kol_names`;

CREATE TABLE `survey_kol_names` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `kol_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `survey_org_names` */

DROP TABLE IF EXISTS `survey_org_names`;

CREATE TABLE `survey_org_names` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `org_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `survey_queries` */

DROP TABLE IF EXISTS `survey_queries`;

CREATE TABLE `survey_queries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `query` text CHARACTER SET utf8 COLLATE utf8_bin,
  `type` tinyint(1) DEFAULT '0' COMMENT 'predefined query or query builder',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `survey_questions` */

DROP TABLE IF EXISTS `survey_questions`;

CREATE TABLE `survey_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` tinyint(1) DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `question` text CHARACTER SET utf8 COLLATE utf8_bin,
  `created_by` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `survey_roles` */

DROP TABLE IF EXISTS `survey_roles`;

CREATE TABLE `survey_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_by` date DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `modified_by` date DEFAULT NULL,
  `modified_on` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `surveys` */

DROP TABLE IF EXISTS `surveys`;

CREATE TABLE `surveys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_bin,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `question_ids` text CHARACTER SET utf8 COLLATE utf8_bin,
  `is_active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `user_kols` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `kol_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_user_kols` (`kol_id`),
  KEY `FK_users_kols` (`user_id`),
  CONSTRAINT `FK_users_kols` FOREIGN KEY (`user_id`) REFERENCES `client_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_user_kols` FOREIGN KEY (`kol_id`) REFERENCES `kols` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `user_orgs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `org_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_user_orgs` (`org_id`),
  KEY `FK_users_orgs` (`user_id`),
  CONSTRAINT `FK_users_orgs` FOREIGN KEY (`user_id`) REFERENCES `client_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_user_orgs` FOREIGN KEY (`org_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/**Table structure for table `mirf` 
* Table for saving the MIRF details
**/

CREATE TABLE IF NOT EXISTS `otsuka_crm`.`interaction_mirf` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `mirf_id` VARCHAR(40) NOT NULL,
  `interaction_id` INT(50) NOT NULL,
  `date_of_request` DATE NOT NULL,
  `kol_id` INT(11) NOT NULL,
  `degree` VARCHAR(255) NOT NULL,
  `specialty` VARCHAR(255) NOT NULL,
  `licence` VARCHAR(255) NOT NULL,
  `institution` VARCHAR(255) NOT NULL,
  `address` TEXT NOT NULL,
  `city` VARCHAR(255) NOT NULL,
  `state` VARCHAR(255) NOT NULL,
  `zip_code` VARCHAR(255) NOT NULL,
  `telephone` INT(50) NOT NULL,
  `email_id` INT(5) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `mail` INT(5) NOT NULL,
  `fax_id` INT(5) NOT NULL,
  `fax` VARCHAR(255) NOT NULL,
  `answer_provided` INT(5) NOT NULL,
  `mir_questions` TEXT NOT NULL,
  `msl_info` TEXT NOT NULL,
  `client_id` INT(50) NOT NULL,
  `created_by` INT(11) NOT NULL,
  `created_on` TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` VARCHAR(40) NOT NULL,
  `modified_on` TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  INDEX `kol_id` (`kol_id` ASC),
  INDEX `interaction_id` (`interaction_id` ASC),
  INDEX `client_id` (`client_id` ASC),
  CONSTRAINT `interaction_mirf_ibfk_1`
    FOREIGN KEY (`kol_id`)
    REFERENCES `otsuka_crm`.`kols` (`id`)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT,
  CONSTRAINT `interaction_mirf_ibfk_2`
    FOREIGN KEY (`interaction_id`)
    REFERENCES `otsuka_crm`.`interactions` (`id`),
  CONSTRAINT `interaction_mirf_ibfk_3`
    FOREIGN KEY (`client_id`)
    REFERENCES `otsuka_crm`.`client_users` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 75
DEFAULT CHARACTER SET = latin1
COLLATE = latin1_swedish_ci

/**
* Table for saving the MIRF product details
**/

CREATE TABLE IF NOT EXISTS `otsuka_crm`.`interaction_mirf_products` (
  `interaction_mirf_id` INT(50) NOT NULL,
  `product_id` INT(12) NULL DEFAULT NULL,
  `is_single_use_vial` INT(5) NOT NULL,
  `is_dual_chamber_syringe` INT(5) NOT NULL,
  `is_non_kit_specific_enquiry` INT(5) NOT NULL,
  `other_product_name` TEXT NOT NULL,
  INDEX `product_id` (`product_id` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1

/**
* Table for getting  the MIRF products
**/

CREATE TABLE IF NOT EXISTS `otsuka_crm`.`products` (
  `id` INT(12) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(250) NULL DEFAULT NULL,
  `status` TINYINT(2) NULL DEFAULT '1' COMMENT '1 - active, 0 - inactive',
  `created_by` INT(12) NULL DEFAULT NULL,
  `created_on` DATETIME NULL DEFAULT NULL,
  `modified_by` INT(12) NULL DEFAULT NULL,
  `modified_on` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 7
DEFAULT CHARACTER SET = utf8;



CREATE TABLE contact_restrictions (
	id int(10) NOT NULL auto_increment,
	visit int(10) NOT NULL,
	`call` int(10) NOT NULL,
	fax int(10) NOT NULL,
	mail int(10) NOT NULL,
	email int(10) NOT NULL,
	contact_type varchar(255) NOT NULL,
	contact int(10) NOT NULL,
	PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


/**
* log tables
**/

CREATE TABLE `log_activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(255) DEFAULT NULL,
  `controller` varchar(255) DEFAULT NULL,
  `method` varchar(255) DEFAULT NULL,
  `param` varchar(255) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `url` text,
  `description` text,
  `type` varchar(255) DEFAULT NULL COMMENT 'import,export,add,delete,crashed etc',
  `status` varchar(255) DEFAULT NULL COMMENT 'success,failure etc',
  `file_name` varchar(255) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `browser` varchar(255) DEFAULT NULL,
  `os` varchar(255) DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `miscellaneous1` varchar(255) DEFAULT NULL,
  `miscellaneous2` varchar(255) DEFAULT NULL,
  `miscellaneous3` varchar(255) DEFAULT NULL,
  `miscellaneous4` varchar(255) DEFAULT NULL,
  `transaction_id` int(11) DEFAULT NULL,
  `transaction_table_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2315 DEFAULT CHARSET=utf8;

CREATE TABLE `transaction_tables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;


CREATE TABLE `investigational_agent` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL,
  `is_active` int(12) NOT NULL,
  `created_by` int(12) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int(12) NOT NULL,
  `modified_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `source_type` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL,
  `is_active` int(12) NOT NULL,
  `created_by` int(12) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int(12) NOT NULL,
  `modified_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `sphere_of_influence` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL,
  `is_active` int(12) NOT NULL,
  `created_by` int(12) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int(12) NOT NULL,
  `modified_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `org_mco_type` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL,
  `is_active` int(12) NOT NULL,
  `created_by` int(12) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int(12) NOT NULL,
  `modified_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `org_address_type` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL,
  `is_active` int(12) NOT NULL,
  `created_by` int(12) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int(12) NOT NULL,
  `modified_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `validation_status` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL,
  `is_active` int(12) NOT NULL,
  `created_by` int(12) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int(12) NOT NULL,
  `modified_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `interaction_location_types` (
  `id` int(12) NOT NULL,
  `name` varchar(255) NOT NULL,
  `is_active` int(12) NOT NULL,
  `created_by` int(12) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` int(12) NOT NULL,
  `modified_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `phone_type` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `phone_type` (`id`, `name`) VALUES
(1, 'Answering Service'),
(2, 'Cell'),
(3, 'Face Time'),
(4, 'Fax'),
(5, 'Office Phone'),
(6, 'Pager'),
(7, 'Voice Mail'),
(8, 'Web Address'),
(9, 'Work'),
(10, 'Others');


ALTER TABLE `phone_type`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `phone_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

CREATE TABLE `staff_title` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `staff_title` (`id`, `name`) VALUES
(1, 'Administrative Assistant'),
(2, 'NP'),
(3, 'Nurse'),
(4, 'Office Manager'),
(5, 'Physician\'s Assistant'),
(6, 'Receptionist'),
(7, 'Social Worker'),
(8, 'Therapist'),
(9, 'Other');

ALTER TABLE `staff_title`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `staff_title`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;


CREATE TABLE `app_setting_types` (
  `id` int(11) NOT NULL,
  `name` varchar(300) NOT NULL,
  `lable_name` varchar(300) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


ALTER TABLE `app_setting_types`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `app_setting_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

INSERT INTO `app_setting_types` (`id`, `name`, `lable_name`, `status`) VALUES
(1, 'interaction_filter_date', 'Interaction month range', 0),
(2, 'medintel_filter_date', 'MedIntel month range', 0),
(3, 'kols_list_view', 'KTL View', 0);


CREATE TABLE `app_setting_type_values` (
  `id` int(11) NOT NULL,
  `app_setting_type_id` int(11) NOT NULL,
  `type_value` varchar(250) NOT NULL,
  `type_lable` varchar(250) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `app_setting_type_values`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `app_setting_type_values`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

INSERT INTO `app_setting_type_values` (`id`, `app_setting_type_id`, `type_value`, `type_lable`, `status`) VALUES
(1, 1, '1', 'One Month', 0),
(2, 1, '2', 'Two Month', 0),
(3, 1, '3', 'Three Month', 0),
(4, 2, '1', 'One Month', 0),
(5, 2, '2', 'Two Month', 0),
(6, 2, '3', 'Three Month', 0),
(7, 3, '1', 'Grid View', 0),
(8, 3, '2', 'List View', 0);

ALTER TABLE `app_setting_type_values`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;


CREATE TABLE `user_app_settings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `app_setting_type_id` int(11) NOT NULL,
  `app_setting_value_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `user_app_settings`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `user_app_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;



CREATE TABLE `opt_inout` (
  `id` int(11) NOT NULL,
  `kol_id` int(11) NOT NULL,
  `unique_id` varchar(250) NOT NULL,
  `status` int(10) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `first_name` varchar(250) NOT NULL,
  `last_name` varchar(250) NOT NULL,
  `title` varchar(250) NOT NULL,
  `org_name` varchar(500) NOT NULL,
  `city` varchar(250) NOT NULL,
  `state` varchar(250) NOT NULL,
  `postal_code` varchar(250) NOT NULL,
  `country` varchar(250) NOT NULL,
  `phone_number` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `note` text NOT NULL,
  `upload_file_content` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `opt_inout`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `opt_inout`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

CREATE TABLE optin_optout_settings (
 id int(11) NOT NULL,
 region int(11) NOT NULL,
 isEnabled tinyint(4) NOT NULL,
 duration int(11) NOT NULL,
 client_id int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE optin_optout_settings
 ADD PRIMARY KEY (id);

ALTER TABLE optin_optout_settings
 MODIFY id int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;


-- Table structure for table kol_update_status
-- to update status of kol data crawl/update by analyist
-- created on : 10-07-2017

CREATE TABLE `kol_update_status` (
  `id` int(11) NOT NULL,
  `kol_id` int(11) NOT NULL,
  `status` tinyint(2) DEFAULT NULL COMMENT '1-crawled, 2-updated',
  `user_added_on` date NOT NULL,
  `created_by` varchar(40) NOT NULL,
  `created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `kol_update_status` ADD PRIMARY KEY (`id`);

ALTER TABLE `kol_update_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

CREATE TABLE `opt_inout_statuses` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `opt_inout_statuses` (`id`, `name`) VALUES
(1, 'New'),
(2, 'Opt-in Requested'),
(3, 'Opt-out'),
(4, 'Opt-in Approved');

ALTER TABLE `opt_inout_statuses`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `opt_inout_statuses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

/* New group created for giving permission to access report. User need to be associated with this group for visibility in reports*/
INSERT INTO `groups` (`group_id`, `group_name`, `group_type`, `created_by`, `created_on`, `modified_by`, `modified_on`) VALUES (NULL, 'AnalyticsReports', 'Group', '232', '2017-07-13 09:41:49 ', '232', '2017-07-13 09:41:49');

/* New group created to access Opt In Opt Out. User need to be associated with this group for visibility in settings*/
INSERT INTO `groups` (`group_id`, `group_name`, `group_type`, `created_by`, `created_on`, `modified_by`, `modified_on`) VALUES (NULL, 'OIOOPermission', 'Group', '232', '2017-07-14 09:41:49 ', '232', '2017-07-14 09:41:49');
/* New group created to access User Profile Request. User need to be associated with this group for Request Aproval*/
INSERT INTO `groups` (`group_id`, `group_name`, `group_type`, `created_by`, `created_on`, `modified_by`, `modified_on`) VALUES (NULL, 'ProfileRequestAccess', 'Group', '232', '2017-07-14 09:41:49 ', '232', '2017-07-14 09:41:49');

/* Create Table to store Title-Clients Mappings (1:N) */
CREATE TABLE `title_client_mappings` (
 	`id` INT NOT NULL AUTO_INCREMENT ,
 	`title_id` INT NOT NULL ,
 	`client_id` INT NOT NULL ,
 	`created_by` INT NOT NULL ,
 	`created_on` DATETIME NOT NULL ,
 	 PRIMARY KEY (`id`)
) ENGINE = InnoDB;
/* Master table for languages */
CREATE TABLE `languages` (
  `id` int(11) NOT NULL,
  `lang_value` varchar(250) NOT NULL,
  `lang_name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `languages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

INSERT INTO `languages` (`id`, `lang_value`, `lang_name`) VALUES
(1, 'brazil_portugese', 'Brazil Portugese'),
(2, 'czech', 'Czech'),
(3, 'danish', 'Danish'),
(4, 'english', 'English'),
(5, 'french', 'French'),
(6, 'german', 'German'),
(7, 'italian', 'Italian'),
(8, 'japan', 'Japan'),
(9, 'spanish', 'Latin America Spanish'),
(10, 'netherlands_dutch', 'Netherlands/Dutch'),
(11, 'norway', 'Norway'),
(12, 'russia', 'Russia'),
(13, 'spanish_europe', 'Spanish-Europe'),
(14, 'sweden', 'Sweden'),
(15, 'taiwan_chinese', 'Taiwan Chinese');


/* Create Table to store Speciality-Clients Mappings (1:N) */
CREATE TABLE `specialty_client_association` (
  `id` int(11) NOT NULL,
  `specialty_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB;
