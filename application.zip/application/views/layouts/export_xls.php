<html>
<head>
<?php
date_default_timezone_set('Asia/Calcutta');

header("Pragma: public");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Content-Type: application/vnd.ms-excel; charset=UTF-8");
header("Content-Type: application/force-download");
header("Content-Type: application/download");
header ("Content-Disposition: attachment; filename=\"report.xls" );
header ("Content-Description: Generated Report" );
?>
</head>
<body>
	<?php echo $this->load->view($contentPage); ?> 
</body>
</html>