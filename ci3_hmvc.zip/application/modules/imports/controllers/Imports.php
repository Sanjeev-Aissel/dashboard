<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @Description : Controller to import kol details and organization details from analyst app
 * @Author : Sanjeev K
 * @Since : HMVC Kolm 1.0
 * @Package : application.controllers
 * @Created : 30-03-2018
 * @Refactored : 30-03-2018
 */
class Imports extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('import');
		$this->load->model('logins/login');
		$this->load->model('helpers/country_helper');
		$this->load->model('helpers/common_helper');
		$this->load->model('helpers/event_helper');
		$this->load->model('specialities/speciality');
		$this->load->model('kols/kol');
		$this->load->model('organizations/organization');
		$this->load->library("Ajax_pagination");
		$this->loggedUserId = $this->session->userdata('user_id');
	}
	/*
	 * @Author : Sanjeev K
	 * @Method : kols_import()
	 * @Action : loads page of kol imports
	 */
	function kols_import(){
		ini_set('memory_limit', '-1');
	
		$this->common_helper->checkUsers();
		$data['contentPage'] = 'kols/kols_import';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	/*
	 * @Author : Sanjeev K
	 * @Method : upload_zip_file()
	 * @Parameter : file
	 * @Action : loads page of kol imports
	 */
	function upload_zip_file() {
		//	$path_info = pathinfo($_FILES["overview_import"]['name']);
		$dest = APPPATH. "documents/imports/kol_imports/uploaded/" . $_FILES["prof_import"]['name'];
		move_uploaded_file($_FILES["prof_import"]['tmp_name'], $dest);
		$name = substr($_FILES["prof_import"]['name'], 0, -4);
		//$this->load->library('unzip');
		//$this->unzip->extract($dest, $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/imports/kol_imports/uploaded/");
		$up_zip = new ZipArchive();
		$x = $up_zip->open($dest);
		if($x === true) {
			$up_zip->extractTo(APPPATH."documents/imports/kol_imports/uploaded");
			$up_zip->close();
			$unzip_path = APPPATH."documents/imports/kol_imports/uploaded/".$name;
			chmod($unzip_path,0777);
			//unlink($zip_path);
		}
		$arrUHFiles = array();
		$payerPath = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."application/documents/imports/kol_imports/uploaded/";
		if ($handle = opendir($payerPath)) {
			/* This is the correct way to loop over the directory. */
	
			$chk = substr($entry, -4);
			//$arrUHFiles[] = $entry;
			if ($chk != '.zip') {
				if (is_dir($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "application/documents/imports/kol_imports/uploaded/" . $name)) {
	
					if ($handle1 = opendir($_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "application/documents/imports/kol_imports/uploaded/" . $name)) {
	
						while (false !== ($entry1 = readdir($handle1))) {
							echo $entry1;
							if ($entry1 != '.' && $entry1 != '..' && $entry1 != '.svn') {
								$arrUHFiles[$name][] = $entry1;
							}
						}
					}
				}
			}
		}
		$data['arrProfiles'] = $arrUHFiles;
	
		$data['contentPage'] = 'kols/list_import_files';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	
	/*
	 * @Author : Sanjeev K
	 * @Method : list_all_uploaded_files()
	 * @Action : loads page of kol imports
	 */
	function list_all_uploaded_files() {
		$arrFiles = array();
		$kolUploadedPath = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "documents/imports/kol_imports/uploaded/";
		if ($handle = opendir($kolUploadedPath)) {
			/* This is the correct way to loop over the directory. */
			while (false !== ($entry = readdir($handle))) {
	
				if ($entry != '.' && $entry != '..' && $entry != '.svn') {
					$chk = substr($entry, -4);
					//$arrUHFiles[] = $entry;
	
					if ($chk != '.zip') {
	
						if (is_dir($kolUploadedPath . $entry)) {
	
							if ($handle1 = opendir($kolUploadedPath . $entry)) {
	
								while (false !== ($entry1 = readdir($handle1))) {
									if ($entry1 != '.' && $entry1 != '..' && $entry1 != '.svn') {
										$arrFiles[$entry][] = $entry1;
									}
								}
							}
						}
					}
				}
			}
		}
		$data['arrProfiles'] = $arrFiles;
	
		$data['contentPage'] = 'kols/list_import_files';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	
	/*
	 * @Author : Sanjeev K
	 * @Method : import_multiple_kol_profiles()
	 * @Action : import multiple kol profile details using uploaded excel sheet in documents/imports/kol_imports/uploaded
	 */
	function import_multiple_kol_profiles() {
		$edcationDetailCount = array();
		$affiliationCount = array();
		$pubCount = array();
		$trialCount = array();
	
		$initialTime = microtime(true);
		//ini_set("max_execution_time", 7200);
		ini_set('memory_limit', "-1");
		ini_set("max_execution_time", 0);
		// Load the plugin
		$files = $this->input->post('files');
		$arrFiles = array();
		foreach ($files as $row) {
			$row	= str_replace(';','',$row);
			$pos = strpos($row, '&');
			$folderNAme = substr($row, 0, $pos);
			$arrFiles[$folderNAme][] = substr($row, $pos + 1);
		}
		$arrEventTypes = $this->event_helper->getAllConferenceEventTypes();
		$arrSessionTypes = $this->event_helper->getAllConferenceSessionTypes();
		$arrCountries = $this->country_helper->listCountries();
		$arrStates = $this->country_helper->listStates();
		$arrCities = $this->country_helper->listCities();
		$arrStatesAssociated = $this->country_helper->listStatesAssociated();
		$arrCitiesAssociated = $this->country_helper->listCitiesAssociated();
		$arrEventOrganizerTypes = $this->event_helper->getOrganizerTypes();
	
		$arrEventSponsorTypes = $this->event_helper->getSponsorTypes();
		$countryId = 0;
		$stateId = 0;
		$cityId = 0;
	
	
		//         $this->load->plugin('excelReader/reader2');
		//$this->load->plugin("excelreader/reader2");
		require_once APPPATH."third_party/excelreader/reader2_pi.php";
		$currentMethod = $this->input->post('methodName');
		$userId = $this->session->userdata('user_id');
		$clientId = $this->session->userdata('client_id');
		$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
		$arrSpecialitys = $this->speciality->getAllSpecialties();
		$arrStaffTitle = $this->kol->getStaffTitle();
		$arrPhoneType = $this->kol->getPhoneType();
	
		$profile_type = 'Aissel Analyst';
		// Get the file information of the Uploaded EXCEL file
		//$fileInfo 					= pathinfo($_FILES["prof_import"]['name']);
		// Location of the folder where all the Uploaded Excel documents will be stored
		// Generate the Random Text, which will be used to store as FILE NAME, on the server
		// This will ensure that we won't be over-writing any files on the server, even by mistake, while importing
		//$randomText					= random_string('unique', 20);
		//$uploadedFile 				= $folderLocation . $randomText . "." . $fileInfo['extension'];
		foreach ($arrFiles as $folder => $filename) {
			$folderLocation = $_SERVER['DOCUMENT_ROOT'] . "/" . $this->config->item('app_folder_path') . "application/documents/imports/kol_imports/uploaded/" . $folder;
			foreach ($filename as $file1) {
				$arrImportStatusMsg[$file1] = array();
				//$startTime = microtime(true);
				$uploadedFile = $folderLocation . "/" . $file1;
				$reader = new Spreadsheet_Excel_Reader($uploadedFile, true, 'utf-8');
				// Dump the EXCEL data for debugging
				//Prepare the data required fileds
				//To Read the shhet name and its index
				$arrKOLDetailsByPIN = array();
				foreach ($reader->boundsheets as $k => $sheet) {
	
					/**
					 * The EXCEL file information is available as an array of SHEETS.
					 * Each sheet information is available as a two dimensional array or ROW AND COLUMN
					 * Example: The First cell of the First Sheet can be accessed as
					 * $reader->sheets[1]["cells"][1][1]	== $reader->sheets[SHEET_NUMBER]["cells"][ROW_NUMBER][COLUMN_NUMBER]
					 */
	
					// Start of processing the sheet - "Professional Info"
					if (strcasecmp(trim($sheet['name']),'Professional Info')==0 || strcasecmp(trim($sheet['name']),'Prof_Info')==0) {
						//echo "started personal info<br />";
						//Check the Professional Info Header Format
						$row = 1;
						if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Salutation")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"First Name")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Middle Name")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Last Name")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Suffix")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"Gender")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][8]),"Specialty")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][9]),"Sub-Specialty")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][10]),"Company Name")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][11]),"Division")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][12]),"Title")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][13]),"License #")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][14]),"NPI Number")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][15]),"Profile Type")!=0) {
									$arrImportStatusMsg[$file1]['professional']['incorrect_format'] = 'Professional Info Header format is incorrect';
									break;
								}
	
								$existingkols = array();
								$arrLocationData = array(); // for kol_location
								$arrEmailData = array(); // for email
								$arrPhoneData = array();// for phone
								$arrLicenceData = array(); // for licence
								$kid;// kol_id for kol_location
								$korg_id; //org_id for kol_location
								for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
									$kolsDetails = array();
									$kolsDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
									// Get Salutation ID based on the Salutation Text
									$kolsDetails['salutation'] = array_search(trim($reader->sheets[$k]["cells"][$row][2]), $arrSalutations);
									if (!$kolsDetails['salutation']) {
										$kolsDetails['salutation'] = '';
									}
									$kolsDetails['first_name'] = trim($reader->sheets[$k]["cells"][$row][3]);
									$kolsDetails['middle_name'] = trim($reader->sheets[$k]["cells"][$row][4]);
									$kolsDetails['last_name'] = trim($reader->sheets[$k]["cells"][$row][5]);
									$kolsDetails['suffix'] = trim($reader->sheets[$k]["cells"][$row][6]);
									if(!empty($kolsDetails['suffix'])){
										$suffix = explode(',', $kolsDetails['suffix']);
										foreach ($suffix as $suffixRow){
											$suffix_id = $this->kol->saveSuffix(trim($suffixRow)); // save suffix if not exists
											//$kolsDetails['suffix'] = $suffix_id;
										}
									}
									$kolsDetails['gender'] = ucwords(trim($reader->sheets[$k]["cells"][$row][7]));
									// Get Specialty ID based on the Specialty Text
									$kolsDetails['specialty'] = array_search(trim($reader->sheets[$k]["cells"][$row][8]), $arrSpecialitys);
									if (!$kolsDetails['specialty']) {
										$sep = array("specialty"=>trim($reader->sheets[$k]["cells"][$row][8]),"client_id"=>INTERNAL_CLIENT_ID,"all"=>1);
										$sep_id = $this->kol->saveSpecialty($sep); // save specialty if not exists
										$kolsDetails['specialty'] = $sep_id;
									}
									$kolsDetails['sub_specialty'] = ucwords(trim($reader->sheets[$k]["cells"][$row][9]));
									$organization['name'] = trim($reader->sheets[$k]["cells"][$row][10]);
									if (!empty($organization['name'])) {
										$organization['created_by'] = $this->loggedUserId;
										$organization['created_on'] = date("Y-m-d H:i:s");
										$organization['modified_by'] = $this->loggedUserId;
										$organization['modified_on'] = date('Y-m-d H:i:s');
										$organization['status_otsuka'] = "ACTV";
										$kolsDetails['org_id'] = $this->organization->saveOrganization($organization);
										$korg_id = $kolsDetails['org_id'];
										$arrKOLDetailsByPIN[$kolsDetails['pin']]['kol_org_id'] = $kolsDetails['org_id'];
										if ($kolsDetails['org_id']) {
											//Update pin as kolid
											$updateData['id'] = $kolsDetails['org_id'];
											$updateData['cin_num'] = $kolsDetails['org_id'];
											$this->organization->updateOrganization($updateData);
										}
									}
									$kolsDetails['division'] = ucwords(trim($reader->sheets[$k]["cells"][$row][11]));
									$kolsDetails['title'] = ucwords(trim($reader->sheets[$k]["cells"][$row][12]));
									if(!empty($kolsDetails['title'])){
										$kolsDetails['title'] = $this->kol->saveTitle($kolsDetails['title']); // save title if not exists / if exsits get id
									}
									$kolsDetails['license'] = trim($reader->sheets[$k]["cells"][$row][13]);
									$kolsDetails['npi_num'] = trim($reader->sheets[$k]["cells"][$row][14]);
									$kolsDetails['profile_type'] = trim($reader->sheets[$k]["cells"][$row][15]);
									if($kolsDetails['profile_type'] == "Market Access Profile" || $kolsDetails['profile_type'] == "Market Access"){
										$kolsDetails['profile_type'] = 'Market Access';
									}elseif($kolsDetails['profile_type']=='' || ($kolsDetails['profile_type']!='Full Profile' && $kolsDetails['profile_type']!='Basic' && $kolsDetails['profile_type']!='Basic Plus' && $kolsDetails['profile_type']!='Legacy')){
										$kolsDetails['profile_type'] = 'Full Profile';
									}
	
									$kolsDetails['created_by'] = $this->loggedUserId;
									$kolsDetails['created_on'] = date("Y-m-d H:i:s");
									$kolsDetails['is_imported'] = 1;
									$kolsDetails['is_pubmed_processed'] = 0;
									//$kolsDetails['status'] = New1;
									$status = trim($reader->sheets[$k]["cells"][$row][17]);
									if ($status != '') {
										$kolsDetails['status'] = $status;
									} else {
										$kolsDetails['status'] = New1;
									}
									if ($kolsDetails['pin'] != "") {
										$id = $this->kol->saveImportedKol($kolsDetails);
										$kid=$id;
										//$arrLicenceData[$kolsDetails['pin']]['state_license'] = $kolsDetails['license'];
										// echo $reader->sheets[$k]["cells"][$row][13].'--'.$kolsDetails['license'].'<br />';
										//If the kol already Exists then it won't save
										if ($id == false) {
											//array of already existing kols
											$existingkols[] = $kolsDetails['first_name'] . " " . $kolsDetails['middle_name'] . " " . $kolsDetails['last_name'];
											/*unset($kolsDetails['first_name']);
											 unset($kolsDetails['middle_name']);
											 unset($kolsDetails['last_name']);*/
											$kid = $this->kol->updateImportedKol($kolsDetails);
											$idVla = $this->kol->getKolIdByPin($kolsDetails['pin']);
											$totalKolIds[$idVla] = $idVla;
										}else{
											$totalKolIds[$id] = $id;
										}
										//Assign User
										/* $arrData = array();
										$arrData['user_id'] = $this->loggedUserId;
										$arrData['kol_id'] = $kid;
										$arrData['type'] = 2;
										$saveAssignId = $this->kol->saveAssignClient($arrData); */
										$arrKOLDetailsByPIN[$kolsDetails['pin']]['kol_id'] = $kid;
										$arrKOLDetailsByPIN[$kolsDetails['pin']]['state_license'] = $kolsDetails['license'];
									} else {
										//array of KOL having no 'PIN'
										$arrImportStatusMsg[$file1]['professional']['no_pin_num'][] = $kolsDetails['first_name'] . " " . $kolsDetails['middle_name'] . " " . $kolsDetails['last_name'];
									}
									// pr(count($reader->sheets[$k]["cells"]));
								}
								$arrImportStatusMsg[$file1]['professional']['success'] = true;
								$arrImportStatusMsg[$file1]['professional']['existingKols'] = $existingkols;
					}
					//echo $k;exit;
					//End of processing the sheet - 'Professional Info' or 'Prof_Info'
					// Start of processing the sheet - "Contact Info"
					if (strcasecmp(trim($sheet['name']),'Contact Info')==0 || strcasecmp(trim($sheet['name']),'Contact_Info')==0) {
						//echo "started contact info<br />";
						//Check the Contact Info Header Format
						$row = 1;
						if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Primary Phone")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Fax")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Primary Email")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Address 1")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Address 2")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"City")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][8]),"State / Province")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][9]),"Postal Code")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][10]),"Country")!=0) {
									$arrImportStatusMsg[$file1]['contact']['incorrect_format'] = 'Contact Info Header format is incorrect';
									break;
								}
								// Start parsing the Values
								for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
									$countryId = 0;
									$stateId = 0;
									$cityId = 0;
									// Create a new array
									$kolsDetails = array();
									$kolsDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
									$kolsDetails['primary_phone'] = trim($reader->sheets[$k]["cells"][$row][2]);
									$kolsDetails['fax'] = trim($reader->sheets[$k]["cells"][$row][3]);
									$kolsDetails['primary_email'] = trim($reader->sheets[$k]["cells"][$row][4]);
									$kolsDetails['address1'] = trim($reader->sheets[$k]["cells"][$row][5]);
									$kolsDetails['address2'] = trim($reader->sheets[$k]["cells"][$row][6]);
	
									$arrLocationData['org_institution_id'] = $arrKOLDetailsByPIN[$kolsDetails['pin']]['kol_org_id'];
									$arrLocationData['address1'] = $kolsDetails['address1'];
									$arrLocationData['address2'] = $kolsDetails['address2'];
									$arrLocationData['address3'] = '';
									$arrLocationData['validation_status'] = 'VALD';
									$arrLocationData['address_type'] = 'Physical';
									// Get the CityID, based on the provided City Name
	
									if (array_key_exists(ucwords(trim($reader->sheets[$k]["cells"][$row][8])), $arrStates)) {
	
									}
	
	
									$countryId = $arrCountries[ucwords(trim($reader->sheets[$k]["cells"][$row][10]))]['country_id'];
									$state = ucwords(trim($reader->sheets[$k]["cells"][$row][8]));
									if ($state != '') {
										$stateId = $this->country_helper->checkStateIfExistElseAdd($state, $countryId);
										$kolsDetails['state_id'] = $stateId;
										$arrLocationData['state_id'] = $stateId;
										$arrLicenceData[$kolsDetails['pin']]['region'] = $stateId;
									}
									$city = ucwords(trim($reader->sheets[$k]["cells"][$row][7]));
									if ($city != '') {
										$kolsDetails['city_id'] = $this->country_helper->checkCityIfExistElseAdd($city, $stateId, $countryId);
										$arrLocationData['city_id'] = $kolsDetails['city_id'];
									}
	
									$kolsDetails['postal_code'] = ucwords(trim($reader->sheets[$k]["cells"][$row][9]));
									$arrLocationData['postal_code'] = $kolsDetails['postal_code'];
									if (array_key_exists(ucwords(trim($reader->sheets[$k]["cells"][$row][10])), $arrCountries))
	
										//echo
										$kolsDetails['country_id'] = $countryId;
										$arrLocationData['country_id'] = $countryId;
										$arrLocationData['is_primary'] = 1;
										$arrLocationData['created_by'] = $this->loggedUserId;
										$arrLocationData['created_on'] = date('Y-m-d H:i:s');
										$arrLocationData['modified_by'] = $this->loggedUserId;
										$arrLocationData['modified_on'] = date('Y-m-d H:i:s');
										$arrLocationData['kol_id'] = $arrKOLDetailsByPIN[$kolsDetails['pin']]['kol_id'];
										$genericId = $this->common_helper->getGenericId("Location Form");
										$arrLocationData['generic_id'] = $genericId;
										$arrLocationData['data_type_indicator'] = $profile_type;
										$lastLocId = $this->kol->saveKolLocation($arrLocationData); // insert in kol_location
	
										$arrEmailData['type'] = 'Work';
										$arrEmailData['email'] = $kolsDetails['primary_email'];
										$arrEmailData['is_primary'] = 1;
										$arrEmailData['contact'] = $arrKOLDetailsByPIN[$kolsDetails['pin']]['kol_id'];
										$arrEmailData['created_by'] = $this->loggedUserId;
										$arrEmailData['created_on'] = date('Y-m-d H:i:s');
										$arrEmailData['modified_by'] = $this->loggedUserId;
										$arrEmailData['modified_on'] = date('Y-m-d H:i:s');
										$arrEmailData['data_type_indicator'] = $profile_type;
										$this->kol->saveKolEmails($arrEmailData); // insert in email
	
										$arrPhoneData['number'] = $kolsDetails['primary_phone'];
										$arrPhoneData['is_primary'] = 1;
										$arrPhoneData['contact'] = $arrKOLDetailsByPIN[$kolsDetails['pin']]['kol_id'];
										$arrPhoneData['location_id'] = $lastLocId;
										$arrPhoneData['contact_type'] = "location";
										$arrPhoneData['created_by'] = $this->loggedUserId;
										$arrPhoneData['created_on'] = date('Y-m-d H:i:s');
										$arrPhoneData['modified_by'] = $this->loggedUserId;
										$arrPhoneData['modified_on'] = date('Y-m-d H:i:s');
										$arrPhoneData['type'] = 'Office Phone';
										$arrPhoneData['data_type_indicator'] = $profile_type;
										$this->kol->saveKolPhones($arrPhoneData); // insert in phone_number
										//pr($arrKOLDetailsByPIN);
										if(isset($arrKOLDetailsByPIN[$kolsDetails['pin']]['state_license']) && !empty($arrKOLDetailsByPIN[$kolsDetails['pin']]['state_license'])){
											$arrNewLicenceData  = array();
											$arrNewLicenceData['state_license'] = $arrKOLDetailsByPIN[$kolsDetails['pin']]['state_license'];
											$arrNewLicenceData['region'] = $arrKOLDetailsByPIN[$kolsDetails['pin']]['region'];
											$arrNewLicenceData['contact'] = $arrKOLDetailsByPIN[$kolsDetails['pin']]['kol_id'];
											$arrNewLicenceData['is_primary'] = 1;
											$arrNewLicenceData['created_by'] = $this->loggedUserId;
											$arrNewLicenceData['created_on'] = date('Y-m-d H:i:s');
											$arrNewLicenceData['modified_by'] = $this->loggedUserId;
											$arrNewLicenceData['modified_on'] = date('Y-m-d H:i:s');
											$arrNewLicenceData['data_type_indicator'] = $profile_type;
											// pr($arrLicenceData);
											// pr($arrNewLicenceData);
	
											$this->kol->saveKolLicense($arrNewLicenceData); // insert in sate_licence
										}
	
	
										if($kolsDetails['fax']!=''){
											$arrPhoneData['is_primary'] = 0;
											$arrPhoneData['number']=$kolsDetails['fax'];
											$arrPhoneData['type'] = 'Fax';
											$this->kol->saveKolPhones($arrPhoneData); // insert fax in phone_number
										}
	
										//Update only if the 'pin' is not blank
										if ($kolsDetails['pin'] != "") {
											$id = $this->kol->updateImportedKol($kolsDetails);
											if ($id == false) {
												//Array of KOLs with mentioned 'PIN' not present in database
												$arrImportStatusMsg[$file1]['contact']['no_matching_pin_num'][] = $kolsDetails['pin'];
											}
										} else {
											//Array of KOLs having no 'PIN' in EXCEL file
											$arrImportStatusMsg[$file1]['contact']['no_pin_num'][] = $kolsDetails['primary_phone'];
										}
								}
								$arrImportStatusMsg[$file1]['contact']['success'] = true;
					}
	
	
					if (strcasecmp(trim($sheet['name']),'Details_Page')==0) {
						//echo "started contact info<br />";
						//Check the Contact Info Header Format
						$row = 1;
						if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Is Primary")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Data Type")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Institution Name")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Department")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Title")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"License")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][8]),"Specialty")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][9]),"Specialty Type")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][10]),"Phone Type")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][11]),"Phone")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][12]),"Email Type")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][13]),"Email")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][14]),"Address 1")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][15]),"Address 2")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][16]),"City")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][17]),"State/ Province")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][18]),"Country")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][19]),"Postal Code")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][20]),"Staff Name")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][21]),"Languages Spoken")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][22]),"Bio / Comments")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][23]),"Areas of Interest")!=0) {
									$arrImportStatusMsg[$file1]['details']['incorrect_format'] = 'Details Header format is incorrect';
									break;
								}
	
								$globalOrgId = '';
								$insData = false;
								// Start parsing the Values
								for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
									//Save only if the 'pin' is not blank
									$detailsPin = trim($reader->sheets[$k]["cells"][$row][1]);
									if ($detailsPin != "") {
										$kolId = $this->kol->getKolIdByPin($detailsPin);
										if ($kolId != 0) {
											$edcationDetailCount[$kolId]['kolId'] = $kolId;
											$insData = true;
										} else {
											$insData = false;
											$arrImportStatusMsg[$file1]['details']['no_matching_pin_num'][] = $detailsPin;
										}
									} else {
										//aray of Affiliation having no 'pin'
										$insData = false;
										$arrImportStatusMsg[$file1]['details']['no_pin_num'][] = trim($reader->sheets[$k]["cells"][$row][3]);
									}
									$countryId = 0;
									$stateId = 0;
									$cityId = 0;
									$dataType = trim($reader->sheets[$k]["cells"][$row][3]);
									switch($dataType){
										//Location Info Details
										case 'Location':
											$arrLoc = array();
											$arrLoc['is_primary'] = trim($reader->sheets[$k]["cells"][$row][2]);
											if(strcasecmp($arrLoc['is_primary'],'Yes')==0){
												$arrLoc['is_primary'] = 1;
											}else{
												$arrLoc['is_primary'] = 0;
											}
											$arrLoc['division'] = trim($reader->sheets[$k]["cells"][$row][5]);
											$arrLoc['title'] = ucwords(trim($reader->sheets[$k]["cells"][$row][6]));
											if(!empty($arrLoc['title'])){
												$arrLoc['title'] = $this->kol->saveTitle($arrLoc['title']); // save title if not exists / if exsits get id
											}
											$arrLoc['address1'] = trim($reader->sheets[$k]["cells"][$row][14]);
											$arrLoc['address2'] = trim($reader->sheets[$k]["cells"][$row][15]);
											// Get the Country Id,State Id,City Id based on the provided Names
											$country_name = trim($reader->sheets[$k]["cells"][$row][18]);
											$arrLoc['country_id'] = $this->country_helper->checkCountryIfExistElseAdd($country_name);
											if(!empty(trim($reader->sheets[$k]["cells"][$row][17]))){
												$arrLoc['state_id'] = $this->country_helper->checkStateIfExistElseAdd(trim($reader->sheets[$k]["cells"][$row][17]),$arrLoc['country_id']);
											}
											if(!empty(trim($reader->sheets[$k]["cells"][$row][16]))){
												$arrLoc['city_id'] = $this->country_helper->checkCityIfExistElseAdd(trim($reader->sheets[$k]["cells"][$row][16]),$arrLoc['state_id'],$arrLoc['country_id']);
											}
											$arrLoc['postal_code'] = ucwords(trim($reader->sheets[$k]["cells"][$row][19]));
											$department_name = trim($reader->sheets[$k]["cells"][$row][5]);
											$institute_name = trim($reader->sheets[$k]["cells"][$row][4]);
											if(!empty($institute_name)){
												$arrLoc['org_institution_id'] = $this->organization->getOrgIdByOrgName($institute_name);
												if ($arrLoc['org_institution_id'] == 0) {
													$arrOrgData = array();
													$arrOrgData['address'] = $arrLoc['address1'] . " " . $arrLoc['address2'];
													$arrOrgData['name'] = $institute_name;
													$arrOrgData['state_id'] = $arrLoc['state_id'];
													$arrOrgData['city_id'] = $arrLoc['city_id'];
													$arrOrgData['country_id'] = $arrLoc['country_id'];
													$arrOrgData['postal_code'] = $arrLoc['postal_code'];
													$arrOrgData['created_by'] = $this->loggedUserId;
													$arrOrgData['created_on'] = date('Y-m-d H:i:s');
													$arrOrgData['modified_by'] = $this->loggedUserId;
													$arrOrgData['modified_on'] = date('Y-m-d H:i:s');
													$arrOrgData['type_id'] = $this->kol->getOrgTypeIdByName($department_name);
													if($arrOrgData['type_id'] == 0){
														$arrOrgData['type_id'] = 7;
													}
													$arrOrgData['profile_type'] = 1;
													$arrOrgData['status_otsuka'] = "ACTV";
													$arrOrgData['status'] = "";
													$org_id = $this->organization->saveOrganization($arrOrgData);
													$arrLoc['org_institution_id'] = $org_id;
												}
											}
											$arrLoc['kol_id'] = $kolId;
											$arrLoc['data_type_indicator'] = $profile_type;
											if($insData){
												$lastLocId = $this->kol->saveKolLocation($arrLoc);//insert in kol_locations
												if($arrLoc['is_primary'] == 1){
													$arrKolDetails = array();
													$arrKolDetails['id'] = $kolId;
													$arrKolDetails['org_id'] = $arrLoc['org_institution_id'];
													$arrKolDetails['address1'] = $arrLoc['address1'];
													$arrKolDetails['address2'] = $arrLoc['address2'];
													$arrKolDetails['country_id'] = $arrLoc['country_id'];
													$arrKolDetails['state_id'] = $arrLoc['state_id'];
													$arrKolDetails['city_id'] = $arrLoc['city_id'];
													$arrKolDetails['postal_code'] = $arrLoc['postal_code'];
													$arrKolDetails['modified_by'] = $this->loggedUserId;
													$arrKolDetails['modified_on'] = date('Y-m-d H:i:s');
													$this->kol->updateKol($arrKolDetails);
												}
												$insData = false;
											}
											break;
										case 'Phone':
											$arrPhoneData = array();
											$arrPhoneData['number'] = trim($reader->sheets[$k]["cells"][$row][11]);
											$arrPhoneData['type'] = array_search(trim($reader->sheets[$k]["cells"][$row][10]), $arrPhoneType);
											if (!$arrPhoneData['type']) {
												if(!empty($arrPhoneData['type'])){
													$phoneType = array("name"=>trim($reader->sheets[$k]["cells"][$row][10]));
													$type_id = $this->kol->savePhoneType($phoneType); // save specialty if not exists
													$arrPhoneData['type'] = $type_id;
												}
											}
											$arrPhoneData['is_primary'] = trim($reader->sheets[$k]["cells"][$row][2]);
											if($arrPhoneData['is_primary']=='Yes' || $arrPhoneData['is_primary']=='yes'){
	
												$arrPhoneData['is_primary'] = 1;
											}else{
												$arrPhoneData['is_primary'] = 0;
											}
											$institute_name = trim($reader->sheets[$k]["cells"][$row][4]);
											if(!empty($institute_name)){
												$org_institution_id = $this->organization->getOrgIdByOrgName($institute_name,false);
												$arrPhoneData['location_id'] = '';
												if ($org_institution_id > 0) {
													$arrLocationData['org_institution_id'] = $org_institution_id;
													$arrLocationData['kol_id'] = $kolId;
													$locationId = $this->kol->getKolLocationByOrgInstId($arrLocationData);
													if(is_numeric($locationId)){
														$arrPhoneData['location_id'] = $locationId;
													}
												}
											}
											$arrPhoneData['contact'] = $kolId;
											$arrPhoneData['contact_type'] = "location";
											$arrPhoneData['created_by'] = $this->loggedUserId;
											$arrPhoneData['created_on'] = date('Y-m-d H:i:s');
											$arrPhoneData['modified_by'] = $this->loggedUserId;
											$arrPhoneData['modified_on'] = date('Y-m-d H:i:s');
											$arrPhoneData['data_type_indicator'] = $profile_type;
											if($insData){
												$this->kol->saveKolPhones($arrPhoneData); // insert in phone_number
												$insData = false;
											}
											break;
											//Email Info Details
										case 'Email':
											$arrEmailData = array();
											$arrEmailData['type'] = trim($reader->sheets[$k]["cells"][$row][12]);
											$arrEmailData['email'] = trim($reader->sheets[$k]["cells"][$row][13]);
											$arrEmailData['is_primary'] = trim($reader->sheets[$k]["cells"][$row][2]);
											if($arrEmailData['is_primary']=='Yes' || $arrEmailData['is_primary']=='yes'){
												$arrEmailData['is_primary'] = 1;
											}else{
												$arrEmailData['is_primary'] = 0;
											}
											$arrEmailData['contact'] = $kolId;
											$arrEmailData['created_by'] = $this->loggedUserId;
											$arrEmailData['created_on'] = date('Y-m-d H:i:s');
											$arrEmailData['modified_by'] = $this->loggedUserId;
											$arrEmailData['modified_on'] = date('Y-m-d H:i:s');
											$arrEmailData['data_type_indicator'] = $profile_type;
											if($insData){
												$this->kol->saveKolEmails($arrEmailData); // insert in email
												$insData = false;
											}
											break;
											//License Info Details
										case 'License':
	
											$arrNewLicenceData  = array();
											$arrNewLicenceData['state_license'] = trim($reader->sheets[$k]["cells"][$row][7]);
											$country_name = trim($reader->sheets[$k]["cells"][$row][18]);
											$arrNewLicenceData['country_id'] = $this->country_helper->checkCountryIfExistElseAdd($country_name);
											if(!empty(trim($reader->sheets[$k]["cells"][$row][17]))){
												$arrNewLicenceData['region'] = $this->country_helper->checkStateIfExistElseAdd(trim($reader->sheets[$k]["cells"][$row][17]),$arrNewLicenceData['country_id']);
											}
											$arrNewLicenceData['contact'] = $kolId;
											$arrNewLicenceData['is_primary'] = trim($reader->sheets[$k]["cells"][$row][2]);
											if($arrNewLicenceData['is_primary']=='Yes' || $arrNewLicenceData['is_primary']=='yes'){
												$arrNewLicenceData['is_primary'] = 1;
											}else{
												$arrNewLicenceData['is_primary'] = 0;
											}
											$arrNewLicenceData['created_by'] = $this->loggedUserId;
											$arrNewLicenceData['created_on'] = date('Y-m-d H:i:s');
											$arrNewLicenceData['modified_by'] = $this->loggedUserId;
											$arrNewLicenceData['modified_on'] = date('Y-m-d H:i:s');
											$arrNewLicenceData['data_type_indicator'] = $profile_type;
											if($insData){
												$this->kol->saveKolLicense($arrNewLicenceData); // insert in sate_licence
												$insData = false;
											}
											break;
											//Specialty Info Details
										case 'Specialty':
											$arrNewSpecialty = array();
											$arrNewSpecialty['kol_sub_specialty_id'] = array_search(trim($reader->sheets[$k]["cells"][$row][8]), $arrSpecialitys);
											if (!$arrNewSpecialty['kol_sub_specialty_id']) {
												if(!empty($arrNewSpecialty['kol_sub_specialty_id'])){
													$sep = array("specialty"=>trim($reader->sheets[$k]["cells"][$row][8]),"client_id"=>INTERNAL_CLIENT_ID,"all"=>1);
													$sep_id = $this->kol->saveSpecialty($sep); // save specialty if not exists
													$arrNewSpecialty['kol_sub_specialty_id'] = $sep_id;
												}
											}
											$arrNewSpecialty['kol_id']= $kolId;
											$specialtyType = trim($reader->sheets[$k]["cells"][$row][9]);
											switch($specialtyType){
												case 'Primary Specialty':
													$arrNewSpecialty['priority'] = 1;
													break;
												case 'Additional Specialty';
												$arrNewSpecialty['priority'] = 2;
												break;
												case 'Sub-Specialty';
												$arrNewSpecialty['priority'] = 0;
												break;
											}
											if($insData){
												$this->kol->saveKolSpecialty($arrNewSpecialty); // insert in sate_licence
												$insData = false;
											}
											break;
										case 'Staff':
											$arrNewStaffData  = array();
											$arrNewStaffData['title'] = trim($reader->sheets[$k]["cells"][$row][6]);
											$arrNewStaffData['name'] = trim($reader->sheets[$k]["cells"][$row][20]);
											$arrNewStaffData['phone_number'] = trim($reader->sheets[$k]["cells"][$row][11]);
											$arrNewStaffData['phone_type'] = array_search(trim($reader->sheets[$k]["cells"][$row][10]), $arrPhoneType);
											if (!$arrNewStaffData['phone_type']) {
												if(!empty($arrNewStaffData['phone_type'])){
													$phoneType = array("name"=>trim($reader->sheets[$k]["cells"][$row][10]));
													$type_id = $this->kol->savePhoneType($phoneType); // save specialty if not exists
													$arrNewStaffData['phone_type'] = $type_id;
												}
											}
											$arrNewStaffData['title'] = array_search(trim($reader->sheets[$k]["cells"][$row][6]), $arrStaffTitle);
											if (!$arrNewStaffData['title']) {
												if(!empty($arrNewStaffData['title'])){
													$stafftitle = array("name"=>trim($reader->sheets[$k]["cells"][$row][6]));
													$title_id = $this->kol->saveStaffTitle($stafftitle); // save specialty if not exists
													$arrNewStaffData['title'] = $title_id;
												}
											}
											$arrNewStaffData['email'] = trim($reader->sheets[$k]["cells"][$row][13]);
											$institute_name = trim($reader->sheets[$k]["cells"][$row][4]);
											if(!empty($institute_name)){
												$org_institution_id = $this->organization->getOrgIdByOrgName($institute_name,false);
												$arrNewStaffData['location_id'] = '';
												if ($org_institution_id > 0) {
													$arrLocationData['org_institution_id'] = $org_institution_id;
													$arrLocationData['kol_id'] = $kolId;
													$locationId = $this->kol->getKolLocationByOrgInstId($arrLocationData);
													if(is_numeric($locationId)){
														$arrNewStaffData['location_id'] = $locationId;
													}
												}
											}
											$arrNewStaffData['contact'] = $kolId;
											$arrNewStaffData['contact_type'] = "location";
											$arrNewStaffData['created_by'] = $this->loggedUserId;
											$arrNewStaffData['created_on'] = date('Y-m-d H:i:s');
											$arrNewStaffData['modified_by'] = $this->loggedUserId;
											$arrNewStaffData['modified_on'] = date('Y-m-d H:i:s');
											$arrNewStaffData['data_type_indicator'] = $profile_type;
											if($insData){
												$this->kol->saveStaff($arrNewStaffData); // insert in sate_licence
												$insData = false;
											}
											break;
										case 'Areas of Interest':
											$rowData = trim($reader->sheets[$k]["cells"][$row][23]);
											if(!empty($rowData)){
												$arrData =array();
												$arrData['area_of_interest'] = $rowData;
												if($insData){
													$this->kol->additionalDataInsert($arrData,$kolId);
													$insData = false;
												}
											}
											break;
										case 'Bio / Comments':
											$rowData = trim($reader->sheets[$k]["cells"][$row][22]);
											if(!empty($rowData)){
												$arrData =array();
												$arrData['bio_comments'] = $rowData;
												if($insData){
													$this->kol->additionalDataInsert($arrData,$kolId);
													$insData = false;
												}
											}
											break;
										case 'Languages Spoken':
											$rowData = trim($reader->sheets[$k]["cells"][$row][21]);
											if(!empty($rowData)){
												$arrData =array();
												$arrData['languages_spoken'] = $rowData;
												if($insData){
													$this->kol->additionalDataInsert($arrData,$kolId);
													$insData = false;
												}
											}
											break;
									}
	
								}
									
								$arrImportStatusMsg[$file1]['details']['success'] = true;
					}
	
	
					//- End of processing the sheet - 'Contact Info'
					// Start of processing the sheet - "Biography"
					if (strcasecmp(trim($sheet['name']),'Biography')==0) {
						//echo "started biography<br />";
						//Check the Biography Header Format
						$row = 1;
						if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Biography")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Clinical Research Interests")!=0) {
									$arrImportStatusMsg[$file1]['biography']['incorrect_format'] = 'Biography Header format is incorrect';
									break;
								}
								for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
									$kolsDetails = array();
									$kolsDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
									$kolsDetails['biography'] = trim($reader->sheets[$k]["cells"][$row][2]);
									$kolsDetails['research_interests'] = trim($reader->sheets[$k]["cells"][$row][3]);
									//Update only if the 'pin' is not blank
									if ($kolsDetails['pin'] != "") {
										$id = $this->kol->updateImportedKol($kolsDetails);
										if ($id == false) {
											//array of 'pin' not present in database
											$arrImportStatusMsg[$file1]['biography']['no_matching_cin_num'][] = $kolsDetails['pin'];
										}
									} else {
										//aray of kol having no 'pin'
										$arrImportStatusMsg[$file1]['biography']['no_pin_num'][] = $kolsDetails['biography'];
									}
								}
								$arrImportStatusMsg[$file1]['biography']['success'] = true;
					}
					//- End of processing the sheet - 'Biography'
					// Start of processing the sheet - 'Education'
					if (strcasecmp(trim($sheet['name']),'Education')==0) {
						$educationBulkInsert = array();
						//echo "started education<br />";
						//Check the Education Info Header Format
						$row = 1;
						if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Education Type")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Institution Name")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Degree")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Specialty")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Time Frame")!=0) {
									$arrImportStatusMsg[$file1]['education']['incorrect_format'] = 'Education Info Header format is incorrect';
									break;
								}
								//Arrays to check education types
								$eduTypes = array("Education", "education");
								$trainingTypes = array("Training", "training");
								$boardTypes = array("board_certification","Board_certification", "Board Certification", "Board certification");
								$honorTypes = array("honors_awards","Honors_awards", "Awards/Honors", "Honors/Awards", "Honors", "Awards", "Honors/awards", "Honors and Awards");
								$startTime = microtime(true);
								for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
									$kolDetails = array();
									$eduDetails = array();
									$kolDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
									//Check for the  Education Type
									$educationType = trim($reader->sheets[$k]["cells"][$row][2]);
									if (in_array($educationType, $eduTypes)) {
										$type = "education";
									} else if (in_array($educationType, $trainingTypes)) {
										$type = "training";
									} else if (in_array($educationType, $boardTypes)) {
										$type = "board_certification";
									} else if (in_array($educationType, $honorTypes)) {
										$type = "honors_awards";
									} else {
										//Deafult value
										$type = "education";
									}
									$eduDetails['type'] = $type;
									if ($type != "honors_awards") {
										//Get Institute id
										$institution = array();
										$institution['name'] = trim($reader->sheets[$k]["cells"][$row][3]);
										$institution['created_by'] = $this->loggedUserId;
										$institution['created_on'] = date('Y-m-d H:i:s');
										if ($institution['name'] != '')
											$institueId = $this->kol->getInstituteIdElseSave($institution);
											$eduDetails['institute_id'] = $institueId;
									}
									if ($type == "honors_awards") {
										//   $eduDetails['institute_id'] = '';
										$eduDetails['honor_name'] = trim($reader->sheets[$k]["cells"][$row][3]);
									}
									$eduDetails['degree'] = trim($reader->sheets[$k]["cells"][$row][4]);
									$eduDetails['specialty'] = trim($reader->sheets[$k]["cells"][$row][5]);
									//Get the start and end years
									$timeFrame = trim($reader->sheets[$k]["cells"][$row][6]);
									$startDate = "";
									$endDate = "";
									$arrTimeFrame = explode('-', $timeFrame);
									$startDate = trim($arrTimeFrame[0]);
									if (sizeof($arrTimeFrame) > 1) {
										$endDate = trim($arrTimeFrame[1]);
									}
									//For honours Separate column year
									if ($type == "honors_awards") {
										$eduDetails['year'] = $startDate;
										$eduDetails['start_date'] = $startDate;
										$eduDetails['end_date'] = $endDate;
									} else {
										$eduDetails['start_date'] = $startDate;
										$eduDetails['end_date'] = $endDate;
									}
									$eduDetails['created_by'] = $this->loggedUserId;
									$eduDetails['created_on'] = date("Y-m-d H:i:s");
									$eduDetails['client_id'] = $this->session->userdata('client_id');
									$eduDetails['data_type_indicator'] = $profile_type;
									//Save only if the 'pin' is not blank
									if ($kolDetails['pin'] != "") {
										$kolId = $this->kol->getKolIdByPin($kolDetails['pin']);
										if ($kolId != 0) {
											$edcationDetailCount[$kolId]['kolId'] = $kolId;
	
											$eduDetails['kol_id'] = $kolId;
											$id = $this->kol->saveEducationDetail($eduDetails);
											$educationBulkInsert[] = $eduDetails;
										} else {
											$arrImportStatusMsg[$file1]['education']['no_matching_pin_num'][] = $eduDetails['pin'];
										}
									} else {
										//aray of Education having no 'pin'
										$arrImportStatusMsg[$file1]['education']['no_pin_num'][] = $institution['name'];
									}
								}
								foreach ($edcationDetailCount as $kolId => $values) {
									if (!(isset($edcationDetailCount[$kolId]['educationCount']))) {
										$edcationDetailCount[$kolId]['educationCount'] = $this->kol->getCountOfEducations($kolId);
									}
								}
	
								//echo "Endtime".(microtime(true)-$startTime);
								$arrImportStatusMsg[$file1]['education']['success'] = true;
	
	
								//$this->kol->saveEducationDetailByBulk($educationBulkInsert);
					}
	
					//- End of processing the sheet - 'Education'
					// Start of processing the sheet - 'Affiliation'
					if (strcasecmp(trim($sheet['name']),'Affiliation')==0) {
						$arrAffiliationForBulk = array();
						//echo "started affiliation<br />";
						//Check the Affiliation Info Header Format
						$row = 1;
						if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Organization Name")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Dept/Committee")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Title/Purpose")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Time frame")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Organization Type")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"Engagement Type")!=0) {
									$arrImportStatusMsg[$file1]['affiliation']['incorrect_format'] = 'Affiliation Info Header format is incorrect';
									break;
								}
								//Arrays to check Affiliation types
								$uniTypes = array("University/Hospital", "University", "university");
								$assocTypes = array("Association", "association", "Associations");
								$indTypes = array("Industry", "industry");
								$govTypes = array("Government", "Government Agency", "Government-Agency", "Government agency", "government");
								$otherTypes = array("Others", "others", "Other", "other");
								for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
									$kolDetails = array();
									$affDetails = array();
									$kolDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
									//Check for the  Organization Type(Type of Affiliation)
									$orgType = trim($reader->sheets[$k]["cells"][$row][6]);
									if (in_array($orgType, $uniTypes)) {
										$type = "university";
									} else if (in_array($orgType, $assocTypes)) {
										$type = "association";
									} else if (in_array($orgType, $indTypes)) {
										$type = "industry";
									} else if (in_array($orgType, $govTypes)) {
										$type = "government";
									} else if (in_array($orgType, $otherTypes)) {
										$type = "others";
									} else {
										//Deafult value
										$type = "university";
									}
									$affDetails['type'] = $type;
									//Get Institute id//Oranization Id
									$institution = array();
									$institution['name'] = trim($reader->sheets[$k]["cells"][$row][2]);
									$institution['created_by'] = $this->loggedUserId;
									$institution['created_on'] = date('Y-m-d H:i:s');
									if ($institution['name'] != '')
										$institueId = $this->kol->getInstituteIdElseSave($institution);
										$affDetails['institute_id'] = $institueId;
										$affDetails['department'] = trim($reader->sheets[$k]["cells"][$row][3]);
										$affDetails['role'] = trim($reader->sheets[$k]["cells"][$row][4]);
										//Get the start and end years
										$timeFrame = trim($reader->sheets[$k]["cells"][$row][5]);
										$startDate = "";
										$endDate = "";
										$arrTimeFrame = explode('-', $timeFrame);
										if (sizeof($arrTimeFrame) > 0) {
											$startDate = trim($arrTimeFrame[0]);
										}
										if (sizeof($arrTimeFrame) > 1) {
											$endDate = trim($arrTimeFrame[1]);
										}
										//Get Engagement id
										$engagement = ucwords(trim($reader->sheets[$k]["cells"][$row][7]));
										$engagementId = $this->engagement_type->getEngagementId($engagement);
										if ($engagementId) {
											$affDetails['engagement_id'] = $engagementId;
										}
										$affDetails['start_date'] = $startDate;
										$affDetails['end_date'] = $endDate;
										$affDetails['created_by'] = $this->loggedUserId;
										$affDetails['created_on'] = date("Y-m-d H:i:s");
										$affDetails['client_id'] = $this->session->userdata('client_id');
										$affDetails['data_type_indicator'] = $profile_type;
										//pr($affDetails);
										//Save only if the 'pin' is not blank
										if ($kolDetails['pin'] != "") {
											$kolId = $this->kol->getKolIdByPin($kolDetails['pin']);
											if ($kolId != 0) {
												$affDetails['kol_id'] = $kolId;
												$edcationDetailCount[$kolId]['kolId'] = $kolId;
												//$edcationDetailCount[$kolId]['affCount'] = 12;
												//$id						= $this->kol->saveMembership($affDetails);
												$arrAffiliationForBulk[] = $affDetails;
											} else {
												$arrImportStatusMsg[$file1]['affiliation']['no_matching_pin_num'][] = $kolDetails['pin'];
											}
										} else {
											//aray of Affiliation having no 'pin'
											$arrImportStatusMsg[$file1]['affiliation']['no_pin_num'][] = $institution['name'];
										}
								}
								foreach ($edcationDetailCount as $kolId => $values) {
									if (!(isset($edcationDetailCount[$kolId]['affiliationCount']))) {
										$edcationDetailCount[$kolId]['affiliationCount'] = $this->kol->getCountOfAffiliation($kolId);
									}
								}
	
								//pr($edcationDetailCount);
								$arrImportStatusMsg[$file1]['affiliation']['success'] = true;
								// pr($arrAffiliationForBulk);
								// exit;
								$this->kol->saveAffiliationDetailByBulk($arrAffiliationForBulk);
					}
					//- End of processing the sheet - 'Affiliation'
					// Start of processing the sheet - 'Event'
					if (strcasecmp(trim($sheet['name']),'Event')==0) {
						$startTime = microtime(true);
						$arrEventsForBulk = array();
						//echo "In Events<br />";
						//Check the Event Info Header Format
						$row = 1;
						if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Event Name")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Event Type")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Session Type")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Session Name")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Role")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"Topic")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][8]),"Start")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][9]),"End")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][10]),"Organizer")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][11]),"Organizer Type")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][12]),"Session Sponsor")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][13]),"Sponsor Type")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][14]),"Location")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][15]),"Address")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][16]),"Country")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][17]),"State")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][18]),"City")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][19]),"Postal Code")!=0) {
									$arrImportStatusMsg[$file1]['event']['incorrect_format'] = 'Event Info Header format is incorrect';
									//break;
								}
								for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
									$kolDetails = array();
									$eventDetails = array();
									$event = array();
									$countryId = 0;
									$stateId = 0;
									$cityId = 0;
									$kolDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
									$event['name'] = trim($reader->sheets[$k]["cells"][$row][2]);
									if ($kolDetails['pin'] != '' && $event['name'] != '') {
										$eventDetails['type'] = 'conference';
										//Get event id
										$event['category'] = 'conference';
										$event['created_by'] = $this->loggedUserId;
										$event['created_on'] = date('Y-m-d H:i:s');
										$eventId = $this->kol->getEventIdElseSave($event);
										$eventDetails['event_id'] = $eventId;
										//Get the event type ID
										$eventType = array_search(ucwords(trim($reader->sheets[$k]["cells"][$row][3])), $arrEventTypes);
										if (!$eventType) {
											$arrEventType['event_type'] = ucwords(trim($reader->sheets[$k]["cells"][$row][3]));
											if ($this->db->insert('conf_event_types', $arrEventType)) {
												$eventType = $this->db->insert_id();
												$arrEventTypes[$eventType] = $arrEventType['event_type'];
											} else {
												$eventType = "";
											}
										}
										$eventDetails['event_type'] = $eventType;
										//Get the Session type ID
										$sessionType = array_search(ucwords(trim($reader->sheets[$k]["cells"][$row][4])), $arrSessionTypes);
										if (!$sessionType) {
											$arrSessionType['session_type'] = ucwords(trim($reader->sheets[$k]["cells"][$row][4]));
											if ($this->db->insert('conf_session_types', $arrSessionType)) {
												$sessionType = $this->db->insert_id();
												$arrSessionTypes[$sessionType] = $arrSessionType['session_type'];
											} else {
												$sessionType = "";
											}
										}
										$eventDetails['session_type'] = $sessionType;
	
										$eventDetails['session_name'] = trim($reader->sheets[$k]["cells"][$row][5]);
										$eventDetails['role'] = ucwords(trim($reader->sheets[$k]["cells"][$row][6]));
										//Get the Evet Topic Id and then Save
										$topic = '';
										$topicId = '';
										$topic = ucwords(trim($reader->sheets[$k]["cells"][$row][7]));
										if ($topic != '') {
											$topicId = $this->kol->getTopicId($topic);
											if ($topicId == 0) {
												$arrEventTopic['name'] = $topic;
												if ($this->db->insert('event_topics', $arrEventTopic)) {
													$topicId = $this->db->insert_id();
												}
											}
										}
										$eventDetails['topic'] = $topicId;
										//Get the start and end Dates
										$startDate = '';
										$endDate = '';
										$startDate = $this->kol->convertDateToYYYYMMDD(trim($reader->sheets[$k]["cells"][$row][8]));
										$endDate = $this->kol->convertDateToYYYYMMDD(trim($reader->sheets[$k]["cells"][$row][9]));
										$eventDetails['start'] = $startDate;
										$eventDetails['end'] = $endDate;
										$eventDetails['organizer'] = trim($reader->sheets[$k]["cells"][$row][10]);
	
										$oranizerType = array_search(ucwords(trim($reader->sheets[$k]["cells"][$row][11])), $arrEventOrganizerTypes);
	
										$eventDetails['organizer_type'] = $oranizerType;
	
										$eventDetails['session_sponsor'] = trim($reader->sheets[$k]["cells"][$row][12]);
	
										$sponsorType = array_search(ucwords(trim($reader->sheets[$k]["cells"][$row][13])), $arrEventSponsorTypes);
	
										$eventDetails['sponsor_type'] = $sponsorType;
	
	
										//
										$eventDetails['location'] = trim($reader->sheets[$k]["cells"][$row][14]);
	
										$eventDetails['address'] = trim($reader->sheets[$k]["cells"][$row][15]);
										if (array_key_exists(ucwords(trim($reader->sheets[$k]["cells"][$row][16])), $arrCountries))
											$countryId = $arrCountries[ucwords(trim($reader->sheets[$k]["cells"][$row][16]))]['country_id'];
											$eventDetails['country_id'] = $countryId;
											$index = $countryId.'_'.ucwords(trim(str_replace(" ", "_", $reader->sheets[$k]["cells"][$row][17])));
											if (array_key_exists($index, $arrStatesAssociated)){
												$stateId = $arrStatesAssociated[$index]['state_id'];
											}
											$eventDetails['state_id'] = $stateId;
											$index = $countryId.'_'.$stateId.'_'.ucwords(trim(str_replace(" ", "_", $reader->sheets[$k]["cells"][$row][18])));
											if (array_key_exists($index, $arrCitiesAssociated)){
												$cityId = $arrCitiesAssociated[$index]['city_id'];
											}
											$eventDetails['city_id'] = $cityId;
											$eventDetails['postal_code'] = ucwords(trim($reader->sheets[$k]["cells"][$row][19]));
											$eventDetails['created_by'] = $this->loggedUserId;
											$eventDetails['created_on'] = date("Y-m-d H:i:s");
											$eventDetails['client_id'] = $this->session->userdata('client_id');
											$eventDetails['data_type_indicator'] = $profile_type;
	
											//Save only if the 'pin' is not blank
											if ($kolDetails['pin'] != "") {
												$kolId = $this->kol->getKolIdByPin($kolDetails['pin']);
												if ($kolId != 0) {
													$eventDetails['kol_id'] = $kolId;
													//$id						= $this->kol->saveEvent($eventDetails);
													$edcationDetailCount[$kolId]['kolId'] = $kolId;
													$arrEventsForBulk[] = $eventDetails;
												} else {
													$arrImportStatusMsg[$file1]['event']['no_matching_pin_num'][] = $kolDetails['pin'];
												}
											} else {
												//aray of Event having no 'pin'
												$arrImportStatusMsg[$file1]['event']['no_pin_num'][] = $event['name'];
											}
									}
								}
								foreach ($edcationDetailCount as $kolId => $values) {
									if (!(isset($edcationDetailCount[$kolId]['eventCount']))) {
										$edcationDetailCount[$kolId]['eventCount'] = $this->kol->getCountOfEvents($kolId);
									}
								}
								//	echo "End Time".(microtime(true)-$startTime);
								$arrImportStatusMsg[$file1]['event']['success'] = true;
								$this->kol->saveEventDetailByBulk($arrEventsForBulk);
					}
					//- End of processing the sheet - 'Event'
					//- End of processing the sheet - 'Publication'
					if (strcasecmp(trim($sheet['name']),'Publication')==0) {
						//echo "started publication<br />";
						//Check the Publication Info Header Format
						$row = 1;
						if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Article Title")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"PMID")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Journal Name")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Date")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Authors")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"Authorship Position")!=0) {
									$arrImportStatusMsg[$file1]['publication']['incorrect_format'] = 'Publication Info Header format is incorrect';
									break;
								}
								for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
									$kolDetails = array();
									$pubDetails = array();
									$kolDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
									$pubDetails['article_title'] = trim($reader->sheets[$k]["cells"][$row][2]);
									$pubDetails['pmid'] = trim($reader->sheets[$k]["cells"][$row][3]);
									//get journal name
									$journalName = '';
									$journalName = trim($reader->sheets[$k]["cells"][$row][4]);
									$pubDetails['created_date'] = $this->kol->convertDateToYYYYMMDD(trim($reader->sheets[$k]["cells"][$row][5]));
									//Considering this data also Manually added Import data
									$pubDetails['is_manual'] = 1;
									$pubDetails['link'] = trim($reader->sheets[$k]["cells"][$row][8]);
									$pubDetails['data_type_indicator'] = $profile_type;
									//For Authors
									//Currently considering as last name, initial, first name format
									$multipleAuthors = array();
									$authorsData = trim($reader->sheets[$k]["cells"][$row][6]);
									$arrAuthor = explode(',', $authorsData);
									foreach ($arrAuthor as $authors) {
										$lastName = '';
										$initials = '';
										$foreName = '';
										$authors = trim($authors);
										$singleAuthor = explode(" ", $authors);
										$singleAuthorStrings = array();
										foreach ($singleAuthor as $authString) {
											if ($authString != '')
												$singleAuthorStrings[] = $authString;
										}
										$singleAuthor = $singleAuthorStrings;
										if (sizeof($singleAuthor) > 0) {
											$lastName = trim($singleAuthor[0]);
										}
										//As per the CR Considering the last name and initial to insert. they will change in the ambiguity
										if (sizeof($singleAuthor) > 1) {
											$initials = trim($singleAuthor[1]);
										}
										if (sizeof($singleAuthor) > 2) {
											$initials = $initials . " " . trim($singleAuthor[2]);
										}
										$author['last_name'] = $lastName;
										$author['initials'] = $initials;
										$author['fore_name'] = '';
										$multipleAuthors[] = $author;
									}
									$authPosition = trim($reader->sheets[$k]["cells"][$row][7]);
									//Save only if the 'pin' is not blank
									if ($kolDetails['pin'] != "") {
										$kolId = $this->kol->getKolIdByPin($kolDetails['pin']);
										if ($kolId != 0) {
	
											//foreach($edcationDetailCount as $kolId=>$values){
											if (!(isset($edcationDetailCount[$kolId]['pubCount']))) {
												$edcationDetailCount[$kolId]['pubCount'] = $this->kol->getCountOfPubs($kolId);
											}
											//}
											$pmId = array();
											if ($pubDetails['pmid'] == '') {
												$pmId[] = $this->pubmed->getManualPmid();
												$pubDetails['pmid'] = $pmId[0];
											} else {
												//Check for the pmid. if its present then associate it with kol
												$arrUniquePMIDs = array($pubDetails['pmid']);
												//Returns the NEW pmid which is not there in database
												$pmId = $this->pubmed->checkAndAssociateAlreadyExistPubs($arrUniquePMIDs, $kolId, null, 1);
											}
	
											//If its new pmID then insert it into database
											if (sizeof($pmId) > 0) {
												$pubDetails['journal_id'] = $this->pubmed->savejournalName($journalName);
												$pubId = $this->pubmed->savePublicationsManualAndFlags($pubDetails, $kolId);
												//save 'publication-authors'
												$isSaved = $this->save_pub_authors($multipleAuthors, $pubId);
												$position = '';
												if (!empty($authPosition)) {
													$position = $authPosition;
												} else {
													//	Calculate Authorship position and save
													$position = $this->pubmed->calculateAuthorShipPosition($pubId, $kolId, null);
												}
												$this->pubmed->updateAuthorshipPos($kolId, $pubId, $position);
											} else {
												$arrImportStatusMsg[$file1]['publication']['pmid_exist'][] = $pubDetails['pmid'] . " :Is Exist and associated with the kol pin: " . $kolDetails['pin'];
												$pubId = $this->pubmed->checkPubExist($pubDetails['pmid']);
												if (!empty($authPosition)) {
													$position = $authPosition;
												} else {
													//	Calculate Authorship position and save
													$position = $this->pubmed->calculateAuthorShipPosition($pubId, $kolId, null);
												}
												//echo $pubId.':'.$kolId.':'.$position."-";
												$this->pubmed->updateAuthorshipPos($kolId, $pubId, $position);
											}
										} else {
											$arrImportStatusMsg[$file1]['publication']['no_matching_pin_num'][] = $kolDetails['pin'];
										}
									} else {
										//aray of publication having no 'pin'
										$arrImportStatusMsg[$file1]['publication']['no_pin_num'][] = $publication['pmid'];
									}
								}
								$arrImportStatusMsg[$file1]['publication']['success'] = true;
					}
					//- End of processing the sheet - 'Publication'
					//- End of processing the sheet - 'Clinical Trial'
					if (strcasecmp(trim($sheet['name']),'Trial')==0) {
						//echo "started trial<br />";
						//Check the Trial Info Header Format
						$row = 1;
						if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"CTID")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Study Type")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Trial Name")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Condition")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Intervention")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"Phase")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][8]),"Role")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][9]),"Number of enrollees")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][10]),"Number of trial sites")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][11]),"Sponsors")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][12]),"Status")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][13]),"Start Date")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][14]),"End Date")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][15]),"Minimum Age")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][16]),"Maximum Age")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][17]),"Gender")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][18]),"Investigators")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][19]),"Collaborator")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][20]),"Purpose")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][21]),"Official Title")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][22]),"Keywords")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][23]),"MeSH Terms")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][24]),"Url")!=0) {
									$arrImportStatusMsg[$file1]['trial']['incorrect_format'] = 'Trial Info Header format is incorrect';
									break;
								}
								for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
									$kolDetails = array();
									$trialDetails = array();
									$kolDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
									$trialDetails['ct_id'] = trim($reader->sheets[$k]["cells"][$row][2]);
									$trialDetails['study_type'] = trim($reader->sheets[$k]["cells"][$row][3]);
									$trialDetails['trial_name'] = trim($reader->sheets[$k]["cells"][$row][4]);
									$trialDetails['kol_role'] = trim($reader->sheets[$k]["cells"][$row][8]);
									$trialDetails['no_of_enrollees'] = trim($reader->sheets[$k]["cells"][$row][9]);
									$trialDetails['no_of_trial_sites'] = trim($reader->sheets[$k]["cells"][$row][10]);
									$trialDetails['start_date'] = trim($reader->sheets[$k]["cells"][$row][13]);
									$trialDetails['end_date'] = trim($reader->sheets[$k]["cells"][$row][14]);
									$trialDetails['min_age'] = trim($reader->sheets[$k]["cells"][$row][15]);
									$trialDetails['max_age'] = trim($reader->sheets[$k]["cells"][$row][16]);
									$trialDetails['gender'] = trim($reader->sheets[$k]["cells"][$row][17]);
									$trialDetails['collaborator'] = trim($reader->sheets[$k]["cells"][$row][19]);
									$trialDetails['purpose'] = trim($reader->sheets[$k]["cells"][$row][20]);
									$trialDetails['official_title'] = trim($reader->sheets[$k]["cells"][$row][21]);
									$trialKeywords = trim($reader->sheets[$k]["cells"][$row][22]);
									$trialMeshTerms = trim($reader->sheets[$k]["cells"][$row][23]);
									$trialDetails['link'] = trim($reader->sheets[$k]["cells"][$row][24]);
									$statusName = trim($reader->sheets[$k]["cells"][$row][12]);
									$trialDetails['data_type_indicator'] = $profile_type;
									//Considering this data also Manually added Import data
									$trialDetails['is_manual'] = 1;
	
	
									//As per the CR Sponcer and Investigators are separating by (;),semicolon
									//For sponcers
									$arrSponcers = array();
									$multipleSponcers = array();
									$multiSponcers = array();
									$sponcers = trim($reader->sheets[$k]["cells"][$row][11]);
									if ($sponcers != '') {
										$arrSponcers = explode(';', $sponcers);
										foreach ($arrSponcers as $singleSponcer) {
											$multipleSponcers['agency'] = $singleSponcer;
											$multiSponcers[] = $multipleSponcers;
										}
									}
									$trialDetails['condition'] = trim($reader->sheets[$k]["cells"][$row][5]);
									//For intervention
									$arrInterventions = array();
									$multipleInterventions = array();
									$multiInterventions = array();
									$interventions = trim($reader->sheets[$k]["cells"][$row][6]);
									if ($interventions != '') {
										$arrInterventions = explode(';', $interventions);
										foreach ($arrInterventions as $singleIntervention) {
											$multipleInterventions['name'] = $singleIntervention;
											$multiInterventions[] = $multipleInterventions;
										}
									}
									$trialDetails['phase'] = trim($reader->sheets[$k]["cells"][$row][7]);
									//For Investigators
									$arrInvestigator = array();
									$multipleInvestigators = array();
									$multiInvestigators = array();
									$investigators = trim($reader->sheets[$k]["cells"][$row][18]);
									if ($investigators != '') {
										$arrInvestigator = explode(';', $investigators);
										foreach ($arrInvestigator as $singleInvestigator) {
											$multipleInvestigators['last_name'] = $singleInvestigator;
											$multiInvestigators[] = $multipleInvestigators;
										}
									}
	
									//Save only if the 'pin' is not blank
									if ($kolDetails['pin'] != "") {
										$kolId = $this->kol->getKolIdByPin($kolDetails['pin']);
										if ($kolId != 0) {
	
											if (!(isset($edcationDetailCount[$kolId]['trialCount']))) {
												$edcationDetailCount[$kolId]['trialCount'] = $this->kol->getCountOfTrials($kolId);
											}
											$nctId = array();
											if ($trialDetails['ct_id'] == '') {
												$nctId[] = $this->clinical_trial->getManualCtid();
												$trialDetails['ct_id'] = $nctId[0];
											} else {
												//Check for the ct_id. if its present then associate it with kol
												$arrUniqueCTIDs = array($trialDetails['ct_id']);
												//Returns the NEW CTID which is not there in database
												$nctId = $this->clinical_trial->checkAndAssociateAlreadyExistClinicalTrials($arrUniqueCTIDs, $kolId);
											}
											//If its new CTID then insert it into database
											if (sizeof($nctId) > 0) {
												$statusId = $this->clinical_trial->saveStatus($statusName);
												$trialDetails['status_id'] = $statusId;
												$ctId = $this->clinical_trial->saveClinicalTrialsManualAndFlags($trialDetails, $kolId);
												if (sizeof($multiSponcers) > 0) {
													$isSaved = $this->clinical_trial->saveSponsers($multiSponcers, $ctId);
												}
												if (sizeof($multiInterventions) > 0) {
													$isSaved = $this->clinical_trial->saveInterventions($multiInterventions, $ctId);
												}
												if (sizeof($multiInvestigators) > 0) {
													$isSaved = $this->clinical_trial->saveInvestigators($multiInvestigators, $ctId);
												}
												if ($trialKeywords != '') {
													$arrTrialKeywords = explode(',', $trialKeywords);
													foreach ($arrTrialKeywords as $key => $keyword) {
														if ($keywordId = $this->clinical_trial->getKeywordIdByKeyword($keyword)) {
															//	echo 'Already exists '.$keyword;
														} else if ($keywordId = $this->clinical_trial->saveKeyword(array('name' => $keyword))) {
															//	echo 'New Keyword '.$keyword;
														}
														if (!empty($keywordId)) {
															$arrAssociateKeyword['keyword_id'] = $keywordId;
															$arrAssociateKeyword['cts_id'] = $ctId;
															$this->clinical_trial->saveCtKeyword($arrAssociateKeyword);
														}
													}
												}
												if ($trialMeshTerms != '') {
													$arrTrialMeshTerms = explode(',', $trialMeshTerms);
													foreach ($arrTrialMeshTerms as $key => $meshTerm) {
														if ($meshTermId = $this->clinical_trial->getMeshTermIdByMeshTerm($meshTerm)) {
															//	echo 'Already exists '.$keyword;
														} else if ($meshTermId = $this->clinical_trial->saveMeshterms(array('term_name' => $meshTerm))) {
															//	echo 'New Keyword '.$keyword;
														}
														if (!empty($meshTermId)) {
															$arrAssociateMeshTerm['term_id'] = $meshTermId;
															$arrAssociateMeshTerm['cts_id'] = $ctId;
															$this->clinical_trial->saveCtMeshterms($arrAssociateMeshTerm);
														}
													}
												}
											} else
												$arrImportStatusMsg[$file1]['trial']['ctid_exist'][] = $trialDetails['ct_id'] . " :Is Exist and associated with the kol pin: " . $kolDetails['pin'];
										}else {
											$arrImportStatusMsg[$file1]['trial']['no_matching_pin_num'][] = $kolDetails['pin'];
										}
									} else {
										//aray of trial having no 'pin'
										$arrImportStatusMsg[$file1]['trial']['no_pin_num'][] = $trialDetails['ct_id'];
									}
								}
								$arrImportStatusMsg[$file1]['trial']['success'] = true;
					}
					//- End of processing the sheet - 'Clinical Trials'
					// Start of processing the sheet - 'Social Media'
					if (strcasecmp(trim($sheet['name']),'Social Media')==0) {
						//echo "started social media<br />";
						//Check the Social Media Header Format
						$row = 1;
						if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Blog")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Linkedin")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Facebook")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Twitter")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"YouTube")!=0) {
									$arrImportStatusMsg[$file1]['media']['incorrect_format'] = 'Social Media Header format is incorrect';
									//break;
								}
								for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
									$kolsDetails = array();
									$kolsDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
									$kolsDetails['blog'] = trim($reader->sheets[$k]["cells"][$row][2]);
									$kolsDetails['linked_in'] = trim($reader->sheets[$k]["cells"][$row][3]);
									$kolsDetails['facebook'] = trim($reader->sheets[$k]["cells"][$row][4]);
									$kolsDetails['twitter'] = trim($reader->sheets[$k]["cells"][$row][5]);
									$kolsDetails['you_tube'] = trim($reader->sheets[$k]["cells"][$row][6]);
									//Update only if the 'pin' is not blank
									if ($kolsDetails['pin'] != "") {
										$id = $this->kol->updateImportedKol($kolsDetails);
										if ($id == false) {
											//array of 'pin' not present in database
											$arrImportStatusMsg[$file1]['media']['no_matching_pin_num'][] = $kolsDetails['pin'];
										}
									} else {
										//aray of media having no 'pin'
										$arrImportStatusMsg[$file1]['media']['no_pin_num'][] = $kolsDetails['linked_in'];
									}
								}
								$arrImportStatusMsg[$file1]['media']['success'] = true;
					}
					//- End of processing the sheet - 'Social Media'
					// Start of processing the sheet - 'PMIDs Only'
					if (strcasecmp(trim($sheet['name']),'PMIDs_only')==0) {
						//echo "started social media<br />";
						//Check the Social Media Header Format
						$row = 1;
						if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"Article Title")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"PMID")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Journal Name")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Date")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Authors")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"Authorship Position")!=0) {
									$arrImportStatusMsg['publication']['incorrect_format'] = 'Publication Info Header format is incorrect';
									break;
								}
								for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
									$kolsDetails = array();
									$kolsDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
									$kolsDetails['pmid'] = trim($reader->sheets[$k]["cells"][$row][3]);
									//Add only if the 'pin' is not blank
									if ($kolsDetails['pin'] != "") {
										$kolId = $this->kol->getKolIdByPin($kolsDetails['pin']);
										if ($kolId == false) {
											//array of 'pin' not present in database
											$arrImportStatusMsg['publication']['no_matching_pin_num'][] = $kolsDetails['pin'];
										} else {
											$status = $this->pubmed->savePMID($kolsDetails['pmid'], $kolId);
											if ($status == false)
												$arrImportStatusMsg['publication']['pmid_exist'][] = $kolsDetails['pmid'];
	
												$kolPubmedStatusData = array();
												$kolPubmedStatusData['id'] = $kolId;
												$kolPubmedStatusData['is_pubmed_processed'] = 2;
												$this->pubmed->updatePubmedProcessedKol($kolPubmedStatusData);
										}
									}else {
										//aray of media having no 'pin'
										$arrImportStatusMsg['publication']['no_pin_num'][] = $kolsDetails['linked_in'];
									}
								}
								$arrImportStatusMsg['publication']['success'] = true;
					}
					//- End of processing the sheet - 'PMIDs only'
					// Start of processing the sheet - 'CTIDs Only'
					if (strcasecmp(trim($sheet['name']),'CTIDs_only')==0) {
						//echo "started social media<br />";
						//Check the Social Media Header Format
						$row = 1;
						if (strcasecmp(trim($reader->sheets[$k]["cells"][$row][1]),"PIN")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][2]),"CTID")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][3]),"Study Type")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][4]),"Trial Name")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][5]),"Condition")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][6]),"Intervention")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][7]),"Phase")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][8]),"Role")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][9]),"Number of enrollees")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][10]),"Number of trial sites")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][11]),"Sponsors")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][12]),"Status")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][13]),"Start Date")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][14]),"End Date")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][15]),"Minimum Age")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][16]),"Maximum Age")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][17]),"Gender")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][18]),"Investigators")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][19]),"Collaborator")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][20]),"Purpose")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][21]),"Official Title")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][22]),"Keywords")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][23]),"MeSH Terms")!=0 ||
								strcasecmp(trim($reader->sheets[$k]["cells"][$row][24]),"Url")!=0) {
									$arrImportStatusMsg['trial']['incorrect_format'] = 'Trial Info Header format is incorrect';
									break;
								}
								for ($row = 2; $row <= count($reader->sheets[$k]["cells"]); $row++) {
									$kolsDetails = array();
									$kolsDetails['pin'] = trim($reader->sheets[$k]["cells"][$row][1]);
									$kolsDetails['ctid'] = trim($reader->sheets[$k]["cells"][$row][2]);
									//Add only if the 'pin' is not blank
									if ($kolsDetails['pin'] != "") {
										$kolId = $this->kol->getKolIdByPin($kolsDetails['pin']);
										if ($kolId == false) {
											//array of 'pin' not present in database
											$arrImportStatusMsg['trial']['no_matching_pin_num'][] = $kolsDetails['pin'];
										} else {
											$status = $this->clinical_trial->saveCTID($kolsDetails['ctid'], $kolId);
											if ($status == false)
												$arrImportStatusMsg['trial']['ctid_exist'][] = $kolsDetails['ctid'];
	
												$kolTrialStatusData = array();
												$kolTrialStatusData['id'] = $kolId;
												$kolTrialStatusData['is_clinical_trial_processed'] = 0;
												$this->clinical_trial->updateClinicalTrialProcessedKol($kolTrialStatusData);
										}
									}else {
										//aray of media having no 'pin'
										$arrImportStatusMsg['trial']['no_pin_num'][] = $kolsDetails['linked_in'];
									}
								}
								$arrImportStatusMsg['trial']['success'] = true;
					}
					//- End of processing the sheet - 'CTIDs only'
				}
				//- End of Looping through each sheets
				/* } else{
				$arrImportStatusMsg['professional']['upload_error']		= "Error in uploading file '".$_FILES["prof_import"]['name']."'";
				} */
				//- End of processing the EXCEL FILE
				/* }else{
				// Set the error message if the file is not of EXCEL
				$arrImportStatusMsg['professional']['file_type_missmatch']	= "Sorry! File is not the valid EXCEL FILE. Kindly upload the Valid Excel file with XLS or XLSX extension'";
				}
				} */
				//if($currentMethod == 'analyst_kol_import_page'){
				//pr($arrImportStatusMsg);
				//$data['arrImportStatusMsg'][]	= $arrImportStatusMsg;
				$data[$file1]['timeTaken'] = "Time Taken for Import " . $file1 . ": " . ( microtime(true) - $startTime) . "";
	
				/* }else{
				 $data['arrImportStatusMsg']	= $arrImportStatusMsg;
				 $data['contentPage'] 		= 'kols/kol_import_status';
				 //$this->load->view('layouts/client_view',$data);
				 } */
			}
			$data['arrImportStatusMsg'][] = $arrImportStatusMsg;
		}
		//Delete The uploaded file which is used to read the data.
		//unlink($uploadedFile);
	
	
		foreach ($edcationDetailCount as $key => $count) {
			$arrName = $this->kol->getKolName($key);
			$count['name'] = $arrName['first_name'] . " " . $arrName['middle_name'] . " " . $arrName['last_name'];
			if (isset($count['educationCount'])) {
				$eduCount = $this->kol->getCountOfEducations($key);
				$count['eduCountAfterImport'] = $eduCount - $count['educationCount'];
			}
			if (isset($count['affiliationCount'])) {
				$affCount = $this->kol->getCountOfAffiliation($key);
				$count['affCountAfterImport'] = $affCount - $count['affiliationCount'];
			}
			if (isset($count['eventCount'])) {
				$eventCount = $this->kol->getCountOfEvents($key);
				$count['eventCountAfterImport'] = $eventCount - $count['eventCount'];
			}
			if (isset($count['pubCount'])) {
				$pubCount = $this->kol->getCountOfPubs($key);
				$count['pubCountAfterImport'] = $pubCount - $count['pubCount'];
			}
	
	
			if (isset($count['trialCount'])) {
				$trialCount = $this->kol->getCountOfTrials($key);
				$count['trailCountAfterImport'] = $trialCount - $count['trialCount'];
			}
	
			$arrCounts[] = $count;
		}
		// Add the industry sponser events to industry affiliation
		//         pr($totalKolIds);
		//         exit;
		foreach ($totalKolIds as $key=>$val){
			$this->add_events_to_affiliations($val);
		}
		//pr($arrCounts);
		$data['arrCounts'] = $arrCounts;
		$data['contentPage'] = 'kols/kol_import_status';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
		//echo "Total Time Taken : ".( microtime(true)-$initialTime);
	}
	
	function add_events_to_affiliations($kolId = '',$eventId=''){
		$dataType = 'User Added';
		$client_id =$this->session->userdata('client_id');
		if($client_id == INTERNAL_CLIENT_ID){
			$dataType = 'Aissel Analyst';
		}
		$this->db->where("sponsor_type",2);
		//		$this->db->where("role","Speaker");
		if($kolId != '')
			$this->db->where("kol_id",$kolId);
			if($eventId != '')
				$this->db->where("id",$eventId);
				$arr = $this->db->get("kol_events");
				$arrData = array();
				//		echo $this->db->last_query();
				//		exit;
				foreach ($arr->result_array() as $row){
					//			pr($row);
					//			continue;
					if (strpos($row["start"], '/') !== FALSE){
						$start = $this->getYear($row["start"]);
					}else{
						$start = $this->common_helpers->getOnlyYearByDate($row["start"]);
					}
					if (strpos($row["end"], '/') !== FALSE){
						$end = $this->getYear($row["end"]);
					}else{
						$end = $this->common_helpers->getOnlyYearByDate($row["end"]);
					}
					$where = array();
					$where["kol_id"] = $row['kol_id'];
					$where["organizer"] = $row['session_sponsor'];
					$where["start"] = $start;
					$where["end"] = $end;
					$row['start'] = $start;
					$row['end'] = $end;
					$arrMembershipResult = $this->kol->getAllAffiliationsTypeIndustry('industry',$where);
					//			echo var_dump($arrMembershipResult);
	
					if(!$arrMembershipResult){
						//				$arrData[] = $row;
						$arrAffData = array();
						//                         $row["session_sponsor"] = mysqli_real_escape_string($row["session_sponsor"]);
						$orgName["name"] = $row["session_sponsor"];
						$instiId 						= $this->kol->getInstituteIdElseSave($orgName);
						$arrAffData["kol_id"] 			= $row["kol_id"];
						$arrAffData["engagement_id"] 	= 17;
						$arrAffData["type"] 			= "industry";
						$arrAffData["institute_id"] 	= $instiId;
						$arrAffData["start_date"] 		= $row["start"];
						$arrAffData["end_date"] 		= $row["end"];
						$arrAffData["role"] 			= "Speaker";
						$arrAffData["created_by"] 		= $this->loggedUserId;
						$arrAffData["created_on"] 		= date("Y-m-d H:i:s");
						$arrAffData["data_type_indicator"] 		= $dataType;
						$arrAffData["client_id"] 		= $this->session->userdata('client_id');
						$arrAffData["added_from"] 		= 1;
						$arrAffData["source_row_id"] 	= $row["id"];
						$this->db->insert('kol_memberships',$arrAffData);
						//                         echo $this->db->last_query();
						//                         				pr($arrAffData);
						//                         				exit;
					}
				}
				return true;
	
	}
	
	function list_imported_kols(){
		$data['arrClientList']=  $this->common_helper->getEntityById('clients',array ());
		$data['contentPage'] = 'kols/list_kols';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	
	function get_all_kols_available(){
		$page				= (int)$this->input->post('page'); // get the requested page
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$data				= array();
		$arrReturnData = array();
		$arrSalutations = array(0 => '', 1 => 'Dr.', 2 => 'Prof.', 3 => 'Mr.', 4 => 'Ms.');
		$arrKolData = $this->import->getAllKols();
		foreach ($arrKolData as $row) {
			$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
			$kolName = $arrSalutations[$row['salutation']] . ' ' . $row['kol_name'];
			$row['kol_link'] = '<a target="_blank" href="' . base_url() . 'kols/view/' . $row['kol_id'] . '">' . $kolName . '</a>';
			$arrReturnData[] = $row;
		}
		$count=sizeof($arrReturnData);
		if( $count >0 ){
			$total_pages = ceil($count/$limit);
		}else{
			$total_pages = 0;
		}
	
		$data['records']=$count;
		$data['total']=$total_pages;
		$data['page']=$page;
		$data['rows']=$arrReturnData;
		echo json_encode($data);
	}
	
	function get_kols_not_associated_with_client($clientId){
		$page				= (int)$this->input->post('page'); // get the requested page
		$limit				= (int)$this->input->post('rows'); // get how many rows we want to have into the grid
		$data				= array();
		$arrReturnData = array();
		$arrSalutations = array(0 => '', 1 => 'Dr.', 2 => 'Prof.', 3 => 'Mr.', 4 => 'Ms.');
		$arrKolData = $this->import->getKolsNotAssociatedWithClient($clientId);
		foreach ($arrKolData as $row) {
			$arrSalutations = array(0 => '', 'Dr.', 'Prof.', 'Mr.', 'Ms.');
			$kolName = $arrSalutations[$row['salutation']] . ' ' . $row['kol_name'];
			$row['kol_link'] = '<a target="_blank" href="' . base_url() . 'kols/view/' . $row['kol_id'] . '">' . $kolName . '</a>';
			$arrReturnData[] = $row;
		}
		$count=sizeof($arrReturnData);
		if( $count >0 ){
			$total_pages = ceil($count/$limit);
		}else{
			$total_pages = 0;
		}
	
		$data['records']=$count;
		$data['total']=$total_pages;
		$data['page']=$page;
		$data['rows']=$arrReturnData;
		echo json_encode($data);
	}
	/*
	 * @Author : Sanjeev K
	 * @Method : organizations_import()
	 * @Action : loads page of organization imports
	 */
	function organizations_import(){
		ini_set('memory_limit', '-1');
	
		$this->common_helper->checkUsers();
		$data['contentPage'] = 'organizations/organizations_import';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
	}
	
	function upload_zip_file_organizations(){
		//	$path_info = pathinfo($_FILES["overview_import"]['name']);
		$type = $this->input->post('university');
	
		if($type=='uni'){
			$dest = APPPATH. "documents/imports/org_imports/university/uploaded/".$_FILES["overview_import"]['name'];
		}else{
			$dest = APPPATH. "documents/imports/org_imports/payer/uploaded/".$_FILES["overview_import"]['name'];
		}
		move_uploaded_file($_FILES["overview_import"]['tmp_name'],$dest);
	
		$name = substr($_FILES["overview_import"]['name'],0,-4);
	
	
		$up_zip = new ZipArchive();
		$x = $up_zip->open($dest);
		if($x === true) {
			if($type=='uni'){
				$up_zip->extractTo(APPPATH."documents/imports/org_imports/university/uploaded");
			}else{
				$up_zip->extractTo(APPPATH."documents/imports/org_imports/payer/uploaded/");
			}
			$up_zip->close();
			if($type=='uni'){
				$unzip_path = APPPATH."documents/imports/org_imports/university/uploaded".$name;
			}else{
				$unzip_path = APPPATH."documents/imports/org_imports/payer/uploaded/".$name;
			}
			chmod($unzip_path,0777);
			//unlink($zip_path);
		}
	
		$arrUHFiles = array();
		if($type=='uni'){
			$path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."application/documents/imports/org_imports/university/uploaded/";
		}else{
			$path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."application/documents/imports/org_imports/payer/uploaded/";
		}
	
		if ($handle = opendir($path)) {
			/* This is the correct way to loop over the directory. */
	
			$chk = substr($entry,-4);
			if($chk!='.zip'){
				if(is_dir($path.$name)){
	
					if ($handle1 = opendir($path.$name)) {
							
						while (false !== ($entry1 = readdir($handle1))) {
	
							if($entry1 !='.' && $entry1 !='..' && $entry1 !='.svn'){
								$arrUHFiles[$name][] = $entry1;
							}
						}
	
					}
	
				}
	
			}
		}
		$data['arrProfiles'] = $arrUHFiles;
		$data['type'] = $type;
		$data['contentPage'] = 'organizations/list_import_files';
		$data['showNavBar']=false;
		$this->load->view(ANALYST_HEADER,$data);
		//	pr($arrUHFiles);
	}
	function read_and_import_org_files(){
		ini_set("max_execution_time",7200);
		$arrCountries	=$this->Country_helper->listCountries();
		$arrStates		=$this->Country_helper->listStates();
		$arrCities		=$this->Country_helper->listCities();
		$arrKeyPeopleRoles=$this->organization->getAllKeyPeopleRoles();
		$organizationTypes=$this->organization->getAllOrganizationTypes();
			
		// Load the plugin
		$this->load->plugin('excelReader/reader2');
		$userId		=$this->session->userdata('user_id');
		$clientId	=$this->session->userdata('client_id');
		$initialTime = microtime(true);
		ini_set("memory_limit","2000M");
		$uhPath = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_profiles/uh/";
		//$arrUHFiles = $this->input->post('uh_files');
	
		$files = $this->input->post('files');
		$arrFiles = array();
		$organizationDetailCount = array();
		foreach($files as $row){
			$pos = strpos($row,'&');
			$folderNAme = substr($row,0,$pos);
			$arrFiles[$folderNAme][]=substr($row,$pos+1);
		}
		foreach($arrFiles as $folderName=>$uniFiles) {
			foreach($uniFiles as $name){
				$arrImportStatusMsg[$name]=array();
				$startTime = microtime(true);
				// Increasing the max execution time to pasrse all sheet data
	
				$orgID		= 0;
				$target_path = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_imports/university/uploaded/";
				$overviewFileName	= random_string('unique', 20);
				$name= str_replace(';', '', $name);
				$overview_file_target_path = $target_path . "/".$folderName."/".$name;
				if(true){
					if(true){
						if(true) {
							$reader				=	new Spreadsheet_Excel_Reader($overview_file_target_path, true, 'utf-8');
							//loop through each sheet
							foreach($reader->sheets as $k=>$details){
								//Parsing of 1st sheet  - Overview: $k = index of the sheet
								if($k==0){
									$numColumns=0;
									$existingOrgs=array();
									$row=1;
									foreach($details['cells'] as $data){
										if($row==1){
											//condition to check whether format of the column is correct or not
											if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="COMPANY TYPE" || trim($data[4])!="LOGO" || trim($data[5])!="WEBSITE"
													|| trim($data[6])!="COMPANY HEADQUARTERS" || trim($data[7])!="COMPANY BACKGROUND" || trim($data[8])!="MISSION, VISION & VALUES"  ||trim($data[9])!="FOUNDED" || trim($data[10])!="NPI NUMBER"){
														$arrImportStatusMsg[$name]['overview']['incorrect_format']='Uploaded File format is incorrect';
														break;
											}
											$numColumns=sizeof($data);
										}
										$organizationDetails=array();
										if($row>1){
											for($i=1;$i<=$numColumns;$i++){
												if(!isset($data[$i]))
													$data[$i]="";
											}
											$organizationDetails['cin_num']=trim($data[1]);
											//$organizationDetails['name']=ucwords(trim($data[2]));
											$organizationDetails['name']=trim($data[2]);
											$orgType=array_search(trim($data[3]),$organizationTypes);
											$organizationDetails['type_id']=$orgType;
											$organizationDetails['company_logo']=trim($data[4]);
											$organizationDetails['website']=trim($data[5]);
											$organizationDetails['headquarters']=trim($data[6]);
											$organizationDetails['background']=trim($data[7]);
											$organizationDetails['mission_vision']=trim($data[8]);
											$organizationDetails['founded']=trim($data[9]);
											$organizationDetails['npi_num']=trim($data[10]);
											$organizationDetails['profile_type'] = FULL;
											$profilType = trim($data[11]);
											if($profilType=='Basic'){
												$organizationDetails['profile_type'] =BASIC;
											}
											if($profilType=='Full Profile'){
												$organizationDetails['profile_type'] =FULL;
											}
											$organizationDetails['url']=trim($data[12]);
											$organizationDetails['status']=New1;
											$organizationDetails['created_by']	=$userId;
											$organizationDetails['created_on']	=date("Y-m-d H:i:s");
											//Save only if the 'cin_num' is not blank
											if($organizationDetails['cin_num']!=""){
												$id=$this->organization->saveOrganization($organizationDetails);
												//  echo $this->db->last_query();
												if($id==false){
													//array of already existing organizations
													$existingOrgs[]=$organizationDetails['name'].' has been updated';
												}else{
													$orgID	= $id;
												}
											}else{
												//aray of organizations having no 'cin_num'
												$arrImportStatusMsg[$name]['overview']['no_cin_num'][]= $organizationDetails['name'];
											}
												
										}
										$row++;
										$arrImportStatusMsg[$name]['overview']['success']=true;
									}
									$arrImportStatusMsg[$name]['overview']['existingOrgs']=$existingOrgs;
	
								}
									
								else if($k==1){
									//Parsing of 2st sheet  - Adress: $k = index of the sheet
									$numColumns=0;
									$row=1;
									foreach ($details['cells'] as $data) {
										//check wherether format is correct or not
										if($row==1){
											if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="ADDRESS" || trim($data[4])!="CITY" || trim($data[5])!="POSTAL CODE"
													|| trim($data[6])!="STATE" || trim($data[7])!="COUNTRY" || trim($data[8])!="PHONE" || trim($data[9])!="FAX" || trim($data[10])!="ADDITIONAL PHONE NUMBERS"){
														$arrImportStatusMsg[$name]['address']['incorrect_format']='Uploaded File format is incorrect';
														break;
											}
											$numColumns=sizeof($data);
										}
										$organizationDetails=array();
										if($row>1){
											for($i=1;$i<=$numColumns;$i++){
												if(!isset($data[$i]))
													$data[$i]="";
											}
											$countryId=0;
											$stateId=0;
											$cityId=0;
											$organizationDetails['cin_num']=trim($data[1]);
											$organizationDetails['name']=trim($data[2]);
											$organizationDetails['address']=trim($data[3]);
	
											/*if(array_key_exists(ucwords(trim($data[4])),$arrCities))
											 $cityId=$arrCities[ucwords(trim($data[4]))]['city_id'];
											 $organizationDetails['city_id']=$cityId;*/
	
											$organizationDetails['postal_code']=trim($data[5]);
											if(array_key_exists(ucwords(trim($data[6])),$arrStates))
												$stateId=$arrStates[ucwords(trim($data[6]))]['state_id'];
												$organizationDetails['state_id']=$stateId;
												$city					= ucwords(trim($data[4]));
												if($city!=''){
													$organizationDetails['city_id']= $this->kol->getCityIdByState($city,$stateId);
												}
	
												if(array_key_exists(ucwords(trim($data[7])),$arrCountries))
													$countryId=$arrCountries[ucwords(trim($data[7]))]['country_id'];
													$organizationDetails['country_id']=$countryId;
													$organizationDetails['phone']=trim($data[8]);
													$organizationDetails['fax']=trim($data[9]);
													$faxDetails=explode(" ",$organizationDetails['fax']);
													$arrFaxValues=array();
													$faxNumber="";
													foreach($faxDetails as $value){
														if(strpos($value, "+")!=false){
															$faxNumber.=trim($value);
														}
														if(is_numeric($value)){
															$faxNumber.=trim($value);
														}
													}
													$organizationDetails['addr_url']=trim($data[11]);
													$organizationDetails['email']=trim($data[12]);
													$organizationDetails['created_by']	=$userId;
													$organizationDetails['created_on']	=date("Y-m-d H:i:s");
														
													//Save only if the 'cin_num' is not blank
													if($organizationDetails['cin_num']!=""){
														$orgID =$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
														if($orgID>0){
															$organizationDetails['id']	= $orgID;
														}
														$id=$this->organization->updateImportedOrganization($organizationDetails);
														if($id==false){
															//array of 'cin_num' not present in database
															$arrImportStatusMsg[$name]['address']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
														}
													}else{
														//aray of organizations  having no 'cin_num'
														$arrImportStatusMsg[$name]['address']['no_cin_num'][]= $organizationDetails['name'];
													}
														
													//Parsing and saving additional contact details
													if($organizationDetails['cin_num']!=""){
														$arrContactDetails=array();
														$orgId=$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
														$aditionalContats=trim($data[10]);
														$arrAditionalContactDetails=explode("\n",$aditionalContats);
														foreach($arrAditionalContactDetails as $aditionalContat){
															$contactDetails=array();
															$phNumber="";
															$relatedTo="";
															if(strpos($aditionalContat, "-")!=false){
																$aditionalContatDetails=explode("-",$aditionalContat);
																foreach($aditionalContatDetails as $value){
																	if(strpos($value, "+")!=false){
																		$phNumber.=trim($value);
																	}else if(is_numeric($value)){
																		$phNumber.=trim($value);
																	}else {
																		$relatedTo.=trim($value);
																	}
																}
															}else if(strpos($aditionalContat, ":")!=false){
																	
																//echo $aditionalContat;
																$aditionalContatDetails=explode(":",$aditionalContat);
																$contactDetails['related_to']=$aditionalContatDetails[0];
																$contactDetails['phone']=$aditionalContatDetails[1];
															}else{
																$aditionalContatDetails=explode(" ",$aditionalContat);
															}
															$arrContactDetails[]=$contactDetails;
														}
														if($orgId!=0){
															//save additional contact details
															foreach($arrContactDetails as $row){
																$row['org_id']=$orgId;
																$row['created_by']	=$userId;
																$row['created_on']	=date("Y-m-d H:i:s");
																$this->organization->saveContact($row);
															}
														}else{
															//set error details
														}
													}
										}
										$row++;
										$arrImportStatusMsg[$name]['address']['success']=true;
									}
								}
								else if($k==2){
									$bulkInsertOfMedical =array();
									$medicalService =1;
									//Parsing of 3st sheet  - Mediacal Services: $k = index of the sheet
									$numColumns=0;
									$row=1;
										
									foreach($details['cells'] as $key=>$data) {
										if($row==1){
											if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!='MEDICAL SERVICES' || trim($data[4])!='URL'){
												$arrImportStatusMsg[$name]['mediacal_services']['incorrect_format']='Uploaded File format is incorrect';
												break;
											}
											$numColumns=sizeof($data);
										}
										$medicalServiceDataDetails=array();
										if($row>1){
											for($i=1;$i<=$numColumns;$i++){
												if(!isset($data[$i]))
													$data[$i]="";
											}
											$cinNum  = trim($data[1]);
											//$orgName =ucwords(trim($data[2]));
											$orgName =trim($data[2]);
												
											$medicalServiceName=trim($data[3]);
											$medicalServiceDataDetails['url'] = trim($data[4]);
											if($medicalServiceName!=''){
												$medicalServiceDataDetails['medical_service_id'] = $this->organization->saveOrgMedicalService($medicalServiceName);
	
											}
											//Save only if the 'cin_num' is not blank
											if($cinNum!=""){
												$orgID	= $this->organization->getOrgIdBySinNumber($cinNum);
												$medicalServiceDataDetails['org_id'] =$orgID;
												if($orgID==0){
													//array of 'cin_num' not present in database
													$arrImportStatusMsg[$name]['mediacal_services']['no_matching_cin_num'][]= $cinNum;
												}else{
	
													if(!(isset($organizationDetailCount[$orgID]['medicalCount']))){
														$organizationDetailCount[$orgID]['medicalCount'] = $this->organization->getCountOfMedical($orgID);
														//echo $this->db->last_query();
													}
													$bulkInsertOfMedical[] = $medicalServiceDataDetails;
	
	
													//$this->organization->saveOrgMediacalAssociation($medicalServiceDataDetails);
													//echo $this->db->last_query();
												}
											}else{
												//aray of address detains having no 'cin_num'
												$arrImportStatusMsg[$name]['mediacal_services']['no_cin_num'][]= $orgName;
											}
												
										}
										$row++;
										$arrImportStatusMsg[$name]['mediacal_services']['success']=true;
									}
	
									//pr($organizationDetailCount);
									$this->organization->OrgMediacalServicesByBulk($bulkInsertOfMedical);
									//	exit();
	
								}
								else if($k==3){
									$arrAffliationDetails = array();
									//Parsing of 3st sheet  - Affiliate patnership: $k = index of the sheet
									$numColumns=0;
									$row=1;
									foreach($details['cells'] as $key=>$data) {
										if($row==1){
											if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!='INSTITUTE NAME'
													|| trim($data[4])!='ADDRESS' || trim($data[5])!='CITY' || trim($data[6])!='POSTAL CODE'
													|| trim($data[7])!='STATE'|| trim($data[8])!='COUNTRY'|| trim($data[9])!='PHONE' ||   trim($data[10])!='NPI NUMBER'
													){
														$arrImportStatusMsg[$name]['affiliate_patnership']['incorrect_format']='Uploaded File format is incorrect';
														break;
											}
											$numColumns=sizeof($data);
										}
										$otherLoactionDetails=array();
										if($row>1){
											for($i=1;$i<=$numColumns;$i++){
												if(!isset($data[$i]))
													$data[$i]="";
											}
											$cinNum  = trim($data[1]);
											//$orgName =ucwords(trim($data[2]));
											$orgName =trim($data[2]);
											$subOrgName = trim($data[3]);
											//$subOrgName = ucwords($subOrgName);
											$otherLoactionDetails['address'] = trim($data[4]);
	
											/*if(array_key_exists(ucwords(trim($data[5])),$arrCities))
											 $cityId=$arrCities[ucwords(trim($data[5]))]['city_id'];
											 $otherLoactionDetails['city_id']=$cityId;*/
	
											$otherLoactionDetails['postal_code']=trim($data[6]);
											if(array_key_exists(ucwords(trim($data[7])),$arrStates))
												$stateId=$arrStates[ucwords(trim($data[7]))]['state_id'];
												$otherLoactionDetails['state_id']=$stateId;
	
												$city					= ucwords(trim($data[5]));
												if($city!=''){
													$otherLoactionDetails['city_id']= $this->kol->getCityIdByState($city,$stateId);
												}
	
												if(array_key_exists(ucwords(trim($data[8])),$arrCountries))
													$countryId=$arrCountries[ucwords(trim($data[8]))]['country_id'];
													$otherLoactionDetails['country_id']=$countryId;
														
													$otherLoactionDetails['phone']=$data[9];
													$otherLoactionDetails['npi_num']=$data[10];
													$otherLoactionDetails['url']=$data[11];
	
													if($cinNum!=''){
														$otherLoactionDetails['org_id'] =$this->organization->getOrgIdBySinNumber($cinNum);
														if($otherLoactionDetails['org_id']!=0){
															//echo $this->db->last_query();
															$orgDetails['name'] = $subOrgName;
															$orgDetails['address'] = $otherLoactionDetails['address'];
															$orgDetails['city_id']=$otherLoactionDetails['city_id'];
															$orgDetails['state_id']=$otherLoactionDetails['state_id'];
															$orgDetails['country_id']=$otherLoactionDetails['country_id'];
															$orgDetails['postal_code']=$otherLoactionDetails['postal_code'];
															$orgDetails['email']=trim($data[12]);
															$orgDetails['phone']=$otherLoactionDetails['phone'];
															$orgDetails['status'] ='new';
															$orgDetails['created_by']	=$userId;
															$orgDetails['created_on']	=date("Y-m-d H:i:s");
															$otherLoactionDetails['sub_org_id'] = $this->organization->getOrgId($orgDetails);
															$arrAffliationDetails[]=$otherLoactionDetails;
															if(!(isset($organizationDetailCount[$otherLoactionDetails['org_id']]['affiliateCount']))){
																$organizationDetailCount[$otherLoactionDetails['org_id']]['affiliateCount'] = $this->organization->getCountOfAffiliates($otherLoactionDetails['org_id']);
																//echo $this->db->last_query();
															}
															$this->organization->saveAffiliatesPartnerships($otherLoactionDetails);
														}else{
																
															$arrImportStatusMsg[$name]['affiliate_patnership']['no_matching_cin_num'][]= $cinNum;
														}
													}else{
														//aray of address detains having no 'cin_num'
														$arrImportStatusMsg[$name]['affiliate_patnership']['no_cin_num'][]=$orgName;
													}
										}
										$row++;
										$arrImportStatusMsg[$name]['other_locations']['success']=true;
									}
	
									//$this->organization->saveAffiliatesPartnershipsBulk($arrAffliationDetails);
								}
	
								else if($k==4){
									//Parsing of 3st sheet  - Social Media : $k = index of the sheet
									$numColumns=0;
									$row=1;
									foreach($details['cells'] as $data) {
										if($row==1){
											if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="BLOG" || trim($data[4])!="YOUTUBE" || trim($data[5])!="LINKEDIN"
									 			|| trim($data[6])!="FACEBOOK" || trim($data[7])!="TWITTER" ){
									 				$arrImportStatusMsg[$name]['social_media']['incorrect_format']='Uploaded File format is incorrect';
									 				break;
											}
											$numColumns=sizeof($data);
										}
										$organizationDetails=array();
										if($row>1){
											for($i=1;$i<=$numColumns;$i++){
												if(!isset($data[$i]))
													$data[$i]="";
											}
											$organizationDetails['cin_num']=trim($data[1]);
											//$organizationDetails['name']=ucwords(trim($data[2]));
											$organizationDetails['name']=trim($data[2]);
												
											$organizationDetails['blog']=trim($data[3]);
											$organizationDetails['youtube']=trim($data[4]);
											$organizationDetails['linkedin']=trim($data[5]);
											$organizationDetails['facebook']=trim($data[6]);
											//$organizationDetails['myspace']=trim($data[7]);
											$organizationDetails['twitter']=trim($data[7]);
												
											$organizationDetails['created_by']	=$userId;
											$organizationDetails['created_on']	=date("Y-m-d H:i:s");
												
											//Save only if the 'cin_num' is not blank
											if($organizationDetails['cin_num']!=""){
												$orgID	= $this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
												if($orgID>0){
													$organizationDetails['id']	= $orgID;
												}
												$id=$this->organization->updateImportedOrganization($organizationDetails);
												if($id==false){
													//array of 'cin_num' not present in database
													$arrImportStatusMsg[$name]['social_media']['no_matching_cin_num'][]= $organizationDetails['name'];
												}
											}else{
												//aray of address detains having no 'cin_num'
												$arrImportStatusMsg[$name]['social_media']['no_cin_num'][]= $organizationDetails['name'];
											}
												
										}
										$row++;
										$arrImportStatusMsg[$name]['social_media']['success']=true;
									}
								}
								else if($k==5){
									$arrKeyPeopleDetails = array();
									$kePeople=1;
									//Parsing of 4th sheet  -key_people: $k = index of the sheet
									$numColumns=0;
									$row=1;
									$arrSalutations	= array(''=>0,'Dr.' => 1, 'Prof.' => 2, 'Mr.' => 3, 'Ms.' =>4);
									foreach($details['cells'] as $data) {
										if($row==1){
											if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="ROLE" || trim($data[4])!="SALUTATION" || trim($data[5])!="FIRST NAME"
													|| trim($data[6])!="MIDDLE NAME" || trim($data[7])!="LAST NAME" || trim($data[8])!="DEPARTMENT/DIVISION/CENTER" || trim($data[9])!="TITLE" || trim($data[10])!="EMAIL" ){
														$arrImportStatusMsg[$name]['key_people']['incorrect_format']='Uploaded File format is incorrect';
														break;
											}
											$numColumns=sizeof($data);
										}
										$organizationDetails=array();
										if($row>1){
											for($i=1;$i<=$numColumns;$i++){
												if(!isset($data[$i]))
													$data[$i]="";
											}
											$organizationDetails['cin_num']=trim($data[1]);
											//$organizationDetails['name']=ucwords(trim($data[2]));
											$organizationDetails['name']=trim($data[2]);
											$roleId=array_search(trim(strtolower($data[3])),array_map('strtolower',$arrKeyPeopleRoles));//array_search(trim($data[3]),$arrKeyPeopleRoles);
											$keyPeopleDetails['role_id']=$roleId;
											$keyPeopleDetails['salutation']=$arrSalutations[trim($data[4])];
											$keyPeopleDetails['first_name']=trim($data[5]);
											$keyPeopleDetails['middle_name']=trim($data[6]);
											$keyPeopleDetails['last_name']=trim($data[7]);
											$keyPeopleDetails['department']=trim($data[8]);
											$keyPeopleDetails['title']=trim($data[9]);
											$keyPeopleDetails['email']=trim($data[10]);
											$keyPeopleDetails['url']=trim($data[11]);
												
											$keyPeopleDetails['created_by']	=$userId;
											$keyPeopleDetails['created_on']	=date("Y-m-d H:i:s");
											//Save only if the 'cin_num' is not blank
											if($organizationDetails['cin_num']!=""){
												$orgId=$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
												if($orgId==0){
													$orgId=$this->organization->getOrgIdByOrgName($organizationDetails['name']);
												}
												if($orgId!=0){
													$keyPeopleDetails['org_id']=$orgId;
													//if($kePeople ==1){
													//$this->organization->deleteKeyPeopleByOrgId($orgId);
													//$kePeople++;
													//}
													if(!(isset($organizationDetailCount[$orgId]['keyPeopleCount']))){
														$organizationDetailCount[$orgId]['keyPeopleCount'] = $this->organization->getCountOfKeyPeople($orgId);
														//echo $this->db->last_query();
													}
	
													$arrKeyPeopleDetails[] = $keyPeopleDetails;
													//$this->organization->saveKeyPeople($keyPeopleDetails);
											}else{
													
												$arrImportStatusMsg[$name]['key_people']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
											}
										}else{
											//aray of address detains having no 'cin_num'
											$arrImportStatusMsg[$name]['key_people']['no_cin_num'][]= $organizationDetails['name'];
										}
											
									}
									$row++;
									$arrImportStatusMsg[$name]['key_people']['success']=true;
								}
	
								$this->organization->saveKeyPeopleBulk($arrKeyPeopleDetails);
							}
								
							else if($k==7){
								$fact=1;
								//Parsing of 7th sheet  - Stats Facts: $k = index of the sheet
								foreach($details['cells'] as $factKey=>$facts){
									if($factKey==1){
										if(trim($facts[1])!="CIN NUM" || trim($facts[2])!="COMPANY NAME" || trim($facts[3])!="NO. OF BEDS"){
											$arrImportStatusMsg[$name]['stats_facts']['incorrect_format']='Uploaded File format is incorrect';
											break;
										}
											
										if(trim($facts[4])!="INPATIENT"  || trim($facts[5])!="BIRTHS" || trim($facts[6])!="OUTPATIENT"){
											$arrImportStatusMsg[$name]['stats_facts']['incorrect_format']='Uploaded File format is incorrect';
											break;
										}
											
										if( trim($facts[7])!="EMERGENCY DEPARTMENT" || trim($facts[8])!="NO. OF SURGERIES" ){
											$arrImportStatusMsg[$name]['stats_facts']['incorrect_format']='Uploaded File format is incorrect';
											break;
										}
										$numColumns=sizeof($facts);
									}
									if($factKey!=1){
										$factDataDetails=array();
										$cinNum = $facts[1];
											
										$factDataDetails["no_of_beds"] 		= $facts[3];
										$factDataDetails["inpatient"]		= $facts[4];
											
										$factDataDetails["births"] 	 	    = $facts[5];
										$factDataDetails['outpatient']		= $facts[6];
										$factDataDetails["emergency_department"] 	  = $facts[7];
										$factDataDetails["no_of_surgeries"] 	  	  = $facts[8];
										$factDataDetails['link1'] = $facts[9];
										$factDataDetails['link2'] = $facts[10];
										if($cinNum!=''){
											$factDataDetails['org_id'] =$this->organization->getOrgIdBySinNumber($cinNum);
											if($factDataDetails['org_id']!=0){
												$this->organization->orgStatsFacats($factDataDetails);
												///if($fact==1){
												//$this->organization->deleteFacts($orgId);
												//$fact++;
												//}
													
										}else{
												
											$arrImportStatusMsg[$name]['stats_facts']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
										}
									}else{
										//aray of address detains having no 'cin_num'
										$arrImportStatusMsg[$name]['stats_facts']['no_cin_num'][]= $organizationDetails['name'];
									}
								}
								$arrImportStatusMsg[$name]['stats_facts']['success']=true;
									
							}
						}
						else if($k==8){
							//Parsing of 8th sheet  - Publication: $k = index of the sheet
							foreach($details['cells'] as $sub=>$orgPubData){
								if($sub==1){
									if(trim($orgPubData[1])!="CIN NUM" || trim($orgPubData[2])!="COMPANY NAME" || trim($orgPubData[3])!="Article Title" ||  trim($orgPubData[4])!="PMID" || trim($orgPubData[5])!="Journal Name" || trim($orgPubData[6])!="Date" || trim($orgPubData[7])!="Authors" ){
										$arrImportStatusMsg[$name]['publication']['incorrect_format']='Uploaded File format is incorrect';
										break;
									}
										
									$numColumns=sizeof($data);
								}
								if($sub!=1){
									$orgPubDetails=array();
									$cinNum = $orgPubData[1];
									$orgName =$orgPubData[2];
									$orgPubDetails['pmid'] = $orgPubData[4];
										
									if($cinNum!=""){
										$orgPubDetails['org_id'] =$this->organization->getOrgIdBySinNumber($cinNum);
										if($orgPubDetails['org_id'] ==0){
											//array of 'pin' not present in database
											$arrImportStatusMsg[$name]['publication']['no_matching_cin_num'][]= $cinNum;
										}else{
												
											if(!(isset($organizationDetailCount[$orgPubDetails['org_id']]['pmidCount']))){
												$organizationDetailCount[$orgPubDetails['org_id']]['pmidCount'] = $this->organization->getCountOfPmids($orgPubDetails['org_id']);
												//echo $this->db->last_query();
											}
											$status = $this->pubmed_org->saveOrgPMID($orgPubDetails);
											if($status == false)
												$arrImportStatusMsg[$name]['publication']['pmid_exist'][]= $orgPubDetails['pmid'];
													
												$orgPubmedStatusData = array();
												$orgPubmedStatusData['id'] = $orgPubDetails['org_id'];
												$orgPubmedStatusData['is_pubmed_processed'] = 2;
												$this->pubmed_org->updatePubmedProcessedOrg($orgPubmedStatusData);
										}
									}else{
										//aray of media having no 'pin'
										$arrImportStatusMsg[$name]['publication']['no_pin_num'][]=  $orgName;
									}
								}
								$arrImportStatusMsg[$name]['publication']['success']=true;
									
							}
								
						}
						else if($k==9){
							//Parsing of 9th sheet  - Trial: $k = index of the sheet
							foreach($details['cells'] as $sub=>$orgClinicalData){
								if($sub==1){
									if(trim($orgClinicalData[1])!="CIN NUM" || trim($orgClinicalData[2])!="COMPANY NAME" || trim($orgClinicalData[3])!="CTID" ||
											trim($orgClinicalData[4])!="Study Type" || trim($orgClinicalData[5])!="Trial Name" ||
											trim($orgClinicalData[6])!="Condition" || trim($orgClinicalData[7])!="Intervention" ||
											trim($orgClinicalData[8])!="Phase" || trim($orgClinicalData[9])!="Number of enrollees" ||
											trim($orgClinicalData[10])!="Number of trial sites" || trim($orgClinicalData[11])!="Sponsors" ||
											trim($orgClinicalData[12])!="Status" || trim($orgClinicalData[13])!="Start Date" ||
											trim($orgClinicalData[14])!="End Date" || trim($orgClinicalData[15])!="Minimum Age" || trim($orgClinicalData[16])!="Maximum Age" ||
											trim($orgClinicalData[17])!="Gender" || trim($orgClinicalData[18])!="Investigators" ||
											trim($orgClinicalData[19])!="Collaborator" || trim($orgClinicalData[20])!="Purpose" ||
											trim($orgClinicalData[21])!="Official Title" || trim($orgClinicalData[22])!="Keywords" ||
											trim($orgClinicalData[23])!="MeSH Terms"
	
											){
												$arrImportStatusMsg[$name]['trial']['incorrect_format']='Uploaded File format is incorrect';
												break;
									}
									$numColumns=sizeof($data);
								}
								if($sub!=1){
									$orgClinicalDetails=array();
									$cinNum = $orgClinicalData[1];
									$orgName =$orgClinicalData[2];
									$orgClinicalDetails['ctid'] = $orgClinicalData[3];
										
									if($cinNum!=""){
										$orgClinicalDetails['org_id'] =$this->organization->getOrgIdBySinNumber($cinNum);
											
										if($orgClinicalDetails['org_id']==0){
											//array of 'pin' not present in database
											$arrImportStatusMsg[$name]['trial']['no_matching_cin_num'][]= $cinNum;
										}else{
											if(!(isset($organizationDetailCount[$orgClinicalDetails['org_id']]['ctidCount']))){
												$organizationDetailCount[$orgClinicalDetails['org_id']]['ctidCount'] = $this->organization->getCountOfCtids($orgClinicalDetails['org_id']);
												//echo $this->db->last_query();
											}
											$status = $this->clinical_trial_org->saveCTID($orgClinicalDetails);
											if($status == false)
												$arrImportStatusMsg[$name]['trial']['ctid_exist'][]= $orgClinicalDetails['ctid'];
													
												$orgTrialStatusData = array();
												$orgTrialStatusData['id'] = $orgClinicalDetails['org_id'];
												$orgTrialStatusData['is_clinical_trial_processed'] = 0;
												$this->clinical_trial_org->updateClinicalTrialProcessedKol($orgTrialStatusData);
										}
									}else{
											
										$arrImportStatusMsg[$name]['trial']['no_cin_num'][]= $orgName;
									}
								}
								$arrImportStatusMsg[$name]['trial']['success']=true;
									
							}
								
						}
					}
				}
			}
			else{
				$arrImportStatusMsg['overview']['file_type_missmatch']="file type is not 'xls'";
			}
		}
			
		//$data['arrImportStatusMsg']=$arrImportStatusMsg;
		////$data['contentPage'] 	=	'organizations/view_import_status';
		$data['timeTaken']		=	"Time Taken for Import ".$entry.": ".( microtime(true)-$startTime)."";
		//	;
	}
	$data['arrImportStatusMsg'][] = $arrImportStatusMsg;
	//pr($data);
	
	
	}
	
	
	foreach($organizationDetailCount as $key=>$row){
		$row['id']=$key;
		$row['name'] = $this->organization->getOrgNameByOrgId($row['id']);
			
		if(isset($row['medicalCount'])){
			$medicalCount = $this->organization->getCountOfMedical($key);
			$row['medicalCountAfterImport'] = $medicalCount-$row['medicalCount'];
		}
		if(isset($row['pmidCount'])){
			$pmidCount = $this->organization->getCountOfPmids($key);
			$row['pmidCountAfterImport'] = $pmidCount-$row['pmidCount'];
		}
		if(isset($row['ctidCount'])){
			$ctidCount = $this->organization->getCountOfCtids($key);
			$row['ctidCountAfterImport'] = $ctidCount-$row['ctidCount'];
		}
			
		if(isset($row['keyPeopleCount'])){
			$keyPeopleCount = $this->organization->getCountOfKeyPeople($key);
			$row['keyPeopleCountAfterImport'] = $keyPeopleCount-$row['keyPeopleCount'];
		}
		$organizationDetailCount1[]=$row;
			
	}
		
	//pr($organizationDetailCount);
	$data['arrCounts'] = $organizationDetailCount1;
	$data['type'] = 'Uni';
	$data['contentPage'] 		= 'organizations/view_import_status';
	echo "Total Time Taken : ".( microtime(true)-$initialTime);
	$this->load->view(ANALYST_HEADER,$data);
	}
	
	function read_and_import_payer_files(){
		ini_set("max_execution_time",7200);
		$arrCountries	=$this->Country_helper->listCountries();
		$arrStates		=$this->Country_helper->listStates();
		$arrCities		=$this->Country_helper->listCities();
		$arrKeyPeopleRoles=$this->organization->getAllKeyPeopleRoles();
		$organizationTypes=$this->organization->getAllOrganizationTypes();
		$arrCollabarationCategories = $this->organization->getCollabarationCategories();
		$arrCollabarationRatings = $this->organization->getCollabarationRatings();
		$arrClaimsAndprocess = $this->organization->getClaimsaAndProcess();
		$arrFormularyDropDownValues = $this->organization->getFormularyDropDownValues();
			
		// Load the plugin
		$this->load->plugin('excelReader/reader2');
		$userId		=$this->session->userdata('user_id');
		$clientId	=$this->session->userdata('client_id');
		$orgID		= 0;
		$files = $this->input->post('files');
		$arrFiles = array();
		$organizationDetailCount = array();
		foreach($files as $row){
			$pos = strpos($row,'&');
			$folderNAme = substr($row,0,$pos);
			$arrFiles[$folderNAme][]=substr($row,$pos+1);
		}
		//pr($arrFiles);
	
		$initialTime = microtime(true);
		ini_set("memory_limit","2000M");
		$payerPath = $_SERVER['DOCUMENT_ROOT']."/".$this->config->item('app_folder_path')."documents/imports/org_imports/payer/uploaded/";
	
		foreach($arrFiles as $folder=>$files) {
				
			foreach($files as $filename){
				$arrImportStatusMsg[$filename]=array();
				$startTime = microtime(true);
				// Increasing the max execution time to pasrse all sheet data
				//$overviewFileName	= random_string('unique', 20);
				$overview_file_target_path = $payerPath."/".$folder."/".$filename;
				if(true){
					if(true){
						if(true) {
							$reader				=	new Spreadsheet_Excel_Reader($overview_file_target_path, true, 'utf-8');
							//loop through each sheet
							foreach($reader->sheets as $k=>$details){
								//Parsing of 1st sheet  - Overview: $k = index of the sheet
								if($k==0){
									$numColumns=0;
									$existingOrgs=array();
									$row=1;
									foreach($details['cells'] as $data){
										if($row==1){
											//condition to check whether format of the column is correct or not
											if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="COMPANY TYPE" || trim($data[4])!="LOGO" || trim($data[5])!="WEBSITE"
													|| trim($data[6])!="COMPANY HEADQUARTERS" || trim($data[7])!="COMPANY BACKGROUND" || trim($data[8])!="MISSION, VISION & VALUES"  || trim($data[9])!="KEY PRODUCTS" || trim($data[10])!="MERGERS & ACQUISITIONS" || trim($data[11])!="TOP CLIENTS"  ){
														$arrImportStatusMsg[$filename]['overview']['incorrect_format']='Uploaded File format is incorrect';
														break;
											}
											$numColumns=sizeof($data);
										}
										$organizationDetails=array();
										if($row>1){
											for($i=1;$i<=$numColumns;$i++){
												if(!isset($data[$i]))
													$data[$i]="";
											}
											$organizationDetails['cin_num']=trim($data[1]);
											$organizationDetails['name']=ucwords(trim($data[2]));
											$orgType=array_search(trim($data[3]),$organizationTypes);
											$organizationDetails['type_id']=$orgType;
											$organizationDetails['company_logo']=trim($data[4]);
											$organizationDetails['website']=trim($data[5]);
											$organizationDetails['headquarters']=trim($data[6]);
											$organizationDetails['background']=trim($data[7]);
											$organizationDetails['mission_vision']=trim($data[8]);
											$organizationDetails['key_products']=trim($data[9]);
											$organizationDetails['mergers']=trim($data[10]);
											$organizationDetails['clients']=trim($data[11]);
											$organizationDetails['profile_type'] = FULL;
											$profileType=trim($data[12]);
											if($profileType=='Basic'){
												$organizationDetails['profile_type'] = BASIC;
											}
											if($profileType=='Full Profile'){
												$organizationDetails['profile_type'] = FULL;
											}
											$organizationDetails['status']=New1;
											$organizationDetails['created_by']	=$userId;
											$organizationDetails['created_on']	=date("Y-m-d H:i:s");
												
											//break;
											//Save only if the 'cin_num' is not blank
											if($organizationDetails['cin_num']!=""){
												$id=$this->organization->saveOrganization($organizationDetails);
												if($id==false){
													//array of already existing organizations
													$existingOrgs[]=$organizationDetails['name'].' has been updated';
												}else{
													$orgID	= $id;
												}
											}else{
												//aray of organizations having no 'cin_num'
												$arrImportStatusMsg[$filename]['overview']['no_cin_num'][]= $organizationDetails['name'];
											}
												
										}
										$row++;
										$arrImportStatusMsg[$filename]['overview']['success']=true;
									}
									$arrImportStatusMsg[$filename]['overview']['existingOrgs']=$existingOrgs;
								}
									
								else if($k==1){
									//Parsing of 2st sheet  - Adress: $k = index of the sheet
									$numColumns=0;
									$row=1;
									foreach ($details['cells'] as $data) {
										//check wherether format is correct or not
										if($row==1){
											if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="ADDRESS" || trim($data[4])!="CITY" || trim($data[5])!="POSTAL CODE"
													|| trim($data[6])!="STATE" || trim($data[7])!="COUNTRY" || trim($data[8])!="PHONE" || trim($data[9])!="FAX" || trim($data[10])!="ADDITIONAL PHONE NUMBERS" || trim($data[11])!="KEY REGIONAL OFFICES" ){
														$arrImportStatusMsg[$filename]['address']['incorrect_format']='Uploaded File format is incorrect';
														break;
											}
											$numColumns=sizeof($data);
										}
										$organizationDetails=array();
										if($row>1){
											for($i=1;$i<=$numColumns;$i++){
												if(!isset($data[$i]))
													$data[$i]="";
											}
											$countryId=0;
											$stateId=0;
											$cityId=0;
											$organizationDetails['cin_num']=trim($data[1]);
											$organizationDetails['name']=trim($data[2]);
											$organizationDetails['address']=trim($data[3]);
											/*
											 if(array_key_exists(ucwords(trim($data[4])),$arrCities))
													$cityId=$arrCities[ucwords(trim($data[4]))]['city_id'];
													$organizationDetails['city_id']=$cityId;*/
	
											 $organizationDetails['postal_code']=trim($data[5]);
											 if(array_key_exists(ucwords(trim($data[6])),$arrStates))
													$stateId=$arrStates[ucwords(trim($data[6]))]['state_id'];
													$organizationDetails['state_id']=$stateId;
	
													$city					= ucwords(trim($data[4]));
													if($city!=''){
														$organizationDetails['city_id']= $this->kol->getCityIdByState($city,$stateId);
													}
													if(array_key_exists(ucwords(trim($data[7])),$arrCountries))
														$countryId=$arrCountries[ucwords(trim($data[7]))]['country_id'];
														$organizationDetails['country_id']=$countryId;
														$organizationDetails['phone']=trim($data[8]);
														$organizationDetails['fax']=trim($data[9]);
															
														$faxDetails=explode(" ",$organizationDetails['fax']);
														$arrFaxValues=array();
														$faxNumber="";
														foreach($faxDetails as $value){
															if(strpos($value, "+")!=false){
																$faxNumber.=trim($value);
															}
															if(is_numeric($value)){
																$faxNumber.=trim($value);
															}
														}
															
														$organizationDetails['key_reginal_offices']=trim($data[11]);
														$organizationDetails['addr_url']=trim($data[12]);
														$organizationDetails['created_by']	=$userId;
														$organizationDetails['created_on']	=date("Y-m-d H:i:s");
															
														//Save only if the 'cin_num' is not blank
														if($organizationDetails['cin_num']!=""){
															$orgID =$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
															if($orgID>0){
																$organizationDetails['id']	= $orgID;
															}
															$id=$this->organization->updateImportedOrganization($organizationDetails);
															if($id==false){
																//array of 'cin_num' not present in database
																$arrImportStatusMsg[$filename]['address']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
															}
														}else{
															//aray of organizations  having no 'cin_num'
															$arrImportStatusMsg[$filename]['address']['no_cin_num'][]= $organizationDetails['name'];
														}
															
														//Parsing and saving additional contact details
														if($organizationDetails['cin_num']!=""){
															$arrContactDetails=array();
															$orgId=$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
															$aditionalContats=trim($data[10]);
															$arrAditionalContactDetails=explode("\n",$aditionalContats);
															foreach($arrAditionalContactDetails as $aditionalContat){
																$contactDetails=array();
																$phNumber="";
																$relatedTo="";
																if(strpos($aditionalContat, "-")!=false){
																	$aditionalContatDetails=explode("-",$aditionalContat);
																	foreach($aditionalContatDetails as $value){
																		if(strpos($value, "+")!=false){
																			$phNumber.=trim($value);
																		}else if(is_numeric($value)){
																			$phNumber.=trim($value);
																		}else {
																			$relatedTo.=trim($value);
																		}
																	}
																}else if(strpos($aditionalContat, ":")!=false){
																		
																	//echo $aditionalContat;
																	$aditionalContatDetails=explode(":",$aditionalContat);
																	$contactDetails['related_to']=$aditionalContatDetails[0];
																	$contactDetails['phone']=$aditionalContatDetails[1];
																}else{
																	$aditionalContatDetails=explode(" ",$aditionalContat);
																}
																$arrContactDetails[]=$contactDetails;
															}
															if($orgId!=0){
																//save additional contact details
																foreach($arrContactDetails as $row){
																	$row['org_id']=$orgId;
																	$row['created_by']	=$userId;
																	$row['created_on']	=date("Y-m-d H:i:s");
																	$this->organization->saveContact($row);
																}
															}else{
																//set error details
															}
														}
										}
										$row++;
										$arrImportStatusMsg[$filename]['address']['success']=true;
									}
										
								}
								else if($k==2){
										
	
									$fact =1;
									//Parsing of 3st sheet  - Mediacal Services: $k = index of the sheet
									$numColumns=0;
									$row=1;
										
									foreach($details['cells'] as $key=>$data) {
										if($row==1){
											if( trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="NO. OF HOSPITALS" || trim($data[4])!="TOTAL NO. OF PHYSICIANS" || trim($data[5])!='NO. OF PHYSICIANS EMPLOYED' || trim($data[6])!='NO. OF PHYSICIANS AFFILIATED' ||
														
													trim($data[7])!='PHARMACY BENEFIT MANAGEMENT' || trim($data[8])!='SPECIALTY PHARMACY' || trim($data[9])!='NCQA STATUS' ||
													trim($data[10])!='MEDICARE STAR RATING' || trim($data[11])!='CLAIMS & EMR DATA' || trim($data[12])!='DATA PROCESSING'
													){
														$arrImportStatusMsg[$filename]['facts']['incorrect_format']='Uploaded File format is incorrect';
														break;
											}
											$numColumns=sizeof($data);
										}
										$factDataDetails=array();
										if($row>1){
											for($i=1;$i<=$numColumns;$i++){
												if(!isset($data[$i]))
													$data[$i]="";
											}
											$cinNum  = trim($data[1]);
											$orgName =ucwords(trim($data[2]));
												
											$factDataDetails['no_of_hospitals']=trim($data[3]);
											$factDataDetails['no_of_physicians']=trim($data[4]);
											$factDataDetails['physicians_employed']=trim($data[5]);
											$factDataDetails['no_of_affiliated']=trim($data[6]);
											$factDataDetails['benefit_management']=trim($data[7]);
											$factDataDetails['specialty_pharmacy']=trim($data[8]);
											$factDataDetails['ncqa_status']=trim($data[9]);
											$factDataDetails['start_rating']=trim($data[10]);
											//Save only if the 'cin_num' is not blank
											if($cinNum!=""){
												$orgID	= $this->organization->getOrgIdBySinNumber($cinNum);
												$factDataDetails['org_id'] =$orgID;
												if($orgID==0){
													//array of 'cin_num' not present in database
													$arrImportStatusMsg[$filename]['facts']['no_matching_cin_num'][]= $cinNum;
												}else{
													if($fact ==1){
														//$this->organization->deleteOrgPayerFacts($orgID);
														//$fact++;
													}
													$id = $this->organization->saveOrgPayerFacts($factDataDetails);
													$claims =trim($data[11]);
													if($claims!=''){
														$claimsArray = explode(',',$claims);
															
														$arrClaimsData = array();
														foreach($claimsArray as $value){
															$arrClaims =array();
															if(array_key_exists(trim($value),$arrClaimsAndprocess)){
																$arrClaims['type_id'] = CLAIMS;
																$arrClaims['fact_id'] = $id;
																$arrClaims['cliam_process_id']=$arrClaimsAndprocess[trim($value)]['id'];
																$this->organization->saveClaimData($arrClaims);
															}
														}
													}
													$dataProcessing=trim($data[12]);
													if($dataProcessing!=''){
														$processingArray = explode(',',$dataProcessing);
															
														$arrClaimsData = array();
														foreach($processingArray as $process){
															$arrProcess =array();
															if(array_key_exists(trim($process),$arrClaimsAndprocess)){
																$arrProcess['type_id'] = DATA_PROCESSING;
																$arrProcess['fact_id'] = $id;
																$arrProcess['cliam_process_id']=$arrClaimsAndprocess[trim($process)]['id'];
																$this->organization->saveClaimData($arrProcess);
															}
														}
													}
														
												}
											}else{
												//aray of address detains having no 'cin_num'
												$arrImportStatusMsg[$filename]['facts']['no_cin_num'][]= $orgName;
											}
												
										}
										$row++;
										$arrImportStatusMsg[$filename]['facts']['success']=true;
									}
								}
								else if($k==3){
									//Parsing of 3st sheet  - Affiliate patnership: $k = index of the sheet
									$numColumns=0;
									$row=1;
									$enroll=1;
									foreach($details['cells'] as $key=>$data) {
										if($row==1){
											if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!='ENROLLMENT TYPE'
													){
														$arrImportStatusMsg[$filename]['enrollment']['incorrect_format']='Uploaded File format is incorrect';
														break;
											}
											$numColumns=sizeof($data);
											unset($data[1]);
											unset($data[2]);
											unset($data[3]);
											$years=$data;
										}
										$enrollementDetails=array();
										if($row>1){
											for($i=1;$i<=$numColumns;$i++){
												if(!isset($data[$i]))
													$data[$i]="";
											}
											$cinNum  = trim($data[1]);
											$orgName =ucwords(trim($data[2]));
											//pr($data);
											$enrollementDetails['type']=trim($data[3]);
											//echo $cinNum;
											//$enrollementDetails['2009']=trim($data[4]);
											///$enrollementDetails['2010']=trim($data[5]);
											//$enrollementDetails['2011']=trim($data[6]);
											// $enrollementDetails['2012']=trim($data[7]);
											if($cinNum!=''){
												$enrollementDetails['org_id'] =$this->organization->getOrgIdBySinNumber($cinNum);
													
												if($enrollementDetails['org_id']!=0){
													//$orgId = $enrollementDetails['org_id'];
													//	if($enroll ==1){
													//$this->organization->deleteOrgEnrollement($enrollementDetails['org_id']);
														//$enroll++;
														//}
														if(!(isset($organizationDetailCount[$enrollementDetails['org_id']]['enrollementCount']))){
															$organizationDetailCount[$enrollementDetails['org_id']]['enrollementCount'] = $this->organization->getCountOfEnrollments($enrollementDetails['org_id']);
														}
														$id = $this->organization->saveOrgEnrollement($enrollementDetails);
														// pr($years);
														$lenth=sizeOf($years)+4;
															
														for($k=4;$k<$lenth;$k++){
															$arr =array();
															$arr['year']=$years[$k];
															$arr['value']=preg_replace("/[^0-9]/", "", $data[$k]);//str_replace(",","",$data[$k]);
															$arr['enroll_id']=$id;
																
															$this->organization->saveEnrollements($arr);
																
														}
													}else{
															
														$arrImportStatusMsg[$filename]['enrollment']['no_matching_cin_num'][]= $cinNum;
													}
												}else{
													//aray of address detains having no 'cin_num'
													$arrImportStatusMsg[$filename]['enrollment']['no_cin_num'][]=$orgName;
												}
											}
											$row++;
											$arrImportStatusMsg[$filename]['enrollment']['success']=true;
										}
											
									}
	
									else if($k==4){
											
											
										//Parsing of 3st sheet  - Social Media : $k = index of the sheet
										$numColumns=0;
										$row=1;
										$formulary=1;
										foreach($details['cells'] as $data) {
											if($row==1){
												if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="DRUG NAME" || trim($data[4])!="DRUG TIER" || trim($data[5])!="PA  CRITERIA"
														){
															$arrImportStatusMsg[$filename]['formulary']['incorrect_format']='Uploaded File format is incorrect';
															//break;
												}
												$numColumns=sizeof($data);
											}
											$formularyDetails=array();
											if($row>1){
												for($i=1;$i<=$numColumns;$i++){
													if(!isset($data[$i]))
									 				$data[$i]="";
												}
												$cinNum=trim($data[1]);
												$name=ucwords(trim($data[2]));
													
												$formularyDetails['drug_name']=trim($data[3]);
												$formularyDetails['created_by']	=$this->loggedUserId;
												$formularyDetails['created_on']	=date("Y-m-d H:i:s");
												$formularyDetails['client_id']	=$this->session->userdata('client_id');
												$drugs=trim($data[4]);
												$paCretaria=trim($data[5]);
												//$formularyDetails['pa_creteria']=trim($data[5]);
													
												//$formularyDetails['created_by']	=$userId;
												//$formularyDetails['created_on']	=date("Y-m-d H:i:s");
													
												//Save only if the 'cin_num' is not blank
												if($cinNum!=""){
													$orgID	= $this->organization->getOrgIdBySinNumber($cinNum);
														
													if($orgID==0){
														//array of 'cin_num' not present in database
														$arrImportStatusMsg[$filename]['formulary']['no_matching_cin_num'][]= $cinNum;
													}else{
														$formularyDetails['org_id'] = $orgID;
														//if($formulary ==1){
														//$this->organization->deleteOrgFormulary($orgID);
														//$formulary++;
														//}
														if(!(isset($organizationDetailCount[$orgID]['formularyCount']))){
															$organizationDetailCount[$orgID]['formularyCount'] = $this->organization->getCountOfFormularies($orgID);
														}
														$id = $this->organization->saveOrgFormularies($formularyDetails);
														if($drugs!=''){
															$drugsArray = explode(',',$drugs);
																
															//$arrDrugsData = array();
															foreach($drugsArray as $value){
																$arrDrugsData =array();
																if(array_key_exists(trim($value),$arrFormularyDropDownValues)){
																	$arrDrugsData['type'] = DRUG_TIER;
																	$arrDrugsData['form_id'] = $id;
																	$arrDrugsData['drug_pa_id']=$arrFormularyDropDownValues[trim($value)]['id'];
																		
																	$this->organization->saveFormularyDropdownData($arrDrugsData);
																}
															}
														}
														if($paCretaria!=''){
															$paArray = explode(',',$paCretaria);
	
															//$arrDrugsData = array();
															foreach($paArray as $value){
																$arrPaData =array();
																if(array_key_exists(trim($value),$arrFormularyDropDownValues)){
																	$arrPaData['type'] = PA_CRITERIA;
																	$arrPaData['form_id'] = $id;
																	$arrPaData['drug_pa_id']=$arrFormularyDropDownValues[trim($value)]['id'];
																		
																	$this->organization->saveFormularyDropdownData($arrPaData);
																}
															}
														}
												}
											}else{
												//aray of address detains having no 'cin_num'
												$arrImportStatusMsg[$filename]['formulary']['no_cin_num'][]= $name;
											}
												
										}
										$row++;
										$arrImportStatusMsg[$filename]['formulary']['success']=true;
									}
										
								}
								else if($k==6){
	
									//Parsing of 3st sheet  - Social Media : $k = index of the sheet
									$numColumns=0;
									$row=1;
									$rate=1;
									foreach($details['cells'] as $data) {
										if($row==1){
											if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="CATEGORY" || trim($data[4])!="RATING"
									 			){
									 				$arrImportStatusMsg[$filename]['collabaration']['incorrect_format']='Uploaded File format is incorrect';
									 				break;
											}
											$numColumns=sizeof($data);
										}
										$formularyDetails=array();
										if($row>1){
											for($i=1;$i<=$numColumns;$i++){
												if(!isset($data[$i]))
													$data[$i]="";
											}
											$cinNum=trim($data[1]);
											$name=ucwords(trim($data[2]));
												
											$category=trim($data[3]);
											if(array_key_exists(trim($category),$arrCollabarationCategories)){
												$categoryId = $arrCollabarationCategories[$category]['id'];
											}
												
											$ratings=trim($data[4]);
											//echo $ratings;
											//$formularyDetails['pa_creteria']=trim($data[5]);
												
											//$formularyDetails['created_by']	=$userId;
											//$formularyDetails['created_on']	=date("Y-m-d H:i:s");
												
											//Save only if the 'cin_num' is not blank
											if($cinNum!=""){
												$orgID	= $this->organization->getOrgIdBySinNumber($cinNum);
													
												if($orgID==0){
													//array of 'cin_num' not present in database
													$arrImportStatusMsg[$filename]['collabaration']['no_matching_cin_num'][]= $cinNum;
												}else{
														
													//$formularyDetails['org_id'] = $orgID;
													if($rate==1){
														$this->organization->deleteCollabarationRatings($orgID);
														$rate++;
													}
													//$id = $this->organization->saveOrgFormularies($formularyDetails);
														
													if($ratings!=''){
															
														$arrRatings = explode(',',$ratings);
														foreach($arrRatings  as $rating){
																
															if(array_key_exists(trim($rating),$arrCollabarationRatings)){
																$ratings =array();
																$ratingId = $arrCollabarationRatings[trim($rating)]['id'];
																$ratings['category_id'] = $categoryId;
																$ratings['org_id'] = $orgID;
																$ratings['rating_id'] = $ratingId;
																$ratings['created_by']	=$this->loggedUserId;
																$ratings['created_on']	=date("Y-m-d H:i:s");
																$ratings['client_id']	=$this->session->userdata('client_id');
																$this->organization->saveCollabarationRatings($ratings);
																	
															}
														}
													}
														
												}
											}else{
												//aray of address detains having no 'cin_num'
												$arrImportStatusMsg[$filename]['collabaration']['no_cin_num'][]= $name;
											}
												
										}
										$row++;
										$arrImportStatusMsg[$filename]['collabaration']['success']=true;
									}
										
								}
								else if($k==7){
									$arrKeyPeopleDetails = array();
									$kePeople=1;
									//Parsing of 4th sheet  -key_people: $k = index of the sheet
									$numColumns=0;
									$row=1;
									$arrSalutations	= array(''=>0,'Dr.' => 1, 'Prof.' => 2, 'Mr.' => 3, 'Ms.' =>4);
									foreach($details['cells'] as $data) {
										if($row==1){
											if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="ROLE" || trim($data[4])!="SALUTATION" || trim($data[5])!="FIRST NAME"
													|| trim($data[6])!="MIDDLE NAME" || trim($data[7])!="LAST NAME" || trim($data[8])!="DEPARTMENT/DIVISION/CENTER" || trim($data[9])!="TITLE" || trim($data[10])!="EMAIL" ){
														$arrImportStatusMsg[$filename]['key_people']['incorrect_format']='Uploaded File format is incorrect';
														break;
											}
											$numColumns=sizeof($data);
										}
										$organizationDetails=array();
										if($row>1){
											for($i=1;$i<=$numColumns;$i++){
												if(!isset($data[$i]))
													$data[$i]="";
											}
											$organizationDetails['cin_num']=trim($data[1]);
											$organizationDetails['name']=ucwords(trim($data[2]));
												
											$roleId=array_search(trim(strtolower($data[3])),array_map('strtolower',$arrKeyPeopleRoles));//array_search(trim($data[3]),$arrKeyPeopleRoles);
											$keyPeopleDetails['role_id']=$roleId;
											$keyPeopleDetails['salutation']=$arrSalutations[trim($data[4])];
											$keyPeopleDetails['first_name']=trim($data[5]);
											$keyPeopleDetails['middle_name']=trim($data[6]);
											$keyPeopleDetails['last_name']=trim($data[7]);
											$keyPeopleDetails['department']=trim($data[8]);
											$keyPeopleDetails['title']=trim($data[9]);
											$keyPeopleDetails['email']=trim($data[10]);
											$keyPeopleDetails['url']=trim($data[11]);
											$keyPeopleDetails['created_by']	=$userId;
											$keyPeopleDetails['created_on']	=date("Y-m-d H:i:s");
											//Save only if the 'cin_num' is not blank
											if($organizationDetails['cin_num']!=""){
												$orgId=$this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
												if($orgId==0){
													$orgId=$this->organization->getOrgIdByOrgName($organizationDetails['name']);
												}
												if($orgId!=0){
													$keyPeopleDetails['org_id']=$orgId;
													//if($kePeople ==1){
													//	$this->organization->deleteKeyPeopleByOrgId($orgId);
													//	$kePeople++;
													//}
													if(!(isset($organizationDetailCount[$orgId]['keyPeopleCount']))){
														$organizationDetailCount[$orgId]['keyPeopleCount'] = $this->organization->getCountOfKeyPeople($orgId);
													}
													$arrKeyPeopleDetails[]=$keyPeopleDetails;
													//	$this->organization->saveKeyPeople($keyPeopleDetails);
											}else{
													
												$arrImportStatusMsg[$filename]['key_people']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
											}
										}else{
											//aray of address detains having no 'cin_num'
											$arrImportStatusMsg[$filename]['key_people']['no_cin_num'][]= $organizationDetails['name'];
										}
											
									}
									$row++;
									$arrImportStatusMsg[$filename]['key_people']['success']=true;
								}
								$this->organization->saveKeyPeopleBulk($arrKeyPeopleDetails);
							}
								
							else if($k==5){
								$management = 1;
								///pr($arrDiseaseDropDownValues);
								//Parsing of 7th sheet  - Stats Facts: $k = index of the sheet
								foreach($details['cells'] as $factKey=>$facts){
									if($factKey==1){
										if(trim($facts[1])!="CIN NUM" || trim($facts[2])!="COMPANY NAME" || trim($facts[3])!="DISEASE NAME" || trim($facts[4])!="DISEASE MANAGEMENT PLATFORMS" ||
												trim($facts[5])!="IDENTIFICATION" || trim($facts[6])!="INTERVENTION" || trim($facts[7])!="MEASUREMENT"
												){
													$arrImportStatusMsg[$filename]['disease_management']['incorrect_format']='Uploaded File format is incorrect';
													break;
										}
											
											
										$numColumns=sizeof($facts);
									}
									if($factKey!=1){
										$managmentDataDetails=array();
										$cinNum = $facts[1];
										$name = $facts[2];
										$managmentDataDetails["disease_name"] 		= $facts[3];
											
										$managmentDataDetails['created_by']	=$this->loggedUserId;
										$managmentDataDetails['created_on']	=date("Y-m-d H:i:s");
										$managmentDataDetails['client_id'] = $this->session->userdata('client_id');
										$platForms	= $facts[4];
										$identification	= $facts[5];
										$intervention	= $facts[6];
										$measurement	= $facts[7];
										//$managmentDataDetails["identification"] 	 	    = $facts[5];
											
										//$managmentDataDetails["intervention"] 	= $facts[6];
										//$managmentDataDetails["measurement"]    = $facts[7];
										if($cinNum!=''){
											$managmentDataDetails['org_id'] =$this->organization->getOrgIdBySinNumber($cinNum);
											if($managmentDataDetails['org_id']!=0){
													
												//	if($management ==1){
												//	$this->organization->deleteDiseaseManagement($managmentDataDetails['org_id']);
												//$management++;
												//}
												if(!(isset($organizationDetailCount[$managmentDataDetails['org_id']]['diseaseCount']))){
													$organizationDetailCount[$managmentDataDetails['org_id']]['diseaseCount'] = $this->organization->getCountOfDisease($managmentDataDetails['org_id']);
												}
												$id = $this->organization->saveDeaseManagement($managmentDataDetails);
												if($platForms!=''){
													$platFormArray = explode(',',$platForms);
													$arrDiseaseDropDownValues = $this->organization->getDiseaseDropDownValuesForParticulars(DISEASE_MANAGEMENT_PLATFORMS);
													//$arrDrugsData = array();
													foreach($platFormArray as $value){
															
														$arrPlatFormData =array();
															
														if(array_key_exists(trim($value),$arrDiseaseDropDownValues)){
															//echo $value;
															$arrPlatFormData['type'] = DISEASE_MANAGEMENT_PLATFORMS;
															$arrPlatFormData['disease_id'] = $id;
															$arrPlatFormData['value_id']=$arrDiseaseDropDownValues[trim($value)]['id'];
																
															$this->organization->saveDiseaseDropdownData($arrPlatFormData);
														}
													}
														
												}
													
												if($identification!=''){
													$identificationArray = explode(',',$identification);
													$arrDiseaseDropDownValues = $this->organization->getDiseaseDropDownValuesForParticulars(IDENTIFICATION);
													//$arrDrugsData = array();
													foreach($identificationArray as $value){
															
														$arrIdentData =array();
															
														if(array_key_exists(trim($value),$arrDiseaseDropDownValues)){
															//echo $value;
															$arrIdentData['type'] = IDENTIFICATION;
															$arrIdentData['disease_id'] = $id;
															$arrIdentData['value_id']=$arrDiseaseDropDownValues[trim($value)]['id'];
																
															$this->organization->saveDiseaseDropdownData($arrIdentData);
														}
													}
														
												}
													
												if($intervention!=''){
													$interventionArray = explode(',',$intervention);
													$arrDiseaseDropDownValues = $this->organization->getDiseaseDropDownValuesForParticulars(INTERVENTION);
													//$arrDrugsData = array();
													foreach($interventionArray as $value){
															
														$arrInterData =array();
															
														if(array_key_exists(trim($value),$arrDiseaseDropDownValues)){
															//echo $value;
															$arrInterData['type'] = INTERVENTION;
															$arrInterData['disease_id'] = $id;
															$arrInterData['value_id']=$arrDiseaseDropDownValues[trim($value)]['id'];
															//pr($arrPlatFormData);
															$this->organization->saveDiseaseDropdownData($arrInterData);
														}
													}
														
												}
													
												if($measurement!=''){
													$measurementArray = explode(',',$measurement);
													$arrDiseaseDropDownValues = $this->organization->getDiseaseDropDownValuesForParticulars(MEASUREMENT);
													//$arrDrugsData = array();
													foreach($measurementArray as $value){
															
														$arrMeasuremenData =array();
															
														if(array_key_exists(trim($value),$arrDiseaseDropDownValues)){
															//echo $value;
															$arrMeasuremenData['type'] = MEASUREMENT;
															$arrMeasuremenData['disease_id'] = $id;
															$arrMeasuremenData['value_id']=$arrDiseaseDropDownValues[trim($value)]['id'];
															//pr($arrPlatFormData);
															$this->organization->saveDiseaseDropdownData($arrMeasuremenData);
														}
													}
														
												}
													
										}else{
												
											$arrImportStatusMsg[$filename]['disease_management']['no_matching_cin_num'][]= $cinNum;
										}
									}else{
										//aray of address detains having no 'cin_num'
										$arrImportStatusMsg[$filename]['disease_management']['no_cin_num'][]= $name;
									}
								}
								$arrImportStatusMsg[$filename]['disease_management']['success']=true;
									
							}
							// break;
						}
	
						else if($k==8){
							//Parsing of 3st sheet  - Social Media : $k = index of the sheet
							$numColumns=0;
							$row=1;
							foreach($details['cells'] as $data) {
								if($row==1){
									if(trim($data[1])!="CIN NUM" || trim($data[2])!="COMPANY NAME" || trim($data[3])!="BLOG" || trim($data[4])!="YOUTUBE" || trim($data[5])!="LINKEDIN"
											|| trim($data[6])!="FACEBOOK" || trim($data[7])!="TWITTER" ){
												$arrImportStatusMsg[$filename]['social_media']['incorrect_format']='Uploaded File format is incorrect';
												break;
									}
									$numColumns=sizeof($data);
								}
								$organizationDetails=array();
								if($row>1){
									for($i=1;$i<=$numColumns;$i++){
										if(!isset($data[$i]))
											$data[$i]="";
									}
									$organizationDetails['cin_num']=trim($data[1]);
									$organizationDetails['name']=ucwords(trim($data[2]));
										
									$organizationDetails['blog']=trim($data[3]);
									$organizationDetails['youtube']=trim($data[4]);
									$organizationDetails['linkedin']=trim($data[5]);
									$organizationDetails['facebook']=trim($data[6]);
									//$organizationDetails['myspace']=trim($data[7]);
									$organizationDetails['twitter']=trim($data[7]);
										
									$organizationDetails['created_by']	=$userId;
									$organizationDetails['created_on']	=date("Y-m-d H:i:s");
										
									//Save only if the 'cin_num' is not blank
									if($organizationDetails['cin_num']!=""){
										$orgID	= $this->organization->getOrgIdBySinNumber($organizationDetails['cin_num']);
										if($orgID>0){
											$organizationDetails['id']	= $orgID;
										}
										$id=$this->organization->updateImportedOrganization($organizationDetails);
										if($id==false){
											//array of 'cin_num' not present in database
											$arrImportStatusMsg[$filename]['social_media']['no_matching_cin_num'][]= $organizationDetails['cin_num'];
										}
									}else{
										//aray of address detains having no 'cin_num'
										$arrImportStatusMsg[$filename]['social_media']['no_cin_num'][]= $organizationDetails['name'];
									}
										
								}
								$row++;
								$arrImportStatusMsg[$filename]['social_media']['success']=true;
							}
						}
							
					}
				}
			}
			else{
				$arrImportStatusMsg[$filename]['overview']['file_type_missmatch']="file type is not 'xls'";
			}
		}
	}
	$data['arrImportStatusMsg'][] = $arrImportStatusMsg;
	}
	
	$stTime = microtime(true);
	foreach($organizationDetailCount as $key=>$count){
		$count['id'] = $key;
		if(isset($count['enrollementCount'])){
	
			$enrollementCount = $this->organization->getCountOfEnrollments($key);
			$count['enrollementCountAfterImport'] = $enrollementCount-$count['enrollementCount'];
		}
		if(isset($count['formularyCount'])){
			$formularyCount = $this->organization->getCountOfFormularies($key);
			$count['formularyCountAfterImport'] = $formularyCount-$count['formularyCount'];
		}
		if(isset($count['keyPeopleCount'])){
			$keyPeopleCount = $this->organization->getCountOfKeyPeople($key);
			$count['keyPeopleCountAfterImport'] = $keyPeopleCount-$count['keyPeopleCount'];
		}
		if(isset($count['diseaseCount'])){
			$diseaseCount = $this->organization->getCountOfDisease($key);
			$count['diseaseCountAfterImport'] = $diseaseCount-$count['diseaseCount'];
		}
		$organizationDetailCount1[] = $count;
	}
	
	$ndTime = microtime(true);
	//echo $stTime-$ndTime."dddddddd";
	
	
	
	
	$data['type'] = 'Payer';
	$data['arrCounts'] = $organizationDetailCount1;
	//$data['arrImportStatusMsg']=$arrImportStatusMsg;
	$data['contentPage'] 	=	'organizations/view_import_status';
	$data['timeTaken']	=	"Time Taken for Import ".$entry.": ".( microtime(true)-$startTime)."";
	$this->load->view(ANALYST_HEADER,$data);
	//echo "Total Time Taken : ".( microtime(true)-$initialTime);
	}
}

?>