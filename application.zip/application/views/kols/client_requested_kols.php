<?php 
/**
 * Contains fucntion required for Listing requested Kols
 * 
 * @author Vinayak
 * @since 4.2
 * @package application.view
 * @created 13-6-2012
 */
//$queued_js_scripts = array('kols/view_affiliations','highcharts 2.1.0','highchartsTheme','i18n/grid.locale-en','jquery.jqGrid.min','jquery.validate');
	$queued_js_scripts = array('i18n/grid.locale-en','jquery.jqGrid.min','jquery/jquery.validate1.9.min');
	// add the JS files into queue i.e Append to the existing queue
	$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
	
	$autoApproveRequest	= IS_APPROVER;
 ?>
 	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/ui.jqgrid.css" />
	<style type="text/css">
		.gridWrapper {
			width: 98%;
		}
		
		#myPendingApprovalsResultSet_cb{
			vertical-align: top;
		}
		#rejectBox span{
			color: black;
		    font-size: 12px;
		}
		#rejectBox label{
			font-size: 13px !important;
		}
		#rejectBox textarea{
			width: 90%;
		}
		#rejectBox input{
			float: right;
   			margin-right: 35px;
		}
		.approve-reject{
			float: left;
   			margin-left: 5px;
		}
		.approve{
			background-attachment: scroll;
		    background-clip: border-box;
		    background-color: transparent;
		    background-image: url("<?php echo base_url()?>images/right_blue.svg");
		    background-origin: padding-box;
		    background-position: 0 6px;
		    background-repeat: no-repeat;
		    height: 29px;
		    width: 22px;
		    margin-top: -3px;
		}
		.reject{
			background-attachment: scroll;
		    background-clip: border-box;
		    background-color: transparent;
		    background-image: url("<?php echo base_url()?>images/deny_red.svg");
		    background-origin: padding-box;
		    background-position: 0 6px;
		    background-repeat: no-repeat;
		    height: 29px;
		    width: 22px;
		    margin-top: -3px;
		}
		#allProfileRequestsGridContainer{
			margin-top:20px;
		}
		.gridWrapper .ui-jqgrid tr.jqgrow td{
			padding: 2px 2px 2px 4px !important;
		}
		.title-bar-actions{
			float:right;
			margin-right: 19px;
		}
		.title-bar-actions .sprite_iconSet{
			float:right;
			margin-left: 0;
		}
		.title-bar-actions .blueButton{
			/*background: none no-repeat scroll left center #BBBBBB;
		    border-color: #8A8A8A !important;*/
		    margin-left: 5px;
		}
		.reasonContent{
			height: 79px !important;
			width:350px;
		}
		.reasonContent .profileContent{
			height: 60px !important;
    		min-height: 40px !important;
		}
		.title-bar-actions .approve-button, .title-bar-actions .reject-button{
			padding-bottom: 2px;
		}
		.title-bar-actions .approve-button{
			background-image: url("<?php echo base_url()?>images/right_white.svg");
			background-position: 3px 3px;
		    background-repeat: no-repeat;
		    background-size: 17px auto;
		    padding-left: 23px;
		}
		.title-bar-actions .approve-button:HOVER{
			background-image: url("<?php echo base_url()?>images/right_blue.svg");
			background-position: 3px 3px;
		    background-repeat: no-repeat;
		    background-size: 17px auto;
		    padding-left: 23px;
		}
		.title-bar-actions .reject-button{
			background-image: url("<?php echo base_url()?>images/deny_red.svg");
			background-position: 3px 3px;
		    background-repeat: no-repeat;
		    background-size: 17px auto;
		    padding-left: 23px;
		}
		.title-bar-actions .reject-button:HOVER{
			background-image: url("<?php echo base_url()?>images/deny_red.svg");
			background-position: 3px 3px;
		    background-repeat: no-repeat;
		    background-size: 17px auto;
		    padding-left: 23px;
		}
		#cb_myPendingApprovalsResultSet{
			margin-left: 6px;
		}
		.ui-widget-content{
		  background: #ffffff;
		}
	</style>
	<!--[if IE]>
	<style type="text/css">
		#cb_myPendingApprovalsResultSet{
			margin-left: 3px;
		}
		#jqgh_myPendingApprovalsResultSet_rn{
			margin-right: -2px !important;
		}
	</style>
	<![endif]-->

	<script type="text/javascript">
	var urlFilters = null;
	<?php if(isset($urlString)){?>
	urlFilters = <?php echo $urlString ?>;
	<?php }?>
	var autoApproveRequest= '<?php echo $autoApproveRequest;?>';
	var myPendingApprovalsTitle = "<?php echo lang("ProfileRequest.PendingApprovals");?>";
	var requestTypeHeader = "<?php echo lang("ProfileRequest.RequestType");?>";
	var organizationHeader = "<?php echo lang("Surveys.Organization");?>";
	var statusHeader = "<?php echo lang("Overview.Status");?>";
	var nameHeader = "<?php echo lang("Organizations.Name");?>";
	var createdByHeader = "<?php echo lang("Surveys.CreatedBy");?>";
	var actionHeader = "<?php echo lang("Overview.Action");?>";
	var approverHeader = "<?php echo lang("ProfileRequest.Approver");?>";
	var allProfRequestTitle = "<?php echo lang("ProfileRequest.ProfileRequests");?>";
	jqgridIds	= new Array('myPendingApprovalsResultSet','allProfileRequestsResultSet');
	jqgridMinWidth	= 1010;
	jqgridMaxWidth	= 1305;
		function myPendingApprovals(){
			$("#myPendingApprovals").html("");
			// Append the required div and table
			$("#myPendingApprovals").html('<table id="myPendingApprovalsResultSet"></table><div id="myPendingApprovalsPager"></div>');
		
			jQuery("#myPendingApprovalsResultSet").jqGrid({
			   	url:'<?php echo base_url()?>requested_kols/list_my_pending_approvals/',
				datatype: "json",
				colNames:['Id','','','',statusHeader,nameHeader,requestTypeHeader,organizationHeader,createdByHeader,"Requested On","Approved / Rejected On",actionHeader,"approve_allow"],
			   	colModel:[
							{name:'id',index:'id', hidden:true},
							{name:'created_by',index:'created_by', hidden:true},
							{name:'kol_id',index:'kol_id', hidden:true},
							{name:'micro',index:'micro',width:30, search:false },
							<?php //if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN){
								if($autoApproveRequest){
							?>
							{name:'status',index:'status',width:80, resizable:false},
							<?php }else{ ?>
							{name:'status',index:'status',width:100, resizable:false},
							<?php } ?>
							{name:'kol_name',index:'kol_name',width:190 },
							{name:'request_for',index:'request_for',width:100 },
							{name:'name',index:'name',width:220},
					   		{name:'user_full_name',index:'user_full_name',width:120, resizable:false},
					   		{name:'requested_on',index:'requested_on',width:100 },
							{name:'rej_or_appr_on',index:'rej_or_appr_on',width:200 },
					   		{name:'act',resizable:true,search:false,width:100,align:'center',title:false,sortable:false},
							{name:'approve_allow',index:'approve_allow', hidden:true}
			   	],
			   	rowNum:10,
			   	rownumbers: true,
				//rownumWidth: 60,
			   	<?php //if($this->session->userdata('user_role_id') == ROLE_MANAGER || $this->session->userdata('user_role_id') == ROLE_ADMIN){
			   	if($autoApproveRequest){
			   	?>
				multiselect: true,
				<?php } ?>
				autowidth: false, 
			   	loadonce:true,
			   	ignoreCase:true,
			   	hiddengrid:false,
			   	height: "auto",	
			   	width:"100%",
			   	resizable:true,
			   	shrinkToFit: true,
			   	pager: '#myPendingApprovalsPager',
			   	mtype: "POST",
			   	sortname: 'requested_on',
			    viewrecords: true,
			    sortorder: "desc",
			    jsonReader: { repeatitems : false, id: "0" }, 
			    caption:myPendingApprovalsTitle,
			   	rowList:paginationValues,
			    gridComplete: function(){
			    	/*$("#jqgh_rn").html("Select All");
				    $("#jqgh_cb").prepend("Select All");
				    $("#myPendingApprovalsResultSet").css("width","80px");
				   	$("#myPendingApprovalsResultSet tbody tr").children().first("td").css("width","80px");
				   	*/
					var userId = <?php echo $this->session->userdata('user_id')?>;
			   		var ids = jQuery("#myPendingApprovalsResultSet").jqGrid('getDataIDs'); 
		    		for(var i=0;i < ids.length;i++){ 
				    	var arrId = jQuery('#myPendingApprovalsResultSet').jqGrid ('getRowData', ids[i]);
				    	//var cl = ids[i];				    	
		    			var cl = arrId.id;
				    	var rowData = jQuery("#myPendingApprovalsResultSet").jqGrid('getRowData', ids[i]);
				    	if(autoApproveRequest){
							be = "<div class='tooltip-demo tooltop-left approve-reject'><a onclick='approveRequestedKols(" + cl + "," + ids[i] + ")' href='#' class='tooltipLink approve' rel='tooltip' title=\"Approve profile request\">&nbsp;</a></div> <div class='tooltip-demo tooltop-left approve-reject'><a onclick='showRejectBox(" + cl + "," + ids[i] + ")' href='#' class='tooltipLink reject' rel='tooltip' title=\"Reject profile request\">&nbsp;</a></div>";
				    		jQuery("#myPendingApprovalsResultSet").jqGrid('setRowData',ids[i],{act:be});
				    	}else{
				    		be = "<div style='margin-right: 10px;'><label><div class='actionIcon deleteIcon tooltip-demo tooltop-left' onclick=\"deleteRequsetedKol('" + cl + "','" + ids[i] + "'); return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Delete\">&nbsp;</a></div></label></div>";
					    	//jQuery("#myPendingApprovalsResultSet").jqGrid('setRowData',ids[i],{act:be});
					    }

						microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewKolMicroProfile('"+rowData.kol_id+"',this); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Profile Snapshot\">&nbsp;</a></div></label>";
				    	jQuery("#myPendingApprovalsResultSet").jqGrid('setRowData',ids[i],{micro:microviewLink}); 
			    	}
		    	jQuery("#myPendingApprovalsResultSet").jqGrid('navGrid','hideCol',"id"); 
		    	//Initialize the tooltips
		    	<?php $mobile = mobile_device_detect(); 
				if(!isset($mobile[1])){	?>			
					initializeCustomToolTips();
				<?php }?>
		    	},
		    	onSelectAll: function(aRowids,status) {
		    		var ids = jQuery("#myPendingApprovalsResultSet").jqGrid('getDataIDs'); 
		    		for(var i=0;i < ids.length;i++){ 
		    			var arrId = jQuery('#myPendingApprovalsResultSet').jqGrid ('getRowData', ids[i]);
		    			var cl = arrId.id;
		    			var rowData = jQuery("#myPendingApprovalsResultSet").jqGrid('getRowData', ids[i]);
					    	if(rowData.status=='Approved' || rowData.status=='Profiling' || rowData.status=='Review'){
					    		  var cbs = $("tr.jqgrow > td > input.cbox:disabled",jQuery("#myPendingApprovalsResultSet")[0]);
					                cbs.removeAttr("checked");
					                //modify the selarrrow parameter
					                jQuery("#myPendingApprovalsResultSet")[0].p.selarrrow = jQuery("#myPendingApprovalsResultSet").find("tr.jqgrow:has(td > input.cbox:checked)")
					                    .map(function() { return this.id; }) // convert to set of ids
					                    .get(); // convert to instance of Array
							}
			    	} 
		        }
			});
			//jQuery("#JQBlistAllResultSet").jqGrid('navGrid','#listAllPager',{edit:false,add:false,del:false,search:false,refresh:false});
			jQuery("#myPendingApprovalsResultSet").jqGrid('navGrid','#myPendingApprovalsPager',{edit:false,add:false,del:false,search:false,refresh:false});
			//Toolbar search bar below the Table Headers
			jQuery("#myPendingApprovalsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn",beforeSearch: function(){
				/*$(".ui-search-toolbar input[type='text']").each(function(){
					if($(this).val() == 'Search')
						$(this).val("");
			    });*/
			},afterSearch:function(){
				/*$(".ui-search-toolbar input[type='text']").each(function(){
					if($(this).val() == '')
						$(this).val("Search");
			    });*/
			}}); 

			if(autoApproveRequest){
		   		$('#jqgh_myPendingApprovalsResultSet_rn').html('All');
		   		$("#jqgh_myPendingApprovalsResultSet_rn").css("margin-right","-2px");
		   		$("#jqgh_myPendingApprovalsResultSet_rn").css("margin-top","4px");
		   		$("#jqgh_myPendingApprovalsResultSet_rn").css("text-align","right");
		   	}
		   	
			//Add action button in the title bar
			if(autoApproveRequest){
				var buttonsText = "<div class='title-bar-actions'>";
					buttonsText += "<a class='blueButton approve-button' href='#' onclick='approveRequestedKols()' class='tooltipLink' rel='tooltip' title='Approve profile request(s)'>Approve</a>";
					buttonsText += "<a class='blueButton reject-button' href='#' onclick='showRejectBox()' class='tooltipLink' rel='tooltip' title='Reject profile request(s)'>Reject</a>";
					buttonsText += "<div class='excelExportIcon sprite_iconSet tooltip-demo' onclick='export_excel(1)'> <a rel='tooltip' href='#' title='Export'>&nbsp;</a></div>";
					buttonsText += "</div>";
				$("#myPendingApprovals .ui-jqgrid-titlebar").append(buttonsText);
			}else{
				//Add action button in the title bar
				var buttonsText = "<div class='title-bar-actions'>";
					buttonsText += "<div class='excelExportIcon sprite_iconSet tooltip-demo' onclick='export_excel(1)'> <a rel='tooltip' href='#' title='Export'>&nbsp;</a></div>";
					buttonsText += "</div>";
				$("#myPendingApprovals .ui-jqgrid-titlebar").append(buttonsText); 
			}
			jQuery("#myPendingApprovalsResultSet").jqGrid('setGridWidth',jqgridMaxWidth); 
					
		}

		function allProfileRequests(){
			jqgridMaxWidth	= 1305;
			$("#allProfileRequests").html("");
			// Append the required div and table
			$("#allProfileRequests").html('<table id="allProfileRequestsResultSet"></table><div id="allProfileRequestsPager"></div>');
		
			jQuery("#allProfileRequestsResultSet").jqGrid({
			   	url:'<?php echo base_url()?>requested_kols/list_all_profile_requests/',
				datatype: "json",
			 	colNames:['Id','','','',statusHeader,nameHeader,approverHeader,organizationHeader,createdByHeader,requestTypeHeader,'',"Requested On","Approved / Rejected On"],
			   	colModel:[
							{name:'id',index:'id', hidden:true},
							{name:'created_by',index:'created_by', hidden:true},
							{name:'kol_id',index:'kol_id', hidden:true},
							{name:'micro',index:'micro',width:30, search:false },
							{name:'status',index:'status',width:100, resizable:false,title: false},
							{name:'kol_name',index:'kol_name',width:190 },
							{name:'approved_by',index:'approved_by',width:100, resizable:false},
							{name:'name',index:'name',width:220},
					   		{name:'user_full_name',index:'user_full_name',width:120, resizable:false},
							{name:'request_for',index:'request_for',width:100 },
							{name:'comments',index:'comments',width:100,hidden:true },
							{name:'requested_on',index:'requested_on',width:100 },
							{name:'rej_or_appr_on',index:'rej_or_appr_on',width:200 }
			   	],
			   	rowNum:10,
			   	rownumbers: true,
				//rownumWidth: 60,
				multiselect: false,
			   	autowidth: false, 
			   	loadonce:true,
			   	ignoreCase:true,
			   	hiddengrid:false,
			   	height: "auto",	
			   	width:"100%",
			   	resizable:true,
			   	shrinkToFit: true,
			   	pager: '#allProfileRequestsPager',
			   	mtype: "POST",
			   	sortname: 'rej_or_appr_on',
			    viewrecords: true,
			    sortorder: "desc",
			    jsonReader: { repeatitems : false, id: "0" }, 
			    caption:allProfRequestTitle,
			   	rowList:paginationValues,
			   	afterInsertRow: function(rowid, aData) {
				   	if(aData.status == 'Rejected'){
				   		jQuery("#allProfileRequestsResultSet").setCell(rowid, 'status', '', '',{ title: "Click to View Reason" });
				   		jQuery("#allProfileRequestsResultSet").setCell(rowid, 'status', '', '',{ onclick: "showRejectREason(this,'"+aData.comments+"');" });
				   	}
				   	else
			    		jQuery("#allProfileRequestsResultSet").setCell(rowid, 'status', '', '',{ title: aData.status });
			    },
			    gridComplete: function(){
			    	var ids = jQuery("#allProfileRequestsResultSet").jqGrid('getDataIDs'); 
		    		for(var i=0;i < ids.length;i++){ 
				    	var cl = ids[i];				    	
				    	var rowData = jQuery("#allProfileRequestsResultSet").jqGrid('getRowData', cl);
						    	
				    	microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewKolMicroProfile('"+rowData.kol_id+"',this,true); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Profile Snapshot\">&nbsp;</a></div></label>";
				    	jQuery("#allProfileRequestsResultSet").jqGrid('setRowData',cl,{micro:microviewLink});
		    		} 

			    	jQuery("#allProfileRequestsResultSet").jqGrid('navGrid','hideCol',"id"); 
			    	//Initialize the tooltips
			    	<?php $mobile = mobile_device_detect(); 
					if(!isset($mobile[1])){	?>			
						initializeCustomToolTips();
					<?php }?>
		    	},
		    	onSelectAll: function(aRowids,status) {
		    		var ids = jQuery("#allProfileRequestsResultSet").jqGrid('getDataIDs'); 
		    		for(var i=0;i < ids.length;i++){ 
		    			var arrId = jQuery('#allProfileRequestsResultSet').jqGrid ('getRowData', ids[i]);
		    			var cl = arrId.id;
		    			var rowData = jQuery("#allProfileRequestsResultSet").jqGrid('getRowData', ids[i]);
					    	if(rowData.status=='Approved' || rowData.status=='Profiling' || rowData.status=='Review'){
					    		  var cbs = $("tr.jqgrow > td > input.cbox:disabled",jQuery("#allProfileRequestsResultSet")[0]);
					                cbs.removeAttr("checked");
					                //modify the selarrrow parameter
					                jQuery("#allProfileRequestsResultSet")[0].p.selarrrow = jQuery("#allProfileRequestsResultSet").find("tr.jqgrow:has(td > input.cbox:checked)")
					                    .map(function() { return this.id; }) // convert to set of ids
					                    .get(); // convert to instance of Array
							}
			    	} 
		        }
			});
			//jQuery("#JQBlistAllResultSet").jqGrid('navGrid','#listAllPager',{edit:false,add:false,del:false,search:false,refresh:false});
			jQuery("#allProfileRequestsResultSet").jqGrid('navGrid','#allProfileRequestsPager',{edit:false,add:false,del:false,search:false,refresh:false});
			//Toolbar search bar below the Table Headers
			jQuery("#allProfileRequestsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn",beforeSearch: function(){
				$(".ui-search-toolbar input[type='text']").each(function(){
					if($(this).val() == 'Search')
						$(this).val("");
			    });
			},afterSearch:function(){
				/*$(".ui-search-toolbar input[type='text']").each(function(){
					if($(this).val() == '')
						$(this).val("Search");
			    });*/
			}});

			//Add action button in the title bar
			var buttonsText = "<div class='title-bar-actions'>";
				buttonsText += "<div class='excelExportIcon sprite_iconSet' onclick='export_excel(2)' >	<a rel='tooltip' href='#' title='Export'>&nbsp;</a>	</div>";
				buttonsText += "</div>";
			$("#allProfileRequestsGridContainer .ui-jqgrid-titlebar").append(buttonsText); 		
			jQuery("#allProfileRequestsResultSet").jqGrid('setGridWidth',jqgridMaxWidth); 
		}

		$(document).ready(function(){
			myPendingApprovals();
			allProfileRequests();
			var addNewKol = {
					title: "Add KOL",
					modal: true,
					autoOpen: false,
					width: 400,
					draggable:false,
					position: ['center', modalBoxTopPosition],
					dialogClass: "microView",
					open: function() {
						//display correct dialog content
					}
			};
	
			$("#addNewKol").dialog(addNewKol);

			addNewKol.width = 400;	
			$("#upgradeKol").dialog(addNewKol);

			$(".ui-icon-closethick").click(function(){
				$("#addNewKol").dialog('option','width',550);
			});

			if(urlFilters != null){
				//alert(urlFilters);
				addNewKolProfile();
				$("#addNewKol").css({"height":"auto"});
			}
			
		});

		function showRejectREason(thisEle,comments){
			var pos = getElementAbsolutePos(thisEle);

			var xPos=pos.x+23;
			var yPos=pos.y+170;
			var position = findPos(thisEle);
			$("#arraouHolder").css({'position': 'absolute','top':position[0]-57,'left':position[1]+13});
			$("#contentHolder").css({'position': 'absolute','top':position[0]-24,'left':position[1]+24});
			$("#arraouHolder").show();
			$("#contentHolder").show();
			$(".profileContent").html(comments);
			$("#contentHolder").addClass("reasonContent");
		}
		function addNewKolProfile(){
			$(".addNewKolContent").html("<div class='microViewLoading'>Loading...</div>");
			$("#addNewKol").dialog("open");
			$(".addNewKolContent").load(base_url+'requested_kols/add_cleint_kol',{},function(){
				if(urlFilters != null){
					$(".msgBox").html("Contact you are looking for is not pressent in iProfile. Would you like to request for profile?");
					$("#first_name").val(urlFilters.FIRST);
					$("#middle_name").val(urlFilters.MIDDLE);
					$("#last_name").val(urlFilters.LAST);
					$("#npiNum").val(urlFilters.NPI);

					$("input[value='Full Profile']").attr("checked","checked");
					urlFilters = null;
					
				}
			});
			return false;	
		}
	
		function approveRequestedKols(id,rowId){
			var arrIds = new Array();
			var arrKolids = new Array();
			if(id == null){
				arrIds	= $("#myPendingApprovalsResultSet").getGridParam('selarrrow');
				$.each(arrIds, function( index, value ) {
					var arrRowData = jQuery('#myPendingApprovalsResultSet').jqGrid ('getRowData', value);
					//arrKolids.push($("#myPendingApprovalsResultSet").jqGrid ('getCell', value, 'kol_id'));
					arrKolids.push(arrRowData.id);
				});
			}
			else{
				arrIds.push(rowId);
				arrKolids.push(id);
			}
			if(arrIds == ''){
				jAlert("Please select at least one KTL")
				return false;
			}
			var data = {};
			data['arrIds'] = arrKolids;			
			jConfirm("The <?php echo lang("KOL"); ?> Profile request(s) will be sent for processing. You will not be able to undo this request. You will get a notification once the requests are processed.",'Please Confirm',function(event){
				if(event){
					$('#listKolsTbl').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
					$('#msg').removeClass('success');
					$('#msg').addClass('notice');
					$('#msg').show();

					$('#msg').html('Saving the data... <img src="'+base_url+'images/ajax_loader_black.gif" />');
				
					$.ajax({
							url:'<?php echo base_url()?>requested_kols/approve',
							type:'post',
							data:data,
							dataType:'json',
							success:function(returnData){
								$('#listKolsTbl').unblock();
								$('#msg').fadeOut(1500);
								//myPendingApprovals();
								//allProfileRequests();
								var numberSelected = arrIds.length;
								for(i=0;i<numberSelected;i++){
									var id = arrIds[i];
									var rowData = jQuery("#myPendingApprovalsResultSet").jqGrid('getRowData', id);
									rowData.status = 'Approved';
									rowData.approved_by = returnData.approved_by;

									var selectedOPtion = $(".ui-pg-selbox").val();
									$(".ui-pg-selbox option:last").attr('selected','selected');
							    	$('.ui-pg-selbox').trigger('change');

							    	var su=jQuery("#allProfileRequestsResultSet").jqGrid('setRowData',id,rowData);
									$('#myPendingApprovalsResultSet').jqGrid('delRowData',id);  
							    	
							    	$(".ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');
							    	$('.ui-pg-selbox').trigger('change');
								}
							}
		
						});
			}else{
				return false;
				}
			});
				
		}

		function selectAll(thise){
			if($(thise).attr("checked")=='checked'){

				$.each($("input[name='kol_id[]']"),function(){
					if($(this).attr('disabled')!='disabled')
					$(this).attr('checked','checked');
				});

			}else{
				$.each($("input[name='kol_id[]']"),function(){
					$(this).removeAttr('checked','checked');
				});
			}
			//if($(this).attr("checked","chcked"))

		}

		function deleteRequsetedKol(id,rowId){
			var formAction ='<?php echo base_url();?>requested_kols/delete/'+id;
			jQuery("#myPendingApprovalsResultSet").jqGrid('delGridRow',rowId,{reloadAfterSubmit:false,url:formAction}); 
			$('#allProfileRequestsResultSet').jqGrid('delRowData',rowId); 
			//$("#delmodmyPendingApprovalsResultSet").addClass("gridConfirmFormCenterAlign");
			$("#delmodmyPendingApprovalsResultSet").center();
		}

		function rejectRequestedKol(id,rowId){
			$("#addNewKol").dialog("close");
			var arrIds = new Array();
			var arrKolids = new Array();
			if(id == null){
				arrIds	= $("#myPendingApprovalsResultSet").getGridParam('selarrrow');				
				$.each(arrIds, function( index, value ) {
					var arrRowData = jQuery('#myPendingApprovalsResultSet').jqGrid ('getRowData', value);
					arrKolids.push(arrRowData.id);
					//arrKolids.push($("#myPendingApprovalsResultSet").jqGrid ('getCell', value, 'id'));
				});					
			}
			else{
				arrIds.push(rowId);
				arrKolids.push(id);
			}

			var data = {};
			data['comments'] = $("#comments").val();
			data['arrIds'] = arrKolids;
			$('#listKolsTbl').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
			$('#msg').removeClass('success');
			$('#msg').addClass('notice');
			$('#msg').show();

			$('#msg').html('Rejecting the data... <img src="'+base_url+'images/ajax_loader_black.gif" />');
		
			$.ajax({
					url:'<?php echo base_url()?>requested_kols/reject',
					data:data,
					type:'post',
					dataType:'json',
					success:function(returnData){
						$('#msg').html('Rejected successfully');
						$('#msg').fadeOut(1500);
						$('#listKolsTbl').unblock();
						//myPendingApprovals();
						//allProfileRequests();
						var numberSelected = arrIds.length;
						for(i=0;i<numberSelected;i++){
							var id = arrIds[i];
							var rowData = jQuery("#myPendingApprovalsResultSet").jqGrid('getRowData', id);
							rowData.status = 'Rejected';
							rowData.approved_by = returnData.approved_by;
							rowData.comments = data['comments'];

							var selectedOPtion = $(".ui-pg-selbox").val();
							$(".ui-pg-selbox option:last").attr('selected','selected');
					    	$('.ui-pg-selbox').trigger('change');

					    	var su=jQuery("#allProfileRequestsResultSet").jqGrid('setRowData',id,rowData);
							$('#myPendingApprovalsResultSet').jqGrid('delRowData',id);
							$("#allProfileRequestsResultSet tr#"+rowData.id+" td:eq(5)"). attr("title",rowData.comments);
							$("#allProfileRequestsResultSet tr#"+rowData.id+" td:eq(5)"). attr("onclick","showRejectREason(this,'"+rowData.comments+"');");
					    	
					    	$(".ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');
					    	$('.ui-pg-selbox').trigger('change');
						}
					}
				});

		}

		function showRejectBox(id,rowId){
			var arrIds = new Array();
			if(id == null)
				arrIds	= $("#myPendingApprovalsResultSet").getGridParam('selarrrow');
			else
				arrIds.push(id);

			if(arrIds == ''){
				jAlert("Please select at least one KTL")
				return false;
			}
			
			$(".addNewKolContent").html("<div id='rejectBox'><label>Reason for rejecting Profile(s) </label><textarea id='comments'></textarea><input type='button' value='Reject' onclick='rejectRequestedKol("+id+","+rowId+");' /></div>");
			$("#addNewKol").dialog("open");
			return false;	
		}


		function viewKolMicroProfile(kolId,thisEle,allPage){
				$("#contentHolder").removeClass("reasonContent");
				//var elmt=document.getElementById(kolId);	
				var pos = getElementAbsolutePos(thisEle);

				var xPos=pos.x+23;
				if(allPage == null){
					var yPos=pos.y+170;
				}else{
					var yPos=pos.y+480;
				}
				$("#arraouHolder").css({'position': 'absolute','top':yPos-31,'left':xPos-11});
				$("#contentHolder").css({'position': 'absolute','top':yPos,'left':xPos});

				var position = findPos(thisEle);
				$("#arraouHolder").css({'position': 'absolute','top':position[0]-57,'left':position[1]+13});
				$("#contentHolder").css({'position': 'absolute','top':position[0]-24,'left':position[1]+24});
				
				$("#arraouHolder").show();
				$("#contentHolder").show();

				$(".profileContent").html("");
				//$("#contentHolder").html("<div class='microViewLoading'>Loading...</div>");
				$('#contentHolder .profileContent').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(../images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});		


				$("#contentHolder .profileContent").load(base_url+'kols/view_kol_micro/'+kolId+'/'+kolId+'/1',{},
						function(){	$('#contentHolder .profileContent').unblock(); }
					);
				
				return false;
			}

		function findPos(obj) {
			 var obj2 = obj;
			 var curtop = 0;
			 var curleft = 0;
			 if (document.getElementById || document.all) {
			  do  {
			   curleft += obj.offsetLeft-obj.scrollLeft;
			   curtop += obj.offsetTop-obj.scrollTop;
			   obj = obj.offsetParent;
			   obj2 = obj2.parentNode;
			   while (obj2!=obj) {
			    curleft -= obj2.scrollLeft;
			    curtop -= obj2.scrollTop;
			    obj2 = obj2.parentNode;
			   }
			  } while (obj.offsetParent)
			 } else if (document.layers) {
			  curtop += obj.y;
			  curleft += obj.x;
			 }
			 return [curtop, curleft];
			}   // en
			
		function closeKolProfile(){
			$("#arraouHolder").hide();
			$(".profileContent").html("");
			$("#contentHolder").hide();
		}

		function showUpgradeBox(){
			$(".upgradeKolContent").html("");
			$(".upgradeKolContent").html("<div class='microViewLoading'>Loading...</div>");
			$("#upgradeKol").dialog("open");
			$(".upgradeKolContent").load(base_url+'requested_kols/upgrade_request_page');
			return false;	
		}

		function saveUpgradeRequest(thisEle){
			if(userRoleId == ROLE_MANAGER || userRoleId == ROLE_ADMIN)
				jAlert("The <?php echo lang("KOL");?>  Profile request(s) will be sent for processing. You will not be able to undo this request. You will get a notification once the requests are processed");
			else
				jAlert("Your <?php echo lang("KOL");?>  Profile request has been submitted to your manager for approval. We will notify you when your request is approved");
			
			$('.msgBox').removeClass('success');
			$('.msgBox').addClass('notice');
			$('.msgBox').show();
			$('.msgBox').html('Saving the data... <img src="'+base_url+'images/ajax_loader_black.gif" />');

			var data = {};
			if(thisEle == null){
				data['kol_id'] = $("#kol_id").val();
				data['profile_type'] = $("#profile_type").val();
			}else{
				data['kol_id'] = $(thisEle).parent().parent().find('#kol_id').val();
				data['profile_type'] = $(thisEle).parent().find('#profile_type').val();
			}
			
			$.ajax({
					url:'<?php echo base_url()?>requested_kols/save_upgrade_request',
					data:data,
					type:'post',
					dataType:'json',
					success:function(returnData){
						if(returnData.saved == true){
							$('.msgBox').html('Saved successfully');
							$('.msgBox').fadeOut(1500);
							//myPendingApprovals();
							//allProfileRequests();
							if(returnData.arrKol.org_name == '0')
								returnData.arrKol.org_name = "";
							var datarow = {
								id:returnData.arrKol.id,
								created_by		:	returnData.arrKol.created_by,
								kol_id:returnData.arrKol.kol_id,
								micro:"<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewKolMicroProfile('"+returnData.kol_id+"',this); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Profile Snapshot\">&nbsp;</a></div></label>",
								status:returnData.arrKol.status,
								kol_name:returnData.arrKol.kol_name,
								request_for:returnData.arrKol.request_for,
								name:returnData.arrKol.org_name,
								user_full_name:	returnData.arrKol.user_full_name
							};
							if(!returnData.is_manager)
								var su=jQuery("#myPendingApprovalsResultSet").jqGrid('addRowData',returnData.arrKol.id,datarow);
							else
								datarow.approved_by =  datarow.user_full_name;
							var dt=jQuery("#allProfileRequestsResultSet").jqGrid('addRowData',returnData.arrKol.id,datarow); 

							if(thisEle == null)
								$("#upgradeKol").dialog("close");
							else
								$("#addNewKol").dialog("close");
						}else{
							$('.msgBox').html(returnData.msg);
						}
					}
				});
		}

		function sendReRequest(thisEle){
			if(autoApproveRequest)
				jAlert("The KOL Profile request(s) will be sent for processing. You will not be able to undo this request. You will get a notification once the requests are processed");
			else
				jAlert("Your <?php echo lang("KOL");?>  Profile request has been submitted to your manager for approval. We will notify you when your request is approved");
			
			$('.msgBox').addClass('notice');
			$('.msgBox').show();
			$('.msgBox').html('Saving the data... <img src="'+base_url+'images/ajax_loader_black.gif" />');

			var data = {};
			data['kol_id'] = $(thisEle).parent().parent().find('#kol_id').val();
			data['current_profile_type'] = $(thisEle).parent().parent().find('#current_profile_type').val();
			
			
			$.ajax({
					url:'<?php echo base_url()?>requested_kols/re_request',
					data:data,
					type:'post',
					dataType:'json',
					success:function(returnData){
						$('.msgBox').html('Saved successfully');
						$('.msgBox').fadeOut(1500);
						//myPendingApprovals();
						//allProfileRequests();
						if(returnData.arrKol.org_name == '0')
							returnData.arrKol.org_name = "";
						
						var datarow = {
							id:returnData.arrKol.id,
							created_by		:	returnData.arrKol.created_by,
							kol_id:returnData.arrKol.kol_id,
							micro:"<label><div class='tooltip-demo tooltop-right microViewIcon' onclick=\"viewKolMicroProfile('"+returnData.kol_id+"',this); return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Profile Snapshot\">&nbsp;</a></div></label>",
							status:returnData.arrKol.status,
							kol_name:returnData.arrKol.kol_name,
							request_for:returnData.arrKol.request_for,
							name:returnData.arrKol.org_name,
							user_full_name:	returnData.arrKol.user_full_name
						};
						if(!returnData.is_manager)
							var su=jQuery("#myPendingApprovalsResultSet").jqGrid('addRowData',returnData.arrKol.id,datarow);
	
						datarow.approved_by =  datarow.user_full_name;
						var dt=jQuery("#allProfileRequestsResultSet").jqGrid('addRowData',returnData.arrKol.id,datarow); 
					
						$("#addNewKol").dialog("close");
					}
				});
		}

		function export_excel(type){
			$('#type').val(type);
			var excelFilters = '';
			if(type==1){
    			$("#myPendingApprovals .ui-jqgrid tr.ui-search-toolbar th input").each(function(){
    				if($(this).val() != ''){
    					var filterName = $(this).attr('name');
    					var filterValue = $(this).val();
    					excelFilters += filterName+" : "+filterValue+",";
    				}
    			});
    			$("#filters").val(excelFilters);
    			var selectedOPtion = $("#myPendingApprovals .ui-pg-selbox").val();
    			$("#myPendingApprovals .ui-pg-selbox option:last").attr('selected','selected');
    	    	$('#myPendingApprovals .ui-pg-selbox').trigger('change');
    	    	var arrIds = jQuery("#myPendingApprovalsResultSet").jqGrid('getDataIDs');
    	    	var id =[];
    	    	// Loop trough each row(id) and prepare a microview, edit and delete links and update the perticular row
    	    	for(var i=0;i < arrIds.length;i++){ 
    	    		var arrId =  jQuery('#myPendingApprovalsResultSet').jqGrid ('getRowData',  arrIds[i]);
    		    	id.push(arrId.id);	
    	    	}
    	    	$('#exportIds').val(id);
    			//return false;
    			//console.log(arrId);
    	    	$('#exportClientRequestDetail').submit();
    	    	$("#myPendingApprovals .ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');
    	    	$('#myPendingApprovals .ui-pg-selbox').trigger('change');
			}else{
				$("#allProfileRequestsGridContainer .ui-jqgrid tr.ui-search-toolbar th input").each(function(){
					if($(this).val() != ''){
						var filterName = $(this).attr('name');
						var filterValue = $(this).val();
						excelFilters += filterName+" : "+filterValue+",";
					}
				});
				$("#filters").val(excelFilters);
				var selectedOPtion = $("#allProfileRequestsGridContainer .ui-pg-selbox").val();
				$("#allProfileRequestsGridContainer .ui-pg-selbox option:last").attr('selected','selected');
		    	$('#allProfileRequestsGridContainer .ui-pg-selbox').trigger('change');
		    	var arrIds = jQuery("#allProfileRequestsResultSet").jqGrid('getDataIDs');
		    	var id=[] ;
		    	// Loop trough each row(id) and prepare a microview, edit and delete links and update the perticular row
		    	for(var i=0;i < arrIds.length;i++){ 
		    		var arrId =  jQuery('#allProfileRequestsResultSet').jqGrid ('getRowData',  arrIds[i]);
			    	id.push(arrId.id);	
		    	}
		    	$('#exportIds').val(id);
			//	return false;
		    	$('#exportClientRequestDetail').submit();
		    	$("#allProfileRequestsGridContainer .ui-pg-selbox option[value="+selectedOPtion+"]").attr('selected','selected');
		    	$('#allProfileRequestsGridContainer .ui-pg-selbox').trigger('change');
			}
		}
		
	</script>
	<form action="<?php echo base_url()?>requested_kols/export_kol_detail" method="post" id="exportClientRequestDetail">
		<input type="hidden" value="" name="exportIds" id="exportIds" />
		<input type="hidden" value="" name="filters" id="filters" />
		<input type="hidden" value="" name="type" id="type" />
	</form>
	<div id="listKols">
		<div id="msg"></div>
		<div id="listKolsTbl">
			
		</div>
	</div>
	<div id="addNewKol" class="microProfileDialogBox">
		<div class="addNewKolContent profileContent"></div>
	</div>
	<div id="upgradeKol" class="microProfileDialogBox">
		<div class="upgradeKolContent profileContent"></div>
	</div>
	
	
	<div>
		<div class="gridWrapper" id="myPendingApprovals" style="clear: both;">
			<table id="myPendingApprovalstResultSet"></table>
			<div id="myPendingApprovalstPager"></div>
		</div>
		
		<div class="gridWrapper" id="allProfileRequestsGridContainer">
			<table id="allProfileRequestsResultSet"></table>
			<div id="allProfileRequestsPager"></div>
		</div>		
	</div>
	
	<!-- Container for the 'Micro Profile'  box -->
		<div id="contentHolder" class="callOutTest microView" style="display: none;">
			<div>
				<a href="#" onclick="return false;" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span onclick="closeKolProfile();" class="ui-icon ui-icon-closethick">close</span></a><!--
				<img class="ui-icon ui-icon-closethick" alt="" src="" onclick="closeKolProfile();" />
			--></div>
			<div class="profileContent"></div>
		</div>
		<div id="arraouHolder" class="callOutTest" style="display: none;"><div class="arrowMarkIcon"></div></div>