<link rel="stylesheet" href="https://localhost/hmvc/assets/jqgrid/css/jquery-ui-1.8.4.custom.css" />
<link rel="stylesheet" href="https://localhost/hmvc/assets/jqgrid/css/ui.jqgrid.css" />
<link rel="stylesheet" href="https://localhost/hmvc/assets/jqgrid/css/ui.multiselect.css" />
<link rel="stylesheet" href="https://localhost/hmvc/assets/jqgrid/css/jqgrid.css" />

<script type="text/javascript" src="https://localhost/hmvc/assets/jqgrid/jquery.js"></script>
<script type="text/javascript" src="https://localhost/hmvc/assets/jqgrid/jquery-ui-1.8.4.custom.min.js"></script>
<script type="text/javascript" src="https://localhost/hmvc/assets/jqgrid/i18n/grid.locale-en.js"></script>
<script type="text/javascript" src="https://localhost/hmvc/assets/jqgrid/jquery.jqGrid.min_3.8.js"></script>
<script type="text/javascript">
var base_url = "<?php echo base_url(); ?>";
var orgId = '<?php echo $arrOrganization['id'];?>';
$(document).ready(function(){
	allAffilatesResult();
	allInteractionResult();
	allKeyPeopleResult();

	$("form#saveNote").submit(function(){
    	var noteVal = $.trim($("#user-note").val());
    	if(noteVal.length > 200){
    		jAlert("Note is too long. Max 200 characters allowed");
    		return false;
    	}
    	if(noteVal == ''){
    		jAlert("Note should not be empty");
    		return false;
    	}	    	
        var formData = new FormData($(this)[0]);
        //console.log(formData);
    	var data = {};
    	data['note'] = noteVal;
    	$('#saveBtn').attr('disabled','disabled');    	    	
    	$('#saveBtn').text('Processing...');
    	$.ajax({
    		url:base_url+'organizations/save_notes/'+orgId,
    		type:'post',
    		dataType:'json',
    		data: formData,
    		async: false,
    		cache: false,
	        contentType: false,
	        processData: false,
    		success:function(returnData){
    			$('#notesCountDown').html('200');
    			if(returnData.id){
    				var newNotesText = "<li id='"+returnData.id+"'>";
    				newNotesText += '<div id="container-'+returnData.id+'">';
    				newNotesText += '<span class="'+returnData.id+'">'+$("#user-note").val()+'</span>';
    				newNotesText += '<div class="notes-actions">';
    				if(returnData.document!=''){
    					newNotesText += '<div class="actionIcon downloadIcon tooltip-demo tooltop-left" style="background: none;"><a href="'+base_url+'organizations/note_document_download/'+returnData.id+'" class="tooltipLink" rel="tooltip" ></a>Download file</div>';
    				}
    				newNotesText += '	<div class="actionIcon editIcon tooltip-demo tooltop-left" onclick="editNote('+returnData.id+'); return false;"><a data-original-title="Edit" href="#" class="tooltipLink" rel="tooltip"></a></div>&nbsp;&nbsp;';
    				newNotesText += '	<div class="actionIcon deleteIcon tooltip-demo tooltop-left" onclick="deleteNote('+returnData.id+'); return false;"><a href="#" class="tooltipLink" rel="tooltip" title="Delete"></a></div>';
    				newNotesText += '</div>';
    				newNotesText += '<div>';
    				if(returnData.document!=''){
    					newNotesText += '<div class="notes-details">Uploaded document: <gg id="uploadedFile_'+returnData.id+'">'+returnData.document_name+'</gg></div>';
    				}
    				newNotesText += '<div class="notes-details">Posted by: '+returnData.name+', '+returnData.created_on+'</div>';
    				newNotesText += "</li>";
    				newNotesText +='<input type="hidden" id="orginal_file_'+returnData.id+'" value="'+returnData.orginal_doc_name+'" data-docname="'+returnData.document_name+'" />';  				
    				
    				$("#notes-container ul").prepend(newNotesText);
    				/*$('#notes-container').animate({
    			        scrollTop: $("#notes-container ul li:first").offset().top},
    			     'slow');*/
    				$(".subnotes").hide('slow');
    				$("#user-note").val('');
    				$("#saveNote").trigger('reset');
    			}
    		},
    		complete: function() {
    			$('#saveBtn').removeAttr('disabled');
    	    	$('#saveBtn').text('Save');
    		}			
    	});
        return false;
    });
	$( "#user-note" ).focus(function() {
  	  $('.subnotes').show('slow');
  });
  $( "#user-note" ).focusout(function() {
	    if($.trim($(this).val())==''){	
	  	  $('.subnotes').hide('slow');
	    }  
  });
});
function allAffilatesResult(){
	var ele=document.getElementById('allAffilatesGridContainer');
	var gridWidth=ele.clientWidth;
	var totalRecCount = '';
//	gridWidth+=10;
		/*
	*JqGrid for ALL tab
	*/
	jQuery("#JQBlistAllAffilatesResultSet").jqGrid({
		url:base_url+'organizations/list_sub_org_details/'+orgId,
		datatype:"json",
		colNames:['Id','Institute Name','Address','City','Postal Code','State' ,'Country','','','','created_by_full_name','data_type_indicator','Action'],
	   	colModel:[
			{name:'id',index:'id', hidden:true},
			{name:'sub_org',index:'sub_org',
				
				 formatter: function (cellvalue, options, rowObject) {
				//if(rowObject.status=='Completed'){
				var orgId= rowObject.id;
		        return "<a href='"+base_url+"/organizations/view/"+orgId+"' target='New' class='link' title='" + $.jgrid.stripHtml(cellvalue) + "'>" +
		            $.jgrid.htmlEncode(cellvalue) + "</a>";
				//}else{
				//	return $.jgrid.htmlEncode(cellvalue);
				//}
						
	    	},firstsortorder:'asc'
			},
			{name:'address',index:'address',width:205},
	   		{name:'city',index:'city',width:100},
	   		{name:'postal_code',index:'postal_code',width:100},
	   		{name:'region',index:'region',width:100},
	   		{name:'country',index:'country',width:100},
	   		{name:'status',index:'status' ,hidden:true},
	   		{name:'created_by',index:'created_by' ,hidden:true},
	   		{name:'client_id',index:'client_id' ,hidden:true},
	   		{name:'created_by_full_name',index:'created_by_full_name',hidden:true},
	   		{name:'data_type_indicator',index:'data_type_indicator', hidden:true},
	   		{name:'act',index:'act' ,width:70,search:false},

	   	],
	   	rowNum:5,
	   	rownumbers: true,
	   	autowidth: false, 
	   	loadonce:true,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",	
	   	width:"100%",
	   	resizable:true,
	   	shrinkToFit: true,
	   	pager: '#listAllAffilatesPager',
	   	mtype: "POST",
	   	sortname: 'sub_org',
	    viewrecords: true,
	    sortorder: "asc",
	    pgbuttons: false,
	    pgtext: null,
	    viewrecords: false,
	    jsonReader: {repeatitems : false, id: "0", records: function(obj) { totalRecCount = obj.records; }}, 
	    caption: "Records found <span id='intAffGridCountData'></span>",
	    gridComplete: function(){
			   		if(totalRecCount > 5){
			   			$("#intAffGridCountData").text("(5 of "+totalRecCount+")");
			   			$("#listAllAffilatesPager").html("<div class='show_more'><a href='"+base_url+"organizations/view_sub_organizations/"+orgId+"/all'>Show more</a></div>");
			   		}else{
			   			$("#intAffGridCountData").text("("+totalRecCount+" of "+totalRecCount+")");
	    			}
			   		var ids = jQuery("#JQBlistAllAffilatesResultSet").jqGrid('getDataIDs');
		    		for(var i=0;i < ids.length;i++){ 
		    			var be='';
					    	var cl = ids[i];
					    	var isAnalyst = jQuery("#JQBlistAllAffilatesResultSet").jqGrid('getCell',cl,'client_id');
		                    var createdByName = jQuery("#JQBlistAllAffilatesResultSet").jqGrid('getCell',cl,'created_by_full_name'); 
					    	var ret = jQuery("#JQBlistAllAffilatesResultSet").jqGrid('getRowData', cl);
					    	if(isAnalyst != 1 && isAnalyst != 'null'){                    
								be = "<div class='actionIcon iconCreatedByUser tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Added by: "+createdByName+"' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'></a></div>";
			                 }else{
			                 //	jQuery("#JQBlistAllResultSet").jqGrid('setRowData',ids[i],{created_by_full_name:'Aissel Analyst'});
			                 	var dataTypeIndicator = jQuery("#JQBlistAllAffilatesResultSet").jqGrid('getCell',cl,'data_type_indicator');
			                 	be += data_type_indicator(dataTypeIndicator);		    		
			                 }
					    	jQuery("#JQBlistAllAffilatesResultSet").jqGrid('setRowData',ids[i],{act:be});
			    	} 
		    	jQuery("#JQBlistAllAffilatesResultSet").jqGrid('navGrid','hideCol',"id"); 
	    	}
		    	
	});
	jQuery("#JQBlistAllAffilatesResultSet").jqGrid('navGrid','#listAllAffilatesPager',{edit:false,add:false,del:false,search:false,refresh:false});
	jQuery("#JQBlistAllAffilatesResultSet").jqGrid('setGridWidth',gridWidth);
}

//Key people
function allKeyPeopleResult(){
	var ele=document.getElementById('allKeyPeopleGridContainer');
	var gridWidth=ele.clientWidth;
	var totalRecCount = '';
//	gridWidth+=10;
		/*
	*JqGrid for ALL tab
	*/
	jQuery("#JQBlistAllKeyPeopleResultSet").jqGrid({
		url:base_url+'organizations/list_key_peoples/'+orgId,
		datatype:"json",
		colNames:['Id','','','Name','Title','Department','Role','','','','created_by_full_name','data_type_indicator','Action'],
	   	colModel:[
			{name:'id',index:'id', hidden:true},
			{name:'micro',index:'micro',width:40, search:false,hidden:true},
			{name:'kol_id',index:'kol_id', hidden:true},
	   		{name:'kol_name',index:'kol_name',width:150,resizable:false,
				 formatter: function (cellvalue, options, rowObject) {
				
					if(rowObject.is_kol=='Yes'){
					var kolId= rowObject.kol_id;
			        return "<a href='"+base_url+"/kols/view/"+kolId+"' target='_NEW' class='link' title='" + $.jgrid.stripHtml(cellvalue) + "'>" +
			            $.jgrid.htmlEncode(cellvalue) + "</a>";
					}else{
						return $.jgrid.htmlEncode(cellvalue);
					}
							
		    	},firstsortorder:'asc'
			},
	   		{name:'title',index:'title',width:100,resizable:false},
	   		{name:'department',index:'department', width:200,resizable:false},
	   		{name:'role',index:'role', width:150,resizable:false},
	   		{name:'is_kol',index:'is_kol', hidden:true},
	   		{name:'created_by',index:'created_by',hidden:true},
	   		{name:'client_id',index:'client_id',hidden:true},
	   		{name:'created_by_full_name',index:'created_by_full_name',hidden:true},
	   		{name:'data_type_indicator',index:'data_type_indicator', hidden:true},
	   		{name:'act',index:'act' ,width:70,search:false}
	   				   			
	   	],
	   	rowNum:5,
	   	rownumbers: true,
	   	autowidth: false, 
	   	loadonce:true,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",	
	   	width:"100%",
	   	resizable:true,
	   	shrinkToFit: true,
	   	pager: '#listAllKeyPeoplePager',
	   	mtype: "POST",
	   	sortname: 'kol_name',
	    viewrecords: true,
	    sortorder: "asc",
	    pgbuttons: false,
	    pgtext: null,
	    viewrecords: false,
	    jsonReader: {repeatitems : false, id: "0", records: function(obj) { totalRecCount = obj.records; }}, 
	    caption: "Records found  <span id='intKeyGridCountData'></span>",
	    gridComplete: function(){
			   		if(totalRecCount > 5){
			   			$("#intKeyGridCountData").text("(5 of "+totalRecCount+")");
			   			$("#listAllKeyPeoplePager").html("<div class='show_more'><a href='"+base_url+"organizations/view_keypeople/"+orgId+"'>Show more</a></div>");
			   		}else{
			   			$("#intKeyGridCountData").text("("+totalRecCount+" of "+totalRecCount+")");
	    			}
			   		var ids = jQuery("#JQBlistAllKeyPeopleResultSet").jqGrid('getDataIDs');
		    		for(var i=0;i < ids.length;i++){ 
					    	var cl = ids[i];	
					    	var be='';
					    	var isAnalyst = jQuery("#JQBlistAllKeyPeopleResultSet").jqGrid('getCell',cl,'client_id');
		                    var createdByName = jQuery("#JQBlistAllKeyPeopleResultSet").jqGrid('getCell',cl,'created_by_full_name'); 
					    	var ret = jQuery("#JQBlistAllKeyPeopleResultSet").jqGrid('getRowData', cl);
					    	if(isAnalyst != 1 && isAnalyst !='' && isAnalyst !='null'){                    
								be = "<div class='actionIcon iconCreatedByUser tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Added by: "+createdByName+"' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'></a></div>";
			                 }else{
			                 //	jQuery("#JQBlistAllResultSet").jqGrid('setRowData',ids[i],{created_by_full_name:'Aissel Analyst'});
			                 	var dataTypeIndicator = jQuery("#JQBlistKeyPeopleResultSet").jqGrid('getCell',cl,'data_type_indicator');
			                 	be += data_type_indicator(dataTypeIndicator);		    		
			                 }
					    	jQuery("#JQBlistAllKeyPeopleResultSet").jqGrid('setRowData',ids[i],{act:be});
								if(ret.is_kol=='Yes'){
						    		microviewLink = "<label><div class='tooltip-demo tooltop-right microViewIcon Male' onclick=\"viewKolMicroProfile('"+cl+"','"+ret.kol_id+"',event);return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Profile Snapshot\">&nbsp;</a></div></label>";
						    		jQuery("#JQBlistAllKeyPeopleResultSet").jqGrid('setRowData',ids[i],{micro:microviewLink}); 
								}else{
									microviewLink = "<label><div class='tooltip-demo tooltop-right requestProfile sprite_iconSet' onclick=\"addNewKolProfile('"+cl+"','keyPeople');return false;\" ><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Request Profile\">&nbsp;</a></div></label>";
						    		jQuery("#JQBlistAllKeyPeopleResultSet").jqGrid('setRowData',ids[i],{micro:microviewLink}); 
								}
						
			    	} 
		    	jQuery("#JQBlistAllKeyPeopleResultSet").jqGrid('navGrid','hideCol',"id"); 
	    	}
		    	
	});
	jQuery("#JQBlistAllKeyPeopleResultSet").jqGrid('navGrid','#listAllKeyPeoplePager',{edit:false,add:false,del:false,search:false,refresh:false});
	jQuery("#JQBlistAllKeyPeopleResultSet").jqGrid('setGridWidth',gridWidth);
}
//Interactions
function allInteractionResult(){
	var data = {};
	data['interaction_for'] = 'org';
	data['kol_id'] = orgId;
	var ele=document.getElementById('allInteractionGridContainer');
	var gridWidth=ele.clientWidth;
	var totalRecCount = '';
//	gridWidth+=10;
		/*
	*JqGrid for ALL tab
	*/
	jQuery("#JQBlistAllInteractionResultSet").jqGrid({
	   	url:base_url+'interactions/list_interactions_by_date_range/',
		datatype:"json",
	 	colNames:['Id','Organization Name','Interaction Date', 'Employee Name', 'Interaction Type', 'Discussion Type', 'Product','client_id','data_type_indicator','Action'],
	   	colModel:[
					{name:'id',index:'id', hidden:true},
					{name:'kol_name',index:'kol_name',width:170, resizable:false,formatter: "showlink"},
					{name:'date',index:'date',width:120,sorttype:'date',formatoptions: {newformat:'m/d/Y'}, datefmt: 'm/d/Y'},
			   		{name:'recorded_by',index:'recorded_by',width:100, resizable:false},
			   		{name:'mode_name',index:'mode_name',width:100, resizable:false},
					{name:'objective_name',index:'objective_name',width:180, resizable:false},
			   		{name:'product_name',index:'product_name',width:150, resizable:false},
			   		{name:'client_id',index:'client_id',width:175, resizable:false,search:false,hidden:true},
	   		   		{name:'data_type_indicator',index:'data_type_indicator', hidden:true},
	   		   		{name:'act',width:80,align:'center',search:false}
	   	],
	   	
	   	postData:data,
	   	rowNum:5,
	   	rownumbers: true,
	   	autowidth: false, 
	   	loadonce:true,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",	
	   	width:"100%",
	   	resizable:true,
	   	shrinkToFit: true,
	   	pager: '#listAllInteractionPager',
	   	mtype: "POST",
	   	sortname: 'date',
	    viewrecords: true,
	    sortorder: "desc",
	    pgbuttons: false,
	    pgtext: null,
	    viewrecords: false,
	    jsonReader: {repeatitems : false, id: "0", records: function(obj) { totalRecCount = obj.records; }}, 
	    caption: "Records found  <span id='intGridCountData'></span>",
	    gridComplete: function(){
			   		if(totalRecCount > 5){
			   			$("#intGridCountData").text("(5 of "+totalRecCount+")");
			   			$("#listAllInteractionPager").html("<div class='show_more'><a href='"+base_url+"organizations/view_interactions/"+orgId+"/interaction'>Show more</a></div>");
			   		}else{
			   			$("#intGridCountData").text("(Recent "+totalRecCount+" of "+totalRecCount+")");
	    			}
			   		var ids = jQuery("#JQBlistAllInteractionResultSet").jqGrid('getDataIDs');
		    		for(var i=0;i < ids.length;i++){ 
					    	var cl = ids[i];	
					    	var actionLink='';
					    	var isAnalyst = jQuery("#JQBlistAllInteractionResultSet").jqGrid('getCell',cl,'client_id');
					    	 var createdByName = jQuery("#JQBlistAllInteractionResultSet").jqGrid('getCell',cl,'recorded_by'); 
					    	var ret = jQuery("#JQBlistAllInteractionResultSet").jqGrid('getRowData', cl);        			
					    	if(isAnalyst != 1){                    
			               		 actionLink = "<div class='actionIcon iconCreatedByUser tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Added by: "+createdByName+"' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'></a></div>";
			                    }else{
			                    //	jQuery("#JQBlistAllResultSet").jqGrid('setRowData',ids[i],{created_by_full_name:'Aissel Analyst'});
			                    	var dataTypeIndicator = jQuery("#JQBlistAllInteractionResultSet").jqGrid('getCell',cl,'data_type_indicator');
			                    	actionLink += data_type_indicator(dataTypeIndicator);		    		
			                    }
					    	jQuery("#JQBlistAllInteractionResultSet").jqGrid('setRowData',ids[i],{act:actionLink});
			    	} 
		    	jQuery("#JQBlistAllInteractionResultSet").jqGrid('navGrid','hideCol',"id"); 
	    	}
		    	
	});
	jQuery("#JQBlistAllInteractionResultSet").jqGrid('navGrid','#listAllInteractionPager',{edit:false,add:false,del:false,search:false,refresh:false});
	jQuery("#JQBlistAllInteractionResultSet").jqGrid('setGridWidth',gridWidth);
}
function limitText(limitField, limitCount, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	} else {
		$('#'+limitCount).html(limitNum - limitField.value.length);
	}
}
function saveNote(){
	var note1 = $('#note').val();
	var note = jQuery.trim(note1);
	
	if(note==''){
		jAlert('Note Should not be empty');
		return false;
	}
	$('#noteForm').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url('+base_url+'images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
	
	var id = $('#id').val();
	
	
	$.ajax({
		url:base_url+'organizations/save_note/'+orgId,
		type:'post',
		data:$('#noteForm').serialize(),
		dataType:'json',
		success:function(data){
		$('#notesCountDown').html('200');
		$('#noteForm').unblock();
		var description = '<div class="borderBottom" id="notesContainer_'+data.id+'" onmouseover="show(this)" onmouseout="hide(this)"><div class="profileContainer" style="width: 99%;">';
					description+='<div class="profileData">';
						
						description+='<p>Posted By: '+data.name+'<span class="timestamp"> on '+data.created_on+'</span></p>';
					description+='</div>';
					description+='<div class="action" style="display:none" id="action_'+data.id+'">';
						description+='<div>';
							description+="<div class='actionIcon editIcon tooltip-demo tooltop-left' onclick='editNote("+data.id+"); return false;'><a href='#' class='tooltipLink' rel='tooltip' title='Edit'></a></div>&nbsp;&nbsp;";
							description+="<div class='actionIcon deleteIcon tooltip-demo tooltop-left' onclick='deleteNote("+data.id+"); return false;'><a href='#' class='tooltipLink' rel='tooltip' title='Delete'></a></div>";
						description+='</div>';
					description+='</div>';		
			description+='</div>';
			description+='<div class="textAreaContainer"><div class="notes expand" style="clear:both" onclick="expand(this)">'+data.note+'</div></div></div>';
			
			//description+='<h1 class="line" style=" border-bottom: 1px solid gray;padding-bottom: 5px;"></h1>';
			$('.notesContaier').prepend(description);
					
		    var thisEle = $('#notesContainer_'+data.id).children('.textAreaContainer').children('.notes');
		    	
		        var content = $(thisEle).html();
		 
		        if(content.length > showChar) {
		 
		            var c = content.substr(0, showChar);
		            var h = content.substr(showChar-1, content.length - showChar);
		 
		            var html = c + '<span class="moreellipses">' + ellipsestext+ '&nbsp;</span><span class="morecontent"><span>' + h + '</span></span>';
		 
		            $(thisEle).html(html);
		        }
		        $('#note').val('');
			
		}
		
	})
}
</script>
<style>

.object-name {
    display: inline-block;
}
.panel{
border-radius:0px !important;
}
.panel-group .panel+.panel {
    margin-top: 0px !important;
}
.panel-title {
    font-size: 13px !important;
    font-weight: bold;
}
.title{
	font-size: 14px;
	margin-top: 20px;
    font-weight: bold;
    border-bottom:1px dashed #ccc;
}
.box-background{
	background: #f4f4f4;

}
.top-buttons{
    position: absolute;
    top: 0;
    right: 0;
    margin-top: 5px;
    font-size: 12px;
}
.glyphicon { margin-right:10px; }
.panel-body { padding:0px; }
.panel-body table tr td { padding-left: 15px }
.panel-body .table {margin-bottom: 0px; }
.org-box{margin-bottom:10px;padding :10px; min-height: 190px;}
.border-box{ border:1px solid #ccc;} 
.subnotes{margin-top:10px;}
input[type=file] {
    display: inline !important;
}
.organization-container-head{
	/* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#ffffff+0,f4f4f4+47,c9c9c9+100 */
background: #ffffff; /* Old browsers */
background: -moz-linear-gradient(top,  #f0f0f0 0%, #f4f4f4 47%, #c9c9c9 100%); /* FF3.6-15 */
background: -webkit-linear-gradient(top,  #f0f0f0 0%,#f4f4f4 47%,#c9c9c9 100%); /* Chrome10-25,Safari5.1-6 */
background: linear-gradient(to bottom,  #f0f0f0 0%,#f4f4f4 47%,#c9c9c9 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#f0f0f0', endColorstr='#c9c9c9',GradientType=0 ); /* IE6-9 */
	
}
p.profileName {
    margin-bottom: 0px;
    font-weight: bold;
    text-align: center;
}
#organizationShortDetails {
    text-align: center;
    width: 100%;
    background: #ffffff;
    padding: 10px 0;
    color: #000000;
    font-weight: bold;
    border-top: 1px solid #ccc;
}
.top-header{
	padding:5px 0;
}
.margin-zero{
	margin-top:0 !important;
}
</style>
<div class="row top-header">
	<?php $this->load->view('organizations/organization_header_bar'); ?>
</div>
<div class="row">
		<div class="secondary-menu col-md-2" style="padding-right: 0px;padding-left: 0px;">
		<?php $this->load->view('organizations/organization_left_side_bar'); ?>
		</div>
		<div class="content col-md-10" style="border-left: 1px solid #ccc;">
				<div class="row">
					<div class="col-md-4">
						<div class="border-box org-box box-background">
							<div>
				    			<h4 style="margin-bottom: 5px;"><?php echo $arrOrganization['name']; ?> <span style="font-size:11px;">(University/Hospital) 
				    			<a href="<?php echo base_url();?>organizations/add_org/<?php echo $arrOrganization['id'];?>" data-toggle="tooltip" title="Edit Orgnaization details"><span class="glyphicon glyphicon glyphicon-edit"></span></a></span>
				    			</h4>
				    			<p style="font-size:10px;"><b>ADDRESS </b>: <?php 
																	if($arrOrganization['address'] != '')
																		echo $arrOrganization['address'].",";
																?><br/>
				    			<?php 		
																			if(!empty($arrOrganization['city_name']))
																				echo $arrOrganization['city_name'] . ", ";
																			if($arrOrganization['country_name']=='United States')
																					echo $arrOrganization['state_code'][0]['state_code']. " ". $arrOrganization['postal_code'];
																				else if($arrOrganization['state_name']!='' && $arrOrganization['postal_code']!='')
																					echo $arrOrganization['state_name']. " ". $arrOrganization['postal_code'];
																				else
																					echo $arrOrganization['state_name'];
																?> <br/>
				    			<?php
																			if(!empty($arrOrganization['country_name']))
																				echo $arrOrganization['country_name'];
																?>
				    			</p>
				    			<?php 
									if(!empty($arrOrganization['phone']) && sizeof($arrOrganization['phone'])>10){
										$arrOrganization['phone']	= (($arrOrganization['phone'][0]=="+")?'':'+').$arrOrganization['phone'];
									}
									if(!empty($arrOrganization['fax']) && sizeof($arrOrganization['fax'])>10){
										$arrOrganization['fax']		= (($arrOrganization['fax'][0]=="+")?'':'+').$arrOrganization['fax'];
									}
								?>
				    			<div>
				    			<b>PHONE </b>: 
				    				<?php if (strcmp($arrOrganization['phone'],"0")) { ?>
									<?php  echo '<a class="linkClickToCall" href="callto:'.$arrOrganization['phone'].'" >'.$arrOrganization['phone'].'</a>'; } ?>					
								</div>
				    			<div><b>FAX </b>: 
				    			<?php if (strcmp($arrOrganization['fax'],"0")) { ?>
								<?php echo '<a class="linkClickToCall" href="callto:'.$arrOrganization['fax'].'" >'.$arrOrganization['fax'].'</a>'; } ?>
				    			</div>
				    			<div><b>EMAIL </b>: 
				    			<?php if (strcmp($arrOrganization['email'],"0")) { ?>
								<?php echo '<a class="linkClickToCall" href="mailto:'.$arrOrganization['email'].'" >'.$arrOrganization['email'].'</a>'; } ?>
				    			</div>
				    		</div>
						</div>
					</div>
					<div class="col-md-8">
						<div class="border-box org-box box-background">
							<p class="title margin-zero">COMPANY BACKGROUND</p>
							<p>
								<?php echo $arrOrganization['background'];?>
							</p>
						</div>
					</div>
					
				</div>
				<div class="row">
						<div class="col-md-12">
							<p class="title">USER NOTE</p>
							<table class="table">
								<input type="hidden" name="orginal_doc_name" id="orginal_file_<?php echo $note['id'];?>" value="<?php echo $note['orginal_doc_name'] ?>" data-docname="<?php echo $note['document_name']?>"/>
								<?php foreach($arrNotes as $note){?>
								<tr id="<?php echo $note['id'];?>">
									
									<div id="container-<?php echo $note['id'];?>" class="clearfix">
										<?php if(strlen($note['note']) >= 400){?>
        									<span class="<?php echo $note['id'];?> halftext"><?php echo substr($note['note'],0,400)."...";?></span>
        									<span class="<?php echo $note['id'];?> fulltext a"><?php echo $note['note'];?></span>
        								<?php }else{?>
        									<span class="<?php echo $note['id'];?>"><?php echo $note['note'];?></span>
        								<?php }?>
        								
        								<div class="notes-actions">
        									<?php if($note['orginal_doc_name']!=''){ ?>
        									<div class="actionIcon downloadIcon tooltip-demo tooltop-left"><a href="<?php echo base_url(); ?>organizations/note_document_download/<?php echo $note['id'];?>" class="tooltipLink" rel="tooltip"></a>Download file</div>
        									<?php } ?>
        									<div class="actionIcon editIcon tooltip-demo tooltop-left" onclick="editNote(<?php echo $note['id'];?>); return false;"><a data-original-title="Edit" href="#" class="tooltipLink" rel="tooltip"></a></div>&nbsp;&nbsp;
        									<div class="actionIcon deleteIcon tooltip-demo tooltop-left" onclick="deleteNote(<?php echo $note['id'];?>); return false;"><a href="#" class="tooltipLink" rel="tooltip" title="Delete"></a></div>
        								</div>
        								
									</div>
									
									<?php if($note['orginal_doc_name']!=''){ ?>
        									<div class="notes-details clearfix" >Uploaded document: <gg id="uploadedFile_<?php echo $note['id']; ?>"><?php echo $note['document_name']?></gg></div>
        							<?php } ?>
        							<?php if($note['modified_by'] > 0 && $note['modified_by'] != ''){?>
        									<div class="notes-details clearfix">Modified by: <?php echo $note['modified_by_first_name']." ".$note['modified_by_last_name'];?>, <?php echo date('d M Y, h:i A', strtotime($note['modified_on']));?></div>
        							<?php }else{?>												
        									<div class="notes-details clearfix">Posted by: <?php echo $note['first_name']." ".$note['last_name'];?>, <?php echo date('d M Y, h:i A', strtotime($note['created_on']));?></div>
        							<?php }?>	
								</tr>
							<?php } ?>
							</table>
							<form id="saveNote" method="post" action="#" >
								<h6 style="margin-bottom: 0;font-weight:bold;">Add Note</h6>
								<div id="add-notes-area" >
									<textarea onkeydown="limitText(this,'notesCountDown',200);" onkeyup="limitText(this,'notesCountDown',200);" rows="2" style="width:100%;" id="user-note" name="user_note" placeholder="Enter notes..."></textarea>
								<div>You have <span id="notesCountDown">200</span> characters left. <font size="1">(Maximum characters: 200)</font></div>
								<div class="subnotes" style="display: none;">
	            						<label style="margin-left: 0 !important">Attach File :  </label><input type="text" name="fileName" id="file_name" value="" placeholder="Enter file name">
	                                    <!-- label for="contractRate" style="margin-left: 0 !important">Upload Doc:</label -->
	                                    <input type="file" name="note_file" id="noteFile" value="">
	                					<button type="submit" id="saveBtn">Save</button>        										
	            				</div>
								</div>
							</form>
						</div>
				</div>
				<div class="clearfix" style="clear:both;"></div>
				<div class="row">
					<div class="col-md-12">
						<p class="title">AFFILIATES & PARTNERS</p>
							<div class="gridWrapper" id="allAffilatesGridContainer">
														<table id="JQBlistAllAffilatesResultSet"></table>
														<div id="listAllAffilatesPager"></div>
							</div>		
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<p class="title">KEY PEOPLE</p>
							<div class="gridWrapper" id="allKeyPeopleGridContainer">
													<table id="JQBlistAllKeyPeopleResultSet"></table>
													<div id="listAllKeyPeoplePager"></div>
							</div>	
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
					<p class="title">INTERACTIONS</p>
						<div class="gridWrapper" id="allInteractionGridContainer">
												<table id="JQBlistAllInteractionResultSet"></table>
												<div id="listAllInteractionPager"></div>
						</div>		
					</div>
				</div>
		</div>
</div>