<?php
?>
<!--  -->	
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/jquery.treeview.css" />
	
	<script src="http://code.jquery.com/jquery-latest.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery-ui-1.8.4.custom.min.js" ></script>	
	
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery.treeview.js" ></script>
		<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url()?>css/themes/jquery-ui-1.8.4.custom.css" />
	
  <style type="text/css">
  #browser {
    font-family: Verdana, helvetica, arial, sans-serif;
    font-size: 68.75%;
  }
  /*
	.hitarea {
		background:transparent url(../images/treeview-default.gif) no-repeat scroll -64px -25px;
		cursor:pointer;
		float:left;
		height:16px;
		margin-left:-16px;
		width:16px;
	}
	.expandable-hitarea {
		background-position:-80px -3px;
	}
	*/

	.treeview li div{
		display: inline;
		width: 10%;
	}
	
	div .selecterContainers {
		float: left;
		width: 45%;
	}
	
	#xAxisSlider, #yAxisSlider{
		float: left;
		width: 45%;
		padding: 5px;
	}
	
	.weightage{
		border:0; 
		color:#f6931f; 
		font-weight:bold;
	}
	
  </style>
  <script>
  $(document).ready(function(){
    $("#tree").treeview({
  	 	prerendered: true
	})
  });
  </script>
  
   <script type="text/javascript" language="javascript">
  var xElements=[];
  var yElements=[];
  	function displaySliders(){

  	  	//loop trough each radio button option
		$("#treeViewContainer input[type=radio]:checked").each(function(){
				if(this.value=="x"){
					//if the selected value is x-axis, add to array only if it is not in the array
					if(xElements.indexOf(this.name)==-1)
						xElements.push(this.name);
					//remove it if it is there in the Y-array
					if(yElements.indexOf(this.name)!=-1){
						index=yElements.indexOf(this.name);
						yElements.splice(index, 1);
					}
				}
				else if(this.value=="y"){
					//if the selected value is y-axis, add to array only if it is not in the array
					if(yElements.indexOf(this.name)==-1)
						yElements.push(this.name);
					//remove it if it is there in the X-array
					if(xElements.indexOf(this.name)!=-1){
						index=xElements.indexOf(this.name);
						xElements.splice(index, 1);
					}
				}
				else {
					//if exclide is selected then remove it from both the array
					
					//remove it if it is there in the Y-array
					if(yElements.indexOf(this.name)!=-1){
						$("#slider_"+this.name).parent().remove();
						calculateAndSetTotal('yAxisSlider','total_weight_y');
						index=yElements.indexOf(this.name);
						yElements.splice(index, 1);
					}
					//remove it if it is there in the X-array
					if(xElements.indexOf(this.name)!=-1){
						$("#slider_"+this.name).parent().remove();
						calculateAndSetTotal('xAxisSlider','total_weight_x');
						index=xElements.indexOf(this.name);
						xElements.splice(index, 1);
					}
				}
			});

		
		$.each(xElements,function(key, value){
			if(($("#xAxisSlider #slider_"+value).length) == 0){
				$("#slider_"+value).parent().remove();
				calculateAndSetTotal('yAxisSlider','total_weight_y');
				$("#xAxisSlider").append("<div class='sliderContainer'><p>"+value+": </p><div id='slider_"+value+"'></div><input type='text' id='weight_"+value+"' class='weightage'/></div>");
				$("#slider_"+value).slider({
					range: "min",
					min: 0,
					max: 100,
					step:1,
					slide: function( event, ui ) {
						$( "#weight_"+value ).val( "" + ui.value );
						var total=0;
						$("#xAxisSlider .sliderContainer .weightage").each(function(){
							if(this.value!='')
								total=parseInt(total)+parseInt(this.value);
						});
						$("#total_weight_x").val(total);
					}
				});
			}
		});
		
		$.each(yElements,function(key, value){
			if(($("#yAxisSlider #slider_"+value).length) == 0){
				$("#slider_"+value).parent().remove();
				calculateAndSetTotal('xAxisSlider','total_weight_x');
				$("#yAxisSlider").append("<div class='sliderContainer'><p> "+value+": </p><div id='slider_"+value+"'></div><input type='text' id='weight_"+value+"' class='weightage'/></div>");
				$("#slider_"+value).slider({
					range: "min",
					min: 0,
					max: 100,
					step:1,
					slide: function( event, ui ) {
						$( "#weight_"+value ).val( "" + ui.value );
						var total=0;
						$("#yAxisSlider .sliderContainer .weightage").each(function(){
							if(this.value!='')
								total=parseInt(total)+parseInt(this.value);
						});
						
						$("#total_weight_y").val(total);
					}
				});
			}
		});
  }

  	function calculateAndSetTotal(axisId,totalHolderId){
		var total=0;
		$("#"+axisId+" .sliderContainer .weightage").each(function(){
			if(this.value!='')
				total=parseInt(total)+parseInt(this.value);
		});
		$("#"+totalHolderId).val(total);
	}

	function validateAndSubmit(){

		//call validate function
		
		//get all the params and the respective Weightages
		getAffiliationParamsAndWeightges('xAxisSlider');
		getAffiliationParamsAndWeightges('yAxisSlider');
		
	}

	function getAffiliationParamsAndWeightges(axisId){
		var affParams=new Array(0,0,0,new Array(),new Array());
		var affWeights=new Array();
		var i=0;
		
		$("#"+axisId+" .ui-slider").each(function(){
			var idName=this.id;
			var splitParts=idName.split("_");
			if(splitParts.length==2 && splitParts[1]=='affiliation'){
				affParams[0]=1;
				jAlert(idName);
			}else{
				
			}
			
		});
	}
  </script>

<div id="scatOpsTreeAndTable" class="scatG">
<!--    -->
	<div  id="treeViewContainer" class="selecterContainers">
	<form name="" >
	  <ul class="treeview" id="tree">
	    <li class="expandable"><div class="hitarea expandable-hitarea"></div><span><strong>Affiliations</strong></span>
	    	<div class="xAxis"><input type="radio" name="affiliation" value="x" id="affiliation_x"/> <label for="affiliation_x">X- Axis</label></div>
			<div class="yAxis"><input type="radio" name="affiliation" value="y" id="affiliation_y"/> <label for="affiliation_y">Y- Axis</label></div>
			<div class="noAxis"><input type="radio" name="affiliation" value="na" checked="checked" id="affiliation_n"/> <label for="affiliation_n">Exclude</label></div>
	      <ul style="display: none;">
			<li class="expandable"><div class="hitarea expandable-hitarea "></div><span><strong>Eng Type</strong></span>
				<div class="xAxis"><input type="radio" name="affiliation_1" value="x" id="affiliation_1_x"/> <label for="affiliation_1_x">X- Axis</label></div>
				<div class="yAxis"><input type="radio" name="affiliation_1" value="y" id="affiliation_1_y"/> <label for="affiliation_1_y">Y- Axis</label></div>
				<div class="noAxis"><input type="radio" name="affiliation_1" value="na" checked="checked" id="affiliation_1_n"/> <label for="affiliation_1_n">Exclude</label></div>
			  <ul style="display: none;">
			  	<?php foreach($arrEngagementTypes as $engType){?>
			  		<li class="endElement">
						<div class="itemName"><?php echo $engType['type'];?></div>
						<div class="xAxis"><input type="radio" name="affiliation_1_<?php echo $engType['id'];?>" value="x" id="affiliation_1_<?php echo $engType['id'];?>_x"/> <label for="affiliation_1_<?php echo $engType['id'];?>_x">X- Axis</label></div>
						<div class="yAxis"><input type="radio" name="affiliation_1_<?php echo $engType['id'];?>" value="y" id="affiliation_1_<?php echo $engType['id'];?>_y"/> <label for="affiliation_1_<?php echo $engType['id'];?>_y">Y- Axis</label></div>
						<div class="noAxis"><input type="radio" name="affiliation_1_<?php echo $engType['id'];?>" value="na" checked="checked" id="affiliation_1_<?php echo $engType['id'];?>_n"/> <label for="affiliation_1_<?php echo $engType['id'];?>_n">Exclude</label></div>
					</li>
			  	<?php }?>
			  </ul>
			</li>
			<li class="expandable lastExpandable"><div class="hitarea expandable-hitarea lastExpandable-hitarea"></div><span><strong>Org Type</strong></span>
				<div class="xAxis"><input type="radio" name="affiliation_2" value="x" id="affiliation_2_x"/> <label for="affiliation_2_x">X- Axis</label></div>
				<div class="yAxis"><input type="radio" name="affiliation_2" value="y" id="affiliation_2_y"/> <label for="affiliation_2_y">Y- Axis</label></div>
				<div class="noAxis"><input type="radio" name="affiliation_2" value="na" checked="checked" id="affiliation_2_n"/> <label for="affiliation_2_n">Exclude</label></div>
			  <ul style="display: none;">
				<?php foreach($arrOrganizationTypes as $orgType){?>
			  		<li class="endElement">
						<div class="itemName"><?php echo $orgType['type'];?></div>
						<div class="xAxis"><input type="radio" name="affiliation_2_<?php echo $orgType['id'];?>" value="x" id="affiliation_2_<?php echo $orgType['id'];?>_x"/> <label for="affiliation_2_<?php echo $orgType['id'];?>_x">X- Axis</label></div>
						<div class="yAxis"><input type="radio" name="affiliation_2_<?php echo $orgType['id'];?>" value="y" id="affiliation_2_<?php echo $orgType['id'];?>_y"/> <label for="affiliation_2_<?php echo $orgType['id'];?>_y">Y- Axis</label></div>
						<div class="noAxis"><input type="radio" name="affiliation_2_<?php echo $orgType['id'];?>" value="na" checked="checked" id="affiliation_2_<?php echo $orgType['id'];?>_n"/> <label for="affiliation_2_<?php echo $orgType['id'];?>_n">Exclude</label></div>
					</li>
			  	<?php }?>
			  </ul>
			</li>
	      </ul>
	    </li>
	    <li class="expandable"><div class="hitarea expandable-hitarea"></div><span><strong>Events</strong></span>
    		<div class="xAxis"><input type="radio" name="event" value="x" id="event_x"/> <label for="event_x">X- Axis</label></div>
			<div class="yAxis"><input type="radio" name="event" value="y" id="event_y"/> <label for="event_y">Y- Axis</label></div>
			<div class="noAxis"><input type="radio" name="event" value="na" checked="checked" id="event_n"/> <label for="event_n">Exclude</label></div>
	      <ul style="display: none;">
			<li class="expandable"><div class="hitarea expandable-hitarea"></div><span><strong>Session Type</strong></span>
				<div class="xAxis"><input type="radio" name="event_1" value="x" id="event_1_x"/> <label for="event_1_x">X- Axis</label></div>
				<div class="yAxis"><input type="radio" name="event_1" value="y" id="event_1_y"/> <label for="event_1_y">Y- Axis</label></div>
				<div class="noAxis"><input type="radio" name="event_1" value="na" checked="checked" id="event_1_n"/> <label for="event_1_n">Exclude</label></div>
			  <ul style="display: none;">
				<?php foreach($arrSessionTypes as $sessionType){?>
			  		<li class="endElement">
						<div class="itemName"><?php echo $sessionType['type'];?></div>
						<div class="xAxis"><input type="radio" name="event_1_<?php echo $sessionType['id'];?>" value="x" id="event_1_<?php echo $sessionType['id'];?>_x"/> <label for="event_1_<?php echo $sessionType['id'];?>_x">X- Axis</label></div>
						<div class="yAxis"><input type="radio" name="event_1_<?php echo $sessionType['id'];?>" value="y" id="event_1_<?php echo $sessionType['id'];?>_y"/> <label for="event_1_<?php echo $sessionType['id'];?>_y">Y- Axis</label></div>
						<div class="noAxis"><input type="radio" name="event_1_<?php echo $sessionType['id'];?>" value="na" checked="checked" id="event_1_<?php echo $sessionType['id'];?>_n"/> <label for="event_1_<?php echo $sessionType['id'];?>_n">Exclude</label></div>
					</li>
			  	<?php }?>
			  </ul>
			</li>
			<li class="expandable lastExpandable"><div class="hitarea expandable-hitarea lastExpandable-hitarea"></div><span><strong>Roles</strong></span>
				<div class="xAxis"><input type="radio" name="event_2" value="x" id="event_2_x"/> <label for="event_2_x">X- Axis</label></div>
				<div class="yAxis"><input type="radio" name="event_2" value="y" id="event_2_y"/> <label for="event_2_y">Y- Axis</label></div>
				<div class="noAxis"><input type="radio" name="event_2" value="na" checked="checked" id="event_2_n"/> <label for="event_2_n">Exclude</label></div>
			  <ul style="display: none;">
				<?php foreach($arrRoles as $role){?>
			  		<li class="endElement">
						<div class="itemName"><?php echo $role['role'];?></div>
						<div class="xAxis"><input type="radio" name="event_2_<?php echo $role['role'];?>" value="x" id="event_2_<?php echo $role['role'];?>_x"/> <label for="event_2_<?php echo $role['role'];?>_x">X- Axis</label></div>
						<div class="yAxis"><input type="radio" name="event_2_<?php echo $role['role'];?>" value="y" id="event_2_<?php echo $role['role'];?>_y"/> <label for="event_2_<?php echo $role['role'];?>_y">Y- Axis</label></div>
						<div class="noAxis"><input type="radio" name="event_2_<?php echo $role['role'];?>" value="na" checked="checked" id="event_2_<?php echo $role['role'];?>_n"/> <label for="event_2_<?php echo $role['role'];?>_n">Exclude</label></div>
					</li>
			  	<?php }?>
			  </ul>
			</li>
	      </ul>
	    </li>
	    <li class="expandable"><div class="hitarea expandable-hitarea"></div><span><strong>Publications</strong></span>
	    	<div class="xAxis"><input type="radio" name="publication" value="x" id="publication_x"/> <label for="publication_x">X- Axis</label></div>
			<div class="yAxis"><input type="radio" name="publication" value="y" id="publication_y"/> <label for="publication_y">Y- Axis</label></div>
			<div class="noAxis"><input type="radio" name="publication" value="na" checked="checked" id="publication_n"/> <label for="publication_n">Exclude</label></div>
	      <ul style="display: none;">
	      	<li class="endElement">
				<div class="itemName">First Auth</div>
				<div class="xAxis"><input type="radio" name="pub_1" value="x" id="pub_1_x"/> <label for="pub_1_x">X- Axis</label></div>
				<div class="yAxis"><input type="radio" name="pub_1" value="y" id="pub_1_y"/> <label for="pub_1_y">Y- Axis</label></div>
				<div class="noAxis"><input type="radio" name="pub_1" value="na" checked="checked" id="pub_1_n"/> <label for="pub_1_n">Exclude</label></div>
			</li>
			<li class="endElement">
				<div class="itemName">Siangle Auth</div>
				<div class="xAxis"><input type="radio" name="pub_2" value="x" id="pub_2_x"/> <label for="pub_2_x">X- Axis</label></div>
				<div class="yAxis"><input type="radio" name="pub_2" value="y" id="pub_2_y"/> <label for="pub_2_y">Y- Axis</label></div>
				<div class="noAxis"><input type="radio" name="pub_2" value="na" checked="checked" id="pub_2_n"/> <label for="pub_2_n">Exclude</label></div>
			</li>
			<li class="endElement">
				<div class="itemName">Middle Auth</div>
				<div class="xAxis"><input type="radio" name="pub_3" value="x" id="pub_3_x"/> <label for="pub_3_x">X- Axis</label></div>
				<div class="yAxis"><input type="radio" name="pub_3" value="y" id="pub_3_y"/> <label for="pub_3_y">Y- Axis</label></div>
				<div class="noAxis"><input type="radio" name="pub_3" value="na" checked="checked" id="pub_3_n"/> <label for="pub_3_n">Exclude</label></div>
			</li>
			<li class="endElement last">
				<div class="itemName">Last Auth</div>
				<div class="xAxis"><input type="radio" name="pub_4" value="x" id="pub_4_x"/> <label for="pub_4_x">X- Axis</label></div>
				<div class="yAxis"><input type="radio" name="pub_4" value="y" id="pub_4_y"/> <label for="pub_4_y">Y- Axis</label></div>
				<div class="noAxis"><input type="radio" name="pub_4" value="na" checked="checked" id="pub_4_n"/> <label for="pub_4_n">Exclude</label></div>
			</li>
	      </ul>
	    </li>
	    <li class="expandable last"><span><strong>Trials</strong></span>
	    	<div class="xAxis"><input type="radio" name="trial" value="x" id="trial_x"/> <label for="trial_x">X- Axis</label></div>
			<div class="yAxis"><input type="radio" name="trial" value="y" id="trial_y"/> <label for="trial_y">Y- Axis</label></div>
			<div class="noAxis"><input type="radio" name="trial" value="na" checked="checked" id="trial_n"/> <label for="trial_n">Exclude</label></div>
	    </li>
	    
	  </ul>
	  <input type="button" value="Apply" onClick="displaySliders();"/>
	  </form>
  </div>
  <div id="weightageCaontainer" class="selecterContainers">
	  <div id="xAxisSlider">
	 	&nbsp;X-Elements
	 	Total : <input type="text" id="total_weight_x" class="weightage"/>
	  </div>
	  <div id="yAxisSlider">
	  	&nbsp;Y-Elements
	  	Total : <input type="text" id="total_weight_y" class="weightage"/>
	  </div>
 </div>
 <input type="button" name="apply" value="Apply" id="apply"  onclick="validateAndSubmit();"/>
  <!--  
  <table>
  	<thead>
  		<tr>
  			<th>Categories</th>
  			<th>X-Axis</th>
  			<th>Y-Axis</th>
  			<th>Exclude</th>
  		</tr>
  	</thead>
  	<tbody>
  		<tr>
  			<td class="expandable"><div class="hitarea expandable-hitarea"></div>Affiliations</td>
  			<td><input type="radio" name="aff" value="x" /></td>
  			<td><input type="radio" name="aff" value="y" /></td>
  			<td><input type="radio" name="aff" value="e" /></td>
  		</tr>
  		<tr>
  			<td class="expandable"><div class="hitarea expandable-hitarea"></div>Events</td>
  			<td><input type="radio" name="events" value="x" /></td>
  			<td><input type="radio" name="events" value="y" /></td>
  			<td><input type="radio" name="events" value="e" /></td>
  		</tr>
  		<tr>
  			<td class="expandable"><div class="hitarea expandable-hitarea"></div>Publications</td>
  			<td><input type="radio" name="pubs" value="x" /></td>
  			<td><input type="radio" name="pubs" value="y" /></td>
  			<td><input type="radio" name="pubs" value="e" /></td>
  		</tr>
  		<tr>
  			<td class="expandable"><div class="hitarea expandable-hitarea"></div>Trials</td>
  			<td><input type="radio" name="trials" value="x" /></td>
  			<td><input type="radio" name="trials" value="y" /></td>
  			<td><input type="radio" name="trials" value="e" /></td>
  		</tr>
  	</tbody>
  </table>
  -->
</div>
<div id="scatOpsWeights" class="scatG">

</div>
<div id="scatGraph" class="scatG">

</div>