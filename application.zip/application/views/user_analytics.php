<?php
/**
 * List the user analytics such as Username, client name, login time, logout time etc
 * 
 * @author Ramesh B
 * @since	
 * @created: 15-01-11
 */
?>

<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/screen.css" />
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$(window).scroll(function(){
	        if  ($(window).scrollTop() == $(document).height() - $(window).height() || $(window).scrollTop() == $(document).height() - $(window).height()){
	        	loadMore();
	        }
		}); 
	});

	var isRequestSent = false;
	function loadMore(){
		if(!isRequestSent){
			isRequestSent = true;
			var data={};
			data['start_from']=$(".analytics-row:last").attr("id");
			if(data['start_from'] != null){
				$('div#lastPostsLoader').show();
				$.ajax({
				 	type: 'POST',
			  	  	data: data,
				  	url: '<?php echo base_url()?>login/list_all_user_analytics',
				  	dataType: 'text',
			      	success: function(returnData) {
						if (returnData != "") {
							$("#userAnalyticsContainer tbody").append(returnData);
						}
						$('div#lastPostsLoader').hide();
						isRequestSent = false;
			  		}	
				});
			}
		}
	}
</script>

<style>
	#userAnalyticsContainer table{
		 margin: auto;
		 width: 800px;
		 border: 1px solid silver;
	}
	#userAnalyticsContainer table tr td,#userAnalyticsContainer table tr th{
	 	text-align: center;	 
	}
	
	#userAnalyticsContainer .leftAlign{
		text-align: left;
	}
	
	#userAnalyticsContainer .loginFailed{
		color: red;
	}
	
</style>
<div id="userAnalyticsContainer">
	<table cellpadding="5">
		<thead>
			<tr>
				<th>Username</th>
				<th>Client Name</th>
				<th>Login Time</th>
				<th>Logout Time</th>
			</tr>
		</thead>
		<tbody>
			<?php $this->load->view('user_analytics_element'); ?>
		</tbody>
	</table>
	<div id="lastPostsLoader" style="text-align: center;">
		<img src="../images/ajax-loader-round.gif" />
	</div>	
</div>