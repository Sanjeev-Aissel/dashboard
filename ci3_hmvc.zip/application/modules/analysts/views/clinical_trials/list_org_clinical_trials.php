<?php
/**
 * Analyst page for organization cilical trials operatons
 *
 * @author: Ramesh B
 * @since Otsuka 1.0.11
 * @created on: 04-04-2013
 * @package application.views.organizations
 */
function listRecordsPerPage($maxRecords=100,$increament=10){
	$rowList="";
 	for($i=10;$i<=$maxRecords;$i+=$increament){
 		$rowList.=$i.",";
 	}
 	$rowList=substr($rowList,0,-1);
 	return $rowList;
}

$isClientView	= false;
$clientId				= $this->session->userdata('client_id');
if($clientId==INTERNAL_CLIENT_ID){
	$enableEdit	= true;
}
		
?>	
<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/custom_overwrite.css" media="screen" />
<script>
	var orgId = <?php echo $arrOrganization['id'];?>;
	$(document).ready(function(){
		// Settings for the Add Clinical Trial Dialog Box
		var clinicalTrialAddOpts = {
				title: "ADD CLINICAL TRIAL",
				modal: true,
				autoOpen: false,
				width: 800,
				dialogClass: "microView",
				position: ['center', 80],
				open: function() {
					//display correct dialog content
				}
		};
		
		$("#clinicalTrailAddContainer").dialog(clinicalTrialAddOpts);
		
		listUnverifiedClinicalTrials();
	
		// Initiate the 'Ternary Navigation
		$("#kolEventsTernaryNav").tabs().addClass("ui-tabs-vertical ui-helper-clearfix" );
	
		// Remove the Surrounding Border
		$("#kolEventsTernaryNav" ).removeClass("ui-widget-content");
	
		// Remove the Round Corner
		$("#kolEventsTernaryNav ul").removeClass("ui-corner-all ui-widget-header");
		
		$("#kolEventsTernaryNav li").removeClass( "ui-corner-top" );
	
		// Add the Custom Class to control View
		$("#kolEventsTernaryNav > div").addClass( "span-20 last" );
	
		$(".ternaryNav li a").click(function(){
			loadSelectedTab();
		});
	
		
		/*
		* To Move Selcted records into Verifeid publications list
		* @author Vinayak Malladad
		* @since 1.5.2
		* @created on 21/3/2011
		*/
		$("#verify").click(function(){
			$("#delmodJQBlistClinicalTrialResultSet").remove();
			var sr = jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").getGridParam('selarrrow');	
			action = '<?php echo base_url();?>clinical_trials_org/verified_clinical_trials';
			var data = {};
			data['trial_ids' ] = sr;
			data['kol_id' ] = orgId;
			jQuery.jgrid.del = {
				    caption: "verify",
				    msg: "Move selected record(s) into Verified List?",
				    bSubmit: "Verify",
				    bCancel: "Cancel",
				    processData: "Processing...",
				    top:400,
				    left:500,
				    url:action,
				    delData:data,
				    reloadAfterSubmit:true,
				    afterSubmit:function(response, postdata){				    		
			    		var success=true;
			    		var message="sucess";
			    		var new_id=2;
			    		jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").trigger("reloadGrid");
			    		//jQuery("#JQBlistClinicalTrialsResultSet").setGridParam({page: 1});
			    		return [success,message,new_id];				    		
			    	}
				};
			jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").delGridRow( sr, {} );
			//$(".dData").click();
			//$(".ui-icon-closethick").click();			
		});
	
			/*
			* To Move Selcted records into Deleted ClinicalTrialss list
			* @author Vinayak Malladad
			* @since 1.5.2
			* @created on 21/3/2011
			*/
			$("#deleteUnVerifiedRecords").click(function(){
				//Get all the selected id's from jqGrid manually
				/*
				var pubValues = new Array();
				$("input.cbox:checked").each(function(){
					var idName=this.id;
					var mySplitResult = idName.split("_");
					
					pubValues.push(mySplitResult[2]);
				});
				*/
				$("#delmodJQBlistClinicalTrialsResultSet").remove();
				var delUrl='<?php echo base_url();?>clinical_trials_org/deleted_clinical_trials';
				var sr = jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").getGridParam('selarrrow');
				var data={};
				data['trial_ids']=sr;
				data['kol_id' ] = orgId;
				
				jQuery.jgrid.del = {
					    caption: "Delete",
					    msg: "Move selected record(s) into Deleted List?",
					    bSubmit: "Delete",
					    bCancel: "Cancel",
					    processData: "Processing...",
					    url:delUrl,
					    delData:data,
					    reloadAfterSubmit:true,
					    afterSubmit:function(response, postdata){				    		
				    		var success=true;
				    		var message="sucess";
				    		var new_id=2;
				    		jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").trigger("reloadGrid");
				    		//jQuery("#JQBlistClinicalTrialsResultSet").setGridParam({page: 1});
				    		return [success,message,new_id];				    		
				    	}
					};				
				jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").delGridRow( sr, {} );
			});
	
			
			
			/*
			* To Move Selcted records into Unvarifeid ClinicalTrialss list
			* @author Vinayak Malladad
			* @since 1.5.2
			* @created on 21/3/2011
			*/
			$("#unVerify").click(function(){
				$("#delmodJQBlistClinicalTrialsResultSet").remove();
				var sr = jQuery("#JQBlistClinicalTrialsResultSet").getGridParam('selarrrow');	
				action = '<?php echo base_url();?>clinical_trials_org/un_verified_clinical_trials';
				var data = {};
				data['trial_ids' ] = sr;
				data['kol_id' ] = orgId;
				
				jQuery.jgrid.del = {
					    caption: "Unverify ",
					    msg: "Move selected record(s) into Unverified List?",
					    bSubmit: "Unverify",
					    bCancel: "Cancel",
					    processData: "Processing...",
					    url:action,
					    delData:data,
					    reloadAfterSubmit:true,
					    afterSubmit:function(response, postdata){				    		
				    		var success=true;
				    		var message="sucess";
				    		var new_id=2;
				    		jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").trigger("reloadGrid");
				    		//jQuery("#JQBlistClinicalTrialsResultSet").setGridParam({page: 1});
				    		return [success,message,new_id];				    		
				    	}
					};
				
				jQuery("#JQBlistClinicalTrialsResultSet").delGridRow( sr, {} );
			});
	
			/*
			* To Move Selcted records into Deleted ClinicalTrialss list
			* @author Vinayak Malladad
			* @since 1.5.2
			* @created on 21/3/2011
			*/
			$("#deleteVerifiedRecords").click(function(){
				$("#delmodJQBlistClinicalTrialsResultSet").remove();
				var delUrl='<?php echo base_url();?>clinical_trials_org/deleted_clinical_trials';
				var sr = jQuery("#JQBlistClinicalTrialsResultSet").getGridParam('selarrrow');	
				var data={};
				data['trial_ids']=sr;
				data['kol_id' ] = orgId;
				jQuery.jgrid.del = {
					    caption: "Delete",
					    msg: "Move selected record(s) into Deleted List?",
					    bSubmit: "Delete",
					    bCancel: "Cancel",
					    processData: "Processing...",
					    url:delUrl,
					    delData:data,
					    reloadAfterSubmit:true,
					    afterSubmit:function(response, postdata){				    		
				    		var success=true;
				    		var message="sucess";
				    		var new_id=2;
				    		jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").trigger("reloadGrid");
				    		//jQuery("#JQBlistClinicalTrialsResultSet").setGridParam({page: 1});
				    		return [success,message,new_id];				    		
				    	}
					};
				
				jQuery("#JQBlistClinicalTrialsResultSet").delGridRow( sr, {} );
			});
	
			/*
			* To Move  deleted records into Verified ClinicalTrialss list
			* @author Vinayak Malladad
			* @since 1.5.2
			* @created on 21/3/2011
			*/
			$("#deleteToVerify").click(function(){
				$("#delmodJQBlistDeletedClinicalTrialsResultSet").remove();
				var delUrl='<?php echo base_url();?>clinical_trials_org/verified_clinical_trials';
				var sr = jQuery("#JQBlistDeletedClinicalTrialsResultSet").getGridParam('selarrrow');	
				var data={};
				data['trial_ids']=sr;
				data['kol_id' ] = orgId;
				jQuery.jgrid.del = {
					    caption: "Verify",
					    msg: "Move selected record(s) into Verified List?",
					    bSubmit: "Verify",
					    bCancel: "Cancel",
					    processData: "Processing...",
					    url:delUrl,
					    delData:data,
					    reloadAfterSubmit:true,
					    afterSubmit:function(response, postdata){				    		
				    		var success=true;
				    		var message="sucess";
				    		var new_id=2;
				    		jQuery("#JQBlistClinicalTrialsResultSet").trigger("reloadGrid");
				    		//jQuery("#JQBlistClinicalTrialsResultSet").setGridParam({page: 1});
				    		return [success,message,new_id];				    		
				    	}
					};
	
				jQuery("#JQBlistDeletedClinicalTrialsResultSet").delGridRow( sr, {} );
			});
	
			/*
			* To Move  deleted records into Verify ClinicalTrialss list
			* @author Vinayak Malladad
			* @since 1.5.2
			* @created on 21/3/2011
			*/
			$("#deleteToUnVerify").click(function(){
				$("#delmodJQBlistDeletedClinicalTrialsResultSet").remove();
				var delUrl='<?php echo base_url();?>clinical_trials_org/un_verified_clinical_trials';
				var sr = jQuery("#JQBlistDeletedClinicalTrialsResultSet").getGridParam('selarrrow');	
				var data={};
				data['trial_ids']=sr;
				data['kol_id' ] = orgId;
				jQuery.jgrid.del = {
					    caption: "Unverify",
					    msg: "Move selected record(s) into Unverified List?",
					    bSubmit: "Unverify",
					    bCancel: "Cancel",
					    processData: "Processing...",
					    url:delUrl,
					    delData:data,
					    reloadAfterSubmit:true,
					    afterSubmit:function(response, postdata){				    		
				    		var success=true;
				    		var message="sucess";
				    		var new_id=2;
				    		jQuery("#JQBlistClinicalTrialsResultSet").trigger("reloadGrid");
				    		//jQuery("#JQBlistClinicalTrialsResultSet").setGridParam({page: 1});
				    		return [success,message,new_id];				    		
				    	}
					};
				
				jQuery("#JQBlistDeletedClinicalTrialsResultSet").delGridRow( sr, {} );
			});
			
						
	});

	function listVerifiedClinicalTrials(){
		jQuery("#JQBlistClinicalTrialsResultSet").jqGrid({
		   	url:'<?php echo base_url();?>clinical_trials_org/list_clinical_trials_details/<?php echo $arrOrganization['id']?>/verified',
			datatype: "json",
			colNames:['Id','','CT ID','Trial Name','Status' ,'Sponsors','Condition','Intervention','Phase','Investigators','','Action'],
		   	colModel:[
				{name:'id',index:'id', hidden:true},
				{name:'is_manual',index:'is_manual', hidden:true},
		   		{name:'ct_id',index:'ct_id', width:105,editable:true},
		   		{name:'trial_name',index:'trial_name',width:300,editable:true},
		   		{name:'status',index:'status',width:60,editable:true},
		   		{name:'sponsors',index:'sponsors',width:100,editable:true},
		   		{name:'condition',index:'condition',width:100,editable:true},
		   		{name:'interventions',index:'interventions',width:80,editable:true},
		   		{name:'phase',index:'phase',width:50,editable:true},
		   		{name:'investigators',index:'investigators',width:80,editable:true},
		   		{name:'trial_id',index:'trial_id',hidden:true},
		   		{name:'act',resizable:true,width:100 <?php if($isClientView) echo ' ,hidden:true';?>}					   		
		   	],
		   	rowNum:10,
		   	rowList:paginationValues,
		   	rownumbers: true,
		   	autowidth: true, 
		   	loadonce:true,
		   	multiselect: true,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",		   
		   	pager: '#listClinicalTrialsPage',
		   	mtype: "POST",
		   	sortname: 'name',
		    viewrecords: true,
		    sortorder: "desc",
		    gridComplete: function(){						     
			    var ids = jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('getDataIDs'); 
			    	for(var i=0;i < ids.length;i++){ 
				    	var cl = ids[i];	
				    	var ret = jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('getRowData', cl);
				    	val = ret.is_manual;
				    	var ctId = ret.trial_id;
				    	if(val == 0){
				    		be = "<label onclick=\"deleteClinicalTrial('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";
				    		<?php
								if($enableEdit){?>
									be += " | ";
						    		be += "<label onclick=\"editClinicalTrail('"+ctId+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png' class='editIcon'></label>";
							<?php	}	?>
				    	}else{
				    		be = "<label onclick=\"deleteClinicalTrial('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";	
				    		be += " | ";
				    		be += "<label onclick=\"editClinicalTrail('"+ctId+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png' class='editIcon'></label>";	
				    	}		    	
				    	jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('setRowData',ids[i],{act:be}); 
				    	} 
			    	jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('navGrid','hideCol',"id"); 
			    	}, 
			loadComplete: function() {
			    	    $("option[value=100000000]").text('All');
			    	},
			    							    	
		    jsonReader: { repeatitems : false, id: "0" }, 
		    editurl:"#",		   
		    caption:""		    
		});
		var delUrl='<?php echo base_url();?>clinical_trials_org/delete_clinical_trials';
		jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('navGrid','#listClinicalTrialsPage',{edit:false,add:false,search:false,refresh:false}, {},{}, {reloadAfterSubmit:false, url:delUrl, onclickSubmit : function(eparams) {
		    var retarr = {};					  
		    var sr = jQuery("#JQBlistClinicalTrialsResultSet").getGridParam('selarrrow');				  
		        retarr = {slr:sr};					   
		   		 return retarr;
			}
		}, {} ); 	
		//Toolbar search bar below the Table Headers
		jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
		//Toolbar search bar above the Table Headers
		//jQuery("#t_JQBlistClinicalTrialsResultSet").height(25).jqGrid('filterGrid',"JQBlistClinicalTrialsResultSet",{gridModel:true,gridToolbar:true});
		
		//Toggle Toolbar Search 
		jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('navButtonAdd',"#listlistClinicalTrialsPage",{
			caption:"Search",title:"Toggle Search",
			onClickButton:function(){ 			
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}							
			} 
		}); 

		jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000});
	}

	function listUnverifiedClinicalTrials(){
		/*
		*jqgrid for Clinical Trials table
		*/
		jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").jqGrid({
		   	url:'<?php echo base_url();?>clinical_trials_org/list_clinical_trials_details/<?php echo $arrOrganization['id']?>/unverified',
			datatype: "json",
			colNames:['Id','','CT ID','Trial Name','Status' ,'Sponsors','Condition','Intervention','Phase','Investigators','Action'],
		   	colModel:[
				{name:'id',index:'id', hidden:true},
				{name:'is_manual',index:'is_manual', hidden:true},
		   		{name:'ct_id',index:'ct_id', width:105,editable:true},
		   		{name:'trial_name',index:'trial_name',width:300,editable:true},
		   		{name:'status',index:'status',width:60,editable:true},
		   		{name:'sponsors',index:'sponsors',width:100,editable:true},
		   		{name:'condition',index:'condition',width:100,editable:true},
		   		{name:'interventions',index:'interventions',width:80,editable:true},
		   		{name:'phase',index:'phase',width:50,editable:true},
		   		{name:'investigators',index:'investigators',width:80,editable:true},
		   		{name:'act',resizable:true,width:100 <?php if($isClientView) echo ' ,hidden:true';?>}					   		
		   	],
		   	rowNum:10,
		   	rowList:paginationValues,
		   	rownumbers: true,
		   	autowidth: true, 
		   	loadonce:true,
		   	multiselect: true,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",		   
		   	pager: '#listUnverifiedClinicalTrialsPage',
		   	mtype: "POST",
		   	sortname: 'name',
		    viewrecords: true,
		    sortorder: "desc",
		    gridComplete: function(){						     
			    var ids = jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").jqGrid('getDataIDs'); 
			    	for(var i=0;i < ids.length;i++){ 
				    	var cl = ids[i];	
				    	var ret = jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").jqGrid('getRowData', cl);
				    	val = ret.is_manual;
				    	if(val == 0){
				    		be = "<label onclick=\"deleteClinicalTrial('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";
				    		<?php
								if($enableEdit){?>
									be += " | ";
						    		be += "<label onclick=\"editClinicalTrail('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png' class='editIcon'></label>";
							<?php	}	?>
				    	}else{
				    		be = "<label onclick=\"deleteClinicalTrial('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";	
				    		be += " | ";
				    		be += "<label onclick=\"editClinicalTrail('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png' class='editIcon'></label>";	
				    	}		    	
				    	jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").jqGrid('setRowData',ids[i],{act:be}); 
				    	} 
			    	jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").jqGrid('navGrid','hideCol',"id"); 
			    	}, 
			loadComplete: function() {
			    	    $("option[value=100000000]").text('All');
			    	},
			    							    	
		    jsonReader: { repeatitems : false, id: "0" }, 
		    editurl:"#",		   
		    caption:""		    
		});
		var delUrl='<?php echo base_url();?>clinical_trials_org/delete_clinical_trials';
		jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").jqGrid('navGrid','#listUnverifiedClinicalTrialsPage',{edit:false,add:false,search:false,refresh:false}, {},{}, {reloadAfterSubmit:false, url:delUrl, onclickSubmit : function(eparams) {
		    var retarr = {};					  
		    var sr = jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").getGridParam('selarrrow');				  
		        retarr = {slr:sr};					   
		   		 return retarr;
			}
		}, {} ); 	
		//Toolbar search bar below the Table Headers
		jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
		//Toolbar search bar above the Table Headers
		//jQuery("#t_JQBlistUnverifiedClinicalTrialsResultSet").height(25).jqGrid('filterGrid',"JQBlistUnverifiedClinicalTrialsResultSet",{gridModel:true,gridToolbar:true});
		
		//Toggle Toolbar Search 
		jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").jqGrid('navButtonAdd',"#listlistClinicalTrialsPage",{
			caption:"Search",title:"Toggle Search",
			onClickButton:function(){ 			
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}							
			} 
		}); 

		jQuery("#JQBlistUnverifiedClinicalTrialsResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000});
	}

	function listDeletedClinicalTrials(){
		/*
		*jqgrid for Clinical Trials table
		*/
		jQuery("#JQBlistDeletedClinicalTrialsResultSet").jqGrid({
		   	url:'<?php echo base_url();?>clinical_trials_org/list_clinical_trials_details/<?php echo $arrOrganization['id']?>/deleted',
			datatype: "json",
			colNames:['Id','','CT ID','Trial Name','Status' ,'Sponsors','Condition','Intervention','Phase','Investigators','Action'],
		   	colModel:[
				{name:'id',index:'id', hidden:true},
				{name:'is_manual',index:'is_manual', hidden:true},
		   		{name:'ct_id',index:'ct_id', width:105,editable:true},
		   		{name:'trial_name',index:'trial_name',width:300,editable:true},
		   		{name:'status',index:'status',width:60,editable:true},
		   		{name:'sponsors',index:'sponsors',width:100,editable:true},
		   		{name:'condition',index:'condition',width:100,editable:true},
		   		{name:'interventions',index:'interventions',width:80,editable:true},
		   		{name:'phase',index:'phase',width:50,editable:true},
		   		{name:'investigators',index:'investigators',width:80,editable:true},
		   		{name:'act',resizable:true,width:100 <?php if($isClientView) echo ' ,hidden:true';?>}					   		
		   	],
		   	rowNum:10,
		   	rowList:paginationValues,
		   	rownumbers: true,
		   	autowidth: true, 
		   	loadonce:true,
		   	multiselect: true,
		   	ignoreCase:true,
		   	hiddengrid:false,
		   	height: "auto",		   
		   	pager: '#listDeletedClinicalTrialsPage',
		   	mtype: "POST",
		   	sortname: 'name',
		    viewrecords: true,
		    sortorder: "desc",
		    gridComplete: function(){						     
			    var ids = jQuery("#JQBlistDeletedClinicalTrialsResultSet").jqGrid('getDataIDs'); 
			    	for(var i=0;i < ids.length;i++){ 
				    	var cl = ids[i];	
				    	var ret = jQuery("#JQBlistDeletedClinicalTrialsResultSet").jqGrid('getRowData', cl);
				    	val = ret.is_manual;
				    	if(val == 0){
				    		be = "<label onclick=\"deleteClinicalTrial('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";
				    		<?php
								if($enableEdit){?>
									be += " | ";
						    		be += "<label onclick=\"editClinicalTrail('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png' class='editIcon'></label>";
							<?php	}	?>
				    	}else{
				    		be = "<label onclick=\"deleteClinicalTrial('"+cl+"');\" ><img title='Delete' src='<?php echo base_url()?>images/delete.png' class='deleteIcon'></label>";	
				    		be += " | ";
				    		be += "<label onclick=\"editClinicalTrail('"+cl+"');\" ><img title='Edit' src='<?php echo base_url()?>images/edit.png' class='editIcon'></label>";	
				    	}		    	
				    	jQuery("#JQBlistDeletedClinicalTrialsResultSet").jqGrid('setRowData',ids[i],{act:be}); 
				    	} 
			    	jQuery("#JQBlistDeletedClinicalTrialsResultSet").jqGrid('navGrid','hideCol',"id"); 
			    	}, 
			loadComplete: function() {
			    	    $("option[value=100000000]").text('All');
			    	},
			    							    	
		    jsonReader: { repeatitems : false, id: "0" }, 
		    editurl:"#",		   
		    caption:""		    
		});
		var delUrl='<?php echo base_url();?>clinical_trials_org/delete_clinical_trials';
		jQuery("#JQBlistDeletedClinicalTrialsResultSet").jqGrid('navGrid','#listDeletedClinicalTrialsPage',{edit:false,add:false,search:false,refresh:false}, {},{}, {reloadAfterSubmit:false, url:delUrl, onclickSubmit : function(eparams) {
		    var retarr = {};					  
		    var sr = jQuery("#JQBlistDeletedClinicalTrialsResultSet").getGridParam('selarrrow');				  
		        retarr = {slr:sr};					   
		   		 return retarr;
			}
		}, {} ); 	
		//Toolbar search bar below the Table Headers
		jQuery("#JQBlistDeletedClinicalTrialsResultSet").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
		//Toolbar search bar above the Table Headers
		//jQuery("#t_JQBlistDeletedClinicalTrialsResultSet").height(25).jqGrid('filterGrid',"JQBlistDeletedClinicalTrialsResultSet",{gridModel:true,gridToolbar:true});
		
		//Toggle Toolbar Search 
		jQuery("#JQBlistDeletedClinicalTrialsResultSet").jqGrid('navButtonAdd',"#listlistClinicalTrialsPage",{
			caption:"Search",title:"Toggle Search",
			onClickButton:function(){ 			
				if(jQuery(".ui-search-toolbar").css("display")=="none") {
					jQuery(".ui-search-toolbar").css("display","");
				} else {
					jQuery(".ui-search-toolbar").css("display","none");
				}							
			} 
		}); 

		jQuery("#JQBlistDeletedClinicalTrialsResultSet").jqGrid('gridResize',{'minWidth':550, 'maxWidth':2000});
	}

	/**
	* Delete the 'Education Details'
	*/
	function deleteClinicalTrial(id){								
		var formAction = '<?php echo base_url();?>clinical_trials_org/delete_clinical_trial/'+id+'/<?php echo $arrOrganization['id']?>';			
		jQuery("#JQBlistClinicalTrialsResultSet").jqGrid('delGridRow',id,{reloadAfterSubmit:false,url:formAction});
			  
	}	
	function addClinicalTrail(){
		$("#modal-box").addClass("modal-lg");
		$(".modal-body").html("<div class='ctmicroViewLoading'>Loading...</div>");
		$(".modal-title").html("Add New Clinical Trial");
		$(".modal-body").load('<?php echo base_url()?>analysts/clinical_trials/add_clinical_trial/<?php echo $arrOrganization['id']?>');
		return false;		
	}
	
	function editClinicalTrail(id){
		$("#clinicalTrailAddProfileContent").val("");
		$(".ctprofileContent").val("");
		$(".ctprofileContent").html("<div class='ctmicroViewLoading'>Loading...</div>");
		$("#clinicalTrailAddContainer").dialog("open");
		$("#clinicalTrailAddProfileContent").load('<?php echo base_url().'clinical_trials_org/edit_clinical_trial_manual/'?>'+id+'/'+orgId);
		return false;	
	}
	function processCTIds(){
		var ids	= $.trim($('#crawlCtIds').val());
		if(ids!=""){
			var formAction = '<?php echo base_url()?>clinical_trials_org/processCTIDs/<?php echo $arrOrganization['id']?>';
			$.ajax({
				url:formAction,
				type:'post',
				dataType:'json',
				data:'ctids='+ids,
				success:function(returnData){
					if(returnData.status=='success'){
						$("#clinicalTrailAddContainer").dialog("close");
					}else{
						$('.msgBox').text(returnData.msg);
						$('.msgBox').fadeOut(2500);
					}
				}
			
				});
		}else{
			jAlert('Enter at least one Clinical trial ID');
		}
	}
	function crawlCTIDs(){	
		$("#modal-box").removeClass("modal-lg");
		$(".modal-body").html("<div class='ctmicroViewLoading'>Loading...</div>");
		$(".modal-title").html("Add Clinical Trial IDs for Crawling");
		$(".modal-body").html("<div><div class='form-group'><label>Enter CT ID(s):</label><textarea cols='50' rows='3' id='crawlCtIds' class='form-control'></textarea><span class='pull-right'>comma(,) separated</span></div> <button onclick='processCTIds()' class='btn btn-primary'><span class='glyphicon glyphicon-save'></span> Save and Crawl</button></div>");
		return false;	
	}
	
	function loadSelectedTab(selected){
			$("#JQBlistClinicalTrialsResultSet").setGridParam({loadonce:false});
			var select= $(selected).attr('aria-controls');
			//var select    = $("#kolEventsTernaryNav").tabs("option","selected");
			switch(select){
				case 'unverified'	:	$("#genericGridContainer").html("");
										$("#genericGridContainer").html('<table id="JQBlistUnverifiedClinicalTrialsResultSet"></table><div id="listUnverifiedClinicalTrialsPage"></div>');
										listUnverifiedClinicalTrials();
							break;
							
				case 'verified'	: 	$("#genericGridContainer").html("");
									$("#genericGridContainer").html('<table id="JQBlistClinicalTrialsResultSet"></table><div id="listClinicalTrialsPage"></div>');
									listVerifiedClinicalTrials();
							break;
				
				case 'deleted'	:	$("#genericGridContainer").html("");
									$("#genericGridContainer").html('<table id="JQBlistDeletedClinicalTrialsResultSet"></table><div id="listDeletedClinicalTrialsPage"></div>');
									listDeletedClinicalTrials();
							break;
				default :	listUnverifiedClinicalTrials();
	
			}
			$("#JQBlistClinicalTrialsResultSet").setGridParam({loadonce:true});
	}	

	function loadUnprocessedInvestigatorsPage(){
		$('#unProceInvestigators').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(<?php echo base_url()?>images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		$("#unProceInvestigators").load("<?php echo base_url()?>clinical_trials_org/get_unprocessed_investigators_page/"+orgId,{},
				function(){	$('#unProceInvestigators').unblock(); }
		);
	}

	function loadProcessedInvestigatorsPage(){
		$('#proceInvestigators').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(<?php echo base_url()?>images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		$("#proceInvestigators").load("<?php echo base_url()?>clinical_trials_org/get_processed_investigators_page/"+orgId,{},
				function(){	$('#proceInvestigators').unblock(); }
		);
	}


	//get selected investigators and AliasId and send ajax request to associate
	function associateInvestigators(){
		var investigatorsIds=$("#unproceInvestigatorsList").val();
		var aliasInvestigatorId=$("#aliasInvestigatorsList").val();
		var data={};
		data['investigators_ids']=investigatorsIds;
		data['alias_id']=aliasInvestigatorId;
		$('#unProceInvestigators').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(<?php echo base_url()?>images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
		$.ajax({
			url:'<?php echo base_url();?>clinical_trials_org/associate_investigators/'+orgId,
			data:data,
			type:'post',
			datType:'json',
			success:function(returnData){
				//loadUnprocessedInvestigatorPage();
				//remove the processed co authors from the both list
				$("#unproceInvestigatorsList option:selected").each(function(){
					$(this).remove();
				 }); 
				for(var i=0; i<investigatorsIds.length; i++) {
					var value = investigatorsIds[i];
					$("#aliasInvestigators option").each(function(){
						if(this.value==value){
							if(this.value != aliasInvestigatorId)
								$(this).remove();
						}
					}); 
				}
				$('#unProceInvestigators').unblock();
			}
		});
	}

	//disassociate the co author from associated co author
	function disassociateInvestigatoror(investigatorId){
		var ele=document.getElementById("proceInvestigatorsTable");
		var data={};
		data['investigator_id']=investigatorId;
		jConfirm("Are you sure you want to disassociate?","Please confirm",function(r){
				if(r){
					$('#proceInvestigators').block({ message: ' ',overlayCSS: { backgroundColor: '#F7F7F7',cursor:'default'},css:{ backgroundImage:'url(<?php echo base_url()?>images/ajax-loader-round.gif)',backgroundPosition:'center',backgroundRepeat:'no-repeat',backgroundColor:'transparent',border:'0px',height:'30%',cursor:'default'}});
					$.ajax({
						url:'<?php echo base_url();?>clinical_trials_org/disassociate_investigator/'+orgId,
						data:data,
						type:'post',
						datType:'json',
						success:function(returnData){
							if(returnData==1){
								$("#investigator"+investigatorId).remove();
							}
							$('#proceInvestigators').unblock();
						}
					});
					}else{
							return false;
						}
			});
	}
</script>
<?php $this->load->view('kols/secondary_menu');?>	
<div class="main-content">
	<div class="row">
		<div id="kolTernaryNav" class="col-md-12">
        <!-- Start Nav tabs -->
               <ul class="nav nav-tabs" role="tablist">
                  <li role="Details" class="active"><a href="#unverified" aria-controls="unverified" role="tab" data-toggle="tab">Unverified</a></li>
                  <li role="Details"><a href="#verified" aria-controls="verified" role="tab" data-toggle="tab">Verified</a></li>
                  <li role="Details"><a href="#deleted" aria-controls="deleted" role="tab" data-toggle="tab">Deleted</a></li>                  
               </ul>
		<!-- End Nav tabs -->
               <div class="tab-content">
               <div>
               	<h5 style="font-weight:bold;color:#656565;">Profile of : <?php echo $arrKol['first_name'].' '.$arrKol['middle_name'].' '.$arrKol['last_name']; ?></h5>
               </div>
               <div id="clinicalTrailAddLink"  class="pull-right">
				<label onclick="crawlCTIDs();" style="float:left;" data-toggle="modal" data-target="#analystModelBox"><img height="26" src="http://localhost/demo/images/bullet_add.png" border="0">Add CTIDs</label>
				<label onclick="addClinicalTrail();" style="padding-left:5px;"  data-toggle="modal" data-target="#analystModelBox"><img height="26" src="http://localhost/demo/images/bullet_add.png" border="0">Add New Clinical Trial</label>
				</div>
        <!-- Start Tab panels -->
                  <div role="tabpanel" class="tab-pane active" id="unverified">				  		
                  	<button id="verify" class="btn btn-default"><span class='icon green glyphicon glyphicon-eye-open'></span> Verify</button> <button id="deleteUnVerifiedRecords" class="btn btn-default"><span class='icon red glyphicon glyphicon-trash'></span> Delete</button>
                  </div>
                  <div role="tabpanel" class="tab-pane" id="verified">
                  	<button id="unVerify" class="btn btn-default"><span class='icon red glyphicon glyphicon-eye-close'></span> Unverify</button>  <button id="deleteVerifiedRecords" class="btn btn-default"><span class='icon red glyphicon glyphicon-trash'></span> Delete</button>	
                  </div>
                  <div role="tabpanel" class="tab-pane" id="deleted">
                  <button id="deleteToVerify" class="btn btn-default"><span class='icon green glyphicon glyphicon-eye-open'></span>  Verify</button>  <button id="deleteToUnVerify" class="btn btn-default"><span class='icon red glyphicon glyphicon-eye-close'></span>  Unverify</button>
                  </div>
        <!-- End Tab panels --> 
        <!-- Generic Grid Panel to load all four respective grid content --> 
			<div class="col-md-12 gridData">
                  <div class="gridWrapper" id="genericGridContainer">
					<table id="JQBlistUnverifiedClinicalTrialsResultSet"></table>
						<div id="listUnverifiedClinicalTrialsPage"></div>
				  </div>
            </div>
		<!-- End of Grid Panel -->   
               </div>     
        </div>
	</div>
</div>	
</div>	