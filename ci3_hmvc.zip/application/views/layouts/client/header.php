<?php 
	$data	= array();
	$current_tab= ltrim($_SERVER['PATH_INFO'], '/');
	$data['current_tab'] = $current_tab;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Hmvc Application</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script>
  var js_files_loaded = false;
  </script>
  <script src="<?php echo base_url().ASSETS;?>bootstrap/js/popper.min.js"></script>
	  <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
	  <!-- script src="<?php echo base_url().ASSETS;?>bootstrap/js/jquery-3.2.1.slim.min.js"></script> -->
  <link rel="stylesheet" href="<?php echo base_url().ASSETS;?>bootstrap/css/bootstrap.min.css">
  <script src="<?php echo base_url().ASSETS;?>bootstrap/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/jquery.autocomplete.js"></script>
</head>
<style>
#footerWrapper{
	border-top:1px solid;
}
.row_padding{
padding:10px 0px;
}
#primaryNavigationWrapper > div{
	padding:0px;
}
#primaryNavigationWrapper > div .navbar{
	margin-bottom:0px;
	border-radius:0px; 
}
#pageContentWrapper, #secondaryMenuWrapper, #rightSideBarWrapper{
	min-height: 500px;
}
.navbar-default {
  background-color: #f8f8f8;
  border-color: #e7e7e7;
    border-left: none;
    border-right: none;
}
</style>
<script>
var chartColors=<?php echo CHART_COLOR_CODES ?>;
var isiPad			= false;
var base_url		= "<?php echo base_url()?>";
var profileRequestConfirmMessage = 'Do you want to submit this request for a Full Profile to be built for this Contact?';
var orgRequestConfirmMessage = 'Do you want to submit this request for a Profile to be built for this Organization?';
function data_type_indicator(dataTypeIndicator){	
	$UserAdded=0;		
	if(dataTypeIndicator == '' || dataTypeIndicator == 'Legacy'){
		return "<div class='dataTypeIndicator tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Legacy Data' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'>L</a></div>";
	}else if(dataTypeIndicator == 'User Added'){
		//return "<div class='dataTypeIndicator tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Added by: "+createdByName+"' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'>U</a></div>";
		return '';
	}else if(dataTypeIndicator == 'Aissel Analyst'){
		return "<div class='dataTypeIndicator tooltip-demo tooltop-left' onclick=\"showUserName(this); return false;\"><a href='#' title='Added by: Aissel Analyst' class='tooltipLink' rel='tooltip' data-placement='left' data-toggle='tooltip'>A</a></div>";
	}	
}

</script>
<body>
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-3">
				 <img src="<?php echo base_url().APPLICATION_IMAGES;?>logo/kolm_logo_beta.png" class="rounded float-left" alt="LOGO">
			</div>
			<div class="col-sm-5 col-sm-offset-1" style="margin-top: 20px;">
			 <form action="/action_page.php" class="form-inline">
			  <span class="glyphicon glyphicon-user"></span>
			    <div class="input-group">
			      <input type="text" class="form-control" placeholder="Search Contacts" name="search">
			      <div class="input-group-btn">
			        <button class="btn btn-default" type="submit" title="Advance search">
			        <i class="glyphicon glyphicon-search"></i></button>
			      </div>
			    </div>
			  </form>
			 </div>
			<div class="col-sm-3" style="margin-top: 20px;">
			<?php $this->load->view(CLIENT_LAYOUT.'settings',array('is_analyst'=>false));?>
			</div>
		</div>
		<div class="row" id="primaryNavigationWrapper">
			<div class="col-lg-12">
				<?php 
					  echo $this->load->view(CUSTOM_APP_CACHE.strtolower($this->session->userdata('client_name')).'/'.'navigations/primary_navigation',$data);
				?>
			</div>
		</div>
	<?php 
		$json = file_get_contents(APPPATH.'views/permission/'.$this->session->userdata('role_id').'.php');
		$GLOBALS['permissions'] =json_decode($json,true);
// 		print_r($GLOBALS['permissions']);
		?>
		<?php 
		echo $this->load->view($contentPage, $contentData);?>
	<div class="row" id="footerWrapper">
			<div class="col-sm-12">
			<footer>
				<div style="float: right;">
						<a href="<?php echo base_url()?>client_users/show_terms_page/terms" style="text-decoration: none;" class="privacy" target="new">Terms of Service</a> |  Copyright &copy;  <a style="text-decoration: none;" href="http://www.aissel.com" target="new">Aissel</a> Technologies | Powered by <a style="text-decoration: none;" href="http://www.aissel.com" target="new">Aissel</a>
				</div>
			</footer>			
			</div>
		</div>
	</div>
	<?php
		// 	Load all JS files from the queue		 
		foreach($this->config->item('js_files_to_load') as $key => $js_files){
			echo '<script type="text/javascript" src="'.base_url().'/assets/'.$js_files.'.js"></script>';
		}
	?>