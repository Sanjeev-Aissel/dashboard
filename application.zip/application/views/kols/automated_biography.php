<?php
$segment= $this->uri->segment(1);

$queued_js_scripts =array('i18n/grid.locale-en',
							'jquery.jqGrid.min'
							);
	// add the JS files into queue i.e Append to the existing queue
$this->config->set_item('js_files_to_load',array_merge($this->config->item('js_files_to_load'),$queued_js_scripts));
//pr($biographyTextDetails);
?>
<style>
 ul.autoBio{
 	padding-left: 12px;
 	margin-bottom: 10px;
 }
 
 ul.autoBio li{
 	/*list-style: none;*/
 	margin: 3px 0;
 	color: #333333;
    font-family: "Droid Sans","Segoe UI",tahoma,arial,"Trebuchet Ms" !important;
    font-size: 12px;
 }
 
 .topLinks{
 	text-decoration: underline !important;
 	cursor: pointer;
 }
 
 .topTopics{
 	margin-bottom: 10px;
 }
 
 .topTopics div label{
 	color: #333333;
    font-family: "Droid Sans","Segoe UI",tahoma,arial,"Trebuchet Ms" !important;
    font-size: 12px;
 }
 .topTopics div span{
 	color: #333333;
    font-family: "Droid Sans","Segoe UI",tahoma,arial,"Trebuchet Ms" !important;
    font-size: 12px;
 }
 #popupMicroInfo h1{
 	color: #fff;
 	font-size: 15px;	
 }
</style>
<?php if($segment=='m'){?>
<style>
	.topPubsTopic{margin-top: 10px !important;}
</style>
<?php }?>
<script>
    var eventName='';
    var segment='';
    $(document).ready(function(){
		// Settings for the Dialog Box
		var summaryMicroviewDialogOpts = {
				title: "",
				modal: true,
				autoOpen: false,
				width: 600,
				dialogClass: "microView",
				position: ['center', modalBoxTopPosition],
				open: function() {
					//display correct dialog content
				}
		};
		//Initialize the Dialog boxes
		$("#event").dialog(summaryMicroviewDialogOpts);
    });
var topicType = "";
var topicName = "";
function listKOLEvents(name,type){
	topicType = type;
	topicName = name;
	eventName=name;
    segment='<?php echo $segment ?>';
    var url='<?php echo base_url()?>kols/view_summary_events/<?php echo $kol_id ?>/';
    if(segment!='i'){
		$("#event").html("<div class='microViewLoading'>Loading...</div>");
		$("#event").dialog("open");
		$("#event").load(url);
	}
	if(segment=='i'){
		$("#title").remove();
		$("#back").remove()
		$("#modalBoxMyList").modal("show");
		$('#modalBoxMyList div').addClass("modal-md").removeClass("modal-sm");
		$('#modalBoxMyList .content').empty();
		$('#modalBoxMyList .content').load(url);
	}
	if(segment=='m'){
		window.location = '<?php echo base_url().MOBILE_URL_SEGMENT?>/kols/view_profile_summary/<?php echo $kol_id ?>/'+type+'/'+name;
	}
}

function back(){
   listKOLEvents(eventName,topicType); 
}
	    
</script>

<ul class='autoBio'>
	<?php //if($arrKol['profile_type'] != 'Basic'){?>
		<?php if($biographyTextDetails['arrCarrier']['experience'] > 0){?>
		<li><span><?php if($biographyTextDetails['arrCarrier']['experience'] == 1){ echo $biographyTextDetails['arrCarrier']['experience']." Year of experience";}else if($biographyTextDetails['arrCarrier']['experience'] > 1){ echo $biographyTextDetails['arrCarrier']['experience']." Years of experience";}?> </span></li>
		<?php }?>
	<?php //}?>
	<?php if(count($biographyTextDetails['arrCarrier']['education']) > 0){
	foreach($biographyTextDetails['arrCarrier']['education'] as $edu)
				$eduText .= $edu.", ";
	?>
	<li><span>Studied in <?php echo trim($eduText," ,");?></span></li>
	<?php } ?>
	
	<?php if($biographyTextDetails['arrCarrier']['affiliations']['affiliations_left'] > 0 ){?>
	<li><span><?php echo $biographyTextDetails['arrCarrier']['affiliations']['university_name'];?> <?php if($biographyTextDetails['arrCarrier']['affiliations']['affiliations_left'] > 0){?> and <?php echo $biographyTextDetails['arrCarrier']['affiliations']['affiliations_left'];?> other <?php if($biographyTextDetails['arrCarrier']['affiliations']['affiliations_left'] > 1){?>affiliations<?php }else{echo "affiliation";}}?></span></li>
	<?php }else if($biographyTextDetails['arrCarrier']['affiliations']['university_name'] != ''){ ?>
	<li><span> Affiliated with <?php echo $biographyTextDetails['arrCarrier']['affiliations']['university_name']; ?></span></li>
	<?php } ?>
	<?php //pr($biographyTextDetails['speakerEvents']); 
		if($biographyTextDetails['arrCarrier']['speaker_events']['count'] > 0){?>
		<li><span>Speaker in <?php if($biographyTextDetails['arrCarrier']['speaker_events']['count'] > 1){ echo $biographyTextDetails['arrCarrier']['speaker_events']['count']." sessions";}else{echo $biographyTextDetails['arrCarrier']['speaker_events']['count']." session";}?> in <?php if($biographyTextDetails['arrCarrier']['speaker_events']['count'] > 1){ echo "conferences";}else{echo "conference";}?></span></li>
	<?php }?>
	<?php if($biographyTextDetails['arrCarrier']['publications']['count'] > 0){?>
		<li><span><?php echo $biographyTextDetails['arrCarrier']['publications']['count'];?> <?php if($biographyTextDetails['arrCarrier']['publications']['count'] == 1){echo "Publication";}else{echo "Publications";}?><?php if($biographyTextDetails['arrCarrier']['publications']['pub_auth_pos_count']>0){ if($biographyTextDetails['arrCarrier']['publications']['pub_auth_pos_count']>1){echo " with ".$biographyTextDetails['arrCarrier']['publications']['pub_auth_pos_count']." articles as lead author";}else{echo " with ".$biographyTextDetails['arrCarrier']['publications']['pub_auth_pos_count']." article as lead author";}}?></span></li>
	<?php }?>
	<?php if($biographyTextDetails['arrCarrier']['trails']['no_of_trails'] > 0){?>
		<li><span>Investigator in <?php if($biographyTextDetails['arrCarrier']['trails']['no_of_trails'] > 1){ echo $biographyTextDetails['arrCarrier']['trails']['no_of_trails']." clinical studies";}else{ echo $biographyTextDetails['arrCarrier']['trails']['no_of_trails']." clinical study"; }?></span></li>
	<?php }?>
	<?php if($biographyTextDetails['arrCarrier']['interactions']['interactions_by_users_count'] > 0){?>
		<li><span><?php echo $biographyTextDetails['arrCarrier']['interactions']['interactions_by_users_count'];?> <?php if($biographyTextDetails['arrCarrier']['interactions']['interactions_by_users_count'] > 1){ echo "interactions";}else{echo "interaction";}?> entered by <?php echo $biographyTextDetails['arrCarrier']['interactions']['interactions_count']?><?php if($biographyTextDetails['arrCarrier']['interactions']['interactions_count'] > 1){ echo " employees";}else{echo " employee";}?> in last 6 months</span></li>
	<?php }?>
</ul>

<div class="topTopics">
	<div>
	
	<?php 
	if(count($biographyTextDetails['arrTopics']['topic'])>0){
		foreach ($biographyTextDetails['arrTopics']['topic'] as $event){
				$arrTopThreeEvents[] = '<a class="topLinks" onclick="listKOLEvents(\'' .addslashes($event["name"]).'\',\'events\')" >' . $event["name"] . '</a>';//$event["name"];
		}
		if(count($arrTopThreeEvents) > 0){
			echo "<label>Top Event Topics: </label><span>".implode($arrTopThreeEvents	," | ")."</span>";
		}
	}
	?>
	</div>
	<div style="margin-top: 0.4em;">
	<?php 
	if(count($biographyTextDetails['arrTopics']['pub_mesh_terms'])>0){
		foreach ($biographyTextDetails['arrTopics']['pub_mesh_terms'] as $pubTerms){
			$arrTopThreePubTerms[] = '<a class="topLinks" onclick="listKOLEvents(\'' .addslashes($pubTerms["name"]).'\',\'pubs\')" >' . $pubTerms["name"] . '</a>';//$event["name"];
		}
		if(count($arrTopThreePubTerms) > 0){
			echo "<label>Top Publication Topics: </label><span>".implode($arrTopThreePubTerms	," | ")."</span>";
		}
	}
	?>
	</div>
</div>

<?php if($segment=='i') {?>
        <div id="modalBoxMyList" class="modal fade" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
               <button type="button"  style='width:50px' class="close" data-dismiss="modal">&times;</button>
                <h4 class="title"></h4>
            </div>
            <div class="modal-body">
                <div class="content"></div>
            </div>

        </div>
    </div>
</div>
<?php } ?>
