<script type="text/javascript">
$(document).ready(function(){
	var columnSettings={
		title: "Column Settings",
		modal: true,
		autoOpen: false,
		width: 700,
		height: 300,
		dialogClass: "microView",
		draggable:false,
		open: function(){

		}
	};
	$( "#projectFormcontainer" ).dialog(columnSettings);
	getProject();
});

function addProject(){
	$("#projectFormcontainer .profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$('#projectFormcontainer').dialog("open");
	$('.projectFormContent').load(base_url+'identifications/create_project');
}

function editProject(id){
	$("#projectFormcontainer .profileContent").html("<div class='microViewLoading'>Loading...</div>");
	$('#projectFormcontainer').dialog("open");
	$('.projectFormContent').load(base_url+'identifications/edit_project/'+id);
}

function uploadProjectData(id){
	$("#projectFormcontainer .profileContent").html("<form action='"+base_url+"identifications/import_id_project/"+id+"' method='post' enctype='multipart/form-data'><h2 style='text-align:center;'>Project Name :</h2><label>Upload File</label><input name='file_name' type='file' /><input type='submit' value='Import'></form>");
	$('#projectFormcontainer').dialog("open");
}

function getProject(){
	$("#gridProjectListContainer").html("");
	$("#gridProjectListContainer").html('<table id="JQBlistProjectDetails"></table><div id="listProjectDetailsPage"></div>');
	var ele=document.getElementById('gridProjectListContainer');
	var base_url = '<?php echo base_url() ?>';
	var gridWidth=$('#gridProjectListContainer').width();
	jQuery("#JQBlistProjectDetails").jqGrid({
		url: base_url + 'identifications/getIdProject',
		datatype: "json",
		colNames:['Id','Name','Description','Time Range','Created By','Action'],
	   	colModel:[
			{name:'id',index:'id', hidden:true, search:false,width:50},
	   		{name:'name',index:'name',width:50, search:true},
	   		{name:'description',index:'description',width:50,search:true},
	   		{name:'year_range',index:'year_range',width:50},
			{name:'user_name',index:'user_name',width:50,search:true},
			{name:'act',width:45, align:'center',search:false}
			
	   	],
	   	rowNum:10,
	   	rownumbers: true,
	   	autowidth: true, 
	   	loadonce:true,
	   	ignoreCase:true,
	   	hiddengrid:false,
	   	height: "auto",		   
	   	pager: '#listProjectDetailsPage',
	   	toppager:false,
	   	mtype: "POST",
	   	sortname: 'kol_name',
	    viewrecords: true,
	    sortorder: "asc",
	    jsonReader: { repeatitems : false, id: "0" },
	    toolbar: "top",
	    caption:"Id Projects",
   		rowList:paginationValues,
	    gridComplete: function(){	
	    	var ids = jQuery("#JQBlistProjectDetails").jqGrid('getDataIDs');
            for (var i = 0; i < ids.length; i++) {
            	var cl = ids[i];
                var rowData = jQuery("#JQBlistProjectDetails").jqGrid('getRowData', cl);
                var actionLink = '';
                actionLink = "<label><div class='actionIcon editIcon tooltip-demo tooltop-left'><a href='"+base_url+"identifications/edit_project/"+cl+"' class=\"tooltipLink\" rel='tooltip' title=\"Edit\"></a></div></label>";
                actionLink += "<label><div class='uploadIcon tooltip-demo tooltop-left' onclick=\"uploadProjectData('" + cl + "');return false;\"><a href=\"#\" class=\"tooltipLink\" rel='tooltip' title=\"Upload\">Upload/Import</a></div></label>";
//                 actionLink += "<label><div class='actionIcon deleteIcon tooltip-demo tooltop-left'><a href='"+base_url+"identifications/edit_project/"+cl+"' class=\"tooltipLink\" rel='tooltip' title=\"Delete\"></a></div></label>";
//                 actionLink += "<label><div class='enableIcon tooltip-demo tooltop-left'><a href=\"#\" class=\"tooltipLink\" rel='tooltip'>Enable</a></div></label>";
//                 actionLink += "<label><div class='viewStatus tooltip-demo tooltop-left'><a href='"+base_url+"identifications/list_project_associations/"+cl+"' class=\"tooltipLink\" rel='tooltip' title=\"View Status\">View Status</a></div></label>";
                jQuery("#JQBlistProjectDetails").jqGrid('setRowData', ids[i], {act: actionLink});
            }
	    }
	});

	jQuery("#JQBlistProjectDetails").jqGrid('navGrid','#listProjectDetailsPage',{edit:false,add:false,del:false,search:false,refresh:false});

	//Toolbar search bar below the Table Headers
	jQuery("#JQBlistProjectDetails").jqGrid('filterToolbar',{stringResult: true,searchOnEnter : false, defaultSearch:"cn"}); 		
	
	//Toggle Toolbar Search 
	jQuery("#JQBlistProjectDetails").jqGrid('navButtonAdd',"#listProjectDetailsPage",{
		caption:"Search",title:"Toggle Search",
		onClickButton:function(){ 			
			if(jQuery(".ui-search-toolbar").css("display")=="none") {
				jQuery(".ui-search-toolbar").css("display","");
			} else {
				jQuery(".ui-search-toolbar").css("display","none");
			}							
		} 
	}); 
	jQuery("#JQBlistProjectDetails").jqGrid('setGridWidth',gridWidth); 
}
</script>

<style>
h2 {
    font-size: 1.5em;
    font-weight: bold;
}
.table-bordered>tbody>tr>td, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>td, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>thead>tr>th {
    border: 1px solid #ddd;
}
.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    padding: 8px;
    line-height: 3;
    vertical-align: top;
    border-top: 1px solid #ddd;
}
button, input.button{
	top:0px;
}
div.editIcon {
    background-image: url("../images/assign_to_edit_inactive.svg") !important;
    background-position: 0 0px !important;
    background-repeat: no-repeat !important;
    background-size: 20px auto !important;
}

div.deleteIcon {
    background: rgba(0, 0, 0, 0) url("../images/cross_gray.svg") no-repeat scroll 0 0 / 20px auto;
    margin-left: 5px;
    float: left;
}
.tooltipLink {
    text-decoration: none !important;
    display: block !important;
    height: 100%;
    width: 100%;
}
.enableIcon, .viewStatus, .uploadIcon{
 margin-left: 5px;
    float: left;
}
</style>


<div class="rightSideOptions">
	<!--  <a href="#" onclick="addProject(); return false;" class="addLink"><img border="0" style="height: 30px;vertical-align: middle;" src="http://localhost/kolm_core/images/bullet_add.png">Add New Project</a>-->
	<a href="<?php echo base_url();?>identifications/create_project" class="addLink"><img border="0" style="height: 30px;vertical-align: middle;" src="<?php echo base_url();?>images/bullet_add.png">Add New Project</a>
</div>
<div class="gridWrapper" id="gridProjectListContainer">
	<table id="JQBlistProjectDetails"></table>
	<div id="listProjectDetailsPage"></div>
</div>

<div id="projectFormcontainer" class="microProfileDialogBox">
	<div class="projectFormContent profileContent"></div>
</div>
