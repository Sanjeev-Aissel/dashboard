<style type="text/css">
	.nameFormats .egStyle{
		font-style: italic;
    	margin-left: 40px;
	}
	.nameFormats .description{
		font-size: 14px;
    	margin-left: -20px;
	}
	.nameFormats .nameLabel{
		margin-left: 10px;
	}
</style>
<script type="text/javascript">
	function setNameFormat(thisEle){
			jConfirm("You are making changes to the format in which names are displayed. the changes will be applied to all users in your company. Are you sure you want to change this?","Please Confirm",function(r){
					if(r){
						var data = {};
							data['val'] = $(thisEle).val();
							$.ajax({
									url:"<?php echo base_url()?>user_settings/save_name_format",
									type:"post",
									data: data,
									dataType:"json",
									success: function (){
//											
										}
								});
						}else{
							call_selected_setting("name_format");
//							return false;
							}
				});
		}
</script>
<div class="topHeader">
	<div class="headerTitle">
		<div class="titleOfPage"><h3>Set name format</h3></div>
	</div>
</div>
<div style="width: 100%; margin: auto;">
	<table class="nameFormats" style="width: 85%; margin: 20px auto auto;">
		<tr>
			<td ><div class="description">Select the name order format. Your selection will be applied throughout the application and all users will see the names in the same format as you have selected below.</div></td>
		</tr>
		<tr>
			<td><input type="radio" id="opt3" name="name_order[]" value="3" onclick="setNameFormat(this);" <?php if(isset($formatId) && $formatId == 3)echo "checked='checked'";?> checked="checked"><label style="color: #000000;font-weight: 500;" for="opt3" class="nameLabel">Default</label></input></td>
		</tr>
		<tr>
			<td><div class="egStyle">Eg : John Peter Smith (First name Middle name Last name)</div></td>
		</tr>
		<tr>
			<td><input type="radio" id="opt1" name="name_order[]" value="1" onclick="setNameFormat(this);" <?php if(isset($formatId) && $formatId == 1)echo "checked='checked'";?>><label style="color: #000000;font-weight: 500;" for="opt1" class="nameLabel">First name  Last name</label></input></td>
		</tr>
		<tr>
			<td><div class="egStyle">Eg : John Smith (First name Last name)</div></td>
		</tr>
		<tr>
			<td><input type="radio" id="opt2" name="name_order[]" value="2" onclick="setNameFormat(this);" <?php if(isset($formatId) && $formatId == 2)echo "checked='checked'";?>><label style="color: #000000;font-weight: 500;" for="opt2" class="nameLabel">Last name , First name</label></input></td>
		</tr> 
		<tr>
			<td><div class="egStyle">Eg : Smith, John (Last name, First name)</div></td>
		</tr>
	</table>
</div>